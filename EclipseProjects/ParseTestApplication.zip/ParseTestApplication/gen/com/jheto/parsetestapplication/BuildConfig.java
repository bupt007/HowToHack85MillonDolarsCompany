/** Automatically generated file. DO NOT MODIFY */
package com.jheto.parsetestapplication;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}