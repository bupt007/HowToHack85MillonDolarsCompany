package android.support.v4.graphics;

import android.graphics.Bitmap;

class BitmapCompatKitKat
{
  static int getAllocationByteCount(Bitmap paramBitmap)
  {
    return paramBitmap.getAllocationByteCount();
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     android.support.v4.graphics.BitmapCompatKitKat
 * JD-Core Version:    0.6.0
 */