package android.support.v4.graphics;

import android.graphics.Bitmap;

class BitmapCompatHoneycombMr1
{
  static int getAllocationByteCount(Bitmap paramBitmap)
  {
    return paramBitmap.getByteCount();
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     android.support.v4.graphics.BitmapCompatHoneycombMr1
 * JD-Core Version:    0.6.0
 */