package android.support.v4.widget;

abstract interface DrawerLayoutImpl
{
  public abstract void setChildInsets(Object paramObject, boolean paramBoolean);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.DrawerLayoutImpl
 * JD-Core Version:    0.6.0
 */