package android.support.v4.app;

import android.app.ActivityManager;

class ActivityManagerCompatKitKat
{
  public static boolean isLowRamDevice(ActivityManager paramActivityManager)
  {
    return paramActivityManager.isLowRamDevice();
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ActivityManagerCompatKitKat
 * JD-Core Version:    0.6.0
 */