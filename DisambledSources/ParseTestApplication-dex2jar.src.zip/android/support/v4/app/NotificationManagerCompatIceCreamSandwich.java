package android.support.v4.app;

class NotificationManagerCompatIceCreamSandwich
{
  static final int SIDE_CHANNEL_BIND_FLAGS = 33;
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     android.support.v4.app.NotificationManagerCompatIceCreamSandwich
 * JD-Core Version:    0.6.0
 */