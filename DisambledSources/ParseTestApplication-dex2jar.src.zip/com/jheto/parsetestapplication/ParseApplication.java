package com.jheto.parsetestapplication;

import android.app.Application;
import android.content.res.Resources;
import com.parse.Parse;
import com.parse.ParseACL;
import com.parse.ParseCrashReporting;
import com.parse.ParseUser;

public class ParseApplication extends Application
{
  public static String YOUR_APPLICATION_ID = "M2tq6g4vV2xsNgZKqAEw0zkS5odMOaBWcxVqWRWM";
  public static String YOUR_CLIENT_KEY = "uIJY26yLax6QUH6aNN0HpiI3A3UkVKc3vioyIxFv";

  public void onCreate()
  {
    super.onCreate();
    Resources localResources = getResources();
    ParseCrashReporting.enable(this);
    Parse.enableLocalDatastore(this);
    Parse.initialize(this, localResources.getString(2130968579), localResources.getString(2130968580));
    ParseUser.enableAutomaticUser();
    ParseACL.setDefaultACL(new ParseACL(), true);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.jheto.parsetestapplication.ParseApplication
 * JD-Core Version:    0.6.0
 */