package com.jheto.parsetestapplication;

public final class R
{
  public static final class attr
  {
  }

  public static final class drawable
  {
    public static final int ic_launcher = 2130837504;
  }

  public static final class id
  {
    public static final int buttonDeleteEmail = 2131099652;
    public static final int buttonDumpTable = 2131099653;
    public static final int buttonExistEmail = 2131099649;
    public static final int buttonSaveEmail = 2131099651;
    public static final int buttonUpdateEmail = 2131099650;
    public static final int editTextEmail = 2131099648;
    public static final int textViewData = 2131099654;
  }

  public static final class layout
  {
    public static final int activity_main = 2130903040;
  }

  public static final class string
  {
    public static final int YOUR_APPLICATION_ID = 2130968579;
    public static final int YOUR_CLIENT_KEY = 2130968580;
    public static final int action_settings = 2130968578;
    public static final int app_name = 2130968576;
    public static final int hello_world = 2130968577;
  }

  public static final class style
  {
    public static final int AppBaseTheme = 2131034112;
    public static final int AppTheme = 2131034113;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.jheto.parsetestapplication.R
 * JD-Core Version:    0.6.0
 */