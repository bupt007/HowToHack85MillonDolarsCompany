package com.jheto.parsetestapplication;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.jheto.parsetestapplication.BuildConfig
 * JD-Core Version:    0.6.0
 */