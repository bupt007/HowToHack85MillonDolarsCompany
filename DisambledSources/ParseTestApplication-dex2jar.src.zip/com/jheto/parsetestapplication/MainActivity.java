package com.jheto.parsetestapplication;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.parse.DeleteCallback;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.SaveCallback;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends Activity
{
  private TextView textViewData = null;

  private void deleteEmail(String paramString)
  {
    while (true)
    {
      int i;
      try
      {
        List localList = ParseQuery.getQuery("VulnerableTable").find();
        if ((localList == null) || (localList.size() <= 0))
          break;
        i = 0;
        if (i >= localList.size())
          return;
        ParseObject localParseObject = (ParseObject)localList.get(i);
        if (localParseObject.containsKey("email"))
        {
          str = localParseObject.get("email").toString();
          if (!paramString.equals(str))
            break label128;
          localParseObject.deleteInBackground(new DeleteCallback(paramString)
          {
            public void done(ParseException paramParseException)
            {
              MainActivity.this.textViewData.setText("Delete email: " + this.val$emailToDelete);
            }
          });
          return;
        }
      }
      catch (Exception localException)
      {
        this.textViewData.setText("Exception DeleteEmail:" + localException);
        return;
      }
      String str = "";
      continue;
      label128: i++;
    }
  }

  private void dumpEmails()
  {
    while (true)
    {
      int i;
      try
      {
        List localList = ParseQuery.getQuery("VulnerableTable").find();
        if ((localList != null) && (localList.size() > 0))
        {
          String str1 = "";
          i = 0;
          if (i < localList.size())
            continue;
          this.textViewData.setText("Dump emails: " + str1);
          return;
          ParseObject localParseObject = (ParseObject)localList.get(i);
          if (!localParseObject.containsKey("email"))
            continue;
          String str2 = localParseObject.get("email").toString();
          str1 = str1 + str2;
          if (i >= -1 + localList.size())
            break label186;
          str1 = str1 + ",";
          break label186;
          str2 = "";
          continue;
        }
      }
      catch (Exception localException)
      {
        this.textViewData.setText("Exception DumpEmails:" + localException);
      }
      return;
      label186: i++;
    }
  }

  private void existEmail(String paramString, IExist paramIExist)
  {
    try
    {
      ParseQuery localParseQuery = ParseQuery.getQuery("VulnerableTable");
      localParseQuery.whereEqualTo("email", paramString);
      localParseQuery.findInBackground(new FindCallback(paramString, paramIExist)
      {
        public void done(List<ParseObject> paramList, ParseException paramParseException)
        {
          int i = 0;
          if (paramList != null)
          {
            int j = paramList.size();
            i = 0;
            if (j > 0)
            {
              i = 0;
              if (paramList != null)
              {
                int k = paramList.size();
                i = 0;
                if (k <= 0);
              }
            }
          }
          label145: for (int m = 0; ; m++)
          {
            int n = paramList.size();
            i = 0;
            if (m >= n)
            {
              if (i == 0)
                this.val$iexist.exist(false);
              return;
            }
            ParseObject localParseObject = (ParseObject)paramList.get(m);
            if (localParseObject.containsKey("email"));
            for (String str = localParseObject.get("email").toString(); ; str = null)
            {
              if (!this.val$emailToCheck.equals(str))
                break label145;
              i = 1;
              this.val$iexist.exist(true);
              break;
            }
          }
        }
      });
      return;
    }
    catch (Exception localException)
    {
      this.textViewData.setText("Exception ExistEmail:" + localException);
    }
  }

  private void saveEmail(String paramString)
  {
    try
    {
      ParseObject localParseObject = new ParseObject("VulnerableTable");
      localParseObject.put("email", paramString);
      localParseObject.saveInBackground(new SaveCallback(paramString)
      {
        public void done(ParseException paramParseException)
        {
          MainActivity.this.textViewData.setText("Saved Email:" + this.val$email);
        }
      });
      return;
    }
    catch (Exception localException)
    {
      this.textViewData.setText("Exception SaveEmail:" + localException);
    }
  }

  private void updateEmail(String paramString)
  {
    try
    {
      ParseQuery localParseQuery = ParseQuery.getQuery("VulnerableTable");
      localParseQuery.whereEqualTo("email", paramString);
      localParseQuery.findInBackground(new FindCallback(paramString)
      {
        public void done(List<ParseObject> paramList, ParseException paramParseException)
        {
          String str = this.val$emailToUpdate + ".update.com";
          Iterator localIterator;
          if (paramParseException == null)
            localIterator = paramList.iterator();
          while (true)
          {
            if (!localIterator.hasNext())
            {
              MainActivity.this.textViewData.setText("Update Email: " + str);
              return;
            }
            ParseObject localParseObject = (ParseObject)localIterator.next();
            localParseObject.put("email", str);
            localParseObject.saveInBackground();
          }
        }
      });
      return;
    }
    catch (Exception localException)
    {
      this.textViewData.setText("Exception UpdateEmail:" + localException);
    }
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    EditText localEditText = (EditText)findViewById(2131099648);
    Button localButton1 = (Button)findViewById(2131099652);
    Button localButton2 = (Button)findViewById(2131099649);
    Button localButton3 = (Button)findViewById(2131099651);
    Button localButton4 = (Button)findViewById(2131099650);
    Button localButton5 = (Button)findViewById(2131099653);
    this.textViewData = ((TextView)findViewById(2131099654));
    localButton4.setOnClickListener(new View.OnClickListener(localEditText)
    {
      public void onClick(View paramView)
      {
        String str = this.val$editTextEmail.getText().toString();
        if (str.length() > 0)
        {
          MainActivity.this.updateEmail(str);
          return;
        }
        Toast.makeText(MainActivity.this, "Complete the email field", 0).show();
      }
    });
    localButton3.setOnClickListener(new View.OnClickListener(localEditText)
    {
      public void onClick(View paramView)
      {
        String str = this.val$editTextEmail.getText().toString();
        if (str.length() > 0)
        {
          MainActivity.this.saveEmail(str);
          return;
        }
        Toast.makeText(MainActivity.this, "Complete the email field", 0).show();
      }
    });
    localButton1.setOnClickListener(new View.OnClickListener(localEditText)
    {
      public void onClick(View paramView)
      {
        String str = this.val$editTextEmail.getText().toString();
        if (str.length() > 0)
        {
          MainActivity.this.deleteEmail(str);
          return;
        }
        Toast.makeText(MainActivity.this, "Complete the email field", 0).show();
      }
    });
    localButton2.setOnClickListener(new View.OnClickListener(localEditText)
    {
      public void onClick(View paramView)
      {
        String str = this.val$editTextEmail.getText().toString();
        if (str.length() > 0)
        {
          MainActivity.this.existEmail(str, new MainActivity.IExist()
          {
            public void exist(boolean paramBoolean)
            {
              MainActivity.this.textViewData.setText("Exist email: " + paramBoolean);
            }
          });
          return;
        }
        Toast.makeText(MainActivity.this, "Complete the email field", 0).show();
      }
    });
    localButton5.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramView)
      {
        MainActivity.this.dumpEmails();
      }
    });
  }

  static abstract interface IExist
  {
    public abstract void exist(boolean paramBoolean);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.jheto.parsetestapplication.MainActivity
 * JD-Core Version:    0.6.0
 */