package com.parse;

import bolts.Capture;
import bolts.Continuation;
import bolts.Task;
import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import org.json.JSONException;
import org.json.JSONObject;

@ParseClassName("_User")
public class ParseUser extends ParseObject
{
  static final String FILENAME_CURRENT_USER = "currentUser";
  private static final String KEY_AUTH_DATA = "authData";
  private static final String KEY_EMAIL = "email";
  private static final String KEY_IS_NEW = "isNew";
  private static final String KEY_PASSWORD = "password";
  private static final String KEY_SESSION_TOKEN = "sessionToken";
  private static final String KEY_USERNAME = "username";
  private static final Object MUTEX_CURRENT_USER;
  static final String PIN_CURRENT_USER = "_currentUser";
  private static final TaskQueue QUEUE_CURRENT_USER;
  private static final List<String> READ_ONLY_KEYS = Collections.unmodifiableList(Arrays.asList(new String[] { "sessionToken", "isNew" }));
  private static Map<String, ParseAuthenticationProvider> authenticationProviders;
  private static boolean autoUserEnabled;
  static ParseUser currentUser;
  private static boolean currentUserMatchesDisk;
  private static final Object isAutoUserEnabledMutex;
  private static boolean isRevocableSessionEnabled;
  private static final Object isRevocableSessionEnabledMutex;
  private final JSONObject authData = new JSONObject();
  private boolean dirty;
  private boolean isCurrentUser = false;
  private boolean isLazy = false;
  private boolean isNew;
  private final Set<String> linkedServiceNames = new HashSet();
  private String password;
  private final Set<String> readOnlyLinkedServiceNames = Collections.unmodifiableSet(this.linkedServiceNames);
  private String sessionToken;

  static
  {
    MUTEX_CURRENT_USER = new Object();
    QUEUE_CURRENT_USER = new TaskQueue();
    authenticationProviders = new HashMap();
    currentUserMatchesDisk = false;
    isAutoUserEnabledMutex = new Object();
    isRevocableSessionEnabledMutex = new Object();
  }

  public static ParseUser become(String paramString)
    throws ParseException
  {
    return (ParseUser)Parse.waitForTask(becomeInBackground(paramString));
  }

  public static Task<ParseUser> becomeInBackground(String paramString)
  {
    if (paramString == null)
      throw new IllegalArgumentException("Must specify a sessionToken for the user to log in with");
    return ParseRESTUserCommand.getCurrentUserCommand(paramString).executeAsync().onSuccessTask(new Continuation()
    {
      public Task<ParseUser> then(Task<Object> paramTask)
        throws Exception
      {
        JSONObject localJSONObject = (JSONObject)paramTask.getResult();
        if (localJSONObject == JSONObject.NULL)
          return Task.forError(new ParseException(101, "invalid login credentials"));
        return ParseUser.access$100((ParseUser)ParseObject.fromJSON(localJSONObject, "_User", true));
      }
    });
  }

  public static void becomeInBackground(String paramString, LogInCallback paramLogInCallback)
  {
    Parse.callbackOnMainThreadAsync(becomeInBackground(paramString), paramLogInCallback);
  }

  private static void checkApplicationContext()
  {
    if (Parse.applicationContext == null)
      throw new RuntimeException("You must call Parse.initialize(context, oauthKey, oauthSecret) before using the Parse library.");
  }

  private void cleanUpAuthData()
  {
    synchronized (this.mutex)
    {
      Iterator localIterator = this.authData.keys();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if (!this.authData.isNull(str))
          continue;
        localIterator.remove();
        this.linkedServiceNames.remove(str);
        if (!authenticationProviders.containsKey(str))
          continue;
        ((ParseAuthenticationProvider)authenticationProviders.get(str)).restoreAuthentication(null);
      }
    }
    monitorexit;
  }

  static void clearCurrentUserFromMemory()
  {
    synchronized (MUTEX_CURRENT_USER)
    {
      currentUser = null;
      currentUserMatchesDisk = false;
      return;
    }
  }

  private ParseRESTUserCommand currentServiceLogInCommand(ParseOperationSet paramParseOperationSet)
    throws ParseException
  {
    JSONObject localJSONObject1;
    JSONObject localJSONObject2;
    synchronized (this.mutex)
    {
      localJSONObject1 = toJSONObjectForSaving(paramParseOperationSet, PointerEncodingStrategy.get());
      localJSONObject2 = this.authData;
    }
    try
    {
      localJSONObject1.put("authData", localJSONObject2);
      ParseRESTUserCommand localParseRESTUserCommand = ParseRESTUserCommand.serviceLogInUserCommand(localJSONObject1, this.sessionToken, isRevocableSessionEnabled());
      return localParseRESTUserCommand;
      localObject2 = finally;
      monitorexit;
      throw localObject2;
    }
    catch (JSONException localJSONException)
    {
    }
    throw new ParseException(localJSONException);
  }

  static void disableAutomaticUser()
  {
    synchronized (isAutoUserEnabledMutex)
    {
      autoUserEnabled = false;
      return;
    }
  }

  static void disableRevocableSession()
  {
    synchronized (isRevocableSessionEnabledMutex)
    {
      isRevocableSessionEnabled = false;
      return;
    }
  }

  public static void enableAutomaticUser()
  {
    synchronized (isAutoUserEnabledMutex)
    {
      autoUserEnabled = true;
      return;
    }
  }

  public static Task<Void> enableRevocableSessionInBackground()
  {
    synchronized (isRevocableSessionEnabledMutex)
    {
      isRevocableSessionEnabled = true;
      return getCurrentUserAsync(false).onSuccessTask(new Continuation()
      {
        public Task<Void> then(Task<ParseUser> paramTask)
          throws Exception
        {
          ParseUser localParseUser = (ParseUser)paramTask.getResult();
          if (localParseUser == null)
            return Task.forResult(null);
          return localParseUser.upgradeToRevocableSessionAsync();
        }
      });
    }
  }

  static String getCurrentSessionToken()
  {
    ParseUser localParseUser = getCurrentUser();
    if (localParseUser != null)
      return localParseUser.getSessionToken();
    return null;
  }

  static Task<String> getCurrentSessionTokenAsync()
  {
    return getCurrentUserAsync(false).onSuccess(new Continuation()
    {
      public String then(Task<ParseUser> paramTask)
        throws Exception
      {
        ParseUser localParseUser = (ParseUser)paramTask.getResult();
        if (localParseUser != null)
          return localParseUser.getSessionToken();
        return null;
      }
    });
  }

  public static ParseUser getCurrentUser()
  {
    return getCurrentUser(isAutomaticUserEnabled());
  }

  private static ParseUser getCurrentUser(boolean paramBoolean)
  {
    try
    {
      ParseUser localParseUser = (ParseUser)Parse.waitForTask(getCurrentUserAsync(paramBoolean));
      return localParseUser;
    }
    catch (ParseException localParseException)
    {
    }
    return null;
  }

  static Task<ParseUser> getCurrentUserAsync()
  {
    return getCurrentUserAsync(isAutomaticUserEnabled());
  }

  private static Task<ParseUser> getCurrentUserAsync(boolean paramBoolean)
  {
    synchronized (MUTEX_CURRENT_USER)
    {
      if (currentUser != null)
      {
        Task localTask = Task.forResult(currentUser);
        return localTask;
      }
      return QUEUE_CURRENT_USER.enqueue(new Continuation(paramBoolean)
      {
        public Task<ParseUser> then(Task<Void> paramTask)
          throws Exception
        {
          return ParseUser.access$900(this.val$shouldAutoCreateUser, paramTask);
        }
      });
    }
  }

  private static Task<ParseUser> getCurrentUserAsync(boolean paramBoolean, Task<Void> paramTask)
  {
    checkApplicationContext();
    return paramTask.continueWithTask(new Continuation(paramBoolean)
    {
      public Task<ParseUser> then(Task<Void> paramTask)
        throws Exception
      {
        boolean bool;
        synchronized (ParseUser.MUTEX_CURRENT_USER)
        {
          ParseUser localParseUser = ParseUser.currentUser;
          bool = ParseUser.currentUserMatchesDisk;
          if (localParseUser != null)
            return Task.forResult(localParseUser);
        }
        if (bool)
        {
          if (this.val$shouldAutoCreateUser)
            return Task.forResult(ParseAnonymousUtils.lazyLogIn());
          return null;
        }
        if (OfflineStore.isEnabled());
        for (Task localTask = ParseQuery.getQuery(ParseUser.class).fromPin("_currentUser").ignoreACLs().findInBackground().onSuccessTask(new Continuation()
        {
          public Task<ParseUser> then(Task<List<ParseUser>> paramTask)
            throws Exception
          {
            List localList = (List)paramTask.getResult();
            if (localList != null)
            {
              if (localList.size() == 1)
                return Task.forResult(localList.get(0));
              return ParseObject.unpinAllInBackground("_currentUser").cast();
            }
            return Task.forResult(null);
          }
        }).onSuccessTask(new Continuation()
        {
          public Task<ParseUser> then(Task<ParseUser> paramTask)
            throws Exception
          {
            if ((ParseUser)paramTask.getResult() != null)
              return paramTask;
            return ParseObject.migrateFromDiskToLDS("currentUser", "_currentUser").cast();
          }
        }); ; localTask = Task.forResult((ParseUser)ParseObject.getFromDisk(Parse.applicationContext, "currentUser")))
          return localTask.continueWith(new Continuation()
          {
            public ParseUser then(Task<ParseUser> paramTask)
              throws Exception
            {
              boolean bool = true;
              ParseUser localParseUser = (ParseUser)paramTask.getResult();
              if (!paramTask.isFaulted());
              while (true)
              {
                synchronized (ParseUser.MUTEX_CURRENT_USER)
                {
                  ParseUser.currentUser = localParseUser;
                  ParseUser.access$1102(bool);
                  if (localParseUser == null)
                    break;
                }
                synchronized (localParseUser.mutex)
                {
                  ParseUser.access$1202(localParseUser, true);
                  return localParseUser;
                  bool = false;
                  continue;
                  localObject2 = finally;
                  monitorexit;
                  throw localObject2;
                }
              }
              if (ParseUser.10.this.val$shouldAutoCreateUser)
                return ParseAnonymousUtils.lazyLogIn();
              return null;
            }
          });
      }
    });
  }

  private Set<String> getLinkedServiceNames()
  {
    synchronized (this.mutex)
    {
      Set localSet = this.readOnlyLinkedServiceNames;
      return localSet;
    }
  }

  public static ParseQuery<ParseUser> getQuery()
  {
    return ParseQuery.getQuery(ParseUser.class);
  }

  static boolean isAutomaticUserEnabled()
  {
    synchronized (isAutoUserEnabledMutex)
    {
      boolean bool = autoUserEnabled;
      return bool;
    }
  }

  private static boolean isRevocableSessionEnabled()
  {
    synchronized (isRevocableSessionEnabledMutex)
    {
      boolean bool = isRevocableSessionEnabled;
      return bool;
    }
  }

  static boolean isRevocableSessionToken(String paramString)
  {
    return paramString.contains("r:");
  }

  private Task<Void> linkWithAsync(String paramString, JSONObject paramJSONObject, Task<Void> paramTask)
  {
    JSONObject localJSONObject = paramJSONObject.optJSONObject("anonymous");
    synchronized (this.mutex)
    {
      Task localTask = Task.call(new Callable(paramString, paramJSONObject)
      {
        public Void call()
          throws Exception
        {
          synchronized (ParseUser.this.mutex)
          {
            ParseUser.this.authData.put(this.val$authType, this.val$authData);
            ParseUser.this.linkedServiceNames.add(this.val$authType);
            ParseUser.this.stripAnonymity();
            ParseUser.access$702(ParseUser.this, true);
            return null;
          }
        }
      }).onSuccessTask(new Continuation(paramTask)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return ParseUser.this.saveAsync(this.val$toAwait);
        }
      }).continueWithTask(new Continuation(localJSONObject, paramString)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          synchronized (ParseUser.this.mutex)
          {
            if ((paramTask.isFaulted()) || (paramTask.isCancelled()))
            {
              ParseUser.this.restoreAnonymity(this.val$oldAnonymousData);
              return paramTask;
            }
            ParseUser.this.synchronizeAuthData(this.val$authType);
            return paramTask;
          }
        }
      });
      return localTask;
    }
  }

  public static ParseUser logIn(String paramString1, String paramString2)
    throws ParseException
  {
    return (ParseUser)Parse.waitForTask(logInInBackground(paramString1, paramString2));
  }

  public static Task<ParseUser> logInInBackground(String paramString1, String paramString2)
  {
    if (paramString1 == null)
      throw new IllegalArgumentException("Must specify a username for the user to log in with");
    if (paramString2 == null)
      throw new IllegalArgumentException("Must specify a password for the user to log in with");
    return ParseRESTUserCommand.logInUserCommand(paramString1, paramString2, isRevocableSessionEnabled()).executeAsync().onSuccessTask(new Continuation()
    {
      public Task<ParseUser> then(Task<Object> paramTask)
        throws Exception
      {
        JSONObject localJSONObject = (JSONObject)paramTask.getResult();
        if (localJSONObject == JSONObject.NULL)
          throw new ParseException(101, "invalid login credentials");
        return ParseUser.access$100((ParseUser)ParseObject.fromJSON(localJSONObject, "_User", true));
      }
    });
  }

  public static void logInInBackground(String paramString1, String paramString2, LogInCallback paramLogInCallback)
  {
    Parse.callbackOnMainThreadAsync(logInInBackground(paramString1, paramString2), paramLogInCallback);
  }

  // ERROR //
  static ParseUser logInLazyUser(String paramString, JSONObject paramJSONObject)
  {
    // Byte code:
    //   0: ldc 2
    //   2: invokestatic 468	com/parse/ParseObject:create	(Ljava/lang/Class;)Lcom/parse/ParseObject;
    //   5: checkcast 2	com/parse/ParseUser
    //   8: astore_2
    //   9: aload_2
    //   10: getfield 282	com/parse/ParseUser:mutex	Ljava/lang/Object;
    //   13: astore_3
    //   14: aload_3
    //   15: monitorenter
    //   16: aload_2
    //   17: iconst_1
    //   18: putfield 103	com/parse/ParseUser:isCurrentUser	Z
    //   21: aload_2
    //   22: iconst_1
    //   23: putfield 101	com/parse/ParseUser:isLazy	Z
    //   26: aload_2
    //   27: getfield 108	com/parse/ParseUser:authData	Lorg/json/JSONObject;
    //   30: aload_0
    //   31: aload_1
    //   32: invokevirtual 339	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   35: pop
    //   36: aload_2
    //   37: getfield 113	com/parse/ParseUser:linkedServiceNames	Ljava/util/Set;
    //   40: aload_0
    //   41: invokeinterface 471 2 0
    //   46: pop
    //   47: aload_3
    //   48: monitorexit
    //   49: getstatic 82	com/parse/ParseUser:MUTEX_CURRENT_USER	Ljava/lang/Object;
    //   52: astore 8
    //   54: aload 8
    //   56: monitorenter
    //   57: iconst_0
    //   58: putstatic 94	com/parse/ParseUser:currentUserMatchesDisk	Z
    //   61: aload_2
    //   62: putstatic 324	com/parse/ParseUser:currentUser	Lcom/parse/ParseUser;
    //   65: aload 8
    //   67: monitorexit
    //   68: aload_2
    //   69: areturn
    //   70: astore 5
    //   72: new 276	java/lang/RuntimeException
    //   75: dup
    //   76: aload 5
    //   78: invokespecial 472	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   81: athrow
    //   82: astore 4
    //   84: aload_3
    //   85: monitorexit
    //   86: aload 4
    //   88: athrow
    //   89: astore 9
    //   91: aload 8
    //   93: monitorexit
    //   94: aload 9
    //   96: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   26	47	70	org/json/JSONException
    //   16	26	82	finally
    //   26	47	82	finally
    //   47	49	82	finally
    //   72	82	82	finally
    //   84	86	82	finally
    //   57	68	89	finally
    //   91	94	89	finally
  }

  static Task<ParseUser> logInWithAsync(String paramString, JSONObject paramJSONObject)
  {
    18 local18 = new Continuation(paramString, paramJSONObject)
    {
      public Task<ParseUser> then(Task<Void> paramTask)
        throws Exception
      {
        ParseRESTUserCommand localParseRESTUserCommand = ParseRESTUserCommand.serviceLogInUserCommand(this.val$authType, this.val$authData, ParseUser.access$500());
        return localParseRESTUserCommand.executeAsync().onSuccessTask(new Continuation(localParseRESTUserCommand)
        {
          public Task<ParseUser> then(Task<Object> paramTask)
            throws Exception
          {
            boolean bool = true;
            ParseUser localParseUser = (ParseUser)ParseObject.fromJSON((JSONObject)paramTask.getResult(), "_User", bool);
            while (true)
            {
              synchronized (localParseUser.mutex)
              {
                try
                {
                  localParseUser.authData.put(ParseUser.18.this.val$authType, ParseUser.18.this.val$authData);
                  localParseUser.linkedServiceNames.add(ParseUser.18.this.val$authType);
                  if (this.val$command.getStatusCode() == 201)
                  {
                    ParseUser.access$602(localParseUser, bool);
                    return ParseUser.access$100(localParseUser);
                  }
                }
                catch (JSONException localJSONException)
                {
                  throw new ParseException(localJSONException);
                }
              }
              bool = false;
            }
          }
        });
      }
    };
    return getCurrentUserAsync().onSuccessTask(new Continuation(paramString, paramJSONObject, local18)
    {
      public Task<ParseUser> then(Task<ParseUser> paramTask)
        throws Exception
      {
        ParseUser localParseUser = (ParseUser)paramTask.getResult();
        if (localParseUser != null)
        {
          synchronized (localParseUser.mutex)
          {
            if (ParseAnonymousUtils.isLinked(localParseUser))
            {
              if (localParseUser.isLazy())
              {
                JSONObject localJSONObject = localParseUser.authData.optJSONObject("anonymous");
                Task localTask2 = localParseUser.taskQueue.enqueue(new Continuation(localParseUser, localJSONObject)
                {
                  public Task<ParseUser> then(Task<Void> paramTask)
                    throws Exception
                  {
                    return paramTask.continueWithTask(new Continuation()
                    {
                      public Task<Void> then(Task<Void> paramTask)
                        throws Exception
                      {
                        synchronized (ParseUser.19.1.this.val$user.mutex)
                        {
                          ParseUser.19.1.this.val$user.stripAnonymity();
                          ParseUser.19.1.this.val$user.authData.put(ParseUser.19.this.val$authType, ParseUser.19.this.val$authData);
                          ParseUser.19.1.this.val$user.linkedServiceNames.add(ParseUser.19.this.val$authType);
                          Task localTask = ParseUser.19.1.this.val$user.resolveLazinessAsync(paramTask).makeVoid();
                          return localTask;
                        }
                      }
                    }).continueWithTask(new Continuation()
                    {
                      public Task<ParseUser> then(Task<Void> paramTask)
                        throws Exception
                      {
                        synchronized (ParseUser.19.1.this.val$user.mutex)
                        {
                          if (paramTask.isFaulted())
                          {
                            ParseUser.19.1.this.val$user.authData.remove(ParseUser.19.this.val$authType);
                            ParseUser.19.1.this.val$user.linkedServiceNames.remove(ParseUser.19.this.val$authType);
                            ParseUser.19.1.this.val$user.restoreAnonymity(ParseUser.19.1.this.val$oldAnonymousData);
                            Task localTask3 = Task.forError(paramTask.getError());
                            return localTask3;
                          }
                          if (paramTask.isCancelled())
                          {
                            Task localTask2 = Task.cancelled();
                            return localTask2;
                          }
                        }
                        Task localTask1 = Task.forResult(ParseUser.19.1.this.val$user);
                        monitorexit;
                        return localTask1;
                      }
                    });
                  }
                });
                return localTask2;
              }
              Task localTask1 = localParseUser.linkWithAsync(this.val$authType, this.val$authData).continueWithTask(new Continuation(localParseUser)
              {
                public Task<ParseUser> then(Task<Void> paramTask)
                  throws Exception
                {
                  if (paramTask.isFaulted())
                  {
                    Exception localException = paramTask.getError();
                    if (((localException instanceof ParseException)) && (((ParseException)localException).getCode() == 208))
                      return Task.forResult(null).continueWithTask(ParseUser.19.this.val$logInWithTask);
                  }
                  if (paramTask.isCancelled())
                    return Task.cancelled();
                  return Task.forResult(this.val$user);
                }
              });
              return localTask1;
            }
          }
          monitorexit;
        }
        return Task.forResult(null).continueWithTask(this.val$logInWithTask);
      }
    });
  }

  public static void logOut()
  {
    try
    {
      Parse.waitForTask(logOutInBackground());
      return;
    }
    catch (ParseException localParseException)
    {
    }
  }

  private Task<Void> logOutAsync()
  {
    return revokeSessionTokenAsync(logOutInternal());
  }

  public static Task<Void> logOutInBackground()
  {
    return QUEUE_CURRENT_USER.enqueue(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseUser.access$1600(paramTask);
      }
    });
  }

  private static Task<Void> logOutInBackground(Task<Void> paramTask)
  {
    checkApplicationContext();
    return paramTask.continueWithTask(new Continuation(getCurrentUserAsync(false))
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return Task.whenAll(Arrays.asList(new Task[] { this.val$userTask.onSuccessTask(new Continuation()
        {
          public Task<Void> then(Task<ParseUser> paramTask)
            throws Exception
          {
            ParseUser localParseUser = (ParseUser)paramTask.getResult();
            if (localParseUser == null)
              return paramTask.cast();
            return localParseUser.logOutAsync();
          }
        }), this.val$userTask.continueWith(new Continuation()
        {
          public Boolean then(Task<ParseUser> paramTask)
            throws Exception
          {
            return Boolean.valueOf(ParseFileUtils.deleteQuietly(new File(Parse.getParseDir(), "currentUser")));
          }
        }
        , Task.BACKGROUND_EXECUTOR).continueWithTask(new Continuation()
        {
          public Task<Boolean> then(Task<Boolean> paramTask)
            throws Exception
          {
            if (OfflineStore.isEnabled())
              paramTask = ParseObject.unpinAllInBackground("_currentUser").continueWith(new Continuation()
              {
                public Boolean then(Task<Void> paramTask)
                  throws Exception
                {
                  if (!paramTask.isFaulted());
                  for (boolean bool = true; ; bool = false)
                    return Boolean.valueOf(bool);
                }
              });
            return paramTask;
          }
        }).onSuccess(new Continuation()
        {
          public Void then(Task<Boolean> paramTask)
            throws Exception
          {
            boolean bool = ((Boolean)paramTask.getResult()).booleanValue();
            synchronized (ParseUser.MUTEX_CURRENT_USER)
            {
              ParseUser.access$1102(bool);
              ParseUser.currentUser = null;
              return null;
            }
          }
        }) }));
      }
    });
  }

  public static void logOutInBackground(LogOutCallback paramLogOutCallback)
  {
    Parse.callbackOnMainThreadAsync(logOutInBackground(), paramLogOutCallback);
  }

  private String logOutInternal()
  {
    String str;
    synchronized (this.mutex)
    {
      str = this.sessionToken;
      Iterator localIterator = getLinkedServiceNames().iterator();
      if (localIterator.hasNext())
        logOutWith((String)localIterator.next());
    }
    this.isCurrentUser = false;
    this.isNew = false;
    this.sessionToken = null;
    monitorexit;
    return str;
  }

  private void logOutWith(String paramString)
  {
    synchronized (this.mutex)
    {
      ParseAuthenticationProvider localParseAuthenticationProvider = (ParseAuthenticationProvider)authenticationProviders.get(paramString);
      if ((localParseAuthenticationProvider != null) && (this.linkedServiceNames.contains(paramString)))
        localParseAuthenticationProvider.deauthenticate();
      return;
    }
  }

  static Task<Void> pinCurrentUserIfNeededAsync(ParseUser paramParseUser)
  {
    synchronized (MUTEX_CURRENT_USER)
    {
      if ((!paramParseUser.isCurrentUser()) || (currentUserMatchesDisk))
      {
        Task localTask = Task.forResult(null);
        return localTask;
      }
      return saveCurrentUserAsync(paramParseUser).makeVoid();
    }
  }

  static void registerAuthenticationProvider(ParseAuthenticationProvider paramParseAuthenticationProvider)
  {
    authenticationProviders.put(paramParseAuthenticationProvider.getAuthType(), paramParseAuthenticationProvider);
    if ((paramParseAuthenticationProvider instanceof AnonymousAuthenticationProvider));
    ParseUser localParseUser;
    do
    {
      return;
      localParseUser = getCurrentUser();
    }
    while (localParseUser == null);
    localParseUser.synchronizeAuthData(paramParseAuthenticationProvider);
  }

  public static void requestPasswordReset(String paramString)
    throws ParseException
  {
    Parse.waitForTask(requestPasswordResetInBackground(paramString));
  }

  public static Task<Void> requestPasswordResetInBackground(String paramString)
  {
    return ParseRESTUserCommand.resetUserPasswordCommand(paramString).executeAsync().makeVoid();
  }

  public static void requestPasswordResetInBackground(String paramString, RequestPasswordResetCallback paramRequestPasswordResetCallback)
  {
    Parse.callbackOnMainThreadAsync(requestPasswordResetInBackground(paramString), paramRequestPasswordResetCallback);
  }

  private Task<ParseUser> resolveLazinessAsync(Task<Void> paramTask)
  {
    synchronized (this.mutex)
    {
      if (!isLazy())
      {
        Task localTask3 = Task.forResult(null);
        return localTask3;
      }
      if (this.linkedServiceNames.size() == 0)
      {
        Task localTask2 = signUpAsync(paramTask).onSuccess(new Continuation()
        {
          public ParseUser then(Task<Void> paramTask)
            throws Exception
          {
            synchronized (ParseUser.this.mutex)
            {
              ParseUser.access$802(ParseUser.this, false);
              ParseUser localParseUser = ParseUser.this;
              return localParseUser;
            }
          }
        });
        return localTask2;
      }
    }
    Capture localCapture = new Capture();
    Task localTask1 = Task.call(new Callable()
    {
      public ParseOperationSet call()
        throws Exception
      {
        return ParseUser.this.startSave();
      }
    }).onSuccessTask(TaskQueue.waitFor(paramTask)).onSuccessTask(new Continuation(localCapture)
    {
      public Task<ParseUser> then(Task<ParseOperationSet> paramTask)
        throws Exception
      {
        this.val$operations.set(paramTask.getResult());
        ParseRESTUserCommand localParseRESTUserCommand = ParseUser.this.currentServiceLogInCommand((ParseOperationSet)this.val$operations.get());
        return localParseRESTUserCommand.executeAsync().onSuccessTask(new Continuation(localParseRESTUserCommand)
        {
          public Task<ParseUser> then(Task<Object> paramTask)
            throws Exception
          {
            JSONObject localJSONObject = (JSONObject)paramTask.getResult();
            boolean bool;
            if (this.val$command.getStatusCode() == 201)
            {
              bool = true;
              if ((!OfflineStore.isEnabled()) || (bool))
                break label59;
            }
            label59: for (Task localTask = Task.forResult(localJSONObject); ; localTask = ParseUser.this.handleSaveResultAsync(localJSONObject, (ParseOperationSet)ParseUser.25.this.val$operations.get()).onSuccess(new Continuation(localJSONObject)
            {
              public JSONObject then(Task<Void> paramTask)
                throws Exception
              {
                return this.val$commandResult;
              }
            }))
            {
              return localTask.onSuccessTask(new Continuation(bool)
              {
                public Task<ParseUser> then(Task<JSONObject> paramTask)
                  throws Exception
                {
                  JSONObject localJSONObject = (JSONObject)paramTask.getResult();
                  synchronized (ParseUser.this.mutex)
                  {
                    ParseUser.access$702(ParseUser.this, false);
                    if (this.val$isNew)
                    {
                      ParseUser.access$802(ParseUser.this, false);
                      Task localTask = Task.forResult(ParseUser.this);
                      return localTask;
                    }
                    return ParseUser.access$100((ParseUser)ParseObject.fromJSON(localJSONObject, "_User", true));
                  }
                }
              });
              bool = false;
              break;
            }
          }
        });
      }
    });
    monitorexit;
    return localTask1;
  }

  private void restoreAnonymity(JSONObject paramJSONObject)
  {
    Object localObject1 = this.mutex;
    monitorenter;
    if (paramJSONObject != null);
    try
    {
      this.linkedServiceNames.add("anonymous");
      try
      {
        this.authData.put("anonymous", paramJSONObject);
        monitorexit;
        return;
      }
      catch (JSONException localJSONException)
      {
        throw new RuntimeException(localJSONException);
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject2;
  }

  private Task<Void> revokeSessionTokenAsync(String paramString)
  {
    if ((paramString == null) || (!isRevocableSessionToken(paramString)))
      return Task.forResult(null);
    return ParseRESTUserCommand.logOutUserCommand(paramString).executeAsync().makeVoid();
  }

  private static Task<ParseUser> saveCurrentUserAsync(ParseUser paramParseUser)
  {
    return QUEUE_CURRENT_USER.enqueue(new Continuation(paramParseUser)
    {
      public Task<ParseUser> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseUser.access$1300(this.val$user, paramTask);
      }
    });
  }

  private static Task<ParseUser> saveCurrentUserAsync(ParseUser paramParseUser, Task<Void> paramTask)
  {
    checkApplicationContext();
    return paramTask.continueWithTask(new Continuation(paramParseUser)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        synchronized (ParseUser.MUTEX_CURRENT_USER)
        {
          ParseUser localParseUser = ParseUser.currentUser;
          if ((localParseUser != null) && (localParseUser != this.val$user))
            localParseUser.logOutInternal();
        }
        synchronized (this.val$user.mutex)
        {
          ParseUser.access$1202(this.val$user, true);
          this.val$user.synchronizeAllAuthData();
          if (OfflineStore.isEnabled())
          {
            return ParseObject.unpinAllInBackground("_currentUser").continueWithTask(new Continuation()
            {
              public Task<Void> then(Task<Void> paramTask)
                throws Exception
              {
                return ParseUser.14.this.val$user.pinInBackground("_currentUser", false);
              }
            });
            localObject2 = finally;
            monitorexit;
            throw localObject2;
          }
        }
        return Task.call(new Callable()
        {
          public Void call()
            throws Exception
          {
            ParseUser.14.this.val$user.saveToDisk(Parse.applicationContext, "currentUser");
            return null;
          }
        }
        , Task.BACKGROUND_EXECUTOR);
      }
    }).continueWith(new Continuation(paramParseUser)
    {
      public ParseUser then(Task<Void> paramTask)
        throws Exception
      {
        synchronized (ParseUser.MUTEX_CURRENT_USER)
        {
          if (!paramTask.isFaulted())
          {
            bool = true;
            ParseUser.access$1102(bool);
            ParseUser.currentUser = this.val$user;
            return this.val$user;
          }
          boolean bool = false;
        }
      }
    });
  }

  private Task<Void> signUpAsync(Task<Void> paramTask)
  {
    ParseUser localParseUser = getCurrentUser();
    Object localObject1 = this.mutex;
    monitorenter;
    if (localParseUser != null);
    while (true)
    {
      try
      {
        str1 = localParseUser.getSessionToken();
        if ((getUsername() != null) && (getUsername().length() != 0))
          continue;
        Task localTask1 = Task.forError(new IllegalArgumentException("Username cannot be missing or blank"));
        return localTask1;
        if (this.password == null)
        {
          Task localTask10 = Task.forError(new IllegalArgumentException("Password cannot be missing or blank"));
          return localTask10;
        }
      }
      finally
      {
        monitorexit;
      }
      String str2 = getObjectId();
      if (str2 != null)
      {
        try
        {
          if ((this.authData.has("anonymous")) && (this.authData.get("anonymous") == JSONObject.NULL))
          {
            Task localTask9 = saveAsync(paramTask);
            monitorexit;
            return localTask9;
          }
        }
        catch (JSONException localJSONException2)
        {
          Task localTask7 = Task.forError(new RuntimeException(localJSONException2));
          monitorexit;
          return localTask7;
        }
        Task localTask8 = Task.forError(new IllegalArgumentException("Cannot sign up a user that has already signed up."));
        monitorexit;
        return localTask8;
      }
      if (this.operationSetQueue.size() > 1)
      {
        Task localTask6 = Task.forError(new IllegalArgumentException("Cannot sign up a user that is already signing up."));
        monitorexit;
        return localTask6;
      }
      if ((localParseUser != null) && (ParseAnonymousUtils.isLinked(localParseUser)))
      {
        if (this == localParseUser)
        {
          Task localTask2 = Task.forError(new IllegalArgumentException("Attempt to merge currentUser with itself."));
          monitorexit;
          return localTask2;
        }
        checkForChangesToMutableContainers();
        localParseUser.checkForChangesToMutableContainers();
        String str3 = localParseUser.getUsername();
        String str4 = localParseUser.password;
        try
        {
          JSONObject localJSONObject = localParseUser.authData.getJSONObject("anonymous");
          localParseUser.copyChangesFrom(this);
          localParseUser.dirty = true;
          localParseUser.setPassword(this.password);
          localParseUser.setUsername(getUsername());
          revert();
          Task localTask4 = localParseUser.saveAsync(paramTask).continueWithTask(new Continuation(localParseUser, str3, str4, localJSONObject)
          {
            public Task<Void> then(Task<Void> paramTask)
              throws Exception
            {
              if ((paramTask.isCancelled()) || (paramTask.isFaulted()))
                synchronized (this.val$user.mutex)
                {
                  if (this.val$oldUsername != null)
                    this.val$user.setUsername(this.val$oldUsername);
                  ParseUser.access$302(this.val$user, this.val$oldPassword);
                  this.val$user.restoreAnonymity(this.val$anonymousData);
                  return paramTask;
                }
              ParseUser.this.mergeFromObject(this.val$user);
              return ParseUser.access$100(ParseUser.this).makeVoid();
            }
          });
          monitorexit;
          return localTask4;
        }
        catch (JSONException localJSONException1)
        {
          Task localTask3 = Task.forError(new RuntimeException(localJSONException1));
          monitorexit;
          return localTask3;
        }
      }
      Task localTask5 = Task.call(new Callable()
      {
        public ParseOperationSet call()
          throws Exception
        {
          synchronized (ParseUser.this.mutex)
          {
            ParseOperationSet localParseOperationSet = ParseUser.this.startSave();
            return localParseOperationSet;
          }
        }
      }).continueWithTask(TaskQueue.waitFor(paramTask)).onSuccessTask(new Continuation(str1)
      {
        public Task<Void> then(Task<ParseOperationSet> paramTask)
          throws Exception
        {
          ParseOperationSet localParseOperationSet = (ParseOperationSet)paramTask.getResult();
          return ParseRESTUserCommand.signUpUserCommand(ParseUser.this.toJSONObjectForSaving(localParseOperationSet, PointerEncodingStrategy.get()), this.val$sessionToken, ParseUser.access$500()).executeAsync().continueWithTask(new Continuation(localParseOperationSet)
          {
            public Task<Void> then(Task<Object> paramTask)
              throws Exception
            {
              return ParseUser.this.handleSaveResultAsync((JSONObject)paramTask.getResult(), this.val$operations).continueWithTask(new Continuation(paramTask)
              {
                public Task<Void> then(Task<Void> paramTask)
                  throws Exception
                {
                  if ((!this.val$signUpTask.isCancelled()) && (!this.val$signUpTask.isFaulted()))
                    synchronized (ParseUser.this.mutex)
                    {
                      ParseUser.access$602(ParseUser.this, true);
                      ParseUser.access$702(ParseUser.this, false);
                      ParseUser.access$802(ParseUser.this, false);
                      return ParseUser.access$100(ParseUser.this).makeVoid();
                    }
                  return this.val$signUpTask.makeVoid();
                }
              });
            }
          });
        }
      });
      monitorexit;
      return localTask5;
      String str1 = null;
    }
  }

  private void stripAnonymity()
  {
    synchronized (this.mutex)
    {
      if (ParseAnonymousUtils.isLinked(this))
        this.linkedServiceNames.remove("anonymous");
      try
      {
        if (getObjectId() != null)
          this.authData.put("anonymous", JSONObject.NULL);
        while (true)
        {
          this.dirty = true;
          return;
          this.authData.remove("anonymous");
        }
      }
      catch (JSONException localJSONException)
      {
        throw new RuntimeException(localJSONException);
      }
    }
  }

  private void synchronizeAllAuthData()
  {
    synchronized (this.mutex)
    {
      Iterator localIterator = this.authData.keys();
      if (localIterator.hasNext())
        synchronizeAuthData((String)localIterator.next());
    }
    monitorexit;
  }

  private void synchronizeAuthData(String paramString)
  {
    ParseAuthenticationProvider localParseAuthenticationProvider;
    synchronized (this.mutex)
    {
      if (!isCurrentUser())
        return;
      localParseAuthenticationProvider = (ParseAuthenticationProvider)authenticationProviders.get(paramString);
      if (localParseAuthenticationProvider == null)
        return;
    }
    synchronizeAuthData(localParseAuthenticationProvider);
    monitorexit;
  }

  private Task<Void> upgradeToRevocableSessionAsync(Task<Void> paramTask)
  {
    String str = getSessionToken();
    if ((str == null) || (isRevocableSessionToken(str)))
      return paramTask;
    return paramTask.continueWithTask(new Continuation(str)
    {
      public Task<JSONObject> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseRESTUserCommand.upgradeRevocableSessionCommand(this.val$sessionToken).executeAsync().cast();
      }
    }).onSuccessTask(new Continuation()
    {
      public Task<Void> then(Task<JSONObject> paramTask)
        throws Exception
      {
        ParseSession localParseSession = (ParseSession)ParseObject.fromJSON((JSONObject)paramTask.getResult(), "_Session", true);
        return ParseUser.this.setSessionTokenInBackground(localParseSession.getSessionToken());
      }
    });
  }

  public ParseUser fetch()
    throws ParseException
  {
    return (ParseUser)super.fetch();
  }

  <T extends ParseObject> Task<T> fetchAsync(Task<Void> paramTask)
  {
    synchronized (this.mutex)
    {
      if (isLazy())
      {
        Task localTask2 = Task.forResult(this);
        return localTask2;
      }
      Task localTask1 = super.fetchAsync(paramTask).onSuccessTask(new Continuation()
      {
        public Task<T> then(Task<T> paramTask)
          throws Exception
        {
          if (ParseUser.this.isCurrentUser())
          {
            ParseUser.this.cleanUpAuthData();
            paramTask = ParseUser.access$100(ParseUser.this).continueWithTask(new Continuation(paramTask)
            {
              public Task<T> then(Task<ParseUser> paramTask)
                throws Exception
              {
                return this.val$fetchAsyncTask;
              }
            });
          }
          return paramTask;
        }
      });
      return localTask1;
    }
  }

  <T extends ParseObject> Task<T> fetchFromLocalDatastoreAsync()
  {
    if (isLazy())
      return Task.forResult(this);
    return super.fetchFromLocalDatastoreAsync();
  }

  public ParseUser fetchIfNeeded()
    throws ParseException
  {
    return (ParseUser)super.fetchIfNeeded();
  }

  public String getEmail()
  {
    return getString("email");
  }

  public String getSessionToken()
  {
    synchronized (this.mutex)
    {
      String str = this.sessionToken;
      return str;
    }
  }

  public String getUsername()
  {
    return getString("username");
  }

  public boolean isAuthenticated()
  {
    while (true)
    {
      synchronized (this.mutex)
      {
        ParseUser localParseUser = getCurrentUser();
        if (!isLazy())
        {
          if ((this.sessionToken == null) || (localParseUser == null) || (!getObjectId().equals(localParseUser.getObjectId())))
            break label62;
          break label56;
          return i;
        }
      }
      label56: int i = 1;
      continue;
      label62: i = 0;
    }
  }

  boolean isCurrentUser()
  {
    synchronized (this.mutex)
    {
      boolean bool = this.isCurrentUser;
      return bool;
    }
  }

  boolean isDirty(boolean paramBoolean)
  {
    return (this.dirty) || (super.isDirty(paramBoolean));
  }

  boolean isKeyMutable(String paramString)
  {
    return !READ_ONLY_KEYS.contains(paramString);
  }

  boolean isLazy()
  {
    synchronized (this.mutex)
    {
      boolean bool = this.isLazy;
      return bool;
    }
  }

  boolean isLinked(String paramString)
  {
    return getLinkedServiceNames().contains(paramString);
  }

  public boolean isNew()
  {
    synchronized (this.mutex)
    {
      boolean bool = this.isNew;
      return bool;
    }
  }

  Task<Void> linkWithAsync(String paramString, JSONObject paramJSONObject)
  {
    return this.taskQueue.enqueue(new Continuation(paramString, paramJSONObject)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseUser.this.linkWithAsync(this.val$authType, this.val$authData, paramTask);
      }
    });
  }

  void mergeFromDiskJSON(JSONObject paramJSONObject)
  {
    synchronized (this.mutex)
    {
      String str1 = paramJSONObject.optString("session_token", null);
      if (str1 != null)
      {
        this.sessionToken = str1;
        paramJSONObject.remove("session_token");
      }
      JSONObject localJSONObject = paramJSONObject.optJSONObject("auth_data");
      if (localJSONObject == null)
        break label152;
      try
      {
        Iterator localIterator = localJSONObject.keys();
        while (localIterator.hasNext())
        {
          String str2 = (String)localIterator.next();
          if (!localJSONObject.isNull(str2))
          {
            this.authData.put(str2, localJSONObject.get(str2));
            this.linkedServiceNames.add(str2);
          }
          synchronizeAuthData(str2);
        }
      }
      catch (JSONException localJSONException)
      {
        throw new RuntimeException(localJSONException);
      }
    }
    paramJSONObject.remove("auth_data");
    label152: super.mergeFromDiskJSON(paramJSONObject);
    monitorexit;
  }

  void mergeFromObject(ParseObject paramParseObject)
  {
    synchronized (this.mutex)
    {
      super.mergeFromObject(paramParseObject);
      if (this == paramParseObject)
        return;
      if (!(paramParseObject instanceof ParseUser))
        break label193;
      this.sessionToken = ((ParseUser)paramParseObject).sessionToken;
      this.isNew = ((ParseUser)paramParseObject).isNew();
      Iterator localIterator1 = this.authData.keys();
      if (localIterator1.hasNext())
      {
        localIterator1.next();
        localIterator1.remove();
      }
    }
    Iterator localIterator2 = ((ParseUser)paramParseObject).authData.keys();
    while (localIterator2.hasNext())
    {
      String str = (String)localIterator2.next();
      try
      {
        Object localObject3 = ((ParseUser)paramParseObject).authData.get(str);
        this.authData.put(str, localObject3);
      }
      catch (JSONException localJSONException)
      {
        throw new RuntimeException("A JSONException occurred where one was not possible.");
      }
    }
    this.linkedServiceNames.clear();
    this.linkedServiceNames.addAll(((ParseUser)paramParseObject).linkedServiceNames);
    label193: monitorexit;
  }

  void mergeFromServer(JSONObject paramJSONObject, ParseDecoder paramParseDecoder, boolean paramBoolean)
  {
    synchronized (this.mutex)
    {
      String str1 = paramJSONObject.optString("sessionToken", null);
      if (str1 != null)
        this.sessionToken = str1;
      JSONObject localJSONObject = paramJSONObject.optJSONObject("authData");
      if (localJSONObject != null)
        try
        {
          Iterator localIterator = localJSONObject.keys();
          while (localIterator.hasNext())
          {
            String str2 = (String)localIterator.next();
            if (!localJSONObject.isNull(str2))
            {
              this.authData.put(str2, localJSONObject.get(str2));
              this.linkedServiceNames.add(str2);
            }
            synchronizeAuthData(str2);
          }
        }
        catch (JSONException localJSONException)
        {
          throw new RuntimeException(localJSONException);
        }
    }
    if (paramJSONObject.has("is_new"))
      this.isNew = paramJSONObject.optBoolean("is_new");
    paramJSONObject.remove("session_token");
    paramJSONObject.remove("sessionToken");
    super.mergeFromServer(paramJSONObject, paramParseDecoder, paramBoolean);
    monitorexit;
  }

  void mergeREST(JSONObject paramJSONObject, ParseDecoder paramParseDecoder)
  {
    synchronized (this.mutex)
    {
      super.mergeREST(paramJSONObject, paramParseDecoder);
      boolean bool1 = paramJSONObject.has("sessionToken");
      if (!bool1);
    }
    try
    {
      this.sessionToken = paramJSONObject.getString("sessionToken");
      boolean bool2 = paramJSONObject.has("authData");
      if (bool2)
      {
        try
        {
          JSONObject localJSONObject = paramJSONObject.getJSONObject("authData");
          Iterator localIterator = localJSONObject.keys();
          while (localIterator.hasNext())
          {
            String str = (String)localIterator.next();
            this.authData.put(str, localJSONObject.get(str));
            if (!localJSONObject.isNull(str))
              this.linkedServiceNames.add(str);
            synchronizeAuthData(str);
          }
        }
        catch (JSONException localJSONException2)
        {
          throw new RuntimeException(localJSONException2);
        }
        localObject2 = finally;
        monitorexit;
        throw localObject2;
      }
    }
    catch (JSONException localJSONException3)
    {
      throw new RuntimeException(localJSONException3.getMessage());
    }
    boolean bool3 = paramJSONObject.has("isNew");
    if (bool3);
    try
    {
      this.isNew = paramJSONObject.getBoolean("isNew");
      monitorexit;
      return;
    }
    catch (JSONException localJSONException1)
    {
    }
    throw new RuntimeException(localJSONException1);
  }

  boolean needsDefaultACL()
  {
    return false;
  }

  public void put(String paramString, Object paramObject)
  {
    synchronized (this.mutex)
    {
      if ("username".equals(paramString))
        stripAnonymity();
      if ("password".equals(paramString))
      {
        setPassword((String)paramObject);
        return;
      }
      super.put(paramString, paramObject);
      return;
    }
  }

  public void remove(String paramString)
  {
    if ("username".equals(paramString))
      throw new IllegalArgumentException("Can't remove the username key.");
    super.remove(paramString);
  }

  Task<Void> saveAsync(Task<Void> paramTask)
  {
    synchronized (this.mutex)
    {
      if (isLazy())
      {
        localTask1 = resolveLazinessAsync(paramTask).makeVoid();
        Task localTask2 = localTask1.onSuccessTask(new Continuation()
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            if (ParseUser.this.isCurrentUser())
            {
              ParseUser.this.cleanUpAuthData();
              return ParseUser.access$100(ParseUser.this).makeVoid();
            }
            return Task.forResult(null);
          }
        });
        return localTask2;
      }
      Task localTask1 = super.saveAsync(paramTask);
    }
  }

  public void setEmail(String paramString)
  {
    put("email", paramString);
  }

  public void setPassword(String paramString)
  {
    synchronized (this.mutex)
    {
      this.password = paramString;
      this.dirty = true;
      return;
    }
  }

  Task<Void> setSessionTokenInBackground(String paramString)
  {
    synchronized (this.mutex)
    {
      this.sessionToken = paramString;
      Task localTask = saveCurrentUserAsync(this).makeVoid();
      return localTask;
    }
  }

  public void setUsername(String paramString)
  {
    put("username", paramString);
  }

  public void signUp()
    throws ParseException
  {
    Parse.waitForTask(signUpInBackground());
  }

  public Task<Void> signUpInBackground()
  {
    return this.taskQueue.enqueue(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseUser.this.signUpAsync(paramTask);
      }
    });
  }

  public void signUpInBackground(SignUpCallback paramSignUpCallback)
  {
    Parse.callbackOnMainThreadAsync(signUpInBackground(), paramSignUpCallback);
  }

  void synchronizeAuthData(ParseAuthenticationProvider paramParseAuthenticationProvider)
  {
    synchronized (this.mutex)
    {
      String str = paramParseAuthenticationProvider.getAuthType();
      if (!paramParseAuthenticationProvider.restoreAuthentication(this.authData.optJSONObject(str)))
        unlinkFromAsync(str);
      return;
    }
  }

  // ERROR //
  JSONObject toJSONObjectForDataFile(boolean paramBoolean, ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 282	com/parse/ParseUser:mutex	Ljava/lang/Object;
    //   4: astore_3
    //   5: aload_3
    //   6: monitorenter
    //   7: aload_0
    //   8: iload_1
    //   9: aload_2
    //   10: invokespecial 790	com/parse/ParseObject:toJSONObjectForDataFile	(ZLcom/parse/ParseObjectEncodingStrategy;)Lorg/json/JSONObject;
    //   13: astore 5
    //   15: aload_0
    //   16: getfield 341	com/parse/ParseUser:sessionToken	Ljava/lang/String;
    //   19: astore 6
    //   21: aload 6
    //   23: ifnull +16 -> 39
    //   26: aload 5
    //   28: ldc_w 718
    //   31: aload_0
    //   32: getfield 341	com/parse/ParseUser:sessionToken	Ljava/lang/String;
    //   35: invokevirtual 339	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   38: pop
    //   39: aload_0
    //   40: getfield 108	com/parse/ParseUser:authData	Lorg/json/JSONObject;
    //   43: invokevirtual 791	org/json/JSONObject:length	()I
    //   46: istore 7
    //   48: iload 7
    //   50: ifle +16 -> 66
    //   53: aload 5
    //   55: ldc_w 724
    //   58: aload_0
    //   59: getfield 108	com/parse/ParseUser:authData	Lorg/json/JSONObject;
    //   62: invokevirtual 339	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   65: pop
    //   66: aload_3
    //   67: monitorexit
    //   68: aload 5
    //   70: areturn
    //   71: astore 10
    //   73: new 276	java/lang/RuntimeException
    //   76: dup
    //   77: ldc_w 793
    //   80: invokespecial 279	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   83: athrow
    //   84: astore 4
    //   86: aload_3
    //   87: monitorexit
    //   88: aload 4
    //   90: athrow
    //   91: astore 8
    //   93: new 276	java/lang/RuntimeException
    //   96: dup
    //   97: ldc_w 795
    //   100: invokespecial 279	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   103: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   26	39	71	org/json/JSONException
    //   7	21	84	finally
    //   26	39	84	finally
    //   39	48	84	finally
    //   53	66	84	finally
    //   66	68	84	finally
    //   73	84	84	finally
    //   86	88	84	finally
    //   93	104	84	finally
    //   53	66	91	org/json/JSONException
  }

  // ERROR //
  JSONObject toJSONObjectForSaving(ParseOperationSet paramParseOperationSet, ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 282	com/parse/ParseUser:mutex	Ljava/lang/Object;
    //   4: astore_3
    //   5: aload_3
    //   6: monitorenter
    //   7: aload_0
    //   8: aload_1
    //   9: aload_2
    //   10: invokespecial 796	com/parse/ParseObject:toJSONObjectForSaving	(Lcom/parse/ParseOperationSet;Lcom/parse/ParseObjectEncodingStrategy;)Lorg/json/JSONObject;
    //   13: astore 5
    //   15: aload_0
    //   16: getfield 108	com/parse/ParseUser:authData	Lorg/json/JSONObject;
    //   19: invokevirtual 791	org/json/JSONObject:length	()I
    //   22: istore 6
    //   24: iload 6
    //   26: ifle +15 -> 41
    //   29: aload 5
    //   31: ldc 14
    //   33: aload_0
    //   34: getfield 108	com/parse/ParseUser:authData	Lorg/json/JSONObject;
    //   37: invokevirtual 339	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   40: pop
    //   41: aload_0
    //   42: getfield 205	com/parse/ParseUser:password	Ljava/lang/String;
    //   45: astore 7
    //   47: aload 7
    //   49: ifnull +15 -> 64
    //   52: aload 5
    //   54: ldc 23
    //   56: aload_0
    //   57: getfield 205	com/parse/ParseUser:password	Ljava/lang/String;
    //   60: invokevirtual 339	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   63: pop
    //   64: aload_3
    //   65: monitorexit
    //   66: aload 5
    //   68: areturn
    //   69: astore 10
    //   71: new 276	java/lang/RuntimeException
    //   74: dup
    //   75: ldc_w 798
    //   78: invokespecial 279	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   81: athrow
    //   82: astore 4
    //   84: aload_3
    //   85: monitorexit
    //   86: aload 4
    //   88: athrow
    //   89: astore 8
    //   91: new 276	java/lang/RuntimeException
    //   94: dup
    //   95: ldc_w 800
    //   98: invokespecial 279	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   101: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   29	41	69	org/json/JSONException
    //   7	24	82	finally
    //   29	41	82	finally
    //   41	47	82	finally
    //   52	64	82	finally
    //   64	66	82	finally
    //   71	82	82	finally
    //   84	86	82	finally
    //   91	102	82	finally
    //   52	64	89	org/json/JSONException
  }

  // ERROR //
  JSONObject toRest(ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 282	com/parse/ParseUser:mutex	Ljava/lang/Object;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aload_0
    //   8: aload_1
    //   9: invokespecial 804	com/parse/ParseObject:toRest	(Lcom/parse/ParseObjectEncodingStrategy;)Lorg/json/JSONObject;
    //   12: astore 4
    //   14: aload_0
    //   15: getfield 341	com/parse/ParseUser:sessionToken	Ljava/lang/String;
    //   18: astore 5
    //   20: aload 5
    //   22: ifnull +15 -> 37
    //   25: aload 4
    //   27: ldc 26
    //   29: aload_0
    //   30: getfield 341	com/parse/ParseUser:sessionToken	Ljava/lang/String;
    //   33: invokevirtual 339	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   36: pop
    //   37: aload_0
    //   38: getfield 108	com/parse/ParseUser:authData	Lorg/json/JSONObject;
    //   41: invokevirtual 791	org/json/JSONObject:length	()I
    //   44: istore 6
    //   46: iload 6
    //   48: ifle +15 -> 63
    //   51: aload 4
    //   53: ldc 14
    //   55: aload_0
    //   56: getfield 108	com/parse/ParseUser:authData	Lorg/json/JSONObject;
    //   59: invokevirtual 339	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   62: pop
    //   63: aload_2
    //   64: monitorexit
    //   65: aload 4
    //   67: areturn
    //   68: astore 9
    //   70: new 276	java/lang/RuntimeException
    //   73: dup
    //   74: ldc_w 806
    //   77: invokespecial 279	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   80: athrow
    //   81: astore_3
    //   82: aload_2
    //   83: monitorexit
    //   84: aload_3
    //   85: athrow
    //   86: astore 7
    //   88: new 276	java/lang/RuntimeException
    //   91: dup
    //   92: ldc_w 798
    //   95: invokespecial 279	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   98: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   25	37	68	org/json/JSONException
    //   7	20	81	finally
    //   25	37	81	finally
    //   37	46	81	finally
    //   51	63	81	finally
    //   63	65	81	finally
    //   70	81	81	finally
    //   82	84	81	finally
    //   88	99	81	finally
    //   51	63	86	org/json/JSONException
  }

  Task<Void> unlinkFromAsync(String paramString)
  {
    Object localObject1 = this.mutex;
    monitorenter;
    if (paramString == null);
    try
    {
      Task localTask2 = Task.forResult(null);
      return localTask2;
      Task localTask1 = Task.forResult(null).continueWithTask(new Continuation(paramString)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          synchronized (ParseUser.this.mutex)
          {
            if (ParseUser.this.authData.has(this.val$authType))
            {
              ParseUser.this.authData.put(this.val$authType, JSONObject.NULL);
              ParseUser.access$702(ParseUser.this, true);
              Task localTask2 = ParseUser.this.saveInBackground();
              return localTask2;
            }
            Task localTask1 = Task.forResult(null);
            return localTask1;
          }
        }
      });
      return localTask1;
    }
    finally
    {
      monitorexit;
    }
    throw localObject2;
  }

  Task<Void> upgradeToRevocableSessionAsync()
  {
    return this.taskQueue.enqueue(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseUser.this.upgradeToRevocableSessionAsync(paramTask);
      }
    });
  }

  void validateDelete()
  {
    synchronized (this.mutex)
    {
      super.validateDelete();
      if ((!isAuthenticated()) && (isDirty()))
        throw new IllegalArgumentException("Cannot delete a ParseUser that is not authenticated.");
    }
    monitorexit;
  }

  void validateSave()
  {
    synchronized (this.mutex)
    {
      if (getObjectId() == null)
        throw new IllegalArgumentException("Cannot save a ParseUser until it has been signed up. Call signUp first.");
    }
    if ((isAuthenticated()) || (!isDirty()) || (isCurrentUser()))
    {
      monitorexit;
      return;
    }
    monitorexit;
    if (!OfflineStore.isEnabled())
    {
      ParseUser localParseUser = getCurrentUser();
      if ((localParseUser != null) && (getObjectId().equals(localParseUser.getObjectId())));
    }
    else
    {
      throw new IllegalArgumentException("Cannot save a ParseUser that is not authenticated.");
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseUser
 * JD-Core Version:    0.6.0
 */