package com.parse;

abstract interface ReportSender
{
  public abstract void send(CrashReportData paramCrashReportData)
    throws ReportSenderException;
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ReportSender
 * JD-Core Version:    0.6.0
 */