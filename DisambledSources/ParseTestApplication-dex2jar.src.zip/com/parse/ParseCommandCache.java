package com.parse;

import android.content.Context;
import android.content.Intent;
import bolts.Capture;
import bolts.Continuation;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONObject;

class ParseCommandCache extends ParseEventuallyQueue
{
  private static final String TAG = "com.parse.ParseCommandCache";
  private static int filenameCounter = 0;
  private static final Object lock = new Object();
  private File cachePath;
  ConnectivityNotifier.ConnectivityListener listener = new ConnectivityNotifier.ConnectivityListener()
  {
    public void networkConnectivityStatusChanged(Context paramContext, Intent paramIntent)
    {
      if (paramIntent.getBooleanExtra("noConnectivity", false))
      {
        ParseCommandCache.this.setConnected(false);
        return;
      }
      ParseCommandCache.this.setConnected(ConnectivityNotifier.isConnected(paramContext));
    }
  };
  private Logger log;
  private int maxCacheSizeBytes = 10485760;
  ConnectivityNotifier notifier;
  private HashMap<File, Task<Object>.TaskCompletionSource> pendingTasks = new HashMap();
  private boolean running;
  private final Object runningLock;
  private boolean shouldStop;
  private int timeoutMaxRetries = 5;
  private double timeoutRetryWaitSeconds = 600.0D;
  private boolean unprocessedCommandsExist;

  public ParseCommandCache(Context paramContext)
  {
    setConnected(false);
    this.shouldStop = false;
    this.running = false;
    this.runningLock = new Object();
    this.log = Logger.getLogger("com.parse.ParseCommandCache");
    this.cachePath = getCacheDir();
    if (!Parse.hasPermission("android.permission.ACCESS_NETWORK_STATE"))
      return;
    setConnected(ConnectivityNotifier.isConnected(paramContext));
    this.notifier = ConnectivityNotifier.getNotifier(paramContext);
    this.notifier.addListener(this.listener);
    resume();
  }

  private Task<Object> enqueueEventuallyAsync(ParseNetworkCommand paramParseNetworkCommand, boolean paramBoolean, ParseObject paramParseObject)
  {
    Parse.requirePermission("android.permission.ACCESS_NETWORK_STATE");
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    if (paramParseObject != null);
    byte[] arrayOfByte;
    try
    {
      if (paramParseObject.getObjectId() == null)
        paramParseNetworkCommand.setLocalId(paramParseObject.getOrCreateLocalId());
      arrayOfByte = paramParseNetworkCommand.toJSONObject().toString().getBytes("UTF-8");
      if (arrayOfByte.length > this.maxCacheSizeBytes)
      {
        if (5 >= Parse.getLogLevel())
          this.log.warning("Unable to save command for later because it's too big.");
        notifyTestHelper(4);
        return Task.forResult(null);
      }
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      if (5 >= Parse.getLogLevel())
        this.log.log(Level.WARNING, "UTF-8 isn't supported.  This shouldn't happen.", localUnsupportedEncodingException);
      notifyTestHelper(4);
      return Task.forResult(null);
    }
    Object localObject1 = lock;
    monitorenter;
    while (true)
    {
      try
      {
        String[] arrayOfString = this.cachePath.list();
        if (arrayOfString == null)
          continue;
        Arrays.sort(arrayOfString);
        int i = 0;
        int j = arrayOfString.length;
        int k = 0;
        if (k >= j)
          continue;
        String str1 = arrayOfString[k];
        i += (int)new File(this.cachePath, str1).length();
        k++;
        continue;
        int m = i + arrayOfByte.length;
        int n = this.maxCacheSizeBytes;
        if (m <= n)
          continue;
        if (!paramBoolean)
          continue;
        if (5 < Parse.getLogLevel())
          continue;
        this.log.warning("Unable to save command for later because storage is full.");
        Task localTask = Task.forResult(null);
        try
        {
          lock.notifyAll();
          return localTask;
        }
        finally
        {
          monitorexit;
        }
        if (5 >= Parse.getLogLevel())
        {
          this.log.warning("Deleting old commands to make room in command cache.");
          break label652;
          int i3 = this.maxCacheSizeBytes;
          if ((m <= i3) || (i2 >= arrayOfString.length))
            continue;
          File localFile2 = this.cachePath;
          int i4 = i2 + 1;
          File localFile3 = new File(localFile2, arrayOfString[i2]);
          m -= (int)localFile3.length();
          removeFile(localFile3);
          i2 = i4;
          continue;
          String str2 = Long.toHexString(System.currentTimeMillis());
          if (str2.length() >= 16)
            continue;
          char[] arrayOfChar2 = new char[16 - str2.length()];
          Arrays.fill(arrayOfChar2, '0');
          StringBuilder localStringBuilder2 = new StringBuilder();
          String str5 = new String(arrayOfChar2);
          str2 = str5 + str2;
          int i1 = filenameCounter;
          filenameCounter = i1 + 1;
          String str3 = Integer.toHexString(i1);
          if (str3.length() >= 8)
            continue;
          char[] arrayOfChar1 = new char[8 - str3.length()];
          Arrays.fill(arrayOfChar1, '0');
          StringBuilder localStringBuilder1 = new StringBuilder();
          String str4 = new String(arrayOfChar1);
          str3 = str4 + str3;
          File localFile1 = File.createTempFile("CachedCommand_" + str2 + "_" + str3 + "_", "", this.cachePath);
          this.pendingTasks.put(localFile1, localTaskCompletionSource);
          paramParseNetworkCommand.retainLocalIds();
          ParseFileUtils.writeByteArrayToFile(localFile1, arrayOfByte);
          notifyTestHelper(3);
          this.unprocessedCommandsExist = true;
          lock.notifyAll();
          monitorexit;
          return localTaskCompletionSource.getTask();
        }
      }
      catch (IOException localIOException)
      {
        if (5 < Parse.getLogLevel())
          continue;
        this.log.log(Level.WARNING, "Unable to save command for later.", localIOException);
        lock.notifyAll();
        continue;
      }
      finally
      {
        lock.notifyAll();
      }
      label652: int i2 = 0;
    }
  }

  private static File getCacheDir()
  {
    File localFile = new File(Parse.getParseDir(), "CommandCache");
    localFile.mkdirs();
    return localFile;
  }

  public static int getPendingCount()
  {
    synchronized (lock)
    {
      String[] arrayOfString = getCacheDir().list();
      if (arrayOfString == null)
      {
        i = 0;
        return i;
      }
      int i = arrayOfString.length;
    }
  }

  // ERROR //
  private void maybeRunAllCommandsNow(int paramInt)
  {
    // Byte code:
    //   0: getstatic 43	com/parse/ParseCommandCache:lock	Ljava/lang/Object;
    //   3: astore_2
    //   4: aload_2
    //   5: monitorenter
    //   6: aload_0
    //   7: iconst_0
    //   8: putfield 286	com/parse/ParseCommandCache:unprocessedCommandsExist	Z
    //   11: aload_0
    //   12: invokevirtual 315	com/parse/ParseCommandCache:isConnected	()Z
    //   15: ifne +6 -> 21
    //   18: aload_2
    //   19: monitorexit
    //   20: return
    //   21: aload_0
    //   22: getfield 90	com/parse/ParseCommandCache:cachePath	Ljava/io/File;
    //   25: invokevirtual 204	java/io/File:list	()[Ljava/lang/String;
    //   28: astore 4
    //   30: aload 4
    //   32: ifnull +9 -> 41
    //   35: aload 4
    //   37: arraylength
    //   38: ifne +11 -> 49
    //   41: aload_2
    //   42: monitorexit
    //   43: return
    //   44: astore_3
    //   45: aload_2
    //   46: monitorexit
    //   47: aload_3
    //   48: athrow
    //   49: aload 4
    //   51: invokestatic 210	java/util/Arrays:sort	([Ljava/lang/Object;)V
    //   54: aload 4
    //   56: arraylength
    //   57: istore 5
    //   59: iconst_0
    //   60: istore 6
    //   62: iload 6
    //   64: iload 5
    //   66: if_icmpge +552 -> 618
    //   69: aload 4
    //   71: iload 6
    //   73: aaload
    //   74: astore 7
    //   76: new 200	java/io/File
    //   79: dup
    //   80: aload_0
    //   81: getfield 90	com/parse/ParseCommandCache:cachePath	Ljava/io/File;
    //   84: aload 7
    //   86: invokespecial 213	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   89: astore 8
    //   91: aload 8
    //   93: invokestatic 319	com/parse/ParseFileUtils:readFileToByteArray	(Ljava/io/File;)[B
    //   96: astore 12
    //   98: new 166	java/lang/String
    //   101: dup
    //   102: aload 12
    //   104: ldc 164
    //   106: invokespecial 322	java/lang/String:<init>	([BLjava/lang/String;)V
    //   109: astore 13
    //   111: new 159	org/json/JSONObject
    //   114: dup
    //   115: aload 13
    //   117: invokespecial 324	org/json/JSONObject:<init>	(Ljava/lang/String;)V
    //   120: astore 14
    //   122: aload_0
    //   123: getfield 59	com/parse/ParseCommandCache:pendingTasks	Ljava/util/HashMap;
    //   126: aload 8
    //   128: invokevirtual 328	java/util/HashMap:containsKey	(Ljava/lang/Object;)Z
    //   131: ifeq +490 -> 621
    //   134: aload_0
    //   135: getfield 59	com/parse/ParseCommandCache:pendingTasks	Ljava/util/HashMap;
    //   138: aload 8
    //   140: invokevirtual 332	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   143: checkcast 288	bolts/Task$TaskCompletionSource
    //   146: astore 29
    //   148: aload 29
    //   150: astore 15
    //   152: aload_0
    //   153: aload 14
    //   155: invokevirtual 336	com/parse/ParseCommandCache:commandFromJSON	(Lorg/json/JSONObject;)Lcom/parse/ParseNetworkCommand;
    //   158: astore 17
    //   160: aload 17
    //   162: invokevirtual 339	com/parse/ParseNetworkCommand:getLocalId	()Ljava/lang/String;
    //   165: astore 24
    //   167: aload 17
    //   169: invokevirtual 342	com/parse/ParseNetworkCommand:executeAsync	()Lbolts/Task;
    //   172: astore 25
    //   174: new 344	com/parse/ParseCommandCache$4
    //   177: dup
    //   178: aload_0
    //   179: aload 15
    //   181: aload 24
    //   183: aload 17
    //   185: invokespecial 347	com/parse/ParseCommandCache$4:<init>	(Lcom/parse/ParseCommandCache;Lbolts/Task$TaskCompletionSource;Ljava/lang/String;Lcom/parse/ParseNetworkCommand;)V
    //   188: astore 26
    //   190: aload_0
    //   191: aload 25
    //   193: aload 26
    //   195: invokevirtual 351	bolts/Task:continueWithTask	(Lbolts/Continuation;)Lbolts/Task;
    //   198: invokespecial 355	com/parse/ParseCommandCache:waitForTaskWithoutLock	(Lbolts/Task;)Ljava/lang/Object;
    //   201: pop
    //   202: aload 15
    //   204: ifnull +13 -> 217
    //   207: aload_0
    //   208: aload 15
    //   210: invokevirtual 292	bolts/Task$TaskCompletionSource:getTask	()Lbolts/Task;
    //   213: invokespecial 355	com/parse/ParseCommandCache:waitForTaskWithoutLock	(Lbolts/Task;)Ljava/lang/Object;
    //   216: pop
    //   217: aload_0
    //   218: aload 8
    //   220: invokespecial 228	com/parse/ParseCommandCache:removeFile	(Ljava/io/File;)V
    //   223: aload_0
    //   224: iconst_1
    //   225: invokevirtual 183	com/parse/ParseCommandCache:notifyTestHelper	(I)V
    //   228: iinc 6 1
    //   231: goto -169 -> 62
    //   234: astore 11
    //   236: bipush 6
    //   238: invokestatic 174	com/parse/Parse:getLogLevel	()I
    //   241: if_icmplt -13 -> 228
    //   244: aload_0
    //   245: getfield 84	com/parse/ParseCommandCache:log	Ljava/util/logging/Logger;
    //   248: getstatic 358	java/util/logging/Level:SEVERE	Ljava/util/logging/Level;
    //   251: ldc_w 360
    //   254: aload 11
    //   256: invokevirtual 198	java/util/logging/Logger:log	(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   259: goto -31 -> 228
    //   262: astore 10
    //   264: bipush 6
    //   266: invokestatic 174	com/parse/Parse:getLogLevel	()I
    //   269: if_icmplt +18 -> 287
    //   272: aload_0
    //   273: getfield 84	com/parse/ParseCommandCache:log	Ljava/util/logging/Logger;
    //   276: getstatic 358	java/util/logging/Level:SEVERE	Ljava/util/logging/Level;
    //   279: ldc_w 362
    //   282: aload 10
    //   284: invokevirtual 198	java/util/logging/Logger:log	(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   287: aload_0
    //   288: aload 8
    //   290: invokespecial 228	com/parse/ParseCommandCache:removeFile	(Ljava/io/File;)V
    //   293: goto -65 -> 228
    //   296: astore 9
    //   298: bipush 6
    //   300: invokestatic 174	com/parse/Parse:getLogLevel	()I
    //   303: if_icmplt +18 -> 321
    //   306: aload_0
    //   307: getfield 84	com/parse/ParseCommandCache:log	Ljava/util/logging/Logger;
    //   310: getstatic 358	java/util/logging/Level:SEVERE	Ljava/util/logging/Level;
    //   313: ldc_w 364
    //   316: aload 9
    //   318: invokevirtual 198	java/util/logging/Logger:log	(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   321: aload_0
    //   322: aload 8
    //   324: invokespecial 228	com/parse/ParseCommandCache:removeFile	(Ljava/io/File;)V
    //   327: goto -99 -> 228
    //   330: astore 16
    //   332: bipush 6
    //   334: invokestatic 174	com/parse/Parse:getLogLevel	()I
    //   337: if_icmplt +18 -> 355
    //   340: aload_0
    //   341: getfield 84	com/parse/ParseCommandCache:log	Ljava/util/logging/Logger;
    //   344: getstatic 358	java/util/logging/Level:SEVERE	Ljava/util/logging/Level;
    //   347: ldc_w 366
    //   350: aload 16
    //   352: invokevirtual 198	java/util/logging/Logger:log	(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   355: aload_0
    //   356: aload 8
    //   358: invokespecial 228	com/parse/ParseCommandCache:removeFile	(Ljava/io/File;)V
    //   361: goto -133 -> 228
    //   364: astore 18
    //   366: aload 18
    //   368: invokevirtual 369	com/parse/ParseException:getCode	()I
    //   371: bipush 100
    //   373: if_icmpne +206 -> 579
    //   376: iload_1
    //   377: ifle +188 -> 565
    //   380: iconst_4
    //   381: invokestatic 174	com/parse/Parse:getLogLevel	()I
    //   384: if_icmplt +49 -> 433
    //   387: aload_0
    //   388: getfield 84	com/parse/ParseCommandCache:log	Ljava/util/logging/Logger;
    //   391: new 247	java/lang/StringBuilder
    //   394: dup
    //   395: invokespecial 248	java/lang/StringBuilder:<init>	()V
    //   398: ldc_w 371
    //   401: invokevirtual 255	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   404: aload_0
    //   405: getfield 51	com/parse/ParseCommandCache:timeoutRetryWaitSeconds	D
    //   408: invokevirtual 374	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   411: ldc_w 376
    //   414: invokevirtual 255	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   417: iload_1
    //   418: invokevirtual 379	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   421: ldc_w 381
    //   424: invokevirtual 255	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   427: invokevirtual 256	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   430: invokevirtual 384	java/util/logging/Logger:info	(Ljava/lang/String;)V
    //   433: invokestatic 233	java/lang/System:currentTimeMillis	()J
    //   436: lstore 19
    //   438: lload 19
    //   440: ldc2_w 385
    //   443: aload_0
    //   444: getfield 51	com/parse/ParseCommandCache:timeoutRetryWaitSeconds	D
    //   447: dmul
    //   448: d2l
    //   449: ladd
    //   450: lstore 21
    //   452: lload 19
    //   454: lload 21
    //   456: lcmp
    //   457: ifge +98 -> 555
    //   460: aload_0
    //   461: invokevirtual 315	com/parse/ParseCommandCache:isConnected	()Z
    //   464: ifeq +10 -> 474
    //   467: aload_0
    //   468: getfield 72	com/parse/ParseCommandCache:shouldStop	Z
    //   471: ifeq +23 -> 494
    //   474: iconst_4
    //   475: invokestatic 174	com/parse/Parse:getLogLevel	()I
    //   478: if_icmplt +13 -> 491
    //   481: aload_0
    //   482: getfield 84	com/parse/ParseCommandCache:log	Ljava/util/logging/Logger;
    //   485: ldc_w 388
    //   488: invokevirtual 384	java/util/logging/Logger:info	(Ljava/lang/String;)V
    //   491: aload_2
    //   492: monitorexit
    //   493: return
    //   494: getstatic 43	com/parse/ParseCommandCache:lock	Ljava/lang/Object;
    //   497: lload 21
    //   499: lload 19
    //   501: lsub
    //   502: invokevirtual 392	java/lang/Object:wait	(J)V
    //   505: invokestatic 233	java/lang/System:currentTimeMillis	()J
    //   508: lstore 19
    //   510: lload 19
    //   512: lload 21
    //   514: ldc2_w 385
    //   517: aload_0
    //   518: getfield 51	com/parse/ParseCommandCache:timeoutRetryWaitSeconds	D
    //   521: dmul
    //   522: d2l
    //   523: lsub
    //   524: lcmp
    //   525: ifge -73 -> 452
    //   528: lload 21
    //   530: ldc2_w 385
    //   533: aload_0
    //   534: getfield 51	com/parse/ParseCommandCache:timeoutRetryWaitSeconds	D
    //   537: dmul
    //   538: d2l
    //   539: lsub
    //   540: lstore 19
    //   542: goto -90 -> 452
    //   545: astore 23
    //   547: aload_0
    //   548: iconst_1
    //   549: putfield 72	com/parse/ParseCommandCache:shouldStop	Z
    //   552: goto -47 -> 505
    //   555: aload_0
    //   556: iload_1
    //   557: iconst_1
    //   558: isub
    //   559: invokespecial 394	com/parse/ParseCommandCache:maybeRunAllCommandsNow	(I)V
    //   562: goto -334 -> 228
    //   565: aload_0
    //   566: iconst_0
    //   567: invokevirtual 70	com/parse/ParseCommandCache:setConnected	(Z)V
    //   570: aload_0
    //   571: bipush 7
    //   573: invokevirtual 183	com/parse/ParseCommandCache:notifyTestHelper	(I)V
    //   576: goto -348 -> 228
    //   579: bipush 6
    //   581: invokestatic 174	com/parse/Parse:getLogLevel	()I
    //   584: if_icmplt +18 -> 602
    //   587: aload_0
    //   588: getfield 84	com/parse/ParseCommandCache:log	Ljava/util/logging/Logger;
    //   591: getstatic 358	java/util/logging/Level:SEVERE	Ljava/util/logging/Level;
    //   594: ldc_w 396
    //   597: aload 18
    //   599: invokevirtual 198	java/util/logging/Logger:log	(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   602: aload_0
    //   603: aload 8
    //   605: invokespecial 228	com/parse/ParseCommandCache:removeFile	(Ljava/io/File;)V
    //   608: aload_0
    //   609: iconst_2
    //   610: aload 18
    //   612: invokevirtual 399	com/parse/ParseCommandCache:notifyTestHelper	(ILjava/lang/Throwable;)V
    //   615: goto -387 -> 228
    //   618: aload_2
    //   619: monitorexit
    //   620: return
    //   621: aconst_null
    //   622: astore 15
    //   624: goto -472 -> 152
    //
    // Exception table:
    //   from	to	target	type
    //   6	20	44	finally
    //   21	30	44	finally
    //   35	41	44	finally
    //   41	43	44	finally
    //   45	47	44	finally
    //   49	59	44	finally
    //   69	91	44	finally
    //   91	122	44	finally
    //   122	148	44	finally
    //   152	160	44	finally
    //   160	202	44	finally
    //   207	217	44	finally
    //   217	228	44	finally
    //   236	259	44	finally
    //   264	287	44	finally
    //   287	293	44	finally
    //   298	321	44	finally
    //   321	327	44	finally
    //   332	355	44	finally
    //   355	361	44	finally
    //   366	376	44	finally
    //   380	433	44	finally
    //   433	452	44	finally
    //   460	474	44	finally
    //   474	491	44	finally
    //   491	493	44	finally
    //   494	505	44	finally
    //   505	542	44	finally
    //   547	552	44	finally
    //   555	562	44	finally
    //   565	576	44	finally
    //   579	602	44	finally
    //   602	615	44	finally
    //   618	620	44	finally
    //   91	122	234	java/io/FileNotFoundException
    //   91	122	262	java/io/IOException
    //   91	122	296	org/json/JSONException
    //   152	160	330	org/json/JSONException
    //   160	202	364	com/parse/ParseException
    //   207	217	364	com/parse/ParseException
    //   217	228	364	com/parse/ParseException
    //   494	505	545	java/lang/InterruptedException
  }

  private void removeFile(File paramFile)
  {
    synchronized (lock)
    {
      this.pendingTasks.remove(paramFile);
    }
    try
    {
      commandFromJSON(new JSONObject(new String(ParseFileUtils.readFileToByteArray(paramFile), "UTF-8"))).releaseLocalIds();
      label42: ParseFileUtils.deleteQuietly(paramFile);
      monitorexit;
      return;
      localObject2 = finally;
      monitorexit;
      throw localObject2;
    }
    catch (Exception localException)
    {
      break label42;
    }
  }

  private void runLoop()
  {
    if (4 >= Parse.getLogLevel())
      this.log.info("Parse command cache has started processing queued commands.");
    int i;
    while (true)
    {
      Object localObject7;
      synchronized (this.runningLock)
      {
        if (this.running)
          return;
        this.running = true;
        this.runningLock.notifyAll();
        synchronized (lock)
        {
          if ((!this.shouldStop) && (!Thread.interrupted()))
          {
            i = 1;
            if (i == 0)
              break label222;
            localObject7 = lock;
            monitorenter;
          }
        }
      }
      try
      {
        maybeRunAllCommandsNow(this.timeoutMaxRetries);
        boolean bool = this.shouldStop;
        if (!bool);
        try
        {
          if (!this.unprocessedCommandsExist)
            lock.wait();
          try
          {
            if (this.shouldStop)
              break label276;
            i = 1;
            monitorexit;
            continue;
          }
          finally
          {
            monitorexit;
          }
          localObject2 = finally;
          monitorexit;
          throw localObject2;
          i = 0;
          continue;
          localObject4 = finally;
          monitorexit;
          throw localObject4;
        }
        catch (InterruptedException localInterruptedException)
        {
          while (true)
            this.shouldStop = true;
        }
      }
      catch (Exception localException)
      {
        if (6 >= Parse.getLogLevel())
          this.log.log(Level.SEVERE, "saveEventually thread had an error.", localException);
        if (this.shouldStop)
          break label282;
        i = 1;
      }
      finally
      {
        if (this.shouldStop);
      }
    }
    while (true)
      throw localObject8;
    label222: synchronized (this.runningLock)
    {
      this.running = false;
      this.runningLock.notifyAll();
      if (4 >= Parse.getLogLevel())
      {
        this.log.info("saveEventually thread has stopped processing commands.");
        return;
      }
    }
    return;
    while (true)
    {
      break;
      label276: i = 0;
      break;
      label282: i = 0;
    }
  }

  private <T> T waitForTaskWithoutLock(Task<T> paramTask)
    throws ParseException
  {
    synchronized (lock)
    {
      Capture localCapture = new Capture(Boolean.valueOf(false));
      paramTask.continueWith(new Continuation(localCapture)
      {
        public Void then(Task<T> paramTask)
          throws Exception
        {
          this.val$finished.set(Boolean.valueOf(true));
          synchronized (ParseCommandCache.lock)
          {
            ParseCommandCache.lock.notifyAll();
            return null;
          }
        }
      }
      , Task.BACKGROUND_EXECUTOR);
      while (true)
      {
        boolean bool = ((Boolean)localCapture.get()).booleanValue();
        if (!bool)
          try
          {
            lock.wait();
          }
          catch (InterruptedException localInterruptedException)
          {
            this.shouldStop = true;
          }
      }
    }
    Object localObject3 = Parse.waitForTask(paramTask);
    monitorexit;
    return localObject3;
  }

  public void clear()
  {
    synchronized (lock)
    {
      File[] arrayOfFile = this.cachePath.listFiles();
      if (arrayOfFile == null)
        return;
      int i = arrayOfFile.length;
      for (int j = 0; j < i; j++)
        removeFile(arrayOfFile[j]);
      this.pendingTasks.clear();
      return;
    }
  }

  public Task<Object> enqueueEventuallyAsync(ParseNetworkCommand paramParseNetworkCommand, ParseObject paramParseObject)
  {
    return enqueueEventuallyAsync(paramParseNetworkCommand, false, paramParseObject);
  }

  void fakeObjectUpdate()
  {
    notifyTestHelper(3);
    notifyTestHelper(1);
    notifyTestHelper(5);
  }

  public void onDestroy()
  {
    this.notifier.removeListener(this.listener);
  }

  public void pause()
  {
    synchronized (this.runningLock)
    {
      if (this.running);
      synchronized (lock)
      {
        this.shouldStop = true;
        lock.notifyAll();
        while (true)
        {
          boolean bool = this.running;
          if (bool)
            try
            {
              this.runningLock.wait();
            }
            catch (InterruptedException localInterruptedException)
            {
            }
        }
      }
    }
    monitorexit;
  }

  public int pendingCount()
  {
    return getPendingCount();
  }

  public void resume()
  {
    synchronized (this.runningLock)
    {
      if (!this.running)
        new Thread("ParseCommandCache.runLoop()")
        {
          public void run()
          {
            ParseCommandCache.this.runLoop();
          }
        }
        .start();
      try
      {
        this.runningLock.wait();
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        synchronized (lock)
        {
          this.shouldStop = true;
          lock.notifyAll();
        }
      }
    }
  }

  public void setConnected(boolean paramBoolean)
  {
    synchronized (lock)
    {
      if ((isConnected() != paramBoolean) && (paramBoolean))
        lock.notifyAll();
      super.setConnected(paramBoolean);
      return;
    }
  }

  public void setMaxCacheSizeBytes(int paramInt)
  {
    synchronized (lock)
    {
      this.maxCacheSizeBytes = paramInt;
      return;
    }
  }

  public void setTimeoutMaxRetries(int paramInt)
  {
    synchronized (lock)
    {
      this.timeoutMaxRetries = paramInt;
      return;
    }
  }

  public void setTimeoutRetryWaitSeconds(double paramDouble)
  {
    synchronized (lock)
    {
      this.timeoutRetryWaitSeconds = paramDouble;
      return;
    }
  }

  void simulateReboot()
  {
    synchronized (lock)
    {
      this.pendingTasks.clear();
      return;
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseCommandCache
 * JD-Core Version:    0.6.0
 */