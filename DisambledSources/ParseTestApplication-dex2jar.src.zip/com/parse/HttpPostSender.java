package com.parse;

import android.net.Uri;
import android.util.Log;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

class HttpPostSender
  implements ReportSender
{
  private Uri mFormUri = null;

  public HttpPostSender(String paramString)
  {
    this.mFormUri = Uri.parse(paramString);
  }

  private Map<String, String> remap(Map<ReportField, String> paramMap)
  {
    HashMap localHashMap = new HashMap(paramMap.size());
    for (ReportField localReportField : ACRA.ALL_CRASH_REPORT_FIELDS)
      localHashMap.put(localReportField.toString(), paramMap.get(localReportField));
    return localHashMap;
  }

  public void send(CrashReportData paramCrashReportData)
    throws ReportSenderException
  {
    try
    {
      Map localMap = remap(paramCrashReportData);
      URL localURL = new URL(this.mFormUri.toString());
      Log.d("CrashReporting", "Connect to " + localURL.toString());
      HttpUtils.doPost(localMap, localURL, ACRA.getConfig().formPostFormat());
      return;
    }
    catch (Exception localException)
    {
    }
    throw new ReportSenderException("Error while sending report to Http Post Form.", localException);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.HttpPostSender
 * JD-Core Version:    0.6.0
 */