package com.parse;

import android.content.Context;
import java.io.IOException;
import org.apache.http.client.methods.HttpUriRequest;

abstract class ParseHttpClient
{
  public static ParseHttpClient create(Context paramContext)
  {
    return new ParseApacheHttpClient(paramContext);
  }

  public abstract ParseHttpResponse execute(HttpUriRequest paramHttpUriRequest)
    throws IOException;
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseHttpClient
 * JD-Core Version:    0.6.0
 */