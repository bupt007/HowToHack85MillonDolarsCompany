package com.parse;

import android.content.Context;
import android.text.format.Time;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

class DropBoxCollector
{
  private static final String[] SYSTEM_TAGS = { "system_app_anr", "system_app_wtf", "system_app_crash", "system_server_anr", "system_server_wtf", "system_server_crash", "BATTERY_DISCHARGE_INFO", "SYSTEM_RECOVERY_LOG", "SYSTEM_BOOT", "SYSTEM_LAST_KMSG", "APANIC_CONSOLE", "APANIC_THREADS", "SYSTEM_RESTART", "SYSTEM_TOMBSTONE", "data_app_strictmode" };

  public static String read(Context paramContext, String[] paramArrayOfString)
  {
    try
    {
      String str1 = Compatibility.getDropBoxServiceName();
      if (str1 != null)
      {
        localStringBuilder = new StringBuilder();
        Object localObject1 = paramContext.getSystemService(str1);
        Class localClass1 = localObject1.getClass();
        Class[] arrayOfClass1 = new Class[2];
        arrayOfClass1[0] = String.class;
        arrayOfClass1[1] = Long.TYPE;
        Method localMethod1 = localClass1.getMethod("getNextEntry", arrayOfClass1);
        if (localMethod1 == null)
          break label555;
        Time localTime = new Time();
        localTime.setToNow();
        localTime.minute -= ACRA.getConfig().dropboxCollectionMinutes();
        localTime.normalize(false);
        long l1 = localTime.toMillis(false);
        ArrayList localArrayList;
        label185: String str3;
        Object localObject2;
        Method localMethod4;
        label325: long l2;
        if (ACRA.getConfig().includeDropBoxSystemTags())
        {
          List localList2 = Arrays.asList(SYSTEM_TAGS);
          localArrayList = new ArrayList(localList2);
          if ((paramArrayOfString != null) && (paramArrayOfString.length > 0))
          {
            List localList1 = Arrays.asList(paramArrayOfString);
            localArrayList.addAll(localList1);
          }
          if (localArrayList.size() <= 0)
            break label547;
          Iterator localIterator = localArrayList.iterator();
          if (!localIterator.hasNext())
            break label555;
          str3 = (String)localIterator.next();
          localStringBuilder.append("Tag: ").append(str3).append('\n');
          Object[] arrayOfObject1 = new Object[2];
          arrayOfObject1[0] = str3;
          arrayOfObject1[1] = Long.valueOf(l1);
          localObject2 = localMethod1.invoke(localObject1, arrayOfObject1);
          if (localObject2 == null)
            break label518;
          Class localClass2 = localObject2.getClass();
          Class[] arrayOfClass2 = new Class[1];
          arrayOfClass2[0] = Integer.TYPE;
          Method localMethod2 = localClass2.getMethod("getText", arrayOfClass2);
          Method localMethod3 = localObject2.getClass().getMethod("getTimeMillis", (Class[])null);
          localMethod4 = localObject2.getClass().getMethod("close", (Class[])null);
          if (localObject2 != null)
          {
            l2 = ((Long)localMethod3.invoke(localObject2, (Object[])null)).longValue();
            localTime.set(l2);
            localStringBuilder.append("@").append(localTime.format2445()).append('\n');
            Object[] arrayOfObject2 = new Object[1];
            arrayOfObject2[0] = Integer.valueOf(500);
            String str4 = (String)localMethod2.invoke(localObject2, arrayOfObject2);
            if (str4 == null)
              break label489;
            localStringBuilder.append("Text: ").append(str4).append('\n');
          }
        }
        while (true)
        {
          localMethod4.invoke(localObject2, (Object[])null);
          Object[] arrayOfObject3 = new Object[2];
          arrayOfObject3[0] = str3;
          arrayOfObject3[1] = Long.valueOf(l2);
          localObject2 = localMethod1.invoke(localObject1, arrayOfObject3);
          break label325;
          break label185;
          localArrayList = new ArrayList();
          break;
          label489: localStringBuilder.append("Not Text!").append('\n');
        }
      }
    }
    catch (SecurityException localSecurityException)
    {
      while (true)
      {
        Log.i("CrashReporting", "DropBoxManager not available.");
        return "N/A";
        localStringBuilder.append("Nothing.").append('\n');
      }
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      StringBuilder localStringBuilder;
      while (true)
        Log.i("CrashReporting", "DropBoxManager not available.");
      localStringBuilder.append("No tag configured for collection.");
      String str2 = localStringBuilder.toString();
      return str2;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      while (true)
        Log.i("CrashReporting", "DropBoxManager not available.");
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      while (true)
        Log.i("CrashReporting", "DropBoxManager not available.");
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      while (true)
        Log.i("CrashReporting", "DropBoxManager not available.");
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      while (true)
        label518: label547: label555: Log.i("CrashReporting", "DropBoxManager not available.");
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.DropBoxCollector
 * JD-Core Version:    0.6.0
 */