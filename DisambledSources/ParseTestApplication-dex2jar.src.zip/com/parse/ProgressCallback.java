package com.parse;

public abstract interface ProgressCallback
{
  public abstract void done(Integer paramInteger);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ProgressCallback
 * JD-Core Version:    0.6.0
 */