package com.parse;

import android.content.Context;
import android.content.Intent;
import bolts.Continuation;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.json.JSONObject;

class ParsePinningEventuallyQueue extends ParseEventuallyQueue
{
  private static final String TAG = "ParsePinningEventuallyQueue";
  private final Object connectionLock = new Object();
  private Task<Void>.TaskCompletionSource connectionTaskCompletionSource = Task.create();
  private ArrayList<String> eventuallyPinUUIDQueue = new ArrayList();
  private ConnectivityNotifier.ConnectivityListener listener = new ConnectivityNotifier.ConnectivityListener()
  {
    public void networkConnectivityStatusChanged(Context paramContext, Intent paramIntent)
    {
      if (paramIntent.getBooleanExtra("noConnectivity", false))
      {
        ParsePinningEventuallyQueue.this.setConnected(false);
        return;
      }
      ParsePinningEventuallyQueue.this.setConnected(ConnectivityNotifier.isConnected(paramContext));
    }
  };
  private ConnectivityNotifier notifier;
  private TaskQueue operationSetTaskQueue = new TaskQueue();
  private HashMap<String, Task<Object>.TaskCompletionSource> pendingEventuallyTasks = new HashMap();
  private HashMap<String, Task<Object>.TaskCompletionSource> pendingOperationSetUUIDTasks = new HashMap();
  private TaskQueue taskQueue = new TaskQueue();
  private final Object taskQueueSyncLock = new Object();
  private HashMap<String, EventuallyPin> uuidToEventuallyPin = new HashMap();
  private HashMap<String, ParseOperationSet> uuidToOperationSet = new HashMap();

  public ParsePinningEventuallyQueue(Context paramContext)
  {
    setConnected(ConnectivityNotifier.isConnected(paramContext));
    this.notifier = ConnectivityNotifier.getNotifier(paramContext);
    this.notifier.addListener(this.listener);
    resume();
  }

  private Task<Void> enqueueEventuallyAsync(ParseNetworkCommand paramParseNetworkCommand, ParseObject paramParseObject, Task<Void> paramTask, Task<Object>.TaskCompletionSource paramTask1)
  {
    return paramTask.continueWithTask(new Continuation(paramParseObject, paramParseNetworkCommand, paramTask1)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return EventuallyPin.pinEventuallyCommand(this.val$object, this.val$command).continueWithTask(new Continuation()
        {
          public Task<Void> then(Task<EventuallyPin> paramTask)
            throws Exception
          {
            EventuallyPin localEventuallyPin = (EventuallyPin)paramTask.getResult();
            Exception localException = paramTask.getError();
            if (localException != null)
            {
              if (5 >= Parse.getLogLevel())
                Parse.logW("ParsePinningEventuallyQueue", "Unable to save command for later.", localException);
              ParsePinningEventuallyQueue.this.notifyTestHelper(4);
              return Task.forResult(null);
            }
            ParsePinningEventuallyQueue.this.pendingOperationSetUUIDTasks.put(localEventuallyPin.getUUID(), ParsePinningEventuallyQueue.5.this.val$tcs);
            ParsePinningEventuallyQueue.this.populateQueueAsync().continueWithTask(new Continuation()
            {
              public Task<Void> then(Task<Void> paramTask)
                throws Exception
              {
                ParsePinningEventuallyQueue.this.notifyTestHelper(3);
                return paramTask;
              }
            });
            return paramTask.makeVoid();
          }
        });
      }
    });
  }

  private Task<Void> populateQueueAsync()
  {
    return this.taskQueue.enqueue(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParsePinningEventuallyQueue.this.populateQueueAsync(paramTask);
      }
    });
  }

  private Task<Void> populateQueueAsync(Task<Void> paramTask)
  {
    return paramTask.continueWithTask(new Continuation()
    {
      public Task<List<EventuallyPin>> then(Task<Void> paramTask)
        throws Exception
      {
        return EventuallyPin.findAllPinned(ParsePinningEventuallyQueue.this.eventuallyPinUUIDQueue);
      }
    }).onSuccessTask(new Continuation()
    {
      public Task<Void> then(Task<List<EventuallyPin>> paramTask)
        throws Exception
      {
        Iterator localIterator = ((List)paramTask.getResult()).iterator();
        while (localIterator.hasNext())
        {
          EventuallyPin localEventuallyPin = (EventuallyPin)localIterator.next();
          ParsePinningEventuallyQueue.this.runEventuallyAsync(localEventuallyPin);
        }
        return paramTask.makeVoid();
      }
    });
  }

  private Task<Object> process(EventuallyPin paramEventuallyPin, ParseOperationSet paramParseOperationSet)
  {
    return waitForConnectionAsync().onSuccessTask(new Continuation(paramEventuallyPin, paramParseOperationSet)
    {
      public Task<Object> then(Task<Void> paramTask)
        throws Exception
      {
        int i = this.val$eventuallyPin.getType();
        ParseObject localParseObject = this.val$eventuallyPin.getObject();
        String str = this.val$eventuallyPin.getSessionToken();
        Task localTask;
        if (i == 1)
          localTask = localParseObject.saveAsync(this.val$operationSet, str);
        while (true)
        {
          return localTask.continueWithTask(new Continuation(i, localParseObject)
          {
            public Task<Object> then(Task<Object> paramTask)
              throws Exception
            {
              Exception localException = paramTask.getError();
              if ((localException != null) && ((localException instanceof ParseException)) && (((ParseException)localException).getCode() == 100))
              {
                ParsePinningEventuallyQueue.this.setConnected(false);
                ParsePinningEventuallyQueue.this.notifyTestHelper(7);
                return ParsePinningEventuallyQueue.this.process(ParsePinningEventuallyQueue.13.this.val$eventuallyPin, ParsePinningEventuallyQueue.13.this.val$operationSet);
              }
              return ParsePinningEventuallyQueue.13.this.val$eventuallyPin.unpinInBackground("_eventuallyPin").continueWithTask(new Continuation(paramTask)
              {
                public Task<Void> then(Task<Void> paramTask)
                  throws Exception
                {
                  Object localObject = this.val$saveTask.getResult();
                  if (ParsePinningEventuallyQueue.13.1.this.val$type == 1)
                    paramTask = ParsePinningEventuallyQueue.13.1.this.val$object.handleSaveEventuallyResultAsync((JSONObject)localObject, ParsePinningEventuallyQueue.13.this.val$operationSet);
                  do
                    return paramTask;
                  while (ParsePinningEventuallyQueue.13.1.this.val$type != 2);
                  return ParsePinningEventuallyQueue.13.1.this.val$object.handleDeleteEventuallyResultAsync(localObject);
                }
              }).continueWithTask(new Continuation(paramTask)
              {
                public Task<Object> then(Task<Void> paramTask)
                  throws Exception
                {
                  return this.val$saveTask;
                }
              });
            }
          });
          if (i == 2)
          {
            localTask = localParseObject.deleteAsync(str);
            continue;
          }
          localTask = this.val$eventuallyPin.getCommand().executeAsync();
        }
      }
    });
  }

  private Task<Void> runEventuallyAsync(EventuallyPin paramEventuallyPin)
  {
    String str = paramEventuallyPin.getUUID();
    if (this.eventuallyPinUUIDQueue.contains(str))
      return Task.forResult(null);
    this.eventuallyPinUUIDQueue.add(str);
    this.operationSetTaskQueue.enqueue(new Continuation(paramEventuallyPin, str)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParsePinningEventuallyQueue.this.runEventuallyAsync(this.val$eventuallyPin, paramTask).continueWithTask(new Continuation()
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            ParsePinningEventuallyQueue.this.eventuallyPinUUIDQueue.remove(ParsePinningEventuallyQueue.9.this.val$uuid);
            return paramTask;
          }
        });
      }
    });
    return Task.forResult(null);
  }

  private Task<Void> runEventuallyAsync(EventuallyPin paramEventuallyPin, Task<Void> paramTask)
  {
    return paramTask.continueWithTask(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParsePinningEventuallyQueue.this.waitForConnectionAsync();
      }
    }).onSuccessTask(new Continuation(paramEventuallyPin)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParsePinningEventuallyQueue.this.waitForOperationSetAndEventuallyPin(null, this.val$eventuallyPin).continueWithTask(new Continuation()
        {
          public Task<Void> then(Task<Object> paramTask)
            throws Exception
          {
            Exception localException = paramTask.getError();
            Task.TaskCompletionSource localTaskCompletionSource;
            if (localException != null)
            {
              if ((localException instanceof ParsePinningEventuallyQueue.PauseException))
                return paramTask.makeVoid();
              if (6 >= Parse.getLogLevel())
                Parse.logE("ParsePinningEventuallyQueue", "Failed to run command.", localException);
              ParsePinningEventuallyQueue.this.notifyTestHelper(2, localException);
              localTaskCompletionSource = (Task.TaskCompletionSource)ParsePinningEventuallyQueue.this.pendingOperationSetUUIDTasks.remove(ParsePinningEventuallyQueue.10.this.val$eventuallyPin.getUUID());
              if (localTaskCompletionSource != null)
              {
                if (localException == null)
                  break label108;
                localTaskCompletionSource.setError(localException);
              }
            }
            while (true)
            {
              return paramTask.makeVoid();
              ParsePinningEventuallyQueue.this.notifyTestHelper(1);
              break;
              label108: localTaskCompletionSource.setResult(paramTask.getResult());
            }
          }
        });
      }
    });
  }

  private Task<Void> waitForConnectionAsync()
  {
    synchronized (this.connectionLock)
    {
      Task localTask = this.connectionTaskCompletionSource.getTask();
      return localTask;
    }
  }

  private Task<Void> whenAll(Collection<TaskQueue> paramCollection)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      localArrayList.add(((TaskQueue)localIterator.next()).enqueue(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }));
    return Task.whenAll(localArrayList);
  }

  public void clear()
  {
    pause();
    Task localTask = this.taskQueue.enqueue(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return paramTask.continueWithTask(new Continuation()
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return EventuallyPin.findAllPinned().onSuccessTask(new Continuation()
            {
              public Task<Void> then(Task<List<EventuallyPin>> paramTask)
                throws Exception
              {
                List localList = (List)paramTask.getResult();
                ArrayList localArrayList = new ArrayList();
                Iterator localIterator = localList.iterator();
                while (localIterator.hasNext())
                  localArrayList.add(((EventuallyPin)localIterator.next()).unpinInBackground("_eventuallyPin"));
                return Task.whenAll(localArrayList);
              }
            });
          }
        });
      }
    });
    try
    {
      Parse.waitForTask(localTask);
      simulateReboot();
      resume();
      return;
    }
    catch (ParseException localParseException)
    {
    }
    throw new IllegalStateException(localParseException);
  }

  public Task<Object> enqueueEventuallyAsync(ParseNetworkCommand paramParseNetworkCommand, ParseObject paramParseObject)
  {
    Parse.requirePermission("android.permission.ACCESS_NETWORK_STATE");
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    this.taskQueue.enqueue(new Continuation(paramParseNetworkCommand, paramParseObject, localTaskCompletionSource)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParsePinningEventuallyQueue.this.enqueueEventuallyAsync(this.val$command, this.val$object, paramTask, this.val$tcs);
      }
    });
    return localTaskCompletionSource.getTask();
  }

  public void onDestroy()
  {
    this.notifier.removeListener(this.listener);
  }

  public void pause()
  {
    synchronized (this.connectionLock)
    {
      this.connectionTaskCompletionSource.trySetError(new PauseException(null));
      this.connectionTaskCompletionSource = Task.create();
      this.connectionTaskCompletionSource.trySetError(new PauseException(null));
      synchronized (this.taskQueueSyncLock)
      {
        Iterator localIterator = this.pendingEventuallyTasks.keySet().iterator();
        if (localIterator.hasNext())
        {
          String str = (String)localIterator.next();
          ((Task.TaskCompletionSource)this.pendingEventuallyTasks.get(str)).trySetError(new PauseException(null));
        }
      }
    }
    this.pendingEventuallyTasks.clear();
    this.uuidToOperationSet.clear();
    this.uuidToEventuallyPin.clear();
    monitorexit;
    try
    {
      TaskQueue[] arrayOfTaskQueue = new TaskQueue[2];
      arrayOfTaskQueue[0] = this.taskQueue;
      arrayOfTaskQueue[1] = this.operationSetTaskQueue;
      Parse.waitForTask(whenAll(Arrays.asList(arrayOfTaskQueue)));
      return;
    }
    catch (ParseException localParseException)
    {
    }
    throw new IllegalStateException(localParseException);
  }

  public int pendingCount()
  {
    try
    {
      int i = ((Integer)Parse.waitForTask(pendingCountAsync())).intValue();
      return i;
    }
    catch (ParseException localParseException)
    {
    }
    throw new IllegalStateException(localParseException);
  }

  public Task<Integer> pendingCountAsync()
  {
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    this.taskQueue.enqueue(new Continuation(localTaskCompletionSource)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParsePinningEventuallyQueue.this.pendingCountAsync(paramTask).continueWithTask(new Continuation()
        {
          public Task<Void> then(Task<Integer> paramTask)
            throws Exception
          {
            int i = ((Integer)paramTask.getResult()).intValue();
            ParsePinningEventuallyQueue.2.this.val$tcs.setResult(Integer.valueOf(i));
            return Task.forResult(null);
          }
        });
      }
    });
    return localTaskCompletionSource.getTask();
  }

  public Task<Integer> pendingCountAsync(Task<Void> paramTask)
  {
    return paramTask.continueWithTask(new Continuation()
    {
      public Task<Integer> then(Task<Void> paramTask)
        throws Exception
      {
        return EventuallyPin.findAllPinned().continueWithTask(new Continuation()
        {
          public Task<Integer> then(Task<List<EventuallyPin>> paramTask)
            throws Exception
          {
            return Task.forResult(Integer.valueOf(((List)paramTask.getResult()).size()));
          }
        });
      }
    });
  }

  public void resume()
  {
    if (isConnected())
    {
      this.connectionTaskCompletionSource.trySetResult(null);
      this.connectionTaskCompletionSource = Task.create();
      this.connectionTaskCompletionSource.trySetResult(null);
    }
    while (true)
    {
      populateQueueAsync();
      return;
      this.connectionTaskCompletionSource = Task.create();
    }
  }

  public void setConnected(boolean paramBoolean)
  {
    synchronized (this.connectionLock)
    {
      if (isConnected() != paramBoolean)
      {
        super.setConnected(paramBoolean);
        if (paramBoolean)
        {
          this.connectionTaskCompletionSource.trySetResult(null);
          this.connectionTaskCompletionSource = Task.create();
          this.connectionTaskCompletionSource.trySetResult(null);
        }
      }
      else
      {
        return;
      }
      this.connectionTaskCompletionSource = Task.create();
    }
  }

  void simulateReboot()
  {
    pause();
    this.pendingOperationSetUUIDTasks.clear();
    this.pendingEventuallyTasks.clear();
    this.uuidToOperationSet.clear();
    this.uuidToEventuallyPin.clear();
    resume();
  }

  Task<Object> waitForOperationSetAndEventuallyPin(ParseOperationSet paramParseOperationSet, EventuallyPin paramEventuallyPin)
  {
    if ((paramEventuallyPin != null) && (paramEventuallyPin.getType() != 1))
      return process(paramEventuallyPin, null);
    Object localObject1 = this.taskQueueSyncLock;
    monitorenter;
    if ((paramParseOperationSet != null) && (paramEventuallyPin == null));
    String str;
    EventuallyPin localEventuallyPin;
    ParseOperationSet localParseOperationSet;
    while (true)
    {
      try
      {
        str = paramParseOperationSet.getUUID();
        this.uuidToOperationSet.put(str, paramParseOperationSet);
        localEventuallyPin = (EventuallyPin)this.uuidToEventuallyPin.get(str);
        localParseOperationSet = (ParseOperationSet)this.uuidToOperationSet.get(str);
        if ((localEventuallyPin != null) && (localParseOperationSet != null))
          break;
        if (!this.pendingEventuallyTasks.containsKey(str))
          break label173;
        localTaskCompletionSource1 = (Task.TaskCompletionSource)this.pendingEventuallyTasks.get(str);
        Task localTask = localTaskCompletionSource1.getTask();
        return localTask;
      }
      finally
      {
        monitorexit;
      }
      if ((paramParseOperationSet == null) && (paramEventuallyPin != null))
      {
        str = paramEventuallyPin.getOperationSetUUID();
        this.uuidToEventuallyPin.put(str, paramEventuallyPin);
        continue;
      }
      throw new IllegalStateException("Either operationSet or eventuallyPin must be set.");
      label173: Task.TaskCompletionSource localTaskCompletionSource1 = Task.create();
      this.pendingEventuallyTasks.put(str, localTaskCompletionSource1);
    }
    Task.TaskCompletionSource localTaskCompletionSource2 = (Task.TaskCompletionSource)this.pendingEventuallyTasks.get(str);
    monitorexit;
    return process(localEventuallyPin, localParseOperationSet).continueWithTask(new Continuation(str, localTaskCompletionSource2)
    {
      public Task<Object> then(Task<Object> paramTask)
        throws Exception
      {
        while (true)
        {
          synchronized (ParsePinningEventuallyQueue.this.taskQueueSyncLock)
          {
            ParsePinningEventuallyQueue.this.pendingEventuallyTasks.remove(this.val$uuid);
            ParsePinningEventuallyQueue.this.uuidToOperationSet.remove(this.val$uuid);
            ParsePinningEventuallyQueue.this.uuidToEventuallyPin.remove(this.val$uuid);
            Exception localException = paramTask.getError();
            if (localException != null)
            {
              this.val$tcs.trySetError(localException);
              return this.val$tcs.getTask();
            }
          }
          if (paramTask.isCancelled())
          {
            this.val$tcs.trySetCancelled();
            continue;
          }
          this.val$tcs.trySetResult(paramTask.getResult());
        }
      }
    });
  }

  private static class PauseException extends Exception
  {
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParsePinningEventuallyQueue
 * JD-Core Version:    0.6.0
 */