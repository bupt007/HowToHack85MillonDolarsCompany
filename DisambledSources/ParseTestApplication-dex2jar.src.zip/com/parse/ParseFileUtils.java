package com.parse;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

class ParseFileUtils
{
  private static final long FILE_COPY_BUFFER_SIZE = 31457280L;
  public static final long ONE_KB = 1024L;
  public static final long ONE_MB = 1048576L;

  public static void cleanDirectory(File paramFile)
    throws IOException
  {
    if (!paramFile.exists())
      throw new IllegalArgumentException(paramFile + " does not exist");
    if (!paramFile.isDirectory())
      throw new IllegalArgumentException(paramFile + " is not a directory");
    File[] arrayOfFile = paramFile.listFiles();
    if (arrayOfFile == null)
      throw new IOException("Failed to list contents of " + paramFile);
    Object localObject = null;
    int i = arrayOfFile.length;
    int j = 0;
    while (true)
      if (j < i)
      {
        File localFile = arrayOfFile[j];
        try
        {
          forceDelete(localFile);
          j++;
        }
        catch (IOException localIOException)
        {
          while (true)
            localObject = localIOException;
        }
      }
    if (localObject != null)
      throw localObject;
  }

  public static void copyFile(File paramFile1, File paramFile2)
    throws IOException
  {
    copyFile(paramFile1, paramFile2, true);
  }

  public static void copyFile(File paramFile1, File paramFile2, boolean paramBoolean)
    throws IOException
  {
    if (paramFile1 == null)
      throw new NullPointerException("Source must not be null");
    if (paramFile2 == null)
      throw new NullPointerException("Destination must not be null");
    if (!paramFile1.exists())
      throw new FileNotFoundException("Source '" + paramFile1 + "' does not exist");
    if (paramFile1.isDirectory())
      throw new IOException("Source '" + paramFile1 + "' exists but is a directory");
    if (paramFile1.getCanonicalPath().equals(paramFile2.getCanonicalPath()))
      throw new IOException("Source '" + paramFile1 + "' and destination '" + paramFile2 + "' are the same");
    File localFile = paramFile2.getParentFile();
    if ((localFile != null) && (!localFile.mkdirs()) && (!localFile.isDirectory()))
      throw new IOException("Destination '" + localFile + "' directory cannot be created");
    if ((paramFile2.exists()) && (!paramFile2.canWrite()))
      throw new IOException("Destination '" + paramFile2 + "' exists but is read-only");
    doCopyFile(paramFile1, paramFile2, paramBoolean);
  }

  public static void deleteDirectory(File paramFile)
    throws IOException
  {
    if (!paramFile.exists());
    do
    {
      return;
      if (isSymlink(paramFile))
        continue;
      cleanDirectory(paramFile);
    }
    while (paramFile.delete());
    throw new IOException("Unable to delete directory " + paramFile + ".");
  }

  public static boolean deleteQuietly(File paramFile)
  {
    if (paramFile == null)
      return false;
    try
    {
      if (paramFile.isDirectory())
        cleanDirectory(paramFile);
      try
      {
        label17: boolean bool = paramFile.delete();
        return bool;
      }
      catch (Exception localException2)
      {
        return false;
      }
    }
    catch (Exception localException1)
    {
      break label17;
    }
  }

  // ERROR //
  private static void doCopyFile(File paramFile1, File paramFile2, boolean paramBoolean)
    throws IOException
  {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual 28	java/io/File:exists	()Z
    //   4: ifeq +42 -> 46
    //   7: aload_1
    //   8: invokevirtual 52	java/io/File:isDirectory	()Z
    //   11: ifeq +35 -> 46
    //   14: new 22	java/io/IOException
    //   17: dup
    //   18: new 32	java/lang/StringBuilder
    //   21: dup
    //   22: invokespecial 33	java/lang/StringBuilder:<init>	()V
    //   25: ldc 107
    //   27: invokevirtual 42	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   30: aload_1
    //   31: invokevirtual 37	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   34: ldc 85
    //   36: invokevirtual 42	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   42: invokespecial 61	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   45: athrow
    //   46: aconst_null
    //   47: astore_3
    //   48: aconst_null
    //   49: astore 4
    //   51: aconst_null
    //   52: astore 5
    //   54: aconst_null
    //   55: astore 6
    //   57: new 136	java/io/FileInputStream
    //   60: dup
    //   61: aload_0
    //   62: invokespecial 138	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   65: astore 7
    //   67: new 140	java/io/FileOutputStream
    //   70: dup
    //   71: aload_1
    //   72: invokespecial 141	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   75: astore 8
    //   77: aload 7
    //   79: invokevirtual 145	java/io/FileInputStream:getChannel	()Ljava/nio/channels/FileChannel;
    //   82: astore 5
    //   84: aload 8
    //   86: invokevirtual 146	java/io/FileOutputStream:getChannel	()Ljava/nio/channels/FileChannel;
    //   89: astore 6
    //   91: aload 5
    //   93: invokevirtual 152	java/nio/channels/FileChannel:size	()J
    //   96: lstore 10
    //   98: lconst_0
    //   99: lstore 12
    //   101: goto +203 -> 304
    //   104: aload 6
    //   106: aload 5
    //   108: lload 12
    //   110: lload 21
    //   112: invokevirtual 156	java/nio/channels/FileChannel:transferFrom	(Ljava/nio/channels/ReadableByteChannel;JJ)J
    //   115: lstore 23
    //   117: lload 23
    //   119: lconst_0
    //   120: lcmp
    //   121: ifne +106 -> 227
    //   124: aload 6
    //   126: invokestatic 162	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/Closeable;)V
    //   129: aload 8
    //   131: invokestatic 165	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/OutputStream;)V
    //   134: aload 5
    //   136: invokestatic 162	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/Closeable;)V
    //   139: aload 7
    //   141: invokestatic 168	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/InputStream;)V
    //   144: aload_0
    //   145: invokevirtual 171	java/io/File:length	()J
    //   148: lstore 14
    //   150: aload_1
    //   151: invokevirtual 171	java/io/File:length	()J
    //   154: lstore 16
    //   156: lload 14
    //   158: lload 16
    //   160: lcmp
    //   161: ifeq +100 -> 261
    //   164: new 22	java/io/IOException
    //   167: dup
    //   168: new 32	java/lang/StringBuilder
    //   171: dup
    //   172: invokespecial 33	java/lang/StringBuilder:<init>	()V
    //   175: ldc 173
    //   177: invokevirtual 42	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   180: aload_0
    //   181: invokevirtual 37	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   184: ldc 175
    //   186: invokevirtual 42	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   189: aload_1
    //   190: invokevirtual 37	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   193: ldc 177
    //   195: invokevirtual 42	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: lload 14
    //   200: invokevirtual 180	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   203: ldc 182
    //   205: invokevirtual 42	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: lload 16
    //   210: invokevirtual 180	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   213: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   216: invokespecial 61	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   219: athrow
    //   220: lload 19
    //   222: lstore 21
    //   224: goto -120 -> 104
    //   227: lload 12
    //   229: lload 23
    //   231: ladd
    //   232: lstore 12
    //   234: goto +70 -> 304
    //   237: astore 9
    //   239: aload 6
    //   241: invokestatic 162	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/Closeable;)V
    //   244: aload 4
    //   246: invokestatic 165	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/OutputStream;)V
    //   249: aload 5
    //   251: invokestatic 162	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/Closeable;)V
    //   254: aload_3
    //   255: invokestatic 168	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/InputStream;)V
    //   258: aload 9
    //   260: athrow
    //   261: iload_2
    //   262: ifeq +12 -> 274
    //   265: aload_1
    //   266: aload_0
    //   267: invokevirtual 185	java/io/File:lastModified	()J
    //   270: invokevirtual 189	java/io/File:setLastModified	(J)Z
    //   273: pop
    //   274: return
    //   275: astore 9
    //   277: aload 7
    //   279: astore_3
    //   280: aconst_null
    //   281: astore 6
    //   283: aconst_null
    //   284: astore 5
    //   286: aconst_null
    //   287: astore 4
    //   289: goto -50 -> 239
    //   292: astore 9
    //   294: aload 8
    //   296: astore 4
    //   298: aload 7
    //   300: astore_3
    //   301: goto -62 -> 239
    //   304: lload 12
    //   306: lload 10
    //   308: lcmp
    //   309: ifge -185 -> 124
    //   312: lload 10
    //   314: lload 12
    //   316: lsub
    //   317: lstore 19
    //   319: lload 19
    //   321: ldc2_w 7
    //   324: lcmp
    //   325: ifle -105 -> 220
    //   328: ldc2_w 7
    //   331: lstore 21
    //   333: goto -229 -> 104
    //
    // Exception table:
    //   from	to	target	type
    //   57	67	237	finally
    //   67	77	275	finally
    //   77	98	292	finally
    //   104	117	292	finally
  }

  public static void forceDelete(File paramFile)
    throws IOException
  {
    if (paramFile.isDirectory())
      deleteDirectory(paramFile);
    boolean bool;
    do
    {
      return;
      bool = paramFile.exists();
    }
    while (paramFile.delete());
    if (!bool)
      throw new FileNotFoundException("File does not exist: " + paramFile);
    throw new IOException("Unable to delete file: " + paramFile);
  }

  public static boolean isSymlink(File paramFile)
    throws IOException
  {
    if (paramFile == null)
      throw new NullPointerException("File must not be null");
    if (paramFile.getParent() == null);
    for (File localFile = paramFile; localFile.getCanonicalFile().equals(localFile.getAbsoluteFile()); localFile = new File(paramFile.getParentFile().getCanonicalFile(), paramFile.getName()))
      return false;
    return true;
  }

  public static void moveFile(File paramFile1, File paramFile2)
    throws IOException
  {
    if (paramFile1 == null)
      throw new NullPointerException("Source must not be null");
    if (paramFile2 == null)
      throw new NullPointerException("Destination must not be null");
    if (!paramFile1.exists())
      throw new FileNotFoundException("Source '" + paramFile1 + "' does not exist");
    if (paramFile1.isDirectory())
      throw new IOException("Source '" + paramFile1 + "' is a directory");
    if (paramFile2.exists())
      throw new IOException("Destination '" + paramFile2 + "' already exists");
    if (paramFile2.isDirectory())
      throw new IOException("Destination '" + paramFile2 + "' is a directory");
    if (!paramFile1.renameTo(paramFile2))
    {
      copyFile(paramFile1, paramFile2);
      if (!paramFile1.delete())
      {
        deleteQuietly(paramFile2);
        throw new IOException("Failed to delete original file '" + paramFile1 + "' after copy to '" + paramFile2 + "'");
      }
    }
  }

  public static FileInputStream openInputStream(File paramFile)
    throws IOException
  {
    if (paramFile.exists())
    {
      if (paramFile.isDirectory())
        throw new IOException("File '" + paramFile + "' exists but is a directory");
      if (!paramFile.canRead())
        throw new IOException("File '" + paramFile + "' cannot be read");
    }
    else
    {
      throw new FileNotFoundException("File '" + paramFile + "' does not exist");
    }
    return new FileInputStream(paramFile);
  }

  public static FileOutputStream openOutputStream(File paramFile)
    throws IOException
  {
    if (paramFile.exists())
    {
      if (paramFile.isDirectory())
        throw new IOException("File '" + paramFile + "' exists but is a directory");
      if (!paramFile.canWrite())
        throw new IOException("File '" + paramFile + "' cannot be written to");
    }
    else
    {
      File localFile = paramFile.getParentFile();
      if ((localFile != null) && (!localFile.exists()) && (!localFile.mkdirs()))
        throw new IOException("File '" + paramFile + "' could not be created");
    }
    return new FileOutputStream(paramFile);
  }

  public static byte[] readFileToByteArray(File paramFile)
    throws IOException
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = openInputStream(paramFile);
      byte[] arrayOfByte = ParseIOUtils.toByteArray(localFileInputStream);
      return arrayOfByte;
    }
    finally
    {
      ParseIOUtils.closeQuietly(localFileInputStream);
    }
    throw localObject;
  }

  public static void writeByteArrayToFile(File paramFile, byte[] paramArrayOfByte)
    throws IOException
  {
    FileOutputStream localFileOutputStream = null;
    try
    {
      localFileOutputStream = openOutputStream(paramFile);
      localFileOutputStream.write(paramArrayOfByte);
      return;
    }
    finally
    {
      ParseIOUtils.closeQuietly(localFileOutputStream);
    }
    throw localObject;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseFileUtils
 * JD-Core Version:    0.6.0
 */