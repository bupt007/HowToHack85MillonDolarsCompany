package com.parse;

import android.content.Context;

class BaseCrashReporter
  implements ReportsCrashes
{
  protected Context mApplicationContext;

  public BaseCrashReporter(Context paramContext)
  {
    if (paramContext == null)
      throw new IllegalArgumentException("Application context cannot be null");
    this.mApplicationContext = paramContext;
  }

  public String[] additionalDropBoxTags()
  {
    return new String[0];
  }

  public boolean checkSSLCertsOnCrashReport()
  {
    return true;
  }

  public int dropboxCollectionMinutes()
  {
    return 5;
  }

  public String formPostFormat()
  {
    return "application/x-www-form-urlencoded";
  }

  public Context getApplicationContext()
  {
    return this.mApplicationContext;
  }

  public boolean includeDropBoxSystemTags()
  {
    return false;
  }

  public String[] logcatArguments()
  {
    return new String[] { "-t", "200", "-v", "time" };
  }

  public int socketTimeout()
  {
    return 3000;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.BaseCrashReporter
 * JD-Core Version:    0.6.0
 */