package com.parse;

abstract interface NonCrashException
{
  public abstract String getExceptionFriendlyName();
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.NonCrashException
 * JD-Core Version:    0.6.0
 */