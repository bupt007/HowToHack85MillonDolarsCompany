package com.parse;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.charset.IllegalCharsetNameException;
import java.nio.charset.UnsupportedCharsetException;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

class CrashReportData extends EnumMap<ReportField, String>
{
  private static final int CONTINUE = 3;
  private static final int IGNORE = 5;
  private static final int KEY_DONE = 4;
  private static final int NONE = 0;
  private static final String PROP_DTD_NAME = "http://java.sun.com/dtd/properties.dtd";
  private static final int SLASH = 1;
  private static final int UNICODE = 2;
  private static String lineSeparator = "\n";
  private static final long serialVersionUID = 4112578634029874840L;
  protected CrashReportData defaults;

  public CrashReportData()
  {
    super(ReportField.class);
  }

  public CrashReportData(CrashReportData paramCrashReportData)
  {
    super(ReportField.class);
    this.defaults = paramCrashReportData;
  }

  private void dumpString(Appendable paramAppendable, String paramString, boolean paramBoolean)
    throws IOException
  {
    int i = paramString.length();
    int j = 0;
    if (!paramBoolean)
    {
      j = 0;
      if (i < 0)
      {
        int m = paramString.charAt(0);
        j = 0;
        if (m == 32)
        {
          paramAppendable.append("\\ ");
          j = 0 + 1;
        }
      }
    }
    if (j < i)
    {
      char c = paramString.charAt(j);
      switch (c)
      {
      case '\013':
      default:
        if (((paramBoolean) && (c == ' ')) || (c == '\\') || (c == '#') || (c == '!') || (c == ':'))
          paramAppendable.append('\\');
        if ((c < ' ') || (c > '~'))
          break;
        paramAppendable.append(c);
      case '\t':
      case '\n':
      case '\f':
      case '\r':
      }
      while (true)
      {
        j++;
        break;
        paramAppendable.append("\\t");
        continue;
        paramAppendable.append("\\n");
        continue;
        paramAppendable.append("\\f");
        continue;
        paramAppendable.append("\\r");
        continue;
        String str = Integer.toHexString(c);
        paramAppendable.append("\\u");
        for (int k = 0; k < 4 - str.length(); k++)
          paramAppendable.append('0');
        paramAppendable.append(str);
      }
    }
  }

  public static Writer getWriter(OutputStream paramOutputStream)
  {
    try
    {
      OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(paramOutputStream, "ISO8859_1");
      return localOutputStreamWriter;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
    }
    return null;
  }

  private boolean isEbcdic(BufferedInputStream paramBufferedInputStream)
    throws IOException
  {
    int i;
    do
    {
      i = (byte)paramBufferedInputStream.read();
      if ((i == -1) || (i == 35) || (i == 10) || (i == 61))
        return false;
    }
    while (i != 21);
    return true;
  }

  private Enumeration<ReportField> keys()
  {
    return Collections.enumeration(keySet());
  }

  private String substitutePredefinedEntries(String paramString)
  {
    return paramString.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("'", "&apos;").replaceAll("\"", "&quot;");
  }

  public String getProperty(ReportField paramReportField)
  {
    String str = (String)super.get(paramReportField);
    if ((str == null) && (this.defaults != null))
      str = this.defaults.getProperty(paramReportField);
    return str;
  }

  public String getProperty(ReportField paramReportField, String paramString)
  {
    String str = (String)super.get(paramReportField);
    if ((str == null) && (this.defaults != null))
      str = this.defaults.getProperty(paramReportField);
    if (str == null)
      return paramString;
    return str;
  }

  public void list(PrintStream paramPrintStream)
  {
    if (paramPrintStream == null)
      throw new NullPointerException();
    StringBuilder localStringBuilder = new StringBuilder(80);
    Enumeration localEnumeration = keys();
    if (localEnumeration.hasMoreElements())
    {
      ReportField localReportField = (ReportField)localEnumeration.nextElement();
      localStringBuilder.append(localReportField);
      localStringBuilder.append('=');
      String str = (String)super.get(localReportField);
      for (CrashReportData localCrashReportData = this.defaults; str == null; localCrashReportData = localCrashReportData.defaults)
        str = (String)localCrashReportData.get(localReportField);
      if (str.length() > 40)
      {
        localStringBuilder.append(str.substring(0, 37));
        localStringBuilder.append("...");
      }
      while (true)
      {
        paramPrintStream.println(localStringBuilder.toString());
        localStringBuilder.setLength(0);
        break;
        localStringBuilder.append(str);
      }
    }
  }

  public void list(PrintWriter paramPrintWriter)
  {
    if (paramPrintWriter == null)
      throw new NullPointerException();
    StringBuilder localStringBuilder = new StringBuilder(80);
    Enumeration localEnumeration = keys();
    if (localEnumeration.hasMoreElements())
    {
      ReportField localReportField = (ReportField)localEnumeration.nextElement();
      localStringBuilder.append(localReportField);
      localStringBuilder.append('=');
      String str = (String)super.get(localReportField);
      for (CrashReportData localCrashReportData = this.defaults; str == null; localCrashReportData = localCrashReportData.defaults)
        str = (String)localCrashReportData.get(localReportField);
      if (str.length() > 40)
      {
        localStringBuilder.append(str.substring(0, 37));
        localStringBuilder.append("...");
      }
      while (true)
      {
        paramPrintWriter.println(localStringBuilder.toString());
        localStringBuilder.setLength(0);
        break;
        localStringBuilder.append(str);
      }
    }
  }

  public void load(InputStream paramInputStream)
    throws IOException
  {
    monitorenter;
    if (paramInputStream == null)
      try
      {
        throw new NullPointerException();
      }
      finally
      {
        monitorexit;
      }
    BufferedInputStream localBufferedInputStream = new BufferedInputStream(paramInputStream);
    localBufferedInputStream.mark(2147483647);
    boolean bool = isEbcdic(localBufferedInputStream);
    localBufferedInputStream.reset();
    if (!bool)
      load(new InputStreamReader(localBufferedInputStream, "ISO8859-1"));
    while (true)
    {
      monitorexit;
      return;
      load(new InputStreamReader(localBufferedInputStream));
    }
  }

  public void load(Reader paramReader)
    throws IOException
  {
    monitorenter;
    int i = 0;
    int j = 0;
    int k = 0;
    Object localObject2;
    int m;
    int n;
    int i1;
    char c;
    int i4;
    while (true)
    {
      BufferedReader localBufferedReader;
      int i2;
      try
      {
        localObject2 = new char[40];
        m = -1;
        n = 1;
        localBufferedReader = new BufferedReader(paramReader);
        i1 = 0;
        i2 = localBufferedReader.read();
        if ((i2 == -1) || (i2 == 0))
        {
          if ((i != 2) || (k > 4))
            break label804;
          throw new IllegalArgumentException("luni.08");
        }
      }
      finally
      {
        monitorexit;
      }
      c = (char)i2;
      if (i1 == localObject2.length)
      {
        char[] arrayOfChar = new char[2 * localObject2.length];
        System.arraycopy(localObject2, 0, arrayOfChar, 0, i1);
        localObject2 = arrayOfChar;
      }
      if (i != 2)
        break label423;
      int i3 = Character.digit(c, 16);
      if (i3 >= 0)
      {
        j = i3 + (j << 4);
        k++;
        if (k < 4)
          continue;
      }
      do
      {
        i = 0;
        i4 = i1 + 1;
        localObject2[i1] = (char)j;
        if ((c == '\n') || (c == ''))
          break label419;
        i1 = i4;
        i = 0;
        break;
      }
      while (k > 4);
      throw new IllegalArgumentException("luni.09");
      label207: int i5 = i1 + 1;
      localObject2[i1] = c;
      i1 = i5;
      n = 0;
      continue;
      label230: if (!Character.isWhitespace(c))
        break label789;
      if (i != 3)
        break label672;
      i = 5;
      break label672;
      int i7;
      do
      {
        int i6 = localBufferedReader.read();
        if (i6 == -1)
          break;
        i7 = (char)i6;
        if ((i7 == 13) || (i7 == 10))
          break;
      }
      while (i7 != 133);
      continue;
      label291: String str3 = new String(localObject2, 0, i1);
      put(Enum.valueOf(ReportField.class, str3.substring(0, m)), str3.substring(m));
      break label749;
    }
    while (true)
    {
      if (m >= 0)
      {
        String str1 = new String(localObject2, 0, i1);
        ReportField localReportField = (ReportField)Enum.valueOf(ReportField.class, str1.substring(0, m));
        String str2 = str1.substring(m);
        if (i == 1)
          str2 = str2 + "";
        put(localReportField, str2);
      }
      monitorexit;
      return;
      label419: i1 = i4;
      label423: if (i == 1)
      {
        i = 0;
        switch (c)
        {
        default:
        case '\r':
        case '\n':
        case '':
        case 'b':
        case 'f':
        case 'n':
        case 'r':
        case 't':
        case 'u':
        }
      }
      while (true)
      {
        if (i != 4)
          break label802;
        m = i1;
        i = 0;
        break label207;
        i = 3;
        break;
        i = 5;
        break;
        c = '\b';
        i = 0;
        continue;
        c = '\f';
        i = 0;
        continue;
        c = '\n';
        i = 0;
        continue;
        c = '\r';
        i = 0;
        continue;
        c = '\t';
        i = 0;
        continue;
        i = 2;
        k = 0;
        j = 0;
        break;
        switch (c)
        {
        default:
          if ((i1 == 0) || (i1 == m) || (i == 5))
            break;
          if (m == -1)
            i = 4;
          break;
        case '!':
        case '#':
          if (n == 0)
            break label230;
          break;
        case '\n':
          if (i == 3)
            i = 5;
          break;
        case '\r':
        case '':
          n = 1;
          if ((i1 > 0) || ((i1 == 0) && (m == 0)))
          {
            if (m != -1)
              break label291;
            m = i1;
            break label291;
          }
          m = -1;
          i = 0;
          i1 = 0;
          break;
        case '\\':
          if (i == 4)
            m = i1;
          i = 1;
          break;
        case ':':
        case '=':
          label672: label749: if (m != -1)
            break label230;
          m = i1;
          i = 0;
          break;
          label789: if ((i != 5) && (i != 3))
            continue;
          i = 0;
        }
      }
      label802: break label207;
      label804: if ((m != -1) || (i1 <= 0))
        continue;
      m = i1;
    }
  }

  public String put(ReportField paramReportField, String paramString, Writer paramWriter)
    throws IOException
  {
    String str = (String)put(paramReportField, paramString);
    if (paramWriter != null)
      storeKeyValuePair(paramWriter, paramReportField, paramString);
    return str;
  }

  @Deprecated
  public void save(OutputStream paramOutputStream, String paramString)
  {
    try
    {
      store(paramOutputStream, paramString);
      return;
    }
    catch (IOException localIOException)
    {
    }
  }

  public Object setProperty(ReportField paramReportField, String paramString)
  {
    return put(paramReportField, paramString);
  }

  public void store(OutputStream paramOutputStream, String paramString)
    throws IOException
  {
    monitorenter;
    try
    {
      store(getWriter(paramOutputStream), paramString);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void store(Writer paramWriter, String paramString)
    throws IOException
  {
    monitorenter;
    if (paramString != null);
    try
    {
      storeComment(paramWriter, paramString);
      Iterator localIterator = entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        storeKeyValuePair(paramWriter, (ReportField)localEntry.getKey(), (String)localEntry.getValue());
      }
    }
    finally
    {
      monitorexit;
    }
    paramWriter.flush();
    monitorexit;
  }

  public void storeComment(Writer paramWriter, String paramString)
    throws IOException
  {
    monitorenter;
    try
    {
      paramWriter.write("#");
      paramWriter.write(paramString);
      paramWriter.write(lineSeparator);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void storeKeyValuePair(Writer paramWriter, ReportField paramReportField, String paramString)
    throws IOException
  {
    monitorenter;
    try
    {
      String str1 = paramReportField.toString();
      if (paramString == null);
      for (String str2 = ""; ; str2 = paramString)
      {
        int i = 1 + (str1.length() + str2.length());
        StringBuilder localStringBuilder = new StringBuilder(i + i / 5);
        dumpString(localStringBuilder, str1, true);
        localStringBuilder.append('=');
        dumpString(localStringBuilder, str2, false);
        localStringBuilder.append(lineSeparator);
        paramWriter.write(localStringBuilder.toString());
        paramWriter.flush();
        return;
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void storeToXML(OutputStream paramOutputStream, String paramString)
    throws IOException
  {
    storeToXML(paramOutputStream, paramString, "UTF-8");
  }

  public void storeToXML(OutputStream paramOutputStream, String paramString1, String paramString2)
    throws IOException
  {
    monitorenter;
    if ((paramOutputStream == null) || (paramString2 == null))
      try
      {
        throw new NullPointerException();
      }
      finally
      {
        monitorexit;
      }
    try
    {
      String str4 = Charset.forName(paramString2).name();
      str1 = str4;
      localPrintStream = new PrintStream(paramOutputStream, false, str1);
      localPrintStream.print("<?xml version=\"1.0\" encoding=\"");
      localPrintStream.print(str1);
      localPrintStream.println("\"?>");
      localPrintStream.print("<!DOCTYPE properties SYSTEM \"");
      localPrintStream.print("http://java.sun.com/dtd/properties.dtd");
      localPrintStream.println("\">");
      localPrintStream.println("<properties>");
      if (paramString1 != null)
      {
        localPrintStream.print("<comment>");
        localPrintStream.print(substitutePredefinedEntries(paramString1));
        localPrintStream.println("</comment>");
      }
      Iterator localIterator = entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        String str2 = ((ReportField)localEntry.getKey()).toString();
        String str3 = (String)localEntry.getValue();
        localPrintStream.print("<entry key=\"");
        localPrintStream.print(substitutePredefinedEntries(str2));
        localPrintStream.print("\">");
        localPrintStream.print(substitutePredefinedEntries(str3));
        localPrintStream.println("</entry>");
      }
    }
    catch (IllegalCharsetNameException localIllegalCharsetNameException)
    {
      while (true)
      {
        System.out.println("Warning: encoding name " + paramString2 + " is illegal, using UTF-8 as default encoding");
        str1 = "UTF-8";
      }
    }
    catch (UnsupportedCharsetException localUnsupportedCharsetException)
    {
      PrintStream localPrintStream;
      while (true)
      {
        System.out.println("Warning: encoding " + paramString2 + " is not supported, using UTF-8 as default encoding");
        String str1 = "UTF-8";
      }
      localPrintStream.println("</properties>");
      localPrintStream.flush();
      monitorexit;
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.CrashReportData
 * JD-Core Version:    0.6.0
 */