package com.parse;

public abstract interface GetCallback<T extends ParseObject> extends ParseCallback2<T, ParseException>
{
  public abstract void done(T paramT, ParseException paramParseException);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.GetCallback
 * JD-Core Version:    0.6.0
 */