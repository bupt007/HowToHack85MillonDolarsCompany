package com.parse;

import org.json.JSONObject;

abstract interface ParseObjectEncodingStrategy
{
  public abstract JSONObject encodeRelatedObject(ParseObject paramParseObject);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseObjectEncodingStrategy
 * JD-Core Version:    0.6.0
 */