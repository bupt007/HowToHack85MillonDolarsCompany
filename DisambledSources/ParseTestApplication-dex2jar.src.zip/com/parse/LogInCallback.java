package com.parse;

public abstract interface LogInCallback extends ParseCallback2<ParseUser, ParseException>
{
  public abstract void done(ParseUser paramParseUser, ParseException paramParseException);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.LogInCallback
 * JD-Core Version:    0.6.0
 */