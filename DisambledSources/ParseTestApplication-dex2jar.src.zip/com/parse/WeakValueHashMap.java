package com.parse;

import java.lang.ref.WeakReference;
import java.util.HashMap;

class WeakValueHashMap<K, V>
{
  private HashMap<K, WeakReference<V>> map = new HashMap();

  public void clear()
  {
    this.map.clear();
  }

  public V get(K paramK)
  {
    WeakReference localWeakReference = (WeakReference)this.map.get(paramK);
    Object localObject;
    if (localWeakReference == null)
      localObject = null;
    do
    {
      return localObject;
      localObject = localWeakReference.get();
    }
    while (localObject != null);
    this.map.remove(paramK);
    return localObject;
  }

  public void put(K paramK, V paramV)
  {
    this.map.put(paramK, new WeakReference(paramV));
  }

  public void remove(K paramK)
  {
    this.map.remove(paramK);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.WeakValueHashMap
 * JD-Core Version:    0.6.0
 */