package com.parse;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import bolts.Continuation;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class ParseSQLiteDatabase
{
  private static final ExecutorService dbExecutor = Executors.newSingleThreadExecutor();
  private static final TaskQueue taskQueue = new TaskQueue();
  private Task<Void> current = null;
  private final Object currentLock = new Object();
  private SQLiteDatabase db;
  private int openFlags;
  private final Task<Void>.TaskCompletionSource tcs = Task.create();

  private ParseSQLiteDatabase(int paramInt)
  {
    this.openFlags = paramInt;
    taskQueue.enqueue(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        synchronized (ParseSQLiteDatabase.this.currentLock)
        {
          ParseSQLiteDatabase.access$102(ParseSQLiteDatabase.this, paramTask);
          return ParseSQLiteDatabase.this.tcs.getTask();
        }
      }
    });
  }

  static Task<ParseSQLiteDatabase> openDatabaseAsync(SQLiteOpenHelper paramSQLiteOpenHelper, int paramInt)
  {
    ParseSQLiteDatabase localParseSQLiteDatabase = new ParseSQLiteDatabase(paramInt);
    return localParseSQLiteDatabase.open(paramSQLiteOpenHelper).continueWithTask(new Continuation(localParseSQLiteDatabase)
    {
      public Task<ParseSQLiteDatabase> then(Task<Void> paramTask)
        throws Exception
      {
        return Task.forResult(this.val$db);
      }
    });
  }

  public Task<Void> beginTransactionAsync()
  {
    synchronized (this.currentLock)
    {
      this.current = this.current.continueWithTask(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          ParseSQLiteDatabase.this.db.beginTransaction();
          return paramTask;
        }
      }
      , dbExecutor);
      Task localTask = this.current.continueWithTask(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR);
      return localTask;
    }
  }

  public Task<Void> closeAsync()
  {
    synchronized (this.currentLock)
    {
      this.current = this.current.continueWithTask(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          try
          {
            ParseSQLiteDatabase.this.db.close();
            return ParseSQLiteDatabase.this.tcs.getTask();
          }
          finally
          {
            ParseSQLiteDatabase.this.tcs.setResult(null);
          }
          throw localObject;
        }
      }
      , dbExecutor);
      Task localTask = this.current.continueWithTask(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR);
      return localTask;
    }
  }

  public Task<Void> deleteAsync(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    synchronized (this.currentLock)
    {
      Task localTask1 = this.current.onSuccess(new Continuation(paramString1, paramString2, paramArrayOfString)
      {
        public Integer then(Task<Void> paramTask)
          throws Exception
        {
          return Integer.valueOf(ParseSQLiteDatabase.this.db.delete(this.val$table, this.val$where, this.val$args));
        }
      }
      , dbExecutor);
      this.current = localTask1.makeVoid();
      Task localTask2 = localTask1.continueWithTask(new Continuation()
      {
        public Task<Integer> then(Task<Integer> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR).makeVoid();
      return localTask2;
    }
  }

  public Task<Void> endTransactionAsync()
  {
    synchronized (this.currentLock)
    {
      this.current = this.current.continueWith(new Continuation()
      {
        public Void then(Task<Void> paramTask)
          throws Exception
        {
          ParseSQLiteDatabase.this.db.endTransaction();
          return null;
        }
      }
      , dbExecutor);
      Task localTask = this.current.continueWithTask(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR);
      return localTask;
    }
  }

  public boolean inTransaction()
  {
    return this.db.inTransaction();
  }

  public Task<Void> insertOrThrowAsync(String paramString, ContentValues paramContentValues)
  {
    synchronized (this.currentLock)
    {
      Task localTask1 = this.current.onSuccess(new Continuation(paramString, paramContentValues)
      {
        public Long then(Task<Void> paramTask)
          throws Exception
        {
          return Long.valueOf(ParseSQLiteDatabase.this.db.insertOrThrow(this.val$table, null, this.val$values));
        }
      }
      , dbExecutor);
      this.current = localTask1.makeVoid();
      Task localTask2 = localTask1.continueWithTask(new Continuation()
      {
        public Task<Long> then(Task<Long> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR).makeVoid();
      return localTask2;
    }
  }

  public Task<Void> insertWithOnConflict(String paramString, ContentValues paramContentValues, int paramInt)
  {
    synchronized (this.currentLock)
    {
      Task localTask1 = this.current.onSuccess(new Continuation(paramString, paramContentValues, paramInt)
      {
        public Long then(Task<Void> paramTask)
          throws Exception
        {
          return Long.valueOf(ParseSQLiteDatabase.this.db.insertWithOnConflict(this.val$table, null, this.val$values, this.val$conflictAlgorithm));
        }
      }
      , dbExecutor);
      this.current = localTask1.makeVoid();
      Task localTask2 = localTask1.continueWithTask(new Continuation()
      {
        public Task<Long> then(Task<Long> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR).makeVoid();
      return localTask2;
    }
  }

  public Task<Boolean> isOpenAsync()
  {
    synchronized (this.currentLock)
    {
      Task localTask = this.current.continueWith(new Continuation()
      {
        public Boolean then(Task<Void> paramTask)
          throws Exception
        {
          return Boolean.valueOf(ParseSQLiteDatabase.this.db.isOpen());
        }
      });
      this.current = localTask.makeVoid();
      return localTask;
    }
  }

  public Task<Boolean> isReadOnlyAsync()
  {
    synchronized (this.currentLock)
    {
      Task localTask = this.current.continueWith(new Continuation()
      {
        public Boolean then(Task<Void> paramTask)
          throws Exception
        {
          return Boolean.valueOf(ParseSQLiteDatabase.this.db.isReadOnly());
        }
      });
      this.current = localTask.makeVoid();
      return localTask;
    }
  }

  Task<Void> open(SQLiteOpenHelper paramSQLiteOpenHelper)
  {
    synchronized (this.currentLock)
    {
      this.current = this.current.continueWith(new Continuation(paramSQLiteOpenHelper)
      {
        public SQLiteDatabase then(Task<Void> paramTask)
          throws Exception
        {
          if ((0x1 & ParseSQLiteDatabase.this.openFlags) == 1)
            return this.val$helper.getReadableDatabase();
          return this.val$helper.getWritableDatabase();
        }
      }
      , dbExecutor).continueWithTask(new Continuation()
      {
        public Task<Void> then(Task<SQLiteDatabase> paramTask)
          throws Exception
        {
          ParseSQLiteDatabase.access$302(ParseSQLiteDatabase.this, (SQLiteDatabase)paramTask.getResult());
          return paramTask.makeVoid();
        }
      }
      , Task.BACKGROUND_EXECUTOR);
      Task localTask = this.current;
      return localTask;
    }
  }

  public Task<Cursor> queryAsync(String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2)
  {
    synchronized (this.currentLock)
    {
      Task localTask1 = this.current.onSuccess(new Continuation(paramString1, paramArrayOfString1, paramString2, paramArrayOfString2)
      {
        public Cursor then(Task<Void> paramTask)
          throws Exception
        {
          return ParseSQLiteDatabase.this.db.query(this.val$table, this.val$select, this.val$where, this.val$args, null, null, null);
        }
      }
      , dbExecutor).onSuccess(new Continuation()
      {
        public Cursor then(Task<Cursor> paramTask)
          throws Exception
        {
          Cursor localCursor = ParseSQLiteCursor.create((Cursor)paramTask.getResult(), ParseSQLiteDatabase.dbExecutor);
          localCursor.getCount();
          return localCursor;
        }
      }
      , dbExecutor);
      this.current = localTask1.makeVoid();
      Task localTask2 = localTask1.continueWithTask(new Continuation()
      {
        public Task<Cursor> then(Task<Cursor> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR);
      return localTask2;
    }
  }

  public Task<Cursor> rawQueryAsync(String paramString, String[] paramArrayOfString)
  {
    synchronized (this.currentLock)
    {
      Task localTask1 = this.current.onSuccess(new Continuation(paramString, paramArrayOfString)
      {
        public Cursor then(Task<Void> paramTask)
          throws Exception
        {
          return ParseSQLiteDatabase.this.db.rawQuery(this.val$sql, this.val$args);
        }
      }
      , dbExecutor).onSuccess(new Continuation()
      {
        public Cursor then(Task<Cursor> paramTask)
          throws Exception
        {
          Cursor localCursor = ParseSQLiteCursor.create((Cursor)paramTask.getResult(), ParseSQLiteDatabase.dbExecutor);
          localCursor.getCount();
          return localCursor;
        }
      }
      , dbExecutor);
      this.current = localTask1.makeVoid();
      Task localTask2 = localTask1.continueWithTask(new Continuation()
      {
        public Task<Cursor> then(Task<Cursor> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR);
      return localTask2;
    }
  }

  public Task<Void> setTransactionSuccessfulAsync()
  {
    synchronized (this.currentLock)
    {
      this.current = this.current.onSuccessTask(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          ParseSQLiteDatabase.this.db.setTransactionSuccessful();
          return paramTask;
        }
      }
      , dbExecutor);
      Task localTask = this.current.continueWithTask(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR);
      return localTask;
    }
  }

  public Task<Integer> updateAsync(String paramString1, ContentValues paramContentValues, String paramString2, String[] paramArrayOfString)
  {
    synchronized (this.currentLock)
    {
      Task localTask1 = this.current.onSuccess(new Continuation(paramString1, paramContentValues, paramString2, paramArrayOfString)
      {
        public Integer then(Task<Void> paramTask)
          throws Exception
        {
          return Integer.valueOf(ParseSQLiteDatabase.this.db.update(this.val$table, this.val$values, this.val$where, this.val$args));
        }
      }
      , dbExecutor);
      this.current = localTask1.makeVoid();
      Task localTask2 = localTask1.continueWithTask(new Continuation()
      {
        public Task<Integer> then(Task<Integer> paramTask)
          throws Exception
        {
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR);
      return localTask2;
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseSQLiteDatabase
 * JD-Core Version:    0.6.0
 */