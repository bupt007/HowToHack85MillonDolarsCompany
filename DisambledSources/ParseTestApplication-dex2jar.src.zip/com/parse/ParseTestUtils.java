package com.parse;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy.Builder;
import bolts.Task;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.URL;
import java.util.Set;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

class ParseTestUtils
{
  private static final String TAG = "com.parse.ParseTestUtils";
  private static final Object TEST_SERVER_LOCK = new Object();
  private static final AtomicBoolean strictModeEnabled = new AtomicBoolean(false);
  private static String testServer;

  public static void clearApp()
  {
    ParseCommand localParseCommand = new ParseCommand("clear_app", null);
    try
    {
      Parse.waitForTask(localParseCommand.executeAsync());
      return;
    }
    catch (ParseException localParseException)
    {
    }
    throw new RuntimeException(localParseException.getMessage());
  }

  public static void clearCurrentInstallationFromMemory()
  {
    ParseInstallation.currentInstallation = null;
  }

  public static int commandCacheUnexpectedEvents()
  {
    return Parse.eventuallyQueue.getTestHelper().unexpectedEvents();
  }

  public static void disconnectCommandCache()
  {
    Parse.eventuallyQueue.setConnected(false);
  }

  public static String getInstallationId(Context paramContext)
  {
    return ParseInstallation.getCurrentInstallation().getInstallationId();
  }

  public static ParseObject getObjectFromDisk(Context paramContext, String paramString)
  {
    return ParseObject.getFromDisk(paramContext, paramString);
  }

  private static File getParseDir(Context paramContext)
  {
    return paramContext.getDir("Parse", 0);
  }

  public static JSONObject getSerializedPushStateJSON()
  {
    return Parse.getDiskObject(Parse.applicationContext, "pushState");
  }

  private static String getTestServer(Context paramContext)
  {
    if (testServer == null);
    while (true)
    {
      synchronized (TEST_SERVER_LOCK)
      {
        String str = testServer;
        if (str != null)
          continue;
        try
        {
          testServer = new BufferedReader(new InputStreamReader(paramContext.getAssets().open("server.config"))).readLine();
          return testServer;
        }
        catch (Exception localException)
        {
          if (!Build.PRODUCT.contains("vbox"))
            break label81;
        }
        testServer = "http://192.168.56.1:3000";
      }
      label81: if ((Build.PRODUCT.contains("sdk")) || (Build.PRODUCT.contains("full_x86")))
      {
        testServer = "http://10.0.2.2:3000";
        continue;
      }
      testServer = "http://localhost:3000";
    }
  }

  public static ParseUser getUserObjectFromDisk(Context paramContext, String paramString)
  {
    return (ParseUser)ParseObject.getFromDisk(paramContext, paramString);
  }

  public static Set<String> keySet(ParseObject paramParseObject)
  {
    return paramParseObject.keySet();
  }

  public static ServerSocket mockPushServer()
  {
    try
    {
      ServerSocket localServerSocket = new ServerSocket(0);
      InetSocketAddress localInetSocketAddress = (InetSocketAddress)localServerSocket.getLocalSocketAddress();
      PushService.useServer(localInetSocketAddress.getHostName(), localInetSocketAddress.getPort());
      Parse.logI("com.parse.ParseTestUtils", "running mockPushServer on " + localInetSocketAddress);
      return localServerSocket;
    }
    catch (IOException localIOException)
    {
    }
    throw new RuntimeException(localIOException.getMessage());
  }

  public static void mockV8Client()
  {
    ParseCommand localParseCommand = new ParseCommand("mock_v8_client", null);
    try
    {
      Parse.waitForTask(localParseCommand.executeAsync());
      return;
    }
    catch (ParseException localParseException)
    {
    }
    throw new RuntimeException(localParseException);
  }

  public static Set<String> pushRoutes(Context paramContext)
  {
    Task localTask = PushRouter.getSubscriptionsAsync(false);
    try
    {
      localTask.waitForCompletion();
      label9: return (Set)localTask.getResult();
    }
    catch (InterruptedException localInterruptedException)
    {
      break label9;
    }
  }

  public static void reconnectCommandCache()
  {
    Parse.eventuallyQueue.setConnected(true);
  }

  public static void resetCommandCache()
  {
    ParseEventuallyQueue localParseEventuallyQueue = Parse.getEventuallyQueue();
    ParseEventuallyQueue.TestHelper localTestHelper = localParseEventuallyQueue.getTestHelper();
    localParseEventuallyQueue.clear();
    localTestHelper.clear();
  }

  public static void saveObjectToDisk(ParseObject paramParseObject, Context paramContext, String paramString)
  {
    paramParseObject.saveToDisk(paramContext, paramString);
  }

  public static void saveStringToDisk(String paramString1, Context paramContext, String paramString2)
  {
    File localFile = new File(getParseDir(paramContext), paramString2);
    try
    {
      FileOutputStream localFileOutputStream = new FileOutputStream(localFile);
      localFileOutputStream.write(paramString1.getBytes("UTF-8"));
      localFileOutputStream.close();
      return;
    }
    catch (IOException localIOException)
    {
      return;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
    }
  }

  public static void setCommandInitialDelay(long paramLong)
  {
    ParseCommand.setDefaultInitialRetryDelay(paramLong);
  }

  public static int setPushHistoryLength(int paramInt)
  {
    int i = PushRouter.MAX_HISTORY_LENGTH;
    PushRouter.MAX_HISTORY_LENGTH = paramInt;
    return i;
  }

  public static void setRetryDelayEnabled(boolean paramBoolean)
  {
    PushConnection.ENABLE_RETRY_DELAY = paramBoolean;
  }

  public static void setStrictModeEnabledForMainThread(boolean paramBoolean)
  {
    AtomicBoolean localAtomicBoolean = strictModeEnabled;
    if (!paramBoolean);
    for (boolean bool = true; ; bool = false)
    {
      if (localAtomicBoolean.compareAndSet(bool, paramBoolean))
      {
        Semaphore localSemaphore = new Semaphore(0);
        new Handler(Looper.getMainLooper()).post(new Runnable(paramBoolean, localSemaphore)
        {
          public void run()
          {
            ParseTestUtils.setStrictModeEnabledForThisThread(this.val$enabled);
            this.val$done.release();
          }
        });
        localSemaphore.acquireUninterruptibly();
      }
      return;
    }
  }

  public static void setStrictModeEnabledForThisThread(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().penaltyDeath().build());
      return;
    }
    StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build());
  }

  public static void setTestServer(String paramString)
  {
    synchronized (TEST_SERVER_LOCK)
    {
      testServer = paramString;
      return;
    }
  }

  public static void startServiceIfRequired(Context paramContext)
  {
    PushService.startServiceIfRequired(paramContext);
  }

  public static void unmockV8Client()
  {
    ParseCommand localParseCommand = new ParseCommand("unmock_v8_client", null);
    try
    {
      Parse.waitForTask(localParseCommand.executeAsync());
      return;
    }
    catch (ParseException localParseException)
    {
    }
    throw new RuntimeException(localParseException);
  }

  public static String useBadServerPort()
  {
    return useBadServerPort(ParseObject.server);
  }

  public static String useBadServerPort(String paramString)
  {
    Object localObject = "http://10.0.2.2:6000";
    try
    {
      URL localURL = new URL(paramString);
      String str = localURL.getProtocol() + "://" + localURL.getHost() + ":" + (999 + localURL.getPort());
      localObject = str;
      label65: return useServer((String)localObject);
    }
    catch (MalformedURLException localMalformedURLException)
    {
      break label65;
    }
  }

  public static String useInvalidServer()
  {
    return useServer("http://invalid.server:3000");
  }

  public static String useServer(String paramString)
  {
    String str = ParseObject.server;
    ParseObject.server = paramString;
    return str;
  }

  public static String useTestServer(Context paramContext)
  {
    return useServer(getTestServer(paramContext));
  }

  public static boolean waitForCommandCacheEnqueue()
  {
    return Parse.eventuallyQueue.getTestHelper().waitFor(3);
  }

  public static boolean waitForCommandCacheFailure()
  {
    return Parse.eventuallyQueue.getTestHelper().waitFor(2);
  }

  public static boolean waitForCommandCacheSuccess()
  {
    return (Parse.eventuallyQueue.getTestHelper().waitFor(1)) && (Parse.eventuallyQueue.getTestHelper().waitFor(5));
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseTestUtils
 * JD-Core Version:    0.6.0
 */