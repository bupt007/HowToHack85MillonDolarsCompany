package com.parse.codec;

public class EncoderException extends Exception
{
  private static final long serialVersionUID = 1L;

  public EncoderException()
  {
  }

  public EncoderException(String paramString)
  {
    super(paramString);
  }

  public EncoderException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }

  public EncoderException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.codec.EncoderException
 * JD-Core Version:    0.6.0
 */