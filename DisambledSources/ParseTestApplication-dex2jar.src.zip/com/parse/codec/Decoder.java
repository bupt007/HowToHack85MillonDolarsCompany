package com.parse.codec;

public abstract interface Decoder
{
  public abstract Object decode(Object paramObject)
    throws DecoderException;
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.codec.Decoder
 * JD-Core Version:    0.6.0
 */