package com.parse;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;
import java.util.WeakHashMap;
import java.util.concurrent.locks.Lock;

class LockSet
{
  private static long nextStableId;
  private static WeakHashMap<Lock, Long> stableIds = new WeakHashMap();
  private final Set<Lock> locks = new TreeSet(new Comparator()
  {
    public int compare(Lock paramLock1, Lock paramLock2)
    {
      return LockSet.access$000(paramLock1).compareTo(LockSet.access$000(paramLock2));
    }
  });

  static
  {
    nextStableId = 0L;
  }

  public LockSet(Collection<Lock> paramCollection)
  {
    this.locks.addAll(paramCollection);
  }

  private static Long getStableId(Lock paramLock)
  {
    synchronized (stableIds)
    {
      if (stableIds.containsKey(paramLock))
      {
        Long localLong2 = (Long)stableIds.get(paramLock);
        return localLong2;
      }
      long l = nextStableId;
      nextStableId = 1L + l;
      stableIds.put(paramLock, Long.valueOf(l));
      Long localLong1 = Long.valueOf(l);
      return localLong1;
    }
  }

  public void lock()
  {
    Iterator localIterator = this.locks.iterator();
    while (localIterator.hasNext())
      ((Lock)localIterator.next()).lock();
  }

  public void unlock()
  {
    Iterator localIterator = this.locks.iterator();
    while (localIterator.hasNext())
      ((Lock)localIterator.next()).unlock();
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.LockSet
 * JD-Core Version:    0.6.0
 */