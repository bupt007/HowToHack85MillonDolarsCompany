package com.parse;

import bolts.Task;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.json.JSONObject;

class ParseAWSRequest extends ParseRequest<byte[], byte[]>
{
  private byte[] data;
  private String mimeType;
  private JSONObject postParams;

  public ParseAWSRequest(ParseRequest.Method paramMethod, String paramString)
  {
    super(paramMethod, paramString);
  }

  public ParseAWSRequest(String paramString)
  {
    super(paramString);
  }

  // ERROR //
  protected org.apache.http.HttpEntity newEntity(ProgressCallback paramProgressCallback)
  {
    // Byte code:
    //   0: new 26	com/parse/CountingMultipartEntity
    //   3: dup
    //   4: getstatic 32	com/parse/entity/mime/HttpMultipartMode:BROWSER_COMPATIBLE	Lcom/parse/entity/mime/HttpMultipartMode;
    //   7: aload_1
    //   8: invokespecial 35	com/parse/CountingMultipartEntity:<init>	(Lcom/parse/entity/mime/HttpMultipartMode;Lcom/parse/ProgressCallback;)V
    //   11: astore_2
    //   12: aload_2
    //   13: ldc 37
    //   15: new 39	com/parse/entity/mime/content/StringBody
    //   18: dup
    //   19: aload_0
    //   20: getfield 41	com/parse/ParseAWSRequest:mimeType	Ljava/lang/String;
    //   23: invokespecial 42	com/parse/entity/mime/content/StringBody:<init>	(Ljava/lang/String;)V
    //   26: invokevirtual 46	com/parse/CountingMultipartEntity:addPart	(Ljava/lang/String;Lcom/parse/entity/mime/content/ContentBody;)V
    //   29: aload_0
    //   30: getfield 48	com/parse/ParseAWSRequest:postParams	Lorg/json/JSONObject;
    //   33: invokevirtual 54	org/json/JSONObject:keys	()Ljava/util/Iterator;
    //   36: astore 4
    //   38: aload 4
    //   40: invokeinterface 60 1 0
    //   45: ifeq +83 -> 128
    //   48: aload 4
    //   50: invokeinterface 64 1 0
    //   55: checkcast 66	java/lang/String
    //   58: astore 5
    //   60: aload_2
    //   61: aload 5
    //   63: new 39	com/parse/entity/mime/content/StringBody
    //   66: dup
    //   67: aload_0
    //   68: getfield 48	com/parse/ParseAWSRequest:postParams	Lorg/json/JSONObject;
    //   71: aload 5
    //   73: invokevirtual 70	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   76: invokespecial 42	com/parse/entity/mime/content/StringBody:<init>	(Ljava/lang/String;)V
    //   79: invokevirtual 46	com/parse/CountingMultipartEntity:addPart	(Ljava/lang/String;Lcom/parse/entity/mime/content/ContentBody;)V
    //   82: goto -44 -> 38
    //   85: astore 7
    //   87: new 72	java/lang/RuntimeException
    //   90: dup
    //   91: aload 7
    //   93: invokevirtual 76	java/io/UnsupportedEncodingException:getMessage	()Ljava/lang/String;
    //   96: invokespecial 77	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   99: athrow
    //   100: astore_3
    //   101: new 72	java/lang/RuntimeException
    //   104: dup
    //   105: aload_3
    //   106: invokevirtual 76	java/io/UnsupportedEncodingException:getMessage	()Ljava/lang/String;
    //   109: invokespecial 77	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   112: athrow
    //   113: astore 6
    //   115: new 72	java/lang/RuntimeException
    //   118: dup
    //   119: aload 6
    //   121: invokevirtual 78	org/json/JSONException:getMessage	()Ljava/lang/String;
    //   124: invokespecial 77	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   127: athrow
    //   128: aload_2
    //   129: ldc 80
    //   131: new 82	com/parse/entity/mime/content/ByteArrayBody
    //   134: dup
    //   135: aload_0
    //   136: getfield 84	com/parse/ParseAWSRequest:data	[B
    //   139: aload_0
    //   140: getfield 41	com/parse/ParseAWSRequest:mimeType	Ljava/lang/String;
    //   143: ldc 80
    //   145: invokespecial 87	com/parse/entity/mime/content/ByteArrayBody:<init>	([BLjava/lang/String;Ljava/lang/String;)V
    //   148: invokevirtual 46	com/parse/CountingMultipartEntity:addPart	(Ljava/lang/String;Lcom/parse/entity/mime/content/ContentBody;)V
    //   151: aload_2
    //   152: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   60	82	85	java/io/UnsupportedEncodingException
    //   12	29	100	java/io/UnsupportedEncodingException
    //   60	82	113	org/json/JSONException
  }

  protected Task<byte[]> onResponse(ParseHttpResponse paramParseHttpResponse, ProgressCallback paramProgressCallback)
  {
    int i = paramParseHttpResponse.getStatusCode();
    if (((i >= 200) && (i < 300)) || (i == 304))
    {
      if (this.method != ParseRequest.Method.GET)
        return null;
    }
    else
    {
      if (this.method == ParseRequest.Method.GET);
      for (String str = "Download from"; ; str = "Upload to")
      {
        Object[] arrayOfObject = new Object[2];
        arrayOfObject[0] = str;
        arrayOfObject[1] = Integer.valueOf(i);
        return Task.forError(new ParseException(100, String.format("%s S3 failed. %s", arrayOfObject)));
      }
    }
    int j = paramParseHttpResponse.getTotalSize();
    InputStream localInputStream = null;
    try
    {
      localInputStream = paramParseHttpResponse.getContent();
      localByteArrayOutputStream = new ByteArrayOutputStream();
      byte[] arrayOfByte = new byte[32768];
      1 local1 = null;
      int k = 0;
      if (paramProgressCallback != null)
        local1 = new ParseCallback2(paramProgressCallback)
        {
          Integer maxProgressSoFar = Integer.valueOf(0);

          public void done(Integer paramInteger, ParseException paramParseException)
          {
            if (paramInteger.intValue() > this.maxProgressSoFar.intValue())
            {
              this.maxProgressSoFar = paramInteger;
              this.val$downloadProgressCallback.done(paramInteger);
            }
          }
        };
      while (true)
      {
        int m = localInputStream.read(arrayOfByte, 0, arrayOfByte.length);
        if (m == -1)
          break;
        localByteArrayOutputStream.write(arrayOfByte, 0, m);
        k += m;
        if ((local1 == null) || (j == -1))
          continue;
        Parse.callbackOnMainThreadAsync(Task.forResult(Integer.valueOf(Math.round(100.0F * (k / j)))), local1);
      }
    }
    catch (IOException localIOException)
    {
      ByteArrayOutputStream localByteArrayOutputStream;
      Task localTask1 = Task.forError(localIOException);
      return localTask1;
      Task localTask2 = Task.forResult(localByteArrayOutputStream.toByteArray());
      return localTask2;
    }
    finally
    {
      ParseIOUtils.closeQuietly(localInputStream);
    }
    throw localObject;
  }

  public void setData(byte[] paramArrayOfByte)
  {
    this.data = paramArrayOfByte;
  }

  public void setMimeType(String paramString)
  {
    this.mimeType = paramString;
  }

  public void setPostParams(JSONObject paramJSONObject)
  {
    this.postParams = paramJSONObject;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseAWSRequest
 * JD-Core Version:    0.6.0
 */