package com.parse;

import android.content.Context;
import bolts.Continuation;
import bolts.Task;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ParseConfig
{
  static final String CURRENT_CONFIG_FILENAME = "currentConfig";
  private static ParseConfig currentConfig;
  private static final Object currentConfigMutex;
  private static final TaskQueue taskQueue = new TaskQueue();
  private final Map<String, Object> params;

  static
  {
    currentConfigMutex = new Object();
  }

  ParseConfig()
  {
    this.params = Collections.unmodifiableMap(new HashMap());
  }

  ParseConfig(JSONObject paramJSONObject, ParseDecoder paramParseDecoder)
    throws JSONException
  {
    Map localMap = (Map)((Map)paramParseDecoder.decode(paramJSONObject)).get("params");
    if (localMap == null)
      throw new RuntimeException("Object did not contain the 'params' key.");
    this.params = Collections.unmodifiableMap(localMap);
  }

  static void clearCurrentConfigForTesting()
  {
    synchronized (currentConfigMutex)
    {
      currentConfig = null;
      return;
    }
  }

  public static ParseConfig get()
    throws ParseException
  {
    return (ParseConfig)Parse.waitForTask(getInBackground());
  }

  private static Task<ParseConfig> getAsync(Task<Void> paramTask)
  {
    return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation(paramTask)
    {
      public Task<JSONObject> then(Task<String> paramTask)
        throws Exception
      {
        ParseRESTConfigCommand localParseRESTConfigCommand = ParseRESTConfigCommand.fetchConfigCommand((String)paramTask.getResult());
        localParseRESTConfigCommand.enableRetrying();
        return this.val$toAwait.continueWithTask(new Continuation(localParseRESTConfigCommand)
        {
          public Task<JSONObject> then(Task<Void> paramTask)
            throws Exception
          {
            return this.val$command.executeAsync().cast();
          }
        });
      }
    }).onSuccess(new Continuation()
    {
      public ParseConfig then(Task<JSONObject> paramTask)
        throws Exception
      {
        ParseConfig localParseConfig1 = new ParseConfig((JSONObject)paramTask.getResult(), new ParseDecoder());
        localParseConfig1.saveToDisk(Parse.applicationContext, "currentConfig");
        synchronized (ParseConfig.currentConfigMutex)
        {
          ParseConfig.access$302(localParseConfig1);
          ParseConfig localParseConfig2 = ParseConfig.currentConfig;
          return localParseConfig2;
        }
      }
    }
    , Task.BACKGROUND_EXECUTOR);
  }

  public static ParseConfig getCurrentConfig()
  {
    if (currentConfig == null);
    synchronized (currentConfigMutex)
    {
      ParseConfig localParseConfig = getFromDisk(Parse.applicationContext, "currentConfig");
      if (localParseConfig != null)
      {
        currentConfig = localParseConfig;
        return currentConfig;
      }
      localParseConfig = new ParseConfig();
    }
  }

  private static ParseConfig getFromDisk(Context paramContext, String paramString)
  {
    JSONObject localJSONObject = Parse.getDiskObject(paramContext, paramString);
    if (localJSONObject == null)
      return null;
    try
    {
      ParseConfig localParseConfig = new ParseConfig(localJSONObject, new ParseDecoder());
      return localParseConfig;
    }
    catch (JSONException localJSONException)
    {
    }
    return null;
  }

  public static Task<ParseConfig> getInBackground()
  {
    return taskQueue.enqueue(new Continuation()
    {
      public Task<ParseConfig> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseConfig.access$000(paramTask);
      }
    });
  }

  public static void getInBackground(ConfigCallback paramConfigCallback)
  {
    Parse.callbackOnMainThreadAsync(getInBackground(), paramConfigCallback);
  }

  private void saveToDisk(Context paramContext, String paramString)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("params", (JSONObject)Parse.encode(this.params, PointerEncodingStrategy.get()));
      Parse.saveDiskObject(paramContext, paramString, localJSONObject);
      return;
    }
    catch (JSONException localJSONException)
    {
    }
    throw new RuntimeException("could not serialize config to JSON");
  }

  public Object get(String paramString)
  {
    return get(paramString, null);
  }

  public Object get(String paramString, Object paramObject)
  {
    if (!this.params.containsKey(paramString))
      return paramObject;
    if (this.params.get(paramString) == JSONObject.NULL)
      return null;
    return this.params.get(paramString);
  }

  public boolean getBoolean(String paramString)
  {
    return getBoolean(paramString, false);
  }

  public boolean getBoolean(String paramString, boolean paramBoolean)
  {
    if (!this.params.containsKey(paramString));
    Object localObject;
    do
    {
      return paramBoolean;
      localObject = this.params.get(paramString);
    }
    while (!(localObject instanceof Boolean));
    return ((Boolean)localObject).booleanValue();
  }

  public Date getDate(String paramString)
  {
    return getDate(paramString, null);
  }

  public Date getDate(String paramString, Date paramDate)
  {
    if (!this.params.containsKey(paramString))
      return paramDate;
    Object localObject = this.params.get(paramString);
    if ((localObject == null) || (localObject == JSONObject.NULL))
      return null;
    if ((localObject instanceof Date));
    for (Date localDate = (Date)localObject; ; localDate = paramDate)
      return localDate;
  }

  public double getDouble(String paramString)
  {
    return getDouble(paramString, 0.0D);
  }

  public double getDouble(String paramString, double paramDouble)
  {
    Number localNumber = getNumber(paramString);
    if (localNumber != null)
      paramDouble = localNumber.doubleValue();
    return paramDouble;
  }

  public int getInt(String paramString)
  {
    return getInt(paramString, 0);
  }

  public int getInt(String paramString, int paramInt)
  {
    Number localNumber = getNumber(paramString);
    if (localNumber != null)
      paramInt = localNumber.intValue();
    return paramInt;
  }

  public JSONArray getJSONArray(String paramString)
  {
    return getJSONArray(paramString, null);
  }

  public JSONArray getJSONArray(String paramString, JSONArray paramJSONArray)
  {
    List localList = getList(paramString);
    if (localList != null);
    for (Object localObject = Parse.encode(localList, PointerEncodingStrategy.get()); ; localObject = null)
    {
      if ((localObject == null) || ((localObject instanceof JSONArray)))
        paramJSONArray = (JSONArray)localObject;
      return paramJSONArray;
    }
  }

  public JSONObject getJSONObject(String paramString)
  {
    return getJSONObject(paramString, null);
  }

  public JSONObject getJSONObject(String paramString, JSONObject paramJSONObject)
  {
    Map localMap = getMap(paramString);
    if (localMap != null);
    for (Object localObject = Parse.encode(localMap, PointerEncodingStrategy.get()); ; localObject = null)
    {
      if ((localObject == null) || ((localObject instanceof JSONObject)))
        paramJSONObject = (JSONObject)localObject;
      return paramJSONObject;
    }
  }

  public <T> List<T> getList(String paramString)
  {
    return getList(paramString, null);
  }

  public <T> List<T> getList(String paramString, List<T> paramList)
  {
    if (!this.params.containsKey(paramString))
      return paramList;
    Object localObject1 = this.params.get(paramString);
    if ((localObject1 == null) || (localObject1 == JSONObject.NULL))
      return null;
    if ((localObject1 instanceof List));
    for (Object localObject2 = (List)localObject1; ; localObject2 = paramList)
      return localObject2;
  }

  public long getLong(String paramString)
  {
    return getLong(paramString, 0L);
  }

  public long getLong(String paramString, long paramLong)
  {
    Number localNumber = getNumber(paramString);
    if (localNumber != null)
      paramLong = localNumber.longValue();
    return paramLong;
  }

  public <V> Map<String, V> getMap(String paramString)
  {
    return getMap(paramString, null);
  }

  public <V> Map<String, V> getMap(String paramString, Map<String, V> paramMap)
  {
    if (!this.params.containsKey(paramString))
      return paramMap;
    Object localObject1 = this.params.get(paramString);
    if ((localObject1 == null) || (localObject1 == JSONObject.NULL))
      return null;
    if ((localObject1 instanceof Map));
    for (Object localObject2 = (Map)localObject1; ; localObject2 = paramMap)
      return localObject2;
  }

  public Number getNumber(String paramString)
  {
    return getNumber(paramString, null);
  }

  public Number getNumber(String paramString, Number paramNumber)
  {
    if (!this.params.containsKey(paramString))
      return paramNumber;
    Object localObject = this.params.get(paramString);
    if ((localObject == null) || (localObject == JSONObject.NULL))
      return null;
    if ((localObject instanceof Number));
    for (Number localNumber = (Number)localObject; ; localNumber = paramNumber)
      return localNumber;
  }

  public ParseFile getParseFile(String paramString)
  {
    return getParseFile(paramString, null);
  }

  public ParseFile getParseFile(String paramString, ParseFile paramParseFile)
  {
    if (!this.params.containsKey(paramString))
      return paramParseFile;
    Object localObject = this.params.get(paramString);
    if ((localObject == null) || (localObject == JSONObject.NULL))
      return null;
    if ((localObject instanceof ParseFile));
    for (ParseFile localParseFile = (ParseFile)localObject; ; localParseFile = paramParseFile)
      return localParseFile;
  }

  public ParseGeoPoint getParseGeoPoint(String paramString)
  {
    return getParseGeoPoint(paramString, null);
  }

  public ParseGeoPoint getParseGeoPoint(String paramString, ParseGeoPoint paramParseGeoPoint)
  {
    if (!this.params.containsKey(paramString))
      return paramParseGeoPoint;
    Object localObject = this.params.get(paramString);
    if ((localObject == null) || (localObject == JSONObject.NULL))
      return null;
    if ((localObject instanceof ParseGeoPoint));
    for (ParseGeoPoint localParseGeoPoint = (ParseGeoPoint)localObject; ; localParseGeoPoint = paramParseGeoPoint)
      return localParseGeoPoint;
  }

  public String getString(String paramString)
  {
    return getString(paramString, null);
  }

  public String getString(String paramString1, String paramString2)
  {
    if (!this.params.containsKey(paramString1))
      return paramString2;
    Object localObject = this.params.get(paramString1);
    if ((localObject == null) || (localObject == JSONObject.NULL))
      return null;
    if ((localObject instanceof String));
    for (String str = (String)localObject; ; str = paramString2)
      return str;
  }

  public String toString()
  {
    return "ParseConfig[" + this.params.toString() + "]";
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseConfig
 * JD-Core Version:    0.6.0
 */