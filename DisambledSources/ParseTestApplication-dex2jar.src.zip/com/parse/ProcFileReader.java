package com.parse;

import android.os.Process;
import android.util.Log;
import java.io.File;

class ProcFileReader
{
  public static final int CANNOT_DETERMINE_OPEN_FDS = -1;
  public static final int SECURITY_EXCEPTION = -2;
  private static final Class<?> TAG = ProcFileReader.class;

  public static int getOpenFDCount()
  {
    try
    {
      String[] arrayOfString1 = new String[3];
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = Integer.valueOf(Process.myPid());
      arrayOfString1[0] = String.format("/proc/%s/fd", arrayOfObject1);
      arrayOfString1[1] = "/proc/self/fd";
      Object[] arrayOfObject2 = new Object[1];
      arrayOfObject2[0] = Integer.valueOf(Process.myTid());
      arrayOfString1[2] = String.format("/proc/%s/fd", arrayOfObject2);
      for (int i = 0; i < arrayOfString1.length; i++)
      {
        String[] arrayOfString2 = new File(arrayOfString1[i]).list();
        if (arrayOfString2 == null)
          continue;
        int j = arrayOfString2.length;
        return j;
      }
      return -1;
    }
    catch (SecurityException localSecurityException)
    {
      Log.e(TAG.toString(), localSecurityException.getMessage());
    }
    return -2;
  }

  // ERROR //
  public static OpenFDLimits getOpenFDLimits()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_0
    //   2: new 79	java/util/Scanner
    //   5: dup
    //   6: new 49	java/io/File
    //   9: dup
    //   10: ldc 81
    //   12: invokespecial 52	java/io/File:<init>	(Ljava/lang/String;)V
    //   15: invokespecial 84	java/util/Scanner:<init>	(Ljava/io/File;)V
    //   18: astore_1
    //   19: aload_1
    //   20: ldc 86
    //   22: sipush 5000
    //   25: invokevirtual 90	java/util/Scanner:findWithinHorizon	(Ljava/lang/String;I)Ljava/lang/String;
    //   28: astore 5
    //   30: aload 5
    //   32: ifnonnull +13 -> 45
    //   35: aload_1
    //   36: ifnull +7 -> 43
    //   39: aload_1
    //   40: invokevirtual 93	java/util/Scanner:close	()V
    //   43: aconst_null
    //   44: areturn
    //   45: new 95	com/parse/ProcFileReader$OpenFDLimits
    //   48: dup
    //   49: aload_1
    //   50: invokevirtual 98	java/util/Scanner:next	()Ljava/lang/String;
    //   53: aload_1
    //   54: invokevirtual 98	java/util/Scanner:next	()Ljava/lang/String;
    //   57: invokespecial 101	com/parse/ProcFileReader$OpenFDLimits:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   60: astore 6
    //   62: aload_1
    //   63: ifnull +7 -> 70
    //   66: aload_1
    //   67: invokevirtual 93	java/util/Scanner:close	()V
    //   70: aload 6
    //   72: areturn
    //   73: astore 8
    //   75: aload_0
    //   76: ifnull -33 -> 43
    //   79: aload_0
    //   80: invokevirtual 93	java/util/Scanner:close	()V
    //   83: aconst_null
    //   84: areturn
    //   85: astore 7
    //   87: aload_0
    //   88: ifnull -45 -> 43
    //   91: aload_0
    //   92: invokevirtual 93	java/util/Scanner:close	()V
    //   95: aconst_null
    //   96: areturn
    //   97: astore 4
    //   99: aload_0
    //   100: ifnull +7 -> 107
    //   103: aload_0
    //   104: invokevirtual 93	java/util/Scanner:close	()V
    //   107: aload 4
    //   109: athrow
    //   110: astore 4
    //   112: aload_1
    //   113: astore_0
    //   114: goto -15 -> 99
    //   117: astore_3
    //   118: aload_1
    //   119: astore_0
    //   120: goto -33 -> 87
    //   123: astore_2
    //   124: aload_1
    //   125: astore_0
    //   126: goto -51 -> 75
    //
    // Exception table:
    //   from	to	target	type
    //   2	19	73	java/io/IOException
    //   2	19	85	java/util/NoSuchElementException
    //   2	19	97	finally
    //   19	30	110	finally
    //   45	62	110	finally
    //   19	30	117	java/util/NoSuchElementException
    //   45	62	117	java/util/NoSuchElementException
    //   19	30	123	java/io/IOException
    //   45	62	123	java/io/IOException
  }

  public static class OpenFDLimits
  {
    public final String hardLimit;
    public final String softLimit;

    public OpenFDLimits(String paramString1, String paramString2)
    {
      this.softLimit = paramString1;
      this.hardLimit = paramString2;
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ProcFileReader
 * JD-Core Version:    0.6.0
 */