package com.parse;

import android.content.Context;

abstract interface ReportsCrashes
{
  public abstract String[] additionalDropBoxTags();

  public abstract boolean checkSSLCertsOnCrashReport();

  public abstract int dropboxCollectionMinutes();

  public abstract String formPostFormat();

  public abstract Context getApplicationContext();

  public abstract boolean includeDropBoxSystemTags();

  public abstract String[] logcatArguments();

  public abstract int socketTimeout();
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ReportsCrashes
 * JD-Core Version:    0.6.0
 */