package com.parse;

 enum PushType
{
  private final String pushType;

  static
  {
    GCM = new PushType("GCM", 2, "gcm");
    PushType[] arrayOfPushType = new PushType[3];
    arrayOfPushType[0] = NONE;
    arrayOfPushType[1] = PPNS;
    arrayOfPushType[2] = GCM;
    $VALUES = arrayOfPushType;
  }

  private PushType(String paramString)
  {
    this.pushType = paramString;
  }

  static PushType fromString(String paramString)
  {
    if ("none".equals(paramString))
      return NONE;
    if ("ppns".equals(paramString))
      return PPNS;
    if ("gcm".equals(paramString))
      return GCM;
    return null;
  }

  public String toString()
  {
    return this.pushType;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.PushType
 * JD-Core Version:    0.6.0
 */