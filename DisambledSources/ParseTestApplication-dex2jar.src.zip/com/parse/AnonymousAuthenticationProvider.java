package com.parse;

import bolts.Task;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

class AnonymousAuthenticationProvider extends ParseAuthenticationProvider
{
  public Task<JSONObject> authenticateAsync()
  {
    try
    {
      Task localTask = Task.forResult(getAuthData());
      return localTask;
    }
    catch (JSONException localJSONException)
    {
    }
    return Task.forError(localJSONException);
  }

  public void cancel()
  {
  }

  public void deauthenticate()
  {
  }

  public JSONObject getAuthData()
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject();
    localJSONObject.put("id", UUID.randomUUID().toString());
    return localJSONObject;
  }

  public String getAuthType()
  {
    return "anonymous";
  }

  public boolean restoreAuthentication(JSONObject paramJSONObject)
  {
    return true;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.AnonymousAuthenticationProvider
 * JD-Core Version:    0.6.0
 */