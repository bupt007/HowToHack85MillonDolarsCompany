package com.parse;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.UUID;

class Installation
{
  private static final String INSTALLATION = "installation";
  private static String sID = null;

  public static String id(FileProvider paramFileProvider)
  {
    monitorenter;
    try
    {
      File localFile1;
      String str;
      if (sID == null)
      {
        localFile1 = paramFileProvider.getFile("cr");
        if (localFile1 == null)
          str = "n/a";
      }
      while (true)
      {
        return str;
        File localFile2 = new File(localFile1, "installation");
        try
        {
          if (!localFile2.exists())
            writeInstallationFile(localFile2);
          sID = readInstallationFile(localFile2);
          str = sID;
        }
        catch (Exception localException)
        {
          str = "n/a";
        }
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  private static String readInstallationFile(File paramFile)
    throws IOException
  {
    RandomAccessFile localRandomAccessFile = new RandomAccessFile(paramFile, "r");
    try
    {
      byte[] arrayOfByte = new byte[(int)localRandomAccessFile.length()];
      localRandomAccessFile.readFully(arrayOfByte);
      String str = new String(arrayOfByte);
      return str;
    }
    finally
    {
      localRandomAccessFile.close();
    }
    throw localObject;
  }

  private static void writeInstallationFile(File paramFile)
    throws IOException
  {
    FileOutputStream localFileOutputStream = new FileOutputStream(paramFile);
    try
    {
      localFileOutputStream.write(UUID.randomUUID().toString().getBytes());
      return;
    }
    finally
    {
      localFileOutputStream.close();
    }
    throw localObject;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.Installation
 * JD-Core Version:    0.6.0
 */