package com.parse;

import bolts.Continuation;
import bolts.Task;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class ParseCloud
{
  public static <T> T callFunction(String paramString, Map<String, ?> paramMap)
    throws ParseException
  {
    return Parse.waitForTask(callFunctionInBackground(paramString, paramMap));
  }

  public static <T> Task<T> callFunctionInBackground(String paramString, Map<String, ?> paramMap)
  {
    return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation(paramString, paramMap)
    {
      public Task<T> then(Task<String> paramTask)
        throws Exception
      {
        String str = (String)paramTask.getResult();
        return ParseRESTCloudCommand.callFunctionCommand(this.val$name, this.val$params, str).executeAsync().onSuccess(new Continuation()
        {
          public T then(Task<Object> paramTask)
            throws Exception
          {
            return ParseCloud.access$000(paramTask.getResult());
          }
        });
      }
    });
  }

  public static <T> void callFunctionInBackground(String paramString, Map<String, ?> paramMap, FunctionCallback<T> paramFunctionCallback)
  {
    Parse.callbackOnMainThreadAsync(callFunctionInBackground(paramString, paramMap), paramFunctionCallback);
  }

  private static Object convertCloudResponse(Object paramObject)
  {
    JSONObject localJSONObject;
    if ((paramObject instanceof JSONObject))
      localJSONObject = (JSONObject)paramObject;
    try
    {
      Object localObject2 = localJSONObject.get("result");
      paramObject = localObject2;
      Object localObject1 = new ParseDecoder().decode(paramObject);
      if (localObject1 != null)
        paramObject = localObject1;
      return paramObject;
    }
    catch (JSONException localJSONException)
    {
    }
    return paramObject;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseCloud
 * JD-Core Version:    0.6.0
 */