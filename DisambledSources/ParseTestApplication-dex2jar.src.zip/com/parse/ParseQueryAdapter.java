package com.parse;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import bolts.Capture;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;

public class ParseQueryAdapter<T extends ParseObject> extends BaseAdapter
{
  private static final int VIEW_TYPE_ITEM = 0;
  private static final int VIEW_TYPE_NEXT_PAGE = 1;
  private boolean autoload = true;
  private Context context;
  private int currentPage = 0;
  private WeakHashMap<DataSetObserver, Void> dataSetObservers = new WeakHashMap();
  private boolean hasNextPage = true;
  private String imageKey;
  private WeakHashMap<ParseImageView, Void> imageViewSet = new WeakHashMap();
  private Integer itemResourceId;
  private List<List<T>> objectPages = new ArrayList();
  private List<T> objects = new ArrayList();
  private int objectsPerPage = 25;
  private List<OnQueryLoadListener<T>> onQueryLoadListeners = new ArrayList();
  private boolean paginationEnabled = true;
  private Drawable placeholder;
  private QueryFactory<T> queryFactory;
  private String textKey;

  public ParseQueryAdapter(Context paramContext, QueryFactory<T> paramQueryFactory)
  {
    this(paramContext, paramQueryFactory, null);
  }

  public ParseQueryAdapter(Context paramContext, QueryFactory<T> paramQueryFactory, int paramInt)
  {
    this(paramContext, paramQueryFactory, Integer.valueOf(paramInt));
  }

  private ParseQueryAdapter(Context paramContext, QueryFactory<T> paramQueryFactory, Integer paramInteger)
  {
    this.context = paramContext;
    this.queryFactory = paramQueryFactory;
    this.itemResourceId = paramInteger;
  }

  public ParseQueryAdapter(Context paramContext, Class<? extends ParseObject> paramClass)
  {
    this(paramContext, ParseObject.getClassName(paramClass));
  }

  public ParseQueryAdapter(Context paramContext, Class<? extends ParseObject> paramClass, int paramInt)
  {
    this(paramContext, ParseObject.getClassName(paramClass), paramInt);
  }

  public ParseQueryAdapter(Context paramContext, String paramString)
  {
    this(paramContext, new QueryFactory()
    {
      public ParseQuery<T> create()
      {
        ParseQuery localParseQuery = ParseQuery.getQuery(ParseQueryAdapter.this);
        localParseQuery.orderByDescending("createdAt");
        return localParseQuery;
      }
    });
    if (paramString == null)
      throw new RuntimeException("You need to specify a className for the ParseQueryAdapter");
  }

  public ParseQueryAdapter(Context paramContext, String paramString, int paramInt)
  {
    this(paramContext, new QueryFactory()
    {
      public ParseQuery<T> create()
      {
        ParseQuery localParseQuery = ParseQuery.getQuery(ParseQueryAdapter.this);
        localParseQuery.orderByDescending("createdAt");
        return localParseQuery;
      }
    }
    , paramInt);
    if (paramString == null)
      throw new RuntimeException("You need to specify a className for the ParseQueryAdapter");
  }

  private View getDefaultView(Context paramContext)
  {
    if (this.itemResourceId != null)
      return View.inflate(paramContext, this.itemResourceId.intValue(), null);
    LinearLayout localLinearLayout = new LinearLayout(paramContext);
    localLinearLayout.setPadding(8, 4, 8, 4);
    ParseImageView localParseImageView = new ParseImageView(paramContext);
    localParseImageView.setId(16908294);
    localParseImageView.setLayoutParams(new LinearLayout.LayoutParams(50, 50));
    localLinearLayout.addView(localParseImageView);
    TextView localTextView = new TextView(paramContext);
    localTextView.setId(16908308);
    localTextView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
    localTextView.setPadding(8, 0, 0, 0);
    localLinearLayout.addView(localTextView);
    return localLinearLayout;
  }

  private int getPaginationCellRow()
  {
    return this.objects.size();
  }

  private void loadObjects(int paramInt, boolean paramBoolean)
  {
    ParseQuery localParseQuery = this.queryFactory.create();
    if ((this.objectsPerPage > 0) && (this.paginationEnabled))
      setPageOnQuery(paramInt, localParseQuery);
    notifyOnLoadingListeners();
    if (paramInt >= this.objectPages.size())
      this.objectPages.add(paramInt, new ArrayList());
    localParseQuery.findInBackground(new FindCallback(localParseQuery, paramBoolean, new Capture(Boolean.valueOf(true)), paramInt)
    {
      @SuppressLint({"ShowToast"})
      public void done(List<T> paramList, ParseException paramParseException)
      {
        if ((!OfflineStore.isEnabled()) && (this.val$query.getCachePolicy() == ParseQuery.CachePolicy.CACHE_ONLY) && (paramParseException != null) && (paramParseException.getCode() == 120))
          return;
        if ((paramParseException != null) && ((paramParseException.getCode() == 100) || (paramParseException.getCode() != 120)))
          ParseQueryAdapter.access$002(ParseQueryAdapter.this, true);
        do
        {
          ParseQueryAdapter.this.notifyOnLoadedListeners(paramList, paramParseException);
          return;
        }
        while (paramList == null);
        if ((this.val$shouldClear) && (((Boolean)this.val$firstCallBack.get()).booleanValue()))
        {
          ParseQueryAdapter.this.objectPages.clear();
          ParseQueryAdapter.this.objectPages.add(new ArrayList());
          ParseQueryAdapter.access$202(ParseQueryAdapter.this, this.val$page);
          this.val$firstCallBack.set(Boolean.valueOf(false));
        }
        ParseQueryAdapter localParseQueryAdapter;
        if (this.val$page >= ParseQueryAdapter.this.currentPage)
        {
          ParseQueryAdapter.access$202(ParseQueryAdapter.this, this.val$page);
          localParseQueryAdapter = ParseQueryAdapter.this;
          if (paramList.size() <= ParseQueryAdapter.this.objectsPerPage)
            break label306;
        }
        label306: for (boolean bool = true; ; bool = false)
        {
          ParseQueryAdapter.access$002(localParseQueryAdapter, bool);
          if ((ParseQueryAdapter.this.paginationEnabled) && (paramList.size() > ParseQueryAdapter.this.objectsPerPage))
            paramList.remove(ParseQueryAdapter.this.objectsPerPage);
          List localList = (List)ParseQueryAdapter.this.objectPages.get(this.val$page);
          localList.clear();
          localList.addAll(paramList);
          ParseQueryAdapter.this.syncObjectsWithPages();
          ParseQueryAdapter.this.notifyDataSetChanged();
          break;
        }
      }
    });
  }

  private void notifyOnLoadedListeners(List<T> paramList, Exception paramException)
  {
    Iterator localIterator = this.onQueryLoadListeners.iterator();
    while (localIterator.hasNext())
      ((OnQueryLoadListener)localIterator.next()).onLoaded(paramList, paramException);
  }

  private void notifyOnLoadingListeners()
  {
    Iterator localIterator = this.onQueryLoadListeners.iterator();
    while (localIterator.hasNext())
      ((OnQueryLoadListener)localIterator.next()).onLoading();
  }

  private boolean shouldShowPaginationCell()
  {
    return (this.paginationEnabled) && (this.objects.size() > 0) && (this.hasNextPage);
  }

  private void syncObjectsWithPages()
  {
    this.objects.clear();
    Iterator localIterator = this.objectPages.iterator();
    while (localIterator.hasNext())
    {
      List localList = (List)localIterator.next();
      this.objects.addAll(localList);
    }
  }

  public void addOnQueryLoadListener(OnQueryLoadListener<T> paramOnQueryLoadListener)
  {
    this.onQueryLoadListeners.add(paramOnQueryLoadListener);
  }

  public void clear()
  {
    this.objectPages.clear();
    syncObjectsWithPages();
    notifyDataSetChanged();
    this.currentPage = 0;
  }

  public Context getContext()
  {
    return this.context;
  }

  public int getCount()
  {
    int i = this.objects.size();
    if (shouldShowPaginationCell())
      i++;
    return i;
  }

  public T getItem(int paramInt)
  {
    if (paramInt == getPaginationCellRow())
      return null;
    return (ParseObject)this.objects.get(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  // ERROR //
  public View getItemView(T paramT, View paramView, ViewGroup paramViewGroup)
  {
    // Byte code:
    //   0: aload_2
    //   1: ifnonnull +12 -> 13
    //   4: aload_0
    //   5: aload_0
    //   6: getfield 83	com/parse/ParseQueryAdapter:context	Landroid/content/Context;
    //   9: invokespecial 296	com/parse/ParseQueryAdapter:getDefaultView	(Landroid/content/Context;)Landroid/view/View;
    //   12: astore_2
    //   13: aload_2
    //   14: ldc 186
    //   16: invokevirtual 300	android/view/View:findViewById	(I)Landroid/view/View;
    //   19: checkcast 184	android/widget/TextView
    //   22: astore 5
    //   24: aload 5
    //   26: ifnull +19 -> 45
    //   29: aload_0
    //   30: getfield 302	com/parse/ParseQueryAdapter:textKey	Ljava/lang/String;
    //   33: ifnonnull +61 -> 94
    //   36: aload 5
    //   38: aload_1
    //   39: invokevirtual 306	com/parse/ParseObject:getObjectId	()Ljava/lang/String;
    //   42: invokevirtual 310	android/widget/TextView:setText	(Ljava/lang/CharSequence;)V
    //   45: aload_0
    //   46: getfield 312	com/parse/ParseQueryAdapter:imageKey	Ljava/lang/String;
    //   49: ifnull +153 -> 202
    //   52: aload_2
    //   53: ldc 165
    //   55: invokevirtual 300	android/view/View:findViewById	(I)Landroid/view/View;
    //   58: checkcast 163	com/parse/ParseImageView
    //   61: astore 7
    //   63: aload 7
    //   65: ifnonnull +83 -> 148
    //   68: new 314	java/lang/IllegalStateException
    //   71: dup
    //   72: ldc_w 316
    //   75: invokespecial 317	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   78: athrow
    //   79: astore 4
    //   81: new 314	java/lang/IllegalStateException
    //   84: dup
    //   85: ldc_w 319
    //   88: aload 4
    //   90: invokespecial 322	java/lang/IllegalStateException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   93: athrow
    //   94: aload_1
    //   95: aload_0
    //   96: getfield 302	com/parse/ParseQueryAdapter:textKey	Ljava/lang/String;
    //   99: invokevirtual 325	com/parse/ParseObject:get	(Ljava/lang/String;)Ljava/lang/Object;
    //   102: ifnull +22 -> 124
    //   105: aload 5
    //   107: aload_1
    //   108: aload_0
    //   109: getfield 302	com/parse/ParseQueryAdapter:textKey	Ljava/lang/String;
    //   112: invokevirtual 325	com/parse/ParseObject:get	(Ljava/lang/String;)Ljava/lang/Object;
    //   115: invokevirtual 330	java/lang/Object:toString	()Ljava/lang/String;
    //   118: invokevirtual 310	android/widget/TextView:setText	(Ljava/lang/CharSequence;)V
    //   121: goto -76 -> 45
    //   124: aload 5
    //   126: aconst_null
    //   127: invokevirtual 310	android/widget/TextView:setText	(Ljava/lang/CharSequence;)V
    //   130: goto -85 -> 45
    //   133: astore 6
    //   135: new 314	java/lang/IllegalStateException
    //   138: dup
    //   139: ldc_w 332
    //   142: aload 6
    //   144: invokespecial 322	java/lang/IllegalStateException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   147: athrow
    //   148: aload_0
    //   149: getfield 64	com/parse/ParseQueryAdapter:imageViewSet	Ljava/util/WeakHashMap;
    //   152: aload 7
    //   154: invokevirtual 335	java/util/WeakHashMap:containsKey	(Ljava/lang/Object;)Z
    //   157: ifne +14 -> 171
    //   160: aload_0
    //   161: getfield 64	com/parse/ParseQueryAdapter:imageViewSet	Ljava/util/WeakHashMap;
    //   164: aload 7
    //   166: aconst_null
    //   167: invokevirtual 339	java/util/WeakHashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   170: pop
    //   171: aload 7
    //   173: aload_0
    //   174: getfield 341	com/parse/ParseQueryAdapter:placeholder	Landroid/graphics/drawable/Drawable;
    //   177: invokevirtual 345	com/parse/ParseImageView:setPlaceholder	(Landroid/graphics/drawable/Drawable;)V
    //   180: aload 7
    //   182: aload_1
    //   183: aload_0
    //   184: getfield 312	com/parse/ParseQueryAdapter:imageKey	Ljava/lang/String;
    //   187: invokevirtual 325	com/parse/ParseObject:get	(Ljava/lang/String;)Ljava/lang/Object;
    //   190: checkcast 347	com/parse/ParseFile
    //   193: invokevirtual 351	com/parse/ParseImageView:setParseFile	(Lcom/parse/ParseFile;)V
    //   196: aload 7
    //   198: invokevirtual 355	com/parse/ParseImageView:loadInBackground	()Lbolts/Task;
    //   201: pop
    //   202: aload_2
    //   203: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   13	24	79	java/lang/ClassCastException
    //   52	63	133	java/lang/ClassCastException
  }

  public int getItemViewType(int paramInt)
  {
    if (paramInt == getPaginationCellRow())
      return 1;
    return 0;
  }

  public View getNextPageView(View paramView, ViewGroup paramViewGroup)
  {
    if (paramView == null)
      paramView = getDefaultView(this.context);
    ((TextView)paramView.findViewById(16908308)).setText("Load more...");
    return paramView;
  }

  public int getObjectsPerPage()
  {
    return this.objectsPerPage;
  }

  public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    if (getItemViewType(paramInt) == 1)
    {
      View localView = getNextPageView(paramView, paramViewGroup);
      localView.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramView)
        {
          ParseQueryAdapter.this.loadNextPage();
        }
      });
      return localView;
    }
    return getItemView(getItem(paramInt), paramView, paramViewGroup);
  }

  public int getViewTypeCount()
  {
    return 2;
  }

  public void loadNextPage()
  {
    loadObjects(1 + this.currentPage, false);
  }

  public void loadObjects()
  {
    loadObjects(0, true);
  }

  public void registerDataSetObserver(DataSetObserver paramDataSetObserver)
  {
    super.registerDataSetObserver(paramDataSetObserver);
    this.dataSetObservers.put(paramDataSetObserver, null);
    if (this.autoload)
      loadObjects();
  }

  public void removeOnQueryLoadListener(OnQueryLoadListener<T> paramOnQueryLoadListener)
  {
    this.onQueryLoadListeners.remove(paramOnQueryLoadListener);
  }

  public void setAutoload(boolean paramBoolean)
  {
    if (this.autoload == paramBoolean);
    do
    {
      return;
      this.autoload = paramBoolean;
    }
    while ((!this.autoload) || (this.dataSetObservers.isEmpty()) || (!this.objects.isEmpty()));
    loadObjects();
  }

  public void setImageKey(String paramString)
  {
    this.imageKey = paramString;
  }

  public void setObjectsPerPage(int paramInt)
  {
    this.objectsPerPage = paramInt;
  }

  protected void setPageOnQuery(int paramInt, ParseQuery<T> paramParseQuery)
  {
    paramParseQuery.setLimit(1 + this.objectsPerPage);
    paramParseQuery.setSkip(paramInt * this.objectsPerPage);
  }

  public void setPaginationEnabled(boolean paramBoolean)
  {
    this.paginationEnabled = paramBoolean;
  }

  public void setPlaceholder(Drawable paramDrawable)
  {
    if (this.placeholder == paramDrawable);
    while (true)
    {
      return;
      this.placeholder = paramDrawable;
      Iterator localIterator = this.imageViewSet.keySet().iterator();
      while (localIterator.hasNext())
      {
        ParseImageView localParseImageView = (ParseImageView)localIterator.next();
        if (localParseImageView == null)
          continue;
        localParseImageView.setPlaceholder(this.placeholder);
      }
    }
  }

  public void setTextKey(String paramString)
  {
    this.textKey = paramString;
  }

  public void unregisterDataSetObserver(DataSetObserver paramDataSetObserver)
  {
    super.unregisterDataSetObserver(paramDataSetObserver);
    this.dataSetObservers.remove(paramDataSetObserver);
  }

  public static abstract interface OnQueryLoadListener<T extends ParseObject>
  {
    public abstract void onLoaded(List<T> paramList, Exception paramException);

    public abstract void onLoading();
  }

  public static abstract interface QueryFactory<T extends ParseObject>
  {
    public abstract ParseQuery<T> create();
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseQueryAdapter
 * JD-Core Version:    0.6.0
 */