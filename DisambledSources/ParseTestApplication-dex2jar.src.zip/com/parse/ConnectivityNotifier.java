package com.parse;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ReceiverCallNotAllowedException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

class ConnectivityNotifier extends BroadcastReceiver
{
  private static final String TAG = "com.parse.ConnectivityNotifier";
  private static final ConnectivityNotifier singleton = new ConnectivityNotifier();
  private boolean hasRegisteredReceiver = false;
  private Set<ConnectivityListener> listeners = new HashSet();
  private final Object lock = new Object();

  public static ConnectivityNotifier getNotifier(Context paramContext)
  {
    singleton.tryToRegisterForNetworkStatusNotifications(paramContext);
    return singleton;
  }

  public static boolean isConnected(Context paramContext)
  {
    ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    if (localConnectivityManager == null);
    NetworkInfo localNetworkInfo;
    do
    {
      return false;
      localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
    }
    while ((localNetworkInfo == null) || (!localNetworkInfo.isConnected()));
    return true;
  }

  private boolean tryToRegisterForNetworkStatusNotifications(Context paramContext)
  {
    synchronized (this.lock)
    {
      if (this.hasRegisteredReceiver)
        return true;
      if (paramContext == null)
        return false;
    }
    try
    {
      paramContext.getApplicationContext().registerReceiver(this, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
      this.hasRegisteredReceiver = true;
      monitorexit;
      return true;
      localObject2 = finally;
      monitorexit;
      throw localObject2;
    }
    catch (ReceiverCallNotAllowedException localReceiverCallNotAllowedException)
    {
      Parse.logV("com.parse.ConnectivityNotifier", "Cannot register a broadcast receiver because the executing thread is currently in a broadcast receiver. Will try again later.");
      monitorexit;
    }
    return false;
  }

  public void addListener(ConnectivityListener paramConnectivityListener)
  {
    synchronized (this.lock)
    {
      this.listeners.add(paramConnectivityListener);
      return;
    }
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    synchronized (this.lock)
    {
      ArrayList localArrayList = new ArrayList(this.listeners);
      Iterator localIterator = localArrayList.iterator();
      if (localIterator.hasNext())
        ((ConnectivityListener)localIterator.next()).networkConnectivityStatusChanged(paramContext, paramIntent);
    }
  }

  public void removeListener(ConnectivityListener paramConnectivityListener)
  {
    synchronized (this.lock)
    {
      this.listeners.remove(paramConnectivityListener);
      return;
    }
  }

  public static abstract interface ConnectivityListener
  {
    public abstract void networkConnectivityStatusChanged(Context paramContext, Intent paramIntent);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ConnectivityNotifier
 * JD-Core Version:    0.6.0
 */