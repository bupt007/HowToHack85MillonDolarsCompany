package com.parse;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import bolts.Continuation;
import bolts.Task;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.Callable;
import org.json.JSONObject;

@ParseClassName("_Installation")
public class ParseInstallation extends ParseObject
{
  static final String FILENAME_CURRENT_INSTALLATION = "currentInstallation";
  private static final String INSTALLATION_ID_LOCATION = "installationId";
  private static final String KEY_APP_IDENTIFIER = "appIdentifier";
  private static final String KEY_APP_NAME = "appName";
  private static final String KEY_APP_VERSION = "appVersion";
  private static final String KEY_DEVICE_TOKEN = "deviceToken";
  private static final String KEY_DEVICE_TOKEN_LAST_MODIFIED = "deviceTokenLastModified";
  private static final String KEY_DEVICE_TYPE = "deviceType";
  private static final String KEY_INSTALLATION_ID = "installationId";
  private static final String KEY_PARSE_VERSION = "parseVersion";
  private static final String KEY_PUSH_TYPE = "pushType";
  private static final String KEY_TIME_ZONE = "timeZone";
  private static final Object MUTEX_CURRENT_INSTALLATION = new Object();
  private static final String PIN_CURRENT_INSTALLATION = "_currentInstallation";
  private static final List<String> READ_ONLY_FIELDS = Collections.unmodifiableList(Arrays.asList(new String[] { "deviceType", "installationId", "deviceToken", "pushType", "timeZone", "appVersion", "appName", "parseVersion", "deviceTokenLastModified", "appIdentifier" }));
  private static final String TAG = "com.parse.ParseInstallation";
  static ParseInstallation currentInstallation = null;
  static String installationId = null;

  static void clearCurrentInstallationFromDisk(Context paramContext)
  {
    synchronized (MUTEX_CURRENT_INSTALLATION)
    {
      currentInstallation = null;
      installationId = null;
      if (OfflineStore.isEnabled())
        ParseObject.unpinAllInBackground("_currentInstallation");
      Parse.deleteDiskObject(paramContext, "currentInstallation");
      Parse.deleteDiskObject(paramContext, "installationId");
      return;
    }
  }

  static void clearCurrentInstallationFromMemory()
  {
    synchronized (MUTEX_CURRENT_INSTALLATION)
    {
      currentInstallation = null;
      return;
    }
  }

  public static ParseInstallation getCurrentInstallation()
  {
    int i = 0;
    ParseInstallation localParseInstallation;
    synchronized (MUTEX_CURRENT_INSTALLATION)
    {
      localParseInstallation = currentInstallation;
      if (localParseInstallation != null)
        return localParseInstallation;
    }
    if (OfflineStore.isEnabled());
    try
    {
      localParseInstallation = (ParseInstallation)Parse.waitForTask(ParseQuery.getQuery(ParseInstallation.class).fromPin("_currentInstallation").ignoreACLs().findInBackground().onSuccessTask(new Continuation()
      {
        public Task<ParseInstallation> then(Task<List<ParseInstallation>> paramTask)
          throws Exception
        {
          List localList = (List)paramTask.getResult();
          if (localList != null)
          {
            if (localList.size() == 1)
              return Task.forResult(localList.get(0));
            return ParseObject.unpinAllInBackground("_currentInstallation").cast();
          }
          return Task.forResult(null);
        }
      }).onSuccessTask(new Continuation()
      {
        public Task<ParseInstallation> then(Task<ParseInstallation> paramTask)
          throws Exception
        {
          if ((ParseInstallation)paramTask.getResult() != null)
            return paramTask;
          return ParseObject.migrateFromDiskToLDS("currentInstallation", "_currentInstallation").cast();
        }
      }));
      while (true)
      {
        label74: if (localParseInstallation == null)
        {
          localParseInstallation = (ParseInstallation)ParseObject.create(ParseInstallation.class);
          localParseInstallation.updateDeviceInfo();
          if (i != 0)
            localParseInstallation.maybeUpdateInstallationIdOnDisk();
        }
        synchronized (MUTEX_CURRENT_INSTALLATION)
        {
          currentInstallation = localParseInstallation;
          return localParseInstallation;
          localParseInstallation = (ParseInstallation)getFromDisk(Parse.applicationContext, "currentInstallation");
          continue;
          i = 1;
          Parse.logV("com.parse.ParseInstallation", "Successfully deserialized Installation object");
        }
      }
    }
    catch (ParseException localParseException)
    {
      break label74;
    }
  }

  static String getOrCreateCurrentInstallationId()
  {
    synchronized (MUTEX_CURRENT_INSTALLATION)
    {
      String str = installationId;
      if (str != null);
    }
    try
    {
      installationId = new String(ParseFileUtils.readFileToByteArray(new File(Parse.getParseDir(), "installationId")));
      if (installationId == null)
      {
        installationId = UUID.randomUUID().toString();
        setCurrentInstallationId(installationId);
      }
      monitorexit;
      return installationId;
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      while (true)
        Parse.logI("com.parse.ParseInstallation", "Couldn't find existing installationId file. Creating one instead.");
      localObject2 = finally;
      monitorexit;
      throw localObject2;
    }
    catch (IOException localIOException)
    {
      while (true)
        Parse.logE("com.parse.ParseInstallation", "Unexpected exception reading installation id from disk", localIOException);
    }
  }

  public static ParseQuery<ParseInstallation> getQuery()
  {
    return ParseQuery.getQuery(ParseInstallation.class);
  }

  static Task<Boolean> hasCurrentInstallationAsync()
  {
    synchronized (MUTEX_CURRENT_INSTALLATION)
    {
      if (currentInstallation != null)
      {
        Task localTask = Task.forResult(Boolean.valueOf(true));
        return localTask;
      }
      if (OfflineStore.isEnabled())
        return ParseQuery.getQuery(ParseInstallation.class).fromPin("_currentInstallation").ignoreACLs().countInBackground().onSuccess(new Continuation()
        {
          public Boolean then(Task<Integer> paramTask)
            throws Exception
          {
            if (((Integer)paramTask.getResult()).intValue() == 1);
            for (boolean bool = true; ; bool = false)
              return Boolean.valueOf(bool);
          }
        });
    }
    return Task.call(new Callable()
    {
      public Boolean call()
        throws Exception
      {
        return Boolean.valueOf(new File(Parse.getParseDir(), "currentInstallation").exists());
      }
    }
    , Task.BACKGROUND_EXECUTOR);
  }

  private boolean isCurrentInstallation()
  {
    while (true)
    {
      synchronized (MUTEX_CURRENT_INSTALLATION)
      {
        if (this == currentInstallation)
        {
          i = 1;
          return i;
        }
      }
      int i = 0;
    }
  }

  private static Task<Void> maybeFlushToDiskAsync(ParseInstallation paramParseInstallation)
  {
    if (!paramParseInstallation.isCurrentInstallation())
      return Task.forResult(null);
    if (OfflineStore.isEnabled());
    for (Task localTask = ParseObject.unpinAllInBackground("_currentInstallation").continueWithTask(new Continuation(paramParseInstallation)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return this.val$installation.pinInBackground("_currentInstallation", false);
      }
    }); ; localTask = Task.forResult(null).continueWithTask(new Continuation(paramParseInstallation)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        this.val$installation.saveToDisk(Parse.applicationContext, "currentInstallation");
        return paramTask;
      }
    }))
      return localTask.continueWithTask(new Continuation(paramParseInstallation)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          this.val$installation.maybeUpdateInstallationIdOnDisk();
          return paramTask;
        }
      });
  }

  private void maybeUpdateInstallationIdOnDisk()
  {
    String str1 = getInstallationId();
    String str2 = getOrCreateCurrentInstallationId();
    if ((str1 == null) || (str1.length() == 0));
    for (int i = 1; ; i = 0)
    {
      if ((i == 0) && (!str1.equals(str2)))
      {
        Parse.logW("com.parse.ParseInstallation", "Will update installation id on disk: " + str2 + " because it does not match installation id in ParseInstallation: " + str1);
        setCurrentInstallationId(str1);
      }
      return;
    }
  }

  static void setCurrentInstallationId(String paramString)
  {
    synchronized (MUTEX_CURRENT_INSTALLATION)
    {
      File localFile = new File(Parse.getParseDir(), "installationId");
      try
      {
        ParseFileUtils.writeByteArrayToFile(localFile, paramString.getBytes());
        installationId = paramString;
        return;
      }
      catch (IOException localIOException)
      {
        while (true)
          Parse.logE("com.parse.ParseInstallation", "Unexpected exception writing installation id to disk", localIOException);
      }
    }
  }

  private void updateDeviceInfo()
  {
    if (!has("installationId"))
      performPut("installationId", getOrCreateCurrentInstallationId());
    if (!"android".equals(get("deviceType")))
      performPut("deviceType", "android");
  }

  private void updateTimezone()
  {
    String str = TimeZone.getDefault().getID();
    if (((str.indexOf('/') > 0) || (str.equals("GMT"))) && (!str.equals(get("timeZone"))))
      performPut("timeZone", str);
  }

  private void updateVersionInfo()
  {
    synchronized (this.mutex)
    {
      try
      {
        String str1 = Parse.applicationContext.getPackageName();
        PackageManager localPackageManager = Parse.applicationContext.getPackageManager();
        String str2 = localPackageManager.getPackageInfo(str1, 0).versionName;
        String str3 = localPackageManager.getApplicationLabel(localPackageManager.getApplicationInfo(str1, 0)).toString();
        if ((str1 != null) && (!str1.equals(get("appIdentifier"))))
          performPut("appIdentifier", str1);
        if ((str3 != null) && (!str3.equals(get("appName"))))
          performPut("appName", str3);
        if ((str2 != null) && (!str2.equals(get("appVersion"))))
          performPut("appVersion", str2);
        if (!"1.9.1".equals(get("parseVersion")))
          performPut("parseVersion", "1.9.1");
        return;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        while (true)
          Parse.logW("com.parse.ParseInstallation", "Cannot load package info; will not be saved to installation");
      }
    }
  }

  <T extends ParseObject> Task<T> fetchAsync(Task<Void> paramTask)
  {
    synchronized (this.mutex)
    {
      if (getObjectId() == null)
      {
        localTask1 = saveAsync(paramTask);
        Task localTask2 = localTask1.onSuccessTask(new Continuation(paramTask)
        {
          public Task<T> then(Task<Void> paramTask)
            throws Exception
          {
            return ParseInstallation.this.fetchAsync(this.val$toAwait);
          }
        });
        return localTask2;
      }
      Task localTask1 = Task.forResult(null);
    }
  }

  String getDeviceToken()
  {
    return super.getString("deviceToken");
  }

  public String getInstallationId()
  {
    return getString("installationId");
  }

  PushType getPushType()
  {
    return PushType.fromString(super.getString("pushType"));
  }

  Task<Void> handleFetchResultAsync(JSONObject paramJSONObject)
  {
    return super.handleFetchResultAsync(paramJSONObject).onSuccessTask(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseInstallation.access$100(ParseInstallation.this);
      }
    });
  }

  Task<Void> handleSaveResultAsync(JSONObject paramJSONObject, ParseOperationSet paramParseOperationSet)
  {
    Task localTask = super.handleSaveResultAsync(paramJSONObject, paramParseOperationSet);
    if (ManifestInfo.getPushUsesBroadcastReceivers())
      localTask = localTask.onSuccessTask(new Continuation()
      {
        public Task<Boolean> then(Task<Void> paramTask)
          throws Exception
        {
          return PushRouter.getForceEnabledStateAsync();
        }
      }).onSuccess(new Continuation()
      {
        public Void then(Task<Boolean> paramTask)
          throws Exception
        {
          Boolean localBoolean = (Boolean)paramTask.getResult();
          if ((localBoolean == null) || (localBoolean.booleanValue()))
            PushService.startServiceIfRequired(Parse.applicationContext);
          return null;
        }
      });
    return localTask.onSuccessTask(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseInstallation.access$100(ParseInstallation.this);
      }
    });
  }

  boolean isDeviceTokenStale()
  {
    return super.getLong("deviceTokenLastModified") != ManifestInfo.getLastModified();
  }

  boolean isKeyMutable(String paramString)
  {
    return !READ_ONLY_FIELDS.contains(paramString);
  }

  boolean needsDefaultACL()
  {
    return false;
  }

  void removeDeviceToken()
  {
    performRemove("deviceToken");
    performRemove("deviceTokenLastModified");
  }

  void removePushType()
  {
    performRemove("pushType");
  }

  void setDeviceToken(String paramString)
  {
    if ((paramString != null) && (paramString.length() > 0))
    {
      performPut("deviceToken", paramString);
      performPut("deviceTokenLastModified", Long.valueOf(ManifestInfo.getLastModified()));
    }
  }

  void setDeviceTokenLastModified(long paramLong)
  {
    performPut("deviceTokenLastModified", Long.valueOf(paramLong));
  }

  void setPushType(PushType paramPushType)
  {
    if (paramPushType != null)
      performPut("pushType", paramPushType.toString());
  }

  void updateBeforeSave()
  {
    super.updateBeforeSave();
    if (isCurrentInstallation())
    {
      updateTimezone();
      updateVersionInfo();
      updateDeviceInfo();
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseInstallation
 * JD-Core Version:    0.6.0
 */