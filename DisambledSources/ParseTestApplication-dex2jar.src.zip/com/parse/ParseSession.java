package com.parse;

import bolts.Continuation;
import bolts.Task;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.json.JSONObject;

@ParseClassName("_Session")
public class ParseSession extends ParseObject
{
  private static final String KEY_CREATED_WITH = "createdWith";
  private static final String KEY_EXPIRES_AT = "expiresAt";
  private static final String KEY_INSTALLATION_ID = "installationId";
  private static final String KEY_RESTRICTED = "restricted";
  private static final String KEY_SESSION_TOKEN = "sessionToken";
  private static final String KEY_USER = "user";
  private static final List<String> READ_ONLY_KEYS = Collections.unmodifiableList(Arrays.asList(new String[] { "sessionToken", "createdWith", "restricted", "user", "expiresAt", "installationId" }));

  public static Task<ParseSession> getCurrentSessionInBackground()
  {
    return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation()
    {
      public Task<JSONObject> then(Task<String> paramTask)
        throws Exception
      {
        String str = (String)paramTask.getResult();
        if (str == null)
          return Task.forResult(null);
        return ParseRESTSessionCommand.getCurrentSessionCommand(str).executeAsync().cast();
      }
    }).onSuccess(new Continuation()
    {
      public ParseSession then(Task<JSONObject> paramTask)
        throws Exception
      {
        JSONObject localJSONObject = (JSONObject)paramTask.getResult();
        if (localJSONObject == null)
          return null;
        return (ParseSession)ParseObject.fromJSON(localJSONObject, "_Session", true);
      }
    });
  }

  public static void getCurrentSessionInBackground(GetCallback<ParseSession> paramGetCallback)
  {
    Parse.callbackOnMainThreadAsync(getCurrentSessionInBackground(), paramGetCallback);
  }

  public static ParseQuery<ParseSession> getQuery()
  {
    return ParseQuery.getQuery(ParseSession.class);
  }

  public String getSessionToken()
  {
    return getString("sessionToken");
  }

  boolean isKeyMutable(String paramString)
  {
    return !READ_ONLY_KEYS.contains(paramString);
  }

  boolean needsDefaultACL()
  {
    return false;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseSession
 * JD-Core Version:    0.6.0
 */