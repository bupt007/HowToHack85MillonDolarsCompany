package com.parse;

public abstract interface CountCallback
{
  public abstract void done(int paramInt, ParseException paramParseException);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.CountCallback
 * JD-Core Version:    0.6.0
 */