package com.parse;

abstract interface CustomReportDataSupplier
{
  public abstract String getCustomData(Throwable paramThrowable);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.CustomReportDataSupplier
 * JD-Core Version:    0.6.0
 */