package com.parse;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;
import android.util.Pair;
import bolts.Capture;
import bolts.Continuation;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import org.json.JSONException;
import org.json.JSONObject;

class OfflineStore
{
  private static final int MAX_SQL_VARIABLES = 999;
  private static OfflineStore defaultInstance;
  private static final Object defaultInstanceLock = new Object();
  private final WeakValueHashMap<Pair<String, String>, ParseObject> classNameAndObjectIdToObjectMap = new WeakValueHashMap();
  private final WeakHashMap<ParseObject, Task<ParseObject>> fetchedObjects = new WeakHashMap();
  private final OfflineSQLiteOpenHelper helper;
  private final Object lock = new Object();
  private final WeakHashMap<ParseObject, Task<String>> objectToUuidMap = new WeakHashMap();
  private final WeakValueHashMap<String, ParseObject> uuidToObjectMap = new WeakValueHashMap();

  static
  {
    defaultInstance = null;
  }

  private OfflineStore(Context paramContext)
  {
    this.helper = new OfflineSQLiteOpenHelper(paramContext);
  }

  private Task<Void> deleteDataForObjectAsync(ParseObject paramParseObject, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    Capture localCapture = new Capture();
    synchronized (this.lock)
    {
      Task localTask1 = (Task)this.objectToUuidMap.get(paramParseObject);
      if (localTask1 == null)
      {
        Task localTask2 = Task.forResult(null);
        return localTask2;
      }
      return localTask1.onSuccessTask(new Continuation(localCapture)
      {
        public Task<String> then(Task<String> paramTask)
          throws Exception
        {
          this.val$uuid.set(paramTask.getResult());
          return paramTask;
        }
      }).onSuccessTask(new Continuation(localCapture, paramParseSQLiteDatabase)
      {
        public Task<Cursor> then(Task<String> paramTask)
          throws Exception
        {
          String[] arrayOfString1 = { "key" };
          String[] arrayOfString2 = new String[1];
          arrayOfString2[0] = ((String)this.val$uuid.get());
          return this.val$db.queryAsync("Dependencies", arrayOfString1, "uuid=?", arrayOfString2);
        }
      }).onSuccessTask(new Continuation(paramParseSQLiteDatabase, paramParseObject)
      {
        public Task<Void> then(Task<Cursor> paramTask)
          throws Exception
        {
          Cursor localCursor = (Cursor)paramTask.getResult();
          ArrayList localArrayList1 = new ArrayList();
          localCursor.moveToFirst();
          while (!localCursor.isAfterLast())
          {
            localArrayList1.add(localCursor.getString(0));
            localCursor.moveToNext();
          }
          localCursor.close();
          ArrayList localArrayList2 = new ArrayList();
          Iterator localIterator = localArrayList1.iterator();
          while (localIterator.hasNext())
          {
            String str = (String)localIterator.next();
            localArrayList2.add(OfflineStore.this.getPointerAsync(str, this.val$db).onSuccessTask(new Continuation()
            {
              public Task<ParsePin> then(Task<ParseObject> paramTask)
                throws Exception
              {
                ParsePin localParsePin = (ParsePin)paramTask.getResult();
                return OfflineStore.this.fetchLocallyAsync(localParsePin, OfflineStore.38.this.val$db);
              }
            }).continueWithTask(new Continuation(str)
            {
              public Task<Void> then(Task<ParsePin> paramTask)
                throws Exception
              {
                ParsePin localParsePin = (ParsePin)paramTask.getResult();
                List localList = localParsePin.getObjects();
                if ((localList == null) || (!localList.contains(OfflineStore.38.this.val$object)))
                  return paramTask.makeVoid();
                localList.remove(OfflineStore.38.this.val$object);
                if (localList.size() == 0)
                  return OfflineStore.this.unpinAsync(this.val$uuid, OfflineStore.38.this.val$db);
                localParsePin.setObjects(localList);
                return OfflineStore.this.saveLocallyAsync(localParsePin, true, OfflineStore.38.this.val$db);
              }
            }));
          }
          return Task.whenAll(localArrayList2);
        }
      }).onSuccessTask(new Continuation(localCapture, paramParseSQLiteDatabase)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          String[] arrayOfString = new String[1];
          arrayOfString[0] = ((String)this.val$uuid.get());
          return this.val$db.deleteAsync("Dependencies", "uuid=?", arrayOfString);
        }
      }).onSuccessTask(new Continuation(localCapture, paramParseSQLiteDatabase)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          String[] arrayOfString = new String[1];
          arrayOfString[0] = ((String)this.val$uuid.get());
          return this.val$db.deleteAsync("ParseObjects", "uuid=?", arrayOfString);
        }
      }).onSuccessTask(new Continuation(paramParseObject)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          synchronized (OfflineStore.this.lock)
          {
            String str = this.val$object.getObjectId();
            if (str != null)
              OfflineStore.this.classNameAndObjectIdToObjectMap.remove(Pair.create(this.val$object.getClassName(), str));
            OfflineStore.this.fetchedObjects.remove(this.val$object);
            return paramTask;
          }
        }
      });
    }
  }

  private Task<Void> deleteObjects(List<String> paramList, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    if (paramList.size() <= 0)
      return Task.forResult(null);
    if (paramList.size() > 999)
      return deleteObjects(paramList.subList(0, 999), paramParseSQLiteDatabase).onSuccessTask(new Continuation(paramList, paramParseSQLiteDatabase)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return OfflineStore.this.deleteObjects(this.val$uuids.subList(999, this.val$uuids.size()), this.val$db);
        }
      });
    String[] arrayOfString = new String[paramList.size()];
    for (int i = 0; i < arrayOfString.length; i++)
      arrayOfString[i] = "?";
    return paramParseSQLiteDatabase.deleteAsync("ParseObjects", "uuid IN (" + TextUtils.join(",", arrayOfString) + ")", (String[])paramList.toArray(new String[paramList.size()]));
  }

  static void disableOfflineStore()
  {
    synchronized (defaultInstanceLock)
    {
      defaultInstance = null;
      return;
    }
  }

  public static void enableOfflineStore(Context paramContext)
  {
    synchronized (defaultInstanceLock)
    {
      if (defaultInstance == null)
      {
        defaultInstance = new OfflineStore(paramContext);
        return;
      }
      throw new RuntimeException("enableOfflineStore() called multiple times.");
    }
  }

  private <T extends ParseObject> Task<List<T>> findAsync(ParseQuery<T> paramParseQuery, ParseUser paramParseUser, ParsePin paramParsePin, boolean paramBoolean)
  {
    return this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation(paramParseQuery, paramParseUser, paramParsePin, paramBoolean)
    {
      public Task<List<T>> then(Task<ParseSQLiteDatabase> paramTask)
        throws Exception
      {
        ParseSQLiteDatabase localParseSQLiteDatabase = (ParseSQLiteDatabase)paramTask.getResult();
        return OfflineStore.this.findAsync(this.val$query, this.val$user, this.val$pin, this.val$isCount, localParseSQLiteDatabase).continueWithTask(new Continuation(localParseSQLiteDatabase)
        {
          public Task<List<T>> then(Task<List<T>> paramTask)
            throws Exception
          {
            this.val$db.closeAsync();
            return paramTask;
          }
        });
      }
    });
  }

  private <T extends ParseObject> Task<List<T>> findAsync(ParseQuery<T> paramParseQuery, ParseUser paramParseUser, ParsePin paramParsePin, boolean paramBoolean, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    boolean bool = paramParseQuery.includeIsDeletingEventually;
    OfflineQueryLogic localOfflineQueryLogic = new OfflineQueryLogic(this);
    ArrayList localArrayList = new ArrayList();
    String[] arrayOfString1;
    String str;
    String[] arrayOfString2;
    if (paramParsePin == null)
    {
      arrayOfString1 = new String[] { "uuid" };
      str = "className=?";
      if (!bool)
        str = str + " AND isDeletingEventually=0";
      arrayOfString2 = new String[1];
      arrayOfString2[0] = paramParseQuery.getClassName();
    }
    Task localTask2;
    for (Task localTask1 = paramParseSQLiteDatabase.queryAsync("ParseObjects", arrayOfString1, str, arrayOfString2); ; localTask1 = localTask2.onSuccessTask(new Continuation(bool, paramParseQuery, paramParseSQLiteDatabase)
    {
      public Task<Cursor> then(Task<String> paramTask)
        throws Exception
      {
        String str1 = (String)paramTask.getResult();
        String[] arrayOfString1 = { "A.uuid" };
        String str2 = "className=? AND key=?";
        if (!this.val$includeIsDeletingEventually)
          str2 = str2 + " AND isDeletingEventually=0";
        String[] arrayOfString2 = new String[2];
        arrayOfString2[0] = this.val$query.getClassName();
        arrayOfString2[1] = str1;
        return this.val$db.queryAsync("ParseObjects A  INNER JOIN Dependencies B  ON A.uuid=B.uuid", arrayOfString1, str2, arrayOfString2);
      }
    }))
    {
      8 local8 = new Continuation(localOfflineQueryLogic, paramParseQuery, paramParseUser, paramParseSQLiteDatabase, localArrayList)
      {
        public Task<Void> then(Task<Cursor> paramTask)
          throws Exception
        {
          Cursor localCursor = (Cursor)paramTask.getResult();
          ArrayList localArrayList = new ArrayList();
          localCursor.moveToFirst();
          while (!localCursor.isAfterLast())
          {
            localArrayList.add(localCursor.getString(0));
            localCursor.moveToNext();
          }
          localCursor.close();
          OfflineQueryLogic.ConstraintMatcher localConstraintMatcher = this.val$queryLogic.createMatcher(this.val$query, this.val$user);
          Task localTask = Task.forResult(null);
          Iterator localIterator = localArrayList.iterator();
          while (localIterator.hasNext())
          {
            String str = (String)localIterator.next();
            Capture localCapture = new Capture();
            localTask = localTask.onSuccessTask(new Continuation(str)
            {
              public Task<T> then(Task<Void> paramTask)
                throws Exception
              {
                return OfflineStore.this.getPointerAsync(this.val$uuid, OfflineStore.8.this.val$db);
              }
            }).onSuccessTask(new Continuation(localCapture)
            {
              public Task<T> then(Task<T> paramTask)
                throws Exception
              {
                this.val$object.set(paramTask.getResult());
                return OfflineStore.this.fetchLocallyAsync((ParseObject)this.val$object.get(), OfflineStore.8.this.val$db);
              }
            }).onSuccessTask(new Continuation(localCapture, localConstraintMatcher)
            {
              public Task<Boolean> then(Task<T> paramTask)
                throws Exception
              {
                if (!((ParseObject)this.val$object.get()).isDataAvailable())
                  return Task.forResult(Boolean.valueOf(false));
                return this.val$matcher.matchesAsync((ParseObject)this.val$object.get(), OfflineStore.8.this.val$db);
              }
            }).onSuccess(new Continuation(localCapture)
            {
              public Void then(Task<Boolean> paramTask)
              {
                if (((Boolean)paramTask.getResult()).booleanValue())
                  OfflineStore.8.this.val$results.add(this.val$object.get());
                return null;
              }
            });
          }
          return localTask;
        }
      };
      return localTask1.onSuccessTask(local8).onSuccessTask(new Continuation(localOfflineQueryLogic, localArrayList, paramParseQuery, paramBoolean, paramParseSQLiteDatabase)
      {
        public Task<List<T>> then(Task<Void> paramTask)
          throws Exception
        {
          this.val$queryLogic.sort(this.val$results, this.val$query);
          List localList = this.val$results;
          int i = this.val$query.getSkip();
          if ((!this.val$isCount) && (i >= 0))
            localList = localList.subList(Math.min(this.val$query.getSkip(), localList.size()), localList.size());
          int j = this.val$query.getLimit();
          if ((!this.val$isCount) && (j >= 0) && (localList.size() > j))
            localList = localList.subList(0, j);
          Task localTask = Task.forResult(null);
          Iterator localIterator = localList.iterator();
          while (localIterator.hasNext())
            localTask = localTask.onSuccessTask(new Continuation((ParseObject)localIterator.next())
            {
              public Task<Void> then(Task<Void> paramTask)
                throws Exception
              {
                return OfflineStore.7.this.val$queryLogic.fetchIncludes(this.val$object, OfflineStore.7.this.val$query, OfflineStore.7.this.val$db);
              }
            });
          return localTask.onSuccess(new Continuation(localList)
          {
            public List<T> then(Task<Void> paramTask)
              throws Exception
            {
              return this.val$finalTrimmedResults;
            }
          });
        }
      });
      localTask2 = (Task)this.objectToUuidMap.get(paramParsePin);
      if (localTask2 == null)
        return Task.forResult(localArrayList);
    }
  }

  public static OfflineStore getCurrent()
  {
    synchronized (defaultInstanceLock)
    {
      OfflineStore localOfflineStore = defaultInstance;
      return localOfflineStore;
    }
  }

  private Task<String> getOrCreateUUIDAsync(ParseObject paramParseObject, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    String str = UUID.randomUUID().toString();
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    synchronized (this.lock)
    {
      Task localTask = (Task)this.objectToUuidMap.get(paramParseObject);
      if (localTask != null)
        return localTask;
      this.objectToUuidMap.put(paramParseObject, localTaskCompletionSource.getTask());
      this.uuidToObjectMap.put(str, paramParseObject);
      this.fetchedObjects.put(paramParseObject, localTaskCompletionSource.getTask().onSuccess(new Continuation(paramParseObject)
      {
        public ParseObject then(Task<String> paramTask)
          throws Exception
        {
          return this.val$object;
        }
      }));
      ContentValues localContentValues = new ContentValues();
      localContentValues.put("uuid", str);
      localContentValues.put("className", paramParseObject.getClassName());
      paramParseSQLiteDatabase.insertOrThrowAsync("ParseObjects", localContentValues).continueWith(new Continuation(localTaskCompletionSource, str)
      {
        public Void then(Task<Void> paramTask)
          throws Exception
        {
          this.val$tcs.setResult(this.val$newUUID);
          return null;
        }
      });
      return localTaskCompletionSource.getTask();
    }
  }

  private <T extends ParseObject> Task<T> getPointerAsync(String paramString, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    synchronized (this.lock)
    {
      ParseObject localParseObject = (ParseObject)this.uuidToObjectMap.get(paramString);
      if (localParseObject != null)
      {
        Task localTask = Task.forResult(localParseObject);
        return localTask;
      }
      return paramParseSQLiteDatabase.queryAsync("ParseObjects", new String[] { "className", "objectId" }, "uuid = ?", new String[] { paramString }).onSuccess(new Continuation(paramString)
      {
        public T then(Task<Cursor> paramTask)
          throws Exception
        {
          Cursor localCursor = (Cursor)paramTask.getResult();
          localCursor.moveToFirst();
          if (localCursor.isAfterLast())
          {
            localCursor.close();
            throw new IllegalStateException("Attempted to find non-existent uuid " + this.val$uuid);
          }
          synchronized (OfflineStore.this.lock)
          {
            ParseObject localParseObject1 = (ParseObject)OfflineStore.this.uuidToObjectMap.get(this.val$uuid);
            if (localParseObject1 != null)
              return localParseObject1;
            String str1 = localCursor.getString(0);
            String str2 = localCursor.getString(1);
            localCursor.close();
            ParseObject localParseObject2 = ParseObject.createWithoutData(str1, str2);
            if (str2 == null)
            {
              OfflineStore.this.uuidToObjectMap.put(this.val$uuid, localParseObject2);
              OfflineStore.this.objectToUuidMap.put(localParseObject2, Task.forResult(this.val$uuid));
            }
            return localParseObject2;
          }
        }
      });
    }
  }

  public static boolean isEnabled()
  {
    while (true)
    {
      synchronized (defaultInstanceLock)
      {
        if (defaultInstance != null)
        {
          i = 1;
          return i;
        }
      }
      int i = 0;
    }
  }

  private Task<Void> saveLocallyAsync(ParseObject paramParseObject, List<ParseObject> paramList, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    if (paramList != null);
    ArrayList localArrayList2;
    for (ArrayList localArrayList1 = new ArrayList(paramList); ; localArrayList1 = new ArrayList())
    {
      if (!localArrayList1.contains(paramParseObject))
        localArrayList1.add(paramParseObject);
      localArrayList2 = new ArrayList();
      Iterator localIterator = localArrayList1.iterator();
      while (localIterator.hasNext())
        localArrayList2.add(fetchLocallyAsync((ParseObject)localIterator.next(), paramParseSQLiteDatabase).makeVoid());
    }
    return Task.whenAll(localArrayList2).continueWithTask(new Continuation(paramParseObject)
    {
      public Task<String> then(Task<Void> paramTask)
        throws Exception
      {
        return (Task)OfflineStore.this.objectToUuidMap.get(this.val$object);
      }
    }).onSuccessTask(new Continuation(paramParseSQLiteDatabase)
    {
      public Task<Void> then(Task<String> paramTask)
        throws Exception
      {
        String str = (String)paramTask.getResult();
        if (str == null)
          return null;
        return OfflineStore.this.unpinAsync(str, this.val$db);
      }
    }).onSuccessTask(new Continuation(paramParseObject, paramParseSQLiteDatabase)
    {
      public Task<String> then(Task<Void> paramTask)
        throws Exception
      {
        return OfflineStore.this.getOrCreateUUIDAsync(this.val$object, this.val$db);
      }
    }).onSuccessTask(new Continuation(localArrayList1, paramParseSQLiteDatabase)
    {
      public Task<Void> then(Task<String> paramTask)
        throws Exception
      {
        String str = (String)paramTask.getResult();
        ArrayList localArrayList = new ArrayList();
        Iterator localIterator = this.val$objects.iterator();
        while (localIterator.hasNext())
        {
          ParseObject localParseObject = (ParseObject)localIterator.next();
          localArrayList.add(OfflineStore.this.saveLocallyAsync(str, localParseObject, this.val$db));
        }
        return Task.whenAll(localArrayList);
      }
    });
  }

  private Task<Void> saveLocallyAsync(ParseObject paramParseObject, boolean paramBoolean, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    ArrayList localArrayList = new ArrayList();
    if (!paramBoolean)
      localArrayList.add(paramParseObject);
    while (true)
    {
      return saveLocallyAsync(paramParseObject, localArrayList, paramParseSQLiteDatabase);
      new ParseTraverser(localArrayList)
      {
        protected boolean visit(Object paramObject)
        {
          if ((paramObject instanceof ParseObject))
            this.val$objectsInTree.add((ParseObject)paramObject);
          return true;
        }
      }
      .setYieldRoot(true).setTraverseParseObjects(true).traverse(paramParseObject);
    }
  }

  private Task<Void> saveLocallyAsync(String paramString, ParseObject paramParseObject, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    if ((paramParseObject.getObjectId() != null) && (!paramParseObject.isDataAvailable()) && (!paramParseObject.hasChanges()) && (!paramParseObject.hasOutstandingOperations()))
      return Task.forResult(null);
    Capture localCapture1 = new Capture();
    Capture localCapture2 = new Capture();
    return getOrCreateUUIDAsync(paramParseObject, paramParseSQLiteDatabase).onSuccessTask(new Continuation(localCapture1, paramParseSQLiteDatabase, localCapture2, paramParseObject)
    {
      public Task<Void> then(Task<String> paramTask)
        throws Exception
      {
        this.val$uuid.set(paramTask.getResult());
        OfflineStore.OfflineEncodingStrategy localOfflineEncodingStrategy = new OfflineStore.OfflineEncodingStrategy(OfflineStore.this, this.val$db);
        this.val$encoded.set(this.val$object.toRest(localOfflineEncodingStrategy));
        return localOfflineEncodingStrategy.whenFinished();
      }
    }).onSuccessTask(new Continuation(paramParseObject, localCapture2, localCapture1, paramParseSQLiteDatabase)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        String str1 = this.val$object.getClassName();
        String str2 = this.val$object.getObjectId();
        String str3 = this.val$encoded.get().toString();
        ContentValues localContentValues = new ContentValues();
        localContentValues.put("className", str1);
        localContentValues.put("json", str3);
        if (str2 != null)
          localContentValues.put("objectId", str2);
        String[] arrayOfString = new String[1];
        arrayOfString[0] = ((String)this.val$uuid.get());
        return this.val$db.updateAsync("ParseObjects", localContentValues, "uuid = ?", arrayOfString).makeVoid();
      }
    }).onSuccessTask(new Continuation(paramString, localCapture1, paramParseSQLiteDatabase)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        ContentValues localContentValues = new ContentValues();
        localContentValues.put("key", this.val$key);
        localContentValues.put("uuid", (String)this.val$uuid.get());
        return this.val$db.insertWithOnConflict("Dependencies", localContentValues, 4);
      }
    });
  }

  private Task<Void> unpinAsync(String paramString)
  {
    return this.helper.getWritableDatabaseAsync().onSuccessTask(new Continuation(paramString)
    {
      public Task<Void> then(Task<ParseSQLiteDatabase> paramTask)
        throws Exception
      {
        ParseSQLiteDatabase localParseSQLiteDatabase = (ParseSQLiteDatabase)paramTask.getResult();
        return localParseSQLiteDatabase.beginTransactionAsync().onSuccessTask(new Continuation(localParseSQLiteDatabase)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return OfflineStore.this.unpinAsync(OfflineStore.27.this.val$key, this.val$db).onSuccessTask(new Continuation()
            {
              public Task<Void> then(Task<Void> paramTask)
                throws Exception
              {
                return OfflineStore.27.1.this.val$db.setTransactionSuccessfulAsync();
              }
            }).continueWithTask(new Continuation()
            {
              public Task<Void> then(Task<Void> paramTask)
                throws Exception
              {
                OfflineStore.27.1.this.val$db.endTransactionAsync();
                OfflineStore.27.1.this.val$db.closeAsync();
                return paramTask;
              }
            });
          }
        });
      }
    });
  }

  private Task<Void> unpinAsync(String paramString, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    LinkedList localLinkedList = new LinkedList();
    return Task.forResult((Void)null).continueWithTask(new Continuation(paramString, paramParseSQLiteDatabase)
    {
      public Task<Cursor> then(Task<Void> paramTask)
        throws Exception
      {
        String[] arrayOfString = new String[1];
        arrayOfString[0] = this.val$key;
        return this.val$db.rawQueryAsync("SELECT uuid FROM Dependencies WHERE key=? AND uuid IN ( SELECT uuid FROM Dependencies GROUP BY uuid HAVING COUNT(uuid)=1)", arrayOfString);
      }
    }).onSuccessTask(new Continuation(localLinkedList, paramParseSQLiteDatabase)
    {
      public Task<Void> then(Task<Cursor> paramTask)
        throws Exception
      {
        Cursor localCursor = (Cursor)paramTask.getResult();
        while (localCursor.moveToNext())
          this.val$uuidsToDelete.add(localCursor.getString(0));
        localCursor.close();
        return OfflineStore.this.deleteObjects(this.val$uuidsToDelete, this.val$db);
      }
    }).onSuccessTask(new Continuation(paramString, paramParseSQLiteDatabase)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        String[] arrayOfString = new String[1];
        arrayOfString[0] = this.val$key;
        return this.val$db.deleteAsync("Dependencies", "key=?", arrayOfString);
      }
    }).onSuccess(new Continuation(localLinkedList)
    {
      public Void then(Task<Void> paramTask)
        throws Exception
      {
        synchronized (OfflineStore.this.lock)
        {
          Iterator localIterator = this.val$uuidsToDelete.iterator();
          while (localIterator.hasNext())
          {
            String str = (String)localIterator.next();
            ParseObject localParseObject = (ParseObject)OfflineStore.this.uuidToObjectMap.get(str);
            if (localParseObject == null)
              continue;
            OfflineStore.this.objectToUuidMap.remove(localParseObject);
            OfflineStore.this.uuidToObjectMap.remove(str);
          }
        }
        monitorexit;
        return null;
      }
    });
  }

  private Task<Void> updateDataForObjectAsync(ParseObject paramParseObject, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    Capture localCapture1 = new Capture();
    Capture localCapture2 = new Capture();
    synchronized (this.lock)
    {
      Task localTask1 = (Task)this.objectToUuidMap.get(paramParseObject);
      if (localTask1 == null)
      {
        Task localTask2 = Task.forResult(null);
        return localTask2;
      }
      return localTask1.onSuccessTask(new Continuation(localCapture1, paramParseSQLiteDatabase, localCapture2, paramParseObject)
      {
        public Task<Void> then(Task<String> paramTask)
          throws Exception
        {
          this.val$uuid.set(paramTask.getResult());
          OfflineStore.OfflineEncodingStrategy localOfflineEncodingStrategy = new OfflineStore.OfflineEncodingStrategy(OfflineStore.this, this.val$db);
          this.val$jsonObject.set(this.val$object.toRest(localOfflineEncodingStrategy));
          return localOfflineEncodingStrategy.whenFinished();
        }
      }).onSuccessTask(new Continuation(paramParseObject, localCapture2, localCapture1, paramParseSQLiteDatabase)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          String str1 = this.val$object.getClassName();
          String str2 = this.val$object.getObjectId();
          String str3 = ((JSONObject)this.val$jsonObject.get()).toString();
          int i = ((JSONObject)this.val$jsonObject.get()).getInt("isDeletingEventually");
          ContentValues localContentValues = new ContentValues();
          localContentValues.put("className", str1);
          localContentValues.put("json", str3);
          if (str2 != null)
            localContentValues.put("objectId", str2);
          localContentValues.put("isDeletingEventually", Integer.valueOf(i));
          String[] arrayOfString = new String[1];
          arrayOfString[0] = ((String)this.val$uuid.get());
          return this.val$db.updateAsync("ParseObjects", localContentValues, "uuid = ?", arrayOfString).makeVoid();
        }
      });
    }
  }

  void clearDatabase(Context paramContext)
  {
    this.helper.clearDatabase(paramContext);
  }

  <T extends ParseObject> Task<Integer> countAsync(ParseQuery<T> paramParseQuery, ParseUser paramParseUser, ParsePin paramParsePin)
  {
    return findAsync(paramParseQuery, paramParseUser, paramParsePin, true).onSuccess(new Continuation()
    {
      public Integer then(Task<List<T>> paramTask)
        throws Exception
      {
        return Integer.valueOf(((List)paramTask.getResult()).size());
      }
    });
  }

  Task<Void> deleteDataForObjectAsync(ParseObject paramParseObject)
  {
    return this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation(paramParseObject)
    {
      public Task<Void> then(Task<ParseSQLiteDatabase> paramTask)
        throws Exception
      {
        ParseSQLiteDatabase localParseSQLiteDatabase = (ParseSQLiteDatabase)paramTask.getResult();
        return localParseSQLiteDatabase.beginTransactionAsync().onSuccessTask(new Continuation(localParseSQLiteDatabase)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return OfflineStore.this.deleteDataForObjectAsync(OfflineStore.36.this.val$object, this.val$db).onSuccessTask(new Continuation()
            {
              public Task<Void> then(Task<Void> paramTask)
                throws Exception
              {
                return OfflineStore.36.1.this.val$db.setTransactionSuccessfulAsync();
              }
            }).continueWithTask(new Continuation()
            {
              public Task<Void> then(Task<Void> paramTask)
                throws Exception
              {
                OfflineStore.36.1.this.val$db.endTransactionAsync();
                OfflineStore.36.1.this.val$db.closeAsync();
                return paramTask;
              }
            });
          }
        });
      }
    });
  }

  <T extends ParseObject> Task<T> fetchLocallyAsync(T paramT)
  {
    return this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation(paramT)
    {
      public Task<T> then(Task<ParseSQLiteDatabase> paramTask)
        throws Exception
      {
        ParseSQLiteDatabase localParseSQLiteDatabase = (ParseSQLiteDatabase)paramTask.getResult();
        return OfflineStore.this.fetchLocallyAsync(this.val$object, localParseSQLiteDatabase).continueWithTask(new Continuation(localParseSQLiteDatabase)
        {
          public Task<T> then(Task<T> paramTask)
            throws Exception
          {
            this.val$db.closeAsync();
            return paramTask;
          }
        });
      }
    });
  }

  <T extends ParseObject> Task<T> fetchLocallyAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    while (true)
    {
      Task localTask1;
      String str1;
      String str2;
      synchronized (this.lock)
      {
        if (!this.fetchedObjects.containsKey(paramT))
          continue;
        Task localTask3 = (Task)this.fetchedObjects.get(paramT);
        return localTask3;
        this.fetchedObjects.put(paramT, localTaskCompletionSource.getTask());
        localTask1 = (Task)this.objectToUuidMap.get(paramT);
        str1 = paramT.getClassName();
        str2 = paramT.getObjectId();
        localTask2 = Task.forResult(null);
        if (str2 != null)
          break label194;
        if (localTask1 == null)
          return localTask2.onSuccessTask(new Continuation(paramParseSQLiteDatabase, paramT)
          {
            public Task<Void> then(Task<String> paramTask)
              throws Exception
            {
              String str = (String)paramTask.getResult();
              if (str == null)
                return Task.forError(new ParseException(120, "Attempted to fetch an object offline which was never saved to the offline cache."));
              try
              {
                JSONObject localJSONObject = new JSONObject(str);
                HashMap localHashMap = new HashMap();
                new ParseTraverser(localHashMap)
                {
                  protected boolean visit(Object paramObject)
                  {
                    if (((paramObject instanceof JSONObject)) && (((JSONObject)paramObject).optString("__type").equals("OfflineObject")))
                    {
                      String str = ((JSONObject)paramObject).optString("uuid");
                      this.val$offlineObjects.put(str, OfflineStore.this.getPointerAsync(str, OfflineStore.13.this.val$db));
                    }
                    return true;
                  }
                }
                .setTraverseParseObjects(false).setYieldRoot(false).traverse(localJSONObject);
                return Task.whenAll(localHashMap.values()).onSuccess(new Continuation(localJSONObject, localHashMap)
                {
                  public Void then(Task<Void> paramTask)
                    throws Exception
                  {
                    OfflineStore.13.this.val$object.mergeREST(this.val$json, new OfflineStore.OfflineDecoder(OfflineStore.this, this.val$offlineObjects, null));
                    return null;
                  }
                });
              }
              catch (JSONException localJSONException)
              {
              }
              return Task.forError(localJSONException);
            }
          }).continueWithTask(new Continuation(localTaskCompletionSource, paramT)
          {
            public Task<T> then(Task<Void> paramTask)
              throws Exception
            {
              if (paramTask.isCancelled())
                this.val$tcs.setCancelled();
              while (true)
              {
                return this.val$tcs.getTask();
                if (paramTask.isFaulted())
                {
                  this.val$tcs.setError(paramTask.getError());
                  continue;
                }
                this.val$tcs.setResult(this.val$object);
              }
            }
          });
      }
      String[] arrayOfString = { "json" };
      Capture localCapture = new Capture();
      Task localTask2 = localTask1.onSuccessTask(new Continuation(localCapture, paramParseSQLiteDatabase, arrayOfString)
      {
        public Task<Cursor> then(Task<String> paramTask)
          throws Exception
        {
          this.val$uuid.set(paramTask.getResult());
          String[] arrayOfString = new String[1];
          arrayOfString[0] = ((String)this.val$uuid.get());
          return this.val$db.queryAsync("ParseObjects", this.val$select, "uuid = ?", arrayOfString);
        }
      }).onSuccess(new Continuation(localCapture)
      {
        public String then(Task<Cursor> paramTask)
          throws Exception
        {
          Cursor localCursor = (Cursor)paramTask.getResult();
          localCursor.moveToFirst();
          if (localCursor.isAfterLast())
          {
            localCursor.close();
            throw new IllegalStateException("Attempted to find non-existent uuid " + (String)this.val$uuid.get());
          }
          String str = localCursor.getString(0);
          localCursor.close();
          return str;
        }
      });
      continue;
      label194: if (localTask1 != null)
      {
        localTaskCompletionSource.setError(new IllegalStateException("This object must have already been fetched from the local datastore, but isn't marked as fetched."));
        synchronized (this.lock)
        {
          this.fetchedObjects.remove(paramT);
          return localTaskCompletionSource.getTask();
        }
      }
      localTask2 = paramParseSQLiteDatabase.queryAsync("ParseObjects", new String[] { "json", "uuid" }, String.format("%s = ? AND %s = ?", new Object[] { "className", "objectId" }), new String[] { str1, str2 }).onSuccess(new Continuation(paramT)
      {
        public String then(Task<Cursor> paramTask)
          throws Exception
        {
          Cursor localCursor = (Cursor)paramTask.getResult();
          localCursor.moveToFirst();
          if (localCursor.isAfterLast())
          {
            localCursor.close();
            throw new ParseException(120, "This object is not available in the offline cache.");
          }
          String str1 = localCursor.getString(0);
          String str2 = localCursor.getString(1);
          localCursor.close();
          synchronized (OfflineStore.this.lock)
          {
            OfflineStore.this.objectToUuidMap.put(this.val$object, Task.forResult(str2));
            OfflineStore.this.uuidToObjectMap.put(str2, this.val$object);
            return str1;
          }
        }
      });
    }
  }

  <T extends ParseObject> Task<List<T>> findAsync(ParseQuery<T> paramParseQuery, ParseUser paramParseUser, ParsePin paramParsePin)
  {
    return findAsync(paramParseQuery, paramParseUser, paramParsePin, false);
  }

  <T extends ParseObject> Task<List<T>> findAsync(ParseQuery<T> paramParseQuery, ParseUser paramParseUser, ParsePin paramParsePin, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    return findAsync(paramParseQuery, paramParseUser, paramParsePin, false, paramParseSQLiteDatabase);
  }

  Pair<ParseObject, Boolean> getOrCreateObjectWithoutData(String paramString1, String paramString2)
  {
    if (paramString2 == null)
      throw new IllegalStateException("objectId cannot be null.");
    Pair localPair1 = Pair.create(paramString1, paramString2);
    synchronized (this.lock)
    {
      ParseObject localParseObject = (ParseObject)this.classNameAndObjectIdToObjectMap.get(localPair1);
      if (localParseObject != null)
      {
        Pair localPair2 = Pair.create(localParseObject, Boolean.valueOf(false));
        return localPair2;
      }
      Pair localPair3 = Pair.create(ParseObject.create(paramString1), Boolean.valueOf(true));
      return localPair3;
    }
  }

  void registerNewObject(ParseObject paramParseObject)
  {
    String str = paramParseObject.getObjectId();
    if (str != null)
    {
      Pair localPair = Pair.create(paramParseObject.getClassName(), str);
      this.classNameAndObjectIdToObjectMap.put(localPair, paramParseObject);
    }
  }

  Task<Void> saveLocallyAsync(ParseObject paramParseObject)
  {
    return this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation(paramParseObject)
    {
      public Task<Void> then(Task<ParseSQLiteDatabase> paramTask)
        throws Exception
      {
        ParseSQLiteDatabase localParseSQLiteDatabase = (ParseSQLiteDatabase)paramTask.getResult();
        return localParseSQLiteDatabase.beginTransactionAsync().onSuccessTask(new Continuation(localParseSQLiteDatabase)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return OfflineStore.this.saveLocallyAsync(OfflineStore.18.this.val$object, true, this.val$db);
          }
        }).onSuccessTask(new Continuation(localParseSQLiteDatabase)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return this.val$db.setTransactionSuccessfulAsync();
          }
        }).continueWithTask(new Continuation(localParseSQLiteDatabase)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            this.val$db.endTransactionAsync();
            this.val$db.closeAsync();
            return paramTask;
          }
        });
      }
    });
  }

  Task<Void> saveLocallyAsync(ParseObject paramParseObject, List<ParseObject> paramList)
  {
    return this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation(paramParseObject, paramList)
    {
      public Task<Void> then(Task<ParseSQLiteDatabase> paramTask)
        throws Exception
      {
        ParseSQLiteDatabase localParseSQLiteDatabase = (ParseSQLiteDatabase)paramTask.getResult();
        return localParseSQLiteDatabase.beginTransactionAsync().onSuccessTask(new Continuation(localParseSQLiteDatabase)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return OfflineStore.this.saveLocallyAsync(OfflineStore.19.this.val$object, OfflineStore.19.this.val$children, this.val$db);
          }
        }).onSuccessTask(new Continuation(localParseSQLiteDatabase)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return this.val$db.setTransactionSuccessfulAsync();
          }
        }).continueWithTask(new Continuation(localParseSQLiteDatabase)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            this.val$db.endTransactionAsync();
            this.val$db.closeAsync();
            return paramTask;
          }
        });
      }
    });
  }

  void simulateReboot()
  {
    synchronized (this.lock)
    {
      this.uuidToObjectMap.clear();
      this.objectToUuidMap.clear();
      this.classNameAndObjectIdToObjectMap.clear();
      this.fetchedObjects.clear();
      return;
    }
  }

  Task<Void> unpinAsync(ParseObject paramParseObject)
  {
    return Task.forResult(null).continueWithTask(new Continuation(paramParseObject)
    {
      public Task<String> then(Task<Void> paramTask)
        throws Exception
      {
        return (Task)OfflineStore.this.objectToUuidMap.get(this.val$object);
      }
    }).continueWithTask(new Continuation()
    {
      public Task<Void> then(Task<String> paramTask)
        throws Exception
      {
        String str = (String)paramTask.getResult();
        if (str == null)
          return Task.forResult(null);
        return OfflineStore.this.unpinAsync(str);
      }
    });
  }

  Task<Void> updateDataForObjectAsync(ParseObject paramParseObject)
  {
    synchronized (this.lock)
    {
      Task localTask1 = (Task)this.fetchedObjects.get(paramParseObject);
      if (localTask1 == null)
      {
        Task localTask2 = Task.forError(new IllegalStateException("An object cannot be updated if it wasn't fetched."));
        return localTask2;
      }
      return localTask1.continueWithTask(new Continuation(paramParseObject)
      {
        public Task<Void> then(Task<ParseObject> paramTask)
          throws Exception
        {
          if (paramTask.isFaulted())
          {
            if (((paramTask.getError() instanceof ParseException)) && (((ParseException)paramTask.getError()).getCode() == 120))
              return Task.forResult(null);
            return paramTask.makeVoid();
          }
          return OfflineStore.this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation()
          {
            public Task<Void> then(Task<ParseSQLiteDatabase> paramTask)
              throws Exception
            {
              ParseSQLiteDatabase localParseSQLiteDatabase = (ParseSQLiteDatabase)paramTask.getResult();
              return localParseSQLiteDatabase.beginTransactionAsync().onSuccessTask(new Continuation(localParseSQLiteDatabase)
              {
                public Task<Void> then(Task<Void> paramTask)
                  throws Exception
                {
                  return OfflineStore.this.updateDataForObjectAsync(OfflineStore.33.this.val$object, this.val$db).onSuccessTask(new Continuation()
                  {
                    public Task<Void> then(Task<Void> paramTask)
                      throws Exception
                    {
                      return OfflineStore.33.1.1.this.val$db.setTransactionSuccessfulAsync();
                    }
                  }).continueWithTask(new Continuation()
                  {
                    public Task<Void> then(Task<Void> paramTask)
                      throws Exception
                    {
                      OfflineStore.33.1.1.this.val$db.endTransactionAsync();
                      OfflineStore.33.1.1.this.val$db.closeAsync();
                      return paramTask;
                    }
                  });
                }
              });
            }
          });
        }
      });
    }
  }

  void updateObjectId(ParseObject paramParseObject, String paramString1, String paramString2)
  {
    if (paramString1 != null)
    {
      if (paramString1.equals(paramString2))
        return;
      throw new RuntimeException("objectIds cannot be changed in offline mode.");
    }
    Pair localPair = Pair.create(paramParseObject.getClassName(), paramString2);
    synchronized (this.lock)
    {
      ParseObject localParseObject = (ParseObject)this.classNameAndObjectIdToObjectMap.get(localPair);
      if ((localParseObject != null) && (localParseObject != paramParseObject))
        throw new RuntimeException("Attempted to change an objectId to one that's already known to the Offline Store.");
    }
    this.classNameAndObjectIdToObjectMap.put(localPair, paramParseObject);
    monitorexit;
  }

  private class OfflineDecoder extends ParseDecoder
  {
    private Map<String, Task<ParseObject>> offlineObjects;

    private OfflineDecoder()
    {
      Object localObject;
      this.offlineObjects = localObject;
    }

    public Object decode(Object paramObject)
    {
      if (((paramObject instanceof JSONObject)) && (((JSONObject)paramObject).optString("__type").equals("OfflineObject")))
      {
        String str = ((JSONObject)paramObject).optString("uuid");
        return ((Task)this.offlineObjects.get(str)).getResult();
      }
      return super.decode(paramObject);
    }
  }

  private class OfflineEncodingStrategy
    implements ParseObjectEncodingStrategy
  {
    private ParseSQLiteDatabase db;
    private ArrayList<Task<Void>> tasks = new ArrayList();
    private final Object tasksLock = new Object();

    public OfflineEncodingStrategy(ParseSQLiteDatabase arg2)
    {
      Object localObject;
      this.db = localObject;
    }

    public JSONObject encodeRelatedObject(ParseObject paramParseObject)
    {
      try
      {
        if (paramParseObject.getObjectId() != null)
        {
          JSONObject localJSONObject1 = new JSONObject();
          localJSONObject1.put("__type", "Pointer");
          localJSONObject1.put("objectId", paramParseObject.getObjectId());
          localJSONObject1.put("className", paramParseObject.getClassName());
          return localJSONObject1;
        }
        JSONObject localJSONObject2 = new JSONObject();
        localJSONObject2.put("__type", "OfflineObject");
        synchronized (this.tasksLock)
        {
          this.tasks.add(OfflineStore.this.getOrCreateUUIDAsync(paramParseObject, this.db).onSuccess(new Continuation(localJSONObject2)
          {
            public Void then(Task<String> paramTask)
              throws Exception
            {
              this.val$result.put("uuid", paramTask.getResult());
              return null;
            }
          }));
          return localJSONObject2;
        }
      }
      catch (JSONException localJSONException)
      {
      }
      throw new RuntimeException(localJSONException);
    }

    public Task<Void> whenFinished()
    {
      return Task.whenAll(this.tasks).continueWithTask(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          synchronized (OfflineStore.OfflineEncodingStrategy.this.tasksLock)
          {
            Iterator localIterator = OfflineStore.OfflineEncodingStrategy.this.tasks.iterator();
            while (localIterator.hasNext())
            {
              Task localTask2 = (Task)localIterator.next();
              if ((localTask2.isFaulted()) || (localTask2.isCancelled()))
                return localTask2;
            }
            OfflineStore.OfflineEncodingStrategy.this.tasks.clear();
            Task localTask1 = Task.forResult((Void)null);
            return localTask1;
          }
        }
      });
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.OfflineStore
 * JD-Core Version:    0.6.0
 */