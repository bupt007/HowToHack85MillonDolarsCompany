package com.parse;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build.VERSION;
import android.os.Bundle;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class ManifestInfo
{
  private static final int NUMBER_OF_PUSH_INTENTS = 3;
  private static final String TAG = "com.parse.ManifestInfo";
  private static String displayName;
  private static int iconId;
  private static long lastModified;
  private static final Object lock = new Object();
  private static PushType pushType;
  private static Boolean pushUsesBroadcastReceivers;
  static int versionCode;
  static String versionName;

  static
  {
    lastModified = -1L;
    versionCode = -1;
    versionName = null;
    iconId = 0;
    displayName = null;
    pushUsesBroadcastReceivers = null;
  }

  private static boolean checkReceiver(Class<? extends BroadcastReceiver> paramClass, String paramString, Intent[] paramArrayOfIntent)
  {
    ActivityInfo localActivityInfo = getReceiverInfo(paramClass);
    if (localActivityInfo == null);
    do
      return false;
    while ((paramString != null) && (!paramString.equals(localActivityInfo.permission)));
    int i = paramArrayOfIntent.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        break label82;
      Intent localIntent = paramArrayOfIntent[j];
      List localList = getPackageManager().queryBroadcastReceivers(localIntent, 0);
      if ((localList.isEmpty()) || (!checkResolveInfo(paramClass, localList)))
        break;
    }
    label82: return true;
  }

  private static boolean checkResolveInfo(Class<? extends BroadcastReceiver> paramClass, List<ResolveInfo> paramList)
  {
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      ResolveInfo localResolveInfo = (ResolveInfo)localIterator.next();
      if ((localResolveInfo.activityInfo != null) && (paramClass.getCanonicalName().equals(localResolveInfo.activityInfo.name)))
        return true;
    }
    return false;
  }

  private static boolean deviceSupportsGcm()
  {
    return (Build.VERSION.SDK_INT >= 8) && (getPackageInfo("com.google.android.gsf") != null);
  }

  private static ManifestCheckResult gcmSupportLevel()
  {
    if (getServiceInfo(PushService.class) == null)
      return ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS;
    String[] arrayOfString = new String[6];
    arrayOfString[0] = "android.permission.INTERNET";
    arrayOfString[1] = "android.permission.ACCESS_NETWORK_STATE";
    arrayOfString[2] = "android.permission.WAKE_LOCK";
    arrayOfString[3] = "android.permission.GET_ACCOUNTS";
    arrayOfString[4] = "com.google.android.c2dm.permission.RECEIVE";
    arrayOfString[5] = (getPackageName() + ".permission.C2D_MESSAGE");
    if (!hasPermissions(arrayOfString))
      return ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS;
    String str = getPackageName();
    Intent[] arrayOfIntent = new Intent[2];
    arrayOfIntent[0] = new Intent("com.google.android.c2dm.intent.RECEIVE").setPackage(str).addCategory(str);
    arrayOfIntent[1] = new Intent("com.google.android.c2dm.intent.REGISTRATION").setPackage(str).addCategory(str);
    if (!checkReceiver(GcmBroadcastReceiver.class, "com.google.android.c2dm.permission.SEND", arrayOfIntent))
      return ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS;
    if (!hasPermissions(new String[] { "android.permission.VIBRATE" }))
      return ManifestCheckResult.MISSING_OPTIONAL_DECLARATIONS;
    return ManifestCheckResult.HAS_ALL_DECLARATIONS;
  }

  private static ApplicationInfo getApplicationInfo()
  {
    return getContext().getApplicationInfo();
  }

  private static ApplicationInfo getApplicationInfo(Context paramContext, int paramInt)
  {
    try
    {
      ApplicationInfo localApplicationInfo = getPackageManager(paramContext).getApplicationInfo(getPackageName(paramContext), paramInt);
      return localApplicationInfo;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
    }
    return null;
  }

  public static Bundle getApplicationMetadata(Context paramContext)
  {
    ApplicationInfo localApplicationInfo = getApplicationInfo(paramContext, 128);
    if (localApplicationInfo != null)
      return localApplicationInfo.metaData;
    return null;
  }

  private static Context getContext()
  {
    return Parse.getApplicationContext();
  }

  public static String getDisplayName()
  {
    synchronized (lock)
    {
      if (displayName == null)
        displayName = getPackageManager().getApplicationLabel(getApplicationInfo()).toString();
      return displayName;
    }
  }

  private static String getGcmManifestMessage()
  {
    String str = getPackageName() + ".permission.C2D_MESSAGE";
    return "make sure that these permissions are declared as children of the root <manifest> element:\n\n<uses-permission android:name=\"android.permission.INTERNET\" />\n<uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\" />\n<uses-permission android:name=\"android.permission.VIBRATE\" />\n<uses-permission android:name=\"android.permission.WAKE_LOCK\" />\n<uses-permission android:name=\"android.permission.GET_ACCOUNTS\" />\n<uses-permission android:name=\"com.google.android.c2dm.permission.RECEIVE\" />\n<permission android:name=\"" + str + "\" " + "android:protectionLevel=\"signature\" />\n" + "<uses-permission android:name=\"" + str + "\" />\n" + "\n" + "Also, please make sure that these services and broadcast receivers are declared as " + "children of the <application> element:\n" + "\n" + "<service android:name=\"com.parse.PushService\" />\n" + "<receiver android:name=\"com.parse.GcmBroadcastReceiver\" " + "android:permission=\"com.google.android.c2dm.permission.SEND\">\n" + "  <intent-filter>\n" + "    <action android:name=\"com.google.android.c2dm.intent.RECEIVE\" />\n" + "    <action android:name=\"com.google.android.c2dm.intent.REGISTRATION\" />\n" + "    <category android:name=\"" + getPackageName() + "\" />\n" + "  </intent-filter>\n" + "</receiver>\n";
  }

  public static int getIconId()
  {
    synchronized (lock)
    {
      if (iconId == 0)
        iconId = getApplicationInfo().icon;
      return iconId;
    }
  }

  static List<ResolveInfo> getIntentReceivers(String[] paramArrayOfString)
  {
    String str1 = getPackageName();
    ArrayList localArrayList = new ArrayList();
    int i = paramArrayOfString.length;
    for (int j = 0; j < i; j++)
    {
      String str2 = paramArrayOfString[j];
      localArrayList.addAll(getPackageManager().queryBroadcastReceivers(new Intent(str2), 32));
    }
    for (int k = -1 + localArrayList.size(); k >= 0; k--)
    {
      if (((ResolveInfo)localArrayList.get(k)).activityInfo.packageName.equals(str1))
        continue;
      localArrayList.remove(k);
    }
    return localArrayList;
  }

  public static long getLastModified()
  {
    synchronized (lock)
    {
      if (lastModified == -1L)
        lastModified = new File(getApplicationInfo().sourceDir).lastModified();
      return lastModified;
    }
  }

  public static String getNonePushTypeLogMessage()
  {
    synchronized (lock)
    {
      if (pushType == PushType.NONE)
      {
        String str = "Push is not configured for this app because the app manifest is missing required declarations. Please add the following declarations to your app manifest to support either GCM or PPNS for push (or both). To enable GCM support, please " + getGcmManifestMessage() + "To enable PPNS support, please " + getPpnsManifestMessage();
        return str;
      }
      return "";
    }
  }

  private static PackageInfo getPackageInfo(String paramString)
  {
    try
    {
      PackageInfo localPackageInfo = getPackageManager().getPackageInfo(paramString, 0);
      return localPackageInfo;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
    }
    return null;
  }

  private static PackageManager getPackageManager()
  {
    return getPackageManager(getContext());
  }

  private static PackageManager getPackageManager(Context paramContext)
  {
    return paramContext.getPackageManager();
  }

  private static String getPackageName()
  {
    return getPackageName(getContext());
  }

  private static String getPackageName(Context paramContext)
  {
    return paramContext.getPackageName();
  }

  private static String getPpnsManifestMessage()
  {
    return "make sure that these permissions are declared as children of the root <manifest> element:\n\n<uses-permission android:name=\"android.permission.INTERNET\" />\n<uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\" />\n<uses-permission android:name=\"android.permission.RECEIVE_BOOT_COMPLETED\" />\n<uses-permission android:name=\"android.permission.VIBRATE\" />\n<uses-permission android:name=\"android.permission.WAKE_LOCK\" />\n\nAlso, please make sure that these services and broadcast receivers are declared as children of the <application> element:\n\n<service android:name=\"com.parse.PushService\" />\n<receiver android:name=\"com.parse.ParseBroadcastReceiver\">\n  <intent-filter>\n    <action android:name=\"android.intent.action.BOOT_COMPLETED\" />\n    <action android:name=\"android.intent.action.USER_PRESENT\" />\n  </intent-filter>\n</receiver>\n";
  }

  public static PushType getPushType()
  {
    while (true)
    {
      ManifestCheckResult localManifestCheckResult2;
      synchronized (lock)
      {
        if (pushType != null)
          continue;
        boolean bool1 = deviceSupportsGcm();
        boolean bool2 = hasAnyGcmSpecificDeclaration();
        ManifestCheckResult localManifestCheckResult1 = gcmSupportLevel();
        localManifestCheckResult2 = ppnsSupportLevel();
        if ((!bool1) || (localManifestCheckResult1 == ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS))
          continue;
        pushType = PushType.GCM;
        if (Parse.getLogLevel() > 5)
          continue;
        if ((pushType != PushType.GCM) || (localManifestCheckResult1 != ManifestCheckResult.MISSING_OPTIONAL_DECLARATIONS))
          break label271;
        Parse.logW("com.parse.ManifestInfo", "Using GCM for push, but the app manifest is missing some optional declarations that should be added for maximum reliability. Please " + getGcmManifestMessage());
        if ((Parse.getLogLevel() > 6) || (pushType != PushType.NONE) || (!bool2))
          continue;
        if (bool1)
          continue;
        Parse.logE("com.parse.ManifestInfo", "Cannot use GCM for push on this device because Google Play Services is not installed. Install Google Play Service from the Play Store, or enable PPNS as a fallback push service. To enable PPNS as a fallback push service on devices without Google Play support, please " + getPpnsManifestMessage());
        if (localManifestCheckResult1 == ManifestCheckResult.HAS_ALL_DECLARATIONS)
          continue;
        Parse.logE("com.parse.ManifestInfo", "Cannot use GCM for push because the app manifest is missing some required declarations. Please " + getGcmManifestMessage());
        if (Parse.getLogLevel() > 2)
          continue;
        Parse.logV("com.parse.ManifestInfo", "Using " + pushType + " for push.");
        return pushType;
        if (((!bool2) || (!bool1)) && (localManifestCheckResult2 != ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS))
          pushType = PushType.PPNS;
      }
      pushType = PushType.NONE;
      continue;
      label271: if ((pushType != PushType.PPNS) || (localManifestCheckResult2 != ManifestCheckResult.MISSING_OPTIONAL_DECLARATIONS))
        continue;
      Parse.logW("com.parse.ManifestInfo", "Using PPNS for push, but the app manifest is missing some optional declarations that should be added for maximum reliability. Please " + getPpnsManifestMessage());
    }
  }

  static boolean getPushUsesBroadcastReceivers()
  {
    if (pushUsesBroadcastReceivers != null)
      return pushUsesBroadcastReceivers.booleanValue();
    boolean bool1 = hasIntentReceiver("com.parse.push.intent.RECEIVE");
    int i = 0;
    if (bool1)
      i = 0 + 1;
    if (hasIntentReceiver("com.parse.push.intent.OPEN"))
      i++;
    if (hasIntentReceiver("com.parse.push.intent.DELETE"))
      i++;
    if ((i != 0) && (i != 3))
      throw new SecurityException("The Parse Push BroadcastReceiver must implement a filter for all of com.parse.push.intent.RECEIVE, com.parse.push.intent.OPEN, and com.parse.push.intent.DELETE");
    if (i == 3);
    for (boolean bool2 = true; ; bool2 = false)
    {
      pushUsesBroadcastReceivers = Boolean.valueOf(bool2);
      return pushUsesBroadcastReceivers.booleanValue();
    }
  }

  private static ActivityInfo getReceiverInfo(Class<? extends BroadcastReceiver> paramClass)
  {
    try
    {
      ActivityInfo localActivityInfo = getPackageManager().getReceiverInfo(new ComponentName(getContext(), paramClass), 0);
      return localActivityInfo;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
    }
    return null;
  }

  private static ServiceInfo getServiceInfo(Class<? extends Service> paramClass)
  {
    try
    {
      ServiceInfo localServiceInfo = getPackageManager().getServiceInfo(new ComponentName(getContext(), paramClass), 0);
      return localServiceInfo;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
    }
    return null;
  }

  public static int getVersionCode()
  {
    synchronized (lock)
    {
      int i = versionCode;
      if (i == -1);
      try
      {
        versionCode = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        return versionCode;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        while (true)
          Parse.logE("com.parse.ManifestInfo", "Couldn't find info about own package", localNameNotFoundException);
      }
    }
  }

  public static String getVersionName()
  {
    synchronized (lock)
    {
      String str = versionName;
      if (str == null);
      try
      {
        versionName = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        return versionName;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        while (true)
          Parse.logE("com.parse.ManifestInfo", "Couldn't find info about own package", localNameNotFoundException);
      }
    }
  }

  private static boolean hasAnyGcmSpecificDeclaration()
  {
    if (!hasPermissions(new String[] { "com.google.android.c2dm.permission.RECEIVE" }))
    {
      String[] arrayOfString = new String[1];
      arrayOfString[0] = (getPackageName() + ".permission.C2D_MESSAGE");
      if (!hasPermissions(arrayOfString))
      {
        ActivityInfo localActivityInfo = getReceiverInfo(GcmBroadcastReceiver.class);
        i = 0;
        if (localActivityInfo == null)
          break label65;
      }
    }
    int i = 1;
    label65: return i;
  }

  static boolean hasIntentReceiver(String paramString)
  {
    return !getIntentReceivers(new String[] { paramString }).isEmpty();
  }

  private static boolean hasPermissions(String[] paramArrayOfString)
  {
    int i = paramArrayOfString.length;
    for (int j = 0; j < i; j++)
    {
      String str = paramArrayOfString[j];
      if (getPackageManager().checkPermission(str, getPackageName()) != 0)
        return false;
    }
    return true;
  }

  private static ManifestCheckResult ppnsSupportLevel()
  {
    if (getServiceInfo(PushService.class) == null)
      return ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS;
    if (!hasPermissions(new String[] { "android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.VIBRATE", "android.permission.WAKE_LOCK", "android.permission.RECEIVE_BOOT_COMPLETED" }))
      return ManifestCheckResult.MISSING_OPTIONAL_DECLARATIONS;
    Intent[] arrayOfIntent = new Intent[2];
    arrayOfIntent[0] = new Intent("android.intent.action.BOOT_COMPLETED").setPackage(getPackageName());
    arrayOfIntent[1] = new Intent("android.intent.action.USER_PRESENT").setPackage(getPackageName());
    if (!checkReceiver(ParseBroadcastReceiver.class, null, arrayOfIntent))
      return ManifestCheckResult.MISSING_OPTIONAL_DECLARATIONS;
    return ManifestCheckResult.HAS_ALL_DECLARATIONS;
  }

  static void setPushType(PushType paramPushType)
  {
    synchronized (lock)
    {
      pushType = paramPushType;
      return;
    }
  }

  public static void setPushUsesBroadcastReceivers(boolean paramBoolean)
  {
    pushUsesBroadcastReceivers = Boolean.valueOf(paramBoolean);
  }

  static enum ManifestCheckResult
  {
    static
    {
      ManifestCheckResult[] arrayOfManifestCheckResult = new ManifestCheckResult[3];
      arrayOfManifestCheckResult[0] = HAS_ALL_DECLARATIONS;
      arrayOfManifestCheckResult[1] = MISSING_OPTIONAL_DECLARATIONS;
      arrayOfManifestCheckResult[2] = MISSING_REQUIRED_DECLARATIONS;
      $VALUES = arrayOfManifestCheckResult;
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ManifestInfo
 * JD-Core Version:    0.6.0
 */