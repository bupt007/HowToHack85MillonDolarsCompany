package com.parse;

import java.io.File;

abstract interface FileProvider
{
  public abstract File getFile(String paramString);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.FileProvider
 * JD-Core Version:    0.6.0
 */