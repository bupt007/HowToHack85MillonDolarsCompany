package com.parse;

import android.net.http.AndroidHttpClient;
import java.io.IOException;
import java.io.InputStream;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;

class ParseApacheHttpResponse extends ParseHttpResponse
{
  private HttpResponse response;

  public ParseApacheHttpResponse(HttpResponse paramHttpResponse)
  {
    this.response = paramHttpResponse;
  }

  public InputStream getContent()
    throws IOException
  {
    return AndroidHttpClient.getUngzippedContent(this.response.getEntity());
  }

  public String getReasonPhrase()
  {
    return this.response.getStatusLine().getReasonPhrase();
  }

  public int getStatusCode()
  {
    return this.response.getStatusLine().getStatusCode();
  }

  public int getTotalSize()
  {
    int i = -1;
    Header[] arrayOfHeader = this.response.getHeaders("Content-Length");
    if (arrayOfHeader.length > 0)
      i = Integer.parseInt(arrayOfHeader[0].getValue());
    return i;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseApacheHttpResponse
 * JD-Core Version:    0.6.0
 */