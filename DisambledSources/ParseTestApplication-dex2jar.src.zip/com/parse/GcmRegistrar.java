package com.parse;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.SystemClock;
import bolts.Continuation;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

class GcmRegistrar
{
  private static final String ERROR_EXTRA = "error";
  private static final String PARSE_SENDER_ID = "1076345567071";
  public static final String REGISTER_ACTION = "com.google.android.c2dm.intent.REGISTER";
  public static final String REGISTER_RESPONSE_ACTION = "com.google.android.c2dm.intent.REGISTRATION";
  private static final String REGISTRATION_ID_EXTRA = "registration_id";
  private static final String SENDER_ID_EXTRA = "com.parse.push.gcm_sender_id";
  private static final String TAG = "com.parse.GcmRegistrar";
  private Context context = null;
  private final Object lock = new Object();
  private Request request = null;

  GcmRegistrar(Context paramContext)
  {
    this.context = paramContext;
  }

  private static String actualSenderIDFromExtra(Object paramObject)
  {
    if (!(paramObject instanceof String));
    String str;
    do
    {
      return null;
      str = (String)paramObject;
    }
    while (!str.startsWith("id:"));
    return str.substring(3);
  }

  public static GcmRegistrar getInstance()
  {
    return Singleton.INSTANCE;
  }

  private void sendRegistrationRequest()
  {
    synchronized (this.lock)
    {
      Object localObject3;
      if (this.request == null)
      {
        Bundle localBundle = ManifestInfo.getApplicationMetadata(this.context);
        String str1 = "1076345567071";
        if (localBundle != null)
        {
          localObject3 = localBundle.get("com.parse.push.gcm_sender_id");
          if (localObject3 != null)
          {
            String str2 = actualSenderIDFromExtra(localObject3);
            if (str2 == null)
              break label117;
            str1 = str1 + "," + str2;
          }
        }
        this.request = Request.createAndSend(this.context, str1);
        this.request.getTask().continueWith(new Continuation()
        {
          public Void then(Task<String> paramTask)
          {
            Exception localException = paramTask.getError();
            if (localException != null)
              Parse.logE("com.parse.GcmRegistrar", "Got error when trying to register for GCM push", localException);
            synchronized (GcmRegistrar.this.lock)
            {
              GcmRegistrar.access$202(GcmRegistrar.this, null);
              return null;
            }
          }
        });
      }
      else
      {
        return;
      }
      label117: Parse.logE("com.parse.GcmRegistrar", "Found com.parse.push.gcm_sender_id <meta-data> element with value \"" + localObject3.toString() + "\", but the value is missing the expected \"id:\" " + "prefix.");
    }
  }

  int getRequestIdentifier()
  {
    while (true)
    {
      synchronized (this.lock)
      {
        if (this.request != null)
        {
          i = this.request.identifier;
          return i;
        }
      }
      int i = 0;
    }
  }

  public void handleRegistrationIntent(Intent paramIntent)
  {
    if (isRegistrationIntent(paramIntent))
    {
      String str = paramIntent.getStringExtra("registration_id");
      if ((str != null) && (str.length() > 0))
      {
        ParseInstallation localParseInstallation = ParseInstallation.getCurrentInstallation();
        localParseInstallation.setPushType(PushType.GCM);
        localParseInstallation.setDeviceToken(str);
        localParseInstallation.saveEventually();
      }
      synchronized (this.lock)
      {
        if (this.request != null)
          this.request.onReceiveResponseIntent(paramIntent);
        return;
      }
    }
  }

  public boolean isRegistrationIntent(Intent paramIntent)
  {
    return (paramIntent != null) && ("com.google.android.c2dm.intent.REGISTRATION".equals(paramIntent.getAction()));
  }

  public void register()
  {
    if (ManifestInfo.getPushType() == PushType.GCM)
      synchronized (this.lock)
      {
        ParseInstallation localParseInstallation = ParseInstallation.getCurrentInstallation();
        if ((localParseInstallation.getDeviceToken() == null) || (localParseInstallation.isDeviceTokenStale()))
        {
          if (localParseInstallation.getPushType() != PushType.GCM)
          {
            localParseInstallation.setPushType(PushType.GCM);
            localParseInstallation.saveEventually();
          }
          sendRegistrationRequest();
        }
        return;
      }
  }

  Task<Void> updateAsync()
  {
    return ParseInstallation.hasCurrentInstallationAsync().onSuccess(new Continuation()
    {
      public Void then(Task<Boolean> paramTask)
        throws Exception
      {
        if ((((Boolean)paramTask.getResult()).booleanValue()) && (ManifestInfo.getPushType() == PushType.GCM))
          synchronized (GcmRegistrar.this.lock)
          {
            ParseInstallation localParseInstallation = ParseInstallation.getCurrentInstallation();
            if ((localParseInstallation.getPushType() == PushType.GCM) && ((localParseInstallation.getDeviceToken() == null) || (localParseInstallation.isDeviceTokenStale())))
              GcmRegistrar.this.sendRegistrationRequest();
          }
        return null;
      }
    });
  }

  private static class Request
  {
    private static final int BACKOFF_INTERVAL_MS = 3000;
    private static final int MAX_RETRIES = 5;
    private static final String RETRY_ACTION = "com.parse.RetryGcmRegistration";
    private final PendingIntent appIntent;
    private final Context context;
    private final int identifier;
    private final Random random;
    private final PendingIntent retryIntent;
    private final BroadcastReceiver retryReceiver;
    private final String senderId;
    private final Task<String>.TaskCompletionSource tcs;
    private final AtomicInteger tries;

    private Request(Context paramContext, String paramString)
    {
      this.context = paramContext;
      this.senderId = paramString;
      this.random = new Random();
      this.identifier = this.random.nextInt();
      this.tcs = Task.create();
      this.appIntent = PendingIntent.getBroadcast(this.context, this.identifier, new Intent(), 0);
      this.tries = new AtomicInteger(0);
      String str = this.context.getPackageName();
      Intent localIntent = new Intent("com.parse.RetryGcmRegistration").setPackage(str);
      localIntent.addCategory(str);
      localIntent.putExtra("random", this.identifier);
      this.retryIntent = PendingIntent.getBroadcast(this.context, this.identifier, localIntent, 0);
      this.retryReceiver = new BroadcastReceiver()
      {
        public void onReceive(Context paramContext, Intent paramIntent)
        {
          if ((paramIntent != null) && (paramIntent.getIntExtra("random", 0) == GcmRegistrar.Request.this.identifier))
            GcmRegistrar.Request.this.send();
        }
      };
      IntentFilter localIntentFilter = new IntentFilter();
      localIntentFilter.addAction("com.parse.RetryGcmRegistration");
      localIntentFilter.addCategory(str);
      paramContext.registerReceiver(this.retryReceiver, localIntentFilter);
    }

    public static Request createAndSend(Context paramContext, String paramString)
    {
      Request localRequest = new Request(paramContext, paramString);
      localRequest.send();
      return localRequest;
    }

    private void finish(String paramString1, String paramString2)
    {
      if (paramString1 != null);
      for (boolean bool = this.tcs.trySetResult(paramString1); ; bool = this.tcs.trySetError(new Exception("GCM registration error: " + paramString2)))
      {
        if (bool)
        {
          this.appIntent.cancel();
          this.retryIntent.cancel();
          this.context.unregisterReceiver(this.retryReceiver);
        }
        return;
      }
    }

    private void send()
    {
      Intent localIntent = new Intent("com.google.android.c2dm.intent.REGISTER");
      localIntent.setPackage("com.google.android.gsf");
      localIntent.putExtra("sender", this.senderId);
      localIntent.putExtra("app", this.appIntent);
      try
      {
        ComponentName localComponentName2 = this.context.startService(localIntent);
        localComponentName1 = localComponentName2;
        if (localComponentName1 == null)
          finish(null, "GSF_PACKAGE_NOT_AVAILABLE");
        this.tries.incrementAndGet();
        Parse.logV("com.parse.GcmRegistrar", "Sending GCM registration intent");
        return;
      }
      catch (SecurityException localSecurityException)
      {
        while (true)
          ComponentName localComponentName1 = null;
      }
    }

    public Task<String> getTask()
    {
      return this.tcs.getTask();
    }

    public void onReceiveResponseIntent(Intent paramIntent)
    {
      String str1 = paramIntent.getStringExtra("registration_id");
      String str2 = paramIntent.getStringExtra("error");
      if ((str1 == null) && (str2 == null))
      {
        Parse.logE("com.parse.GcmRegistrar", "Got no registration info in GCM onReceiveResponseIntent");
        return;
      }
      if (("SERVICE_NOT_AVAILABLE".equals(str2)) && (this.tries.get() < 5))
      {
        ((AlarmManager)this.context.getSystemService("alarm")).set(2, 3000 * (1 << this.tries.get()) + this.random.nextInt(3000) + SystemClock.elapsedRealtime(), this.retryIntent);
        return;
      }
      finish(str1, str2);
    }
  }

  private static class Singleton
  {
    public static final GcmRegistrar INSTANCE = new GcmRegistrar(Parse.getApplicationContext());
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.GcmRegistrar
 * JD-Core Version:    0.6.0
 */