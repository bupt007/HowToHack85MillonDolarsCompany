package com.parse;

import android.util.Log;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class LogCatCollector
{
  private static final int DEFAULT_TAIL_COUNT = 100;

  protected static String collectLogCat(String paramString)
  {
    try
    {
      ArrayList localArrayList1 = new ArrayList();
      localArrayList1.add("logcat");
      if (paramString != null)
      {
        localArrayList1.add("-b");
        localArrayList1.add(paramString);
      }
      int i = -1;
      ArrayList localArrayList2 = new ArrayList(Arrays.asList(ACRA.getConfig().logcatArguments()));
      int j = localArrayList2.indexOf("-t");
      if ((j > -1) && (j < localArrayList2.size()))
      {
        i = Integer.parseInt((String)localArrayList2.get(j + 1));
        if (Compatibility.getAPILevel() < 8)
        {
          localArrayList2.remove(j + 1);
          localArrayList2.remove(j);
          localArrayList2.add("-d");
        }
      }
      BoundedLinkedList localBoundedLinkedList2;
      if (i > 0)
      {
        localBoundedLinkedList2 = new BoundedLinkedList(i);
        try
        {
          localArrayList1.addAll(localArrayList2);
          BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec((String[])localArrayList1.toArray(new String[localArrayList1.size()])).getInputStream()));
          Log.d("CrashReporting", "Retrieving logcat output...");
          while (true)
          {
            String str = localBufferedReader.readLine();
            if (str == null)
              break;
            localBoundedLinkedList2.add(str + "\n");
          }
        }
        catch (IOException localIOException1)
        {
          localBoundedLinkedList1 = localBoundedLinkedList2;
        }
        Log.e("CrashReporting", "LogCatCollector.collectLogcat could not retrieve data.", localIOException1);
      }
      while (true)
      {
        return localBoundedLinkedList1.toString();
        i = 100;
        break;
        localBoundedLinkedList1 = localBoundedLinkedList2;
      }
    }
    catch (IOException localIOException2)
    {
      while (true)
        BoundedLinkedList localBoundedLinkedList1 = null;
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.LogCatCollector
 * JD-Core Version:    0.6.0
 */