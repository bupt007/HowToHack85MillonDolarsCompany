package com.parse;

import bolts.Continuation;
import bolts.Task;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

@ParseClassName("_EventuallyPin")
class EventuallyPin extends ParseObject
{
  public static final String PIN_NAME = "_eventuallyPin";
  public static final int TYPE_COMMAND = 3;
  public static final int TYPE_DELETE = 2;
  public static final int TYPE_SAVE = 1;

  public EventuallyPin()
  {
    super("_EventuallyPin");
  }

  public static Task<List<EventuallyPin>> findAllPinned()
  {
    return findAllPinned(null);
  }

  public static Task<List<EventuallyPin>> findAllPinned(Collection<String> paramCollection)
  {
    ParseQuery localParseQuery = new ParseQuery(EventuallyPin.class).fromPin("_eventuallyPin").ignoreACLs().orderByAscending("time");
    if (paramCollection != null)
      localParseQuery.whereNotContainedIn("uuid", paramCollection);
    return localParseQuery.findInBackground().continueWithTask(new Continuation()
    {
      public Task<List<EventuallyPin>> then(Task<List<EventuallyPin>> paramTask)
        throws Exception
      {
        List localList = (List)paramTask.getResult();
        ArrayList localArrayList = new ArrayList();
        Iterator localIterator = localList.iterator();
        while (localIterator.hasNext())
        {
          ParseObject localParseObject = ((EventuallyPin)localIterator.next()).getObject();
          if (localParseObject == null)
            continue;
          localArrayList.add(localParseObject.fetchFromLocalDatastoreAsync().makeVoid());
        }
        return Task.whenAll(localArrayList).continueWithTask(new Continuation(localList)
        {
          public Task<List<EventuallyPin>> then(Task<Void> paramTask)
            throws Exception
          {
            return Task.forResult(this.val$pins);
          }
        });
      }
    });
  }

  private static Task<EventuallyPin> pinEventuallyCommand(int paramInt, ParseObject paramParseObject, String paramString1, String paramString2, JSONObject paramJSONObject)
  {
    EventuallyPin localEventuallyPin = new EventuallyPin();
    localEventuallyPin.put("uuid", UUID.randomUUID().toString());
    localEventuallyPin.put("time", new Date());
    localEventuallyPin.put("type", Integer.valueOf(paramInt));
    if (paramParseObject != null)
      localEventuallyPin.put("object", paramParseObject);
    if (paramString1 != null)
      localEventuallyPin.put("operationSetUUID", paramString1);
    if (paramString2 != null)
      localEventuallyPin.put("sessionToken", paramString2);
    if (paramJSONObject != null)
      localEventuallyPin.put("command", paramJSONObject);
    return localEventuallyPin.pinInBackground("_eventuallyPin").continueWith(new Continuation(localEventuallyPin)
    {
      public EventuallyPin then(Task<Void> paramTask)
        throws Exception
      {
        return this.val$pin;
      }
    });
  }

  public static Task<EventuallyPin> pinEventuallyCommand(ParseObject paramParseObject, ParseNetworkCommand paramParseNetworkCommand)
  {
    int i = 3;
    JSONObject localJSONObject = null;
    ParseRESTCommand localParseRESTCommand;
    if ((paramParseNetworkCommand instanceof ParseRESTCommand))
    {
      localParseRESTCommand = (ParseRESTCommand)paramParseNetworkCommand;
      if (localParseRESTCommand.httpPath.startsWith("classes"))
        if ((localParseRESTCommand.method == ParseRequest.Method.POST) || (localParseRESTCommand.method == ParseRequest.Method.PUT))
          i = 1;
    }
    while (true)
    {
      label54: return pinEventuallyCommand(i, paramParseObject, paramParseNetworkCommand.getOperationSetUUID(), paramParseNetworkCommand.getSessionToken(), localJSONObject);
      ParseRequest.Method localMethod1 = localParseRESTCommand.method;
      ParseRequest.Method localMethod2 = ParseRequest.Method.DELETE;
      localJSONObject = null;
      if (localMethod1 != localMethod2)
        continue;
      i = 2;
      localJSONObject = null;
      continue;
      localJSONObject = localParseRESTCommand.toJSONObject();
      continue;
      boolean bool = paramParseNetworkCommand instanceof ParseCommand;
      localJSONObject = null;
      if (!bool)
        continue;
      String str = ((ParseCommand)paramParseNetworkCommand).getOp();
      int j = -1;
      switch (str.hashCode())
      {
      default:
      case -1352294148:
      case -838846263:
      case -1335458389:
      }
      while (true)
        switch (j)
        {
        default:
          localJSONObject = paramParseNetworkCommand.toJSONObject();
          break label54;
          if (!str.equals("create"))
            continue;
          j = 0;
          continue;
          if (!str.equals("update"))
            continue;
          j = 1;
          continue;
          if (!str.equals("delete"))
            continue;
          j = 2;
        case 0:
        case 1:
        case 2:
        }
      i = 1;
      localJSONObject = null;
      continue;
      i = 2;
      localJSONObject = null;
    }
  }

  public ParseNetworkCommand getCommand()
    throws JSONException
  {
    JSONObject localJSONObject = getJSONObject("command");
    if (ParseRESTCommand.isValidCommandJSONObject(localJSONObject))
      return ParseRESTCommand.fromJSONObject(localJSONObject);
    if (ParseCommand.isValidCommandJSONObject(localJSONObject))
      return new ParseCommand(localJSONObject);
    throw new JSONException("Failed to load command from JSON.");
  }

  public ParseObject getObject()
  {
    return getParseObject("object");
  }

  public String getOperationSetUUID()
  {
    return getString("operationSetUUID");
  }

  public String getSessionToken()
  {
    return getString("sessionToken");
  }

  public int getType()
  {
    return getInt("type");
  }

  public String getUUID()
  {
    return getString("uuid");
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.EventuallyPin
 * JD-Core Version:    0.6.0
 */