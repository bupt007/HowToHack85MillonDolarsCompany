package com.parse;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ParseRelation<T extends ParseObject>
{
  private String key;
  private Set<ParseObject> knownObjects = new HashSet();
  private final Object mutex = new Object();
  private ParseObject parent;
  private String targetClass;

  ParseRelation(ParseObject paramParseObject, String paramString)
  {
    this.parent = paramParseObject;
    this.key = paramString;
    this.targetClass = null;
  }

  ParseRelation(String paramString)
  {
    this.parent = null;
    this.key = null;
    this.targetClass = paramString;
  }

  ParseRelation(JSONObject paramJSONObject, ParseDecoder paramParseDecoder)
  {
    this.parent = null;
    this.targetClass = paramJSONObject.optString("className", null);
    this.key = null;
    JSONArray localJSONArray = paramJSONObject.optJSONArray("objects");
    if (localJSONArray != null)
      for (int i = 0; i < localJSONArray.length(); i++)
        this.knownObjects.add((ParseObject)paramParseDecoder.decode(localJSONArray.optJSONObject(i)));
  }

  public void add(T paramT)
  {
    synchronized (this.mutex)
    {
      ParseRelationOperation localParseRelationOperation = new ParseRelationOperation(Collections.singleton(paramT), null);
      this.targetClass = localParseRelationOperation.getTargetClass();
      this.parent.performOperation(this.key, localParseRelationOperation);
      this.knownObjects.add(paramT);
      return;
    }
  }

  void addKnownObject(ParseObject paramParseObject)
  {
    synchronized (this.mutex)
    {
      this.knownObjects.add(paramParseObject);
      return;
    }
  }

  JSONObject encodeToJSON(ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
    throws JSONException
  {
    synchronized (this.mutex)
    {
      JSONObject localJSONObject = new JSONObject();
      localJSONObject.put("__type", "Relation");
      localJSONObject.put("className", this.targetClass);
      JSONArray localJSONArray = new JSONArray();
      Iterator localIterator = this.knownObjects.iterator();
      while (localIterator.hasNext())
      {
        ParseObject localParseObject = (ParseObject)localIterator.next();
        try
        {
          localJSONArray.put(paramParseObjectEncodingStrategy.encodeRelatedObject(localParseObject));
        }
        catch (Exception localException)
        {
        }
      }
      localJSONObject.put("objects", localJSONArray);
      return localJSONObject;
    }
  }

  void ensureParentAndKey(ParseObject paramParseObject, String paramString)
  {
    synchronized (this.mutex)
    {
      if (this.parent == null)
        this.parent = paramParseObject;
      if (this.key == null)
        this.key = paramString;
      if (this.parent != paramParseObject)
        throw new IllegalStateException("Internal error. One ParseRelation retrieved from two different ParseObjects.");
    }
    if (!this.key.equals(paramString))
      throw new IllegalStateException("Internal error. One ParseRelation retrieved from two different keys.");
    monitorexit;
  }

  public ParseQuery<T> getQuery()
  {
    synchronized (this.mutex)
    {
      if (this.targetClass == null)
      {
        localParseQuery = ParseQuery.getQuery(this.parent.getClassName());
        localParseQuery.redirectClassNameForKey(this.key);
        localParseQuery.whereRelatedTo(this.parent, this.key);
        return localParseQuery;
      }
      ParseQuery localParseQuery = ParseQuery.getQuery(this.targetClass);
    }
  }

  String getTargetClass()
  {
    synchronized (this.mutex)
    {
      String str = this.targetClass;
      return str;
    }
  }

  boolean hasKnownObject(ParseObject paramParseObject)
  {
    synchronized (this.mutex)
    {
      boolean bool = this.knownObjects.contains(paramParseObject);
      return bool;
    }
  }

  public void remove(T paramT)
  {
    synchronized (this.mutex)
    {
      ParseRelationOperation localParseRelationOperation = new ParseRelationOperation(null, Collections.singleton(paramT));
      this.targetClass = localParseRelationOperation.getTargetClass();
      this.parent.performOperation(this.key, localParseRelationOperation);
      this.knownObjects.remove(paramT);
      return;
    }
  }

  void removeKnownObject(ParseObject paramParseObject)
  {
    synchronized (this.mutex)
    {
      this.knownObjects.remove(paramParseObject);
      return;
    }
  }

  void setTargetClass(String paramString)
  {
    synchronized (this.mutex)
    {
      this.targetClass = paramString;
      return;
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseRelation
 * JD-Core Version:    0.6.0
 */