package com.parse;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Looper;
import android.os.SystemClock;
import bolts.Continuation;
import bolts.Task;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

class PushConnection
{
  private static final int CONNECT_TIMEOUT_MS = 40000;
  static boolean ENABLE_QUICK_ACK_CHECK = false;
  static boolean ENABLE_RETRY_DELAY = false;
  static long KEEP_ALIVE_ACK_INTERVAL = 0L;
  static long KEEP_ALIVE_INTERVAL = 0L;
  private static final long MAX_RETRY_DELAY_MS = 300000L;
  private static final long MIN_RETRY_DELAY_MS = 15000L;
  private static final double RETRY_MULT_FACTOR_MAX = 2.0D;
  private static final double RETRY_MULT_FACTOR_MIN = 1.5D;
  private static final String TAG = "com.parse.PushConnection";
  private static List<StateTransitionListener> stateTransitionListeners;
  private final EventSet eventSet;
  private final ExecutorService executor;
  private final String host;
  private final AtomicLong lastReadTime;
  private final int port;
  private final Service service;

  static
  {
    KEEP_ALIVE_ACK_INTERVAL = 60000L;
    ENABLE_QUICK_ACK_CHECK = true;
    ENABLE_RETRY_DELAY = true;
  }

  public PushConnection(Service paramService, String paramString, int paramInt)
  {
    this.service = paramService;
    this.host = paramString;
    this.port = paramInt;
    this.executor = Executors.newSingleThreadExecutor();
    this.eventSet = new EventSet(null);
    this.lastReadTime = new AtomicLong();
    WaitStartState localWaitStartState = new WaitStartState();
    dispatchOnStateChange(this, null, localWaitStartState);
    this.executor.execute(localWaitStartState);
  }

  private static void closeSocket(Socket paramSocket)
  {
    try
    {
      if (!(paramSocket instanceof SSLSocket))
        paramSocket.shutdownInput();
      paramSocket.close();
      return;
    }
    catch (IOException localIOException)
    {
    }
  }

  private static void dispatchOnStateChange(PushConnection paramPushConnection, State paramState1, State paramState2)
  {
    monitorenter;
    try
    {
      if (stateTransitionListeners != null)
      {
        Iterator localIterator = stateTransitionListeners.iterator();
        while (localIterator.hasNext())
          ((StateTransitionListener)localIterator.next()).onStateChange(paramPushConnection, paramState1, paramState2);
      }
    }
    finally
    {
      monitorexit;
    }
    monitorexit;
  }

  public static void registerStateTransitionListener(StateTransitionListener paramStateTransitionListener)
  {
    monitorenter;
    try
    {
      if (stateTransitionListeners == null)
        stateTransitionListeners = new ArrayList();
      if (!stateTransitionListeners.contains(paramStateTransitionListener))
        stateTransitionListeners.add(paramStateTransitionListener);
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public static void unregisterStateTransitionListener(StateTransitionListener paramStateTransitionListener)
  {
    monitorenter;
    try
    {
      if (stateTransitionListeners == null)
        return;
      stateTransitionListeners.remove(paramStateTransitionListener);
      if (stateTransitionListeners.size() == 0)
        stateTransitionListeners = null;
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  private static boolean writeLine(Socket paramSocket, String paramString)
  {
    if (Thread.currentThread() == Looper.getMainLooper().getThread())
      throw new Error("Wrote to push socket on main thread.");
    try
    {
      OutputStream localOutputStream = paramSocket.getOutputStream();
      localOutputStream.write((paramString + "\n").getBytes("UTF-8"));
      localOutputStream.flush();
      return true;
    }
    catch (IOException localIOException)
    {
      Parse.logV("com.parse.PushConnection", "PushConnection write failed: " + paramString + " due to exception: " + localIOException);
    }
    return false;
  }

  public void start()
  {
    monitorenter;
    try
    {
      this.eventSet.signalEvent(Event.START);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void stop()
  {
    monitorenter;
    try
    {
      this.eventSet.signalEvent(Event.STOP);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public class ConnectState extends PushConnection.State
  {
    private long lastDelay;

    public ConnectState(long arg2)
    {
      super();
      Object localObject;
      this.lastDelay = localObject;
    }

    private long nextDelay()
    {
      return Math.min(Math.max(15000L, ()(this.lastDelay * (1.5D + 0.5D * Math.random()))), 300000L);
    }

    private boolean sendHandshake(Socket paramSocket)
    {
      Task localTask = PushRouter.getPushRequestJSONAsync();
      try
      {
        localTask.waitForCompletion();
        JSONObject localJSONObject = (JSONObject)localTask.getResult();
        boolean bool = false;
        if (localJSONObject != null)
          bool = PushConnection.access$700(paramSocket, localJSONObject.toString());
        return bool;
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          Parse.logE("com.parse.PushConnection", "Unexpected interruption when waiting for handshake to be sent", localInterruptedException);
      }
    }

    public PushConnection.State runState()
    {
      Object localObject1 = null;
      Object localObject2 = null;
      try
      {
        boolean bool2 = "push.parse.com".equals(PushConnection.this.host);
        localObject1 = null;
        if (!bool2);
        Socket localSocket;
        for (localObject1 = new Socket(); ; localObject1 = localSocket)
        {
          ((Socket)localObject1).connect(new InetSocketAddress(PushConnection.this.host, PushConnection.this.port), 40000);
          ((Socket)localObject1).setKeepAlive(true);
          ((Socket)localObject1).setTcpNoDelay(true);
          boolean bool3 = sendHandshake((Socket)localObject1);
          bool1 = bool3;
          if (localObject2 != null)
            Parse.logI("com.parse.PushConnection", "Failed to connect to push server due to " + localObject2);
          if (bool1)
            break;
          PushConnection.access$600((Socket)localObject1);
          return new PushConnection.WaitRetryState(PushConnection.this, nextDelay());
          localSocket = SSLSocketFactory.getDefault().createSocket();
        }
      }
      catch (IOException localIOException)
      {
        while (true)
        {
          localObject2 = localIOException;
          bool1 = false;
        }
      }
      catch (SecurityException localSecurityException)
      {
        while (true)
        {
          localObject2 = localSecurityException;
          boolean bool1 = false;
        }
      }
      return (PushConnection.State)new PushConnection.ConnectedState(PushConnection.this, (Socket)localObject1);
    }
  }

  public class ConnectedState extends PushConnection.State
  {
    private final Socket socket;

    public ConnectedState(Socket arg2)
    {
      super();
      Object localObject;
      this.socket = localObject;
    }

    public PushConnection.State runState()
    {
      Object localObject = null;
      PushConnection.ReachabilityMonitor localReachabilityMonitor = new PushConnection.ReachabilityMonitor(PushConnection.this, null);
      PushConnection.KeepAliveMonitor localKeepAliveMonitor = new PushConnection.KeepAliveMonitor(PushConnection.this, this.socket, PushConnection.KEEP_ALIVE_INTERVAL);
      PushConnection.ReaderThread localReaderThread = new PushConnection.ReaderThread(PushConnection.this, this.socket);
      localReachabilityMonitor.register();
      localKeepAliveMonitor.register();
      localReaderThread.start();
      while (localObject == null)
      {
        PushConnection.EventSet localEventSet2 = PushConnection.this.eventSet;
        PushConnection.Event[] arrayOfEvent2 = new PushConnection.Event[4];
        arrayOfEvent2[0] = PushConnection.Event.STOP;
        arrayOfEvent2[1] = PushConnection.Event.CONNECTIVITY_CHANGED;
        arrayOfEvent2[2] = PushConnection.Event.KEEP_ALIVE_ERROR;
        arrayOfEvent2[3] = PushConnection.Event.READ_ERROR;
        Set localSet = localEventSet2.await(arrayOfEvent2);
        if (localSet.contains(PushConnection.Event.STOP))
        {
          localObject = new PushConnection.StoppedState(PushConnection.this);
          continue;
        }
        if ((!localSet.contains(PushConnection.Event.READ_ERROR)) && (!localSet.contains(PushConnection.Event.KEEP_ALIVE_ERROR)) && (!localSet.contains(PushConnection.Event.CONNECTIVITY_CHANGED)))
          continue;
        localObject = new PushConnection.WaitRetryState(PushConnection.this, 0L);
      }
      localReachabilityMonitor.unregister();
      localKeepAliveMonitor.unregister();
      localReaderThread.stopReading();
      PushConnection.access$600(this.socket);
      PushConnection.EventSet localEventSet1 = PushConnection.this.eventSet;
      PushConnection.Event[] arrayOfEvent1 = new PushConnection.Event[3];
      arrayOfEvent1[0] = PushConnection.Event.CONNECTIVITY_CHANGED;
      arrayOfEvent1[1] = PushConnection.Event.KEEP_ALIVE_ERROR;
      arrayOfEvent1[2] = PushConnection.Event.READ_ERROR;
      localEventSet1.removeEvents(arrayOfEvent1);
      return (PushConnection.State)localObject;
    }
  }

  private static enum Event
  {
    static
    {
      CONNECTIVITY_CHANGED = new Event("CONNECTIVITY_CHANGED", 2);
      KEEP_ALIVE_ERROR = new Event("KEEP_ALIVE_ERROR", 3);
      READ_ERROR = new Event("READ_ERROR", 4);
      Event[] arrayOfEvent = new Event[5];
      arrayOfEvent[0] = START;
      arrayOfEvent[1] = STOP;
      arrayOfEvent[2] = CONNECTIVITY_CHANGED;
      arrayOfEvent[3] = KEEP_ALIVE_ERROR;
      arrayOfEvent[4] = READ_ERROR;
      $VALUES = arrayOfEvent;
    }
  }

  private static class EventSet
  {
    private final Condition condition = this.lock.newCondition();
    private final Lock lock = new ReentrantLock();
    private final HashSet<PushConnection.Event> signaledEvents = new HashSet();

    public Set<PushConnection.Event> await(PushConnection.Event[] paramArrayOfEvent)
    {
      return timedAwait(9223372036854775807L, paramArrayOfEvent);
    }

    public void removeEvents(PushConnection.Event[] paramArrayOfEvent)
    {
      this.lock.lock();
      try
      {
        int i = paramArrayOfEvent.length;
        for (int j = 0; j < i; j++)
        {
          PushConnection.Event localEvent = paramArrayOfEvent[j];
          this.signaledEvents.remove(localEvent);
        }
        return;
      }
      finally
      {
        this.lock.unlock();
      }
      throw localObject;
    }

    public void signalEvent(PushConnection.Event paramEvent)
    {
      this.lock.lock();
      try
      {
        this.signaledEvents.add(paramEvent);
        this.condition.signalAll();
        return;
      }
      finally
      {
        this.lock.unlock();
      }
      throw localObject;
    }

    // ERROR //
    public Set<PushConnection.Event> timedAwait(long paramLong, PushConnection.Event[] paramArrayOfEvent)
    {
      // Byte code:
      //   0: getstatic 72	java/util/Collections:EMPTY_SET	Ljava/util/Set;
      //   3: astore 4
      //   5: new 30	java/util/HashSet
      //   8: dup
      //   9: aload_3
      //   10: invokestatic 78	java/util/Arrays:asList	([Ljava/lang/Object;)Ljava/util/List;
      //   13: invokespecial 81	java/util/HashSet:<init>	(Ljava/util/Collection;)V
      //   16: astore 5
      //   18: invokestatic 87	android/os/SystemClock:elapsedRealtime	()J
      //   21: lstore 6
      //   23: lload_1
      //   24: ldc2_w 38
      //   27: lcmp
      //   28: ifne +98 -> 126
      //   31: iconst_1
      //   32: istore 8
      //   34: aload_0
      //   35: getfield 20	com/parse/PushConnection$EventSet:lock	Ljava/util/concurrent/locks/Lock;
      //   38: invokeinterface 47 1 0
      //   43: aload 4
      //   45: astore 9
      //   47: invokestatic 87	android/os/SystemClock:elapsedRealtime	()J
      //   50: lload 6
      //   52: lsub
      //   53: lstore 12
      //   55: new 30	java/util/HashSet
      //   58: dup
      //   59: aload 5
      //   61: invokespecial 81	java/util/HashSet:<init>	(Ljava/util/Collection;)V
      //   64: astore 14
      //   66: aload 14
      //   68: aload_0
      //   69: getfield 33	com/parse/PushConnection$EventSet:signaledEvents	Ljava/util/HashSet;
      //   72: invokeinterface 93 2 0
      //   77: pop
      //   78: aload_0
      //   79: getfield 33	com/parse/PushConnection$EventSet:signaledEvents	Ljava/util/HashSet;
      //   82: aload 5
      //   84: invokevirtual 96	java/util/HashSet:removeAll	(Ljava/util/Collection;)Z
      //   87: pop
      //   88: aload 14
      //   90: invokeinterface 100 1 0
      //   95: istore 17
      //   97: iload 17
      //   99: ifne +15 -> 114
      //   102: iload 8
      //   104: ifne +28 -> 132
      //   107: lload 12
      //   109: lload_1
      //   110: lcmp
      //   111: iflt +21 -> 132
      //   114: aload_0
      //   115: getfield 20	com/parse/PushConnection$EventSet:lock	Ljava/util/concurrent/locks/Lock;
      //   118: invokeinterface 54 1 0
      //   123: aload 14
      //   125: areturn
      //   126: iconst_0
      //   127: istore 8
      //   129: goto -95 -> 34
      //   132: iload 8
      //   134: ifeq +19 -> 153
      //   137: aload_0
      //   138: getfield 28	com/parse/PushConnection$EventSet:condition	Ljava/util/concurrent/locks/Condition;
      //   141: invokeinterface 103 1 0
      //   146: aload 14
      //   148: astore 9
      //   150: goto -103 -> 47
      //   153: aload_0
      //   154: getfield 28	com/parse/PushConnection$EventSet:condition	Ljava/util/concurrent/locks/Condition;
      //   157: lload_1
      //   158: lload 12
      //   160: lsub
      //   161: getstatic 109	java/util/concurrent/TimeUnit:MILLISECONDS	Ljava/util/concurrent/TimeUnit;
      //   164: invokeinterface 112 4 0
      //   169: pop
      //   170: goto -24 -> 146
      //   173: astore 18
      //   175: goto -61 -> 114
      //   178: astore 10
      //   180: aload 9
      //   182: pop
      //   183: aload_0
      //   184: getfield 20	com/parse/PushConnection$EventSet:lock	Ljava/util/concurrent/locks/Lock;
      //   187: invokeinterface 54 1 0
      //   192: aload 10
      //   194: athrow
      //   195: astore 10
      //   197: goto -14 -> 183
      //
      // Exception table:
      //   from	to	target	type
      //   153	170	173	java/lang/InterruptedException
      //   47	66	178	finally
      //   66	97	195	finally
      //   137	146	195	finally
      //   153	170	195	finally
    }
  }

  private class KeepAliveMonitor
  {
    private PendingIntent broadcast;
    private final long interval;
    private Task<Void> keepAliveTask;
    private AlarmManager manager;
    private BroadcastReceiver readReceiver;
    private final Socket socket;
    private boolean unregistered;
    private BroadcastReceiver writeReceiver;

    public KeepAliveMonitor(Socket paramLong, long arg3)
    {
      this.socket = paramLong;
      Object localObject;
      this.interval = localObject;
    }

    private void signalKeepAliveFailure()
    {
      monitorenter;
      try
      {
        if (!this.unregistered)
          PushConnection.this.eventSet.signalEvent(PushConnection.Event.KEEP_ALIVE_ERROR);
        monitorexit;
        return;
      }
      finally
      {
        localObject = finally;
        monitorexit;
      }
      throw localObject;
    }

    public void register()
    {
      Context localContext = Parse.applicationContext;
      String str = localContext.getPackageName();
      Intent localIntent1 = new Intent("com.parse.PushConnection.readKeepAlive");
      localIntent1.setPackage(str);
      localIntent1.addCategory(str);
      Intent localIntent2 = new Intent("com.parse.PushConnection.writeKeepAlive");
      localIntent2.setPackage(str);
      localIntent2.addCategory(str);
      this.manager = ((AlarmManager)localContext.getSystemService("alarm"));
      PendingIntent localPendingIntent = PendingIntent.getBroadcast(localContext, 0, localIntent1, 0);
      if (localPendingIntent != null)
      {
        this.manager.cancel(localPendingIntent);
        localPendingIntent.cancel();
      }
      while (true)
      {
        this.broadcast = PendingIntent.getBroadcast(localContext, 0, localIntent2, 0);
        this.manager.cancel(this.broadcast);
        long l = SystemClock.elapsedRealtime();
        this.manager.setInexactRepeating(2, l, this.interval, this.broadcast);
        this.readReceiver = new BroadcastReceiver()
        {
          public void onReceive(Context paramContext, Intent paramIntent)
          {
            long l = SystemClock.elapsedRealtime() - PushConnection.this.lastReadTime.get();
            if (l > 2L * PushConnection.KEEP_ALIVE_ACK_INTERVAL)
            {
              Parse.logV("com.parse.PushConnection", "Keep alive failure: last read was " + l + " ms ago.");
              PushConnection.KeepAliveMonitor.this.signalKeepAliveFailure();
            }
          }
        };
        this.writeReceiver = new BroadcastReceiver(localContext, localIntent1)
        {
          public void onReceive(Context paramContext, Intent paramIntent)
          {
            ParseWakeLock localParseWakeLock = ParseWakeLock.acquireNewWakeLock(PushConnection.this.service, 1, "push-keep-alive", 20000L);
            if (PushConnection.KeepAliveMonitor.this.keepAliveTask == null)
              PushConnection.KeepAliveMonitor.access$1302(PushConnection.KeepAliveMonitor.this, Task.forResult(null).makeVoid());
            PushConnection.KeepAliveMonitor.access$1302(PushConnection.KeepAliveMonitor.this, PushConnection.KeepAliveMonitor.this.keepAliveTask.continueWith(new Continuation(localParseWakeLock)
            {
              public Void then(Task<Void> paramTask)
              {
                if (!PushConnection.access$700(PushConnection.KeepAliveMonitor.this.socket, "{}"))
                  PushConnection.KeepAliveMonitor.this.signalKeepAliveFailure();
                boolean bool = PushConnection.ENABLE_QUICK_ACK_CHECK;
                int i = 0;
                if (bool);
                try
                {
                  Thread.sleep(2500L);
                  label44: if (SystemClock.elapsedRealtime() - PushConnection.this.lastReadTime.get() <= 2L * 2500L)
                  {
                    i = 1;
                    if (i != 0)
                      break label143;
                    PendingIntent localPendingIntent = PendingIntent.getBroadcast(PushConnection.KeepAliveMonitor.2.this.val$appContext, System.identityHashCode(this), PushConnection.KeepAliveMonitor.2.this.val$readIntent, 1342177280);
                    PushConnection.KeepAliveMonitor.this.manager.set(2, SystemClock.elapsedRealtime() + PushConnection.KEEP_ALIVE_ACK_INTERVAL, localPendingIntent);
                  }
                  while (true)
                  {
                    this.val$wl.release();
                    return null;
                    i = 0;
                    break;
                    label143: Parse.logV("com.parse.PushConnection", "Keep alive ack was received quickly.");
                  }
                }
                catch (InterruptedException localInterruptedException)
                {
                  break label44;
                }
              }
            }
            , ParseCommand.NETWORK_EXECUTOR));
          }
        };
        IntentFilter localIntentFilter1 = new IntentFilter("com.parse.PushConnection.readKeepAlive");
        localIntentFilter1.addCategory(str);
        localContext.registerReceiver(this.readReceiver, localIntentFilter1);
        IntentFilter localIntentFilter2 = new IntentFilter("com.parse.PushConnection.writeKeepAlive");
        localIntentFilter2.addCategory(str);
        localContext.registerReceiver(this.writeReceiver, localIntentFilter2);
        return;
        Parse.logE("com.parse.PushConnection", "oldReadBroadcast was null");
      }
    }

    public void unregister()
    {
      Parse.applicationContext.unregisterReceiver(this.readReceiver);
      Parse.applicationContext.unregisterReceiver(this.writeReceiver);
      this.manager.cancel(this.broadcast);
      this.broadcast.cancel();
      monitorenter;
      try
      {
        this.unregistered = true;
        return;
      }
      finally
      {
        monitorexit;
      }
      throw localObject;
    }
  }

  private class ReachabilityMonitor
  {
    private ConnectivityNotifier.ConnectivityListener listener;
    private boolean unregistered;

    private ReachabilityMonitor()
    {
    }

    public void register()
    {
      this.listener = new ConnectivityNotifier.ConnectivityListener()
      {
        public void networkConnectivityStatusChanged(Context paramContext, Intent paramIntent)
        {
          synchronized (PushConnection.ReachabilityMonitor.this)
          {
            if (!PushConnection.ReachabilityMonitor.this.unregistered)
              PushConnection.this.eventSet.signalEvent(PushConnection.Event.CONNECTIVITY_CHANGED);
            return;
          }
        }
      };
      ConnectivityNotifier.getNotifier(PushConnection.this.service).addListener(this.listener);
    }

    public void unregister()
    {
      ConnectivityNotifier.getNotifier(PushConnection.this.service).removeListener(this.listener);
      monitorenter;
      try
      {
        this.unregistered = true;
        return;
      }
      finally
      {
        monitorexit;
      }
      throw localObject;
    }
  }

  private class ReaderThread extends Thread
  {
    private final Socket socket;
    private boolean stopped;

    public ReaderThread(Socket arg2)
    {
      Object localObject;
      this.socket = localObject;
      this.stopped = false;
    }

    private void runReaderLoop(BufferedReader paramBufferedReader)
    {
      while (true)
      {
        String str = null;
        try
        {
          str = paramBufferedReader.readLine();
          PushConnection.this.lastReadTime.set(SystemClock.elapsedRealtime());
          label20: if (str == null)
            return;
          JSONTokener localJSONTokener = new JSONTokener(str);
          try
          {
            JSONObject localJSONObject1 = new JSONObject(localJSONTokener);
            localJSONObject2 = localJSONObject1;
            if (localJSONObject2 != null)
              PushRouter.handlePpnsPushAsync(localJSONObject2);
            monitorenter;
            try
            {
              if (this.stopped)
                return;
            }
            finally
            {
              monitorexit;
            }
          }
          catch (JSONException localJSONException)
          {
            while (true)
            {
              Parse.logE("com.parse.PushConnection", "bad json: " + str, localJSONException);
              JSONObject localJSONObject2 = null;
            }
            monitorexit;
          }
        }
        catch (IOException localIOException)
        {
          break label20;
        }
      }
    }

    // ERROR //
    public void run()
    {
      // Byte code:
      //   0: aconst_null
      //   1: astore_1
      //   2: aconst_null
      //   3: astore_2
      //   4: aload_0
      //   5: getfield 19	com/parse/PushConnection$ReaderThread:socket	Ljava/net/Socket;
      //   8: invokevirtual 94	java/net/Socket:getInputStream	()Ljava/io/InputStream;
      //   11: astore_1
      //   12: aconst_null
      //   13: astore_2
      //   14: aload_1
      //   15: ifnull +29 -> 44
      //   18: new 29	java/io/BufferedReader
      //   21: dup
      //   22: new 96	java/io/InputStreamReader
      //   25: dup
      //   26: aload_1
      //   27: invokespecial 99	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
      //   30: invokespecial 102	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
      //   33: astore 6
      //   35: aload_0
      //   36: aload 6
      //   38: invokespecial 104	com/parse/PushConnection$ReaderThread:runReaderLoop	(Ljava/io/BufferedReader;)V
      //   41: aload 6
      //   43: astore_2
      //   44: aload_2
      //   45: invokestatic 110	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/Closeable;)V
      //   48: aload_1
      //   49: invokestatic 112	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/InputStream;)V
      //   52: aload_0
      //   53: monitorenter
      //   54: aload_0
      //   55: getfield 21	com/parse/PushConnection$ReaderThread:stopped	Z
      //   58: ifne +16 -> 74
      //   61: aload_0
      //   62: getfield 14	com/parse/PushConnection$ReaderThread:this$0	Lcom/parse/PushConnection;
      //   65: invokestatic 116	com/parse/PushConnection:access$300	(Lcom/parse/PushConnection;)Lcom/parse/PushConnection$EventSet;
      //   68: getstatic 122	com/parse/PushConnection$Event:READ_ERROR	Lcom/parse/PushConnection$Event;
      //   71: invokevirtual 128	com/parse/PushConnection$EventSet:signalEvent	(Lcom/parse/PushConnection$Event;)V
      //   74: aload_0
      //   75: monitorexit
      //   76: return
      //   77: astore 4
      //   79: aload_2
      //   80: invokestatic 110	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/Closeable;)V
      //   83: aload_1
      //   84: invokestatic 112	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/InputStream;)V
      //   87: goto -35 -> 52
      //   90: astore_3
      //   91: aload_2
      //   92: invokestatic 110	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/Closeable;)V
      //   95: aload_1
      //   96: invokestatic 112	com/parse/ParseIOUtils:closeQuietly	(Ljava/io/InputStream;)V
      //   99: aload_3
      //   100: athrow
      //   101: astore 5
      //   103: aload_0
      //   104: monitorexit
      //   105: aload 5
      //   107: athrow
      //   108: astore_3
      //   109: aload 6
      //   111: astore_2
      //   112: goto -21 -> 91
      //   115: astore 7
      //   117: aload 6
      //   119: astore_2
      //   120: goto -41 -> 79
      //
      // Exception table:
      //   from	to	target	type
      //   4	12	77	java/io/IOException
      //   18	35	77	java/io/IOException
      //   4	12	90	finally
      //   18	35	90	finally
      //   54	74	101	finally
      //   74	76	101	finally
      //   103	105	101	finally
      //   35	41	108	finally
      //   35	41	115	java/io/IOException
    }

    public void stopReading()
    {
      monitorenter;
      try
      {
        this.stopped = true;
        return;
      }
      finally
      {
        monitorexit;
      }
      throw localObject;
    }
  }

  public abstract class State
    implements Runnable
  {
    public State()
    {
    }

    public boolean isTerminal()
    {
      return false;
    }

    public void run()
    {
      State localState = runState();
      PushConnection.access$100(PushConnection.this, this, localState);
      if (isTerminal())
      {
        Parse.logI("com.parse.PushConnection", this + " finished and is the terminal state. Thread exiting.");
        PushConnection.this.executor.shutdown();
        return;
      }
      if (localState != null)
      {
        Parse.logI("com.parse.PushConnection", "PushConnection transitioning from " + this + " to " + localState);
        PushConnection.this.executor.execute(localState);
        return;
      }
      throw new NullPointerException(this + " tried to transition to null state.");
    }

    public abstract State runState();
  }

  public static abstract interface StateTransitionListener
  {
    public abstract void onStateChange(PushConnection paramPushConnection, PushConnection.State paramState1, PushConnection.State paramState2);
  }

  public class StoppedState extends PushConnection.State
  {
    public StoppedState()
    {
      super();
    }

    public boolean isTerminal()
    {
      return true;
    }

    public PushConnection.State runState()
    {
      return null;
    }
  }

  public class WaitRetryState extends PushConnection.State
  {
    private long delay;

    public WaitRetryState(long arg2)
    {
      super();
      Object localObject;
      this.delay = localObject;
    }

    public long getDelay()
    {
      return this.delay;
    }

    public PushConnection.State runState()
    {
      PushConnection.EventSet localEventSet1 = PushConnection.this.eventSet;
      PushConnection.Event[] arrayOfEvent1 = new PushConnection.Event[1];
      arrayOfEvent1[0] = PushConnection.Event.START;
      localEventSet1.removeEvents(arrayOfEvent1);
      long l = this.delay;
      if (!PushConnection.ENABLE_RETRY_DELAY)
        l = 0L;
      PushConnection.EventSet localEventSet2 = PushConnection.this.eventSet;
      PushConnection.Event[] arrayOfEvent2 = new PushConnection.Event[2];
      arrayOfEvent2[0] = PushConnection.Event.STOP;
      arrayOfEvent2[1] = PushConnection.Event.START;
      Set localSet = localEventSet2.timedAwait(l, arrayOfEvent2);
      if (localSet.contains(PushConnection.Event.STOP))
        return new PushConnection.StoppedState(PushConnection.this);
      if (localSet.contains(PushConnection.Event.START))
        return new PushConnection.ConnectState(PushConnection.this, 0L);
      return new PushConnection.ConnectState(PushConnection.this, this.delay);
    }
  }

  public class WaitStartState extends PushConnection.State
  {
    public WaitStartState()
    {
      super();
    }

    public PushConnection.State runState()
    {
      PushConnection.EventSet localEventSet = PushConnection.this.eventSet;
      PushConnection.Event[] arrayOfEvent = new PushConnection.Event[2];
      arrayOfEvent[0] = PushConnection.Event.START;
      arrayOfEvent[1] = PushConnection.Event.STOP;
      Set localSet = localEventSet.await(arrayOfEvent);
      PushConnection.StoppedState localStoppedState;
      if (localSet.contains(PushConnection.Event.STOP))
        localStoppedState = new PushConnection.StoppedState(PushConnection.this);
      boolean bool;
      do
      {
        return localStoppedState;
        bool = localSet.contains(PushConnection.Event.START);
        localStoppedState = null;
      }
      while (!bool);
      return new PushConnection.ConnectState(PushConnection.this, 0L);
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.PushConnection
 * JD-Core Version:    0.6.0
 */