package com.parse;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPOutputStream;

class HttpRequest
{
  public static final String POST_CONTENT_TYPE_FORM_URLENCODED = "application/x-www-form-urlencoded";
  public static final String POST_CONTENT_TYPE_JSON = "application/json";
  private HttpConnectionProvider mConnectionProvider;

  public HttpRequest(HttpConnectionProvider paramHttpConnectionProvider)
  {
    this.mConnectionProvider = paramHttpConnectionProvider;
  }

  public void sendPost(URL paramURL, String paramString, ACRAResponse paramACRAResponse)
    throws IOException
  {
    sendPost(paramURL, paramString, paramACRAResponse, "application/x-www-form-urlencoded");
  }

  public void sendPost(URL paramURL, String paramString1, ACRAResponse paramACRAResponse, String paramString2)
    throws IOException
  {
    HttpURLConnection localHttpURLConnection = this.mConnectionProvider.getConnection(paramURL);
    localHttpURLConnection.setRequestMethod("POST");
    localHttpURLConnection.setRequestProperty("User-Agent", "Android");
    localHttpURLConnection.setRequestProperty("Content-Type", paramString2);
    localHttpURLConnection.setRequestProperty("Content-Encoding", "gzip");
    localHttpURLConnection.setDoOutput(true);
    try
    {
      GZIPOutputStream localGZIPOutputStream = new GZIPOutputStream(localHttpURLConnection.getOutputStream());
      localGZIPOutputStream.write(paramString1.getBytes());
      localGZIPOutputStream.close();
      paramACRAResponse.setStatusCode(localHttpURLConnection.getResponseCode());
      localHttpURLConnection.getInputStream().close();
      return;
    }
    finally
    {
      localHttpURLConnection.disconnect();
    }
    throw localObject;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.HttpRequest
 * JD-Core Version:    0.6.0
 */