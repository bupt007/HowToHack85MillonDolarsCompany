package com.parse;

public abstract interface ConfigCallback extends ParseCallback2<ParseConfig, ParseException>
{
  public abstract void done(ParseConfig paramParseConfig, ParseException paramParseException);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ConfigCallback
 * JD-Core Version:    0.6.0
 */