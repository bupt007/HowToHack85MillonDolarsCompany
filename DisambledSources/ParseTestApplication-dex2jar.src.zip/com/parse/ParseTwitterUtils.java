package com.parse;

import android.content.Context;
import bolts.Task;
import com.parse.twitter.Twitter;
import org.json.JSONException;

public final class ParseTwitterUtils
{
  private static boolean isInitialized;
  private static TwitterAuthenticationProvider provider;
  private static Twitter twitter;

  private static void checkInitialization()
  {
    if (!isInitialized)
      throw new IllegalStateException("You must call ParseTwitterUtils.initialize() before using ParseTwitterUtils");
  }

  private static TwitterAuthenticationProvider getAuthenticationProvider()
  {
    if (provider == null)
    {
      provider = new TwitterAuthenticationProvider(getTwitter());
      ParseUser.registerAuthenticationProvider(provider);
    }
    return provider;
  }

  public static Twitter getTwitter()
  {
    if (twitter == null)
      twitter = new Twitter("", "");
    return twitter;
  }

  public static void initialize(String paramString1, String paramString2)
  {
    getTwitter().setConsumerKey(paramString1).setConsumerSecret(paramString2);
    getAuthenticationProvider();
    isInitialized = true;
  }

  public static boolean isLinked(ParseUser paramParseUser)
  {
    return paramParseUser.isLinked("twitter");
  }

  @Deprecated
  public static void link(ParseUser paramParseUser, Context paramContext)
  {
    link(paramParseUser, paramContext, null);
  }

  public static void link(ParseUser paramParseUser, Context paramContext, SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(linkInBackground(paramContext, paramParseUser), paramSaveCallback, true);
  }

  @Deprecated
  public static void link(ParseUser paramParseUser, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    link(paramParseUser, paramString1, paramString2, paramString3, paramString4, null);
  }

  public static void link(ParseUser paramParseUser, String paramString1, String paramString2, String paramString3, String paramString4, SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(linkInBackground(paramParseUser, paramString1, paramString2, paramString3, paramString4), paramSaveCallback);
  }

  public static Task<Void> linkInBackground(Context paramContext, ParseUser paramParseUser)
  {
    checkInitialization();
    return getAuthenticationProvider().setContext(paramContext).linkAsync(paramParseUser);
  }

  public static Task<Void> linkInBackground(ParseUser paramParseUser, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    checkInitialization();
    try
    {
      TwitterAuthenticationProvider localTwitterAuthenticationProvider = getAuthenticationProvider();
      Task localTask = localTwitterAuthenticationProvider.linkAsync(paramParseUser, localTwitterAuthenticationProvider.getAuthData(paramString1, paramString2, paramString3, paramString4));
      return localTask;
    }
    catch (JSONException localJSONException)
    {
    }
    return Task.forError(new ParseException(localJSONException));
  }

  public static void logIn(Context paramContext, LogInCallback paramLogInCallback)
  {
    Parse.callbackOnMainThreadAsync(logInInBackground(paramContext), paramLogInCallback, true);
  }

  public static void logIn(String paramString1, String paramString2, String paramString3, String paramString4, LogInCallback paramLogInCallback)
  {
    Parse.callbackOnMainThreadAsync(logInInBackground(paramString1, paramString2, paramString3, paramString4), paramLogInCallback);
  }

  public static Task<ParseUser> logInInBackground(Context paramContext)
  {
    checkInitialization();
    return getAuthenticationProvider().setContext(paramContext).logInAsync();
  }

  public static Task<ParseUser> logInInBackground(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    checkInitialization();
    try
    {
      TwitterAuthenticationProvider localTwitterAuthenticationProvider = getAuthenticationProvider();
      Task localTask = localTwitterAuthenticationProvider.logInAsync(localTwitterAuthenticationProvider.getAuthData(paramString1, paramString2, paramString3, paramString4));
      return localTask;
    }
    catch (JSONException localJSONException)
    {
    }
    return Task.forError(new ParseException(localJSONException));
  }

  public static void unlink(ParseUser paramParseUser)
    throws ParseException
  {
    Parse.waitForTask(unlinkInBackground(paramParseUser));
  }

  public static Task<Void> unlinkInBackground(ParseUser paramParseUser)
  {
    checkInitialization();
    return getAuthenticationProvider().unlinkAsync(paramParseUser);
  }

  public static void unlinkInBackground(ParseUser paramParseUser, SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(unlinkInBackground(paramParseUser), paramSaveCallback);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseTwitterUtils
 * JD-Core Version:    0.6.0
 */