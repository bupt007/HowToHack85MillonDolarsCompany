package com.parse;

import bolts.Continuation;
import bolts.Task;
import org.json.JSONObject;

abstract class ParseAuthenticationProvider
{
  public abstract Task<JSONObject> authenticateAsync();

  public abstract void cancel();

  public abstract void deauthenticate();

  public abstract String getAuthType();

  public Task<Void> linkAsync(ParseUser paramParseUser)
  {
    return authenticateAsync().onSuccessTask(new Continuation(paramParseUser)
    {
      public Task<Void> then(Task<JSONObject> paramTask)
        throws Exception
      {
        return ParseAuthenticationProvider.this.linkAsync(this.val$user, (JSONObject)paramTask.getResult());
      }
    });
  }

  public Task<Void> linkAsync(ParseUser paramParseUser, JSONObject paramJSONObject)
  {
    return paramParseUser.linkWithAsync(getAuthType(), paramJSONObject);
  }

  public Task<ParseUser> logInAsync()
  {
    return authenticateAsync().onSuccessTask(new Continuation()
    {
      public Task<ParseUser> then(Task<JSONObject> paramTask)
        throws Exception
      {
        return ParseAuthenticationProvider.this.logInAsync((JSONObject)paramTask.getResult());
      }
    });
  }

  public Task<ParseUser> logInAsync(JSONObject paramJSONObject)
  {
    return ParseUser.logInWithAsync(getAuthType(), paramJSONObject);
  }

  public abstract boolean restoreAuthentication(JSONObject paramJSONObject);

  public Task<Void> unlinkAsync(ParseUser paramParseUser)
  {
    return paramParseUser.unlinkFromAsync(getAuthType());
  }

  static abstract interface ParseAuthenticationCallback
  {
    public abstract void onCancel();

    public abstract void onError(Throwable paramThrowable);

    public abstract void onSuccess(JSONObject paramJSONObject);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseAuthenticationProvider
 * JD-Core Version:    0.6.0
 */