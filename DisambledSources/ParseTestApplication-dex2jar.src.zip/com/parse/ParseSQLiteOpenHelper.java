package com.parse;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import bolts.Task;

abstract class ParseSQLiteOpenHelper
{
  private final SQLiteOpenHelper helper;

  public ParseSQLiteOpenHelper(Context paramContext, String paramString, SQLiteDatabase.CursorFactory paramCursorFactory, int paramInt)
  {
    this.helper = new SQLiteOpenHelper(paramContext, paramString, paramCursorFactory, paramInt)
    {
      public void onCreate(SQLiteDatabase paramSQLiteDatabase)
      {
        ParseSQLiteOpenHelper.this.onCreate(paramSQLiteDatabase);
      }

      public void onOpen(SQLiteDatabase paramSQLiteDatabase)
      {
        super.onOpen(paramSQLiteDatabase);
        ParseSQLiteOpenHelper.this.onOpen(paramSQLiteDatabase);
      }

      public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
      {
        ParseSQLiteOpenHelper.this.onUpgrade(paramSQLiteDatabase, paramInt1, paramInt2);
      }
    };
  }

  private Task<ParseSQLiteDatabase> getDatabaseAsync(boolean paramBoolean)
  {
    SQLiteOpenHelper localSQLiteOpenHelper = this.helper;
    if (!paramBoolean);
    for (int i = 1; ; i = 0)
      return ParseSQLiteDatabase.openDatabaseAsync(localSQLiteOpenHelper, i);
  }

  public Task<ParseSQLiteDatabase> getReadableDatabaseAsync()
  {
    return getDatabaseAsync(false);
  }

  public Task<ParseSQLiteDatabase> getWritableDatabaseAsync()
  {
    return getDatabaseAsync(true);
  }

  public abstract void onCreate(SQLiteDatabase paramSQLiteDatabase);

  public void onOpen(SQLiteDatabase paramSQLiteDatabase)
  {
  }

  public abstract void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseSQLiteOpenHelper
 * JD-Core Version:    0.6.0
 */