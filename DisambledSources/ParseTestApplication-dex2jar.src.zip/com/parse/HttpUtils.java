package com.parse;

import java.io.IOException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONObject;

class HttpUtils
{
  public static void doPost(Map<?, ?> paramMap, URL paramURL)
    throws IOException
  {
    doPost(paramMap, paramURL, "application/x-www-form-urlencoded");
  }

  public static void doPost(Map<?, ?> paramMap, URL paramURL, String paramString)
    throws IOException
  {
    String str;
    if (paramString == "application/json")
    {
      str = encodeParametersJson(paramMap);
      if (!ACRA.getConfig().checkSSLCertsOnCrashReport())
        break label62;
    }
    label62: for (Object localObject = new SSLConnectionProvider(); ; localObject = new UnsafeConnectionProvider())
    {
      new HttpRequest((HttpConnectionProvider)localObject).sendPost(paramURL, str, new ACRAResponse(), paramString);
      return;
      str = encodeParametersFormUrlEncoded(paramMap);
      break;
    }
  }

  public static String encodeParametersFormUrlEncoded(Map<?, ?> paramMap)
    throws IOException
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = paramMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      if (localStringBuilder.length() != 0)
        localStringBuilder.append('&');
      Object localObject2 = paramMap.get(localObject1);
      if (localObject2 == null)
        localObject2 = "";
      localStringBuilder.append(URLEncoder.encode(localObject1.toString(), "UTF-8")).append('=').append(URLEncoder.encode(localObject2.toString(), "UTF-8"));
    }
    return (String)localStringBuilder.toString();
  }

  public static String encodeParametersJson(Map<?, ?> paramMap)
    throws IOException
  {
    return new JSONObject(paramMap).toString();
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.HttpUtils
 * JD-Core Version:    0.6.0
 */