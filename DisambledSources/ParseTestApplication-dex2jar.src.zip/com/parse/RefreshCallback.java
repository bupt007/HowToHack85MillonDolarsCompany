package com.parse;

public abstract interface RefreshCallback extends ParseCallback2<ParseObject, ParseException>
{
  public abstract void done(ParseObject paramParseObject, ParseException paramParseException);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.RefreshCallback
 * JD-Core Version:    0.6.0
 */