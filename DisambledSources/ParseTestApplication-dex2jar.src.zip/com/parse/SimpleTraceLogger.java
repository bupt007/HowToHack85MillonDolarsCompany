package com.parse;

import android.os.SystemClock;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

class SimpleTraceLogger
{
  public static int NO_LIMIT = 0;
  public static final String TAG = "SimpleTraceLogger";
  private Queue<TraceLogLine> mTrace;
  protected final int mTraceCountLimit;

  public SimpleTraceLogger(int paramInt)
  {
    this.mTraceCountLimit = paramInt;
    clear();
  }

  public void append(String paramString)
  {
    monitorenter;
    try
    {
      if ((this.mTraceCountLimit > NO_LIMIT) && (this.mTrace.size() == this.mTraceCountLimit))
        this.mTrace.remove();
      this.mTrace.offer(new TraceLogLine(paramString, SystemClock.elapsedRealtime()));
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void append(String paramString, Object[] paramArrayOfObject)
  {
    append(String.format(paramString, paramArrayOfObject));
  }

  public void clear()
  {
    monitorenter;
    try
    {
      this.mTrace = new LinkedList();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public String toString()
  {
    monitorenter;
    try
    {
      String str = toString(NO_LIMIT);
      monitorexit;
      return str;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public String toString(int paramInt)
  {
    monitorenter;
    while (true)
    {
      int j;
      try
      {
        StringBuilder localStringBuilder = new StringBuilder();
        if (paramInt > NO_LIMIT)
          continue;
        int i = 0;
        j = 0;
        Iterator localIterator = this.mTrace.iterator();
        if (!localIterator.hasNext())
          continue;
        TraceLogLine localTraceLogLine = (TraceLogLine)localIterator.next();
        if (j >= i)
        {
          localStringBuilder.append(localTraceLogLine.toString()).append('\n');
          break label117;
          i = Math.max(this.mTrace.size() - paramInt, 0);
          continue;
          String str = localStringBuilder.toString();
          return str;
        }
      }
      finally
      {
        monitorexit;
      }
      label117: j++;
    }
  }

  protected static class TraceLogLine
  {
    public final long time;
    public final String trace;

    TraceLogLine(String paramString, long paramLong)
    {
      this.trace = paramString;
      this.time = paramLong;
    }

    public String toString()
    {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Long.valueOf(this.time);
      arrayOfObject[1] = this.trace;
      return String.format("[%d] %s", arrayOfObject);
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.SimpleTraceLogger
 * JD-Core Version:    0.6.0
 */