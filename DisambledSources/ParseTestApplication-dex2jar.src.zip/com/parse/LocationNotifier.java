package com.parse;

import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import bolts.Capture;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

class LocationNotifier
{
  private static Location fakeLocation = null;

  static Task<Location> getCurrentLocationAsync(Context paramContext, long paramLong, Criteria paramCriteria)
  {
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    Capture localCapture = new Capture();
    LocationManager localLocationManager = (LocationManager)paramContext.getSystemService("location");
    1 local1 = new LocationListener(localCapture, localTaskCompletionSource, localLocationManager)
    {
      public void onLocationChanged(Location paramLocation)
      {
        if (paramLocation == null)
          return;
        ((ScheduledFuture)this.val$timeoutFuture.get()).cancel(true);
        this.val$tcs.trySetResult(paramLocation);
        this.val$manager.removeUpdates(this);
      }

      public void onProviderDisabled(String paramString)
      {
      }

      public void onProviderEnabled(String paramString)
      {
      }

      public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle)
      {
      }
    };
    localCapture.set(Parse.getScheduledExecutor().schedule(new Runnable(localTaskCompletionSource, localLocationManager, local1)
    {
      public void run()
      {
        this.val$tcs.trySetError(new ParseException(124, "Location fetch timed out."));
        this.val$manager.removeUpdates(this.val$listener);
      }
    }
    , paramLong, TimeUnit.MILLISECONDS));
    String str = localLocationManager.getBestProvider(paramCriteria, true);
    if (str != null)
      localLocationManager.requestLocationUpdates(str, 0L, 0.0F, local1);
    if (fakeLocation != null)
      local1.onLocationChanged(fakeLocation);
    return localTaskCompletionSource.getTask();
  }

  static void setFakeLocation(Location paramLocation)
  {
    fakeLocation = paramLocation;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.LocationNotifier
 * JD-Core Version:    0.6.0
 */