package com.parse;

class ReportSenderException extends Exception
{
  public ReportSenderException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ReportSenderException
 * JD-Core Version:    0.6.0
 */