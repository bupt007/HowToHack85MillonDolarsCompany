package com.parse;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

class ParseOperationSet extends HashMap<String, ParseFieldOperation>
{
  private static final String REST_KEY_IS_SAVE_EVENTUALLY = "__isSaveEventually";
  private static final String REST_KEY_UUID = "__uuid";
  private static final long serialVersionUID = 1L;
  private boolean isSaveEventually = false;
  private String uuid;

  public ParseOperationSet()
  {
    this.uuid = UUID.randomUUID().toString();
  }

  private ParseOperationSet(String paramString)
  {
    this.uuid = paramString;
  }

  public static ParseOperationSet fromRest(JSONObject paramJSONObject, ParseDecoder paramParseDecoder)
    throws JSONException
  {
    Iterator localIterator1 = paramJSONObject.keys();
    String[] arrayOfString = new String[paramJSONObject.length()];
    int j;
    for (int i = 0; localIterator1.hasNext(); i = j)
    {
      String str3 = (String)localIterator1.next();
      j = i + 1;
      arrayOfString[i] = str3;
    }
    JSONObject localJSONObject = new JSONObject(paramJSONObject, arrayOfString);
    String str1 = (String)localJSONObject.remove("__uuid");
    ParseOperationSet localParseOperationSet;
    label123: String str2;
    Object localObject1;
    if (str1 == null)
    {
      localParseOperationSet = new ParseOperationSet();
      boolean bool = localJSONObject.optBoolean("__isSaveEventually");
      localJSONObject.remove("__isSaveEventually");
      localParseOperationSet.setIsSaveEventually(bool);
      Iterator localIterator2 = localJSONObject.keys();
      if (!localIterator2.hasNext())
        break label237;
      str2 = (String)localIterator2.next();
      localObject1 = paramParseDecoder.decode(localJSONObject.get(str2));
      if (str2.equals("ACL"))
        localObject1 = ParseACL.createACLFromJSONObject(localJSONObject.getJSONObject(str2), paramParseDecoder);
      if (!(localObject1 instanceof ParseFieldOperation))
        break label223;
    }
    label223: for (Object localObject2 = (ParseFieldOperation)localObject1; ; localObject2 = new ParseSetOperation(localObject1))
    {
      localParseOperationSet.put(str2, localObject2);
      break label123;
      localParseOperationSet = new ParseOperationSet(str1);
      break;
    }
    label237: return (ParseOperationSet)(ParseOperationSet)localParseOperationSet;
  }

  public String getUUID()
  {
    return this.uuid;
  }

  public boolean isSaveEventually()
  {
    return this.isSaveEventually;
  }

  public void mergeFrom(ParseOperationSet paramParseOperationSet)
  {
    Iterator localIterator = paramParseOperationSet.keySet().iterator();
    if (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      ParseFieldOperation localParseFieldOperation1 = (ParseFieldOperation)paramParseOperationSet.get(str);
      ParseFieldOperation localParseFieldOperation2 = (ParseFieldOperation)get(str);
      if (localParseFieldOperation2 != null);
      for (ParseFieldOperation localParseFieldOperation3 = localParseFieldOperation2.mergeWithPrevious(localParseFieldOperation1); ; localParseFieldOperation3 = localParseFieldOperation1)
      {
        put(str, localParseFieldOperation3);
        break;
      }
    }
  }

  public void setIsSaveEventually(boolean paramBoolean)
  {
    this.isSaveEventually = paramBoolean;
  }

  public JSONObject toRest(ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject();
    Iterator localIterator = keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localJSONObject.put(str, ((ParseFieldOperation)get(str)).encode(paramParseObjectEncodingStrategy));
    }
    localJSONObject.put("__uuid", this.uuid);
    if (this.isSaveEventually)
      localJSONObject.put("__isSaveEventually", true);
    return localJSONObject;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseOperationSet
 * JD-Core Version:    0.6.0
 */