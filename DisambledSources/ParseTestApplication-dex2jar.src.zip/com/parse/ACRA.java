package com.parse;

import android.content.Context;
import android.util.Log;

class ACRA
{
  public static final ReportField[] ALL_CRASH_REPORT_FIELDS;
  public static final String LOG_TAG = "CrashReporting";
  public static final ReportField[] MINIMAL_REPORT_FIELDS;
  public static final String NULL_VALUE = "CR-NULL-STRING";
  private static ReportsCrashes mReportsCrashes;

  static
  {
    ReportField[] arrayOfReportField1 = new ReportField[53];
    arrayOfReportField1[0] = ReportField.REPORT_ID;
    arrayOfReportField1[1] = ReportField.APP_VERSION_CODE;
    arrayOfReportField1[2] = ReportField.APP_VERSION_NAME;
    arrayOfReportField1[3] = ReportField.APP_INSTALL_TIME;
    arrayOfReportField1[4] = ReportField.APP_UPGRADE_TIME;
    arrayOfReportField1[5] = ReportField.PACKAGE_NAME;
    arrayOfReportField1[6] = ReportField.FILE_PATH;
    arrayOfReportField1[7] = ReportField.PHONE_MODEL;
    arrayOfReportField1[8] = ReportField.BRAND;
    arrayOfReportField1[9] = ReportField.PRODUCT;
    arrayOfReportField1[10] = ReportField.ANDROID_VERSION;
    arrayOfReportField1[11] = ReportField.OS_VERSION;
    arrayOfReportField1[12] = ReportField.BUILD;
    arrayOfReportField1[13] = ReportField.TOTAL_MEM_SIZE;
    arrayOfReportField1[14] = ReportField.IS_CYANOGENMOD;
    arrayOfReportField1[15] = ReportField.AVAILABLE_MEM_SIZE;
    arrayOfReportField1[16] = ReportField.CUSTOM_DATA;
    arrayOfReportField1[17] = ReportField.STACK_TRACE;
    arrayOfReportField1[18] = ReportField.CRASH_CONFIGURATION;
    arrayOfReportField1[19] = ReportField.DISPLAY;
    arrayOfReportField1[20] = ReportField.USER_APP_START_DATE;
    arrayOfReportField1[21] = ReportField.USER_CRASH_DATE;
    arrayOfReportField1[22] = ReportField.DUMPSYS_MEMINFO;
    arrayOfReportField1[23] = ReportField.DROPBOX;
    arrayOfReportField1[24] = ReportField.LOGCAT;
    arrayOfReportField1[25] = ReportField.EVENTSLOG;
    arrayOfReportField1[26] = ReportField.RADIOLOG;
    arrayOfReportField1[27] = ReportField.DEVICE_ID;
    arrayOfReportField1[28] = ReportField.INSTALLATION_ID;
    arrayOfReportField1[29] = ReportField.DEVICE_FEATURES;
    arrayOfReportField1[30] = ReportField.ENVIRONMENT;
    arrayOfReportField1[31] = ReportField.SETTINGS_SYSTEM;
    arrayOfReportField1[32] = ReportField.SETTINGS_SECURE;
    arrayOfReportField1[33] = ReportField.PROCESS_NAME;
    arrayOfReportField1[34] = ReportField.PROCESS_NAME_BY_AMS;
    arrayOfReportField1[35] = ReportField.ACTIVITY_LOG;
    arrayOfReportField1[36] = ReportField.JAIL_BROKEN;
    arrayOfReportField1[37] = ReportField.PROCESS_UPTIME;
    arrayOfReportField1[38] = ReportField.DEVICE_UPTIME;
    arrayOfReportField1[39] = ReportField.ACRA_REPORT_FILENAME;
    arrayOfReportField1[40] = ReportField.EXCEPTION_CAUSE;
    arrayOfReportField1[41] = ReportField.REPORT_LOAD_THROW;
    arrayOfReportField1[42] = ReportField.MINIDUMP;
    arrayOfReportField1[43] = ReportField.ANDROID_ID;
    arrayOfReportField1[44] = ReportField.UID;
    arrayOfReportField1[45] = ReportField.UPLOADED_BY_PROCESS;
    arrayOfReportField1[46] = ReportField.OPEN_FD_COUNT;
    arrayOfReportField1[47] = ReportField.OPEN_FD_SOFT_LIMIT;
    arrayOfReportField1[48] = ReportField.OPEN_FD_HARD_LIMIT;
    arrayOfReportField1[49] = ReportField.IS_LOW_RAM_DEVICE;
    arrayOfReportField1[50] = ReportField.SIGQUIT;
    arrayOfReportField1[51] = ReportField.LARGE_MEM_HEAP;
    arrayOfReportField1[52] = ReportField.ANDROID_RUNTIME;
    ALL_CRASH_REPORT_FIELDS = arrayOfReportField1;
    ReportField[] arrayOfReportField2 = new ReportField[49];
    arrayOfReportField2[0] = ReportField.REPORT_ID;
    arrayOfReportField2[1] = ReportField.APP_VERSION_CODE;
    arrayOfReportField2[2] = ReportField.APP_VERSION_NAME;
    arrayOfReportField2[3] = ReportField.APP_INSTALL_TIME;
    arrayOfReportField2[4] = ReportField.APP_UPGRADE_TIME;
    arrayOfReportField2[5] = ReportField.PACKAGE_NAME;
    arrayOfReportField2[6] = ReportField.FILE_PATH;
    arrayOfReportField2[7] = ReportField.PHONE_MODEL;
    arrayOfReportField2[8] = ReportField.BRAND;
    arrayOfReportField2[9] = ReportField.PRODUCT;
    arrayOfReportField2[10] = ReportField.ANDROID_VERSION;
    arrayOfReportField2[11] = ReportField.OS_VERSION;
    arrayOfReportField2[12] = ReportField.BUILD;
    arrayOfReportField2[13] = ReportField.TOTAL_MEM_SIZE;
    arrayOfReportField2[14] = ReportField.IS_CYANOGENMOD;
    arrayOfReportField2[15] = ReportField.AVAILABLE_MEM_SIZE;
    arrayOfReportField2[16] = ReportField.CUSTOM_DATA;
    arrayOfReportField2[17] = ReportField.STACK_TRACE;
    arrayOfReportField2[18] = ReportField.CRASH_CONFIGURATION;
    arrayOfReportField2[19] = ReportField.DISPLAY;
    arrayOfReportField2[20] = ReportField.USER_APP_START_DATE;
    arrayOfReportField2[21] = ReportField.USER_CRASH_DATE;
    arrayOfReportField2[22] = ReportField.DUMPSYS_MEMINFO;
    arrayOfReportField2[23] = ReportField.DROPBOX;
    arrayOfReportField2[24] = ReportField.LOGCAT;
    arrayOfReportField2[25] = ReportField.EVENTSLOG;
    arrayOfReportField2[26] = ReportField.RADIOLOG;
    arrayOfReportField2[27] = ReportField.DEVICE_ID;
    arrayOfReportField2[28] = ReportField.INSTALLATION_ID;
    arrayOfReportField2[29] = ReportField.DEVICE_FEATURES;
    arrayOfReportField2[30] = ReportField.ENVIRONMENT;
    arrayOfReportField2[31] = ReportField.SETTINGS_SYSTEM;
    arrayOfReportField2[32] = ReportField.SETTINGS_SECURE;
    arrayOfReportField2[33] = ReportField.PROCESS_NAME;
    arrayOfReportField2[34] = ReportField.PROCESS_NAME_BY_AMS;
    arrayOfReportField2[35] = ReportField.ACTIVITY_LOG;
    arrayOfReportField2[36] = ReportField.JAIL_BROKEN;
    arrayOfReportField2[37] = ReportField.PROCESS_UPTIME;
    arrayOfReportField2[38] = ReportField.DEVICE_UPTIME;
    arrayOfReportField2[39] = ReportField.ACRA_REPORT_FILENAME;
    arrayOfReportField2[40] = ReportField.EXCEPTION_CAUSE;
    arrayOfReportField2[41] = ReportField.REPORT_LOAD_THROW;
    arrayOfReportField2[42] = ReportField.MINIDUMP;
    arrayOfReportField2[43] = ReportField.ANDROID_ID;
    arrayOfReportField2[44] = ReportField.UID;
    arrayOfReportField2[45] = ReportField.UPLOADED_BY_PROCESS;
    arrayOfReportField2[46] = ReportField.IS_LOW_RAM_DEVICE;
    arrayOfReportField2[47] = ReportField.LARGE_MEM_HEAP;
    arrayOfReportField2[48] = ReportField.ANDROID_RUNTIME;
    MINIMAL_REPORT_FIELDS = arrayOfReportField2;
  }

  public static ReportsCrashes getConfig()
  {
    return mReportsCrashes;
  }

  public static ErrorReporter init(ReportsCrashes paramReportsCrashes, String paramString, boolean paramBoolean, FileProvider paramFileProvider)
  {
    ErrorReporter localErrorReporter = ErrorReporter.getInstance();
    if (mReportsCrashes == null)
    {
      mReportsCrashes = paramReportsCrashes;
      Context localContext = mReportsCrashes.getApplicationContext();
      Log.d("CrashReporting", "Crash reporting is enabled for " + localContext.getPackageName() + ", initializing...");
      localErrorReporter.init(localContext, paramBoolean, paramFileProvider);
      Thread.setDefaultUncaughtExceptionHandler(localErrorReporter);
      if (paramString != null)
        localErrorReporter.setReportSender(new HttpPostSender(paramString));
      localErrorReporter.checkReportsOnApplicationStart();
    }
    return localErrorReporter;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ACRA
 * JD-Core Version:    0.6.0
 */