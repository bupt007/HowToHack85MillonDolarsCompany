package com.parse;

import android.app.Activity;
import android.content.Context;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

class PushRoutes
{
  private static final Pattern CHANNEL_PATTERN = Pattern.compile("^$|^[a-zA-Z][A-Za-z0-9_-]*$");
  private static final String TAG = "com.parse.PushRoutes";
  private final HashMap<String, Route> channels = new HashMap();

  public PushRoutes(JSONObject paramJSONObject)
  {
    if (paramJSONObject != null)
    {
      JSONObject localJSONObject1 = paramJSONObject.optJSONObject("routes");
      if (localJSONObject1 != null)
      {
        Iterator localIterator = localJSONObject1.keys();
        while (localIterator.hasNext())
        {
          String str = (String)localIterator.next();
          Route localRoute2 = Route.newFromJSON(localJSONObject1.optJSONObject(str));
          if ((str == null) || (localRoute2 == null))
            continue;
          put(str, localRoute2);
        }
      }
      JSONObject localJSONObject2 = paramJSONObject.optJSONObject("defaultRoute");
      if (localJSONObject2 != null)
      {
        Route localRoute1 = Route.newFromJSON(localJSONObject2);
        if (localRoute1 != null)
          put(null, localRoute1);
      }
    }
  }

  public static boolean isValidChannelName(String paramString)
  {
    monitorenter;
    try
    {
      boolean bool = CHANNEL_PATTERN.matcher(paramString).matches();
      monitorexit;
      return bool;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public Route get(String paramString)
  {
    return (Route)this.channels.get(paramString);
  }

  public Set<String> getChannels()
  {
    return Collections.unmodifiableSet(this.channels.keySet());
  }

  public Route put(String paramString, Route paramRoute)
  {
    if (paramRoute == null)
      throw new IllegalArgumentException("Can't insert null route");
    if ((paramString != null) && (!isValidChannelName(paramString)))
      throw new IllegalArgumentException("invalid channel name: " + paramString);
    return (Route)this.channels.put(paramString, paramRoute);
  }

  public Route remove(String paramString)
  {
    return (Route)this.channels.remove(paramString);
  }

  public JSONObject toJSON()
    throws JSONException
  {
    JSONObject localJSONObject1 = new JSONObject();
    JSONObject localJSONObject2 = new JSONObject();
    Iterator localIterator = this.channels.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str = (String)localEntry.getKey();
      Route localRoute = (Route)localEntry.getValue();
      if (str == null)
      {
        localJSONObject1.put("defaultRoute", localRoute.toJSON());
        continue;
      }
      localJSONObject2.put(str, localRoute.toJSON());
    }
    localJSONObject1.put("routes", localJSONObject2);
    return localJSONObject1;
  }

  public static final class Route
  {
    private final String activityClassName;
    private final int iconId;

    public Route(String paramString, int paramInt)
    {
      if (paramString == null)
        throw new IllegalArgumentException("activityClassName can't be null");
      if (paramInt == 0)
        throw new IllegalArgumentException("iconId can't be 0");
      this.activityClassName = paramString;
      this.iconId = paramInt;
    }

    public static Route newFromJSON(JSONObject paramJSONObject)
    {
      String str = null;
      int i = 0;
      if (paramJSONObject != null)
      {
        JSONObject localJSONObject = paramJSONObject.optJSONObject("data");
        str = null;
        i = 0;
        if (localJSONObject != null)
        {
          str = localJSONObject.optString("activityClass", null);
          i = localJSONObject.optInt("icon", 0);
        }
      }
      Route localRoute = null;
      if (str != null)
      {
        localRoute = null;
        if (i != 0)
          localRoute = new Route(str, i);
      }
      return localRoute;
    }

    public boolean equals(Object paramObject)
    {
      int i = 0;
      if (paramObject != null)
      {
        boolean bool = paramObject instanceof Route;
        i = 0;
        if (bool)
        {
          Route localRoute = (Route)paramObject;
          if ((!this.activityClassName.equals(localRoute.activityClassName)) || (this.iconId != localRoute.iconId))
            break label54;
          i = 1;
        }
      }
      return i;
      label54: return false;
    }

    public Class<? extends Activity> getActivityClass()
    {
      try
      {
        Class localClass2 = Class.forName(this.activityClassName);
        localClass1 = localClass2;
        if ((localClass1 != null) && (!Activity.class.isAssignableFrom(localClass1)))
          localClass1 = null;
        if (localClass1 == null)
          Parse.logE("com.parse.PushRoutes", "Activity class " + this.activityClassName + " registered to handle push no " + "longer exists. Call PushService.subscribe with an activity class that does exist.");
        return localClass1;
      }
      catch (ClassNotFoundException localClassNotFoundException)
      {
        while (true)
          Class localClass1 = null;
      }
    }

    public int getIconId()
    {
      return this.iconId;
    }

    public int hashCode()
    {
      return 31 * (31 + this.activityClassName.hashCode()) + this.iconId;
    }

    public JSONObject toJSON()
      throws JSONException
    {
      JSONObject localJSONObject1 = new JSONObject();
      JSONObject localJSONObject2 = new JSONObject();
      localJSONObject2.put("appName", ManifestInfo.getDisplayName());
      localJSONObject2.put("activityPackage", Parse.applicationContext.getPackageName());
      localJSONObject2.put("activityClass", this.activityClassName);
      localJSONObject2.put("icon", this.iconId);
      localJSONObject1.put("data", localJSONObject2);
      localJSONObject1.put("name", "com.parse.StandardPushCallback");
      return localJSONObject1;
    }

    public String toString()
    {
      return super.toString() + " (activityClassName: " + this.activityClassName + " iconId: " + this.iconId + ")";
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.PushRoutes
 * JD-Core Version:    0.6.0
 */