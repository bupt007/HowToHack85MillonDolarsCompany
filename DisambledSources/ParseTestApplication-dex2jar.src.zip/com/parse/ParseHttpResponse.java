package com.parse;

import java.io.IOException;
import java.io.InputStream;
import org.apache.http.HttpResponse;

abstract class ParseHttpResponse
{
  public static ParseHttpResponse createParseApacheHttpResponse(HttpResponse paramHttpResponse)
  {
    return new ParseApacheHttpResponse(paramHttpResponse);
  }

  public abstract InputStream getContent()
    throws IOException;

  public abstract String getReasonPhrase();

  public abstract int getStatusCode();

  public abstract int getTotalSize();
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseHttpResponse
 * JD-Core Version:    0.6.0
 */