package com.parse;

import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.IBinder;
import bolts.Capture;
import bolts.Continuation;
import bolts.Task;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class PushService extends Service
{
  static final String CANNOT_USE_PUSH_V1_ERROR_MESSAGE = "PushService.subscribe, PushService.unsubscribe, and PushService.setDefaultPushCallback methods cannot be used in conjunction with ParsePushBroadcastReceiver. See ParsePush.subscribe and ParsePush.unsubscribe.";
  private static final String START_IF_REQUIRED_ACTION = "com.parse.PushService.startIfRequired";
  private static final String TAG = "com.parse.PushService";
  private static final int WAKE_LOCK_TIMEOUT_MS = 20000;
  private static String host = "push.parse.com";
  private static boolean loggedStartError;
  private static int port = 443;
  private static List<ServiceLifecycleCallbacks> serviceLifecycleCallbacks;
  private PushConnection connection;
  private ExecutorService executor;

  static
  {
    loggedStartError = false;
    serviceLifecycleCallbacks = null;
  }

  private static void checkManifestAndThrowExceptionIfNeeded()
  {
    if (ManifestInfo.getPushUsesBroadcastReceivers())
      throw new IllegalStateException("PushService.subscribe, PushService.unsubscribe, and PushService.setDefaultPushCallback methods cannot be used in conjunction with ParsePushBroadcastReceiver. See ParsePush.subscribe and ParsePush.unsubscribe.");
  }

  private static Object[] collectServiceLifecycleCallbacks()
  {
    monitorenter;
    try
    {
      if (serviceLifecycleCallbacks == null)
        return null;
      int i = serviceLifecycleCallbacks.size();
      Object[] arrayOfObject = null;
      if (i > 0)
        arrayOfObject = serviceLifecycleCallbacks.toArray();
      return arrayOfObject;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  private static void dispatchOnServiceCreated(Service paramService)
  {
    Object[] arrayOfObject = collectServiceLifecycleCallbacks();
    if (arrayOfObject != null)
    {
      int i = arrayOfObject.length;
      for (int j = 0; j < i; j++)
        ((ServiceLifecycleCallbacks)arrayOfObject[j]).onServiceCreated(paramService);
    }
  }

  private static void dispatchOnServiceDestroyed(Service paramService)
  {
    Object[] arrayOfObject = collectServiceLifecycleCallbacks();
    if (arrayOfObject != null)
    {
      int i = arrayOfObject.length;
      for (int j = 0; j < i; j++)
        ((ServiceLifecycleCallbacks)arrayOfObject[j]).onServiceDestroyed(paramService);
    }
  }

  @Deprecated
  public static Set<String> getSubscriptions(Context paramContext)
  {
    try
    {
      Set localSet = (Set)Parse.waitForTask(PushRouter.getSubscriptionsAsync(false));
      return localSet;
    }
    catch (ParseException localParseException)
    {
    }
    throw new RuntimeException(localParseException);
  }

  private int onGcmStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    this.executor.execute(new Runnable(paramIntent, paramInt2)
    {
      public void run()
      {
        try
        {
          PushService.this.onHandleGcmIntent(this.val$intent);
          return;
        }
        finally
        {
          ServiceUtils.completeWakefulIntent(this.val$intent);
          PushService.this.stopSelf(this.val$startId);
        }
        throw localObject;
      }
    });
    return 2;
  }

  private void onHandleGcmIntent(Intent paramIntent)
  {
    if (paramIntent != null)
    {
      GcmRegistrar localGcmRegistrar = GcmRegistrar.getInstance();
      if (localGcmRegistrar.isRegistrationIntent(paramIntent))
        localGcmRegistrar.handleRegistrationIntent(paramIntent);
    }
    else
    {
      return;
    }
    if (PushRouter.isGcmPushIntent(paramIntent))
    {
      PushRouter.handleGcmPushIntent(paramIntent);
      return;
    }
    Parse.logE("com.parse.PushService", "PushService got unknown intent in GCM mode: " + paramIntent);
  }

  private int onPpnsStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    PushConnection localPushConnection = this.connection;
    if ((paramIntent == null) || (paramIntent.getAction() == null) || (paramIntent.getAction().equals("com.parse.PushService.startIfRequired")))
    {
      Parse.logI("com.parse.PushService", "Received request to start service if required");
      Capture localCapture = new Capture();
      PushRouter.getForceEnabledStateAsync().onSuccessTask(new Continuation(localCapture)
      {
        public Task<Set<String>> then(Task<Boolean> paramTask)
          throws Exception
        {
          this.val$forceEnabledCapture.set(paramTask.getResult());
          return PushRouter.getSubscriptionsAsync(true);
        }
      }).onSuccess(new Continuation(localCapture, localPushConnection)
      {
        public Void then(Task<Set<String>> paramTask)
          throws Exception
        {
          Boolean localBoolean = (Boolean)this.val$forceEnabledCapture.get();
          boolean bool1 = ManifestInfo.getPushUsesBroadcastReceivers();
          Set localSet = (Set)paramTask.getResult();
          String str;
          if (!bool1)
          {
            str = null;
            if (localSet != null)
            {
              int i = localSet.size();
              str = null;
              if (i == 0)
                str = "Not starting PushService because this device has no subscriptions";
            }
            if (str == null)
              break label122;
            Parse.logI("com.parse.PushService", str);
            PushService.this.stopSelf();
          }
          while (true)
          {
            return null;
            if (ParseInstallation.getCurrentInstallation().getObjectId() == null)
            {
              str = "Not starting PushService because this device is not registered for push notifications.";
              break;
            }
            str = null;
            if (localBoolean == null)
              break;
            boolean bool2 = localBoolean.booleanValue();
            str = null;
            if (bool2)
              break;
            str = "Not starting PushService because push has been manually disabled.";
            break;
            label122: Parse.logD("com.parse.PushService", "Starting PushService.");
            this.val$conn.start();
          }
        }
      });
    }
    return 1;
  }

  static void registerServiceLifecycleCallbacks(ServiceLifecycleCallbacks paramServiceLifecycleCallbacks)
  {
    monitorenter;
    try
    {
      if (serviceLifecycleCallbacks == null)
        serviceLifecycleCallbacks = new ArrayList();
      serviceLifecycleCallbacks.add(paramServiceLifecycleCallbacks);
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  static void runGcmIntentInService(Context paramContext, Intent paramIntent)
  {
    ServiceUtils.runWakefulIntentInService(paramContext, paramIntent, PushService.class, 20000L);
  }

  @Deprecated
  public static void setDefaultPushCallback(Context paramContext, Class<? extends Activity> paramClass)
  {
    setDefaultPushCallback(paramContext, paramClass, paramContext.getApplicationInfo().icon);
  }

  @Deprecated
  public static void setDefaultPushCallback(Context paramContext, Class<? extends Activity> paramClass, int paramInt)
  {
    if (paramInt == 0)
      throw new IllegalArgumentException("Must subscribe to channel with a valid icon identifier.");
    if (paramClass == null)
    {
      unsubscribeInternal(null);
      return;
    }
    PushRouter.subscribeAsync(null, paramClass, paramInt).onSuccess(new Continuation()
    {
      public Void then(Task<Void> paramTask)
      {
        PushService.startServiceIfRequired(Parse.applicationContext);
        return null;
      }
    });
  }

  private static void startPpnsServiceIfRequired(Context paramContext)
  {
    if (ManifestInfo.getPushType() == PushType.PPNS)
    {
      ParseInstallation localParseInstallation = ParseInstallation.getCurrentInstallation();
      if (localParseInstallation.getPushType() == PushType.GCM)
      {
        Parse.logW("com.parse.PushService", "Detected a client that used to use GCM and is now using PPNS.");
        localParseInstallation.removePushType();
        localParseInstallation.removeDeviceToken();
        localParseInstallation.saveEventually();
      }
      ServiceUtils.runIntentInService(paramContext, new Intent("com.parse.PushService.startIfRequired"), PushService.class);
    }
  }

  public static void startServiceIfRequired(Context paramContext)
  {
    switch (8.$SwitchMap$com$parse$PushType[ManifestInfo.getPushType().ordinal()])
    {
    default:
      if (!loggedStartError)
      {
        Parse.logE("com.parse.PushService", "Tried to use push, but this app is not configured for push due to: " + ManifestInfo.getNonePushTypeLogMessage());
        loggedStartError = true;
      }
      return;
    case 1:
      startPpnsServiceIfRequired(paramContext);
      return;
    case 2:
    }
    GcmRegistrar.getInstance().register();
  }

  static void stopPpnsService(Context paramContext)
  {
    if (ManifestInfo.getPushType() == PushType.PPNS)
      paramContext.stopService(new Intent(paramContext, PushService.class));
  }

  @Deprecated
  public static void subscribe(Context paramContext, String paramString, Class<? extends Activity> paramClass)
  {
    subscribe(paramContext, paramString, paramClass, paramContext.getApplicationInfo().icon);
  }

  @Deprecated
  public static void subscribe(Context paramContext, String paramString, Class<? extends Activity> paramClass, int paramInt)
  {
    monitorenter;
    try
    {
      checkManifestAndThrowExceptionIfNeeded();
      if (paramString == null)
        throw new IllegalArgumentException("Can't subscribe to null channel.");
    }
    finally
    {
      monitorexit;
    }
    PushRouter.subscribeAsync(paramString, paramClass, paramInt).onSuccess(new Continuation()
    {
      public Void then(Task<Void> paramTask)
      {
        PushService.startServiceIfRequired(Parse.applicationContext);
        return null;
      }
    });
    monitorexit;
  }

  static void unregisterServiceLifecycleCallbacks(ServiceLifecycleCallbacks paramServiceLifecycleCallbacks)
  {
    monitorenter;
    try
    {
      serviceLifecycleCallbacks.remove(paramServiceLifecycleCallbacks);
      if (serviceLifecycleCallbacks.size() <= 0)
        serviceLifecycleCallbacks = null;
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  @Deprecated
  public static void unsubscribe(Context paramContext, String paramString)
  {
    monitorenter;
    if (paramString == null)
      try
      {
        throw new IllegalArgumentException("Can't unsubscribe from null channel.");
      }
      finally
      {
        monitorexit;
      }
    unsubscribeInternal(paramString);
    monitorexit;
  }

  private static void unsubscribeInternal(String paramString)
  {
    checkManifestAndThrowExceptionIfNeeded();
    PushRouter.unsubscribeAsync(paramString).onSuccessTask(new Continuation()
    {
      public Task<Set<String>> then(Task<Void> paramTask)
      {
        return PushRouter.getSubscriptionsAsync(true);
      }
    }).onSuccess(new Continuation()
    {
      public Void then(Task<Set<String>> paramTask)
      {
        if (((Set)paramTask.getResult()).size() == 0)
          PushService.stopPpnsService(Parse.applicationContext);
        return null;
      }
    });
  }

  static void useServer(String paramString, int paramInt)
  {
    host = paramString;
    port = paramInt;
  }

  private void wipeRoutingAndUpgradePushStateIfNeeded()
  {
    if (ManifestInfo.getPushUsesBroadcastReceivers())
      PushRouter.wipeRoutingAndUpgradePushStateAsync();
  }

  public IBinder onBind(Intent paramIntent)
  {
    throw new IllegalArgumentException("You cannot bind directly to the PushService. Use PushService.subscribe instead.");
  }

  public void onCreate()
  {
    super.onCreate();
    if (Parse.applicationContext == null)
    {
      Parse.logE("com.parse.PushService", "The Parse push service cannot start because Parse.initialize has not yet been called. If you call Parse.initialize from an Activity's onCreate, that call should instead be in the Application.onCreate. Be sure your Application class is registered in your AndroidManifest.xml with the android:name property of your <application> tag.");
      stopSelf();
      return;
    }
    switch (8.$SwitchMap$com$parse$PushType[ManifestInfo.getPushType().ordinal()])
    {
    default:
      Parse.logE("com.parse.PushService", "PushService somehow started even though this device doesn't support push.");
    case 1:
    case 2:
    }
    while (true)
    {
      dispatchOnServiceCreated(this);
      return;
      this.connection = new PushConnection(this, host, port);
      continue;
      this.executor = Executors.newSingleThreadExecutor();
    }
  }

  public void onDestroy()
  {
    if (this.connection != null)
      this.connection.stop();
    if (this.executor != null)
      this.executor.shutdown();
    dispatchOnServiceDestroyed(this);
    super.onDestroy();
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    wipeRoutingAndUpgradePushStateIfNeeded();
    switch (8.$SwitchMap$com$parse$PushType[ManifestInfo.getPushType().ordinal()])
    {
    default:
      Parse.logE("com.parse.PushService", "Started push service even though no push service is enabled: " + paramIntent);
      ServiceUtils.completeWakefulIntent(paramIntent);
      return 2;
    case 1:
      return onPpnsStartCommand(paramIntent, paramInt1, paramInt2);
    case 2:
    }
    return onGcmStartCommand(paramIntent, paramInt1, paramInt2);
  }

  static abstract interface ServiceLifecycleCallbacks
  {
    public abstract void onServiceCreated(Service paramService);

    public abstract void onServiceDestroyed(Service paramService);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.PushService
 * JD-Core Version:    0.6.0
 */