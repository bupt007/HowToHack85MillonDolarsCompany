package com.parse;

import android.content.Intent;
import android.os.Bundle;
import bolts.Capture;
import bolts.Continuation;
import bolts.Task;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.json.JSONException;
import org.json.JSONObject;

public class ParseAnalytics
{
  private static final String TAG = "com.parse.ParseAnalytics";
  private static final Map<String, Boolean> lruSeenPushes = new LinkedHashMap()
  {
    protected boolean removeEldestEntry(Map.Entry<String, Boolean> paramEntry)
    {
      return size() > 10;
    }
  };

  static void clear()
  {
    synchronized (lruSeenPushes)
    {
      lruSeenPushes.clear();
      return;
    }
  }

  @Deprecated
  public static void trackAppOpened(Intent paramIntent)
  {
    trackAppOpenedInBackground(paramIntent);
  }

  public static Task<Void> trackAppOpenedInBackground(Intent paramIntent)
  {
    String str1 = null;
    if (paramIntent != null)
    {
      Bundle localBundle = paramIntent.getExtras();
      str1 = null;
      if (localBundle != null)
        str1 = paramIntent.getExtras().getString("com.parse.Data");
    }
    Capture localCapture = new Capture();
    if (str1 != null);
    try
    {
      String str2 = new JSONObject(str1).optString("push_hash");
      if (str2.length() > 0);
      synchronized (lruSeenPushes)
      {
        if (lruSeenPushes.containsKey(str2))
        {
          Task localTask = Task.forResult(null);
          return localTask;
        }
        lruSeenPushes.put(str2, Boolean.valueOf(true));
        localCapture.set(str2);
        return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation(localCapture)
        {
          public Task<Void> then(Task<String> paramTask)
            throws Exception
          {
            String str = (String)paramTask.getResult();
            ParseRESTAnalyticsCommand localParseRESTAnalyticsCommand = ParseRESTAnalyticsCommand.trackAppOpenedCommand((String)this.val$pushHash.get(), str);
            return Parse.getEventuallyQueue().enqueueEventuallyAsync(localParseRESTAnalyticsCommand, null).makeVoid();
          }
        });
      }
    }
    catch (JSONException localJSONException)
    {
      while (true)
        Parse.logE("com.parse.ParseAnalytics", "Failed to parse push data: " + localJSONException.getMessage());
    }
  }

  public static void trackAppOpenedInBackground(Intent paramIntent, SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(trackAppOpenedInBackground(paramIntent), paramSaveCallback);
  }

  @Deprecated
  public static void trackEvent(String paramString)
  {
    trackEventInBackground(paramString);
  }

  @Deprecated
  public static void trackEvent(String paramString, Map<String, String> paramMap)
  {
    trackEventInBackground(paramString, paramMap);
  }

  public static Task<Void> trackEventInBackground(String paramString)
  {
    return trackEventInBackground(paramString, (Map)null);
  }

  public static Task<Void> trackEventInBackground(String paramString, Map<String, String> paramMap)
  {
    if ((paramString == null) || (paramString.trim().length() == 0))
      throw new RuntimeException("A name for the custom event must be provided.");
    if (paramMap != null);
    for (JSONObject localJSONObject = (JSONObject)Parse.encode(paramMap, NoObjectsEncodingStrategy.get()); ; localJSONObject = null)
      return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation(paramString, localJSONObject)
      {
        public Task<Void> then(Task<String> paramTask)
          throws Exception
        {
          String str = (String)paramTask.getResult();
          ParseRESTAnalyticsCommand localParseRESTAnalyticsCommand = ParseRESTAnalyticsCommand.trackEventCommand(this.val$name, this.val$jsonDimensions, str);
          return Parse.getEventuallyQueue().enqueueEventuallyAsync(localParseRESTAnalyticsCommand, null).makeVoid();
        }
      });
  }

  public static void trackEventInBackground(String paramString, SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(trackEventInBackground(paramString), paramSaveCallback);
  }

  public static void trackEventInBackground(String paramString, Map<String, String> paramMap, SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(trackEventInBackground(paramString, paramMap), paramSaveCallback);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseAnalytics
 * JD-Core Version:    0.6.0
 */