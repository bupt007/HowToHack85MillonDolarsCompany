package com.parse;

public abstract interface LogOutCallback extends ParseCallback1<ParseException>
{
  public abstract void done(ParseException paramParseException);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.LogOutCallback
 * JD-Core Version:    0.6.0
 */