package com.parse;

import bolts.Continuation;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ParseQuery<T extends ParseObject>
{
  private static final String TAG = "com.parse.ParseQuery";
  private CachePolicy cachePolicy;
  private String className;
  private Task<Void>.TaskCompletionSource ct;
  private HashMap<String, Object> extraOptions = null;
  boolean ignoreACLs;
  private ArrayList<String> include;
  boolean includeIsDeletingEventually;
  private boolean isFromLocalDatastore;
  private boolean isRunning = false;
  private final Object isRunningLock = new Object();
  private int limit;
  private long maxCacheAge;
  private long objectsParsed;
  private String order;
  private String pinName;
  private long queryReceived;
  private long querySent;
  private long queryStart;
  private ArrayList<String> selectedKeys;
  private int skip;
  private boolean trace;
  private QueryConstraints where;

  public ParseQuery(Class<T> paramClass)
  {
    this(ParseObject.getClassName(paramClass));
  }

  public ParseQuery(String paramString)
  {
    this.className = paramString;
    this.limit = -1;
    this.skip = 0;
    this.where = new QueryConstraints();
    this.include = new ArrayList();
    this.cachePolicy = CachePolicy.IGNORE_CACHE;
    this.isFromLocalDatastore = false;
    this.maxCacheAge = 9223372036854775807L;
    this.trace = false;
    this.extraOptions = new HashMap();
  }

  private ParseQuery<T> addCondition(String paramString1, String paramString2, Object paramObject)
  {
    checkIfRunning();
    boolean bool1 = this.where.containsKey(paramString1);
    KeyConstraints localKeyConstraints = null;
    if (bool1)
    {
      Object localObject = this.where.get(paramString1);
      boolean bool2 = localObject instanceof KeyConstraints;
      localKeyConstraints = null;
      if (bool2)
        localKeyConstraints = (KeyConstraints)localObject;
    }
    if (localKeyConstraints == null)
      localKeyConstraints = new KeyConstraints();
    localKeyConstraints.put(paramString2, paramObject);
    this.where.put(paramString1, localKeyConstraints);
    return this;
  }

  private ParseQuery<T> build()
  {
    if ((!this.isFromLocalDatastore) && (this.ignoreACLs))
      throw new IllegalStateException("`ignoreACLs` cannot be combined with network queries");
    return this;
  }

  private void checkIfRunning()
  {
    checkIfRunning(false);
  }

  private void checkIfRunning(boolean paramBoolean)
  {
    synchronized (this.isRunningLock)
    {
      if (this.isRunning)
        throw new RuntimeException("This query has an outstanding network connection. You have to wait until it's done.");
    }
    if (paramBoolean)
    {
      this.isRunning = true;
      this.ct = Task.create();
    }
    monitorexit;
  }

  private static void checkLDSEnabled(boolean paramBoolean)
  {
    if ((paramBoolean) && (!OfflineStore.isEnabled()))
      throw new IllegalStateException("Method requires Local Datastore. Please refer to `Parse#enableLocalDatastore(Context)`.");
    if ((!paramBoolean) && (OfflineStore.isEnabled()))
      throw new IllegalStateException("Unsupported method when Local Datastore is enabled.");
  }

  public static void clearAllCachedResults()
  {
    checkLDSEnabled(false);
    ParseKeyValueCache.clearKeyValueCacheDir();
  }

  private List<T> convertFindResponse(JSONObject paramJSONObject)
    throws JSONException
  {
    ArrayList localArrayList = new ArrayList();
    JSONArray localJSONArray = paramJSONObject.getJSONArray("results");
    if (localJSONArray == null)
    {
      Parse.logD("com.parse.ParseQuery", "null results in find response");
      this.objectsParsed = System.nanoTime();
      if (paramJSONObject.has("trace"))
      {
        Object localObject = paramJSONObject.get("trace");
        Object[] arrayOfObject = new Object[3];
        arrayOfObject[0] = Float.valueOf((float)(this.querySent - this.queryStart) / 1000000.0F);
        arrayOfObject[1] = localObject;
        arrayOfObject[2] = Float.valueOf((float)(this.objectsParsed - this.queryReceived) / 1000000.0F);
        Parse.logD("ParseQuery", String.format("Query pre-processing took %f seconds\n%s\nClient side parsing took %f seconds\n", arrayOfObject));
      }
      return localArrayList;
    }
    String str = paramJSONObject.optString("className");
    if (str.equals(""))
      str = this.className;
    int i = 0;
    label153: JSONObject localJSONObject;
    if (i < localJSONArray.length())
    {
      localJSONObject = localJSONArray.getJSONObject(i);
      if (this.selectedKeys != null)
        break label234;
    }
    label234: for (boolean bool = true; ; bool = false)
    {
      ParseObject localParseObject = ParseObject.fromJSON(localJSONObject, str, bool);
      localArrayList.add(localParseObject);
      RelationConstraint localRelationConstraint = (RelationConstraint)this.where.get("$relatedTo");
      if (localRelationConstraint != null)
        localRelationConstraint.getRelation().addKnownObject(localParseObject);
      i++;
      break label153;
      break;
    }
  }

  private Task<Integer> countFromCacheAsync(ParseUser paramParseUser)
  {
    return Task.call(new Callable(paramParseUser)
    {
      public Integer call()
        throws Exception
      {
        Object localObject = ParseKeyValueCache.jsonFromKeyValueCache(ParseQuery.this.currentCountCommand(this.val$user).getCacheKey(), ParseQuery.this.maxCacheAge);
        if (localObject == null)
          throw new ParseException(120, "results not cached");
        if (!(localObject instanceof JSONObject))
          throw new ParseException(120, "the cache contains the wrong datatype");
        JSONObject localJSONObject = (JSONObject)localObject;
        try
        {
          Integer localInteger = Integer.valueOf(localJSONObject.getInt("count"));
          return localInteger;
        }
        catch (JSONException localJSONException)
        {
        }
        throw new ParseException(120, "the cache contains corrupted json");
      }
    }
    , Task.BACKGROUND_EXECUTOR);
  }

  private Task<Integer> countFromLocalDatastoreAsync(ParseUser paramParseUser)
  {
    OfflineStore localOfflineStore = OfflineStore.getCurrent();
    if (this.pinName != null);
    for (Task localTask = ParsePin.getParsePin(this.pinName); ; localTask = Task.forResult(null))
      return localTask.onSuccessTask(new Continuation(localOfflineStore, paramParseUser)
      {
        public Task<Integer> then(Task<ParsePin> paramTask)
          throws Exception
        {
          ParsePin localParsePin = (ParsePin)paramTask.getResult();
          return this.val$store.countAsync(ParseQuery.this, this.val$user, localParsePin);
        }
      });
  }

  private Task<Integer> countFromNetworkAsync(ParseUser paramParseUser, boolean paramBoolean)
  {
    ParseRESTCommand localParseRESTCommand = currentCountCommand(paramParseUser);
    if (paramBoolean)
      localParseRESTCommand.enableRetrying();
    if (this.ct == null)
    {
      localParseRESTCommand.cancel();
      if (this.cachePolicy == CachePolicy.IGNORE_CACHE)
        break label94;
    }
    label94: for (boolean bool = true; ; bool = false)
    {
      return localParseRESTCommand.executeAsync().onSuccessTask(new Continuation(bool, localParseRESTCommand)
      {
        public Task<Object> then(Task<Object> paramTask)
          throws Exception
        {
          if (this.val$caching)
          {
            Object localObject = paramTask.getResult();
            ParseKeyValueCache.saveToKeyValueCache(this.val$command.getCacheKey(), localObject.toString());
          }
          return paramTask;
        }
      }
      , Task.BACKGROUND_EXECUTOR).onSuccess(new Continuation()
      {
        public Integer then(Task<Object> paramTask)
          throws Exception
        {
          return Integer.valueOf(((JSONObject)paramTask.getResult()).optInt("count"));
        }
      });
      this.ct.getTask().continueWith(new Continuation(localParseRESTCommand)
      {
        public Void then(Task<Void> paramTask)
          throws Exception
        {
          if (paramTask.isCancelled())
            this.val$command.cancel();
          return null;
        }
      });
      break;
    }
  }

  private Task<Integer> countWithCachePolicyAsync(CachePolicy paramCachePolicy, ParseUser paramParseUser)
  {
    return runCommandWithPolicyAsync(new CommandDelegate(paramParseUser)
    {
      public Task<Integer> runFromCacheAsync()
      {
        return ParseQuery.this.countFromCacheAsync(this.val$user);
      }

      public Task<Integer> runOnNetworkAsync(boolean paramBoolean)
      {
        return ParseQuery.this.countFromNetworkAsync(this.val$user, paramBoolean);
      }
    }
    , paramCachePolicy);
  }

  private ParseRESTCommand currentCountCommand(ParseUser paramParseUser)
  {
    return ParseRESTQueryCommand.countCommand(currentFindCommand(paramParseUser));
  }

  private ParseRESTQueryCommand currentFindCommand(ParseUser paramParseUser)
  {
    if (paramParseUser != null);
    for (String str = paramParseUser.getSessionToken(); ; str = null)
      return ParseRESTQueryCommand.findCommand(this.className, this.order, this.where, this.selectedKeys, this.include, this.limit, this.skip, this.extraOptions, this.trace, str);
  }

  private <TResult> void doInBackground(CallableWithCachePolicy<Task<TResult>> paramCallableWithCachePolicy, ParseCallback2<TResult, ParseException> paramParseCallback2)
  {
    Parse.callbackOnMainThreadAsync(doWithRunningCheck(new Callable(paramCallableWithCachePolicy, paramParseCallback2)
    {
      public Task<TResult> call()
        throws Exception
      {
        if (ParseQuery.this.cachePolicy == ParseQuery.CachePolicy.CACHE_THEN_NETWORK)
          return Parse.callbackOnMainThreadAsync((Task)this.val$callable.call(ParseQuery.CachePolicy.CACHE_ONLY), this.val$callback).continueWithTask(new Continuation()
          {
            public Task<TResult> then(Task<TResult> paramTask)
              throws Exception
            {
              if (paramTask.isCancelled())
                return paramTask;
              return (Task)ParseQuery.14.this.val$callable.call(ParseQuery.CachePolicy.NETWORK_ONLY);
            }
          });
        return (Task)this.val$callable.call(ParseQuery.this.cachePolicy);
      }
    }), paramParseCallback2);
  }

  private <TResult> Task<TResult> doWithRunningCheck(Callable<Task<TResult>> paramCallable)
  {
    checkIfRunning(true);
    try
    {
      localTask = (Task)paramCallable.call();
      return localTask.continueWithTask(new Continuation()
      {
        public Task<TResult> then(Task<TResult> paramTask)
          throws Exception
        {
          synchronized (ParseQuery.this.isRunningLock)
          {
            ParseQuery.access$1002(ParseQuery.this, false);
            if (ParseQuery.this.ct != null)
              ParseQuery.this.ct.trySetResult(null);
            ParseQuery.access$1102(ParseQuery.this, null);
            return paramTask;
          }
        }
      });
    }
    catch (Exception localException)
    {
      while (true)
        Task localTask = Task.forError(localException);
    }
  }

  private Task<List<T>> findFromCacheAsync(ParseUser paramParseUser)
  {
    return Task.call(new Callable(paramParseUser)
    {
      public List<T> call()
        throws Exception
      {
        Object localObject = ParseKeyValueCache.jsonFromKeyValueCache(ParseQuery.this.currentFindCommand(this.val$user).getCacheKey(), ParseQuery.this.maxCacheAge);
        if (localObject == null)
          throw new ParseException(120, "results not cached");
        if (!(localObject instanceof JSONObject))
          throw new ParseException(120, "the cache contains the wrong datatype");
        JSONObject localJSONObject = (JSONObject)localObject;
        try
        {
          List localList = ParseQuery.this.convertFindResponse(localJSONObject);
          return localList;
        }
        catch (JSONException localJSONException)
        {
        }
        throw new ParseException(120, "the cache contains corrupted json");
      }
    }
    , Task.BACKGROUND_EXECUTOR);
  }

  private Task<List<T>> findFromLocalDatastoreAsync(ParseUser paramParseUser)
  {
    OfflineStore localOfflineStore = OfflineStore.getCurrent();
    if (this.pinName != null);
    for (Task localTask = ParsePin.getParsePin(this.pinName); ; localTask = Task.forResult(null))
      return localTask.onSuccessTask(new Continuation(localOfflineStore, paramParseUser)
      {
        public Task<List<T>> then(Task<ParsePin> paramTask)
          throws Exception
        {
          ParsePin localParsePin = (ParsePin)paramTask.getResult();
          return this.val$store.findAsync(ParseQuery.this, this.val$user, localParsePin);
        }
      });
  }

  private Task<List<T>> findFromNetworkAsync(ParseUser paramParseUser, boolean paramBoolean)
  {
    ParseRESTQueryCommand localParseRESTQueryCommand = currentFindCommand(paramParseUser);
    if (paramBoolean)
      localParseRESTQueryCommand.enableRetrying();
    if (this.ct == null)
    {
      localParseRESTQueryCommand.cancel();
      if (this.cachePolicy == CachePolicy.IGNORE_CACHE)
        break label90;
    }
    label90: for (boolean bool = true; ; bool = false)
    {
      this.querySent = System.nanoTime();
      return localParseRESTQueryCommand.executeAsync().onSuccess(new Continuation(bool, localParseRESTQueryCommand)
      {
        public List<T> then(Task<Object> paramTask)
          throws Exception
        {
          if (this.val$caching)
          {
            Object localObject = paramTask.getResult();
            ParseKeyValueCache.saveToKeyValueCache(this.val$command.getCacheKey(), localObject.toString());
          }
          ParseQuery.access$402(ParseQuery.this, System.nanoTime());
          return ParseQuery.this.convertFindResponse((JSONObject)paramTask.getResult());
        }
      }
      , Task.BACKGROUND_EXECUTOR);
      this.ct.getTask().continueWith(new Continuation(localParseRESTQueryCommand)
      {
        public Void then(Task<Void> paramTask)
          throws Exception
        {
          if (paramTask.isCancelled())
            this.val$command.cancel();
          return null;
        }
      });
      break;
    }
  }

  private Task<T> getFirstFromLocalDatastoreAsync(ParseUser paramParseUser)
  {
    this.limit = 1;
    return findFromLocalDatastoreAsync(paramParseUser).continueWith(new Continuation()
    {
      public T then(Task<List<T>> paramTask)
        throws Exception
      {
        if (paramTask.isFaulted())
          throw paramTask.getError();
        if ((paramTask.getResult() != null) && (((List)paramTask.getResult()).size() > 0))
          return (ParseObject)((List)paramTask.getResult()).get(0);
        throw new ParseException(101, "no results found for query");
      }
    });
  }

  private Task<T> getFirstWithCachePolicyAsync(CachePolicy paramCachePolicy, ParseUser paramParseUser)
  {
    this.limit = 1;
    return findWithCachePolicyAsync(paramCachePolicy, paramParseUser).continueWith(new Continuation()
    {
      public T then(Task<List<T>> paramTask)
        throws Exception
      {
        if (paramTask.isFaulted())
          throw paramTask.getError();
        if ((paramTask.getResult() != null) && (((List)paramTask.getResult()).size() > 0))
          return (ParseObject)((List)paramTask.getResult()).get(0);
        throw new ParseException(101, "no results found for query");
      }
    });
  }

  private Task<T> getFromLocalDatastoreAsync(String paramString, ParseUser paramParseUser)
  {
    this.skip = -1;
    this.where = new QueryConstraints();
    this.where.put("objectId", paramString);
    return getFirstFromLocalDatastoreAsync(paramParseUser);
  }

  public static <T extends ParseObject> ParseQuery<T> getQuery(Class<T> paramClass)
  {
    return new ParseQuery(paramClass);
  }

  public static <T extends ParseObject> ParseQuery<T> getQuery(String paramString)
  {
    return new ParseQuery(paramString);
  }

  private Task<ParseUser> getUserAsync()
  {
    if (this.ignoreACLs)
      return Task.forResult(null);
    return ParseUser.getCurrentUserAsync();
  }

  @Deprecated
  public static ParseQuery<ParseUser> getUserQuery()
  {
    return ParseUser.getQuery();
  }

  private Task<T> getWithCachePolicyAsync(String paramString, CachePolicy paramCachePolicy, ParseUser paramParseUser)
  {
    this.skip = -1;
    this.where = new QueryConstraints();
    this.where.put("objectId", paramString);
    return getFirstWithCachePolicyAsync(paramCachePolicy, paramParseUser);
  }

  public static <T extends ParseObject> ParseQuery<T> or(List<ParseQuery<T>> paramList)
  {
    ArrayList localArrayList = new ArrayList();
    Object localObject = null;
    for (int i = 0; i < paramList.size(); i++)
    {
      if ((localObject != null) && (!((ParseQuery)paramList.get(i)).className.equals(localObject)))
        throw new IllegalArgumentException("All of the queries in an or query must be on the same class ");
      localObject = ((ParseQuery)paramList.get(i)).className;
      localArrayList.add(paramList.get(i));
    }
    if (localArrayList.size() == 0)
      throw new IllegalArgumentException("Can't take an or of an empty list of queries");
    return (ParseQuery<T>)new ParseQuery((String)localObject).whereSatifiesAnyOf(localArrayList);
  }

  private <TResult> Task<TResult> runCommandWithPolicyAsync(CommandDelegate<TResult> paramCommandDelegate, CachePolicy paramCachePolicy)
  {
    switch (31.$SwitchMap$com$parse$ParseQuery$CachePolicy[paramCachePolicy.ordinal()])
    {
    default:
      throw new RuntimeException("Unknown cache policy: " + this.cachePolicy);
    case 1:
    case 2:
      return paramCommandDelegate.runOnNetworkAsync(true);
    case 3:
      return paramCommandDelegate.runFromCacheAsync();
    case 4:
      return paramCommandDelegate.runFromCacheAsync().continueWithTask(new Continuation(paramCommandDelegate)
      {
        public Task<TResult> then(Task<TResult> paramTask)
          throws Exception
        {
          if ((paramTask.isFaulted()) && ((paramTask.getError() instanceof ParseException)))
            paramTask = this.val$c.runOnNetworkAsync(true);
          return paramTask;
        }
      });
    case 5:
      return paramCommandDelegate.runOnNetworkAsync(false).continueWithTask(new Continuation(paramCommandDelegate)
      {
        public Task<TResult> then(Task<TResult> paramTask)
          throws Exception
        {
          if ((paramTask.isFaulted()) && ((paramTask.getError() instanceof ParseException)) && (((ParseException)paramTask.getError()).getCode() == 100))
            paramTask = this.val$c.runFromCacheAsync();
          return paramTask;
        }
      });
    case 6:
    }
    throw new RuntimeException("You cannot use the cache policy CACHE_THEN_NETWORK with find()");
  }

  private ParseQuery<T> whereSatifiesAnyOf(List<ParseQuery<? extends T>> paramList)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      ParseQuery localParseQuery = (ParseQuery)localIterator.next();
      if (localParseQuery.limit >= 0)
        throw new IllegalArgumentException("Cannot have limits in sub queries of an 'OR' query");
      if (localParseQuery.skip > 0)
        throw new IllegalArgumentException("Cannot have skips in sub queries of an 'OR' query");
      if (localParseQuery.order != null)
        throw new IllegalArgumentException("Cannot have an order in sub queries of an 'OR' query");
      if (!localParseQuery.include.isEmpty())
        throw new IllegalArgumentException("Cannot have an include in sub queries of an 'OR' query");
      if (localParseQuery.selectedKeys != null)
        throw new IllegalArgumentException("Cannot have an selectKeys in sub queries of an 'OR' query");
      localArrayList.add(localParseQuery.getConstraints());
    }
    this.where.put("$or", localArrayList);
    return this;
  }

  public ParseQuery<T> addAscendingOrder(String paramString)
  {
    checkIfRunning();
    if (this.order == null)
    {
      this.order = paramString;
      return this;
    }
    this.order = (this.order + "," + paramString);
    return this;
  }

  public ParseQuery<T> addDescendingOrder(String paramString)
  {
    checkIfRunning();
    if (this.order == null)
    {
      this.order = ("-" + paramString);
      return this;
    }
    this.order = (this.order + ",-" + paramString);
    return this;
  }

  public void cancel()
  {
    synchronized (this.isRunningLock)
    {
      if (this.ct != null)
      {
        this.ct.trySetCancelled();
        this.ct = null;
      }
      this.isRunning = false;
      return;
    }
  }

  public void clearCachedResult()
  {
    checkLDSEnabled(false);
    try
    {
      localParseUser = (ParseUser)Parse.waitForTask(getUserAsync());
      ParseKeyValueCache.clearFromKeyValueCache(currentFindCommand(localParseUser).getCacheKey());
      return;
    }
    catch (ParseException localParseException)
    {
      while (true)
        ParseUser localParseUser = null;
    }
  }

  public int count()
    throws ParseException
  {
    return ((Integer)Parse.waitForTask(countInBackground())).intValue();
  }

  public Task<Integer> countInBackground()
  {
    build();
    return doWithRunningCheck(new Callable()
    {
      public Task<Integer> call()
        throws Exception
      {
        return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
        {
          public Task<Integer> then(Task<ParseUser> paramTask)
            throws Exception
          {
            ParseUser localParseUser = (ParseUser)paramTask.getResult();
            ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
            if (ParseQuery.this.isFromLocalDatastore)
              return ParseQuery.this.countFromLocalDatastoreAsync(localParseUser);
            return ParseQuery.this.countWithCachePolicyAsync(ParseQuery.this.cachePolicy, localParseUser);
          }
        });
      }
    });
  }

  public void countInBackground(CountCallback paramCountCallback)
  {
    build();
    25 local25 = null;
    if (paramCountCallback != null)
      local25 = new ParseCallback2(paramCountCallback)
      {
        public void done(Integer paramInteger, ParseException paramParseException)
        {
          CountCallback localCountCallback = this.val$callback;
          if (paramParseException == null);
          for (int i = paramInteger.intValue(); ; i = -1)
          {
            localCountCallback.done(i, paramParseException);
            return;
          }
        }
      };
    if (this.isFromLocalDatastore)
    {
      Parse.callbackOnMainThreadAsync(doWithRunningCheck(new Callable()
      {
        public Task<Integer> call()
          throws Exception
        {
          return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
          {
            public Task<Integer> then(Task<ParseUser> paramTask)
              throws Exception
            {
              ParseUser localParseUser = (ParseUser)paramTask.getResult();
              ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
              return ParseQuery.this.countFromLocalDatastoreAsync(localParseUser);
            }
          });
        }
      }), local25);
      return;
    }
    doInBackground(new CallableWithCachePolicy()
    {
      public Task<Integer> call(ParseQuery.CachePolicy paramCachePolicy)
      {
        return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation(paramCachePolicy)
        {
          public Task<Integer> then(Task<ParseUser> paramTask)
            throws Exception
          {
            ParseUser localParseUser = (ParseUser)paramTask.getResult();
            ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
            return ParseQuery.this.countWithCachePolicyAsync(this.val$cachePolicy, localParseUser);
          }
        });
      }
    }
    , local25);
  }

  public List<T> find()
    throws ParseException
  {
    return (List)Parse.waitForTask(findInBackground());
  }

  public Task<List<T>> findInBackground()
  {
    build();
    return doWithRunningCheck(new Callable()
    {
      public Task<List<T>> call()
        throws Exception
      {
        return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
        {
          public Task<List<T>> then(Task<ParseUser> paramTask)
            throws Exception
          {
            ParseUser localParseUser = (ParseUser)paramTask.getResult();
            ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
            if (ParseQuery.this.isFromLocalDatastore)
              return ParseQuery.this.findFromLocalDatastoreAsync(localParseUser);
            return ParseQuery.this.findWithCachePolicyAsync(ParseQuery.this.cachePolicy, localParseUser);
          }
        });
      }
    });
  }

  public void findInBackground(FindCallback<T> paramFindCallback)
  {
    build();
    if (this.isFromLocalDatastore)
    {
      Parse.callbackOnMainThreadAsync(doWithRunningCheck(new Callable()
      {
        public Task<List<T>> call()
          throws Exception
        {
          return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
          {
            public Task<List<T>> then(Task<ParseUser> paramTask)
              throws Exception
            {
              ParseUser localParseUser = (ParseUser)paramTask.getResult();
              ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
              return ParseQuery.this.findFromLocalDatastoreAsync(localParseUser);
            }
          });
        }
      }), paramFindCallback);
      return;
    }
    doInBackground(new CallableWithCachePolicy()
    {
      public Task<List<T>> call(ParseQuery.CachePolicy paramCachePolicy)
      {
        return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation(paramCachePolicy)
        {
          public Task<List<T>> then(Task<ParseUser> paramTask)
            throws Exception
          {
            ParseUser localParseUser = (ParseUser)paramTask.getResult();
            ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
            return ParseQuery.this.findWithCachePolicyAsync(this.val$cachePolicy, localParseUser);
          }
        });
      }
    }
    , paramFindCallback);
  }

  Task<List<T>> findWithCachePolicyAsync(CachePolicy paramCachePolicy, ParseUser paramParseUser)
  {
    return runCommandWithPolicyAsync(new CommandDelegate(paramParseUser)
    {
      public Task<List<T>> runFromCacheAsync()
      {
        return ParseQuery.this.findFromCacheAsync(this.val$user);
      }

      public Task<List<T>> runOnNetworkAsync(boolean paramBoolean)
      {
        return ParseQuery.this.findFromNetworkAsync(this.val$user, paramBoolean);
      }
    }
    , paramCachePolicy);
  }

  public ParseQuery<T> fromLocalDatastore()
  {
    return fromPin(null);
  }

  ParseQuery<T> fromNetwork()
  {
    checkLDSEnabled(true);
    checkIfRunning();
    this.cachePolicy = CachePolicy.NETWORK_ONLY;
    this.isFromLocalDatastore = false;
    this.pinName = null;
    return this;
  }

  public ParseQuery<T> fromPin()
  {
    return fromPin("_default");
  }

  public ParseQuery<T> fromPin(String paramString)
  {
    checkLDSEnabled(true);
    checkIfRunning();
    this.isFromLocalDatastore = true;
    this.pinName = paramString;
    return this;
  }

  public T get(String paramString)
    throws ParseException
  {
    return (ParseObject)Parse.waitForTask(getInBackground(paramString));
  }

  public CachePolicy getCachePolicy()
  {
    checkLDSEnabled(false);
    return this.cachePolicy;
  }

  public String getClassName()
  {
    return this.className;
  }

  QueryConstraints getConstraints()
  {
    return this.where;
  }

  public T getFirst()
    throws ParseException
  {
    return (ParseObject)Parse.waitForTask(getFirstInBackground());
  }

  public Task<T> getFirstInBackground()
  {
    build();
    return doWithRunningCheck(new Callable()
    {
      public Task<T> call()
        throws Exception
      {
        return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
        {
          public Task<T> then(Task<ParseUser> paramTask)
            throws Exception
          {
            ParseUser localParseUser = (ParseUser)paramTask.getResult();
            ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
            if (ParseQuery.this.isFromLocalDatastore)
              return ParseQuery.this.getFirstFromLocalDatastoreAsync(localParseUser);
            return ParseQuery.this.getFirstWithCachePolicyAsync(ParseQuery.this.cachePolicy, localParseUser);
          }
        });
      }
    });
  }

  public void getFirstInBackground(GetCallback<T> paramGetCallback)
  {
    build();
    if (this.isFromLocalDatastore)
    {
      Parse.callbackOnMainThreadAsync(doWithRunningCheck(new Callable()
      {
        public Task<T> call()
          throws Exception
        {
          return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
          {
            public Task<T> then(Task<ParseUser> paramTask)
              throws Exception
            {
              ParseUser localParseUser = (ParseUser)paramTask.getResult();
              ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
              return ParseQuery.this.getFirstFromLocalDatastoreAsync(localParseUser);
            }
          });
        }
      }), paramGetCallback);
      return;
    }
    doInBackground(new CallableWithCachePolicy()
    {
      public Task<T> call(ParseQuery.CachePolicy paramCachePolicy)
      {
        return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation(paramCachePolicy)
        {
          public Task<T> then(Task<ParseUser> paramTask)
            throws Exception
          {
            ParseUser localParseUser = (ParseUser)paramTask.getResult();
            ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
            return ParseQuery.this.getFirstWithCachePolicyAsync(this.val$cachePolicy, localParseUser);
          }
        });
      }
    }
    , paramGetCallback);
  }

  public Task<T> getInBackground(String paramString)
  {
    build();
    return doWithRunningCheck(new Callable(paramString)
    {
      public Task<T> call()
        throws Exception
      {
        return ParseQuery.this.getUserAsync().continueWithTask(new Continuation()
        {
          public Task<T> then(Task<ParseUser> paramTask)
            throws Exception
          {
            ParseUser localParseUser = (ParseUser)paramTask.getResult();
            ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
            if (ParseQuery.this.isFromLocalDatastore)
              return ParseQuery.this.getFromLocalDatastoreAsync(ParseQuery.28.this.val$objectId, localParseUser);
            return ParseQuery.this.getWithCachePolicyAsync(ParseQuery.28.this.val$objectId, ParseQuery.this.cachePolicy, localParseUser);
          }
        });
      }
    });
  }

  public void getInBackground(String paramString, GetCallback<T> paramGetCallback)
  {
    build();
    if (this.isFromLocalDatastore)
    {
      Parse.callbackOnMainThreadAsync(doWithRunningCheck(new Callable(paramString)
      {
        public Task<T> call()
          throws Exception
        {
          return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
          {
            public Task<T> then(Task<ParseUser> paramTask)
              throws Exception
            {
              ParseUser localParseUser = (ParseUser)paramTask.getResult();
              ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
              return ParseQuery.this.getFromLocalDatastoreAsync(ParseQuery.29.this.val$objectId, localParseUser);
            }
          });
        }
      }), paramGetCallback);
      return;
    }
    doInBackground(new CallableWithCachePolicy(paramString)
    {
      public Task<T> call(ParseQuery.CachePolicy paramCachePolicy)
      {
        return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation(paramCachePolicy)
        {
          public Task<T> then(Task<ParseUser> paramTask)
            throws Exception
          {
            ParseUser localParseUser = (ParseUser)paramTask.getResult();
            ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
            return ParseQuery.this.getWithCachePolicyAsync(ParseQuery.30.this.val$objectId, this.val$cachePolicy, localParseUser);
          }
        });
      }
    }
    , paramGetCallback);
  }

  List<String> getIncludes()
  {
    return Collections.unmodifiableList(this.include);
  }

  public int getLimit()
  {
    return this.limit;
  }

  public long getMaxCacheAge()
  {
    checkLDSEnabled(false);
    return this.maxCacheAge;
  }

  public int getSkip()
  {
    return this.skip;
  }

  public boolean hasCachedResult()
  {
    checkLDSEnabled(false);
    try
    {
      localParseUser = (ParseUser)Parse.waitForTask(getUserAsync());
      return ParseKeyValueCache.loadFromKeyValueCache(currentFindCommand(localParseUser).getCacheKey(), this.maxCacheAge) != null;
    }
    catch (ParseException localParseException)
    {
      while (true)
        ParseUser localParseUser = null;
    }
  }

  public ParseQuery<T> ignoreACLs()
  {
    checkLDSEnabled(true);
    checkIfRunning();
    this.ignoreACLs = true;
    return this;
  }

  public ParseQuery<T> include(String paramString)
  {
    checkIfRunning();
    this.include.add(paramString);
    return this;
  }

  boolean isFromLocalDatastore()
  {
    checkLDSEnabled(true);
    return this.isFromLocalDatastore;
  }

  boolean isFromNetwork()
  {
    checkLDSEnabled(true);
    return this.cachePolicy == CachePolicy.NETWORK_ONLY;
  }

  public ParseQuery<T> orderByAscending(String paramString)
  {
    checkIfRunning();
    this.order = paramString;
    return this;
  }

  public ParseQuery<T> orderByDescending(String paramString)
  {
    checkIfRunning();
    this.order = ("-" + paramString);
    return this;
  }

  ParseQuery<T> redirectClassNameForKey(String paramString)
  {
    this.extraOptions.put("redirectClassNameForKey", paramString);
    return this;
  }

  public ParseQuery<T> selectKeys(Collection<String> paramCollection)
  {
    checkIfRunning();
    if (this.selectedKeys == null)
      this.selectedKeys = new ArrayList();
    this.selectedKeys.addAll(paramCollection);
    return this;
  }

  public ParseQuery<T> setCachePolicy(CachePolicy paramCachePolicy)
  {
    checkLDSEnabled(false);
    checkIfRunning();
    this.cachePolicy = paramCachePolicy;
    return this;
  }

  public ParseQuery<T> setLimit(int paramInt)
  {
    checkIfRunning();
    this.limit = paramInt;
    return this;
  }

  public ParseQuery<T> setMaxCacheAge(long paramLong)
  {
    checkLDSEnabled(false);
    this.maxCacheAge = paramLong;
    return this;
  }

  public ParseQuery<T> setSkip(int paramInt)
  {
    checkIfRunning();
    this.skip = paramInt;
    return this;
  }

  public ParseQuery<T> setTrace(boolean paramBoolean)
  {
    checkIfRunning();
    this.trace = paramBoolean;
    return this;
  }

  String[] sortKeys()
  {
    if (this.order == null)
      return new String[0];
    return this.order.split(",");
  }

  JSONObject toREST()
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("className", this.className);
      localJSONObject.put("where", Parse.encode(this.where, PointerEncodingStrategy.get()));
      if (this.limit >= 0)
        localJSONObject.put("limit", this.limit);
      if (this.skip > 0)
        localJSONObject.put("skip", this.skip);
      if (this.order != null)
        localJSONObject.put("order", this.order);
      if (!this.include.isEmpty())
        localJSONObject.put("include", Parse.join(",", this.include));
      if (this.selectedKeys != null)
        localJSONObject.put("fields", Parse.join(",", this.selectedKeys));
      if (this.trace)
        localJSONObject.put("trace", "1");
      Iterator localIterator = this.extraOptions.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        localJSONObject.put(str, Parse.encode(this.extraOptions.get(str), PointerEncodingStrategy.get()));
      }
    }
    catch (JSONException localJSONException)
    {
      throw new RuntimeException(localJSONException);
    }
    return localJSONObject;
  }

  public ParseQuery<T> whereContainedIn(String paramString, Collection<? extends Object> paramCollection)
  {
    return addCondition(paramString, "$in", new ArrayList(paramCollection));
  }

  public ParseQuery<T> whereContains(String paramString1, String paramString2)
  {
    whereMatches(paramString1, Pattern.quote(paramString2));
    return this;
  }

  public ParseQuery<T> whereContainsAll(String paramString, Collection<?> paramCollection)
  {
    return addCondition(paramString, "$all", new ArrayList(paramCollection));
  }

  public ParseQuery<T> whereDoesNotExist(String paramString)
  {
    return addCondition(paramString, "$exists", Boolean.valueOf(false));
  }

  public ParseQuery<T> whereDoesNotMatchKeyInQuery(String paramString1, String paramString2, ParseQuery<?> paramParseQuery)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("key", paramString2);
      localJSONObject.put("query", paramParseQuery);
      return addCondition(paramString1, "$dontSelect", localJSONObject);
    }
    catch (JSONException localJSONException)
    {
    }
    throw new RuntimeException(localJSONException);
  }

  public ParseQuery<T> whereDoesNotMatchQuery(String paramString, ParseQuery<?> paramParseQuery)
  {
    return addCondition(paramString, "$notInQuery", paramParseQuery);
  }

  public ParseQuery<T> whereEndsWith(String paramString1, String paramString2)
  {
    whereMatches(paramString1, Pattern.quote(paramString2) + "$");
    return this;
  }

  public ParseQuery<T> whereEqualTo(String paramString, Object paramObject)
  {
    checkIfRunning();
    this.where.put(paramString, paramObject);
    return this;
  }

  public ParseQuery<T> whereExists(String paramString)
  {
    return addCondition(paramString, "$exists", Boolean.valueOf(true));
  }

  public ParseQuery<T> whereGreaterThan(String paramString, Object paramObject)
  {
    return addCondition(paramString, "$gt", paramObject);
  }

  public ParseQuery<T> whereGreaterThanOrEqualTo(String paramString, Object paramObject)
  {
    return addCondition(paramString, "$gte", paramObject);
  }

  public ParseQuery<T> whereLessThan(String paramString, Object paramObject)
  {
    return addCondition(paramString, "$lt", paramObject);
  }

  public ParseQuery<T> whereLessThanOrEqualTo(String paramString, Object paramObject)
  {
    return addCondition(paramString, "$lte", paramObject);
  }

  public ParseQuery<T> whereMatches(String paramString1, String paramString2)
  {
    return addCondition(paramString1, "$regex", paramString2);
  }

  public ParseQuery<T> whereMatches(String paramString1, String paramString2, String paramString3)
  {
    addCondition(paramString1, "$regex", paramString2);
    if (paramString3.length() != 0)
      addCondition(paramString1, "$options", paramString3);
    return this;
  }

  public ParseQuery<T> whereMatchesKeyInQuery(String paramString1, String paramString2, ParseQuery<?> paramParseQuery)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("key", paramString2);
      localJSONObject.put("query", paramParseQuery);
      return addCondition(paramString1, "$select", localJSONObject);
    }
    catch (JSONException localJSONException)
    {
    }
    throw new RuntimeException(localJSONException);
  }

  public ParseQuery<T> whereMatchesQuery(String paramString, ParseQuery<?> paramParseQuery)
  {
    return addCondition(paramString, "$inQuery", paramParseQuery);
  }

  public ParseQuery<T> whereNear(String paramString, ParseGeoPoint paramParseGeoPoint)
  {
    return addCondition(paramString, "$nearSphere", paramParseGeoPoint);
  }

  public ParseQuery<T> whereNotContainedIn(String paramString, Collection<? extends Object> paramCollection)
  {
    return addCondition(paramString, "$nin", new ArrayList(paramCollection));
  }

  public ParseQuery<T> whereNotEqualTo(String paramString, Object paramObject)
  {
    return addCondition(paramString, "$ne", paramObject);
  }

  ParseQuery<T> whereRelatedTo(ParseObject paramParseObject, String paramString)
  {
    this.where.put("$relatedTo", new RelationConstraint(paramString, paramParseObject));
    return this;
  }

  public ParseQuery<T> whereStartsWith(String paramString1, String paramString2)
  {
    whereMatches(paramString1, "^" + Pattern.quote(paramString2));
    return this;
  }

  public ParseQuery<T> whereWithinGeoBox(String paramString, ParseGeoPoint paramParseGeoPoint1, ParseGeoPoint paramParseGeoPoint2)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramParseGeoPoint1);
    localArrayList.add(paramParseGeoPoint2);
    HashMap localHashMap = new HashMap();
    localHashMap.put("$box", localArrayList);
    return addCondition(paramString, "$within", localHashMap);
  }

  public ParseQuery<T> whereWithinKilometers(String paramString, ParseGeoPoint paramParseGeoPoint, double paramDouble)
  {
    return whereWithinRadians(paramString, paramParseGeoPoint, paramDouble / ParseGeoPoint.EARTH_MEAN_RADIUS_KM);
  }

  public ParseQuery<T> whereWithinMiles(String paramString, ParseGeoPoint paramParseGeoPoint, double paramDouble)
  {
    return whereWithinRadians(paramString, paramParseGeoPoint, paramDouble / ParseGeoPoint.EARTH_MEAN_RADIUS_MILE);
  }

  public ParseQuery<T> whereWithinRadians(String paramString, ParseGeoPoint paramParseGeoPoint, double paramDouble)
  {
    addCondition(paramString, "$nearSphere", paramParseGeoPoint);
    return addCondition(paramString, "$maxDistance", Double.valueOf(paramDouble));
  }

  public static enum CachePolicy
  {
    static
    {
      CACHE_ONLY = new CachePolicy("CACHE_ONLY", 1);
      NETWORK_ONLY = new CachePolicy("NETWORK_ONLY", 2);
      CACHE_ELSE_NETWORK = new CachePolicy("CACHE_ELSE_NETWORK", 3);
      NETWORK_ELSE_CACHE = new CachePolicy("NETWORK_ELSE_CACHE", 4);
      CACHE_THEN_NETWORK = new CachePolicy("CACHE_THEN_NETWORK", 5);
      CachePolicy[] arrayOfCachePolicy = new CachePolicy[6];
      arrayOfCachePolicy[0] = IGNORE_CACHE;
      arrayOfCachePolicy[1] = CACHE_ONLY;
      arrayOfCachePolicy[2] = NETWORK_ONLY;
      arrayOfCachePolicy[3] = CACHE_ELSE_NETWORK;
      arrayOfCachePolicy[4] = NETWORK_ELSE_CACHE;
      arrayOfCachePolicy[5] = CACHE_THEN_NETWORK;
      $VALUES = arrayOfCachePolicy;
    }
  }

  private static abstract interface CallableWithCachePolicy<TResult>
  {
    public abstract TResult call(ParseQuery.CachePolicy paramCachePolicy);
  }

  private static abstract interface CommandDelegate<T>
  {
    public abstract Task<T> runFromCacheAsync();

    public abstract Task<T> runOnNetworkAsync(boolean paramBoolean);
  }

  static class KeyConstraints extends HashMap<String, Object>
  {
  }

  static class QueryConstraints extends HashMap<String, Object>
  {
  }

  static class RelationConstraint
  {
    private String key;
    private ParseObject object;

    public RelationConstraint(String paramString, ParseObject paramParseObject)
    {
      if ((paramString == null) || (paramParseObject == null))
        throw new IllegalArgumentException("Arguments must not be null.");
      this.key = paramString;
      this.object = paramParseObject;
    }

    public JSONObject encode(ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
    {
      JSONObject localJSONObject = new JSONObject();
      try
      {
        localJSONObject.put("key", this.key);
        localJSONObject.put("object", paramParseObjectEncodingStrategy.encodeRelatedObject(this.object));
        return localJSONObject;
      }
      catch (JSONException localJSONException)
      {
      }
      throw new RuntimeException(localJSONException);
    }

    public String getKey()
    {
      return this.key;
    }

    public ParseObject getObject()
    {
      return this.object;
    }

    public ParseRelation<ParseObject> getRelation()
    {
      return this.object.getRelation(this.key);
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseQuery
 * JD-Core Version:    0.6.0
 */