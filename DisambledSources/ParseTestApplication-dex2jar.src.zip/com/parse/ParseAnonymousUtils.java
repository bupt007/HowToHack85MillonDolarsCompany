package com.parse;

import bolts.Task;
import org.json.JSONException;

public final class ParseAnonymousUtils
{
  static final String AUTH_TYPE = "anonymous";
  static final String SERVICE_NAME = "anonymous";
  private static AnonymousAuthenticationProvider provider;

  private static AnonymousAuthenticationProvider getProvider()
  {
    if (provider == null)
    {
      provider = new AnonymousAuthenticationProvider();
      ParseUser.registerAuthenticationProvider(provider);
    }
    return provider;
  }

  public static boolean isLinked(ParseUser paramParseUser)
  {
    return paramParseUser.isLinked("anonymous");
  }

  static ParseUser lazyLogIn()
  {
    try
    {
      AnonymousAuthenticationProvider localAnonymousAuthenticationProvider = getProvider();
      ParseUser localParseUser = ParseUser.logInLazyUser(localAnonymousAuthenticationProvider.getAuthType(), localAnonymousAuthenticationProvider.getAuthData());
      return localParseUser;
    }
    catch (JSONException localJSONException)
    {
    }
    throw new RuntimeException(localJSONException);
  }

  public static void logIn(LogInCallback paramLogInCallback)
  {
    Parse.callbackOnMainThreadAsync(logInInBackground(), paramLogInCallback);
  }

  public static Task<ParseUser> logInInBackground()
  {
    return getProvider().logInAsync();
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseAnonymousUtils
 * JD-Core Version:    0.6.0
 */