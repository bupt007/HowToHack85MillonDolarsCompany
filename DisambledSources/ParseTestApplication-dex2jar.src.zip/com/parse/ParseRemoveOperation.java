package com.parse;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class ParseRemoveOperation
  implements ParseFieldOperation
{
  protected HashSet<Object> objects = new HashSet();

  public ParseRemoveOperation(Collection<?> paramCollection)
  {
    this.objects.addAll(paramCollection);
  }

  public Object apply(Object paramObject, ParseObject paramParseObject, String paramString)
  {
    ArrayList localArrayList1;
    if (paramObject == null)
      localArrayList1 = new ArrayList();
    while (true)
    {
      return localArrayList1;
      if ((paramObject instanceof JSONArray))
        return new JSONArray((ArrayList)apply(ParseFieldOperations.jsonArrayAsArrayList((JSONArray)paramObject), paramParseObject, paramString));
      if (!(paramObject instanceof List))
        break;
      localArrayList1 = new ArrayList((List)paramObject);
      localArrayList1.removeAll(this.objects);
      ArrayList localArrayList2 = new ArrayList(this.objects);
      localArrayList2.removeAll(localArrayList1);
      HashSet localHashSet = new HashSet();
      Iterator localIterator1 = localArrayList2.iterator();
      while (localIterator1.hasNext())
      {
        Object localObject2 = localIterator1.next();
        if (!(localObject2 instanceof ParseObject))
          continue;
        localHashSet.add(((ParseObject)localObject2).getObjectId());
      }
      Iterator localIterator2 = localArrayList1.iterator();
      while (localIterator2.hasNext())
      {
        Object localObject1 = localIterator2.next();
        if ((!(localObject1 instanceof ParseObject)) || (!localHashSet.contains(((ParseObject)localObject1).getObjectId())))
          continue;
        localIterator2.remove();
      }
    }
    throw new IllegalArgumentException("Operation is invalid after previous operation.");
  }

  public JSONObject encode(ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject();
    localJSONObject.put("__op", "Remove");
    localJSONObject.put("objects", Parse.encode(new ArrayList(this.objects), paramParseObjectEncodingStrategy));
    return localJSONObject;
  }

  public ParseFieldOperation mergeWithPrevious(ParseFieldOperation paramParseFieldOperation)
  {
    if (paramParseFieldOperation == null)
      return this;
    if ((paramParseFieldOperation instanceof ParseDeleteOperation))
      return new ParseSetOperation(this.objects);
    if ((paramParseFieldOperation instanceof ParseSetOperation))
    {
      Object localObject = ((ParseSetOperation)paramParseFieldOperation).getValue();
      if (((localObject instanceof JSONArray)) || ((localObject instanceof List)))
        return new ParseSetOperation(apply(localObject, null, null));
      throw new IllegalArgumentException("You can only add an item to a List or JSONArray.");
    }
    if ((paramParseFieldOperation instanceof ParseRemoveOperation))
    {
      HashSet localHashSet = new HashSet(((ParseRemoveOperation)paramParseFieldOperation).objects);
      localHashSet.addAll(this.objects);
      return new ParseRemoveOperation(localHashSet);
    }
    throw new IllegalArgumentException("Operation is invalid after previous operation.");
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseRemoveOperation
 * JD-Core Version:    0.6.0
 */