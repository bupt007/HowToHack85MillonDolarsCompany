package com.parse;

import java.util.List;

public abstract interface FindCallback<T extends ParseObject> extends ParseCallback2<List<T>, ParseException>
{
  public abstract void done(List<T> paramList, ParseException paramParseException);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.FindCallback
 * JD-Core Version:    0.6.0
 */