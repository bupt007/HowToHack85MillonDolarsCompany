package com.parse;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import org.json.JSONException;
import org.json.JSONTokener;

class ParseKeyValueCache
{
  static final int DEFAULT_MAX_KEY_VALUE_CACHE_BYTES = 2097152;
  static final int DEFAULT_MAX_KEY_VALUE_CACHE_FILES = 1000;
  private static final String DIR_NAME = "ParseKeyValueCache";
  private static final Object MUTEX_IO = new Object();
  private static final String TAG = "ParseKeyValueCache";
  private static File directory;
  static int maxKeyValueCacheBytes = 2097152;
  static int maxKeyValueCacheFiles = 1000;

  static void clearFromKeyValueCache(String paramString)
  {
    synchronized (MUTEX_IO)
    {
      File localFile = getKeyValueCacheFile(paramString);
      if (localFile != null)
        localFile.delete();
      return;
    }
  }

  static void clearKeyValueCacheDir()
  {
    synchronized (MUTEX_IO)
    {
      File[] arrayOfFile = getKeyValueCacheDir().listFiles();
      if (arrayOfFile == null)
        return;
      int i = arrayOfFile.length;
      for (int j = 0; j < i; j++)
        arrayOfFile[j].delete();
      return;
    }
  }

  private static File createKeyValueCacheFile(String paramString)
  {
    String str = String.valueOf(new Date().getTime()) + '.' + paramString;
    return new File(getKeyValueCacheDir(), str);
  }

  private static long getKeyValueCacheAge(File paramFile)
  {
    String str = paramFile.getName();
    try
    {
      long l = Long.parseLong(str.substring(0, str.indexOf('.')));
      return l;
    }
    catch (NumberFormatException localNumberFormatException)
    {
    }
    return 0L;
  }

  static File getKeyValueCacheDir()
  {
    return directory;
  }

  private static File getKeyValueCacheFile(String paramString)
  {
    String str = '.' + paramString;
    File[] arrayOfFile = getKeyValueCacheDir().listFiles(new FilenameFilter(str)
    {
      public boolean accept(File paramFile, String paramString)
      {
        return paramString.endsWith(this.val$suffix);
      }
    });
    if ((arrayOfFile == null) || (arrayOfFile.length == 0))
      return null;
    return arrayOfFile[0];
  }

  static void initialize(Context paramContext)
  {
    directory = new File(paramContext.getCacheDir(), "ParseKeyValueCache");
    if ((!directory.isDirectory()) && (!directory.mkdir()))
      throw new RuntimeException("Could not create ParseKeyValueCache directory");
  }

  static Object jsonFromKeyValueCache(String paramString, long paramLong)
  {
    String str = loadFromKeyValueCache(paramString, paramLong);
    if (str == null)
      return null;
    JSONTokener localJSONTokener = new JSONTokener(str);
    try
    {
      Object localObject = localJSONTokener.nextValue();
      return localObject;
    }
    catch (JSONException localJSONException)
    {
      Parse.logE("ParseKeyValueCache", "corrupted cache for " + paramString, localJSONException);
      clearFromKeyValueCache(paramString);
    }
    return null;
  }

  static String loadFromKeyValueCache(String paramString, long paramLong)
  {
    File localFile;
    Date localDate;
    synchronized (MUTEX_IO)
    {
      localFile = getKeyValueCacheFile(paramString);
      if (localFile == null)
        return null;
      localDate = new Date();
      long l = Math.max(0L, localDate.getTime() - paramLong);
      if (getKeyValueCacheAge(localFile) < l)
        return null;
    }
    localFile.setLastModified(localDate.getTime());
    try
    {
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(localFile, "r");
      byte[] arrayOfByte = new byte[(int)localRandomAccessFile.length()];
      localRandomAccessFile.readFully(arrayOfByte);
      localRandomAccessFile.close();
      String str = new String(arrayOfByte, "UTF-8");
      monitorexit;
      return str;
    }
    catch (IOException localIOException)
    {
      Parse.logE("ParseKeyValueCache", "error reading from cache", localIOException);
      monitorexit;
    }
    return null;
  }

  static void saveToKeyValueCache(String paramString1, String paramString2)
  {
    File localFile2;
    synchronized (MUTEX_IO)
    {
      File localFile1 = getKeyValueCacheFile(paramString1);
      if (localFile1 != null)
        localFile1.delete();
      localFile2 = createKeyValueCacheFile(paramString1);
    }
    try
    {
      FileOutputStream localFileOutputStream = new FileOutputStream(localFile2);
      localFileOutputStream.write(paramString2.getBytes("UTF-8"));
      localFileOutputStream.close();
      label56: File[] arrayOfFile = getKeyValueCacheDir().listFiles();
      int i = arrayOfFile.length;
      int j = 0;
      int k = arrayOfFile.length;
      for (int m = 0; m < k; m++)
      {
        File localFile3 = arrayOfFile[m];
        j = (int)(j + localFile3.length());
      }
      if ((i > maxKeyValueCacheFiles) || (j > maxKeyValueCacheBytes))
      {
        Arrays.sort(arrayOfFile, new Comparator()
        {
          public int compare(File paramFile1, File paramFile2)
          {
            int i = Long.valueOf(paramFile1.lastModified()).compareTo(Long.valueOf(paramFile2.lastModified()));
            if (i != 0)
              return i;
            return paramFile1.getName().compareTo(paramFile2.getName());
          }
        });
        int n = arrayOfFile.length;
        i1 = 0;
        if (i1 < n)
        {
          File localFile4 = arrayOfFile[i1];
          i--;
          j = (int)(j - localFile4.length());
          localFile4.delete();
          if ((i > maxKeyValueCacheFiles) || (j > maxKeyValueCacheBytes))
            break label217;
        }
      }
      monitorexit;
      return;
      localObject2 = finally;
      monitorexit;
      throw localObject2;
    }
    catch (IOException localIOException)
    {
      break label56;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      while (true)
      {
        int i1;
        continue;
        label217: i1++;
      }
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseKeyValueCache
 * JD-Core Version:    0.6.0
 */