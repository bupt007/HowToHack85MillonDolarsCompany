package com.parse.internal;

public abstract interface AsyncCallback
{
  public abstract void onCancel();

  public abstract void onFailure(Throwable paramThrowable);

  public abstract void onSuccess(Object paramObject);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.internal.AsyncCallback
 * JD-Core Version:    0.6.0
 */