package com.parse;

 enum ReportField
{
  static
  {
    ANDROID_ID = new ReportField("ANDROID_ID", 1);
    UID = new ReportField("UID", 2);
    APP_VERSION_CODE = new ReportField("APP_VERSION_CODE", 3);
    APP_VERSION_NAME = new ReportField("APP_VERSION_NAME", 4);
    PACKAGE_NAME = new ReportField("PACKAGE_NAME", 5);
    FILE_PATH = new ReportField("FILE_PATH", 6);
    PHONE_MODEL = new ReportField("PHONE_MODEL", 7);
    ANDROID_VERSION = new ReportField("ANDROID_VERSION", 8);
    OS_VERSION = new ReportField("OS_VERSION", 9);
    IS_CYANOGENMOD = new ReportField("IS_CYANOGENMOD", 10);
    BUILD = new ReportField("BUILD", 11);
    BRAND = new ReportField("BRAND", 12);
    PRODUCT = new ReportField("PRODUCT", 13);
    TOTAL_MEM_SIZE = new ReportField("TOTAL_MEM_SIZE", 14);
    AVAILABLE_MEM_SIZE = new ReportField("AVAILABLE_MEM_SIZE", 15);
    CUSTOM_DATA = new ReportField("CUSTOM_DATA", 16);
    STACK_TRACE = new ReportField("STACK_TRACE", 17);
    CRASH_CONFIGURATION = new ReportField("CRASH_CONFIGURATION", 18);
    DISPLAY = new ReportField("DISPLAY", 19);
    USER_APP_START_DATE = new ReportField("USER_APP_START_DATE", 20);
    USER_CRASH_DATE = new ReportField("USER_CRASH_DATE", 21);
    DUMPSYS_MEMINFO = new ReportField("DUMPSYS_MEMINFO", 22);
    DROPBOX = new ReportField("DROPBOX", 23);
    LOGCAT = new ReportField("LOGCAT", 24);
    EVENTSLOG = new ReportField("EVENTSLOG", 25);
    RADIOLOG = new ReportField("RADIOLOG", 26);
    IS_SILENT = new ReportField("IS_SILENT", 27);
    DEVICE_ID = new ReportField("DEVICE_ID", 28);
    INSTALLATION_ID = new ReportField("INSTALLATION_ID", 29);
    USER_EMAIL = new ReportField("USER_EMAIL", 30);
    DEVICE_FEATURES = new ReportField("DEVICE_FEATURES", 31);
    ENVIRONMENT = new ReportField("ENVIRONMENT", 32);
    SETTINGS_SYSTEM = new ReportField("SETTINGS_SYSTEM", 33);
    SETTINGS_SECURE = new ReportField("SETTINGS_SECURE", 34);
    PROCESS_NAME = new ReportField("PROCESS_NAME", 35);
    PROCESS_NAME_BY_AMS = new ReportField("PROCESS_NAME_BY_AMS", 36);
    UPLOADED_BY_PROCESS = new ReportField("UPLOADED_BY_PROCESS", 37);
    ACTIVITY_LOG = new ReportField("ACTIVITY_LOG", 38);
    ACRA_INTERNAL = new ReportField("ACRA_INTERNAL", 39);
    PROCESS_UPTIME = new ReportField("PROCESS_UPTIME", 40);
    DEVICE_UPTIME = new ReportField("DEVICE_UPTIME", 41);
    JAIL_BROKEN = new ReportField("JAIL_BROKEN", 42);
    ACRA_REPORT_FILENAME = new ReportField("ACRA_REPORT_FILENAME", 43);
    EXCEPTION_CAUSE = new ReportField("EXCEPTION_CAUSE", 44);
    REPORT_LOAD_THROW = new ReportField("REPORT_LOAD_THROW", 45);
    MINIDUMP = new ReportField("MINIDUMP", 46);
    OPEN_FD_COUNT = new ReportField("OPEN_FD_COUNT", 47);
    OPEN_FD_SOFT_LIMIT = new ReportField("OPEN_FD_SOFT_LIMIT", 48);
    OPEN_FD_HARD_LIMIT = new ReportField("OPEN_FD_HARD_LIMIT", 49);
    APP_INSTALL_TIME = new ReportField("APP_INSTALL_TIME", 50);
    APP_UPGRADE_TIME = new ReportField("APP_UPGRADE_TIME", 51);
    SERIAL = new ReportField("SERIAL", 52);
    IS_LOW_RAM_DEVICE = new ReportField("IS_LOW_RAM_DEVICE", 53);
    SIGQUIT = new ReportField("SIGQUIT", 54);
    LARGE_MEM_HEAP = new ReportField("LARGE_MEM_HEAP", 55);
    ANDROID_RUNTIME = new ReportField("ANDROID_RUNTIME", 56);
    ReportField[] arrayOfReportField = new ReportField[57];
    arrayOfReportField[0] = REPORT_ID;
    arrayOfReportField[1] = ANDROID_ID;
    arrayOfReportField[2] = UID;
    arrayOfReportField[3] = APP_VERSION_CODE;
    arrayOfReportField[4] = APP_VERSION_NAME;
    arrayOfReportField[5] = PACKAGE_NAME;
    arrayOfReportField[6] = FILE_PATH;
    arrayOfReportField[7] = PHONE_MODEL;
    arrayOfReportField[8] = ANDROID_VERSION;
    arrayOfReportField[9] = OS_VERSION;
    arrayOfReportField[10] = IS_CYANOGENMOD;
    arrayOfReportField[11] = BUILD;
    arrayOfReportField[12] = BRAND;
    arrayOfReportField[13] = PRODUCT;
    arrayOfReportField[14] = TOTAL_MEM_SIZE;
    arrayOfReportField[15] = AVAILABLE_MEM_SIZE;
    arrayOfReportField[16] = CUSTOM_DATA;
    arrayOfReportField[17] = STACK_TRACE;
    arrayOfReportField[18] = CRASH_CONFIGURATION;
    arrayOfReportField[19] = DISPLAY;
    arrayOfReportField[20] = USER_APP_START_DATE;
    arrayOfReportField[21] = USER_CRASH_DATE;
    arrayOfReportField[22] = DUMPSYS_MEMINFO;
    arrayOfReportField[23] = DROPBOX;
    arrayOfReportField[24] = LOGCAT;
    arrayOfReportField[25] = EVENTSLOG;
    arrayOfReportField[26] = RADIOLOG;
    arrayOfReportField[27] = IS_SILENT;
    arrayOfReportField[28] = DEVICE_ID;
    arrayOfReportField[29] = INSTALLATION_ID;
    arrayOfReportField[30] = USER_EMAIL;
    arrayOfReportField[31] = DEVICE_FEATURES;
    arrayOfReportField[32] = ENVIRONMENT;
    arrayOfReportField[33] = SETTINGS_SYSTEM;
    arrayOfReportField[34] = SETTINGS_SECURE;
    arrayOfReportField[35] = PROCESS_NAME;
    arrayOfReportField[36] = PROCESS_NAME_BY_AMS;
    arrayOfReportField[37] = UPLOADED_BY_PROCESS;
    arrayOfReportField[38] = ACTIVITY_LOG;
    arrayOfReportField[39] = ACRA_INTERNAL;
    arrayOfReportField[40] = PROCESS_UPTIME;
    arrayOfReportField[41] = DEVICE_UPTIME;
    arrayOfReportField[42] = JAIL_BROKEN;
    arrayOfReportField[43] = ACRA_REPORT_FILENAME;
    arrayOfReportField[44] = EXCEPTION_CAUSE;
    arrayOfReportField[45] = REPORT_LOAD_THROW;
    arrayOfReportField[46] = MINIDUMP;
    arrayOfReportField[47] = OPEN_FD_COUNT;
    arrayOfReportField[48] = OPEN_FD_SOFT_LIMIT;
    arrayOfReportField[49] = OPEN_FD_HARD_LIMIT;
    arrayOfReportField[50] = APP_INSTALL_TIME;
    arrayOfReportField[51] = APP_UPGRADE_TIME;
    arrayOfReportField[52] = SERIAL;
    arrayOfReportField[53] = IS_LOW_RAM_DEVICE;
    arrayOfReportField[54] = SIGQUIT;
    arrayOfReportField[55] = LARGE_MEM_HEAP;
    arrayOfReportField[56] = ANDROID_RUNTIME;
    $VALUES = arrayOfReportField;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ReportField
 * JD-Core Version:    0.6.0
 */