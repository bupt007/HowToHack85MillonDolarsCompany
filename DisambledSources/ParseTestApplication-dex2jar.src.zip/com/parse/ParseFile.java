package com.parse;

import android.webkit.MimeTypeMap;
import bolts.Continuation;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class ParseFile
{
  private String contentType = null;
  private Set<Task<?>.TaskCompletionSource> currentTasks = Collections.synchronizedSet(new HashSet());
  byte[] data;
  private boolean dirty = false;
  private String name = null;
  final TaskQueue taskQueue = new TaskQueue();
  private String url = null;

  ParseFile(String paramString1, String paramString2)
  {
    this.name = paramString1;
    this.url = paramString2;
  }

  public ParseFile(String paramString, byte[] paramArrayOfByte)
  {
    this(paramString, paramArrayOfByte, null);
  }

  public ParseFile(String paramString1, byte[] paramArrayOfByte, String paramString2)
  {
    if (paramArrayOfByte.length > Parse.maxParseFileSize)
    {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(Parse.maxParseFileSize);
      throw new IllegalArgumentException(String.format("ParseFile must be less than %d bytes", arrayOfObject));
    }
    this.name = paramString1;
    this.data = paramArrayOfByte;
    this.contentType = paramString2;
    this.dirty = true;
  }

  ParseFile(JSONObject paramJSONObject, ParseDecoder paramParseDecoder)
  {
    this(paramJSONObject.optString("name"), paramJSONObject.optString("url"));
  }

  public ParseFile(byte[] paramArrayOfByte)
  {
    this(null, paramArrayOfByte, null);
  }

  public ParseFile(byte[] paramArrayOfByte, String paramString)
  {
    this(null, paramArrayOfByte, paramString);
  }

  static void clearCache()
  {
    File[] arrayOfFile = getCacheDir().listFiles();
    int i = arrayOfFile.length;
    for (int j = 0; j < i; j++)
      ParseFileUtils.deleteQuietly(arrayOfFile[j]);
  }

  static File getCacheDir()
  {
    return Parse.getParseCacheDir("files");
  }

  private byte[] getCachedData()
  {
    if (this.data != null)
      return this.data;
    try
    {
      File localFile2 = getCacheFile();
      if (localFile2 != null)
      {
        byte[] arrayOfByte2 = ParseFileUtils.readFileToByteArray(localFile2);
        return arrayOfByte2;
      }
    }
    catch (IOException localIOException1)
    {
      try
      {
        File localFile1 = getFilesFile();
        if (localFile1 != null)
        {
          byte[] arrayOfByte1 = ParseFileUtils.readFileToByteArray(localFile1);
          return arrayOfByte1;
        }
      }
      catch (IOException localIOException2)
      {
      }
    }
    return null;
  }

  private Task<byte[]> getDataAsync(ProgressCallback paramProgressCallback, Task<Void> paramTask)
  {
    if (this.data != null)
      return Task.forResult(this.data);
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    this.currentTasks.add(localTaskCompletionSource);
    paramTask.continueWith(new Continuation()
    {
      public byte[] then(Task<Void> paramTask)
        throws Exception
      {
        return ParseFile.this.getCachedData();
      }
    }
    , Task.BACKGROUND_EXECUTOR).continueWith(new Continuation(localTaskCompletionSource, paramProgressCallback)
    {
      public Void then(Task<byte[]> paramTask)
        throws Exception
      {
        byte[] arrayOfByte = (byte[])paramTask.getResult();
        if (arrayOfByte != null)
        {
          this.val$tcs.trySetResult(arrayOfByte);
          return null;
        }
        new ParseAWSRequest(ParseFile.this.url).executeAsync(null, this.val$progressCallback).continueWithTask(new Continuation()
        {
          public Task<byte[]> then(Task<byte[]> paramTask)
            throws Exception
          {
            if ((paramTask.isFaulted()) && ((paramTask.getError() instanceof IllegalStateException)))
              paramTask = Task.forError(new ParseException(100, paramTask.getError().getMessage()));
            do
            {
              return paramTask;
              if (ParseFile.6.this.val$tcs.getTask().isCancelled())
                return ParseFile.6.this.val$tcs.getTask();
              ParseFile.this.data = ((byte[])paramTask.getResult());
            }
            while (ParseFile.this.data == null);
            ParseFileUtils.writeByteArrayToFile(ParseFile.this.getCacheFile(), ParseFile.this.data);
            return paramTask;
          }
        }).continueWith(new Continuation()
        {
          public Void then(Task<byte[]> paramTask)
            throws Exception
          {
            ParseFile.this.currentTasks.remove(ParseFile.6.this.val$tcs);
            if (paramTask.isCancelled())
              ParseFile.6.this.val$tcs.trySetCancelled();
            while (true)
            {
              return null;
              if (paramTask.isFaulted())
              {
                ParseFile.6.this.val$tcs.trySetError(paramTask.getError());
                continue;
              }
              ParseFile.6.this.val$tcs.trySetResult(paramTask.getResult());
            }
          }
        });
        return null;
      }
    });
    return localTaskCompletionSource.getTask();
  }

  private String getFilename()
  {
    return this.name;
  }

  static File getFilesDir()
  {
    return Parse.getParseFilesDir("files");
  }

  private Task<Void> saveAsync(String paramString, ProgressCallback paramProgressCallback, Task<Void>.TaskCompletionSource paramTask)
  {
    return this.taskQueue.enqueue(new Continuation(paramString, paramProgressCallback, paramTask)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseFile.this.saveAsync(this.val$sessionToken, this.val$uploadProgressCallback, paramTask, this.val$tcs);
      }
    });
  }

  private Task<Void> saveAsync(String paramString, ProgressCallback paramProgressCallback, Task<Void> paramTask, Task<Void>.TaskCompletionSource paramTask1)
  {
    if (!isDirty())
      return Task.forResult(null);
    paramTask.continueWith(new Continuation(paramTask1, paramString, paramProgressCallback)
    {
      public Void then(Task<Void> paramTask)
        throws Exception
      {
        if (!ParseFile.this.isDirty())
        {
          this.val$tcs.trySetResult(null);
          return null;
        }
        Task.forResult(null).continueWithTask(new Continuation()
        {
          public Task<JSONObject> then(Task<Void> paramTask)
            throws Exception
          {
            String str1;
            String str2;
            if (ParseFile.this.name != null)
            {
              str1 = ParseFile.this.name;
              if (ParseFile.this.contentType == null)
                break label135;
              str2 = ParseFile.this.contentType;
            }
            while (true)
            {
              if (str2 == null)
                str2 = "application/octet-stream";
              ParseRESTFileCommand localParseRESTFileCommand = ParseRESTFileCommand.uploadFileCommand(str1, ParseFile.this.data, str2, ParseFile.3.this.val$sessionToken);
              localParseRESTFileCommand.enableRetrying();
              ParseFile.3.this.val$tcs.getTask().continueWith(new Continuation(localParseRESTFileCommand)
              {
                public Void then(Task<Void> paramTask)
                  throws Exception
                {
                  if (paramTask.isCancelled())
                    this.val$command.cancel();
                  return null;
                }
              });
              return localParseRESTFileCommand.executeAsync(ParseFile.3.this.val$uploadProgressCallback, null).cast();
              str1 = "file";
              break;
              label135: int i = str1.lastIndexOf(".");
              str2 = null;
              if (i == -1)
                continue;
              String str3 = str1.substring(1 + str1.lastIndexOf("."));
              str2 = MimeTypeMap.getSingleton().getMimeTypeFromExtension(str3);
            }
          }
        }).onSuccessTask(new Continuation()
        {
          public Task<Void> then(Task<JSONObject> paramTask)
            throws Exception
          {
            JSONObject localJSONObject = (JSONObject)paramTask.getResult();
            ParseFile.access$102(ParseFile.this, localJSONObject.getString("name"));
            ParseFile.access$202(ParseFile.this, localJSONObject.getString("url"));
            try
            {
              ParseFileUtils.writeByteArrayToFile(ParseFile.this.getCacheFile(), ParseFile.this.data);
              label65: ParseFile.access$302(ParseFile.this, false);
              return paramTask.makeVoid();
            }
            catch (IOException localIOException)
            {
              break label65;
            }
          }
        }).continueWith(new Continuation()
        {
          public Void then(Task<Void> paramTask)
            throws Exception
          {
            ParseFile.this.currentTasks.remove(ParseFile.3.this.val$tcs);
            if (paramTask.isCancelled())
              ParseFile.3.this.val$tcs.trySetCancelled();
            while (true)
            {
              return null;
              if (paramTask.isFaulted())
              {
                ParseFile.3.this.val$tcs.trySetError(paramTask.getError());
                continue;
              }
              ParseFile.3.this.val$tcs.trySetResult(paramTask.getResult());
            }
          }
        });
        return null;
      }
    });
    return paramTask1.getTask();
  }

  private void setPinned(boolean paramBoolean)
    throws ParseException
  {
    Parse.waitForTask(setPinnedInBackground(paramBoolean));
  }

  private Task<Void> setPinnedInBackground(boolean paramBoolean)
  {
    return this.taskQueue.enqueue(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return paramTask;
      }
    }).continueWith(new Continuation(paramBoolean)
    {
      public Void then(Task<Void> paramTask)
        throws Exception
      {
        if (((this.val$pinned) && (ParseFile.this.isPinned())) || ((!this.val$pinned) && (!ParseFile.this.isPinned())));
        File localFile1;
        File localFile2;
        while (true)
        {
          return null;
          if (this.val$pinned)
            localFile1 = ParseFile.this.getCacheFile();
          for (localFile2 = ParseFile.this.getFilesFile(); localFile2 == null; localFile2 = ParseFile.this.getCacheFile())
          {
            throw new IllegalStateException("Unable to pin file before saving");
            localFile1 = ParseFile.this.getFilesFile();
          }
          if (localFile2.exists())
            ParseFileUtils.deleteQuietly(localFile2);
          if ((!this.val$pinned) || (ParseFile.this.data == null))
            break;
          ParseFileUtils.writeByteArrayToFile(localFile2, ParseFile.this.data);
          if (!localFile1.exists())
            continue;
          ParseFileUtils.deleteQuietly(localFile1);
          return null;
        }
        if ((localFile1 == null) || (!localFile1.exists()))
          throw new IllegalStateException("Unable to pin file before retrieving");
        ParseFileUtils.moveFile(localFile1, localFile2);
        return null;
      }
    }
    , Task.BACKGROUND_EXECUTOR);
  }

  private void setPinnedInBackground(boolean paramBoolean, ParseCallback1<ParseException> paramParseCallback1)
  {
    Parse.callbackOnMainThreadAsync(setPinnedInBackground(paramBoolean), paramParseCallback1);
  }

  public void cancel()
  {
    HashSet localHashSet = new HashSet(this.currentTasks);
    Iterator localIterator = localHashSet.iterator();
    while (localIterator.hasNext())
      ((Task.TaskCompletionSource)localIterator.next()).trySetCancelled();
    this.currentTasks.removeAll(localHashSet);
  }

  JSONObject encode()
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject();
    localJSONObject.put("__type", "File");
    localJSONObject.put("name", getName());
    if (getUrl() == null)
      throw new IllegalStateException("Unable to encode an unsaved ParseFile.");
    localJSONObject.put("url", getUrl());
    return localJSONObject;
  }

  File getCacheFile()
  {
    String str = getFilename();
    if (str != null)
      return new File(getCacheDir(), str);
    return null;
  }

  public byte[] getData()
    throws ParseException
  {
    return (byte[])Parse.waitForTask(getDataInBackground());
  }

  public Task<byte[]> getDataInBackground()
  {
    return getDataInBackground((ProgressCallback)null);
  }

  public Task<byte[]> getDataInBackground(ProgressCallback paramProgressCallback)
  {
    return this.taskQueue.enqueue(new Continuation(paramProgressCallback)
    {
      public Task<byte[]> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseFile.this.getDataAsync(this.val$progressCallback, paramTask);
      }
    });
  }

  public void getDataInBackground(GetDataCallback paramGetDataCallback)
  {
    Parse.callbackOnMainThreadAsync(getDataInBackground(), paramGetDataCallback);
  }

  public void getDataInBackground(GetDataCallback paramGetDataCallback, ProgressCallback paramProgressCallback)
  {
    Parse.callbackOnMainThreadAsync(getDataInBackground(paramProgressCallback), paramGetDataCallback);
  }

  File getFilesFile()
  {
    String str = getFilename();
    if (str != null)
      return new File(getFilesDir(), str);
    return null;
  }

  public String getName()
  {
    return this.name;
  }

  public String getUrl()
  {
    return this.url;
  }

  public boolean isDataAvailable()
  {
    if (this.data == null)
    {
      if (isPinned())
        break label26;
      if (!getCacheFile().exists())
        break label36;
    }
    label26: 
    do
      return true;
    while (getFilesFile().exists());
    label36: return false;
  }

  public boolean isDirty()
  {
    return this.dirty;
  }

  boolean isPinned()
  {
    File localFile = getFilesFile();
    return (localFile != null) && (localFile.exists());
  }

  void pin()
    throws ParseException
  {
    setPinned(true);
  }

  Task<Void> pinInBackground()
  {
    return setPinnedInBackground(true);
  }

  void pinInBackground(ParseCallback1<ParseException> paramParseCallback1)
  {
    setPinnedInBackground(true, paramParseCallback1);
  }

  public void save()
    throws ParseException
  {
    Parse.waitForTask(saveInBackground());
  }

  Task<Void> saveAsync(String paramString, ProgressCallback paramProgressCallback)
  {
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    this.currentTasks.add(localTaskCompletionSource);
    return saveAsync(paramString, paramProgressCallback, localTaskCompletionSource);
  }

  public Task<Void> saveInBackground()
  {
    return saveInBackground((ProgressCallback)null);
  }

  public Task<Void> saveInBackground(ProgressCallback paramProgressCallback)
  {
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    this.currentTasks.add(localTaskCompletionSource);
    return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation(paramProgressCallback, localTaskCompletionSource)
    {
      public Task<Void> then(Task<String> paramTask)
        throws Exception
      {
        String str = (String)paramTask.getResult();
        return ParseFile.this.saveAsync(str, this.val$uploadProgressCallback, this.val$tcs);
      }
    });
  }

  public void saveInBackground(SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(saveInBackground(), paramSaveCallback);
  }

  public void saveInBackground(SaveCallback paramSaveCallback, ProgressCallback paramProgressCallback)
  {
    Parse.callbackOnMainThreadAsync(saveInBackground(paramProgressCallback), paramSaveCallback);
  }

  void unpin()
    throws ParseException
  {
    setPinned(false);
  }

  Task<Void> unpinInBackground()
  {
    return setPinnedInBackground(false);
  }

  void unpinInBackground(ParseCallback1<ParseException> paramParseCallback1)
  {
    setPinnedInBackground(false, paramParseCallback1);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseFile
 * JD-Core Version:    0.6.0
 */