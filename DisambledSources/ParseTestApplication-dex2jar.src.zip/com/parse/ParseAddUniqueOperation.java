package com.parse;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class ParseAddUniqueOperation
  implements ParseFieldOperation
{
  protected LinkedHashSet<Object> objects = new LinkedHashSet();

  public ParseAddUniqueOperation(Collection<?> paramCollection)
  {
    this.objects.addAll(paramCollection);
  }

  public Object apply(Object paramObject, ParseObject paramParseObject, String paramString)
  {
    ArrayList localArrayList;
    if (paramObject == null)
      localArrayList = new ArrayList(this.objects);
    while (true)
    {
      return localArrayList;
      if ((paramObject instanceof JSONArray))
        return new JSONArray((ArrayList)apply(ParseFieldOperations.jsonArrayAsArrayList((JSONArray)paramObject), paramParseObject, paramString));
      if (!(paramObject instanceof List))
        break;
      localArrayList = new ArrayList((List)paramObject);
      HashMap localHashMap = new HashMap();
      for (int i = 0; i < localArrayList.size(); i++)
      {
        if (!(localArrayList.get(i) instanceof ParseObject))
          continue;
        localHashMap.put(((ParseObject)localArrayList.get(i)).getObjectId(), Integer.valueOf(i));
      }
      Iterator localIterator = this.objects.iterator();
      while (localIterator.hasNext())
      {
        Object localObject = localIterator.next();
        if ((localObject instanceof ParseObject))
        {
          String str = ((ParseObject)localObject).getObjectId();
          if ((str != null) && (localHashMap.containsKey(str)))
          {
            localArrayList.set(((Integer)localHashMap.get(str)).intValue(), localObject);
            continue;
          }
          if (localArrayList.contains(localObject))
            continue;
          localArrayList.add(localObject);
          continue;
        }
        if (localArrayList.contains(localObject))
          continue;
        localArrayList.add(localObject);
      }
    }
    throw new IllegalArgumentException("Operation is invalid after previous operation.");
  }

  public JSONObject encode(ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject();
    localJSONObject.put("__op", "AddUnique");
    localJSONObject.put("objects", Parse.encode(new ArrayList(this.objects), paramParseObjectEncodingStrategy));
    return localJSONObject;
  }

  public ParseFieldOperation mergeWithPrevious(ParseFieldOperation paramParseFieldOperation)
  {
    if (paramParseFieldOperation == null)
      return this;
    if ((paramParseFieldOperation instanceof ParseDeleteOperation))
      return new ParseSetOperation(this.objects);
    if ((paramParseFieldOperation instanceof ParseSetOperation))
    {
      Object localObject = ((ParseSetOperation)paramParseFieldOperation).getValue();
      if (((localObject instanceof JSONArray)) || ((localObject instanceof List)))
        return new ParseSetOperation(apply(localObject, null, null));
      throw new IllegalArgumentException("You can only add an item to a List or JSONArray.");
    }
    if ((paramParseFieldOperation instanceof ParseAddUniqueOperation))
      return new ParseAddUniqueOperation((List)apply(new ArrayList(((ParseAddUniqueOperation)paramParseFieldOperation).objects), null, null));
    throw new IllegalArgumentException("Operation is invalid after previous operation.");
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseAddUniqueOperation
 * JD-Core Version:    0.6.0
 */