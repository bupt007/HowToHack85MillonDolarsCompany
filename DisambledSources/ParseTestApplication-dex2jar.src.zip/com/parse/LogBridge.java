package com.parse;

abstract interface LogBridge
{
  public abstract void log(String paramString1, String paramString2, Throwable paramThrowable);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.LogBridge
 * JD-Core Version:    0.6.0
 */