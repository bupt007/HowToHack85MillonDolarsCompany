package com.parse;

import bolts.Continuation;
import bolts.Task;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class TaskQueue
{
  private final Lock lock = new ReentrantLock();
  private Task<Void> tail;

  private Task<Void> getTaskToAwait()
  {
    this.lock.lock();
    try
    {
      if (this.tail != null);
      Task localTask1;
      for (Object localObject2 = this.tail; ; localObject2 = localTask1)
      {
        Task localTask2 = ((Task)localObject2).continueWith(new Continuation()
        {
          public Void then(Task<Void> paramTask)
            throws Exception
          {
            return null;
          }
        });
        return localTask2;
        localTask1 = Task.forResult(null);
      }
    }
    finally
    {
      this.lock.unlock();
    }
    throw localObject1;
  }

  static <T> Continuation<T, Task<T>> waitFor(Task<Void> paramTask)
  {
    return new Continuation(paramTask)
    {
      public Task<T> then(Task<T> paramTask)
        throws Exception
      {
        return this.val$toAwait.continueWithTask(new Continuation(paramTask)
        {
          public Task<T> then(Task<Void> paramTask)
            throws Exception
          {
            return this.val$task;
          }
        });
      }
    };
  }

  // ERROR //
  <T> Task<T> enqueue(Continuation<Void, Task<T>> paramContinuation)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	com/parse/TaskQueue:lock	Ljava/util/concurrent/locks/Lock;
    //   4: invokeinterface 24 1 0
    //   9: aload_0
    //   10: getfield 26	com/parse/TaskQueue:tail	Lbolts/Task;
    //   13: ifnull +58 -> 71
    //   16: aload_0
    //   17: getfield 26	com/parse/TaskQueue:tail	Lbolts/Task;
    //   20: astore_3
    //   21: aload_1
    //   22: aload_0
    //   23: invokespecial 58	com/parse/TaskQueue:getTaskToAwait	()Lbolts/Task;
    //   26: invokeinterface 64 2 0
    //   31: checkcast 33	bolts/Task
    //   34: astore 6
    //   36: aload_0
    //   37: iconst_2
    //   38: anewarray 33	bolts/Task
    //   41: dup
    //   42: iconst_0
    //   43: aload_3
    //   44: aastore
    //   45: dup
    //   46: iconst_1
    //   47: aload 6
    //   49: aastore
    //   50: invokestatic 70	java/util/Arrays:asList	([Ljava/lang/Object;)Ljava/util/List;
    //   53: invokestatic 74	bolts/Task:whenAll	(Ljava/util/Collection;)Lbolts/Task;
    //   56: putfield 26	com/parse/TaskQueue:tail	Lbolts/Task;
    //   59: aload_0
    //   60: getfield 18	com/parse/TaskQueue:lock	Ljava/util/concurrent/locks/Lock;
    //   63: invokeinterface 40 1 0
    //   68: aload 6
    //   70: areturn
    //   71: aconst_null
    //   72: invokestatic 44	bolts/Task:forResult	(Ljava/lang/Object;)Lbolts/Task;
    //   75: astore_3
    //   76: goto -55 -> 21
    //   79: astore 5
    //   81: aload 5
    //   83: athrow
    //   84: astore_2
    //   85: aload_0
    //   86: getfield 18	com/parse/TaskQueue:lock	Ljava/util/concurrent/locks/Lock;
    //   89: invokeinterface 40 1 0
    //   94: aload_2
    //   95: athrow
    //   96: astore 4
    //   98: new 54	java/lang/RuntimeException
    //   101: dup
    //   102: aload 4
    //   104: invokespecial 77	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   107: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   21	36	79	java/lang/RuntimeException
    //   9	21	84	finally
    //   21	36	84	finally
    //   36	59	84	finally
    //   71	76	84	finally
    //   81	84	84	finally
    //   98	108	84	finally
    //   21	36	96	java/lang/Exception
  }

  Lock getLock()
  {
    return this.lock;
  }

  void waitUntilFinished()
    throws InterruptedException
  {
    this.lock.lock();
    try
    {
      Task localTask = this.tail;
      if (localTask == null)
        return;
      this.tail.waitForCompletion();
      return;
    }
    finally
    {
      this.lock.unlock();
    }
    throw localObject;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.TaskQueue
 * JD-Core Version:    0.6.0
 */