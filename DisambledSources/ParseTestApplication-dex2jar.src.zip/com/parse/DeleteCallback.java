package com.parse;

public abstract interface DeleteCallback extends ParseCallback1<ParseException>
{
  public abstract void done(ParseException paramParseException);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.DeleteCallback
 * JD-Core Version:    0.6.0
 */