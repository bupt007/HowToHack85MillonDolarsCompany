package com.parse;

import android.app.Activity;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import java.util.Locale;
import java.util.Random;
import org.json.JSONException;
import org.json.JSONObject;

public class ParsePushBroadcastReceiver extends BroadcastReceiver
{
  public static final String ACTION_PUSH_DELETE = "com.parse.push.intent.DELETE";
  public static final String ACTION_PUSH_OPEN = "com.parse.push.intent.OPEN";
  public static final String ACTION_PUSH_RECEIVE = "com.parse.push.intent.RECEIVE";
  public static final String KEY_PUSH_CHANNEL = "com.parse.Channel";
  public static final String KEY_PUSH_DATA = "com.parse.Data";
  public static final String PROPERTY_PUSH_ICON = "com.parse.push.notification_icon";
  protected static final int SMALL_NOTIFICATION_MAX_CHARACTER_LIMIT = 38;
  private static final String TAG = "com.parse.ParsePushReceiver";

  private JSONObject getPushData(Intent paramIntent)
  {
    try
    {
      JSONObject localJSONObject = new JSONObject(paramIntent.getStringExtra("com.parse.Data"));
      return localJSONObject;
    }
    catch (JSONException localJSONException)
    {
      Parse.logE("com.parse.ParsePushReceiver", "Unexpected JSONException when receiving push data: ", localJSONException);
    }
    return null;
  }

  protected Class<? extends Activity> getActivity(Context paramContext, Intent paramIntent)
  {
    String str1 = Parse.applicationContext.getPackageName();
    Intent localIntent = Parse.applicationContext.getPackageManager().getLaunchIntentForPackage(str1);
    if (localIntent == null)
      return null;
    String str2 = localIntent.getComponent().getClassName();
    try
    {
      Class localClass = Class.forName(str2);
      return localClass;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
    }
    return null;
  }

  protected Bitmap getLargeIcon(Context paramContext, Intent paramIntent)
  {
    return null;
  }

  protected Notification getNotification(Context paramContext, Intent paramIntent)
  {
    JSONObject localJSONObject = getPushData(paramIntent);
    if ((localJSONObject == null) || ((!localJSONObject.has("alert")) && (!localJSONObject.has("title"))))
      return null;
    String str1 = localJSONObject.optString("title", ManifestInfo.getDisplayName());
    String str2 = localJSONObject.optString("alert", "Notification received.");
    String str3 = String.format(Locale.getDefault(), "%s: %s", new Object[] { str1, str2 });
    Bundle localBundle = paramIntent.getExtras();
    Random localRandom = new Random();
    int i = localRandom.nextInt();
    int j = localRandom.nextInt();
    String str4 = paramContext.getPackageName();
    Intent localIntent1 = new Intent("com.parse.push.intent.OPEN");
    localIntent1.putExtras(localBundle);
    localIntent1.setPackage(str4);
    Intent localIntent2 = new Intent("com.parse.push.intent.DELETE");
    localIntent2.putExtras(localBundle);
    localIntent2.setPackage(str4);
    PendingIntent localPendingIntent1 = PendingIntent.getBroadcast(paramContext, i, localIntent1, 134217728);
    PendingIntent localPendingIntent2 = PendingIntent.getBroadcast(paramContext, j, localIntent2, 134217728);
    NotificationCompat.Builder localBuilder = new NotificationCompat.Builder(paramContext);
    localBuilder.setContentTitle(str1).setContentText(str2).setTicker(str3).setSmallIcon(getSmallIconId(paramContext, paramIntent)).setLargeIcon(getLargeIcon(paramContext, paramIntent)).setContentIntent(localPendingIntent1).setDeleteIntent(localPendingIntent2).setAutoCancel(true).setDefaults(-1);
    if ((str2 != null) && (str2.length() > 38))
      localBuilder.setStyle(new NotificationCompat.Builder.BigTextStyle().bigText(str2));
    return localBuilder.build();
  }

  protected int getSmallIconId(Context paramContext, Intent paramIntent)
  {
    Bundle localBundle = ManifestInfo.getApplicationMetadata(paramContext);
    int i = 0;
    if (localBundle != null)
      i = localBundle.getInt("com.parse.push.notification_icon");
    if (i != 0)
      return i;
    return ManifestInfo.getIconId();
  }

  protected void onPushDismiss(Context paramContext, Intent paramIntent)
  {
  }

  protected void onPushOpen(Context paramContext, Intent paramIntent)
  {
    ParseAnalytics.trackAppOpenedInBackground(paramIntent);
    try
    {
      String str2 = new JSONObject(paramIntent.getStringExtra("com.parse.Data")).optString("uri", null);
      str1 = str2;
      localClass = getActivity(paramContext, paramIntent);
      if (str1 != null)
      {
        localIntent = new Intent("android.intent.action.VIEW", Uri.parse(str1));
        localIntent.putExtras(paramIntent.getExtras());
        if (Build.VERSION.SDK_INT < 16)
          break label118;
        TaskStackBuilderHelper.startActivities(paramContext, localClass, localIntent);
        return;
      }
    }
    catch (JSONException localJSONException)
    {
      Intent localIntent;
      while (true)
      {
        Class localClass;
        Parse.logE("com.parse.ParsePushReceiver", "Unexpected JSONException when receiving push data: ", localJSONException);
        String str1 = null;
        continue;
        localIntent = new Intent(paramContext, localClass);
      }
      label118: localIntent.addFlags(268435456);
      localIntent.addFlags(67108864);
      paramContext.startActivity(localIntent);
    }
  }

  protected void onPushReceive(Context paramContext, Intent paramIntent)
  {
    try
    {
      JSONObject localJSONObject1 = new JSONObject(paramIntent.getStringExtra("com.parse.Data"));
      localJSONObject2 = localJSONObject1;
      String str = null;
      if (localJSONObject2 != null)
        str = localJSONObject2.optString("action", null);
      if (str != null)
      {
        Bundle localBundle = paramIntent.getExtras();
        Intent localIntent = new Intent();
        localIntent.putExtras(localBundle);
        localIntent.setAction(str);
        localIntent.setPackage(paramContext.getPackageName());
        paramContext.sendBroadcast(localIntent);
      }
      Notification localNotification = getNotification(paramContext, paramIntent);
      if (localNotification != null)
        ParseNotificationManager.getInstance().showNotification(paramContext, localNotification);
      return;
    }
    catch (JSONException localJSONException)
    {
      while (true)
      {
        Parse.logE("com.parse.ParsePushReceiver", "Unexpected JSONException when receiving push data: ", localJSONException);
        JSONObject localJSONObject2 = null;
      }
    }
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str = paramIntent.getAction();
    int i = -1;
    switch (str.hashCode())
    {
    default:
    case -269490979:
    case -824874927:
    case 374898288:
    }
    while (true)
      switch (i)
      {
      default:
        return;
        if (!str.equals("com.parse.push.intent.RECEIVE"))
          continue;
        i = 0;
        continue;
        if (!str.equals("com.parse.push.intent.DELETE"))
          continue;
        i = 1;
        continue;
        if (!str.equals("com.parse.push.intent.OPEN"))
          continue;
        i = 2;
      case 0:
      case 1:
      case 2:
      }
    onPushReceive(paramContext, paramIntent);
    return;
    onPushDismiss(paramContext, paramIntent);
    return;
    onPushOpen(paramContext, paramIntent);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParsePushBroadcastReceiver
 * JD-Core Version:    0.6.0
 */