package com.parse;

import android.content.Context;
import android.net.http.AndroidHttpClient;
import android.os.Build.VERSION;
import bolts.Continuation;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.http.HttpEntity;
import org.apache.http.HttpRequest;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;

abstract class ParseRequest<Response, Result>
{
  private static final int CORE_POOL_SIZE = 0;
  private static final int CPU_COUNT = 0;
  static final long DEFAULT_INITIAL_RETRY_DELAY = 1000L;
  protected static final int DEFAULT_MAX_RETRIES = 4;
  private static final long KEEP_ALIVE_TIME = 1L;
  private static final int MAX_POOL_SIZE = 0;
  private static final int MAX_QUEUE_SIZE = 128;
  static final ExecutorService NETWORK_EXECUTOR;
  private static final int SOCKET_OPERATION_TIMEOUT = 10000;
  private static ParseHttpClient defaultClient;
  private static long defaultInitialRetryDelay;
  private static final ThreadFactory sThreadFactory = new ThreadFactory()
  {
    private final AtomicInteger mCount = new AtomicInteger(1);

    public Thread newThread(Runnable paramRunnable)
    {
      return new Thread(paramRunnable, "ParseRequest.NETWORK_EXECUTOR-thread-" + this.mCount.getAndIncrement());
    }
  };
  private ParseHttpClient client = defaultClient;
  private AtomicReference<Task<Result>.TaskCompletionSource> currentTask = new AtomicReference();
  protected int maxRetries = 4;
  protected Method method;
  private HttpUriRequest request;
  protected String url;

  static
  {
    CPU_COUNT = Runtime.getRuntime().availableProcessors();
    CORE_POOL_SIZE = 1 + 2 * CPU_COUNT;
    MAX_POOL_SIZE = 1 + 2 * (2 * CPU_COUNT);
    NETWORK_EXECUTOR = newThreadPoolExecutor(CORE_POOL_SIZE, MAX_POOL_SIZE, 1L, TimeUnit.SECONDS, new LinkedBlockingQueue(128), sThreadFactory);
    defaultClient = null;
    defaultInitialRetryDelay = 1000L;
  }

  public ParseRequest(Method paramMethod, String paramString)
  {
    this.method = paramMethod;
    this.url = paramString;
  }

  public ParseRequest(String paramString)
  {
    this(Method.GET, paramString);
  }

  private Task<Response> executeAsync(int paramInt, long paramLong, ProgressCallback paramProgressCallback)
  {
    return sendOneRequestAsync(paramProgressCallback).continueWithTask(new Continuation(paramInt, paramLong, paramProgressCallback)
    {
      public Task<Response> then(Task<Response> paramTask)
        throws Exception
      {
        Exception localException = paramTask.getError();
        if ((paramTask.isFaulted()) && ((localException instanceof ParseException)))
        {
          if (!((Task.TaskCompletionSource)ParseRequest.this.currentTask.get()).getTask().isCancelled())
            break label47;
          paramTask = Task.cancelled();
        }
        label47: 
        do
        {
          do
            return paramTask;
          while (((localException instanceof ParseRequest.ParseRequestException)) && (((ParseRequest.ParseRequestException)localException).isPermanentFailure));
          if (this.val$attemptsMade >= ParseRequest.this.maxRetries)
            continue;
          Parse.logI("com.parse.ParseRequest", "Request failed. Waiting " + this.val$delay + " milliseconds before attempt #" + (1 + this.val$attemptsMade));
          Task.TaskCompletionSource localTaskCompletionSource = Task.create();
          Parse.getScheduledExecutor().schedule(new Runnable(localTaskCompletionSource)
          {
            public void run()
            {
              ParseRequest.this.executeAsync(1 + ParseRequest.8.this.val$attemptsMade, 2L * ParseRequest.8.this.val$delay, ParseRequest.8.this.val$downloadProgressCallback).continueWithTask(new Continuation()
              {
                public Task<Void> then(Task<Response> paramTask)
                  throws Exception
                {
                  if (paramTask.isCancelled())
                    ParseRequest.8.1.this.val$retryTask.setCancelled();
                  while (true)
                  {
                    return null;
                    if (paramTask.isFaulted())
                    {
                      ParseRequest.8.1.this.val$retryTask.setError(paramTask.getError());
                      continue;
                    }
                    ParseRequest.8.1.this.val$retryTask.setResult(paramTask.getResult());
                  }
                }
              });
            }
          }
          , this.val$delay, TimeUnit.MILLISECONDS);
          return localTaskCompletionSource.getTask();
        }
        while (ParseRequest.this.request.isAborted());
        Parse.logI("com.parse.ParseRequest", "Request failed. Giving up.");
        return paramTask;
      }
    });
  }

  public static ParseHttpClient getDefaultClient()
  {
    if (defaultClient == null)
      throw new IllegalStateException("Can't send Parse HTTPS request before Parse.initialize()");
    return defaultClient;
  }

  public static long getDefaultInitialRetryDelay()
  {
    return defaultInitialRetryDelay;
  }

  public static void initialize(Context paramContext)
  {
    if (defaultClient == null)
      defaultClient = ParseHttpClient.create(paramContext);
  }

  private static ThreadPoolExecutor newThreadPoolExecutor(int paramInt1, int paramInt2, long paramLong, TimeUnit paramTimeUnit, BlockingQueue<Runnable> paramBlockingQueue, ThreadFactory paramThreadFactory)
  {
    ThreadPoolExecutor localThreadPoolExecutor = new ThreadPoolExecutor(paramInt1, paramInt2, paramLong, paramTimeUnit, paramBlockingQueue, paramThreadFactory);
    if (Build.VERSION.SDK_INT >= 9)
      localThreadPoolExecutor.allowCoreThreadTimeOut(true);
    return localThreadPoolExecutor;
  }

  private Task<Response> sendOneRequestAsync(ProgressCallback paramProgressCallback)
  {
    if (((Task.TaskCompletionSource)this.currentTask.get()).getTask().isCancelled())
      return Task.cancelled();
    return Task.forResult(null).onSuccessTask(new Continuation(paramProgressCallback)
    {
      public Task<Response> then(Task<Void> paramTask)
        throws Exception
      {
        ParseHttpResponse localParseHttpResponse = ParseRequest.this.client.execute(ParseRequest.this.request);
        return ParseRequest.this.onResponse(localParseHttpResponse, this.val$downloadProgressCallback);
      }
    }
    , NETWORK_EXECUTOR).continueWithTask(new Continuation()
    {
      public Task<Response> then(Task<Response> paramTask)
        throws Exception
      {
        Exception localException;
        if (paramTask.isFaulted())
        {
          localException = paramTask.getError();
          if (!(localException instanceof ClientProtocolException))
            break label35;
          paramTask = Task.forError(ParseRequest.this.newTemporaryException("bad protocol", localException));
        }
        label35: 
        do
          return paramTask;
        while (!(localException instanceof IOException));
        return Task.forError(ParseRequest.this.newTemporaryException("i/o failure", localException));
      }
    }
    , Task.BACKGROUND_EXECUTOR);
  }

  public static void setDefaultClient(ParseHttpClient paramParseHttpClient)
  {
    defaultClient = paramParseHttpClient;
  }

  public static void setDefaultInitialRetryDelay(long paramLong)
  {
    defaultInitialRetryDelay = paramLong;
  }

  public void cancel()
  {
    Task.TaskCompletionSource localTaskCompletionSource = (Task.TaskCompletionSource)this.currentTask.get();
    if (localTaskCompletionSource != null)
      localTaskCompletionSource.trySetCancelled();
    if (this.request != null)
      this.request.abort();
  }

  public Task<Result> executeAsync()
  {
    return executeAsync(null, null);
  }

  public Task<Result> executeAsync(ProgressCallback paramProgressCallback1, ProgressCallback paramProgressCallback2)
  {
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    this.currentTask.set(localTaskCompletionSource);
    Task.forResult(null).continueWithTask(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseRequest.this.onPreExecute(paramTask);
      }
    }).onSuccessTask(new Continuation(paramProgressCallback1, paramProgressCallback2)
    {
      public Task<Response> then(Task<Void> paramTask)
        throws Exception
      {
        long l = ParseRequest.defaultInitialRetryDelay + ()(ParseRequest.defaultInitialRetryDelay * Math.random());
        if (ParseRequest.this.request == null)
          ParseRequest.access$002(ParseRequest.this, ParseRequest.this.newRequest(ParseRequest.this.method, this.val$uploadProgressCallback));
        return ParseRequest.this.executeAsync(0, l, this.val$downloadProgressCallback);
      }
    }).onSuccessTask(new Continuation()
    {
      public Task<Result> then(Task<Response> paramTask)
        throws Exception
      {
        return ParseRequest.this.onPostExecute(paramTask);
      }
    }).continueWithTask(new Continuation(localTaskCompletionSource)
    {
      public Task<Void> then(Task<Result> paramTask)
        throws Exception
      {
        if (paramTask.isCancelled())
          this.val$tcs.trySetCancelled();
        while (true)
        {
          return null;
          if (paramTask.isFaulted())
          {
            this.val$tcs.trySetError(paramTask.getError());
            continue;
          }
          this.val$tcs.trySetResult(paramTask.getResult());
        }
      }
    });
    return localTaskCompletionSource.getTask();
  }

  protected HttpEntity newEntity(ProgressCallback paramProgressCallback)
  {
    return null;
  }

  protected ParseException newPermanentException(int paramInt, String paramString)
  {
    ParseRequestException localParseRequestException = new ParseRequestException(paramInt, paramString);
    localParseRequestException.isPermanentFailure = true;
    return localParseRequestException;
  }

  protected HttpUriRequest newRequest(Method paramMethod, ProgressCallback paramProgressCallback)
    throws ParseException
  {
    Object localObject1;
    switch (9.$SwitchMap$com$parse$ParseRequest$Method[paramMethod.ordinal()])
    {
    default:
      throw new IllegalStateException("Invalid method " + paramMethod);
    case 1:
      localObject1 = new HttpGet(this.url);
    case 4:
    case 2:
    case 3:
    }
    while (true)
    {
      AndroidHttpClient.modifyRequestToAcceptGzipResponse((HttpRequest)localObject1);
      return localObject1;
      localObject1 = new HttpDelete(this.url);
      continue;
      boolean bool1 = this.url.contains(".s3.amazonaws.com");
      Object localObject2 = null;
      if (bool1)
      {
        Matcher localMatcher = Pattern.compile("^https://([a-zA-Z0-9.]*\\.s3\\.amazonaws\\.com)/?.*").matcher(this.url);
        boolean bool2 = localMatcher.matches();
        localObject2 = null;
        if (bool2)
        {
          String str = localMatcher.group(1);
          this.url = this.url.replace(str, "s3.amazonaws.com");
          localObject2 = str;
        }
      }
      HttpPost localHttpPost = new HttpPost(this.url);
      localHttpPost.setEntity(newEntity(paramProgressCallback));
      if (localObject2 != null)
        localHttpPost.addHeader("Host", localObject2);
      localObject1 = localHttpPost;
      continue;
      HttpPut localHttpPut = new HttpPut(this.url);
      localHttpPut.setEntity(newEntity(paramProgressCallback));
      localObject1 = localHttpPut;
    }
  }

  protected ParseException newTemporaryException(int paramInt, String paramString)
  {
    ParseRequestException localParseRequestException = new ParseRequestException(paramInt, paramString);
    localParseRequestException.isPermanentFailure = false;
    return localParseRequestException;
  }

  protected ParseException newTemporaryException(String paramString, Throwable paramThrowable)
  {
    ParseRequestException localParseRequestException = new ParseRequestException(100, paramString, paramThrowable);
    localParseRequestException.isPermanentFailure = false;
    return localParseRequestException;
  }

  protected Task<Result> onPostExecute(Task<Response> paramTask)
    throws ParseException
  {
    return paramTask.cast();
  }

  protected Task<Void> onPreExecute(Task<Void> paramTask)
  {
    return paramTask;
  }

  protected abstract Task<Response> onResponse(ParseHttpResponse paramParseHttpResponse, ProgressCallback paramProgressCallback);

  public void setClient(ParseHttpClient paramParseHttpClient)
  {
    this.client = paramParseHttpClient;
  }

  public void setMaxRetries(int paramInt)
  {
    this.maxRetries = paramInt;
  }

  public void setMethod(Method paramMethod)
  {
    this.method = paramMethod;
  }

  public void setUrl(String paramString)
  {
    this.url = paramString;
  }

  public static enum Method
  {
    static
    {
      DELETE = new Method("DELETE", 3);
      Method[] arrayOfMethod = new Method[4];
      arrayOfMethod[0] = GET;
      arrayOfMethod[1] = POST;
      arrayOfMethod[2] = PUT;
      arrayOfMethod[3] = DELETE;
      $VALUES = arrayOfMethod;
    }

    public static Method fromString(String paramString)
    {
      int i = -1;
      switch (paramString.hashCode())
      {
      default:
      case 70454:
      case 2461856:
      case 79599:
      case 2012838315:
      }
      while (true)
        switch (i)
        {
        default:
          return null;
          if (!paramString.equals("GET"))
            continue;
          i = 0;
          continue;
          if (!paramString.equals("POST"))
            continue;
          i = 1;
          continue;
          if (!paramString.equals("PUT"))
            continue;
          i = 2;
          continue;
          if (!paramString.equals("DELETE"))
            continue;
          i = 3;
        case 0:
        case 1:
        case 2:
        case 3:
        }
      return GET;
      return POST;
      return PUT;
      return DELETE;
    }

    public String toString()
    {
      switch (ParseRequest.9.$SwitchMap$com$parse$ParseRequest$Method[ordinal()])
      {
      default:
        return null;
      case 1:
        return "GET";
      case 2:
        return "POST";
      case 3:
        return "PUT";
      case 4:
      }
      return "DELETE";
    }
  }

  private static class ParseRequestException extends ParseException
  {
    boolean isPermanentFailure = false;

    public ParseRequestException(int paramInt, String paramString)
    {
      super(paramString);
    }

    public ParseRequestException(int paramInt, String paramString, Throwable paramThrowable)
    {
      super(paramString, paramThrowable);
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseRequest
 * JD-Core Version:    0.6.0
 */