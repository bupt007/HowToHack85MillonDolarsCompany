package com.parse;

import android.content.Context;
import bolts.Capture;
import bolts.Continuation;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import java.io.File;
import java.lang.reflect.Member;
import java.lang.reflect.Modifier;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.SimpleTimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ParseObject
{
  static final String API_VERSION = "2";
  private static final String AUTO_CLASS_NAME = "_Automatic";
  public static final String DEFAULT_PIN = "_default";
  private static final String KEY_ACL = "ACL";
  private static final String KEY_CLASS_NAME = "className";
  private static final String KEY_COMPLETE = "__complete";
  private static final String KEY_CREATED_AT = "createdAt";
  private static final String KEY_OBJECT_ID = "objectId";
  private static final String KEY_OPERATIONS = "__operations";
  private static final String KEY_TYPE = "__type";
  private static final String KEY_UPDATED_AT = "updatedAt";
  private static final String NEW_OFFLINE_OBJECT_ID_PLACEHOLDER = "*** Offline Object ***";
  private static final String TAG = "com.parse.ParseObject";
  static final String VERSION_NAME = "1.9.1";
  private static final Map<Class<? extends ParseObject>, String> classNames;
  private static final DateFormat impreciseDateFormat;
  private static final ThreadLocal<String> isCreatingPointerForObjectId;
  private static final Map<String, Class<? extends ParseObject>> objectTypes;
  static String server = "https://api.parse.com";
  private String className;
  private Date createdAt;
  private final Map<String, Boolean> dataAvailability;
  private final Map<String, Object> estimatedData;
  boolean hasBeenFetched;
  private final Map<Object, ParseJSONCacheItem> hashedObjects;
  boolean isDeleted;
  int isDeletingEventually;
  private String localId;
  final Object mutex = new Object();
  private String objectId;
  final LinkedList<ParseOperationSet> operationSetQueue;
  private final ParseMulticastDelegate<ParseObject> saveEvent = new ParseMulticastDelegate();
  private final Map<String, Object> serverData;
  final TaskQueue taskQueue = new TaskQueue();
  private Date updatedAt;

  static
  {
    classNames = new ConcurrentHashMap();
    objectTypes = new ConcurrentHashMap();
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
    localSimpleDateFormat.setTimeZone(new SimpleTimeZone(0, "GMT"));
    impreciseDateFormat = localSimpleDateFormat;
    isCreatingPointerForObjectId = new ThreadLocal()
    {
      protected String initialValue()
      {
        return null;
      }
    };
  }

  protected ParseObject()
  {
    this("_Automatic");
  }

  public ParseObject(String paramString)
  {
    String str = (String)isCreatingPointerForObjectId.get();
    if (paramString == null)
      throw new IllegalArgumentException("You must specify a Parse class name when creating a new ParseObject.");
    if ("_Automatic".equals(paramString))
      paramString = getClassName(getClass());
    if ((getClass().equals(ParseObject.class)) && (objectTypes.containsKey(paramString)) && (!((Class)objectTypes.get(paramString)).isInstance(this)))
      throw new IllegalArgumentException("You must create this type of ParseObject using ParseObject.create() or the proper subclass.");
    if ((!getClass().equals(ParseObject.class)) && (!getClass().equals(objectTypes.get(paramString))))
      throw new IllegalArgumentException("You must register this ParseObject subclass before instantiating it.");
    this.localId = null;
    this.serverData = new HashMap();
    this.operationSetQueue = new LinkedList();
    this.operationSetQueue.add(new ParseOperationSet());
    this.estimatedData = new HashMap();
    this.hashedObjects = new IdentityHashMap();
    this.dataAvailability = new HashMap();
    this.className = paramString;
    if (str == null)
      setDefaultValues();
    for (this.hasBeenFetched = true; ; this.hasBeenFetched = false)
    {
      OfflineStore localOfflineStore = OfflineStore.getCurrent();
      if (localOfflineStore != null)
        localOfflineStore.registerNewObject(this);
      return;
      if (str.equals("*** Offline Object ***"))
        continue;
      this.objectId = str;
    }
  }

  private void applyOperations(ParseOperationSet paramParseOperationSet, Map<String, Object> paramMap)
  {
    while (true)
    {
      String str;
      synchronized (this.mutex)
      {
        Iterator localIterator = paramParseOperationSet.keySet().iterator();
        if (!localIterator.hasNext())
          break;
        str = (String)localIterator.next();
        Object localObject3 = ((ParseFieldOperation)paramParseOperationSet.get(str)).apply(paramMap.get(str), this, str);
        if (localObject3 != null)
          paramMap.put(str, localObject3);
      }
      paramMap.remove(str);
    }
    monitorexit;
  }

  private boolean canBeSerialized()
  {
    synchronized (this.mutex)
    {
      Capture localCapture = new Capture(Boolean.valueOf(true));
      new ParseTraverser(localCapture)
      {
        protected boolean visit(Object paramObject)
        {
          if (((paramObject instanceof ParseObject)) && (((ParseObject)paramObject).getObjectId() == null))
            this.val$result.set(Boolean.valueOf(false));
          return ((Boolean)this.val$result.get()).booleanValue();
        }
      }
      .setYieldRoot(false).setTraverseParseObjects(true).traverse(this);
      boolean bool = ((Boolean)localCapture.get()).booleanValue();
      return bool;
    }
  }

  private void checkForChangesToMutableContainer(String paramString, Object paramObject)
  {
    ParseJSONCacheItem localParseJSONCacheItem1;
    synchronized (this.mutex)
    {
      if (Parse.isContainerObject(paramObject))
      {
        localParseJSONCacheItem1 = (ParseJSONCacheItem)this.hashedObjects.get(paramObject);
        if (localParseJSONCacheItem1 == null)
          throw new IllegalArgumentException("ParseObject contains container item that isn't cached.");
      }
    }
    while (true)
    {
      try
      {
        ParseJSONCacheItem localParseJSONCacheItem2 = new ParseJSONCacheItem(paramObject);
        if (localParseJSONCacheItem1.equals(localParseJSONCacheItem2))
          continue;
        performOperation(paramString, new ParseSetOperation(paramObject));
        monitorexit;
        return;
      }
      catch (JSONException localJSONException)
      {
        throw new RuntimeException(localJSONException);
      }
      this.hashedObjects.remove(paramObject);
    }
  }

  private void checkGetAccess(String paramString)
  {
    if (!isDataAvailable(paramString))
      throw new IllegalStateException("ParseObject has no data for this key.  Call fetchIfNeeded() to get the data.");
  }

  private void checkKeyIsMutable(String paramString)
  {
    if (!isKeyMutable(paramString))
      throw new IllegalArgumentException("Cannot modify `" + paramString + "` property of an " + getClassName() + " object.");
  }

  private void checkpointAllMutableContainers()
  {
    synchronized (this.mutex)
    {
      Iterator localIterator = this.estimatedData.values().iterator();
      if (localIterator.hasNext())
        checkpointMutableContainer(localIterator.next());
    }
    monitorexit;
  }

  private void checkpointMutableContainer(Object paramObject)
  {
    synchronized (this.mutex)
    {
      boolean bool = Parse.isContainerObject(paramObject);
      if (bool);
      try
      {
        ParseJSONCacheItem localParseJSONCacheItem = new ParseJSONCacheItem(paramObject);
        this.hashedObjects.put(paramObject, localParseJSONCacheItem);
        return;
      }
      catch (JSONException localJSONException)
      {
        throw new RuntimeException(localJSONException);
      }
    }
  }

  private static void collectDirtyChildren(Object paramObject, List<ParseObject> paramList, List<ParseFile> paramList1)
  {
    collectDirtyChildren(paramObject, paramList, paramList1, new IdentityHashMap(), new IdentityHashMap());
  }

  private static void collectDirtyChildren(Object paramObject, List<ParseObject> paramList, List<ParseFile> paramList1, IdentityHashMap<ParseObject, ParseObject> paramIdentityHashMap1, IdentityHashMap<ParseObject, ParseObject> paramIdentityHashMap2)
  {
    new ParseTraverser(paramList1, paramList, paramIdentityHashMap1, paramIdentityHashMap2)
    {
      protected boolean visit(Object paramObject)
      {
        if ((paramObject instanceof ParseFile))
          if (this.val$dirtyFiles != null);
        label199: 
        while (true)
        {
          return true;
          ParseFile localParseFile = (ParseFile)paramObject;
          if (localParseFile.getUrl() != null)
            continue;
          this.val$dirtyFiles.add(localParseFile);
          return true;
          if ((!(paramObject instanceof ParseObject)) || (this.val$dirtyChildren == null))
            continue;
          ParseObject localParseObject = (ParseObject)paramObject;
          IdentityHashMap localIdentityHashMap1 = this.val$alreadySeen;
          IdentityHashMap localIdentityHashMap2 = this.val$alreadySeenNew;
          if (localParseObject.getObjectId() != null);
          IdentityHashMap localIdentityHashMap4;
          for (Object localObject = new IdentityHashMap(); ; localObject = localIdentityHashMap4)
          {
            if (localIdentityHashMap1.containsKey(localParseObject))
              break label199;
            IdentityHashMap localIdentityHashMap3 = new IdentityHashMap(localIdentityHashMap1);
            localIdentityHashMap3.put(localParseObject, localParseObject);
            ParseObject.access$1300(localParseObject.estimatedData, this.val$dirtyChildren, this.val$dirtyFiles, localIdentityHashMap3, (IdentityHashMap)localObject);
            if (!localParseObject.isDirty(false))
              break;
            this.val$dirtyChildren.add(localParseObject);
            return true;
            if (localIdentityHashMap2.containsKey(localParseObject))
              throw new RuntimeException("Found a circular dependency while saving.");
            localIdentityHashMap4 = new IdentityHashMap(localIdentityHashMap2);
            localIdentityHashMap4.put(localParseObject, localParseObject);
          }
        }
      }
    }
    .setYieldRoot(true).traverse(paramObject);
  }

  private Map<String, ParseObject> collectFetchedObjects()
  {
    HashMap localHashMap = new HashMap();
    new ParseTraverser(localHashMap)
    {
      protected boolean visit(Object paramObject)
      {
        if ((paramObject instanceof ParseObject))
        {
          ParseObject localParseObject = (ParseObject)paramObject;
          if ((localParseObject.objectId != null) && (localParseObject.isDataAvailable()))
            this.val$fetchedObjects.put(localParseObject.objectId, localParseObject);
        }
        return true;
      }
    }
    .traverse(this.estimatedData);
    return localHashMap;
  }

  public static <T extends ParseObject> T create(Class<T> paramClass)
  {
    return create(getClassName(paramClass));
  }

  public static ParseObject create(String paramString)
  {
    if (objectTypes.containsKey(paramString))
      try
      {
        ParseObject localParseObject = (ParseObject)((Class)objectTypes.get(paramString)).newInstance();
        return localParseObject;
      }
      catch (Exception localException)
      {
        if ((localException instanceof RuntimeException))
          throw ((RuntimeException)localException);
        throw new RuntimeException("Failed to create instance of subclass.", localException);
      }
    return new ParseObject(paramString);
  }

  public static <T extends ParseObject> T createWithoutData(Class<T> paramClass, String paramString)
  {
    return createWithoutData(getClassName(paramClass), paramString);
  }

  // ERROR //
  public static ParseObject createWithoutData(String paramString1, String paramString2)
  {
    // Byte code:
    //   0: invokestatic 229	com/parse/OfflineStore:getCurrent	()Lcom/parse/OfflineStore;
    //   3: astore_2
    //   4: aload_1
    //   5: ifnonnull +91 -> 96
    //   8: getstatic 130	com/parse/ParseObject:isCreatingPointerForObjectId	Ljava/lang/ThreadLocal;
    //   11: ldc 41
    //   13: invokevirtual 477	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
    //   16: aload_2
    //   17: ifnull +102 -> 119
    //   20: aload_1
    //   21: ifnull +98 -> 119
    //   24: aload_2
    //   25: aload_0
    //   26: aload_1
    //   27: invokevirtual 481	com/parse/OfflineStore:getOrCreateObjectWithoutData	(Ljava/lang/String;Ljava/lang/String;)Landroid/util/Pair;
    //   30: astore 9
    //   32: aload 9
    //   34: getfield 486	android/util/Pair:first	Ljava/lang/Object;
    //   37: checkcast 2	com/parse/ParseObject
    //   40: astore 6
    //   42: aload 9
    //   44: getfield 489	android/util/Pair:second	Ljava/lang/Object;
    //   47: checkcast 343	java/lang/Boolean
    //   50: invokevirtual 371	java/lang/Boolean:booleanValue	()Z
    //   53: istore 7
    //   55: iload 7
    //   57: ifeq +78 -> 135
    //   60: aload 6
    //   62: invokevirtual 492	com/parse/ParseObject:hasChanges	()Z
    //   65: ifeq +70 -> 135
    //   68: new 403	java/lang/IllegalStateException
    //   71: dup
    //   72: ldc_w 494
    //   75: invokespecial 406	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   78: athrow
    //   79: astore 8
    //   81: aload 8
    //   83: athrow
    //   84: astore 4
    //   86: getstatic 130	com/parse/ParseObject:isCreatingPointerForObjectId	Ljava/lang/ThreadLocal;
    //   89: aconst_null
    //   90: invokevirtual 477	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
    //   93: aload 4
    //   95: athrow
    //   96: getstatic 130	com/parse/ParseObject:isCreatingPointerForObjectId	Ljava/lang/ThreadLocal;
    //   99: aload_1
    //   100: invokevirtual 477	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
    //   103: goto -87 -> 16
    //   106: astore_3
    //   107: new 397	java/lang/RuntimeException
    //   110: dup
    //   111: ldc_w 466
    //   114: aload_3
    //   115: invokespecial 469	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   118: athrow
    //   119: aload_0
    //   120: invokestatic 459	com/parse/ParseObject:create	(Ljava/lang/String;)Lcom/parse/ParseObject;
    //   123: astore 5
    //   125: aload 5
    //   127: astore 6
    //   129: iconst_1
    //   130: istore 7
    //   132: goto -77 -> 55
    //   135: getstatic 130	com/parse/ParseObject:isCreatingPointerForObjectId	Ljava/lang/ThreadLocal;
    //   138: aconst_null
    //   139: invokevirtual 477	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
    //   142: aload 6
    //   144: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   8	16	79	java/lang/RuntimeException
    //   24	55	79	java/lang/RuntimeException
    //   60	79	79	java/lang/RuntimeException
    //   96	103	79	java/lang/RuntimeException
    //   119	125	79	java/lang/RuntimeException
    //   8	16	84	finally
    //   24	55	84	finally
    //   60	79	84	finally
    //   81	84	84	finally
    //   96	103	84	finally
    //   107	119	84	finally
    //   119	125	84	finally
    //   8	16	106	java/lang/Exception
    //   24	55	106	java/lang/Exception
    //   60	79	106	java/lang/Exception
    //   96	103	106	java/lang/Exception
    //   119	125	106	java/lang/Exception
  }

  private ParseRESTObjectCommand currentDeleteCommand(String paramString)
  {
    synchronized (this.mutex)
    {
      ParseRESTObjectCommand localParseRESTObjectCommand = ParseRESTObjectCommand.deleteObjectCommand(this.objectId, this.className, paramString);
      localParseRESTObjectCommand.enableRetrying();
      return localParseRESTObjectCommand;
    }
  }

  private ParseOperationSet currentOperations()
  {
    synchronized (this.mutex)
    {
      ParseOperationSet localParseOperationSet = (ParseOperationSet)this.operationSetQueue.getLast();
      return localParseOperationSet;
    }
  }

  private static Task<Void> deepSaveAsync(Object paramObject, String paramString)
  {
    ParseUser localParseUser = ParseUser.getCurrentUser();
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    collectDirtyChildren(paramObject, localArrayList1, localArrayList2);
    ArrayList localArrayList3 = new ArrayList();
    Iterator localIterator = localArrayList2.iterator();
    while (localIterator.hasNext())
      localArrayList3.add(((ParseFile)localIterator.next()).saveAsync(paramString, null));
    return Task.whenAll(localArrayList3).onSuccessTask(new Continuation(localArrayList1, localParseUser, paramString)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        IdentityHashMap localIdentityHashMap = new IdentityHashMap();
        Iterator localIterator = this.val$objects.iterator();
        while (localIterator.hasNext())
          localIdentityHashMap.put((ParseObject)localIterator.next(), Boolean.valueOf(true));
        Capture localCapture = new Capture(new ArrayList(localIdentityHashMap.keySet()));
        return Task.forResult(null).continueWhile(new Callable(localCapture)
        {
          public Boolean call()
            throws Exception
          {
            if (((List)this.val$remaining.get()).size() > 0);
            for (boolean bool = true; ; bool = false)
              return Boolean.valueOf(bool);
          }
        }
        , new Continuation(localCapture)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            ArrayList localArrayList1 = new ArrayList();
            ArrayList localArrayList2 = new ArrayList();
            Iterator localIterator = ((List)this.val$remaining.get()).iterator();
            while (localIterator.hasNext())
            {
              ParseObject localParseObject = (ParseObject)localIterator.next();
              if (localParseObject.canBeSerialized())
              {
                localArrayList1.add(localParseObject);
                continue;
              }
              localArrayList2.add(localParseObject);
            }
            this.val$remaining.set(localArrayList2);
            if (localArrayList1.size() == 0)
              throw new RuntimeException("Unable to save a ParseObject with a relation to a cycle.");
            Task localTask = Task.forResult(null);
            if ((ParseObject.40.this.val$currentUser != null) && (ParseObject.40.this.val$currentUser.isLazy()) && (localArrayList1.contains(ParseObject.40.this.val$currentUser)))
              localTask = localTask.onSuccessTask(new Continuation()
              {
                public Task<Void> then(Task<Void> paramTask)
                  throws Exception
                {
                  return ParseObject.40.this.val$currentUser.saveInBackground();
                }
              }).onSuccess(new Continuation(localArrayList1)
              {
                public Void then(Task<Void> paramTask)
                  throws Exception
                {
                  this.val$current.remove(ParseObject.40.this.val$currentUser);
                  return null;
                }
              });
            return localTask.onSuccessTask(new Continuation(localArrayList1)
            {
              public Task<Void> then(Task<Void> paramTask)
                throws Exception
              {
                if (this.val$current.size() == 0)
                  return Task.forResult(null);
                List localList1 = Parse.partitionList(this.val$current, 50);
                ArrayList localArrayList = new ArrayList();
                Iterator localIterator = localList1.iterator();
                while (localIterator.hasNext())
                {
                  List localList2 = (List)localIterator.next();
                  localArrayList.add(ParseObject.enqueueForAll(localList2, new Continuation(localList2)
                  {
                    public Task<Void> then(Task<Void> paramTask)
                      throws Exception
                    {
                      return paramTask.continueWithTask(new Continuation()
                      {
                        public Task<Void> then(Task<Void> paramTask)
                          throws Exception
                        {
                          ArrayList localArrayList1 = new ArrayList();
                          ArrayList localArrayList2 = new ArrayList();
                          Iterator localIterator = ParseObject.40.2.3.1.this.val$batch.iterator();
                          while (localIterator.hasNext())
                          {
                            ParseObject localParseObject = (ParseObject)localIterator.next();
                            synchronized (localParseObject.mutex)
                            {
                              localParseObject.validateSave();
                              ParseOperationSet localParseOperationSet = localParseObject.startSave();
                              localArrayList2.add(localParseOperationSet);
                              localArrayList1.add(localParseObject.currentSaveCommand(localParseOperationSet, PointerEncodingStrategy.get(), ParseObject.40.this.val$sessionToken));
                            }
                          }
                          return ParseRESTObjectBatchCommand.batchCommand(localArrayList1, ParseObject.40.this.val$sessionToken).executeAsync().cast().continueWithTask(new Continuation(localArrayList2)
                          {
                            public Task<Void> then(Task<JSONArray> paramTask)
                              throws Exception
                            {
                              JSONArray localJSONArray = (JSONArray)paramTask.getResult();
                              ArrayList localArrayList = new ArrayList();
                              for (int i = 0; i < ParseObject.40.2.3.this.val$current.size(); i++)
                              {
                                boolean bool = paramTask.isFaulted();
                                JSONObject localJSONObject = null;
                                if (!bool)
                                  localJSONObject = localJSONArray.getJSONObject(i).optJSONObject("success");
                                localArrayList.add(((ParseObject)ParseObject.40.2.3.this.val$current.get(i)).handleSaveResultAsync(localJSONObject, (ParseOperationSet)this.val$operations.get(i)));
                              }
                              return Task.whenAll(localArrayList).continueWithTask(new Continuation(paramTask, localArrayList)
                              {
                                public Task<Void> then(Task<Void> paramTask)
                                  throws Exception
                                {
                                  if ((this.val$commandTask.isFaulted()) || (this.val$commandTask.isCancelled()))
                                    return this.val$commandTask.makeVoid();
                                  if (paramTask.isFaulted())
                                  {
                                    Iterator localIterator = this.val$tasks.iterator();
                                    while (localIterator.hasNext())
                                    {
                                      Task localTask = (Task)localIterator.next();
                                      if (localTask.isFaulted())
                                        return localTask;
                                    }
                                  }
                                  return paramTask;
                                }
                              });
                            }
                          });
                        }
                      });
                    }
                  }));
                }
                return Task.whenAll(localArrayList);
              }
            });
          }
        });
      }
    });
  }

  public static <T extends ParseObject> void deleteAll(List<T> paramList)
    throws ParseException
  {
    Parse.waitForTask(deleteAllAsync(paramList, ParseUser.getCurrentSessionToken()));
  }

  private static <T extends ParseObject> Task<Void> deleteAllAsync(List<T> paramList, String paramString)
  {
    if (paramList.size() == 0)
      return Task.forResult(null);
    return Task.callInBackground(new Callable(paramList)
    {
      public List<ParseObject> call()
      {
        ArrayList localArrayList = new ArrayList();
        HashSet localHashSet = new HashSet();
        Iterator localIterator = this.val$objects.iterator();
        while (localIterator.hasNext())
        {
          ParseObject localParseObject = (ParseObject)localIterator.next();
          if (localHashSet.contains(localParseObject.getObjectId()))
            continue;
          localHashSet.add(localParseObject.getObjectId());
          localArrayList.add(localParseObject);
        }
        return localArrayList;
      }
    }).continueWithTask(new Continuation(paramString)
    {
      public Task<Void> then(Task<List<ParseObject>> paramTask)
        throws Exception
      {
        List localList = (List)paramTask.getResult();
        return ParseObject.enqueueForAll(localList, new Continuation(localList)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return paramTask.continueWithTask(new Continuation()
            {
              public Task<Void> then(Task<Void> paramTask)
                throws Exception
              {
                ArrayList localArrayList1 = new ArrayList();
                Iterator localIterator1 = ParseObject.36.1.this.val$uniqueObjects.iterator();
                while (localIterator1.hasNext())
                  localArrayList1.add(((ParseObject)localIterator1.next()).currentDeleteCommand(ParseObject.36.this.val$sessionToken));
                List localList = ParseRESTObjectBatchCommand.batchCommands(localArrayList1, ParseObject.36.this.val$sessionToken);
                ArrayList localArrayList2 = new ArrayList();
                Iterator localIterator2 = localList.iterator();
                while (localIterator2.hasNext())
                  localArrayList2.add(((ParseRESTCommand)localIterator2.next()).executeAsync().makeVoid());
                return Task.whenAll(localArrayList2).makeVoid();
              }
            });
          }
        });
      }
    });
  }

  public static <T extends ParseObject> Task<Void> deleteAllInBackground(List<T> paramList)
  {
    return deleteAllAsync(paramList, ParseUser.getCurrentSessionToken());
  }

  public static <T extends ParseObject> void deleteAllInBackground(List<T> paramList, DeleteCallback paramDeleteCallback)
  {
    Parse.callbackOnMainThreadAsync(deleteAllInBackground(paramList), paramDeleteCallback);
  }

  private Task<Void> deleteAsync(Task<Void> paramTask)
  {
    String str = ParseUser.getCurrentSessionToken();
    return Task.forResult(null).onSuccessTask(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        synchronized (ParseObject.this.mutex)
        {
          ParseObject.this.validateDelete();
          if (ParseObject.this.objectId == null)
            return null;
          return paramTask;
        }
      }
    }).onSuccessTask(TaskQueue.waitFor(paramTask)).onSuccessTask(new Continuation(str)
    {
      public Task<Object> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseObject.this.deleteAsync(this.val$sessionToken);
      }
    }).onSuccessTask(new Continuation()
    {
      public Task<Void> then(Task<Object> paramTask)
        throws Exception
      {
        return ParseObject.this.handleDeleteResultAsync(paramTask.getResult());
      }
    });
  }

  // ERROR //
  static <T> Task<T> enqueueForAll(List<? extends ParseObject> paramList, Continuation<Void, Task<T>> paramContinuation)
  {
    // Byte code:
    //   0: invokestatic 610	bolts/Task:create	()Lbolts/Task$TaskCompletionSource;
    //   3: astore_2
    //   4: new 516	java/util/ArrayList
    //   7: dup
    //   8: aload_0
    //   9: invokeinterface 563 1 0
    //   14: invokespecial 613	java/util/ArrayList:<init>	(I)V
    //   17: astore_3
    //   18: aload_0
    //   19: invokeinterface 522 1 0
    //   24: astore 4
    //   26: aload 4
    //   28: invokeinterface 322 1 0
    //   33: ifeq +29 -> 62
    //   36: aload_3
    //   37: aload 4
    //   39: invokeinterface 325 1 0
    //   44: checkcast 2	com/parse/ParseObject
    //   47: getfield 146	com/parse/ParseObject:taskQueue	Lcom/parse/TaskQueue;
    //   50: invokevirtual 617	com/parse/TaskQueue:getLock	()Ljava/util/concurrent/locks/Lock;
    //   53: invokeinterface 529 2 0
    //   58: pop
    //   59: goto -33 -> 26
    //   62: new 619	com/parse/LockSet
    //   65: dup
    //   66: aload_3
    //   67: invokespecial 622	com/parse/LockSet:<init>	(Ljava/util/Collection;)V
    //   70: astore 5
    //   72: aload 5
    //   74: invokevirtual 625	com/parse/LockSet:lock	()V
    //   77: aload_1
    //   78: aload_2
    //   79: invokevirtual 631	bolts/Task$TaskCompletionSource:getTask	()Lbolts/Task;
    //   82: invokeinterface 636 2 0
    //   87: checkcast 531	bolts/Task
    //   90: astore 9
    //   92: new 516	java/util/ArrayList
    //   95: dup
    //   96: invokespecial 517	java/util/ArrayList:<init>	()V
    //   99: astore 10
    //   101: aload_0
    //   102: invokeinterface 522 1 0
    //   107: astore 11
    //   109: aload 11
    //   111: invokeinterface 322 1 0
    //   116: ifeq +61 -> 177
    //   119: aload 11
    //   121: invokeinterface 325 1 0
    //   126: checkcast 2	com/parse/ParseObject
    //   129: getfield 146	com/parse/ParseObject:taskQueue	Lcom/parse/TaskQueue;
    //   132: new 638	com/parse/ParseObject$2
    //   135: dup
    //   136: aload 10
    //   138: aload 9
    //   140: invokespecial 641	com/parse/ParseObject$2:<init>	(Ljava/util/List;Lbolts/Task;)V
    //   143: invokevirtual 644	com/parse/TaskQueue:enqueue	(Lbolts/Continuation;)Lbolts/Task;
    //   146: pop
    //   147: goto -38 -> 109
    //   150: astore 7
    //   152: aload 5
    //   154: invokevirtual 647	com/parse/LockSet:unlock	()V
    //   157: aload 7
    //   159: athrow
    //   160: astore 8
    //   162: aload 8
    //   164: athrow
    //   165: astore 6
    //   167: new 397	java/lang/RuntimeException
    //   170: dup
    //   171: aload 6
    //   173: invokespecial 400	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   176: athrow
    //   177: aload 10
    //   179: invokestatic 535	bolts/Task:whenAll	(Ljava/util/Collection;)Lbolts/Task;
    //   182: new 649	com/parse/ParseObject$3
    //   185: dup
    //   186: aload_2
    //   187: invokespecial 652	com/parse/ParseObject$3:<init>	(Lbolts/Task$TaskCompletionSource;)V
    //   190: invokevirtual 655	bolts/Task:continueWith	(Lbolts/Continuation;)Lbolts/Task;
    //   193: pop
    //   194: aload 5
    //   196: invokevirtual 647	com/parse/LockSet:unlock	()V
    //   199: aload 9
    //   201: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   77	92	150	finally
    //   92	109	150	finally
    //   109	147	150	finally
    //   162	165	150	finally
    //   167	177	150	finally
    //   177	194	150	finally
    //   77	92	160	java/lang/RuntimeException
    //   77	92	165	java/lang/Exception
  }

  private Task<Void> enqueueSaveEventuallyOperationAsync(ParseOperationSet paramParseOperationSet)
  {
    if (!paramParseOperationSet.isSaveEventually())
      throw new IllegalStateException("This should only be used to enqueue saveEventually operation sets");
    return this.taskQueue.enqueue(new Continuation(paramParseOperationSet)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return paramTask.continueWithTask(new Continuation()
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return Parse.getEventuallyQueue().waitForOperationSetAndEventuallyPin(ParseObject.16.this.val$operationSet, null).makeVoid();
          }
        });
      }
    });
  }

  public static <T extends ParseObject> List<T> fetchAll(List<T> paramList)
    throws ParseException
  {
    return (List)Parse.waitForTask(fetchAllInBackground(paramList));
  }

  private static <T extends ParseObject> Task<List<T>> fetchAllAsync(List<T> paramList, ParseUser paramParseUser, Task<Void> paramTask)
  {
    if (paramList.size() == 0)
      return Task.forResult(paramList);
    ArrayList localArrayList = new ArrayList();
    String str = ((ParseObject)paramList.get(0)).getClassName();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      ParseObject localParseObject = (ParseObject)localIterator.next();
      if (!localParseObject.getClassName().equals(str))
        throw new IllegalArgumentException("All objects should have the same class");
      if (localParseObject.getObjectId() == null)
        throw new IllegalArgumentException("All objects must exist on the server");
      localArrayList.add(localParseObject.getObjectId());
    }
    ParseQuery localParseQuery = ParseQuery.getQuery(str);
    localParseQuery.whereContainedIn("objectId", localArrayList);
    return paramTask.continueWithTask(new Continuation(localParseQuery, paramParseUser)
    {
      public Task<List<T>> then(Task<Void> paramTask)
        throws Exception
      {
        return this.val$query.findWithCachePolicyAsync(ParseQuery.CachePolicy.IGNORE_CACHE, this.val$user);
      }
    }).onSuccess(new Continuation(paramList)
    {
      public List<T> then(Task<List<T>> paramTask)
        throws Exception
      {
        HashMap localHashMap = new HashMap();
        Iterator localIterator1 = ((List)paramTask.getResult()).iterator();
        while (localIterator1.hasNext())
        {
          ParseObject localParseObject3 = (ParseObject)localIterator1.next();
          localHashMap.put(localParseObject3.getObjectId(), localParseObject3);
        }
        Iterator localIterator2 = this.val$objects.iterator();
        while (localIterator2.hasNext())
        {
          ParseObject localParseObject1 = (ParseObject)localIterator2.next();
          ParseObject localParseObject2 = (ParseObject)localHashMap.get(localParseObject1.getObjectId());
          if (localParseObject2 == null)
            throw new RuntimeException("Object id " + localParseObject1.getObjectId() + " does not exist");
          localParseObject1.mergeFromObject(localParseObject2);
          localParseObject1.hasBeenFetched = true;
        }
        return this.val$objects;
      }
    });
  }

  public static <T extends ParseObject> List<T> fetchAllIfNeeded(List<T> paramList)
    throws ParseException
  {
    return (List)Parse.waitForTask(fetchAllIfNeededInBackground(paramList));
  }

  private static <T extends ParseObject> Task<List<T>> fetchAllIfNeededAsync(List<T> paramList, ParseUser paramParseUser, Task<Void> paramTask)
  {
    ArrayList localArrayList = new ArrayList();
    String str1 = null;
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      ParseObject localParseObject = (ParseObject)localIterator.next();
      if (localParseObject.isDataAvailable())
        continue;
      if ((str1 != null) && (!str1.equals(localParseObject.getClassName())))
        throw new IllegalArgumentException("All objects should have the same class");
      str1 = localParseObject.getClassName();
      String str2 = localParseObject.getObjectId();
      if (str2 == null)
        continue;
      localArrayList.add(str2);
    }
    if (localArrayList.size() == 0)
      return Task.forResult(paramList);
    ParseQuery localParseQuery = ParseQuery.getQuery(str1);
    localParseQuery.whereContainedIn("objectId", localArrayList);
    return paramTask.continueWithTask(new Continuation(localParseQuery, paramParseUser)
    {
      public Task<List<T>> then(Task<Void> paramTask)
        throws Exception
      {
        return this.val$query.findWithCachePolicyAsync(ParseQuery.CachePolicy.IGNORE_CACHE, this.val$user);
      }
    }).onSuccess(new Continuation(paramList)
    {
      public List<T> then(Task<List<T>> paramTask)
        throws Exception
      {
        HashMap localHashMap = new HashMap();
        Iterator localIterator1 = ((List)paramTask.getResult()).iterator();
        while (localIterator1.hasNext())
        {
          ParseObject localParseObject3 = (ParseObject)localIterator1.next();
          localHashMap.put(localParseObject3.getObjectId(), localParseObject3);
        }
        Iterator localIterator2 = this.val$objects.iterator();
        while (localIterator2.hasNext())
        {
          ParseObject localParseObject1 = (ParseObject)localIterator2.next();
          if (localParseObject1.isDataAvailable())
            continue;
          ParseObject localParseObject2 = (ParseObject)localHashMap.get(localParseObject1.getObjectId());
          if (localParseObject2 == null)
            throw new RuntimeException("Object id " + localParseObject1.getObjectId() + " does not exist");
          localParseObject1.mergeFromObject(localParseObject2);
          localParseObject1.hasBeenFetched = true;
        }
        return this.val$objects;
      }
    });
  }

  public static <T extends ParseObject> Task<List<T>> fetchAllIfNeededInBackground(List<T> paramList)
  {
    return enqueueForAll(paramList, new Continuation(paramList, ParseUser.getCurrentUser())
    {
      public Task<List<T>> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseObject.access$1500(this.val$objects, this.val$user, paramTask);
      }
    });
  }

  public static <T extends ParseObject> void fetchAllIfNeededInBackground(List<T> paramList, FindCallback<T> paramFindCallback)
  {
    Parse.callbackOnMainThreadAsync(fetchAllIfNeededInBackground(paramList), paramFindCallback);
  }

  public static <T extends ParseObject> Task<List<T>> fetchAllInBackground(List<T> paramList)
  {
    return enqueueForAll(paramList, new Continuation(paramList, ParseUser.getCurrentUser())
    {
      public Task<List<T>> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseObject.access$1600(this.val$objects, this.val$user, paramTask);
      }
    });
  }

  public static <T extends ParseObject> void fetchAllInBackground(List<T> paramList, FindCallback<T> paramFindCallback)
  {
    Parse.callbackOnMainThreadAsync(fetchAllInBackground(paramList), paramFindCallback);
  }

  static <T extends ParseObject> T fromDiskJSON(JSONObject paramJSONObject)
  {
    String str = paramJSONObject.optString("classname", null);
    if (str == null)
      return null;
    ParseObject localParseObject = createWithoutData(str, paramJSONObject.optString("objectId", null));
    localParseObject.mergeFromDiskJSON(paramJSONObject);
    return localParseObject;
  }

  static <T extends ParseObject> T fromJSON(JSONObject paramJSONObject, String paramString, boolean paramBoolean)
  {
    return fromJSON(paramJSONObject, paramString, paramBoolean, new ParseDecoder());
  }

  static <T extends ParseObject> T fromJSON(JSONObject paramJSONObject, String paramString, boolean paramBoolean, ParseDecoder paramParseDecoder)
  {
    String str = paramJSONObject.optString("objectId", null);
    ParseObject localParseObject = createWithoutData(paramJSONObject.optString("classname", paramString), str);
    localParseObject.mergeAfterFetch(paramJSONObject, paramParseDecoder, paramBoolean);
    return localParseObject;
  }

  private ParseACL getACL(boolean paramBoolean)
  {
    Object localObject3;
    synchronized (this.mutex)
    {
      checkGetAccess("ACL");
      localObject3 = this.estimatedData.get("ACL");
      if (localObject3 == null)
        return null;
      if (!(localObject3 instanceof ParseACL))
        throw new RuntimeException("only ACLs can be stored in the ACL key");
    }
    if ((paramBoolean) && (((ParseACL)localObject3).isShared()))
    {
      ParseACL localParseACL2 = ((ParseACL)localObject3).copy();
      this.estimatedData.put("ACL", localParseACL2);
      addToHashedObjects(localParseACL2);
      monitorexit;
      return localParseACL2;
    }
    ParseACL localParseACL1 = (ParseACL)localObject3;
    monitorexit;
    return localParseACL1;
  }

  static String getApplicationId()
  {
    Parse.checkInit();
    return Parse.applicationId;
  }

  static String getClassName(Class<? extends ParseObject> paramClass)
  {
    String str = (String)classNames.get(paramClass);
    if (str == null)
    {
      ParseClassName localParseClassName = (ParseClassName)paramClass.getAnnotation(ParseClassName.class);
      if (localParseClassName == null)
        return null;
      str = localParseClassName.value();
      classNames.put(paramClass, str);
    }
    return str;
  }

  static ParseObject getFromDisk(Context paramContext, String paramString)
  {
    JSONObject localJSONObject = Parse.getDiskObject(paramContext, paramString);
    if (localJSONObject == null)
      return null;
    return fromDiskJSON(localJSONObject);
  }

  private Task<Void> handleDeleteResultAsync(Object paramObject)
  {
    int i = 1;
    Task localTask = Task.forResult(null);
    Object localObject1 = this.mutex;
    monitorenter;
    while (true)
    {
      if ((paramObject == null) || (i != 0));
      try
      {
        this.isDeleted = true;
        monitorexit;
        OfflineStore localOfflineStore = OfflineStore.getCurrent();
        if (localOfflineStore != null)
          localTask = localTask.continueWithTask(new Continuation(localOfflineStore)
          {
            public Task<Void> then(Task<Void> paramTask)
              throws Exception
            {
              synchronized (ParseObject.this.mutex)
              {
                if (ParseObject.this.isDeleted)
                {
                  Task localTask2 = this.val$store.deleteDataForObjectAsync(ParseObject.this);
                  return localTask2;
                }
                Task localTask1 = this.val$store.updateDataForObjectAsync(ParseObject.this);
                return localTask1;
              }
            }
          });
        return localTask;
        i = 0;
        continue;
      }
      finally
      {
        monitorexit;
      }
    }
    throw localObject2;
  }

  private boolean hasDirtyChildren()
  {
    while (true)
    {
      synchronized (this.mutex)
      {
        ArrayList localArrayList = new ArrayList();
        collectDirtyChildren(this.estimatedData, localArrayList, null);
        if (localArrayList.size() > 0)
        {
          i = 1;
          return i;
        }
      }
      int i = 0;
    }
  }

  private static Date impreciseParseDate(String paramString)
  {
    monitorenter;
    try
    {
      Date localDate2 = impreciseDateFormat.parse(paramString);
      localDate1 = localDate2;
      return localDate1;
    }
    catch (java.text.ParseException localParseException)
    {
      while (true)
      {
        Parse.logE("com.parse.ParseObject", "could not parse date: " + paramString, localParseException);
        Date localDate1 = null;
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  private static boolean isAccessible(Member paramMember)
  {
    return (Modifier.isPublic(paramMember.getModifiers())) || ((paramMember.getDeclaringClass().getPackage().getName().equals("com.parse")) && (!Modifier.isPrivate(paramMember.getModifiers())) && (!Modifier.isProtected(paramMember.getModifiers())));
  }

  private boolean isDataAvailable(String paramString)
  {
    while (true)
    {
      synchronized (this.mutex)
      {
        if (!isDataAvailable())
        {
          if ((!this.dataAvailability.containsKey(paramString)) || (!((Boolean)this.dataAvailability.get(paramString)).booleanValue()))
            break label65;
          break label59;
          return i;
        }
      }
      label59: int i = 1;
      continue;
      label65: i = 0;
    }
  }

  private void mergeAfterSave(JSONObject paramJSONObject, ParseDecoder paramParseDecoder, ParseOperationSet paramParseOperationSet)
  {
    synchronized (this.mutex)
    {
      ListIterator localListIterator = this.operationSetQueue.listIterator(this.operationSetQueue.indexOf(paramParseOperationSet));
      localListIterator.next();
      localListIterator.remove();
      ParseOperationSet localParseOperationSet = (ParseOperationSet)localListIterator.next();
      if (paramJSONObject == null)
      {
        localParseOperationSet.mergeFrom(paramParseOperationSet);
        return;
      }
      applyOperations(paramParseOperationSet, this.serverData);
      mergeFromServer(paramJSONObject, paramParseDecoder, false);
      rebuildEstimatedData();
      checkpointAllMutableContainers();
    }
  }

  static Task<ParseObject> migrateFromDiskToLDS(String paramString1, String paramString2)
  {
    ParseObject localParseObject = getFromDisk(Parse.applicationContext, paramString1);
    if (localParseObject == null)
      return Task.forResult(null);
    return localParseObject.pinInBackground(paramString2).continueWith(new Continuation(paramString1, localParseObject)
    {
      public ParseObject then(Task<Void> paramTask)
        throws Exception
      {
        if (!paramTask.isFaulted())
          ParseFileUtils.deleteQuietly(new File(Parse.getParseDir(), this.val$filename));
        return this.val$disk;
      }
    });
  }

  public static <T extends ParseObject> void pinAll(String paramString, List<T> paramList)
    throws ParseException
  {
    Parse.waitForTask(pinAllInBackground(paramString, paramList));
  }

  public static <T extends ParseObject> void pinAll(List<T> paramList)
    throws ParseException
  {
    Parse.waitForTask(pinAllInBackground("_default", paramList));
  }

  public static <T extends ParseObject> Task<Void> pinAllInBackground(String paramString, List<T> paramList)
  {
    return pinAllInBackground(paramString, paramList, true);
  }

  private static <T extends ParseObject> Task<Void> pinAllInBackground(String paramString, List<T> paramList, boolean paramBoolean)
  {
    if (!OfflineStore.isEnabled())
      throw new IllegalStateException("Method requires Local Datastore. Please refer to `Parse#enableLocalDatastore(Context)`.");
    Task localTask = Task.forResult(null);
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
      localTask = localTask.onSuccessTask(new Continuation((ParseObject)localIterator.next())
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          if (!this.val$object.isDataAvailable("ACL"))
            return Task.forResult(null);
          ParseACL localParseACL = this.val$object.getACL(false);
          if (localParseACL == null)
            return Task.forResult(null);
          if (!localParseACL.hasUnresolvedUser())
            return Task.forResult(null);
          return ParseUser.getCurrentUserAsync().onSuccessTask(new Continuation()
          {
            public Task<Void> then(Task<ParseUser> paramTask)
              throws Exception
            {
              return ParseUser.pinCurrentUserIfNeededAsync((ParseUser)paramTask.getResult());
            }
          });
        }
      });
    return localTask.onSuccessTask(new Continuation(paramString, paramList, paramBoolean)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        if (this.val$name != null);
        for (String str = this.val$name; ; str = "_default")
          return ParsePin.pinAllObjectsAsync(str, this.val$objects, this.val$includeAllChildren);
      }
    });
  }

  public static <T extends ParseObject> Task<Void> pinAllInBackground(List<T> paramList)
  {
    return pinAllInBackground("_default", paramList);
  }

  public static <T extends ParseObject> void pinAllInBackground(String paramString, List<T> paramList, SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(pinAllInBackground(paramString, paramList), paramSaveCallback);
  }

  public static <T extends ParseObject> void pinAllInBackground(List<T> paramList, SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(pinAllInBackground("_default", paramList), paramSaveCallback);
  }

  private void rebuildEstimatedData()
  {
    synchronized (this.mutex)
    {
      this.estimatedData.clear();
      this.estimatedData.putAll(this.serverData);
      Iterator localIterator = this.operationSetQueue.iterator();
      if (localIterator.hasNext())
        applyOperations((ParseOperationSet)localIterator.next(), this.estimatedData);
    }
    monitorexit;
  }

  static void registerParseSubclasses()
  {
    registerSubclass(ParseUser.class);
    registerSubclass(ParseRole.class);
    registerSubclass(ParseInstallation.class);
    registerSubclass(ParseSession.class);
    registerSubclass(ParsePin.class);
    registerSubclass(EventuallyPin.class);
  }

  public static void registerSubclass(Class<? extends ParseObject> paramClass)
  {
    String str = getClassName(paramClass);
    if (str == null)
      throw new IllegalArgumentException("No ParseClassName annoation provided on " + paramClass);
    if (paramClass.getDeclaredConstructors().length > 0)
      try
      {
        if (!isAccessible(paramClass.getDeclaredConstructor(new Class[0])))
          throw new IllegalArgumentException("Default constructor for " + paramClass + " is not accessible.");
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        throw new IllegalArgumentException("No default constructor provided for " + paramClass);
      }
    Class localClass = (Class)objectTypes.get(str);
    if ((localClass != null) && (paramClass.isAssignableFrom(localClass)));
    do
    {
      do
      {
        return;
        objectTypes.put(str, paramClass);
      }
      while ((localClass == null) || (paramClass.equals(localClass)));
      if (!str.equals(getClassName(ParseUser.class)))
        continue;
      ParseUser.clearCurrentUserFromMemory();
      return;
    }
    while (!str.equals(getClassName(ParseInstallation.class)));
    ParseInstallation.clearCurrentInstallationFromMemory();
  }

  public static <T extends ParseObject> void saveAll(List<T> paramList)
    throws ParseException
  {
    Parse.waitForTask(saveAllInBackground(paramList));
  }

  public static <T extends ParseObject> Task<Void> saveAllInBackground(List<T> paramList)
  {
    return deepSaveAsync(paramList, ParseUser.getCurrentSessionToken());
  }

  public static <T extends ParseObject> void saveAllInBackground(List<T> paramList, SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(saveAllInBackground(paramList), paramSaveCallback);
  }

  private void setObjectIdInternal(String paramString)
  {
    synchronized (this.mutex)
    {
      String str = this.objectId;
      OfflineStore localOfflineStore = OfflineStore.getCurrent();
      if (localOfflineStore != null)
        localOfflineStore.updateObjectId(this, str, paramString);
      this.objectId = paramString;
      if (this.localId != null)
      {
        LocalIdManager.getDefaultInstance().setObjectId(this.localId, this.objectId);
        this.localId = null;
      }
      return;
    }
  }

  public static void unpinAll()
    throws ParseException
  {
    Parse.waitForTask(unpinAllInBackground());
  }

  public static void unpinAll(String paramString)
    throws ParseException
  {
    Parse.waitForTask(unpinAllInBackground(paramString));
  }

  public static <T extends ParseObject> void unpinAll(String paramString, List<T> paramList)
    throws ParseException
  {
    Parse.waitForTask(unpinAllInBackground(paramString, paramList));
  }

  public static <T extends ParseObject> void unpinAll(List<T> paramList)
    throws ParseException
  {
    Parse.waitForTask(unpinAllInBackground("_default", paramList));
  }

  public static Task<Void> unpinAllInBackground()
  {
    return unpinAllInBackground("_default");
  }

  public static Task<Void> unpinAllInBackground(String paramString)
  {
    if (!OfflineStore.isEnabled())
      throw new IllegalStateException("Method requires Local Datastore. Please refer to `Parse#enableLocalDatastore(Context)`.");
    if (paramString == null)
      paramString = "_default";
    return ParsePin.unpinAllObjectsAsync(paramString);
  }

  public static <T extends ParseObject> Task<Void> unpinAllInBackground(String paramString, List<T> paramList)
  {
    if (!OfflineStore.isEnabled())
      throw new IllegalStateException("Method requires Local Datastore. Please refer to `Parse#enableLocalDatastore(Context)`.");
    if (paramString == null)
      paramString = "_default";
    return ParsePin.unpinAllObjectsAsync(paramString, paramList);
  }

  public static <T extends ParseObject> Task<Void> unpinAllInBackground(List<T> paramList)
  {
    return unpinAllInBackground("_default", paramList);
  }

  public static void unpinAllInBackground(DeleteCallback paramDeleteCallback)
  {
    Parse.callbackOnMainThreadAsync(unpinAllInBackground(), paramDeleteCallback);
  }

  public static void unpinAllInBackground(String paramString, DeleteCallback paramDeleteCallback)
  {
    Parse.callbackOnMainThreadAsync(unpinAllInBackground(paramString), paramDeleteCallback);
  }

  public static <T extends ParseObject> void unpinAllInBackground(String paramString, List<T> paramList, DeleteCallback paramDeleteCallback)
  {
    Parse.callbackOnMainThreadAsync(unpinAllInBackground(paramString, paramList), paramDeleteCallback);
  }

  public static <T extends ParseObject> void unpinAllInBackground(List<T> paramList, DeleteCallback paramDeleteCallback)
  {
    Parse.callbackOnMainThreadAsync(unpinAllInBackground("_default", paramList), paramDeleteCallback);
  }

  static void unregisterSubclass(String paramString)
  {
    objectTypes.remove(paramString);
  }

  public void add(String paramString, Object paramObject)
  {
    addAll(paramString, Arrays.asList(new Object[] { paramObject }));
  }

  public void addAll(String paramString, Collection<?> paramCollection)
  {
    performOperation(paramString, new ParseAddOperation(paramCollection));
  }

  public void addAllUnique(String paramString, Collection<?> paramCollection)
  {
    performOperation(paramString, new ParseAddUniqueOperation(paramCollection));
  }

  void addToHashedObjects(Object paramObject)
  {
    synchronized (this.mutex)
    {
      try
      {
        this.hashedObjects.put(paramObject, new ParseJSONCacheItem(paramObject));
        return;
      }
      catch (JSONException localJSONException)
      {
        throw new IllegalArgumentException("Couldn't serialize container value to JSON.");
      }
    }
  }

  public void addUnique(String paramString, Object paramObject)
  {
    addAllUnique(paramString, Arrays.asList(new Object[] { paramObject }));
  }

  void checkForChangesToMutableContainers()
  {
    synchronized (this.mutex)
    {
      Iterator localIterator = this.estimatedData.keySet().iterator();
      if (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        checkForChangesToMutableContainer(str, this.estimatedData.get(str));
      }
    }
    this.hashedObjects.keySet().retainAll(this.estimatedData.values());
    monitorexit;
  }

  public boolean containsKey(String paramString)
  {
    synchronized (this.mutex)
    {
      boolean bool = this.estimatedData.containsKey(paramString);
      return bool;
    }
  }

  void copyChangesFrom(ParseObject paramParseObject)
  {
    synchronized (this.mutex)
    {
      ParseOperationSet localParseOperationSet = (ParseOperationSet)paramParseObject.operationSetQueue.getFirst();
      Iterator localIterator = localParseOperationSet.keySet().iterator();
      if (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        performOperation(str, (ParseFieldOperation)localParseOperationSet.get(str));
      }
    }
    monitorexit;
  }

  ParseRESTObjectCommand currentSaveCommand(ParseOperationSet paramParseOperationSet, ParseObjectEncodingStrategy paramParseObjectEncodingStrategy, String paramString)
    throws ParseException
  {
    synchronized (this.mutex)
    {
      JSONObject localJSONObject = toJSONObjectForSaving(paramParseOperationSet, paramParseObjectEncodingStrategy);
      if (this.objectId == null)
      {
        localParseRESTObjectCommand = ParseRESTObjectCommand.createObjectCommand(this.className, localJSONObject, paramString);
        localParseRESTObjectCommand.enableRetrying();
        return localParseRESTObjectCommand;
      }
      ParseRESTObjectCommand localParseRESTObjectCommand = ParseRESTObjectCommand.updateObjectCommand(this.objectId, this.className, localJSONObject, paramString);
    }
  }

  public final void delete()
    throws ParseException
  {
    Parse.waitForTask(deleteInBackground());
  }

  Task<Object> deleteAsync(String paramString)
    throws ParseException
  {
    return currentDeleteCommand(paramString).executeAsync();
  }

  public final Task<Void> deleteEventually()
  {
    Task localTask2;
    synchronized (this.mutex)
    {
      validateDelete();
      this.isDeletingEventually = (1 + this.isDeletingEventually);
      String str1 = getObjectId();
      String str2 = null;
      if (str1 == null)
        str2 = getOrCreateLocalId();
      OfflineStore localOfflineStore = OfflineStore.getCurrent();
      Task localTask1;
      if (localOfflineStore != null)
      {
        localTask1 = localOfflineStore.updateDataForObjectAsync(this);
        ParseRESTObjectCommand localParseRESTObjectCommand = currentDeleteCommand(ParseUser.getCurrentSessionToken());
        localParseRESTObjectCommand.setLocalId(str2);
        localTask2 = localTask1.continueWithTask(new Continuation(localParseRESTObjectCommand)
        {
          public Task<Object> then(Task<Void> paramTask)
            throws Exception
          {
            return Parse.getEventuallyQueue().enqueueEventuallyAsync(this.val$command, ParseObject.this);
          }
        });
        if (OfflineStore.isEnabled())
          return localTask2.makeVoid();
      }
      else
      {
        localTask1 = Task.forResult(null);
      }
    }
    return localTask2.onSuccessTask(new Continuation()
    {
      public Task<Void> then(Task<Object> paramTask)
        throws Exception
      {
        return ParseObject.this.handleDeleteEventuallyResultAsync(paramTask.getResult());
      }
    });
  }

  public final void deleteEventually(DeleteCallback paramDeleteCallback)
  {
    Parse.callbackOnMainThreadAsync(deleteEventually(), paramDeleteCallback);
  }

  public final Task<Void> deleteInBackground()
  {
    return this.taskQueue.enqueue(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseObject.this.deleteAsync(paramTask);
      }
    });
  }

  public final void deleteInBackground(DeleteCallback paramDeleteCallback)
  {
    Parse.callbackOnMainThreadAsync(deleteInBackground(), paramDeleteCallback);
  }

  public <T extends ParseObject> T fetch()
    throws ParseException
  {
    return (ParseObject)Parse.waitForTask(fetchInBackground());
  }

  <T extends ParseObject> Task<T> fetchAsync(Task<Void> paramTask)
  {
    return Task.call(new Callable(ParseUser.getCurrentSessionToken())
    {
      public ParseRESTCommand call()
        throws Exception
      {
        synchronized (ParseObject.this.mutex)
        {
          ParseRESTObjectCommand localParseRESTObjectCommand = ParseRESTObjectCommand.getObjectCommand(ParseObject.this.objectId, ParseObject.this.className, this.val$sessionToken);
          localParseRESTObjectCommand.enableRetrying();
          return localParseRESTObjectCommand;
        }
      }
    }).onSuccessTask(TaskQueue.waitFor(paramTask)).onSuccessTask(new Continuation()
    {
      public Task<JSONObject> then(Task<ParseRESTCommand> paramTask)
        throws Exception
      {
        return ((ParseRESTCommand)paramTask.getResult()).executeAsync().cast();
      }
    }).onSuccessTask(new Continuation()
    {
      public Task<Void> then(Task<JSONObject> paramTask)
        throws Exception
      {
        JSONObject localJSONObject = (JSONObject)paramTask.getResult();
        return ParseObject.this.handleFetchResultAsync(localJSONObject);
      }
    }).onSuccess(new Continuation()
    {
      public T then(Task<Void> paramTask)
        throws Exception
      {
        return ParseObject.this;
      }
    });
  }

  public void fetchFromLocalDatastore()
    throws ParseException
  {
    Parse.waitForTask(fetchFromLocalDatastoreAsync());
  }

  <T extends ParseObject> Task<T> fetchFromLocalDatastoreAsync()
  {
    if (!OfflineStore.isEnabled())
      throw new IllegalStateException("Method requires Local Datastore. Please refer to `Parse#enableLocalDatastore(Context)`.");
    return OfflineStore.getCurrent().fetchLocallyAsync(this);
  }

  public <T extends ParseObject> void fetchFromLocalDatastoreInBackground(GetCallback<T> paramGetCallback)
  {
    Parse.callbackOnMainThreadAsync(fetchFromLocalDatastoreAsync(), paramGetCallback);
  }

  public <T extends ParseObject> T fetchIfNeeded()
    throws ParseException
  {
    return (ParseObject)Parse.waitForTask(fetchIfNeededInBackground());
  }

  public final <T extends ParseObject> Task<T> fetchIfNeededInBackground()
  {
    synchronized (this.mutex)
    {
      if (isDataAvailable())
      {
        Task localTask2 = Task.forResult(this);
        return localTask2;
      }
      Task localTask1 = fetchInBackground();
      return localTask1;
    }
  }

  public final <T extends ParseObject> void fetchIfNeededInBackground(GetCallback<T> paramGetCallback)
  {
    Parse.callbackOnMainThreadAsync(fetchIfNeededInBackground(), paramGetCallback);
  }

  public final <T extends ParseObject> Task<T> fetchInBackground()
  {
    return this.taskQueue.enqueue(new Continuation()
    {
      public Task<T> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseObject.this.fetchAsync(paramTask);
      }
    });
  }

  public final <T extends ParseObject> void fetchInBackground(GetCallback<T> paramGetCallback)
  {
    Parse.callbackOnMainThreadAsync(fetchInBackground(), paramGetCallback);
  }

  public Object get(String paramString)
  {
    synchronized (this.mutex)
    {
      checkGetAccess(paramString);
      Object localObject3 = this.estimatedData.get(paramString);
      if (((localObject3 instanceof ParseACL)) && (paramString.equals("ACL")))
      {
        ParseACL localParseACL1 = (ParseACL)localObject3;
        if (localParseACL1.isShared())
        {
          ParseACL localParseACL2 = localParseACL1.copy();
          this.estimatedData.put("ACL", localParseACL2);
          addToHashedObjects(localParseACL2);
          ParseACL localParseACL3 = getACL();
          return localParseACL3;
        }
      }
      if ((localObject3 instanceof ParseRelation))
        ((ParseRelation)localObject3).ensureParentAndKey(this, paramString);
      return localObject3;
    }
  }

  public ParseACL getACL()
  {
    return getACL(true);
  }

  public boolean getBoolean(String paramString)
  {
    synchronized (this.mutex)
    {
      checkGetAccess(paramString);
      Object localObject3 = this.estimatedData.get(paramString);
      if (!(localObject3 instanceof Boolean))
        return false;
      boolean bool = ((Boolean)localObject3).booleanValue();
      return bool;
    }
  }

  public byte[] getBytes(String paramString)
  {
    synchronized (this.mutex)
    {
      checkGetAccess(paramString);
      Object localObject3 = this.estimatedData.get(paramString);
      if (!(localObject3 instanceof byte[]))
        return null;
      byte[] arrayOfByte = (byte[])(byte[])localObject3;
      return arrayOfByte;
    }
  }

  public String getClassName()
  {
    synchronized (this.mutex)
    {
      String str = this.className;
      return str;
    }
  }

  public Date getCreatedAt()
  {
    synchronized (this.mutex)
    {
      Date localDate = this.createdAt;
      return localDate;
    }
  }

  public Date getDate(String paramString)
  {
    synchronized (this.mutex)
    {
      checkGetAccess(paramString);
      Object localObject3 = this.estimatedData.get(paramString);
      if (!(localObject3 instanceof Date))
        return null;
      Date localDate = (Date)localObject3;
      return localDate;
    }
  }

  public double getDouble(String paramString)
  {
    Number localNumber = getNumber(paramString);
    if (localNumber == null)
      return 0.0D;
    return localNumber.doubleValue();
  }

  public int getInt(String paramString)
  {
    Number localNumber = getNumber(paramString);
    if (localNumber == null)
      return 0;
    return localNumber.intValue();
  }

  public JSONArray getJSONArray(String paramString)
  {
    synchronized (this.mutex)
    {
      checkGetAccess(paramString);
      Object localObject3 = this.estimatedData.get(paramString);
      if ((localObject3 instanceof List))
      {
        localObject3 = Parse.encode(localObject3, PointerOrLocalIdEncodingStrategy.get());
        put(paramString, localObject3);
      }
      if (!(localObject3 instanceof JSONArray))
        return null;
      JSONArray localJSONArray = (JSONArray)localObject3;
      return localJSONArray;
    }
  }

  public JSONObject getJSONObject(String paramString)
  {
    synchronized (this.mutex)
    {
      checkGetAccess(paramString);
      Object localObject3 = this.estimatedData.get(paramString);
      if ((localObject3 instanceof Map))
      {
        localObject3 = Parse.encode(localObject3, PointerOrLocalIdEncodingStrategy.get());
        put(paramString, localObject3);
      }
      if (!(localObject3 instanceof JSONObject))
        return null;
      JSONObject localJSONObject = (JSONObject)localObject3;
      return localJSONObject;
    }
  }

  public <T> List<T> getList(String paramString)
  {
    synchronized (this.mutex)
    {
      Object localObject3 = this.estimatedData.get(paramString);
      if ((localObject3 instanceof JSONArray))
      {
        localObject3 = new ParseDecoder().convertJSONArrayToList((JSONArray)localObject3);
        put(paramString, localObject3);
      }
      if (!(localObject3 instanceof List))
        return null;
      List localList = (List)localObject3;
      return localList;
    }
  }

  public long getLong(String paramString)
  {
    Number localNumber = getNumber(paramString);
    if (localNumber == null)
      return 0L;
    return localNumber.longValue();
  }

  public <V> Map<String, V> getMap(String paramString)
  {
    synchronized (this.mutex)
    {
      Object localObject3 = this.estimatedData.get(paramString);
      if ((localObject3 instanceof JSONObject))
      {
        localObject3 = new ParseDecoder().convertJSONObjectToMap((JSONObject)localObject3);
        put(paramString, localObject3);
      }
      if (!(localObject3 instanceof Map))
        return null;
      Map localMap = (Map)localObject3;
      return localMap;
    }
  }

  public Number getNumber(String paramString)
  {
    synchronized (this.mutex)
    {
      checkGetAccess(paramString);
      Object localObject3 = this.estimatedData.get(paramString);
      if (!(localObject3 instanceof Number))
        return null;
      Number localNumber = (Number)localObject3;
      return localNumber;
    }
  }

  public String getObjectId()
  {
    synchronized (this.mutex)
    {
      String str = this.objectId;
      return str;
    }
  }

  String getOrCreateLocalId()
  {
    synchronized (this.mutex)
    {
      if (this.localId != null)
        break label47;
      if (this.objectId != null)
        throw new IllegalStateException("Attempted to get a localId for an object with an objectId.");
    }
    this.localId = LocalIdManager.getDefaultInstance().createLocalId();
    label47: String str = this.localId;
    monitorexit;
    return str;
  }

  public ParseFile getParseFile(String paramString)
  {
    Object localObject = get(paramString);
    if (!(localObject instanceof ParseFile))
      return null;
    return (ParseFile)localObject;
  }

  public ParseGeoPoint getParseGeoPoint(String paramString)
  {
    synchronized (this.mutex)
    {
      checkGetAccess(paramString);
      Object localObject3 = this.estimatedData.get(paramString);
      if (!(localObject3 instanceof ParseGeoPoint))
        return null;
      ParseGeoPoint localParseGeoPoint = (ParseGeoPoint)localObject3;
      return localParseGeoPoint;
    }
  }

  public ParseObject getParseObject(String paramString)
  {
    Object localObject = get(paramString);
    if (!(localObject instanceof ParseObject))
      return null;
    return (ParseObject)localObject;
  }

  public ParseUser getParseUser(String paramString)
  {
    Object localObject = get(paramString);
    if (!(localObject instanceof ParseUser))
      return null;
    return (ParseUser)localObject;
  }

  public <T extends ParseObject> ParseRelation<T> getRelation(String paramString)
  {
    synchronized (this.mutex)
    {
      Object localObject3 = this.estimatedData.get(paramString);
      if ((localObject3 instanceof ParseRelation))
      {
        ParseRelation localParseRelation2 = (ParseRelation)localObject3;
        localParseRelation2.ensureParentAndKey(this, paramString);
        return localParseRelation2;
      }
      ParseRelation localParseRelation1 = new ParseRelation(this, paramString);
      this.estimatedData.put(paramString, localParseRelation1);
      return localParseRelation1;
    }
  }

  public String getString(String paramString)
  {
    synchronized (this.mutex)
    {
      checkGetAccess(paramString);
      Object localObject3 = this.estimatedData.get(paramString);
      if (!(localObject3 instanceof String))
        return null;
      String str = (String)localObject3;
      return str;
    }
  }

  public Date getUpdatedAt()
  {
    synchronized (this.mutex)
    {
      Date localDate = this.updatedAt;
      return localDate;
    }
  }

  Task<Void> handleDeleteEventuallyResultAsync(Object paramObject)
  {
    synchronized (this.mutex)
    {
      this.isDeletingEventually = (-1 + this.isDeletingEventually);
      return handleDeleteResultAsync(paramObject).onSuccessTask(new Continuation(paramObject)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          if (this.val$result != null);
          for (int i = 1; ; i = 0)
          {
            if (i != 0)
              Parse.getEventuallyQueue().notifyTestHelper(6);
            return paramTask;
          }
        }
      });
    }
  }

  Task<Void> handleFetchResultAsync(JSONObject paramJSONObject)
  {
    Task localTask1 = Task.forResult((Void)null);
    Map localMap = collectFetchedObjects();
    OfflineStore localOfflineStore = OfflineStore.getCurrent();
    if (localOfflineStore != null)
      localTask1 = localTask1.onSuccessTask(new Continuation(localOfflineStore)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return this.val$store.fetchLocallyAsync(ParseObject.this).makeVoid();
        }
      }).continueWithTask(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          if (((paramTask.getError() instanceof ParseException)) && (((ParseException)paramTask.getError()).getCode() == 120))
            paramTask = null;
          return paramTask;
        }
      });
    Task localTask2 = localTask1.onSuccessTask(new Continuation(localMap, paramJSONObject)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        synchronized (ParseObject.this.mutex)
        {
          ParseObject.this.serverData.clear();
          ParseObject.this.dataAvailability.clear();
          KnownParseObjectDecoder localKnownParseObjectDecoder = new KnownParseObjectDecoder(this.val$fetchedObjects);
          ParseObject.this.mergeAfterFetch(this.val$result, localKnownParseObjectDecoder, true);
          return null;
        }
      }
    });
    if (localOfflineStore != null)
      localTask2 = localTask2.onSuccessTask(new Continuation(localOfflineStore)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return this.val$store.updateDataForObjectAsync(ParseObject.this);
        }
      }).continueWithTask(new Continuation()
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          if (((paramTask.getError() instanceof ParseException)) && (((ParseException)paramTask.getError()).getCode() == 120))
            paramTask = null;
          return paramTask;
        }
      });
    return localTask2;
  }

  Task<Void> handleSaveEventuallyResultAsync(JSONObject paramJSONObject, ParseOperationSet paramParseOperationSet)
  {
    return handleSaveResultAsync(paramJSONObject, paramParseOperationSet).onSuccessTask(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        Parse.getEventuallyQueue().notifyTestHelper(5);
        return paramTask;
      }
    });
  }

  Task<Void> handleSaveResultAsync(JSONObject paramJSONObject, ParseOperationSet paramParseOperationSet)
  {
    Task localTask1 = Task.forResult((Void)null);
    Map localMap = collectFetchedObjects();
    OfflineStore localOfflineStore = OfflineStore.getCurrent();
    if (localOfflineStore != null)
      localTask1 = localTask1.onSuccessTask(new Continuation(localOfflineStore)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return this.val$store.fetchLocallyAsync(ParseObject.this).makeVoid();
        }
      });
    Task localTask2 = localTask1.continueWith(new Continuation(localMap, paramJSONObject, paramParseOperationSet)
    {
      public Void then(Task<Void> paramTask)
        throws Exception
      {
        synchronized (ParseObject.this.mutex)
        {
          KnownParseObjectDecoder localKnownParseObjectDecoder = new KnownParseObjectDecoder(this.val$fetchedObjects);
          ParseObject.this.mergeAfterSave(this.val$result, localKnownParseObjectDecoder, this.val$operationsBeforeSave);
          return null;
        }
      }
    });
    if (localOfflineStore != null)
      localTask2 = localTask2.onSuccessTask(new Continuation(localOfflineStore)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return this.val$store.updateDataForObjectAsync(ParseObject.this);
        }
      });
    return localTask2.onSuccess(new Continuation()
    {
      public Void then(Task<Void> paramTask)
        throws Exception
      {
        ParseObject.this.saveEvent.invoke(ParseObject.this, null);
        return null;
      }
    });
  }

  public boolean has(String paramString)
  {
    return containsKey(paramString);
  }

  boolean hasChanges()
  {
    while (true)
    {
      synchronized (this.mutex)
      {
        if (currentOperations().size() > 0)
        {
          i = 1;
          return i;
        }
      }
      int i = 0;
    }
  }

  boolean hasOutstandingOperations()
  {
    for (int i = 1; ; i = 0)
      synchronized (this.mutex)
      {
        if (this.operationSetQueue.size() > i)
          return i;
      }
  }

  public boolean hasSameId(ParseObject paramParseObject)
  {
    while (true)
    {
      synchronized (this.mutex)
      {
        if ((getClassName() != null) && (getObjectId() != null) && (getClassName().equals(paramParseObject.getClassName())) && (getObjectId().equals(paramParseObject.getObjectId())))
        {
          i = 1;
          return i;
        }
      }
      int i = 0;
    }
  }

  public void increment(String paramString)
  {
    increment(paramString, Integer.valueOf(1));
  }

  public void increment(String paramString, Number paramNumber)
  {
    performOperation(paramString, new ParseIncrementOperation(paramNumber));
  }

  public boolean isDataAvailable()
  {
    synchronized (this.mutex)
    {
      boolean bool = this.hasBeenFetched;
      return bool;
    }
  }

  public boolean isDirty()
  {
    return isDirty(true);
  }

  public boolean isDirty(String paramString)
  {
    synchronized (this.mutex)
    {
      boolean bool = currentOperations().containsKey(paramString);
      return bool;
    }
  }

  boolean isDirty(boolean paramBoolean)
  {
    while (true)
    {
      synchronized (this.mutex)
      {
        checkForChangesToMutableContainers();
        if ((!this.isDeleted) && (getObjectId() != null) && (!hasChanges()))
        {
          if ((!paramBoolean) || (!hasDirtyChildren()))
            break label62;
          break label56;
          return i;
        }
      }
      label56: int i = 1;
      continue;
      label62: i = 0;
    }
  }

  boolean isKeyMutable(String paramString)
  {
    return true;
  }

  public Set<String> keySet()
  {
    synchronized (this.mutex)
    {
      Set localSet = Collections.unmodifiableSet(this.estimatedData.keySet());
      return localSet;
    }
  }

  void mergeAfterFetch(JSONObject paramJSONObject, ParseDecoder paramParseDecoder, boolean paramBoolean)
  {
    synchronized (this.mutex)
    {
      mergeFromServer(paramJSONObject, paramParseDecoder, paramBoolean);
      rebuildEstimatedData();
      checkpointAllMutableContainers();
      return;
    }
  }

  void mergeFromDiskJSON(JSONObject paramJSONObject)
  {
    synchronized (this.mutex)
    {
      try
      {
        if ((paramJSONObject.has("id")) && (this.objectId == null))
          setObjectIdInternal(paramJSONObject.getString("id"));
        if (paramJSONObject.has("created_at"))
        {
          String str3 = paramJSONObject.getString("created_at");
          if (str3 != null)
            this.createdAt = impreciseParseDate(str3);
        }
        if (paramJSONObject.has("updated_at"))
        {
          String str2 = paramJSONObject.getString("updated_at");
          if (str2 != null)
            this.updatedAt = impreciseParseDate(str2);
        }
        if (paramJSONObject.has("pointers"))
        {
          JSONObject localJSONObject = paramJSONObject.getJSONObject("pointers");
          Iterator localIterator = localJSONObject.keys();
          while (localIterator.hasNext())
          {
            String str1 = (String)localIterator.next();
            JSONArray localJSONArray = localJSONObject.getJSONArray(str1);
            this.serverData.put(str1, createWithoutData(localJSONArray.optString(0), localJSONArray.optString(1)));
          }
        }
      }
      catch (JSONException localJSONException)
      {
        throw new RuntimeException(localJSONException);
      }
    }
    mergeAfterFetch(paramJSONObject.optJSONObject("data"), new ParseDecoder(), true);
    monitorexit;
  }

  // ERROR //
  void mergeFromObject(ParseObject paramParseObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 141	com/parse/ParseObject:mutex	Ljava/lang/Object;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aload_0
    //   8: aload_1
    //   9: if_acmpne +6 -> 15
    //   12: aload_2
    //   13: monitorexit
    //   14: return
    //   15: aload_0
    //   16: aload_1
    //   17: getfield 235	com/parse/ParseObject:objectId	Ljava/lang/String;
    //   20: putfield 235	com/parse/ParseObject:objectId	Ljava/lang/String;
    //   23: aload_0
    //   24: aload_1
    //   25: getfield 1153	com/parse/ParseObject:createdAt	Ljava/util/Date;
    //   28: putfield 1153	com/parse/ParseObject:createdAt	Ljava/util/Date;
    //   31: aload_0
    //   32: aload_1
    //   33: getfield 1232	com/parse/ParseObject:updatedAt	Ljava/util/Date;
    //   36: putfield 1232	com/parse/ParseObject:updatedAt	Ljava/util/Date;
    //   39: aload_0
    //   40: getfield 196	com/parse/ParseObject:serverData	Ljava/util/Map;
    //   43: invokeinterface 921 1 0
    //   48: aload_0
    //   49: getfield 196	com/parse/ParseObject:serverData	Ljava/util/Map;
    //   52: aload_1
    //   53: getfield 196	com/parse/ParseObject:serverData	Ljava/util/Map;
    //   56: invokeinterface 925 2 0
    //   61: aload_0
    //   62: getfield 201	com/parse/ParseObject:operationSetQueue	Ljava/util/LinkedList;
    //   65: invokevirtual 1291	java/util/LinkedList:size	()I
    //   68: iconst_1
    //   69: if_icmpeq +19 -> 88
    //   72: new 403	java/lang/IllegalStateException
    //   75: dup
    //   76: ldc_w 1355
    //   79: invokespecial 406	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   82: athrow
    //   83: astore_3
    //   84: aload_2
    //   85: monitorexit
    //   86: aload_3
    //   87: athrow
    //   88: aload_0
    //   89: getfield 201	com/parse/ParseObject:operationSetQueue	Ljava/util/LinkedList;
    //   92: invokevirtual 1356	java/util/LinkedList:clear	()V
    //   95: aload_0
    //   96: getfield 201	com/parse/ParseObject:operationSetQueue	Ljava/util/LinkedList;
    //   99: new 203	com/parse/ParseOperationSet
    //   102: dup
    //   103: invokespecial 204	com/parse/ParseOperationSet:<init>	()V
    //   106: invokevirtual 207	java/util/LinkedList:add	(Ljava/lang/Object;)Z
    //   109: pop
    //   110: aload_0
    //   111: invokespecial 875	com/parse/ParseObject:rebuildEstimatedData	()V
    //   114: aload_0
    //   115: invokespecial 877	com/parse/ParseObject:checkpointAllMutableContainers	()V
    //   118: aload_2
    //   119: monitorexit
    //   120: return
    //
    // Exception table:
    //   from	to	target	type
    //   12	14	83	finally
    //   15	83	83	finally
    //   84	86	83	finally
    //   88	120	83	finally
  }

  void mergeFromServer(JSONObject paramJSONObject, ParseDecoder paramParseDecoder, boolean paramBoolean)
  {
    boolean bool = true;
    while (true)
    {
      String str;
      synchronized (this.mutex)
      {
        if ((this.hasBeenFetched) || (paramBoolean))
        {
          this.hasBeenFetched = bool;
          try
          {
            Iterator localIterator = paramJSONObject.keys();
            if (!localIterator.hasNext())
              break;
            str = (String)localIterator.next();
            this.dataAvailability.put(str, Boolean.valueOf(true));
            if (!str.equals("objectId"))
              break label122;
            setObjectIdInternal(paramJSONObject.getString(str));
            continue;
          }
          catch (JSONException localJSONException)
          {
            throw new RuntimeException(localJSONException);
          }
        }
      }
      bool = false;
      continue;
      label122: if (str.equals("createdAt"))
      {
        this.createdAt = Parse.stringToDate(paramJSONObject.getString(str));
        continue;
      }
      if (str.equals("updatedAt"))
      {
        this.updatedAt = Parse.stringToDate(paramJSONObject.getString(str));
        continue;
      }
      if (str.equals("ACL"))
      {
        ParseACL localParseACL = ParseACL.createACLFromJSONObject(paramJSONObject.getJSONObject(str), paramParseDecoder);
        this.serverData.put("ACL", localParseACL);
        addToHashedObjects(localParseACL);
        continue;
      }
      if ((str.equals("__type")) || (str.equals("className")))
        continue;
      Object localObject3 = paramParseDecoder.decode(paramJSONObject.get(str));
      if (Parse.isContainerObject(localObject3))
        addToHashedObjects(localObject3);
      this.serverData.put(str, localObject3);
    }
    if ((this.updatedAt == null) && (this.createdAt != null))
      this.updatedAt = this.createdAt;
    rebuildEstimatedData();
    checkpointAllMutableContainers();
    monitorexit;
  }

  void mergeREST(JSONObject paramJSONObject, ParseDecoder paramParseDecoder)
  {
    ArrayList localArrayList = new ArrayList();
    String str;
    while (true)
    {
      synchronized (this.mutex)
      {
        try
        {
          Iterator localIterator1 = paramJSONObject.keys();
          if (!localIterator1.hasNext())
            break label479;
          str = (String)localIterator1.next();
          this.dataAvailability.put(str, Boolean.valueOf(true));
          if ((str.equals("__type")) || (str.equals("className")))
            continue;
          if (str.equals("objectId"))
          {
            setObjectIdInternal(paramJSONObject.getString(str));
            continue;
          }
        }
        catch (JSONException localJSONException)
        {
          throw new RuntimeException(localJSONException);
        }
      }
      if (str.equals("createdAt"))
      {
        this.createdAt = Parse.stringToDate(paramJSONObject.getString(str));
        continue;
      }
      if (str.equals("updatedAt"))
      {
        this.updatedAt = Parse.stringToDate(paramJSONObject.getString(str));
        continue;
      }
      if (str.equals("isDeletingEventually"))
      {
        this.isDeletingEventually = paramJSONObject.getInt(str);
        continue;
      }
      if (str.equals("ACL"))
      {
        ParseACL localParseACL = ParseACL.createACLFromJSONObject(paramJSONObject.getJSONObject(str), paramParseDecoder);
        this.serverData.put("ACL", localParseACL);
        addToHashedObjects(localParseACL);
        continue;
      }
      if (!str.equals("__complete"))
        break;
      if (this.hasBeenFetched)
        break label547;
      if (!paramJSONObject.getBoolean(str))
        break label553;
      break label547;
    }
    Object localObject4;
    int i;
    ParseOperationSet localParseOperationSet2;
    while (true)
    {
      this.hasBeenFetched = bool;
      break;
      if (str.equals("__operations"))
      {
        ParseOperationSet localParseOperationSet1 = currentOperations();
        JSONArray localJSONArray = paramJSONObject.getJSONArray("__operations");
        if (localJSONArray != null)
        {
          this.operationSetQueue.clear();
          localObject4 = null;
          i = 0;
          if (i < localJSONArray.length())
          {
            localParseOperationSet2 = ParseOperationSet.fromRest(localJSONArray.getJSONObject(i), paramParseDecoder);
            if (localParseOperationSet2.isSaveEventually())
            {
              if (localObject4 != null)
              {
                this.operationSetQueue.add(localObject4);
                localObject4 = null;
              }
              localArrayList.add(localParseOperationSet2);
              this.operationSetQueue.add(localParseOperationSet2);
              break label559;
            }
            if (localObject4 == null)
              break label565;
            localParseOperationSet2.mergeFrom(localObject4);
            break label565;
          }
          if (localObject4 != null)
            this.operationSetQueue.add(localObject4);
        }
        currentOperations().mergeFrom(localParseOperationSet1);
        break;
      }
      Object localObject3 = paramParseDecoder.decode(paramJSONObject.get(str));
      if (Parse.isContainerObject(localObject3))
        addToHashedObjects(localObject3);
      this.serverData.put(str, localObject3);
      break;
      label479: if ((this.updatedAt == null) && (this.createdAt != null))
        this.updatedAt = this.createdAt;
      rebuildEstimatedData();
      checkpointAllMutableContainers();
      monitorexit;
      Iterator localIterator2 = localArrayList.iterator();
      while (localIterator2.hasNext())
        enqueueSaveEventuallyOperationAsync((ParseOperationSet)localIterator2.next());
      return;
      label547: boolean bool = true;
      continue;
      label553: bool = false;
    }
    while (true)
    {
      label559: i++;
      break;
      label565: localObject4 = localParseOperationSet2;
    }
  }

  boolean needsDefaultACL()
  {
    return true;
  }

  void performOperation(String paramString, ParseFieldOperation paramParseFieldOperation)
  {
    synchronized (this.mutex)
    {
      Object localObject3 = paramParseFieldOperation.apply(this.estimatedData.get(paramString), this, paramString);
      if (localObject3 != null)
      {
        this.estimatedData.put(paramString, localObject3);
        ParseFieldOperation localParseFieldOperation = paramParseFieldOperation.mergeWithPrevious((ParseFieldOperation)currentOperations().get(paramString));
        currentOperations().put(paramString, localParseFieldOperation);
        checkpointMutableContainer(localObject3);
        this.dataAvailability.put(paramString, Boolean.TRUE);
        return;
      }
      this.estimatedData.remove(paramString);
    }
  }

  void performPut(String paramString, Object paramObject)
  {
    if (paramString == null)
      throw new IllegalArgumentException("key may not be null.");
    if (paramObject == null)
      throw new IllegalArgumentException("value may not be null.");
    if (!Parse.isValidType(paramObject))
      throw new IllegalArgumentException("invalid type for value: " + paramObject.getClass().toString());
    performOperation(paramString, new ParseSetOperation(paramObject));
  }

  void performRemove(String paramString)
  {
    synchronized (this.mutex)
    {
      if (get(paramString) != null)
        performOperation(paramString, ParseDeleteOperation.getInstance());
      return;
    }
  }

  public void pin()
    throws ParseException
  {
    Parse.waitForTask(pinInBackground());
  }

  public void pin(String paramString)
    throws ParseException
  {
    Parse.waitForTask(pinInBackground(paramString));
  }

  public Task<Void> pinInBackground()
  {
    return pinAllInBackground("_default", Arrays.asList(new ParseObject[] { this }));
  }

  public Task<Void> pinInBackground(String paramString)
  {
    return pinAllInBackground(paramString, Arrays.asList(new ParseObject[] { this }));
  }

  Task<Void> pinInBackground(String paramString, boolean paramBoolean)
  {
    return pinAllInBackground(paramString, Arrays.asList(new ParseObject[] { this }), paramBoolean);
  }

  public void pinInBackground(SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(pinInBackground(), paramSaveCallback);
  }

  public void pinInBackground(String paramString, SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(pinInBackground(paramString), paramSaveCallback);
  }

  public void put(String paramString, Object paramObject)
  {
    checkKeyIsMutable(paramString);
    performPut(paramString, paramObject);
  }

  @Deprecated
  public final void refresh()
    throws ParseException
  {
    fetch();
  }

  @Deprecated
  public final void refreshInBackground(RefreshCallback paramRefreshCallback)
  {
    Parse.callbackOnMainThreadAsync(fetchInBackground(), paramRefreshCallback);
  }

  void registerSaveListener(GetCallback<ParseObject> paramGetCallback)
  {
    synchronized (this.mutex)
    {
      this.saveEvent.subscribe(paramGetCallback);
      return;
    }
  }

  public void remove(String paramString)
  {
    checkKeyIsMutable(paramString);
    performRemove(paramString);
  }

  public void removeAll(String paramString, Collection<?> paramCollection)
  {
    checkKeyIsMutable(paramString);
    performOperation(paramString, new ParseRemoveOperation(paramCollection));
  }

  void revert()
  {
    synchronized (this.mutex)
    {
      currentOperations().clear();
      rebuildEstimatedData();
      checkpointAllMutableContainers();
      return;
    }
  }

  public final void save()
    throws ParseException
  {
    Parse.waitForTask(saveInBackground());
  }

  Task<Void> saveAsync(Task<Void> paramTask)
  {
    if (!isDirty())
      return Task.forResult(null);
    Capture localCapture = new Capture();
    String str = ParseUser.getCurrentSessionToken();
    return Task.forResult(null).onSuccessTask(new Continuation(localCapture)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        synchronized (ParseObject.this.mutex)
        {
          ParseObject.this.validateSave();
          this.val$operations.set(ParseObject.this.startSave());
          if ((ParseObject.this.isDataAvailable("ACL")) && (ParseObject.this.getACL(false) != null) && (ParseObject.this.getACL(false).hasUnresolvedUser()))
          {
            Task localTask = ParseUser.getCurrentUser().saveInBackground().onSuccess(new Continuation()
            {
              public Void then(Task<Void> paramTask)
                throws Exception
              {
                if (ParseObject.this.getACL(false).hasUnresolvedUser())
                  throw new IllegalStateException("ACL has an unresolved ParseUser. Save or sign up before attempting to serialize the ACL.");
                return null;
              }
            });
            return localTask;
          }
          return paramTask;
        }
      }
    }).onSuccessTask(new Continuation(str)
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        synchronized (ParseObject.this.mutex)
        {
          Task localTask = ParseObject.access$400(ParseObject.this.estimatedData, this.val$sessionToken);
          return localTask;
        }
      }
    }).onSuccessTask(TaskQueue.waitFor(paramTask)).onSuccessTask(new Continuation(localCapture, str)
    {
      public Task<Object> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseObject.this.saveAsync((ParseOperationSet)this.val$operations.get(), this.val$sessionToken);
      }
    }).continueWithTask(new Continuation(localCapture)
    {
      public Task<Void> then(Task<Object> paramTask)
        throws Exception
      {
        JSONObject localJSONObject = (JSONObject)paramTask.getResult();
        return ParseObject.this.handleSaveResultAsync(localJSONObject, (ParseOperationSet)this.val$operations.get()).continueWithTask(new Continuation(paramTask)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return this.val$saveTask.makeVoid();
          }
        });
      }
    });
  }

  Task<Object> saveAsync(ParseOperationSet paramParseOperationSet, String paramString)
    throws ParseException
  {
    return currentSaveCommand(paramParseOperationSet, PointerEncodingStrategy.get(), paramString).executeAsync();
  }

  public final Task<Void> saveEventually()
  {
    if (!isDirty())
    {
      Parse.getEventuallyQueue().fakeObjectUpdate();
      return Task.forResult(null);
    }
    ParseOperationSet localParseOperationSet;
    ParseRESTObjectCommand localParseRESTObjectCommand;
    synchronized (this.mutex)
    {
      updateBeforeSave();
      ArrayList localArrayList = new ArrayList();
      collectDirtyChildren(this.estimatedData, localArrayList, null);
      String str1 = getObjectId();
      String str2 = null;
      if (str1 == null)
        str2 = getOrCreateLocalId();
      localParseOperationSet = startSave();
      localParseOperationSet.setIsSaveEventually(true);
      String str3 = ParseUser.getCurrentSessionToken();
      try
      {
        localParseRESTObjectCommand = currentSaveCommand(localParseOperationSet, PointerOrLocalIdEncodingStrategy.get(), str3);
        localParseRESTObjectCommand.setLocalId(str2);
        localParseRESTObjectCommand.setOperationSetUUID(localParseOperationSet.getUUID());
        localParseRESTObjectCommand.retainLocalIds();
        Iterator localIterator = localArrayList.iterator();
        while (localIterator.hasNext())
          ((ParseObject)localIterator.next()).saveEventually();
      }
      catch (ParseException localParseException)
      {
        throw new IllegalStateException("Unable to saveEventually.", localParseException);
      }
    }
    monitorexit;
    Task localTask = Parse.getEventuallyQueue().enqueueEventuallyAsync(localParseRESTObjectCommand, this);
    enqueueSaveEventuallyOperationAsync(localParseOperationSet);
    localParseRESTObjectCommand.releaseLocalIds();
    if (OfflineStore.isEnabled())
      return localTask.makeVoid();
    return localTask.onSuccessTask(new Continuation(localParseOperationSet)
    {
      public Task<Void> then(Task<Object> paramTask)
        throws Exception
      {
        JSONObject localJSONObject = (JSONObject)paramTask.getResult();
        return ParseObject.this.handleSaveEventuallyResultAsync(localJSONObject, this.val$operationSet);
      }
    });
  }

  public final void saveEventually(SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(saveEventually(), paramSaveCallback);
  }

  public final Task<Void> saveInBackground()
  {
    return this.taskQueue.enqueue(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        ParseObject.this.updateBeforeSave();
        return ParseObject.this.saveAsync(paramTask);
      }
    });
  }

  public final void saveInBackground(SaveCallback paramSaveCallback)
  {
    Parse.callbackOnMainThreadAsync(saveInBackground(), paramSaveCallback);
  }

  void saveToDisk(Context paramContext, String paramString)
  {
    if (OfflineStore.isEnabled())
      throw new IllegalStateException("ParseObject#saveToDisk is not allowed when OfflineStore is enabled");
    synchronized (this.mutex)
    {
      Parse.saveDiskObject(paramContext, paramString, toJSONObjectForDataFile(false, PointerEncodingStrategy.get()));
      return;
    }
  }

  public void setACL(ParseACL paramParseACL)
  {
    put("ACL", paramParseACL);
  }

  void setDefaultValues()
  {
    if ((needsDefaultACL()) && (ParseACL.getDefaultACL() != null))
      setACL(ParseACL.getDefaultACL());
  }

  public void setObjectId(String paramString)
  {
    synchronized (this.mutex)
    {
      setObjectIdInternal(paramString);
      return;
    }
  }

  ParseOperationSet startSave()
  {
    synchronized (this.mutex)
    {
      ParseOperationSet localParseOperationSet = currentOperations();
      this.operationSetQueue.addLast(new ParseOperationSet());
      return localParseOperationSet;
    }
  }

  JSONObject toJSONObjectForDataFile(boolean paramBoolean, ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
  {
    JSONObject localJSONObject1;
    JSONObject localJSONObject2;
    while (true)
    {
      String str2;
      Object localObject3;
      synchronized (this.mutex)
      {
        checkForChangesToMutableContainers();
        localJSONObject1 = new JSONObject();
        localJSONObject2 = new JSONObject();
        try
        {
          Iterator localIterator1 = this.serverData.keySet().iterator();
          if (!localIterator1.hasNext())
            break;
          str2 = (String)localIterator1.next();
          localObject3 = this.serverData.get(str2);
          if ((Parse.isContainerObject(localObject3)) && (this.hashedObjects.containsKey(localObject3)))
          {
            localJSONObject2.put(str2, ((ParseJSONCacheItem)this.hashedObjects.get(localObject3)).getJSONObject());
            continue;
          }
        }
        catch (JSONException localJSONException)
        {
          throw new RuntimeException("could not serialize object to JSON");
        }
      }
      localJSONObject2.put(str2, Parse.encode(localObject3, paramParseObjectEncodingStrategy));
    }
    if (this.createdAt != null)
      localJSONObject2.put("createdAt", Parse.dateToString(this.createdAt));
    if (this.updatedAt != null)
      localJSONObject2.put("updatedAt", Parse.dateToString(this.updatedAt));
    if (this.objectId != null)
      localJSONObject2.put("objectId", this.objectId);
    localJSONObject1.put("data", localJSONObject2);
    localJSONObject1.put("classname", this.className);
    if (paramBoolean)
    {
      JSONArray localJSONArray = new JSONArray();
      Iterator localIterator2 = this.operationSetQueue.iterator();
      while (localIterator2.hasNext())
      {
        ParseOperationSet localParseOperationSet = (ParseOperationSet)localIterator2.next();
        JSONObject localJSONObject3 = new JSONObject();
        Iterator localIterator3 = localParseOperationSet.keySet().iterator();
        while (localIterator3.hasNext())
        {
          String str1 = (String)localIterator3.next();
          localJSONObject3.put(str1, ((ParseFieldOperation)localParseOperationSet.get(str1)).encode(paramParseObjectEncodingStrategy));
        }
        localJSONArray.put(localJSONObject3);
      }
      localJSONObject1.put("operations", localJSONArray);
    }
    monitorexit;
    return localJSONObject1;
  }

  JSONObject toJSONObjectForSaving(ParseOperationSet paramParseOperationSet, ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
  {
    JSONObject localJSONObject;
    synchronized (this.mutex)
    {
      localJSONObject = new JSONObject();
      try
      {
        Iterator localIterator = paramParseOperationSet.keySet().iterator();
        while (localIterator.hasNext())
        {
          String str = (String)localIterator.next();
          ParseFieldOperation localParseFieldOperation = (ParseFieldOperation)paramParseOperationSet.get(str);
          localJSONObject.put(str, Parse.encode(localParseFieldOperation, paramParseObjectEncodingStrategy));
          if (!(localParseFieldOperation instanceof ParseSetOperation))
            continue;
          Object localObject3 = ((ParseSetOperation)localParseFieldOperation).getValue();
          if ((!Parse.isContainerObject(localObject3)) || (!this.hashedObjects.containsKey(localObject3)))
            continue;
          this.hashedObjects.put(localObject3, new ParseJSONCacheItem(localObject3));
        }
      }
      catch (JSONException localJSONException)
      {
        throw new RuntimeException("could not serialize object to JSON");
      }
    }
    if (this.objectId != null)
      localJSONObject.put("objectId", this.objectId);
    monitorexit;
    return localJSONObject;
  }

  JSONObject toRest(ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
  {
    JSONObject localJSONObject;
    synchronized (this.mutex)
    {
      checkForChangesToMutableContainers();
      localJSONObject = new JSONObject();
      try
      {
        localJSONObject.put("className", this.className);
        Iterator localIterator1 = this.serverData.keySet().iterator();
        while (localIterator1.hasNext())
        {
          String str = (String)localIterator1.next();
          localJSONObject.put(str, Parse.encode(this.serverData.get(str), paramParseObjectEncodingStrategy));
        }
      }
      catch (JSONException localJSONException)
      {
        throw new RuntimeException("could not serialize object to JSON");
      }
    }
    if (this.objectId != null)
      localJSONObject.put("objectId", this.objectId);
    if (this.createdAt != null)
      localJSONObject.put("createdAt", Parse.dateToString(this.createdAt));
    if (this.updatedAt != null)
      localJSONObject.put("updatedAt", Parse.dateToString(this.updatedAt));
    localJSONObject.put("isDeletingEventually", this.isDeletingEventually);
    JSONArray localJSONArray = new JSONArray();
    Iterator localIterator2 = this.operationSetQueue.iterator();
    while (localIterator2.hasNext())
      localJSONArray.put(((ParseOperationSet)localIterator2.next()).toRest(paramParseObjectEncodingStrategy));
    localJSONObject.put("__operations", localJSONArray);
    localJSONObject.put("__complete", this.hasBeenFetched);
    monitorexit;
    return localJSONObject;
  }

  public void unpin()
    throws ParseException
  {
    Parse.waitForTask(unpinInBackground());
  }

  public void unpin(String paramString)
    throws ParseException
  {
    Parse.waitForTask(unpinInBackground(paramString));
  }

  public Task<Void> unpinInBackground()
  {
    return unpinAllInBackground("_default", Arrays.asList(new ParseObject[] { this }));
  }

  public Task<Void> unpinInBackground(String paramString)
  {
    return unpinAllInBackground(paramString, Arrays.asList(new ParseObject[] { this }));
  }

  public void unpinInBackground(DeleteCallback paramDeleteCallback)
  {
    Parse.callbackOnMainThreadAsync(unpinInBackground(), paramDeleteCallback);
  }

  public void unpinInBackground(String paramString, DeleteCallback paramDeleteCallback)
  {
    Parse.callbackOnMainThreadAsync(unpinInBackground(paramString), paramDeleteCallback);
  }

  void unregisterSaveListener(GetCallback<ParseObject> paramGetCallback)
  {
    synchronized (this.mutex)
    {
      this.saveEvent.unsubscribe(paramGetCallback);
      return;
    }
  }

  void updateBeforeSave()
  {
  }

  void validateDelete()
  {
  }

  void validateSave()
  {
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseObject
 * JD-Core Version:    0.6.0
 */