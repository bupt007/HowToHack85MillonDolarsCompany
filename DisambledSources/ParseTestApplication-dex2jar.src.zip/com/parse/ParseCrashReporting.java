package com.parse;

import android.content.Context;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public final class ParseCrashReporting
{
  static final String CRASH_REPORT = "_CrashReport";

  public static void enable(Context paramContext)
  {
    ParseCrashReporter.enableCrashReporting(paramContext.getApplicationContext());
  }

  public static boolean isCrashReportingEnabled()
  {
    return ParseCrashReporter.isEnabled();
  }

  static void trackCrashReport(JSONObject paramJSONObject)
  {
    HashMap localHashMap = new HashMap();
    localHashMap.put("acraDump", paramJSONObject);
    ParseRESTAnalyticsCommand localParseRESTAnalyticsCommand = ParseRESTAnalyticsCommand.trackEventCommand("_CrashReport", localHashMap, ParseUser.getCurrentSessionToken());
    Parse.getEventuallyQueue().enqueueEventuallyAsync(localParseRESTAnalyticsCommand, null);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseCrashReporting
 * JD-Core Version:    0.6.0
 */