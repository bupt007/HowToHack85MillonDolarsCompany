package com.parse;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.util.Log;
import bolts.AggregateException;
import bolts.Continuation;
import bolts.Task;
import bolts.Task.TaskCompletionSource;
import com.parse.codec.binary.Base64;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SimpleTimeZone;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Parse
{
  public static final int LOG_LEVEL_DEBUG = 3;
  public static final int LOG_LEVEL_ERROR = 6;
  public static final int LOG_LEVEL_INFO = 4;
  public static final int LOG_LEVEL_NONE = 2147483647;
  public static final int LOG_LEVEL_VERBOSE = 2;
  public static final int LOG_LEVEL_WARNING = 5;
  private static final Object MUTEX;
  private static final Object MUTEX_CALLBACKS;
  private static final String PARSE_APPLICATION_ID = "com.parse.APPLICATION_ID";
  private static final String PARSE_CLIENT_KEY = "com.parse.CLIENT_KEY";
  private static final Object SCHEDULED_EXECUTOR_LOCK;
  private static final String TAG = "com.parse.Parse";
  static Context applicationContext;
  static String applicationId;
  private static Set<ParseCallbacks> callbacks;
  static String clientKey;
  private static final DateFormat dateFormat;
  static ParseEventuallyQueue eventuallyQueue;
  private static int logLevel = 6;
  static int maxParseFileSize = 10485760;
  private static ScheduledExecutorService scheduledExecutor;

  static
  {
    MUTEX = new Object();
    eventuallyQueue = null;
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
    localSimpleDateFormat.setTimeZone(new SimpleTimeZone(0, "GMT"));
    dateFormat = localSimpleDateFormat;
    SCHEDULED_EXECUTOR_LOCK = new Object();
    MUTEX_CALLBACKS = new Object();
    callbacks = new HashSet();
  }

  private Parse()
  {
    throw new AssertionError();
  }

  static Number addNumbers(Number paramNumber1, Number paramNumber2)
  {
    if (((paramNumber1 instanceof Double)) || ((paramNumber2 instanceof Double)))
      return Double.valueOf(paramNumber1.doubleValue() + paramNumber2.doubleValue());
    if (((paramNumber1 instanceof Float)) || ((paramNumber2 instanceof Float)))
      return Float.valueOf(paramNumber1.floatValue() + paramNumber2.floatValue());
    if (((paramNumber1 instanceof Long)) || ((paramNumber2 instanceof Long)))
      return Long.valueOf(paramNumber1.longValue() + paramNumber2.longValue());
    if (((paramNumber1 instanceof Integer)) || ((paramNumber2 instanceof Integer)))
      return Integer.valueOf(paramNumber1.intValue() + paramNumber2.intValue());
    if (((paramNumber1 instanceof Short)) || ((paramNumber2 instanceof Short)))
      return Integer.valueOf(paramNumber1.shortValue() + paramNumber2.shortValue());
    if (((paramNumber1 instanceof Byte)) || ((paramNumber2 instanceof Byte)))
      return Integer.valueOf(paramNumber1.byteValue() + paramNumber2.byteValue());
    throw new RuntimeException("Unknown number type.");
  }

  private static boolean allParsePushIntentReceiversInternal()
  {
    Iterator localIterator = ManifestInfo.getIntentReceivers(new String[] { "com.parse.push.intent.RECEIVE", "com.parse.push.intent.DELETE", "com.parse.push.intent.OPEN" }).iterator();
    while (localIterator.hasNext())
      if (((ResolveInfo)localIterator.next()).activityInfo.exported)
        return false;
    return true;
  }

  static Task<Void> callbackOnMainThreadAsync(Task<Void> paramTask, ParseCallback1<ParseException> paramParseCallback1)
  {
    return callbackOnMainThreadAsync(paramTask, paramParseCallback1, false);
  }

  static Task<Void> callbackOnMainThreadAsync(Task<Void> paramTask, ParseCallback1<ParseException> paramParseCallback1, boolean paramBoolean)
  {
    if (paramParseCallback1 == null)
      return paramTask;
    return callbackOnMainThreadAsync(paramTask, new ParseCallback2(paramParseCallback1)
    {
      public void done(Void paramVoid, ParseException paramParseException)
      {
        this.val$callback.done(paramParseException);
      }
    }
    , paramBoolean);
  }

  static <T> Task<T> callbackOnMainThreadAsync(Task<T> paramTask, ParseCallback2<T, ParseException> paramParseCallback2)
  {
    return callbackOnMainThreadAsync(paramTask, paramParseCallback2, false);
  }

  static <T> Task<T> callbackOnMainThreadAsync(Task<T> paramTask, ParseCallback2<T, ParseException> paramParseCallback2, boolean paramBoolean)
  {
    if (paramParseCallback2 == null)
      return paramTask;
    Task.TaskCompletionSource localTaskCompletionSource = Task.create();
    paramTask.continueWith(new Continuation(paramBoolean, localTaskCompletionSource, paramParseCallback2)
    {
      public Void then(Task<T> paramTask)
        throws Exception
      {
        if ((paramTask.isCancelled()) && (!this.val$reportCancellation))
        {
          this.val$tcs.setCancelled();
          return null;
        }
        Task.UI_THREAD_EXECUTOR.execute(new Runnable(paramTask)
        {
          public void run()
          {
            try
            {
              Object localObject2 = this.val$task.getError();
              if ((localObject2 != null) && (!(localObject2 instanceof ParseException)))
                localObject2 = new ParseException((Throwable)localObject2);
              Parse.6.this.val$callback.done(this.val$task.getResult(), (ParseException)localObject2);
              if (this.val$task.isCancelled())
              {
                Parse.6.this.val$tcs.setCancelled();
                return;
              }
              if (this.val$task.isFaulted())
              {
                Parse.6.this.val$tcs.setError(this.val$task.getError());
                return;
              }
              Parse.6.this.val$tcs.setResult(this.val$task.getResult());
              return;
            }
            finally
            {
              if (!this.val$task.isCancelled())
                break label141;
            }
            Parse.6.this.val$tcs.setCancelled();
            while (true)
            {
              throw localObject1;
              label141: if (this.val$task.isFaulted())
              {
                Parse.6.this.val$tcs.setError(this.val$task.getError());
                continue;
              }
              Parse.6.this.val$tcs.setResult(this.val$task.getResult());
            }
          }
        });
        return null;
      }
    });
    return localTaskCompletionSource.getTask();
  }

  static void checkCacheApplicationId()
  {
    File localFile1;
    synchronized (MUTEX)
    {
      if (applicationId != null)
      {
        localFile1 = new File(getParseDir(), "applicationId");
        boolean bool1 = localFile1.exists();
        if (!bool1);
      }
    }
    try
    {
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(localFile1, "r");
      byte[] arrayOfByte = new byte[(int)localRandomAccessFile.length()];
      localRandomAccessFile.readFully(arrayOfByte);
      localRandomAccessFile.close();
      boolean bool3 = new String(arrayOfByte, "UTF-8").equals(applicationId);
      bool2 = bool3;
      if (!bool2)
        recursiveDelete(getParseDir());
      File localFile2 = new File(getParseDir(), "applicationId");
      try
      {
        FileOutputStream localFileOutputStream = new FileOutputStream(localFile2);
        localFileOutputStream.write(applicationId.getBytes("UTF-8"));
        localFileOutputStream.close();
        label148: monitorexit;
        return;
        localObject2 = finally;
        monitorexit;
        throw localObject2;
      }
      catch (IOException localIOException1)
      {
        break label148;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        break label148;
      }
      catch (FileNotFoundException localFileNotFoundException1)
      {
        break label148;
      }
    }
    catch (IOException localIOException2)
    {
      while (true)
        bool2 = false;
    }
    catch (FileNotFoundException localFileNotFoundException2)
    {
      while (true)
        boolean bool2 = false;
    }
  }

  static void checkContext()
  {
    if (applicationContext == null)
      throw new RuntimeException("applicationContext is null. You must call Parse.initialize(Context) before using the Parse library.");
  }

  static void checkInit()
  {
    if (applicationId == null)
      throw new RuntimeException("applicationId is null. You must call Parse.initialize(Context) before using the Parse library.");
    if (clientKey == null)
      throw new RuntimeException("clientKey is null. You must call Parse.initialize(Context) before using the Parse library.");
  }

  private static ParseCallbacks[] collectParseCallbacks()
  {
    synchronized (MUTEX_CALLBACKS)
    {
      if (callbacks == null)
        return null;
      ParseCallbacks[] arrayOfParseCallbacks = new ParseCallbacks[callbacks.size()];
      if (callbacks.size() > 0)
        arrayOfParseCallbacks = (ParseCallbacks[])callbacks.toArray(arrayOfParseCallbacks);
      return arrayOfParseCallbacks;
    }
  }

  static int compareNumbers(Number paramNumber1, Number paramNumber2)
  {
    if (((paramNumber1 instanceof Double)) || ((paramNumber2 instanceof Double)))
      return (int)Math.signum(paramNumber1.doubleValue() - paramNumber2.doubleValue());
    if (((paramNumber1 instanceof Float)) || ((paramNumber2 instanceof Float)))
      return (int)Math.signum(paramNumber1.floatValue() - paramNumber2.floatValue());
    if (((paramNumber1 instanceof Long)) || ((paramNumber2 instanceof Long)))
    {
      long l = paramNumber1.longValue() - paramNumber2.longValue();
      if (l < 0L)
        return -1;
      if (l > 0L)
        return 1;
      return 0;
    }
    if (((paramNumber1 instanceof Integer)) || ((paramNumber2 instanceof Integer)))
      return paramNumber1.intValue() - paramNumber2.intValue();
    if (((paramNumber1 instanceof Short)) || ((paramNumber2 instanceof Short)))
      return paramNumber1.shortValue() - paramNumber2.shortValue();
    if (((paramNumber1 instanceof Byte)) || ((paramNumber2 instanceof Byte)))
      return paramNumber1.byteValue() - paramNumber2.byteValue();
    throw new RuntimeException("Unknown number type.");
  }

  static String dateToString(Date paramDate)
  {
    synchronized (MUTEX)
    {
      String str = dateFormat.format(paramDate);
      return str;
    }
  }

  @Deprecated
  static boolean deleteDiskObject(Context paramContext, String paramString)
  {
    monitorenter;
    try
    {
      setContextIfNeeded(paramContext);
      boolean bool = ParseFileUtils.deleteQuietly(new File(getParseDir(), paramString));
      monitorexit;
      return bool;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  static void destroy()
  {
    synchronized (MUTEX)
    {
      ParseEventuallyQueue localParseEventuallyQueue = eventuallyQueue;
      eventuallyQueue = null;
      if (localParseEventuallyQueue != null)
        localParseEventuallyQueue.onDestroy();
    }
    synchronized (MUTEX)
    {
      applicationId = null;
      clientKey = null;
      applicationContext = null;
      return;
      localObject2 = finally;
      monitorexit;
      throw localObject2;
    }
  }

  private static void dispatchOnParseInitialized()
  {
    ParseCallbacks[] arrayOfParseCallbacks = collectParseCallbacks();
    if (arrayOfParseCallbacks != null)
    {
      int i = arrayOfParseCallbacks.length;
      for (int j = 0; j < i; j++)
        arrayOfParseCallbacks[j].onParseInitialized();
    }
  }

  public static void enableLocalDatastore(Context paramContext)
  {
    if (isInitialized())
      throw new IllegalStateException("`Parse#enableLocalDatastore(Context)` must be invoked before `Parse#initialize(Context)`");
    OfflineStore.enableOfflineStore(paramContext);
  }

  static Object encode(Object paramObject, ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
  {
    try
    {
      if ((paramObject instanceof ParseObject))
        return paramParseObjectEncodingStrategy.encodeRelatedObject((ParseObject)paramObject);
      if ((paramObject instanceof ParseQuery))
        return ((ParseQuery)paramObject).toREST();
      if ((paramObject instanceof Date))
        return encodeDate((Date)paramObject);
      if ((paramObject instanceof byte[]))
      {
        JSONObject localJSONObject1 = new JSONObject();
        localJSONObject1.put("__type", "Bytes");
        localJSONObject1.put("base64", Base64.encodeBase64String((byte[])(byte[])paramObject));
        return localJSONObject1;
      }
    }
    catch (JSONException localJSONException)
    {
      RuntimeException localRuntimeException = new RuntimeException(localJSONException);
      throw localRuntimeException;
    }
    if ((paramObject instanceof ParseFile))
      return ((ParseFile)paramObject).encode();
    if ((paramObject instanceof ParseGeoPoint))
    {
      ParseGeoPoint localParseGeoPoint = (ParseGeoPoint)paramObject;
      JSONObject localJSONObject3 = new JSONObject();
      localJSONObject3.put("__type", "GeoPoint");
      localJSONObject3.put("latitude", localParseGeoPoint.getLatitude());
      localJSONObject3.put("longitude", localParseGeoPoint.getLongitude());
      return localJSONObject3;
    }
    if ((paramObject instanceof ParseACL))
      return ((ParseACL)paramObject).toJSONObject(paramParseObjectEncodingStrategy);
    Object localObject2;
    if ((paramObject instanceof Map))
    {
      Map localMap = (Map)paramObject;
      localObject2 = new JSONObject();
      Iterator localIterator3 = localMap.entrySet().iterator();
      while (localIterator3.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator3.next();
        ((JSONObject)localObject2).put((String)localEntry.getKey(), encode(localEntry.getValue(), paramParseObjectEncodingStrategy));
      }
    }
    if ((paramObject instanceof JSONObject))
    {
      JSONObject localJSONObject2 = (JSONObject)paramObject;
      localObject2 = new JSONObject();
      Iterator localIterator2 = localJSONObject2.keys();
      while (localIterator2.hasNext())
      {
        String str = (String)localIterator2.next();
        ((JSONObject)localObject2).put(str, encode(localJSONObject2.opt(str), paramParseObjectEncodingStrategy));
      }
    }
    JSONArray localJSONArray1;
    if ((paramObject instanceof List))
    {
      localJSONArray1 = new JSONArray();
      Iterator localIterator1 = ((List)paramObject).iterator();
      while (localIterator1.hasNext())
        localJSONArray1.put(encode(localIterator1.next(), paramParseObjectEncodingStrategy));
    }
    if ((paramObject instanceof JSONArray))
    {
      JSONArray localJSONArray2 = (JSONArray)paramObject;
      localObject2 = new JSONArray();
      for (int i = 0; i < localJSONArray2.length(); i++)
        ((JSONArray)localObject2).put(encode(localJSONArray2.opt(i), paramParseObjectEncodingStrategy));
    }
    if ((paramObject instanceof ParseRelation))
      return ((ParseRelation)paramObject).encodeToJSON(paramParseObjectEncodingStrategy);
    if ((paramObject instanceof ParseFieldOperation))
      return ((ParseFieldOperation)paramObject).encode(paramParseObjectEncodingStrategy);
    if ((paramObject instanceof ParseQuery.RelationConstraint))
      return ((ParseQuery.RelationConstraint)paramObject).encode(paramParseObjectEncodingStrategy);
    if (paramObject == null)
    {
      Object localObject1 = JSONObject.NULL;
      return localObject1;
    }
    if (isValidType(paramObject))
      return paramObject;
    throw new IllegalArgumentException("invalid type for ParseObject: " + paramObject.getClass().toString());
    return localObject2;
    return localJSONArray1;
  }

  static JSONObject encodeDate(Date paramDate)
  {
    JSONObject localJSONObject = new JSONObject();
    String str = dateToString(paramDate);
    try
    {
      localJSONObject.put("__type", "Date");
      localJSONObject.put("iso", str);
      return localJSONObject;
    }
    catch (JSONException localJSONException)
    {
    }
    throw new RuntimeException(localJSONException);
  }

  static Context getApplicationContext()
  {
    checkContext();
    return applicationContext;
  }

  @Deprecated
  static JSONObject getDiskObject(Context paramContext, String paramString)
  {
    monitorenter;
    try
    {
      setContextIfNeeded(paramContext);
      JSONObject localJSONObject = getDiskObject(new File(getParseDir(), paramString));
      monitorexit;
      return localJSONObject;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  // ERROR //
  static JSONObject getDiskObject(File paramFile)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: new 410	org/json/JSONObject
    //   6: dup
    //   7: new 552	org/json/JSONTokener
    //   10: dup
    //   11: new 164	java/lang/String
    //   14: dup
    //   15: aload_0
    //   16: invokestatic 556	com/parse/ParseFileUtils:readFileToByteArray	(Ljava/io/File;)[B
    //   19: ldc_w 277
    //   22: invokespecial 280	java/lang/String:<init>	([BLjava/lang/String;)V
    //   25: invokespecial 557	org/json/JSONTokener:<init>	(Ljava/lang/String;)V
    //   28: invokespecial 560	org/json/JSONObject:<init>	(Lorg/json/JSONTokener;)V
    //   31: astore_1
    //   32: ldc 2
    //   34: monitorexit
    //   35: aload_1
    //   36: areturn
    //   37: astore 4
    //   39: aconst_null
    //   40: astore_1
    //   41: goto -9 -> 32
    //   44: astore_3
    //   45: aconst_null
    //   46: astore_1
    //   47: goto -15 -> 32
    //   50: astore_2
    //   51: ldc 2
    //   53: monitorexit
    //   54: aload_2
    //   55: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   3	32	37	java/io/IOException
    //   3	32	44	org/json/JSONException
    //   3	32	50	finally
  }

  static ParseEventuallyQueue getEventuallyQueue()
  {
    synchronized (MUTEX)
    {
      boolean bool = OfflineStore.isEnabled();
      if ((eventuallyQueue == null) || ((bool) && ((eventuallyQueue instanceof ParseCommandCache))) || ((!bool) && ((eventuallyQueue instanceof ParsePinningEventuallyQueue))))
      {
        checkContext();
        if (!bool)
          break label95;
        localObject3 = new ParsePinningEventuallyQueue(applicationContext);
        eventuallyQueue = (ParseEventuallyQueue)localObject3;
        if ((bool) && (ParseCommandCache.getPendingCount() > 0))
          new ParseCommandCache(applicationContext);
      }
      ParseEventuallyQueue localParseEventuallyQueue = eventuallyQueue;
      return localParseEventuallyQueue;
      label95: Object localObject3 = new ParseCommandCache(applicationContext);
    }
  }

  public static int getLogLevel()
  {
    return logLevel;
  }

  static File getParseCacheDir()
  {
    synchronized (MUTEX)
    {
      checkContext();
      File localFile = new File(applicationContext.getCacheDir(), "com.parse");
      if (!localFile.exists())
        localFile.mkdirs();
      return localFile;
    }
  }

  static File getParseCacheDir(String paramString)
  {
    synchronized (MUTEX)
    {
      File localFile = new File(getParseCacheDir(), paramString);
      if (!localFile.exists())
        localFile.mkdirs();
      return localFile;
    }
  }

  @Deprecated
  static File getParseDir()
  {
    synchronized (MUTEX)
    {
      checkContext();
      File localFile = applicationContext.getDir("Parse", 0);
      return localFile;
    }
  }

  static File getParseFilesDir()
  {
    synchronized (MUTEX)
    {
      checkContext();
      File localFile = new File(applicationContext.getFilesDir(), "com.parse");
      if (!localFile.exists())
        localFile.mkdirs();
      return localFile;
    }
  }

  static File getParseFilesDir(String paramString)
  {
    synchronized (MUTEX)
    {
      File localFile = new File(getParseFilesDir(), paramString);
      if (!localFile.exists())
        localFile.mkdirs();
      return localFile;
    }
  }

  static ScheduledExecutorService getScheduledExecutor()
  {
    synchronized (SCHEDULED_EXECUTOR_LOCK)
    {
      if (scheduledExecutor == null)
        scheduledExecutor = Executors.newScheduledThreadPool(1);
      return scheduledExecutor;
    }
  }

  static boolean hasPermission(String paramString)
  {
    checkContext();
    return applicationContext.checkCallingOrSelfPermission(paramString) == 0;
  }

  public static void initialize(Context paramContext)
  {
    applicationContext = paramContext.getApplicationContext();
    Bundle localBundle = ManifestInfo.getApplicationMetadata(applicationContext);
    String str1;
    String str2;
    if (localBundle != null)
    {
      str1 = localBundle.getString("com.parse.APPLICATION_ID");
      str2 = localBundle.getString("com.parse.CLIENT_KEY");
      if (str1 == null)
        throw new RuntimeException("ApplicationId not defined. You must provide ApplicationId in AndroidManifest.xml.\n<meta-data\n    android:name=\"com.parse.APPLICATION_ID\"\n    android:value=\"<Your Application Id>\" />");
      if (str2 == null)
        throw new RuntimeException("ClientKey not defined. You must provide ClientKey in AndroidManifest.xml.\n<meta-data\n    android:name=\"com.parse.CLIENT_KEY\"\n    android:value=\"<Your Client Key>\" />");
    }
    else
    {
      throw new RuntimeException("Can't get Application Metadata");
    }
    initialize(paramContext, str1, str2);
  }

  public static void initialize(Context paramContext, String paramString1, String paramString2)
  {
    ParseRequest.initialize(paramContext);
    ParseKeyValueCache.initialize(paramContext);
    ParseObject.registerParseSubclasses();
    applicationId = paramString1;
    clientKey = paramString2;
    if (paramContext != null)
    {
      applicationContext = paramContext.getApplicationContext();
      checkCacheApplicationId();
      new Thread("Parse.initialize Disk Check & Starting Command Cache")
      {
        public void run()
        {
          Parse.getEventuallyQueue();
        }
      }
      .start();
    }
    ParseFieldOperations.registerDefaultDecoders();
    if (!allParsePushIntentReceiversInternal())
      throw new SecurityException("To prevent external tampering to your app's notifications, all receivers registered to handle the following actions must have their exported attributes set to false: com.parse.push.intent.RECEIVE, com.parse.push.intent.OPEN, com.parse.push.intent.DELETE");
    GcmRegistrar.getInstance().updateAsync().continueWithTask(new Continuation()
    {
      public Task<Void> then(Task<Void> paramTask)
        throws Exception
      {
        return ParseUser.getCurrentUserAsync().makeVoid();
      }
    }).continueWith(new Continuation()
    {
      public Void then(Task<Void> paramTask)
        throws Exception
      {
        ParseConfig.getCurrentConfig();
        return null;
      }
    }
    , Task.BACKGROUND_EXECUTOR);
    dispatchOnParseInitialized();
    synchronized (MUTEX_CALLBACKS)
    {
      callbacks = null;
      return;
    }
  }

  static boolean isContainerObject(Object paramObject)
  {
    return ((paramObject instanceof JSONObject)) || ((paramObject instanceof JSONArray)) || ((paramObject instanceof ParseACL)) || ((paramObject instanceof ParseGeoPoint)) || ((paramObject instanceof List)) || ((paramObject instanceof Map));
  }

  private static boolean isInitialized()
  {
    return (applicationId != null) || (clientKey != null);
  }

  static boolean isValidType(Object paramObject)
  {
    return ((paramObject instanceof JSONObject)) || ((paramObject instanceof JSONArray)) || ((paramObject instanceof String)) || ((paramObject instanceof Number)) || ((paramObject instanceof Boolean)) || (paramObject == JSONObject.NULL) || ((paramObject instanceof ParseObject)) || ((paramObject instanceof ParseACL)) || ((paramObject instanceof ParseFile)) || ((paramObject instanceof ParseGeoPoint)) || ((paramObject instanceof Date)) || ((paramObject instanceof byte[])) || ((paramObject instanceof List)) || ((paramObject instanceof Map)) || ((paramObject instanceof ParseRelation));
  }

  static String join(CharSequence paramCharSequence, Iterable paramIterable)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = 1;
    Iterator localIterator = paramIterable.iterator();
    if (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if (i != 0)
        i = 0;
      while (true)
      {
        localStringBuilder.append(localObject);
        break;
        localStringBuilder.append(paramCharSequence);
      }
    }
    return localStringBuilder.toString();
  }

  static Iterable<String> keys(JSONObject paramJSONObject)
  {
    return new Iterable(paramJSONObject)
    {
      public Iterator<String> iterator()
      {
        return this.val$finalObject.keys();
      }
    };
  }

  private static void log(int paramInt, String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (paramInt >= logLevel)
    {
      if (paramThrowable == null)
        Log.println(logLevel, paramString1, paramString2);
    }
    else
      return;
    Log.println(logLevel, paramString1, paramString2 + '\n' + Log.getStackTraceString(paramThrowable));
  }

  static void logD(String paramString1, String paramString2)
  {
    logD(paramString1, paramString2, null);
  }

  static void logD(String paramString1, String paramString2, Throwable paramThrowable)
  {
    log(3, paramString1, paramString2, paramThrowable);
  }

  static void logE(String paramString1, String paramString2)
  {
    logE(paramString1, paramString2, null);
  }

  static void logE(String paramString1, String paramString2, Throwable paramThrowable)
  {
    log(6, paramString1, paramString2, paramThrowable);
  }

  static void logI(String paramString1, String paramString2)
  {
    logI(paramString1, paramString2, null);
  }

  static void logI(String paramString1, String paramString2, Throwable paramThrowable)
  {
    log(4, paramString1, paramString2, paramThrowable);
  }

  static void logV(String paramString1, String paramString2)
  {
    logV(paramString1, paramString2, null);
  }

  static void logV(String paramString1, String paramString2, Throwable paramThrowable)
  {
    log(2, paramString1, paramString2, paramThrowable);
  }

  static void logW(String paramString1, String paramString2)
  {
    logW(paramString1, paramString2, null);
  }

  static void logW(String paramString1, String paramString2, Throwable paramThrowable)
  {
    log(5, paramString1, paramString2, paramThrowable);
  }

  static <T> List<List<T>> partitionList(List<T> paramList, int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    while (i < paramList.size())
    {
      int j = Math.min(paramList.size() - i, paramInt);
      localArrayList.add(paramList.subList(i, j));
      i += j;
    }
    return localArrayList;
  }

  static void recursiveDelete(File paramFile)
  {
    synchronized (MUTEX)
    {
      if (paramFile.isDirectory())
      {
        File[] arrayOfFile = paramFile.listFiles();
        int i = arrayOfFile.length;
        for (int j = 0; j < i; j++)
          recursiveDelete(arrayOfFile[j]);
      }
      paramFile.delete();
      return;
    }
  }

  static void registerParseCallbacks(ParseCallbacks paramParseCallbacks)
  {
    if (isInitialized())
      throw new IllegalStateException("You must register callbacks before Parse.initialize(Context)");
    synchronized (MUTEX_CALLBACKS)
    {
      if (callbacks == null)
        return;
      callbacks.add(paramParseCallbacks);
      return;
    }
  }

  static void requirePermission(String paramString)
  {
    if (!hasPermission(paramString))
      throw new IllegalStateException("To use this functionality, add this to your AndroidManifest.xml:\n<uses-permission android:name=\"" + paramString + "\" />");
  }

  @Deprecated
  static void saveDiskObject(Context paramContext, String paramString, JSONObject paramJSONObject)
  {
    monitorenter;
    try
    {
      setContextIfNeeded(paramContext);
      saveDiskObject(new File(getParseDir(), paramString), paramJSONObject);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  // ERROR //
  static void saveDiskObject(File paramFile, JSONObject paramJSONObject)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: aload_0
    //   4: aload_1
    //   5: invokevirtual 798	org/json/JSONObject:toString	()Ljava/lang/String;
    //   8: ldc_w 277
    //   11: invokestatic 804	java/nio/charset/Charset:forName	(Ljava/lang/String;)Ljava/nio/charset/Charset;
    //   14: invokevirtual 807	java/lang/String:getBytes	(Ljava/nio/charset/Charset;)[B
    //   17: invokestatic 811	com/parse/ParseFileUtils:writeByteArrayToFile	(Ljava/io/File;[B)V
    //   20: ldc 2
    //   22: monitorexit
    //   23: return
    //   24: astore_3
    //   25: ldc 2
    //   27: monitorexit
    //   28: aload_3
    //   29: athrow
    //   30: astore_2
    //   31: goto -11 -> 20
    //
    // Exception table:
    //   from	to	target	type
    //   3	20	24	finally
    //   3	20	30	java/io/IOException
  }

  static void setContextIfNeeded(Context paramContext)
  {
    if (applicationContext == null)
      applicationContext = paramContext;
  }

  public static void setLogLevel(int paramInt)
  {
    logLevel = paramInt;
  }

  static Date stringToDate(String paramString)
  {
    synchronized (MUTEX)
    {
      try
      {
        Date localDate = dateFormat.parse(paramString);
        return localDate;
      }
      catch (java.text.ParseException localParseException)
      {
        logE("com.parse.Parse", "could not parse date: " + paramString, localParseException);
        return null;
      }
    }
  }

  static Number subtractNumbers(Number paramNumber1, Number paramNumber2)
  {
    if (((paramNumber1 instanceof Double)) || ((paramNumber2 instanceof Double)))
      return Double.valueOf(paramNumber1.doubleValue() - paramNumber2.doubleValue());
    if (((paramNumber1 instanceof Float)) || ((paramNumber2 instanceof Float)))
      return Float.valueOf(paramNumber1.floatValue() - paramNumber2.floatValue());
    if (((paramNumber1 instanceof Long)) || ((paramNumber2 instanceof Long)))
      return Long.valueOf(paramNumber1.longValue() - paramNumber2.longValue());
    if (((paramNumber1 instanceof Integer)) || ((paramNumber2 instanceof Integer)))
      return Integer.valueOf(paramNumber1.intValue() - paramNumber2.intValue());
    if (((paramNumber1 instanceof Short)) || ((paramNumber2 instanceof Short)))
      return Integer.valueOf(paramNumber1.shortValue() - paramNumber2.shortValue());
    if (((paramNumber1 instanceof Byte)) || ((paramNumber2 instanceof Byte)))
      return Integer.valueOf(paramNumber1.byteValue() - paramNumber2.byteValue());
    throw new RuntimeException("Unknown number type.");
  }

  static void unregisterParseCallbacks(ParseCallbacks paramParseCallbacks)
  {
    synchronized (MUTEX_CALLBACKS)
    {
      if (callbacks == null)
        return;
      callbacks.remove(paramParseCallbacks);
      return;
    }
  }

  static <T> T waitForTask(Task<T> paramTask)
    throws ParseException
  {
    Exception localException;
    try
    {
      paramTask.waitForCompletion();
      if (!paramTask.isFaulted())
        break label75;
      localException = paramTask.getError();
      if ((localException instanceof ParseException))
        throw ((ParseException)localException);
    }
    catch (InterruptedException localInterruptedException)
    {
      throw new RuntimeException(localInterruptedException);
    }
    if ((localException instanceof AggregateException))
      throw new ParseException(localException);
    if ((localException instanceof RuntimeException))
      throw ((RuntimeException)localException);
    throw new RuntimeException(localException);
    label75: if (paramTask.isCancelled())
      throw new RuntimeException(new CancellationException());
    Object localObject = paramTask.getResult();
    return localObject;
  }

  static abstract interface ParseCallbacks
  {
    public abstract void onParseInitialized();
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.Parse
 * JD-Core Version:    0.6.0
 */