package com.parse;

class ACRAResponse
{
  private int mStatus;

  public int getStatusCode()
  {
    return this.mStatus;
  }

  public void setStatusCode(int paramInt)
  {
    this.mStatus = paramInt;
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ACRAResponse
 * JD-Core Version:    0.6.0
 */