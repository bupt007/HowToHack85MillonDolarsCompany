package com.parse;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import bolts.Continuation;
import bolts.Task;

public class ParseImageView extends ImageView
{
  private ParseFile file;
  private boolean isLoaded = false;
  private Drawable placeholder;

  public ParseImageView(Context paramContext)
  {
    super(paramContext);
  }

  public ParseImageView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public ParseImageView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  public Task<byte[]> loadInBackground()
  {
    if (this.file == null)
      return Task.forResult(null);
    ParseFile localParseFile = this.file;
    return this.file.getDataInBackground().onSuccessTask(new Continuation(localParseFile)
    {
      public Task<byte[]> then(Task<byte[]> paramTask)
        throws Exception
      {
        byte[] arrayOfByte = (byte[])paramTask.getResult();
        if (ParseImageView.this.file != this.val$loadingFile)
          paramTask = Task.cancelled();
        Bitmap localBitmap;
        do
        {
          do
            return paramTask;
          while (arrayOfByte == null);
          localBitmap = BitmapFactory.decodeByteArray(arrayOfByte, 0, arrayOfByte.length);
        }
        while (localBitmap == null);
        ParseImageView.this.setImageBitmap(localBitmap);
        return paramTask;
      }
    }
    , Task.UI_THREAD_EXECUTOR);
  }

  public void loadInBackground(GetDataCallback paramGetDataCallback)
  {
    Parse.callbackOnMainThreadAsync(loadInBackground(), paramGetDataCallback, true);
  }

  protected void onDetachedFromWindow()
  {
    if (this.file != null)
      this.file.cancel();
  }

  public void setImageBitmap(Bitmap paramBitmap)
  {
    super.setImageBitmap(paramBitmap);
    this.isLoaded = true;
  }

  public void setParseFile(ParseFile paramParseFile)
  {
    if (this.file != null)
      this.file.cancel();
    this.isLoaded = false;
    this.file = paramParseFile;
    setImageDrawable(this.placeholder);
  }

  public void setPlaceholder(Drawable paramDrawable)
  {
    this.placeholder = paramDrawable;
    if (!this.isLoaded)
      setImageDrawable(this.placeholder);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseImageView
 * JD-Core Version:    0.6.0
 */