package com.parse;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.SSLCertificateSocketFactory;
import android.net.SSLSessionCache;
import android.os.Build.VERSION;
import java.io.IOException;
import org.apache.http.HttpHost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.conn.params.ConnPerRouteBean;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

class ParseApacheHttpClient extends ParseHttpClient
{
  private static final int SOCKET_OPERATION_TIMEOUT = 10000;
  private DefaultHttpClient httpClient;

  public ParseApacheHttpClient(Context paramContext)
  {
    if (paramContext == null)
      throw new IllegalArgumentException("Context passed to newHttpClient should not be null.");
    Context localContext = paramContext.getApplicationContext();
    BasicHttpParams localBasicHttpParams = new BasicHttpParams();
    HttpConnectionParams.setStaleCheckingEnabled(localBasicHttpParams, false);
    HttpConnectionParams.setConnectionTimeout(localBasicHttpParams, 10000);
    HttpConnectionParams.setSoTimeout(localBasicHttpParams, 10000);
    HttpConnectionParams.setSocketBufferSize(localBasicHttpParams, 8192);
    HttpClientParams.setRedirecting(localBasicHttpParams, false);
    SSLSessionCache localSSLSessionCache = new SSLSessionCache(localContext);
    HttpProtocolParams.setUserAgent(localBasicHttpParams, getUserAgent(localContext));
    SchemeRegistry localSchemeRegistry = new SchemeRegistry();
    localSchemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
    localSchemeRegistry.register(new Scheme("https", SSLCertificateSocketFactory.getHttpSocketFactory(10000, localSSLSessionCache), 443));
    ConnManagerParams.setMaxConnectionsPerRoute(localBasicHttpParams, new ConnPerRouteBean(20));
    ConnManagerParams.setMaxTotalConnections(localBasicHttpParams, 20);
    String str1 = System.getProperty("http.proxyHost");
    String str2 = System.getProperty("http.proxyPort");
    if ((str1 != null) && (str1.length() != 0) && (str2 != null) && (str2.length() != 0))
      localBasicHttpParams.setParameter("http.route.default-proxy", new HttpHost(str1, Integer.parseInt(str2), "http"));
    this.httpClient = new DefaultHttpClient(new ThreadSafeClientConnManager(localBasicHttpParams, localSchemeRegistry), localBasicHttpParams);
  }

  private String getUserAgent(Context paramContext)
  {
    Object localObject = "unknown";
    try
    {
      String str1 = paramContext.getPackageName();
      int i = paramContext.getPackageManager().getPackageInfo(str1, 0).versionCode;
      String str2 = str1 + "/" + i;
      localObject = str2;
      label54: return "Parse Android SDK 1.9.1 (" + (String)localObject + ") API Level " + Build.VERSION.SDK_INT;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      break label54;
    }
  }

  public ParseHttpResponse execute(HttpUriRequest paramHttpUriRequest)
    throws IOException
  {
    return ParseHttpResponse.createParseApacheHttpResponse(this.httpClient.execute(paramHttpUriRequest));
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseApacheHttpClient
 * JD-Core Version:    0.6.0
 */