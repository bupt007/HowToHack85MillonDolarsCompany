package com.parse;

import bolts.Task;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.http.entity.ByteArrayEntity;

class CountingByteArrayEntity extends ByteArrayEntity
{
  private static final int DEFAULT_CHUNK_SIZE = 4096;
  private final ParseCallback2<Integer, ParseException> progressCallback;

  public CountingByteArrayEntity(byte[] paramArrayOfByte, ProgressCallback paramProgressCallback)
  {
    super(paramArrayOfByte);
    if (paramProgressCallback != null)
    {
      this.progressCallback = new ParseCallback2(paramProgressCallback)
      {
        Integer maxProgressSoFar = Integer.valueOf(0);

        public void done(Integer paramInteger, ParseException paramParseException)
        {
          if (paramInteger.intValue() > this.maxProgressSoFar.intValue())
          {
            this.maxProgressSoFar = paramInteger;
            this.val$progressCallback.done(paramInteger);
          }
        }
      };
      return;
    }
    this.progressCallback = null;
  }

  private void reportProgressIfNeeded(int paramInt)
  {
    Parse.callbackOnMainThreadAsync(Task.forResult(Integer.valueOf(paramInt)), this.progressCallback);
  }

  public void writeTo(OutputStream paramOutputStream)
    throws IOException
  {
    if (paramOutputStream == null)
      throw new IllegalArgumentException("Output stream may not be null");
    int i = 0;
    int j = this.content.length;
    while (i < j)
    {
      int k = Math.min(j - i, 4096);
      paramOutputStream.write(this.content, i, k);
      paramOutputStream.flush();
      i += k;
      reportProgressIfNeeded(i * 100 / j);
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.CountingByteArrayEntity
 * JD-Core Version:    0.6.0
 */