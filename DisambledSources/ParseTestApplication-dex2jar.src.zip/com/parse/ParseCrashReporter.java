package com.parse;

import android.content.Context;
import java.io.File;

class ParseCrashReporter
{
  private static final String REPORT_ENDPOINT = "http://dev/null";
  private static ParseCrashReporter defaultInstance;
  private static final Object defaultInstanceLock = new Object();
  private ErrorReporter innerCrashReporter;

  private ParseCrashReporter(Context paramContext)
  {
    2 local2 = new Parse.ParseCallbacks(paramContext, new FileProvider()
    {
      public File getFile(String paramString)
      {
        return Parse.getParseFilesDir(paramString);
      }
    })
    {
      public void onParseInitialized()
      {
        ParseCrashReporter.access$002(ParseCrashReporter.this, ACRA.init(new BaseCrashReporter(this.val$applicationContext), "http://dev/null", true, this.val$fileProvider));
        ParseCrashReporter.this.innerCrashReporter.setReportSender(new ParseCrashReportHandler());
      }
    };
    try
    {
      Parse.registerParseCallbacks(local2);
      return;
    }
    catch (IllegalStateException localIllegalStateException)
    {
    }
    throw new IllegalStateException("You must enable crash reporting before calling Parse.initialize(context, applicationId, clientKey");
  }

  static void enableCrashReporting(Context paramContext)
  {
    synchronized (defaultInstanceLock)
    {
      if (defaultInstance == null)
      {
        defaultInstance = new ParseCrashReporter(paramContext);
        return;
      }
      throw new RuntimeException("enableCrashReporting() called multiple times.");
    }
  }

  static ParseCrashReporter getCurrent()
  {
    synchronized (defaultInstanceLock)
    {
      ParseCrashReporter localParseCrashReporter = defaultInstance;
      return localParseCrashReporter;
    }
  }

  static boolean isEnabled()
  {
    while (true)
    {
      synchronized (defaultInstanceLock)
      {
        if (defaultInstance != null)
        {
          i = 1;
          return i;
        }
      }
      int i = 0;
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseCrashReporter
 * JD-Core Version:    0.6.0
 */