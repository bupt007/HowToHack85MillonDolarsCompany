package com.parse;

import bolts.Continuation;
import bolts.Task;
import bolts.Task<Ljava.lang.Void;>;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@ParseClassName("_Pin")
class ParsePin extends ParseObject
{
  private static final String KEY_NAME = "_name";
  private static final String KEY_OBJECTS = "_objects";

  static Task<ParsePin> getParsePin(String paramString)
  {
    ParseQuery localParseQuery = ParseQuery.getQuery(ParsePin.class).whereEqualTo("_name", paramString);
    return OfflineStore.getCurrent().findAsync(localParseQuery, null, null).onSuccess(new Continuation(paramString)
    {
      public ParsePin then(Task<List<ParsePin>> paramTask)
        throws Exception
      {
        Object localObject = paramTask.getResult();
        ParsePin localParsePin = null;
        if (localObject != null)
        {
          int i = ((List)paramTask.getResult()).size();
          localParsePin = null;
          if (i > 0)
            localParsePin = (ParsePin)((List)paramTask.getResult()).get(0);
        }
        if (localParsePin == null)
        {
          localParsePin = (ParsePin)ParseObject.create(ParsePin.class);
          localParsePin.setName(this.val$name);
        }
        return localParsePin;
      }
    });
  }

  static <T extends ParseObject> Task<Void> pinAllObjectsAsync(String paramString, List<T> paramList, boolean paramBoolean)
  {
    if ((paramList == null) || (paramList.size() == 0))
      return Task.forResult(null);
    return getParsePin(paramString).onSuccessTask(new Continuation(paramList, paramBoolean)
    {
      public Task<Void> then(Task<ParsePin> paramTask)
        throws Exception
      {
        ParsePin localParsePin = (ParsePin)paramTask.getResult();
        OfflineStore localOfflineStore = OfflineStore.getCurrent();
        Object localObject = localParsePin.getObjects();
        if (localObject == null)
          localObject = new ArrayList(this.val$objects);
        while (true)
        {
          localParsePin.setObjects((List)localObject);
          if (!this.val$includeChildren)
            break;
          return localOfflineStore.saveLocallyAsync(localParsePin);
          Iterator localIterator = this.val$objects.iterator();
          while (localIterator.hasNext())
          {
            ParseObject localParseObject = (ParseObject)localIterator.next();
            if (((List)localObject).contains(localParseObject))
              continue;
            ((List)localObject).add(localParseObject);
          }
        }
        return (Task<Void>)localOfflineStore.saveLocallyAsync(localParsePin, localParsePin.getObjects());
      }
    });
  }

  static Task<Void> unpinAllObjectsAsync(String paramString)
  {
    return getParsePin(paramString).continueWithTask(new Continuation()
    {
      public Task<Void> then(Task<ParsePin> paramTask)
        throws Exception
      {
        if (paramTask.isFaulted())
          return paramTask.makeVoid();
        ParsePin localParsePin = (ParsePin)paramTask.getResult();
        return OfflineStore.getCurrent().unpinAsync(localParsePin);
      }
    });
  }

  static <T extends ParseObject> Task<Void> unpinAllObjectsAsync(String paramString, List<T> paramList)
  {
    if ((paramList == null) || (paramList.size() == 0))
      return Task.forResult(null);
    return getParsePin(paramString).onSuccessTask(new Continuation(paramList)
    {
      public Task<Void> then(Task<ParsePin> paramTask)
        throws Exception
      {
        ParsePin localParsePin = (ParsePin)paramTask.getResult();
        OfflineStore localOfflineStore = OfflineStore.getCurrent();
        List localList = localParsePin.getObjects();
        if (localList == null)
          return Task.forResult(null);
        localList.removeAll(this.val$objects);
        if (localList.size() == 0)
          return localOfflineStore.unpinAsync(localParsePin);
        localParsePin.setObjects(localList);
        return localOfflineStore.saveLocallyAsync(localParsePin);
      }
    });
  }

  public String getName()
  {
    return getString("_name");
  }

  public List<ParseObject> getObjects()
  {
    return getList("_objects");
  }

  boolean needsDefaultACL()
  {
    return false;
  }

  public void setName(String paramString)
  {
    put("_name", paramString);
  }

  public void setObjects(List<ParseObject> paramList)
  {
    put("_objects", paramList);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParsePin
 * JD-Core Version:    0.6.0
 */