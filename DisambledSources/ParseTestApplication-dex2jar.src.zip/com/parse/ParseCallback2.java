package com.parse;

abstract interface ParseCallback2<T1, T2 extends Throwable>
{
  public abstract void done(T1 paramT1, T2 paramT2);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseCallback2
 * JD-Core Version:    0.6.0
 */