package com.parse;

public abstract interface GetDataCallback extends ParseCallback2<byte[], ParseException>
{
  public abstract void done(byte[] paramArrayOfByte, ParseException paramParseException);
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.GetDataCallback
 * JD-Core Version:    0.6.0
 */