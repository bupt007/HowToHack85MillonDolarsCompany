package com.parse;

import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

abstract class ParseNetworkCommand<R, T> extends ParseRequest<R, T>
{
  public ParseNetworkCommand(ParseRequest.Method paramMethod, String paramString)
  {
    super(paramMethod, paramString);
  }

  protected static void getLocalPointersIn(Object paramObject, ArrayList<JSONObject> paramArrayList)
    throws JSONException
  {
    JSONObject localJSONObject;
    if ((paramObject instanceof JSONObject))
    {
      localJSONObject = (JSONObject)paramObject;
      if (("Pointer".equals(localJSONObject.opt("__type"))) && (localJSONObject.has("localId")))
        paramArrayList.add((JSONObject)paramObject);
    }
    while (true)
    {
      return;
      Iterator localIterator = localJSONObject.keys();
      while (localIterator.hasNext())
        getLocalPointersIn(localJSONObject.get((String)localIterator.next()), paramArrayList);
      if (!(paramObject instanceof JSONArray))
        continue;
      JSONArray localJSONArray = (JSONArray)paramObject;
      for (int i = 0; i < localJSONArray.length(); i++)
        getLocalPointersIn(localJSONArray.get(i), paramArrayList);
    }
  }

  abstract String getLocalId();

  abstract String getOperationSetUUID();

  abstract String getSessionToken();

  abstract void releaseLocalIds();

  abstract void retainLocalIds();

  abstract void setLocalId(String paramString);

  abstract void setOperationSetUUID(String paramString);

  abstract JSONObject toJSONObject();
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseNetworkCommand
 * JD-Core Version:    0.6.0
 */