package com.parse;

import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

class ParseCrashReportHandler
  implements ReportSender
{
  private static final ReportField[] CRASH_REPORT_FIELDS;

  static
  {
    ReportField[] arrayOfReportField = new ReportField[26];
    arrayOfReportField[0] = ReportField.REPORT_ID;
    arrayOfReportField[1] = ReportField.APP_INSTALL_TIME;
    arrayOfReportField[2] = ReportField.APP_UPGRADE_TIME;
    arrayOfReportField[3] = ReportField.AVAILABLE_MEM_SIZE;
    arrayOfReportField[4] = ReportField.BRAND;
    arrayOfReportField[5] = ReportField.BUILD;
    arrayOfReportField[6] = ReportField.CRASH_CONFIGURATION;
    arrayOfReportField[7] = ReportField.DEVICE_FEATURES;
    arrayOfReportField[8] = ReportField.DEVICE_UPTIME;
    arrayOfReportField[9] = ReportField.DUMPSYS_MEMINFO;
    arrayOfReportField[10] = ReportField.EXCEPTION_CAUSE;
    arrayOfReportField[11] = ReportField.IS_LOW_RAM_DEVICE;
    arrayOfReportField[12] = ReportField.IS_SILENT;
    arrayOfReportField[13] = ReportField.OPEN_FD_COUNT;
    arrayOfReportField[14] = ReportField.OPEN_FD_HARD_LIMIT;
    arrayOfReportField[15] = ReportField.OPEN_FD_SOFT_LIMIT;
    arrayOfReportField[16] = ReportField.PACKAGE_NAME;
    arrayOfReportField[17] = ReportField.PHONE_MODEL;
    arrayOfReportField[18] = ReportField.PROCESS_NAME;
    arrayOfReportField[19] = ReportField.PROCESS_UPTIME;
    arrayOfReportField[20] = ReportField.PRODUCT;
    arrayOfReportField[21] = ReportField.SIGQUIT;
    arrayOfReportField[22] = ReportField.STACK_TRACE;
    arrayOfReportField[23] = ReportField.TOTAL_MEM_SIZE;
    arrayOfReportField[24] = ReportField.USER_APP_START_DATE;
    arrayOfReportField[25] = ReportField.USER_CRASH_DATE;
    CRASH_REPORT_FIELDS = arrayOfReportField;
  }

  private JSONObject getCrashReportEventPayload(CrashReportData paramCrashReportData)
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject();
    for (ReportField localReportField : CRASH_REPORT_FIELDS)
      localJSONObject.put(localReportField.toString(), paramCrashReportData.get(localReportField));
    return localJSONObject;
  }

  public void send(CrashReportData paramCrashReportData)
    throws ReportSenderException
  {
    try
    {
      JSONObject localJSONObject = getCrashReportEventPayload(paramCrashReportData);
      Log.d("CrashReporting", "Sending crash report to Parse...");
      ParseCrashReporting.trackCrashReport(localJSONObject);
      return;
    }
    catch (JSONException localJSONException)
    {
    }
    throw new ReportSenderException("Failed to convert crash report into event payload", localJSONException);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseCrashReportHandler
 * JD-Core Version:    0.6.0
 */