package com.parse;

import bolts.Continuation;
import bolts.Task;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class OfflineQueryLogic
{
  private final OfflineStore store;

  OfflineQueryLogic(OfflineStore paramOfflineStore)
  {
    this.store = paramOfflineStore;
  }

  private static boolean compare(Object paramObject1, Object paramObject2, Decider paramDecider)
  {
    if ((paramObject2 instanceof List))
      return compareList(paramObject1, (List)paramObject2, paramDecider);
    if ((paramObject2 instanceof JSONArray))
      return compareArray(paramObject1, (JSONArray)paramObject2, paramDecider);
    return paramDecider.decide(paramObject1, paramObject2);
  }

  private static boolean compareArray(Object paramObject, JSONArray paramJSONArray, Decider paramDecider)
  {
    for (int i = 0; i < paramJSONArray.length(); i++)
      try
      {
        boolean bool = paramDecider.decide(paramObject, paramJSONArray.get(i));
        if (bool)
          return true;
      }
      catch (JSONException localJSONException)
      {
        throw new RuntimeException(localJSONException);
      }
    return false;
  }

  private static boolean compareList(Object paramObject, List<?> paramList, Decider paramDecider)
  {
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
      if (paramDecider.decide(paramObject, localIterator.next()))
        return true;
    return false;
  }

  private static int compareTo(Object paramObject1, Object paramObject2)
  {
    int i;
    if ((paramObject1 == JSONObject.NULL) || (paramObject1 == null))
    {
      i = 1;
      if ((paramObject2 != JSONObject.NULL) && (paramObject2 != null))
        break label45;
    }
    label45: for (int j = 1; ; j = 0)
    {
      if ((i == 0) && (j == 0))
        break label58;
      if (i != 0)
        break label50;
      return 1;
      i = 0;
      break;
    }
    label50: if (j == 0)
      return -1;
    return 0;
    label58: if (((paramObject1 instanceof Date)) && ((paramObject2 instanceof Date)))
      return ((Date)paramObject1).compareTo((Date)paramObject2);
    if (((paramObject1 instanceof String)) && ((paramObject2 instanceof String)))
      return ((String)paramObject1).compareTo((String)paramObject2);
    if (((paramObject1 instanceof Number)) && ((paramObject2 instanceof Number)))
      return Parse.compareNumbers((Number)paramObject1, (Number)paramObject2);
    throw new IllegalArgumentException(String.format("Cannot compare %s against %s", new Object[] { paramObject1, paramObject2 }));
  }

  private <T extends ParseObject> ConstraintMatcher<T> createDontSelectMatcher(ParseUser paramParseUser, Object paramObject, String paramString)
  {
    return new ConstraintMatcher(paramParseUser, createSelectMatcher(paramParseUser, paramObject, paramString))
    {
      public Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase)
      {
        return this.val$selectMatcher.matchesAsync(paramT, paramParseSQLiteDatabase).onSuccess(new Continuation()
        {
          public Boolean then(Task<Boolean> paramTask)
            throws Exception
          {
            if (!((Boolean)paramTask.getResult()).booleanValue());
            for (boolean bool = true; ; bool = false)
              return Boolean.valueOf(bool);
          }
        });
      }
    };
  }

  private <T extends ParseObject> ConstraintMatcher<T> createInQueryMatcher(ParseUser paramParseUser, Object paramObject, String paramString)
  {
    return new SubQueryMatcher(paramParseUser, (ParseQuery)paramObject, paramString)
    {
      protected boolean matches(T paramT, List<T> paramList)
        throws ParseException
      {
        return OfflineQueryLogic.access$300(paramList, OfflineQueryLogic.this.getValue(paramT, this.val$key));
      }
    };
  }

  private <T extends ParseObject> ConstraintMatcher<T> createMatcher(ParseUser paramParseUser, ParseQuery.QueryConstraints paramQueryConstraints)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator1 = paramQueryConstraints.keySet().iterator();
    while (localIterator1.hasNext())
    {
      String str1 = (String)localIterator1.next();
      Object localObject = paramQueryConstraints.get(str1);
      if (str1.equals("$or"))
      {
        localArrayList.add(createOrMatcher(paramParseUser, (ArrayList)localObject));
        continue;
      }
      if ((localObject instanceof ParseQuery.KeyConstraints))
      {
        ParseQuery.KeyConstraints localKeyConstraints = (ParseQuery.KeyConstraints)localObject;
        Iterator localIterator2 = localKeyConstraints.keySet().iterator();
        while (localIterator2.hasNext())
        {
          String str2 = (String)localIterator2.next();
          localArrayList.add(createMatcher(paramParseUser, str2, localKeyConstraints.get(str2), str1, localKeyConstraints));
        }
        continue;
      }
      if ((localObject instanceof ParseQuery.RelationConstraint))
      {
        localArrayList.add(new ConstraintMatcher(paramParseUser, (ParseQuery.RelationConstraint)localObject)
        {
          public Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase)
          {
            return Task.forResult(Boolean.valueOf(this.val$relation.getRelation().hasKnownObject(paramT)));
          }
        });
        continue;
      }
      localArrayList.add(new ConstraintMatcher(paramParseUser, str1, localObject)
      {
        public Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase)
        {
          try
          {
            Object localObject = OfflineQueryLogic.this.getValue(paramT, this.val$key);
            return Task.forResult(Boolean.valueOf(OfflineQueryLogic.access$400(this.val$queryConstraintValue, localObject)));
          }
          catch (ParseException localParseException)
          {
          }
          return Task.forError(localParseException);
        }
      });
    }
    return new ConstraintMatcher(paramParseUser, localArrayList)
    {
      public Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase)
      {
        Task localTask = Task.forResult(Boolean.valueOf(true));
        Iterator localIterator = this.val$matchers.iterator();
        while (localIterator.hasNext())
          localTask = localTask.onSuccessTask(new Continuation((OfflineQueryLogic.ConstraintMatcher)localIterator.next(), paramT, paramParseSQLiteDatabase)
          {
            public Task<Boolean> then(Task<Boolean> paramTask)
              throws Exception
            {
              if (!((Boolean)paramTask.getResult()).booleanValue())
                return paramTask;
              return this.val$matcher.matchesAsync(this.val$object, this.val$db);
            }
          });
        return localTask;
      }
    };
  }

  private <T extends ParseObject> ConstraintMatcher<T> createMatcher(ParseUser paramParseUser, String paramString1, Object paramObject, String paramString2, ParseQuery.KeyConstraints paramKeyConstraints)
  {
    if (paramString1.equals("$inQuery"))
      return createInQueryMatcher(paramParseUser, paramObject, paramString2);
    if (paramString1.equals("$notInQuery"))
      return createNotInQueryMatcher(paramParseUser, paramObject, paramString2);
    if (paramString1.equals("$select"))
      return createSelectMatcher(paramParseUser, paramObject, paramString2);
    if (paramString1.equals("$dontSelect"))
      return createDontSelectMatcher(paramParseUser, paramObject, paramString2);
    return new ConstraintMatcher(paramParseUser, paramString2, paramString1, paramObject, paramKeyConstraints)
    {
      public Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase)
      {
        try
        {
          Object localObject = OfflineQueryLogic.this.getValue(paramT, this.val$key);
          Task localTask = Task.forResult(Boolean.valueOf(OfflineQueryLogic.access$500(this.val$operator, this.val$constraint, localObject, this.val$allKeyConstraints)));
          return localTask;
        }
        catch (ParseException localParseException)
        {
        }
        return Task.forError(localParseException);
      }
    };
  }

  private <T extends ParseObject> ConstraintMatcher<T> createNotInQueryMatcher(ParseUser paramParseUser, Object paramObject, String paramString)
  {
    return new ConstraintMatcher(paramParseUser, createInQueryMatcher(paramParseUser, paramObject, paramString))
    {
      public Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase)
      {
        return this.val$inQueryMatcher.matchesAsync(paramT, paramParseSQLiteDatabase).onSuccess(new Continuation()
        {
          public Boolean then(Task<Boolean> paramTask)
            throws Exception
          {
            if (!((Boolean)paramTask.getResult()).booleanValue());
            for (boolean bool = true; ; bool = false)
              return Boolean.valueOf(bool);
          }
        });
      }
    };
  }

  private <T extends ParseObject> ConstraintMatcher<T> createOrMatcher(ParseUser paramParseUser, ArrayList<ParseQuery.QueryConstraints> paramArrayList)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext())
      localArrayList.add(createMatcher(paramParseUser, (ParseQuery.QueryConstraints)localIterator.next()));
    return new ConstraintMatcher(paramParseUser, localArrayList)
    {
      public Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase)
      {
        Task localTask = Task.forResult(Boolean.valueOf(false));
        Iterator localIterator = this.val$matchers.iterator();
        while (localIterator.hasNext())
          localTask = localTask.onSuccessTask(new Continuation((OfflineQueryLogic.ConstraintMatcher)localIterator.next(), paramT, paramParseSQLiteDatabase)
          {
            public Task<Boolean> then(Task<Boolean> paramTask)
              throws Exception
            {
              if (((Boolean)paramTask.getResult()).booleanValue())
                return paramTask;
              return this.val$matcher.matchesAsync(this.val$object, this.val$db);
            }
          });
        return localTask;
      }
    };
  }

  private <T extends ParseObject> ConstraintMatcher<T> createSelectMatcher(ParseUser paramParseUser, Object paramObject, String paramString)
  {
    JSONObject localJSONObject = (JSONObject)paramObject;
    return new SubQueryMatcher(paramParseUser, (ParseQuery)localJSONObject.opt("query"), paramString, localJSONObject.optString("key", null))
    {
      protected boolean matches(T paramT, List<T> paramList)
        throws ParseException
      {
        Object localObject = OfflineQueryLogic.this.getValue(paramT, this.val$key);
        Iterator localIterator = paramList.iterator();
        while (localIterator.hasNext())
        {
          ParseObject localParseObject = (ParseObject)localIterator.next();
          if (OfflineQueryLogic.access$400(localObject, OfflineQueryLogic.this.getValue(localParseObject, this.val$resultKey)))
            return true;
        }
        return false;
      }
    };
  }

  private Task<Void> fetchIncludeAsync(Object paramObject, String paramString, ParseSQLiteDatabase paramParseSQLiteDatabase)
    throws ParseException
  {
    Task localTask;
    if (paramObject == null)
      localTask = Task.forResult(null);
    while (true)
    {
      return localTask;
      if ((paramObject instanceof JSONArray))
      {
        JSONArray localJSONArray = (JSONArray)paramObject;
        localTask = Task.forResult(null);
        for (int i = 0; i < localJSONArray.length(); i++)
        {
          17 local17 = new Continuation(localJSONArray, i, paramString, paramParseSQLiteDatabase)
          {
            public Task<Void> then(Task<Void> paramTask)
              throws Exception
            {
              return OfflineQueryLogic.this.fetchIncludeAsync(this.val$array.get(this.val$index), this.val$path, this.val$db);
            }
          };
          localTask = localTask.onSuccessTask(local17);
        }
        continue;
      }
      if (!(paramObject instanceof List))
        break;
      List localList = (List)paramObject;
      localTask = Task.forResult(null);
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        18 local18 = new Continuation(localIterator.next(), paramString, paramParseSQLiteDatabase)
        {
          public Task<Void> then(Task<Void> paramTask)
            throws Exception
          {
            return OfflineQueryLogic.this.fetchIncludeAsync(this.val$item, this.val$path, this.val$db);
          }
        };
        localTask = localTask.onSuccessTask(local18);
      }
    }
    if (paramString == null)
    {
      if (JSONObject.NULL.equals(paramObject))
        return null;
      if ((paramObject instanceof ParseObject))
      {
        ParseObject localParseObject = (ParseObject)paramObject;
        return this.store.fetchLocallyAsync(localParseObject, paramParseSQLiteDatabase).makeVoid();
      }
      return Task.forError(new ParseException(121, "include is invalid for non-ParseObjects"));
    }
    String[] arrayOfString = paramString.split("\\.", 2);
    String str1 = arrayOfString[0];
    if (arrayOfString.length > 1);
    for (String str2 = arrayOfString[1]; ; str2 = null)
      return Task.forResult(null).continueWithTask(new Continuation(paramObject, paramParseSQLiteDatabase, str1)
      {
        public Task<Object> then(Task<Void> paramTask)
          throws Exception
        {
          Task localTask;
          if ((this.val$container instanceof ParseObject))
            localTask = OfflineQueryLogic.this.fetchIncludeAsync(this.val$container, null, this.val$db).onSuccess(new Continuation()
            {
              public Object then(Task<Void> paramTask)
                throws Exception
              {
                return ((ParseObject)OfflineQueryLogic.20.this.val$container).get(OfflineQueryLogic.20.this.val$key);
              }
            });
          boolean bool;
          do
          {
            return localTask;
            if ((this.val$container instanceof Map))
              return Task.forResult(((Map)this.val$container).get(this.val$key));
            if ((this.val$container instanceof JSONObject))
              return Task.forResult(((JSONObject)this.val$container).opt(this.val$key));
            bool = JSONObject.NULL.equals(this.val$container);
            localTask = null;
          }
          while (bool);
          return Task.forError(new IllegalStateException("include is invalid"));
        }
      }).onSuccessTask(new Continuation(str2, paramParseSQLiteDatabase)
      {
        public Task<Void> then(Task<Object> paramTask)
          throws Exception
        {
          return OfflineQueryLogic.this.fetchIncludeAsync(paramTask.getResult(), this.val$rest, this.val$db);
        }
      });
  }

  private Object getValue(Object paramObject, String paramString)
    throws ParseException
  {
    return getValue(paramObject, paramString, 0);
  }

  private Object getValue(Object paramObject, String paramString, int paramInt)
    throws ParseException
  {
    String[] arrayOfString;
    Object localObject3;
    if (paramString.contains("."))
    {
      arrayOfString = paramString.split("\\.", 2);
      localObject3 = getValue(paramObject, arrayOfString[0], paramInt + 1);
      if ((localObject3 != null) && (localObject3 != JSONObject.NULL) && (!(localObject3 instanceof Map)) && (!(localObject3 instanceof JSONObject)) && (paramInt <= 0));
    }
    try
    {
      Object localObject5 = Parse.encode(localObject3, PointerEncodingStrategy.get());
      localObject4 = localObject5;
      Object localObject2;
      if ((localObject4 instanceof JSONObject))
        localObject2 = getValue(localObject4, arrayOfString[1], paramInt + 1);
      do
      {
        Object localObject1;
        do
        {
          return localObject2;
          throw new ParseException(102, String.format("Key %s is invalid.", new Object[] { paramString }));
          return getValue(localObject3, arrayOfString[1], paramInt + 1);
          if ((paramObject instanceof ParseObject))
          {
            ParseObject localParseObject = (ParseObject)paramObject;
            if (!localParseObject.isDataAvailable())
              throw new ParseException(121, String.format("Bad key: %s", new Object[] { paramString }));
            if (paramString.equals("objectId"))
              return localParseObject.getObjectId();
            if ((paramString.equals("createdAt")) || (paramString.equals("_created_at")))
              return localParseObject.getCreatedAt();
            if ((paramString.equals("updatedAt")) || (paramString.equals("_updated_at")))
              return localParseObject.getUpdatedAt();
            return localParseObject.get(paramString);
          }
          if ((paramObject instanceof JSONObject))
            return ((JSONObject)paramObject).opt(paramString);
          if ((paramObject instanceof Map))
            return ((Map)paramObject).get(paramString);
          localObject1 = JSONObject.NULL;
          localObject2 = null;
        }
        while (paramObject == localObject1);
        localObject2 = null;
      }
      while (paramObject == null);
      throw new ParseException(121, String.format("Bad key: %s", new Object[] { paramString }));
    }
    catch (Exception localException)
    {
      while (true)
        Object localObject4 = null;
    }
  }

  static <T extends ParseObject> boolean hasReadAccess(ParseUser paramParseUser, T paramT)
  {
    if (paramParseUser == paramT);
    ParseACL localParseACL;
    do
    {
      return true;
      localParseACL = paramT.getACL();
    }
    while ((localParseACL == null) || (localParseACL.getPublicReadAccess()) || ((paramParseUser != null) && (localParseACL.getReadAccess(paramParseUser))));
    return false;
  }

  static <T extends ParseObject> boolean hasWriteAccess(ParseUser paramParseUser, T paramT)
  {
    if (paramParseUser == paramT);
    ParseACL localParseACL;
    do
    {
      return true;
      localParseACL = paramT.getACL();
    }
    while ((localParseACL == null) || (localParseACL.getPublicWriteAccess()) || ((paramParseUser != null) && (localParseACL.getWriteAccess(paramParseUser))));
    return false;
  }

  private static boolean matchesAllConstraint(Object paramObject1, Object paramObject2)
  {
    if ((paramObject2 == null) || (paramObject2 == JSONObject.NULL))
      return false;
    if ((!(paramObject2 instanceof List)) && (!(paramObject2 instanceof JSONArray)))
      throw new IllegalArgumentException("Value type not supported for $all queries.");
    if ((paramObject1 instanceof List))
    {
      Iterator localIterator = ((List)paramObject1).iterator();
      while (localIterator.hasNext())
        if (!matchesEqualConstraint(localIterator.next(), paramObject2))
          return false;
      return true;
    }
    if ((paramObject1 instanceof JSONArray))
    {
      for (int i = 0; i < ((JSONArray)paramObject1).length(); i++)
        if (!matchesEqualConstraint(((JSONArray)paramObject1).opt(i), paramObject2))
          return false;
      return true;
    }
    throw new IllegalArgumentException("Constraint type not supported for $all queries.");
  }

  private static boolean matchesEqualConstraint(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 == null) || (paramObject2 == null))
      if (paramObject1 != paramObject2);
    while (true)
    {
      return true;
      return false;
      if (((paramObject1 instanceof Number)) && ((paramObject2 instanceof Number)))
        if (compareTo(paramObject1, paramObject2) != 0)
          return false;
      if ((!(paramObject1 instanceof ParseGeoPoint)) || (!(paramObject2 instanceof ParseGeoPoint)))
        break;
      ParseGeoPoint localParseGeoPoint1 = (ParseGeoPoint)paramObject1;
      ParseGeoPoint localParseGeoPoint2 = (ParseGeoPoint)paramObject2;
      if ((localParseGeoPoint1.getLatitude() != localParseGeoPoint2.getLatitude()) || (localParseGeoPoint2.getLongitude() != localParseGeoPoint2.getLongitude()))
        return false;
    }
    return compare(paramObject1, paramObject2, new Decider()
    {
      public boolean decide(Object paramObject1, Object paramObject2)
      {
        return paramObject1.equals(paramObject2);
      }
    });
  }

  private static boolean matchesExistsConstraint(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 != null) && (((Boolean)paramObject1).booleanValue()))
      return (paramObject2 != null) && (paramObject2 != JSONObject.NULL);
    int i;
    if (paramObject2 != null)
    {
      Object localObject = JSONObject.NULL;
      i = 0;
      if (paramObject2 != localObject);
    }
    else
    {
      i = 1;
    }
    return i;
  }

  private static boolean matchesGreaterThanConstraint(Object paramObject1, Object paramObject2)
  {
    return compare(paramObject1, paramObject2, new Decider()
    {
      public boolean decide(Object paramObject1, Object paramObject2)
      {
        if ((paramObject2 == null) || (paramObject2 == JSONObject.NULL));
        do
          return false;
        while (OfflineQueryLogic.access$000(paramObject1, paramObject2) >= 0);
        return true;
      }
    });
  }

  private static boolean matchesGreaterThanOrEqualToConstraint(Object paramObject1, Object paramObject2)
  {
    return compare(paramObject1, paramObject2, new Decider()
    {
      public boolean decide(Object paramObject1, Object paramObject2)
      {
        if ((paramObject2 == null) || (paramObject2 == JSONObject.NULL));
        do
          return false;
        while (OfflineQueryLogic.access$000(paramObject1, paramObject2) > 0);
        return true;
      }
    });
  }

  private static boolean matchesInConstraint(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 instanceof List))
    {
      Iterator localIterator = ((List)paramObject1).iterator();
      while (localIterator.hasNext())
        if (matchesEqualConstraint(localIterator.next(), paramObject2))
          return true;
      return false;
    }
    if ((paramObject1 instanceof JSONArray))
    {
      for (int i = 0; i < ((JSONArray)paramObject1).length(); i++)
        if (matchesEqualConstraint(((JSONArray)paramObject1).opt(i), paramObject2))
          return true;
      return false;
    }
    if (paramObject1 == JSONObject.NULL)
      return false;
    if (paramObject1 == null)
      return false;
    throw new IllegalArgumentException("Constraint type not supported for $in queries.");
  }

  private static boolean matchesLessThanConstraint(Object paramObject1, Object paramObject2)
  {
    return compare(paramObject1, paramObject2, new Decider()
    {
      public boolean decide(Object paramObject1, Object paramObject2)
      {
        if ((paramObject2 == null) || (paramObject2 == JSONObject.NULL));
        do
          return false;
        while (OfflineQueryLogic.access$000(paramObject1, paramObject2) <= 0);
        return true;
      }
    });
  }

  private static boolean matchesLessThanOrEqualToConstraint(Object paramObject1, Object paramObject2)
  {
    return compare(paramObject1, paramObject2, new Decider()
    {
      public boolean decide(Object paramObject1, Object paramObject2)
      {
        if ((paramObject2 == null) || (paramObject2 == JSONObject.NULL));
        do
          return false;
        while (OfflineQueryLogic.access$000(paramObject1, paramObject2) < 0);
        return true;
      }
    });
  }

  private static boolean matchesNearSphereConstraint(Object paramObject1, Object paramObject2, Double paramDouble)
  {
    int i = 1;
    if ((paramObject2 == null) || (paramObject2 == JSONObject.NULL))
      i = 0;
    do
      return i;
    while ((paramDouble == null) || (((ParseGeoPoint)paramObject1).distanceInRadiansTo((ParseGeoPoint)paramObject2) <= paramDouble.doubleValue()));
    return false;
  }

  private static boolean matchesNotEqualConstraint(Object paramObject1, Object paramObject2)
  {
    return !matchesEqualConstraint(paramObject1, paramObject2);
  }

  private static boolean matchesNotInConstraint(Object paramObject1, Object paramObject2)
  {
    return !matchesInConstraint(paramObject1, paramObject2);
  }

  private static boolean matchesRegexConstraint(Object paramObject1, Object paramObject2, String paramString)
    throws ParseException
  {
    if ((paramObject2 == null) || (paramObject2 == JSONObject.NULL))
      return false;
    if (paramString == null)
      paramString = "";
    if (!paramString.matches("^[imxs]*$"))
      throw new ParseException(102, String.format("Invalid regex options: %s", new Object[] { paramString }));
    boolean bool = paramString.contains("i");
    int i = 0;
    if (bool)
      i = 0x0 | 0x2;
    if (paramString.contains("m"))
      i |= 8;
    if (paramString.contains("x"))
      i |= 4;
    if (paramString.contains("s"))
      i |= 32;
    return Pattern.compile((String)paramObject1, i).matcher((String)paramObject2).find();
  }

  private static boolean matchesStatelessConstraint(String paramString, Object paramObject1, Object paramObject2, ParseQuery.KeyConstraints paramKeyConstraints)
    throws ParseException
  {
    boolean bool = true;
    if (paramString.equals("$ne"))
      bool = matchesNotEqualConstraint(paramObject1, paramObject2);
    do
    {
      do
      {
        return bool;
        if (paramString.equals("$lt"))
          return matchesLessThanConstraint(paramObject1, paramObject2);
        if (paramString.equals("$lte"))
          return matchesLessThanOrEqualToConstraint(paramObject1, paramObject2);
        if (paramString.equals("$gt"))
          return matchesGreaterThanConstraint(paramObject1, paramObject2);
        if (paramString.equals("$gte"))
          return matchesGreaterThanOrEqualToConstraint(paramObject1, paramObject2);
        if (paramString.equals("$in"))
          return matchesInConstraint(paramObject1, paramObject2);
        if (paramString.equals("$nin"))
          return matchesNotInConstraint(paramObject1, paramObject2);
        if (paramString.equals("$all"))
          return matchesAllConstraint(paramObject1, paramObject2);
        if (paramString.equals("$regex"))
          return matchesRegexConstraint(paramObject1, paramObject2, (String)paramKeyConstraints.get("$options"));
      }
      while (paramString.equals("$options"));
      if (paramString.equals("$exists"))
        return matchesExistsConstraint(paramObject1, paramObject2);
      if (paramString.equals("$nearSphere"))
        return matchesNearSphereConstraint(paramObject1, paramObject2, (Double)paramKeyConstraints.get("$maxDistance"));
    }
    while (paramString.equals("$maxDistance"));
    if (paramString.equals("$within"))
      return matchesWithinConstraint(paramObject1, paramObject2);
    Object[] arrayOfObject = new Object[bool];
    arrayOfObject[0] = paramString;
    throw new UnsupportedOperationException(String.format("The offline store does not yet support the %s operator.", arrayOfObject));
  }

  private static boolean matchesWithinConstraint(Object paramObject1, Object paramObject2)
    throws ParseException
  {
    ArrayList localArrayList = (ArrayList)((HashMap)paramObject1).get("$box");
    ParseGeoPoint localParseGeoPoint1 = (ParseGeoPoint)localArrayList.get(0);
    ParseGeoPoint localParseGeoPoint2 = (ParseGeoPoint)localArrayList.get(1);
    ParseGeoPoint localParseGeoPoint3 = (ParseGeoPoint)paramObject2;
    if (localParseGeoPoint2.getLongitude() < localParseGeoPoint1.getLongitude())
      throw new ParseException(102, "whereWithinGeoBox queries cannot cross the International Date Line.");
    if (localParseGeoPoint2.getLatitude() < localParseGeoPoint1.getLatitude())
      throw new ParseException(102, "The southwest corner of a geo box must be south of the northeast corner.");
    if (localParseGeoPoint2.getLongitude() - localParseGeoPoint1.getLongitude() > 180.0D)
      throw new ParseException(102, "Geo box queries larger than 180 degrees in longitude are not supported. Please check point order.");
    return (localParseGeoPoint3.getLatitude() >= localParseGeoPoint1.getLatitude()) && (localParseGeoPoint3.getLatitude() <= localParseGeoPoint2.getLatitude()) && (localParseGeoPoint3.getLongitude() >= localParseGeoPoint1.getLongitude()) && (localParseGeoPoint3.getLongitude() <= localParseGeoPoint2.getLongitude());
  }

  <T extends ParseObject> ConstraintMatcher<T> createMatcher(ParseQuery<T> paramParseQuery, ParseUser paramParseUser)
  {
    return new ConstraintMatcher(paramParseUser, paramParseQuery.ignoreACLs, createMatcher(paramParseUser, paramParseQuery.getConstraints()))
    {
      public Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase)
      {
        if ((!this.val$ignoreACLs) && (!OfflineQueryLogic.hasReadAccess(this.user, paramT)))
          return Task.forResult(Boolean.valueOf(false));
        return this.val$constraintMatcher.matchesAsync(paramT, paramParseSQLiteDatabase);
      }
    };
  }

  <T extends ParseObject> Task<Void> fetchIncludes(T paramT, ParseQuery<T> paramParseQuery, ParseSQLiteDatabase paramParseSQLiteDatabase)
  {
    List localList = paramParseQuery.getIncludes();
    Task localTask = Task.forResult(null);
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
      localTask = localTask.onSuccessTask(new Continuation(paramT, (String)localIterator.next(), paramParseSQLiteDatabase)
      {
        public Task<Void> then(Task<Void> paramTask)
          throws Exception
        {
          return OfflineQueryLogic.this.fetchIncludeAsync(this.val$object, this.val$include, this.val$db);
        }
      });
    return localTask;
  }

  <T extends ParseObject> void sort(List<T> paramList, ParseQuery<T> paramParseQuery)
    throws ParseException
  {
    for (String str2 : paramParseQuery.sortKeys())
    {
      if ((str2.matches("^-?[A-Za-z][A-Za-z0-9_]*$")) || ("_created_at".equals(str2)) || ("_updated_at".equals(str2)))
        continue;
      throw new ParseException(105, String.format("Invalid key name: \"%s\".", new Object[] { str2 }));
    }
    Object localObject1 = null;
    ParseGeoPoint localParseGeoPoint1 = null;
    Iterator localIterator = paramParseQuery.getConstraints().keySet().iterator();
    while (localIterator.hasNext())
    {
      String str1 = (String)localIterator.next();
      Object localObject3 = paramParseQuery.getConstraints().get(str1);
      if (!(localObject3 instanceof ParseQuery.KeyConstraints))
        continue;
      ParseQuery.KeyConstraints localKeyConstraints = (ParseQuery.KeyConstraints)localObject3;
      if (!localKeyConstraints.containsKey("$nearSphere"))
        continue;
      localObject1 = str1;
      localParseGeoPoint1 = (ParseGeoPoint)localKeyConstraints.get("$nearSphere");
    }
    Object localObject2 = localObject1;
    ParseGeoPoint localParseGeoPoint2 = localParseGeoPoint1;
    if ((???.length == 0) && (localObject1 == null))
      return;
    Collections.sort(paramList, new Comparator(localObject2, localParseGeoPoint2, ???)
    {
      // ERROR //
      public int compare(T paramT1, T paramT2)
      {
        // Byte code:
        //   0: aload_0
        //   1: getfield 26	com/parse/OfflineQueryLogic$16:val$nearSphereKey	Ljava/lang/String;
        //   4: ifnull +97 -> 101
        //   7: aload_0
        //   8: getfield 24	com/parse/OfflineQueryLogic$16:this$0	Lcom/parse/OfflineQueryLogic;
        //   11: aload_1
        //   12: aload_0
        //   13: getfield 26	com/parse/OfflineQueryLogic$16:val$nearSphereKey	Ljava/lang/String;
        //   16: invokestatic 43	com/parse/OfflineQueryLogic:access$200	(Lcom/parse/OfflineQueryLogic;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
        //   19: checkcast 45	com/parse/ParseGeoPoint
        //   22: astore 19
        //   24: aload_0
        //   25: getfield 24	com/parse/OfflineQueryLogic$16:this$0	Lcom/parse/OfflineQueryLogic;
        //   28: aload_2
        //   29: aload_0
        //   30: getfield 26	com/parse/OfflineQueryLogic$16:val$nearSphereKey	Ljava/lang/String;
        //   33: invokestatic 43	com/parse/OfflineQueryLogic:access$200	(Lcom/parse/OfflineQueryLogic;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
        //   36: checkcast 45	com/parse/ParseGeoPoint
        //   39: astore 20
        //   41: aload 19
        //   43: aload_0
        //   44: getfield 28	com/parse/OfflineQueryLogic$16:val$nearSphereValue	Lcom/parse/ParseGeoPoint;
        //   47: invokevirtual 49	com/parse/ParseGeoPoint:distanceInRadiansTo	(Lcom/parse/ParseGeoPoint;)D
        //   50: dstore 21
        //   52: aload 20
        //   54: aload_0
        //   55: getfield 28	com/parse/OfflineQueryLogic$16:val$nearSphereValue	Lcom/parse/ParseGeoPoint;
        //   58: invokevirtual 49	com/parse/ParseGeoPoint:distanceInRadiansTo	(Lcom/parse/ParseGeoPoint;)D
        //   61: dstore 23
        //   63: dload 21
        //   65: dload 23
        //   67: dcmpl
        //   68: ifeq +33 -> 101
        //   71: dload 21
        //   73: dload 23
        //   75: dsub
        //   76: dconst_0
        //   77: dcmpl
        //   78: ifle +21 -> 99
        //   81: iconst_1
        //   82: ireturn
        //   83: astore 17
        //   85: new 51	java/lang/RuntimeException
        //   88: dup
        //   89: aload 17
        //   91: invokespecial 54	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
        //   94: astore 18
        //   96: aload 18
        //   98: athrow
        //   99: iconst_m1
        //   100: ireturn
        //   101: aload_0
        //   102: getfield 30	com/parse/OfflineQueryLogic$16:val$keys	[Ljava/lang/String;
        //   105: astore_3
        //   106: aload_3
        //   107: arraylength
        //   108: istore 4
        //   110: iconst_0
        //   111: istore 5
        //   113: iload 5
        //   115: iload 4
        //   117: if_icmpge +144 -> 261
        //   120: aload_3
        //   121: iload 5
        //   123: aaload
        //   124: astore 6
        //   126: aload 6
        //   128: ldc 56
        //   130: invokevirtual 62	java/lang/String:startsWith	(Ljava/lang/String;)Z
        //   133: istore 7
        //   135: iconst_0
        //   136: istore 8
        //   138: iload 7
        //   140: ifeq +14 -> 154
        //   143: iconst_1
        //   144: istore 8
        //   146: aload 6
        //   148: iconst_1
        //   149: invokevirtual 66	java/lang/String:substring	(I)Ljava/lang/String;
        //   152: astore 6
        //   154: aload_0
        //   155: getfield 24	com/parse/OfflineQueryLogic$16:this$0	Lcom/parse/OfflineQueryLogic;
        //   158: aload_1
        //   159: aload 6
        //   161: invokestatic 43	com/parse/OfflineQueryLogic:access$200	(Lcom/parse/OfflineQueryLogic;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
        //   164: astore 11
        //   166: aload_0
        //   167: getfield 24	com/parse/OfflineQueryLogic$16:this$0	Lcom/parse/OfflineQueryLogic;
        //   170: aload_2
        //   171: aload 6
        //   173: invokestatic 43	com/parse/OfflineQueryLogic:access$200	(Lcom/parse/OfflineQueryLogic;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
        //   176: astore 12
        //   178: aload 11
        //   180: aload 12
        //   182: invokestatic 70	com/parse/OfflineQueryLogic:access$000	(Ljava/lang/Object;Ljava/lang/Object;)I
        //   185: istore 15
        //   187: iload 15
        //   189: istore 16
        //   191: iload 16
        //   193: ifeq +62 -> 255
        //   196: iload 8
        //   198: ifeq +8 -> 206
        //   201: iload 16
        //   203: ineg
        //   204: istore 16
        //   206: iload 16
        //   208: ireturn
        //   209: astore 9
        //   211: new 51	java/lang/RuntimeException
        //   214: dup
        //   215: aload 9
        //   217: invokespecial 54	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
        //   220: astore 10
        //   222: aload 10
        //   224: athrow
        //   225: astore 13
        //   227: new 39	java/lang/IllegalArgumentException
        //   230: dup
        //   231: ldc 72
        //   233: iconst_1
        //   234: anewarray 5	java/lang/Object
        //   237: dup
        //   238: iconst_0
        //   239: aload 6
        //   241: aastore
        //   242: invokestatic 76	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   245: aload 13
        //   247: invokespecial 79	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
        //   250: astore 14
        //   252: aload 14
        //   254: athrow
        //   255: iinc 5 1
        //   258: goto -145 -> 113
        //   261: iconst_0
        //   262: ireturn
        //
        // Exception table:
        //   from	to	target	type
        //   7	41	83	com/parse/ParseException
        //   154	178	209	com/parse/ParseException
        //   178	187	225	java/lang/IllegalArgumentException
      }
    });
  }

  abstract class ConstraintMatcher<T extends ParseObject>
  {
    protected ParseUser user;

    public ConstraintMatcher(ParseUser arg2)
    {
      Object localObject;
      this.user = localObject;
    }

    abstract Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase);
  }

  private static abstract interface Decider
  {
    public abstract boolean decide(Object paramObject1, Object paramObject2);
  }

  private abstract class SubQueryMatcher<T extends ParseObject> extends OfflineQueryLogic.ConstraintMatcher<T>
  {
    private final ParseQuery<T> subQuery;
    private Task<List<T>> subQueryResults = null;

    public SubQueryMatcher(ParseQuery<T> arg2)
    {
      super(localParseUser);
      Object localObject;
      this.subQuery = localObject;
    }

    protected abstract boolean matches(T paramT, List<T> paramList)
      throws ParseException;

    public Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase)
    {
      if (this.subQueryResults == null)
        this.subQueryResults = OfflineQueryLogic.this.store.findAsync(this.subQuery, this.user, null, paramParseSQLiteDatabase);
      return this.subQueryResults.onSuccess(new Continuation(paramT)
      {
        public Boolean then(Task<List<T>> paramTask)
          throws ParseException
        {
          return Boolean.valueOf(OfflineQueryLogic.SubQueryMatcher.this.matches(this.val$object, (List)paramTask.getResult()));
        }
      });
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.OfflineQueryLogic
 * JD-Core Version:    0.6.0
 */