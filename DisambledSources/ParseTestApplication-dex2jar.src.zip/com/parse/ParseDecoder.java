package com.parse;

import com.parse.codec.binary.Base64;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class ParseDecoder
{
  List<Object> convertJSONArrayToList(JSONArray paramJSONArray)
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < paramJSONArray.length(); i++)
      localArrayList.add(decode(paramJSONArray.opt(i)));
    return localArrayList;
  }

  Map<String, Object> convertJSONObjectToMap(JSONObject paramJSONObject)
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator = paramJSONObject.keys();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localHashMap.put(str, decode(paramJSONObject.opt(str)));
    }
    return localHashMap;
  }

  public Object decode(Object paramObject)
  {
    if ((paramObject instanceof JSONArray))
      paramObject = convertJSONArrayToList((JSONArray)paramObject);
    do
      return paramObject;
    while (!(paramObject instanceof JSONObject));
    JSONObject localJSONObject = (JSONObject)paramObject;
    if (localJSONObject.optString("__op", null) != null)
      try
      {
        ParseFieldOperation localParseFieldOperation = ParseFieldOperations.decode(localJSONObject, this);
        return localParseFieldOperation;
      }
      catch (JSONException localJSONException2)
      {
        throw new RuntimeException(localJSONException2);
      }
    String str = localJSONObject.optString("__type", null);
    if (str == null)
      return convertJSONObjectToMap(localJSONObject);
    if (str.equals("Date"))
      return Parse.stringToDate(localJSONObject.optString("iso"));
    if (str.equals("Bytes"))
      return Base64.decodeBase64(localJSONObject.optString("base64"));
    if (str.equals("Pointer"))
      return decodePointer(localJSONObject.optString("className"), localJSONObject.optString("objectId"));
    if (str.equals("File"))
    {
      ParseFile localParseFile = new ParseFile(localJSONObject, this);
      return localParseFile;
    }
    if (str.equals("GeoPoint"))
      try
      {
        double d1 = localJSONObject.getDouble("latitude");
        double d2 = localJSONObject.getDouble("longitude");
        ParseGeoPoint localParseGeoPoint = new ParseGeoPoint(d1, d2);
        return localParseGeoPoint;
      }
      catch (JSONException localJSONException1)
      {
        throw new RuntimeException(localJSONException1);
      }
    if (str.equals("Object"))
    {
      ParseObject localParseObject = ParseObject.createWithoutData(localJSONObject.optString("className", null), localJSONObject.optString("objectId", null));
      localParseObject.mergeAfterFetch(localJSONObject, this, true);
      return localParseObject;
    }
    if (str.equals("Relation"))
    {
      ParseRelation localParseRelation = new ParseRelation(localJSONObject, this);
      return localParseRelation;
    }
    if (str.equals("OfflineObject"))
      throw new RuntimeException("An unexpected offline pointer was encountered.");
    return null;
  }

  protected ParseObject decodePointer(String paramString1, String paramString2)
  {
    return ParseObject.createWithoutData(paramString1, paramString2);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ParseDecoder
 * JD-Core Version:    0.6.0
 */