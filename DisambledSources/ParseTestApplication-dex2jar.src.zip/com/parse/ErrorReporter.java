package com.parse;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.Process;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.text.format.Time;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class ErrorReporter
  implements Thread.UncaughtExceptionHandler
{
  public static final String ACRA_DIRNAME = "cr/reports";
  private static final CrashReportType[] ALL_REPORT_TYPES;
  private static final String ANDROID_RUNTIME_ART = "ART";
  private static final String ANDROID_RUNTIME_DALVIK = "DALVIK";
  private static final String ANDROID_RUNTIME_UNKNOWN = "UNKNOWN";
  public static final String CRASH_ATTACHMENT_DUMMY_STACKTRACE = "crash attachment";
  public static final long DEFAULT_MAX_REPORT_SIZE = 51200L;
  private static int DEFAULT_TRACE_COUNT_LIMIT = 0;
  public static final String DUMPFILE_EXTENSION = ".dmp";
  public static final String DUMP_DIR = "cr/minidumps";
  private static final String IS_PROCESSING_ANOTHER_EXCEPTION = "IS_PROCESSING_ANOTHER_EXCEPTION";
  private static final String JAVA_BOOT_CLASS_PATH = "java.boot.class.path";
  private static final String KNOWN_ART_JAR = "/system/framework/core-libart.jar";
  private static final String KNOWN_DALVIK_JAR = "/system/framework/core.jar";
  public static final long MAX_REPORT_AGE = 86400000L;
  public static final int MAX_SEND_REPORTS = 5;
  private static int MAX_TRACE_COUNT_LIMIT = 0;
  private static final long MIN_TEMP_REPORT_AGE = 600000L;
  public static final long NATIVE_MAX_REPORT_SIZE = 512000L;
  public static final long PREALLOCATED_FILESIZE = 51200L;
  public static final String PREALLOCATED_REPORTFILE = "reportfile.prealloc";
  public static final String REPORTFILE_EXTENSION = ".stacktrace";
  public static final String SIGQUIT_DIR = "traces";
  public static final long SIGQUIT_MAX_REPORT_SIZE = 122880L;
  public static final String TEMP_REPORTFILE_EXTENSION = ".temp_stacktrace";
  private static final Pattern VERSION_CODE_REGEX = Pattern.compile("^\\d+-[a-zA-Z0-9_\\-]+-(\\d+)\\.(temp_stacktrace|stacktrace)$");
  private static ErrorReporter mInstanceSingleton;
  private static final String mInternalException = "ACRA_INTERNAL=java.lang.Exception: An exception occurred while trying to collect data about an ACRA internal error\n\tat com.parse.acra.ErrorReporter.handleException(ErrorReporter.java:810)\n\tat com.parse.acra.ErrorReporter.handleException(ErrorReporter.java:866)\n\tat com.parse.acra.ErrorReporter.uncaughtException(ErrorReporter.java:666)\n\tat java.lang.ThreadGroup.uncaughtException(ThreadGroup.java:693)\n\tat java.lang.ThreadGroup.uncaughtException(ThreadGroup.java:690)\n";
  private static AtomicBoolean mProcessingCrash;
  private final SimpleTraceLogger activityLogger = new SimpleTraceLogger(MAX_TRACE_COUNT_LIMIT);
  private final Time mAppStartDate = new Time();
  private String mAppVersionCode;
  private String mAppVersionName;
  private final Map<ReportField, String> mConstantFields = new HashMap();
  private Context mContext;
  private boolean mCurrentlyProcessingOOM = false;
  private final Map<ReportField, String> mDeviceSpecificFields = new HashMap();
  private Thread.UncaughtExceptionHandler mDfltExceptionHandler;
  private FileProvider mFileProvider;
  private boolean mHasNativeCrashDumpOnInit = false;
  Map<String, String> mInstanceCustomParameters = new ConcurrentHashMap();
  Map<String, CustomReportDataSupplier> mInstanceLazyCustomParameters = new ConcurrentHashMap();
  private boolean mIsInternalBuild;
  private LogBridge mLogBridge;
  private long mMaxReportSize = 51200L;
  private PackageManagerWrapper mPackageManager;
  private ArrayList<ReportSender> mReportSenders = new ArrayList();
  private final Object mShouldContinueProcessingExceptionLock = new Object();
  private volatile String mUserId;
  private File preallocFile = null;
  private String processNameByAms;
  private boolean processNameByAmsReady;
  private volatile boolean sendInMemoryReport = false;
  private boolean usePreallocatedFile = false;

  static
  {
    CrashReportType[] arrayOfCrashReportType = new CrashReportType[3];
    arrayOfCrashReportType[0] = CrashReportType.ACRA_CRASH_REPORT;
    arrayOfCrashReportType[1] = CrashReportType.NATIVE_CRASH_REPORT;
    arrayOfCrashReportType[2] = CrashReportType.ANR_REPORT;
    ALL_REPORT_TYPES = arrayOfCrashReportType;
    DEFAULT_TRACE_COUNT_LIMIT = 5;
    MAX_TRACE_COUNT_LIMIT = 20;
    mProcessingCrash = new AtomicBoolean(false);
  }

  private void checkAndSendAcraReports(Context paramContext)
  {
    String[] arrayOfString = getCrashReportFilesList("cr/reports", new String[] { ".stacktrace", ".temp_stacktrace" });
    Arrays.sort(arrayOfString);
    int i = 0;
    String str1 = getProcessNameFromAms();
    int j = arrayOfString.length;
    int k = 0;
    String str2;
    if (k < j)
    {
      str2 = arrayOfString[k];
      if (i >= 5)
        deleteFile("cr/reports", str2);
    }
    while (true)
    {
      k++;
      break;
      Log.d("CrashReporting", "Loading file " + str2);
      try
      {
        CrashReportData localCrashReportData = loadAcraCrashReport(paramContext, str2);
        if (localCrashReportData != null)
        {
          localCrashReportData.put(ReportField.ACRA_REPORT_FILENAME, str2);
          localCrashReportData.put(ReportField.UPLOADED_BY_PROCESS, str1);
          Log.i("CrashReporting", "Sending file " + str2);
          sendCrashReport(localCrashReportData);
          deleteFile("cr/reports", str2);
        }
        i++;
      }
      catch (RuntimeException localRuntimeException)
      {
        Log.e("CrashReporting", "Failed to send crash reports", localRuntimeException);
        deleteFile("cr/reports", str2);
        return;
      }
      catch (IOException localIOException)
      {
        Log.e("CrashReporting", "Failed to load crash report for " + str2, localIOException);
        deleteFile("cr/reports", str2);
        return;
      }
      catch (ReportSenderException localReportSenderException)
      {
        Log.e("CrashReporting", "Failed to send crash report for " + str2, localReportSenderException);
      }
    }
  }

  private int checkAndSendCrashAttachments(Context paramContext, CrashReportType paramCrashReportType)
  {
    Log.d("CrashReporting", "#checkAndSendCrashAttachments - start");
    String[] arrayOfString = getCrashReportFilesList(paramCrashReportType.directory, paramCrashReportType.fileExtensions);
    int i = 0;
    CrashReportData localCrashReportData1;
    if (arrayOfString != null)
    {
      int j = arrayOfString.length;
      i = 0;
      if (j > 0)
      {
        Arrays.sort(arrayOfString);
        localCrashReportData1 = new CrashReportData();
      }
    }
    while (true)
    {
      try
      {
        gatherCrashData("crash attachment", new CrashAttachmentException(null), ACRA.ALL_CRASH_REPORT_FIELDS, localCrashReportData1, null, null);
        int k = arrayOfString.length;
        int m = 0;
        String str2;
        String str1;
        if (m < k)
        {
          str2 = arrayOfString[m];
          if (i >= 5)
          {
            deleteFile("cr/minidumps", str2);
            m++;
            continue;
          }
        }
      }
      catch (Exception localException)
      {
        str1 = "retrieve exception: " + localException.getMessage();
        put(ReportField.REPORT_LOAD_THROW, str1, localCrashReportData1, null);
        continue;
      }
      try
      {
        CrashReportData localCrashReportData2 = loadCrashAttachment(paramContext, str2, paramCrashReportType);
        String str3 = "load failed";
        if (localCrashReportData2 != null)
          str3 = (String)localCrashReportData2.get(paramCrashReportType.attachmentField);
        localCrashReportData1.put(ReportField.REPORT_ID, str2.substring(0, str2.lastIndexOf('.')), null);
        localCrashReportData1.put(paramCrashReportType.attachmentField, str3, null);
        localCrashReportData1.put(ReportField.EXCEPTION_CAUSE, "crash attachment", null);
        sendCrashReport(localCrashReportData1);
        deleteFile(paramCrashReportType.directory, str2);
        i++;
      }
      catch (ReportSenderException localReportSenderException)
      {
        Log.e("CrashReporting", "Failed to send crash attachment report " + str2, localReportSenderException);
        Log.d("CrashReporting", "#checkAndSendCrashAttachments - finish, sent: " + Integer.toString(i));
        return i;
      }
      catch (Throwable localThrowable)
      {
        while (true)
        {
          Log.e("CrashReporting", "Failed on crash attachment file " + str2, localThrowable);
          deleteFile(paramCrashReportType.directory, str2);
        }
      }
    }
  }

  // ERROR //
  private void createPreallocatedReportFile()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: getfield 195	com/parse/ErrorReporter:preallocFile	Ljava/io/File;
    //   6: invokevirtual 393	java/io/File:exists	()Z
    //   9: istore 7
    //   11: aconst_null
    //   12: astore_1
    //   13: iload 7
    //   15: ifne +61 -> 76
    //   18: sipush 10240
    //   21: newarray byte
    //   23: astore 8
    //   25: new 395	java/io/FileOutputStream
    //   28: dup
    //   29: aload_0
    //   30: getfield 195	com/parse/ErrorReporter:preallocFile	Ljava/io/File;
    //   33: invokespecial 398	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   36: astore 9
    //   38: iconst_0
    //   39: istore 10
    //   41: iload 10
    //   43: i2l
    //   44: ldc2_w 27
    //   47: lcmp
    //   48: ifge +25 -> 73
    //   51: aload 9
    //   53: aload 8
    //   55: invokevirtual 402	java/io/FileOutputStream:write	([B)V
    //   58: aload 8
    //   60: arraylength
    //   61: istore 12
    //   63: iload 10
    //   65: iload 12
    //   67: iadd
    //   68: istore 10
    //   70: goto -29 -> 41
    //   73: aload 9
    //   75: astore_1
    //   76: aload_1
    //   77: ifnull +7 -> 84
    //   80: aload_1
    //   81: invokevirtual 405	java/io/FileOutputStream:close	()V
    //   84: return
    //   85: astore 4
    //   87: ldc 245
    //   89: ldc_w 407
    //   92: aload 4
    //   94: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   97: pop
    //   98: aload_1
    //   99: ifnull -15 -> 84
    //   102: aload_1
    //   103: invokevirtual 405	java/io/FileOutputStream:close	()V
    //   106: return
    //   107: astore 6
    //   109: return
    //   110: astore_2
    //   111: aload_1
    //   112: ifnull +7 -> 119
    //   115: aload_1
    //   116: invokevirtual 405	java/io/FileOutputStream:close	()V
    //   119: aload_2
    //   120: athrow
    //   121: astore 11
    //   123: return
    //   124: astore_3
    //   125: goto -6 -> 119
    //   128: astore_2
    //   129: aload 9
    //   131: astore_1
    //   132: goto -21 -> 111
    //   135: astore 4
    //   137: aload 9
    //   139: astore_1
    //   140: goto -53 -> 87
    //
    // Exception table:
    //   from	to	target	type
    //   2	11	85	java/io/IOException
    //   18	38	85	java/io/IOException
    //   102	106	107	java/io/IOException
    //   2	11	110	finally
    //   18	38	110	finally
    //   87	98	110	finally
    //   80	84	121	java/io/IOException
    //   115	119	124	java/io/IOException
    //   51	63	128	finally
    //   51	63	135	java/io/IOException
  }

  private void deleteFile(String paramString1, String paramString2)
  {
    if (!fileForName(this.mFileProvider, paramString1, paramString2).delete())
      Log.w("CrashReporting", "Could not delete error report : " + paramString2);
  }

  private void dumpCustomDataEntry(StringBuilder paramStringBuilder, String paramString1, String paramString2)
  {
    String str1;
    if (paramString1 != null)
    {
      str1 = paramString1.replace("\n", "\\n");
      if (paramString2 == null)
        break label63;
    }
    label63: for (String str2 = paramString2.replace("\n", "\\n"); ; str2 = null)
    {
      paramStringBuilder.append(str1).append(" = ").append(str2).append("\n");
      return;
      str1 = null;
      break;
    }
  }

  private void dumpCustomDataMap(StringBuilder paramStringBuilder, Map<String, String> paramMap)
  {
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      dumpCustomDataEntry(paramStringBuilder, (String)localEntry.getKey(), (String)localEntry.getValue());
    }
  }

  private void dumpLazyCustomDataMap(StringBuilder paramStringBuilder, Map<String, CustomReportDataSupplier> paramMap, Throwable paramThrowable)
  {
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str1 = (String)localEntry.getKey();
      try
      {
        String str2 = ((CustomReportDataSupplier)localEntry.getValue()).getCustomData(paramThrowable);
        if (str2 == null)
          continue;
        dumpCustomDataEntry(paramStringBuilder, str1, str2);
      }
      catch (Throwable localThrowable)
      {
        Log.e("CrashReporting", "Caught throwable while getting custom report data", localThrowable);
      }
    }
  }

  private static File fileForName(FileProvider paramFileProvider, String paramString1, String paramString2)
  {
    return new File(paramFileProvider.getFile(paramString1), paramString2);
  }

  private String formatTimestamp(long paramLong)
  {
    Time localTime = new Time();
    localTime.set(paramLong);
    return localTime.format3339(false);
  }

  private void gatherCrashData(String paramString, Throwable paramThrowable, ReportField[] paramArrayOfReportField, CrashReportData paramCrashReportData, Writer paramWriter, Map<String, String> paramMap)
    throws Exception
  {
    if (paramArrayOfReportField == null)
      paramArrayOfReportField = ACRA.MINIMAL_REPORT_FIELDS;
    put(ReportField.UID, getUserId(), paramCrashReportData, paramWriter);
    put(ReportField.STACK_TRACE, paramString, paramCrashReportData, paramWriter);
    Iterator localIterator = this.mConstantFields.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      put((ReportField)localEntry.getKey(), (String)localEntry.getValue(), paramCrashReportData, paramWriter);
    }
    retrieveCrashTimeData(this.mContext, paramThrowable, paramArrayOfReportField, paramCrashReportData, paramWriter);
    populateConstantDeviceData(paramCrashReportData, paramWriter);
    put(ReportField.CUSTOM_DATA, dumpCustomDataToString(paramMap, paramThrowable), paramCrashReportData, paramWriter);
  }

  private String genCrashReportFileName(Class paramClass, String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder().append(Long.toString(System.currentTimeMillis())).append("-").append(paramClass.getSimpleName());
    if (this.mAppVersionCode != null);
    for (String str = "-" + this.mAppVersionCode; ; str = "")
      return str + paramString;
  }

  private String getAndroidRuntime()
  {
    if (Build.VERSION.SDK_INT < 19)
      return "DALVIK";
    String str = System.getProperty("java.boot.class.path");
    if (str != null)
    {
      if (str.contains("/system/framework/core-libart.jar"))
        return "ART";
      if (str.contains("/system/framework/core.jar"))
        return "DALVIK";
    }
    return "UNKNOWN";
  }

  private static long getAvailableInternalMemorySize()
  {
    try
    {
      StatFs localStatFs = new StatFs(Environment.getDataDirectory().getPath());
      long l = localStatFs.getBlockSize();
      int i = localStatFs.getAvailableBlocks();
      return l * i;
    }
    catch (Exception localException)
    {
    }
    return -1L;
  }

  private Map<ReportField, String> getConstantDeviceData()
  {
    synchronized (this.mDeviceSpecificFields)
    {
      if (this.mDeviceSpecificFields.isEmpty())
      {
        this.mDeviceSpecificFields.put(ReportField.BUILD, ReflectionCollector.collectConstants(Build.class));
        this.mDeviceSpecificFields.put(ReportField.JAIL_BROKEN, getJailStatus());
        this.mDeviceSpecificFields.put(ReportField.INSTALLATION_ID, Installation.id(this.mFileProvider));
        this.mDeviceSpecificFields.put(ReportField.TOTAL_MEM_SIZE, Long.toString(getTotalInternalMemorySize()));
        if (this.mPackageManager.hasPermission("android.permission.READ_PHONE_STATE"))
        {
          String str = ((TelephonyManager)this.mContext.getSystemService("phone")).getDeviceId();
          if (str != null)
            this.mDeviceSpecificFields.put(ReportField.DEVICE_ID, str);
        }
        Display localDisplay = ((WindowManager)this.mContext.getSystemService("window")).getDefaultDisplay();
        this.mDeviceSpecificFields.put(ReportField.DISPLAY, toString(localDisplay));
        this.mDeviceSpecificFields.put(ReportField.ENVIRONMENT, ReflectionCollector.collectStaticGettersResults(Environment.class));
        this.mDeviceSpecificFields.put(ReportField.DEVICE_FEATURES, DeviceFeaturesCollector.getFeatures(this.mContext));
        this.mDeviceSpecificFields.put(ReportField.SETTINGS_SYSTEM, SettingsCollector.collectSystemSettings(this.mContext));
        this.mDeviceSpecificFields.put(ReportField.SETTINGS_SECURE, SettingsCollector.collectSecureSettings(this.mContext));
        if (Build.VERSION.SDK_INT >= 19)
        {
          ActivityManager localActivityManager = (ActivityManager)this.mContext.getSystemService("activity");
          this.mDeviceSpecificFields.put(ReportField.IS_LOW_RAM_DEVICE, Boolean.toString(localActivityManager.isLowRamDevice()));
        }
        this.mDeviceSpecificFields.put(ReportField.ANDROID_RUNTIME, getAndroidRuntime());
      }
      Map localMap2 = this.mDeviceSpecificFields;
      return localMap2;
    }
  }

  private long getDeviceUptime()
  {
    return SystemClock.elapsedRealtime();
  }

  public static ErrorReporter getInstance()
  {
    if (mInstanceSingleton == null)
      mInstanceSingleton = new ErrorReporter();
    return mInstanceSingleton;
  }

  private String getJailStatus()
  {
    String str1 = Build.TAGS;
    if ((str1 != null) && (str1.contains("test-keys")))
      return "yes";
    try
    {
      if (new File("/system/app/Superuser.apk").exists())
        return "yes";
    }
    catch (Exception localException1)
    {
      Log.e("CrashReporting", "Failed to find Superuser.pak", localException1);
      Map localMap = System.getenv();
      if (localMap != null)
      {
        String[] arrayOfString = ((String)localMap.get("PATH")).split(":");
        int i = arrayOfString.length;
        int j = 0;
        while (j < i)
        {
          String str2 = arrayOfString[j];
          String str3 = str2 + "/" + "su";
          try
          {
            File localFile = new File(str3);
            if ((localFile != null) && (localFile.exists()))
              return "yes";
          }
          catch (Exception localException2)
          {
            Log.e("CrashReporting", "Failed to find su binary in the PATH", localException2);
            j++;
          }
        }
      }
    }
    return "no";
  }

  // ERROR //
  private String getProcessName()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 758	com/parse/ErrorReporter:getProcessNameFromAmsOrNull	()Ljava/lang/String;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnonnull +54 -> 60
    //   9: aconst_null
    //   10: astore_2
    //   11: new 760	java/io/BufferedReader
    //   14: dup
    //   15: new 762	java/io/FileReader
    //   18: dup
    //   19: ldc_w 764
    //   22: invokespecial 765	java/io/FileReader:<init>	(Ljava/lang/String;)V
    //   25: sipush 128
    //   28: invokespecial 768	java/io/BufferedReader:<init>	(Ljava/io/Reader;I)V
    //   31: astore_3
    //   32: aload_3
    //   33: invokevirtual 771	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   36: astore_1
    //   37: aload_1
    //   38: ifnull +12 -> 50
    //   41: aload_1
    //   42: invokevirtual 774	java/lang/String:trim	()Ljava/lang/String;
    //   45: astore 8
    //   47: aload 8
    //   49: astore_1
    //   50: aload_3
    //   51: astore_2
    //   52: aload_2
    //   53: ifnull +7 -> 60
    //   56: aload_2
    //   57: invokevirtual 775	java/io/BufferedReader:close	()V
    //   60: aload_1
    //   61: ifnonnull +7 -> 68
    //   64: ldc_w 545
    //   67: astore_1
    //   68: aload_1
    //   69: areturn
    //   70: astore 4
    //   72: ldc 245
    //   74: ldc_w 777
    //   77: aload 4
    //   79: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   82: pop
    //   83: goto -31 -> 52
    //   86: astore 6
    //   88: ldc 245
    //   90: ldc_w 779
    //   93: aload 6
    //   95: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   98: pop
    //   99: goto -39 -> 60
    //   102: astore 4
    //   104: aload_3
    //   105: astore_2
    //   106: goto -34 -> 72
    //
    // Exception table:
    //   from	to	target	type
    //   11	32	70	java/io/IOException
    //   56	60	86	java/io/IOException
    //   32	37	102	java/io/IOException
    //   41	47	102	java/io/IOException
  }

  private String getProcessNameFromAms()
  {
    String str = getProcessNameFromAmsOrNull();
    if (str == null)
      str = "n/a";
    return str;
  }

  private String getProcessNameFromAmsOrNull()
  {
    if (this.processNameByAmsReady)
      return this.processNameByAms;
    this.processNameByAms = null;
    int i = Process.myPid();
    ActivityManager localActivityManager = (ActivityManager)this.mContext.getSystemService("activity");
    if (localActivityManager == null)
      return this.processNameByAms;
    List localList = localActivityManager.getRunningAppProcesses();
    if (localList == null)
      return this.processNameByAms;
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      ActivityManager.RunningAppProcessInfo localRunningAppProcessInfo = (ActivityManager.RunningAppProcessInfo)localIterator.next();
      if (localRunningAppProcessInfo.pid != i)
        continue;
      this.processNameByAms = localRunningAppProcessInfo.processName;
    }
    this.processNameByAmsReady = true;
    return this.processNameByAms;
  }

  private long getProcessUptime()
  {
    return Process.getElapsedCpuTime();
  }

  private ReportField[] getReportFieldsForException(Throwable paramThrowable)
  {
    if ((paramThrowable instanceof OutOfMemoryError))
      return ACRA.MINIMAL_REPORT_FIELDS;
    return ACRA.ALL_CRASH_REPORT_FIELDS;
  }

  private static long getTotalInternalMemorySize()
  {
    try
    {
      StatFs localStatFs = new StatFs(Environment.getDataDirectory().getPath());
      long l = localStatFs.getBlockSize();
      int i = localStatFs.getBlockCount();
      return l * i;
    }
    catch (Exception localException)
    {
    }
    return -1L;
  }

  // ERROR //
  private ReportsSenderWorker handleExceptionInternal(Throwable paramThrowable, Map<String, String> paramMap, String paramString, ReportField[] paramArrayOfReportField, boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual 822	com/parse/ErrorReporter:getMostSignificantCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    //   5: astore 6
    //   7: aload 6
    //   9: invokevirtual 826	java/lang/Object:getClass	()Ljava/lang/Class;
    //   12: astore 7
    //   14: aload_0
    //   15: aload 6
    //   17: invokespecial 830	com/parse/ErrorReporter:shouldContinueProcessingException	(Ljava/lang/Throwable;)Z
    //   20: ifne +5 -> 25
    //   23: aconst_null
    //   24: areturn
    //   25: new 275	com/parse/CrashReportData
    //   28: dup
    //   29: invokespecial 318	com/parse/CrashReportData:<init>	()V
    //   32: astore 8
    //   34: aload_1
    //   35: instanceof 832
    //   38: ifeq +304 -> 342
    //   41: aload_1
    //   42: checkcast 832	com/parse/NonCrashException
    //   45: invokeinterface 835 1 0
    //   50: astore 9
    //   52: aload_0
    //   53: ldc 245
    //   55: new 247	java/lang/StringBuilder
    //   58: dup
    //   59: invokespecial 248	java/lang/StringBuilder:<init>	()V
    //   62: ldc_w 837
    //   65: invokevirtual 254	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: aload 9
    //   70: invokevirtual 254	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   73: invokevirtual 257	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   76: aload_1
    //   77: aload_3
    //   78: invokespecial 841	com/parse/ErrorReporter:writeToLogBridge	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    //   81: ldc 245
    //   83: new 247	java/lang/StringBuilder
    //   86: dup
    //   87: invokespecial 248	java/lang/StringBuilder:<init>	()V
    //   90: ldc_w 843
    //   93: invokevirtual 254	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: aload 9
    //   98: invokevirtual 254	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   101: invokevirtual 257	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   104: invokestatic 263	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   107: pop
    //   108: aload_0
    //   109: aload 7
    //   111: ldc 76
    //   113: invokespecial 845	com/parse/ErrorReporter:genCrashReportFileName	(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/String;
    //   116: astore 11
    //   118: aload_0
    //   119: getfield 409	com/parse/ErrorReporter:mFileProvider	Lcom/parse/FileProvider;
    //   122: ldc 10
    //   124: aload 11
    //   126: invokestatic 413	com/parse/ErrorReporter:fileForName	(Lcom/parse/FileProvider;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    //   129: astore 12
    //   131: aload_0
    //   132: aload 7
    //   134: ldc 67
    //   136: invokespecial 845	com/parse/ErrorReporter:genCrashReportFileName	(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/String;
    //   139: astore 13
    //   141: aload_0
    //   142: getfield 409	com/parse/ErrorReporter:mFileProvider	Lcom/parse/FileProvider;
    //   145: ldc 10
    //   147: aload 13
    //   149: invokestatic 413	com/parse/ErrorReporter:fileForName	(Lcom/parse/FileProvider;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    //   152: astore 14
    //   154: aconst_null
    //   155: astore 15
    //   157: aload_0
    //   158: getfield 211	com/parse/ErrorReporter:usePreallocatedFile	Z
    //   161: ifeq +13 -> 174
    //   164: aload_0
    //   165: getfield 195	com/parse/ErrorReporter:preallocFile	Ljava/io/File;
    //   168: aload 12
    //   170: invokevirtual 849	java/io/File:renameTo	(Ljava/io/File;)Z
    //   173: pop
    //   174: new 851	java/io/RandomAccessFile
    //   177: dup
    //   178: aload 12
    //   180: ldc_w 853
    //   183: invokespecial 854	java/io/RandomAccessFile:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   186: astore 47
    //   188: new 395	java/io/FileOutputStream
    //   191: dup
    //   192: aload 47
    //   194: invokevirtual 858	java/io/RandomAccessFile:getFD	()Ljava/io/FileDescriptor;
    //   197: invokespecial 861	java/io/FileOutputStream:<init>	(Ljava/io/FileDescriptor;)V
    //   200: invokestatic 865	com/parse/CrashReportData:getWriter	(Ljava/io/OutputStream;)Ljava/io/Writer;
    //   203: astore 48
    //   205: aload 48
    //   207: astore 18
    //   209: aload 47
    //   211: astore 15
    //   213: aload_0
    //   214: getstatic 273	com/parse/ReportField:ACRA_REPORT_FILENAME	Lcom/parse/ReportField;
    //   217: aload 13
    //   219: aload 8
    //   221: aload 18
    //   223: invokespecial 344	com/parse/ErrorReporter:put	(Lcom/parse/ReportField;Ljava/lang/String;Lcom/parse/CrashReportData;Ljava/io/Writer;)V
    //   226: aload_0
    //   227: getstatic 375	com/parse/ReportField:EXCEPTION_CAUSE	Lcom/parse/ReportField;
    //   230: aload 7
    //   232: invokevirtual 868	java/lang/Class:getName	()Ljava/lang/String;
    //   235: aload 8
    //   237: aload 18
    //   239: invokespecial 344	com/parse/ErrorReporter:put	(Lcom/parse/ReportField;Ljava/lang/String;Lcom/parse/CrashReportData;Ljava/io/Writer;)V
    //   242: aload_3
    //   243: ifnonnull +9 -> 252
    //   246: aload_0
    //   247: aload_1
    //   248: invokespecial 871	com/parse/ErrorReporter:throwableToString	(Ljava/lang/Throwable;)Ljava/lang/String;
    //   251: astore_3
    //   252: aload_0
    //   253: aload_3
    //   254: aload_1
    //   255: aload 4
    //   257: aload 8
    //   259: aload 18
    //   261: aload_2
    //   262: invokespecial 333	com/parse/ErrorReporter:gatherCrashData	(Ljava/lang/String;Ljava/lang/Throwable;[Lcom/parse/ReportField;Lcom/parse/CrashReportData;Ljava/io/Writer;Ljava/util/Map;)V
    //   265: aload 15
    //   267: ifnull +34 -> 301
    //   270: aload 15
    //   272: invokevirtual 875	java/io/RandomAccessFile:getChannel	()Ljava/nio/channels/FileChannel;
    //   275: astore 44
    //   277: aload 44
    //   279: aload 44
    //   281: invokevirtual 880	java/nio/channels/FileChannel:position	()J
    //   284: invokevirtual 884	java/nio/channels/FileChannel:truncate	(J)Ljava/nio/channels/FileChannel;
    //   287: pop
    //   288: aload 15
    //   290: invokevirtual 885	java/io/RandomAccessFile:close	()V
    //   293: aload 12
    //   295: aload 14
    //   297: invokevirtual 849	java/io/File:renameTo	(Ljava/io/File;)Z
    //   300: pop
    //   301: iload 5
    //   303: ifeq +324 -> 627
    //   306: aload_0
    //   307: getfield 204	com/parse/ErrorReporter:sendInMemoryReport	Z
    //   310: ifeq +289 -> 599
    //   313: new 887	com/parse/ErrorReporter$ReportsSenderWorker
    //   316: dup
    //   317: aload_0
    //   318: aload 8
    //   320: invokespecial 890	com/parse/ErrorReporter$ReportsSenderWorker:<init>	(Lcom/parse/ErrorReporter;Lcom/parse/CrashReportData;)V
    //   323: astore 34
    //   325: ldc 245
    //   327: ldc_w 892
    //   330: invokestatic 895	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   333: pop
    //   334: aload 34
    //   336: invokevirtual 898	com/parse/ErrorReporter$ReportsSenderWorker:start	()V
    //   339: aload 34
    //   341: areturn
    //   342: ldc_w 900
    //   345: astore 9
    //   347: goto -295 -> 52
    //   350: astore 16
    //   352: ldc 245
    //   354: ldc_w 902
    //   357: aload 16
    //   359: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   362: pop
    //   363: aload_0
    //   364: iconst_1
    //   365: putfield 204	com/parse/ErrorReporter:sendInMemoryReport	Z
    //   368: aconst_null
    //   369: astore 18
    //   371: goto -158 -> 213
    //   374: astore 42
    //   376: ldc 245
    //   378: ldc_w 904
    //   381: aload 42
    //   383: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   386: pop
    //   387: goto -86 -> 301
    //   390: astore 25
    //   392: ldc 245
    //   394: ldc_w 906
    //   397: aload 25
    //   399: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   402: pop
    //   403: aload_0
    //   404: getstatic 909	com/parse/ReportField:ACRA_INTERNAL	Lcom/parse/ReportField;
    //   407: aload_0
    //   408: aload 25
    //   410: invokespecial 871	com/parse/ErrorReporter:throwableToString	(Ljava/lang/Throwable;)Ljava/lang/String;
    //   413: aload 8
    //   415: aload 18
    //   417: invokespecial 344	com/parse/ErrorReporter:put	(Lcom/parse/ReportField;Ljava/lang/String;Lcom/parse/CrashReportData;Ljava/io/Writer;)V
    //   420: ldc 245
    //   422: ldc_w 906
    //   425: aload 25
    //   427: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   430: pop
    //   431: aload 15
    //   433: ifnull -132 -> 301
    //   436: aload 15
    //   438: invokevirtual 875	java/io/RandomAccessFile:getChannel	()Ljava/nio/channels/FileChannel;
    //   441: astore 37
    //   443: aload 37
    //   445: aload 37
    //   447: invokevirtual 880	java/nio/channels/FileChannel:position	()J
    //   450: invokevirtual 884	java/nio/channels/FileChannel:truncate	(J)Ljava/nio/channels/FileChannel;
    //   453: pop
    //   454: aload 15
    //   456: invokevirtual 885	java/io/RandomAccessFile:close	()V
    //   459: aload 12
    //   461: aload 14
    //   463: invokevirtual 849	java/io/File:renameTo	(Ljava/io/File;)Z
    //   466: pop
    //   467: goto -166 -> 301
    //   470: astore 31
    //   472: ldc 245
    //   474: ldc_w 904
    //   477: aload 31
    //   479: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   482: pop
    //   483: goto -182 -> 301
    //   486: astore 28
    //   488: ldc 245
    //   490: ldc_w 911
    //   493: aload 28
    //   495: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   498: pop
    //   499: aload_0
    //   500: getstatic 909	com/parse/ReportField:ACRA_INTERNAL	Lcom/parse/ReportField;
    //   503: ldc 83
    //   505: aload 8
    //   507: aload 18
    //   509: invokespecial 344	com/parse/ErrorReporter:put	(Lcom/parse/ReportField;Ljava/lang/String;Lcom/parse/CrashReportData;Ljava/io/Writer;)V
    //   512: ldc 245
    //   514: ldc_w 906
    //   517: aload 25
    //   519: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   522: pop
    //   523: goto -92 -> 431
    //   526: astore 19
    //   528: aload 15
    //   530: ifnull +34 -> 564
    //   533: aload 15
    //   535: invokevirtual 875	java/io/RandomAccessFile:getChannel	()Ljava/nio/channels/FileChannel;
    //   538: astore 22
    //   540: aload 22
    //   542: aload 22
    //   544: invokevirtual 880	java/nio/channels/FileChannel:position	()J
    //   547: invokevirtual 884	java/nio/channels/FileChannel:truncate	(J)Ljava/nio/channels/FileChannel;
    //   550: pop
    //   551: aload 15
    //   553: invokevirtual 885	java/io/RandomAccessFile:close	()V
    //   556: aload 12
    //   558: aload 14
    //   560: invokevirtual 849	java/io/File:renameTo	(Ljava/io/File;)Z
    //   563: pop
    //   564: aload 19
    //   566: athrow
    //   567: astore 26
    //   569: ldc 245
    //   571: ldc_w 906
    //   574: aload 25
    //   576: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   579: pop
    //   580: aload 26
    //   582: athrow
    //   583: astore 20
    //   585: ldc 245
    //   587: ldc_w 904
    //   590: aload 20
    //   592: invokestatic 297	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   595: pop
    //   596: goto -32 -> 564
    //   599: iconst_1
    //   600: anewarray 140	com/parse/ErrorReporter$CrashReportType
    //   603: astore 36
    //   605: aload 36
    //   607: iconst_0
    //   608: getstatic 144	com/parse/ErrorReporter$CrashReportType:ACRA_CRASH_REPORT	Lcom/parse/ErrorReporter$CrashReportType;
    //   611: aastore
    //   612: new 887	com/parse/ErrorReporter$ReportsSenderWorker
    //   615: dup
    //   616: aload_0
    //   617: aload 36
    //   619: invokespecial 914	com/parse/ErrorReporter$ReportsSenderWorker:<init>	(Lcom/parse/ErrorReporter;[Lcom/parse/ErrorReporter$CrashReportType;)V
    //   622: astore 34
    //   624: goto -299 -> 325
    //   627: ldc 245
    //   629: ldc_w 916
    //   632: invokestatic 895	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   635: pop
    //   636: aconst_null
    //   637: areturn
    //   638: astore 16
    //   640: aload 47
    //   642: astore 15
    //   644: goto -292 -> 352
    //
    // Exception table:
    //   from	to	target	type
    //   157	174	350	java/lang/Exception
    //   174	188	350	java/lang/Exception
    //   270	301	374	java/lang/Exception
    //   213	242	390	java/lang/Exception
    //   246	252	390	java/lang/Exception
    //   252	265	390	java/lang/Exception
    //   436	467	470	java/lang/Exception
    //   392	420	486	java/lang/Exception
    //   213	242	526	finally
    //   246	252	526	finally
    //   252	265	526	finally
    //   420	431	526	finally
    //   512	523	526	finally
    //   569	583	526	finally
    //   392	420	567	finally
    //   488	512	567	finally
    //   533	564	583	java/lang/Exception
    //   188	205	638	java/lang/Exception
  }

  private CrashReportData loadAcraCrashReport(Context paramContext, String paramString)
    throws IOException
  {
    return loadCrashReport(paramContext, paramString, CrashReportType.ACRA_CRASH_REPORT, this.mMaxReportSize);
  }

  // ERROR //
  private String loadAttachment(java.io.InputStream paramInputStream, int paramInt)
    throws IOException
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: iconst_0
    //   3: istore 4
    //   5: iload_2
    //   6: newarray byte
    //   8: astore 5
    //   10: iload_2
    //   11: iload_3
    //   12: isub
    //   13: ifle +21 -> 34
    //   16: aload_1
    //   17: aload 5
    //   19: iload_3
    //   20: iload_2
    //   21: iload_3
    //   22: isub
    //   23: invokevirtual 928	java/io/InputStream:read	([BII)I
    //   26: istore 4
    //   28: iload 4
    //   30: iconst_m1
    //   31: if_icmpne +16 -> 47
    //   34: iload 4
    //   36: ifne +19 -> 55
    //   39: ldc_w 545
    //   42: astore 11
    //   44: aload 11
    //   46: areturn
    //   47: iload_3
    //   48: iload 4
    //   50: iadd
    //   51: istore_3
    //   52: goto -42 -> 10
    //   55: new 930	java/io/ByteArrayOutputStream
    //   58: dup
    //   59: invokespecial 931	java/io/ByteArrayOutputStream:<init>	()V
    //   62: astore 6
    //   64: aconst_null
    //   65: astore 7
    //   67: new 933	java/util/zip/GZIPOutputStream
    //   70: dup
    //   71: aload 6
    //   73: invokespecial 936	java/util/zip/GZIPOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   76: astore 8
    //   78: aload 8
    //   80: aload 5
    //   82: iconst_0
    //   83: aload 5
    //   85: arraylength
    //   86: invokevirtual 939	java/util/zip/GZIPOutputStream:write	([BII)V
    //   89: aload 8
    //   91: invokevirtual 942	java/util/zip/GZIPOutputStream:finish	()V
    //   94: aload 6
    //   96: invokevirtual 946	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   99: iconst_0
    //   100: invokestatic 952	android/util/Base64:encodeToString	([BI)Ljava/lang/String;
    //   103: astore 10
    //   105: aload 10
    //   107: astore 11
    //   109: aload 8
    //   111: ifnull -67 -> 44
    //   114: aload 8
    //   116: invokevirtual 953	java/util/zip/GZIPOutputStream:close	()V
    //   119: aload 11
    //   121: areturn
    //   122: astore 9
    //   124: aload 7
    //   126: ifnull +8 -> 134
    //   129: aload 7
    //   131: invokevirtual 953	java/util/zip/GZIPOutputStream:close	()V
    //   134: aload 9
    //   136: athrow
    //   137: astore 9
    //   139: aload 8
    //   141: astore 7
    //   143: goto -19 -> 124
    //
    // Exception table:
    //   from	to	target	type
    //   67	78	122	finally
    //   78	105	137	finally
  }

  private CrashReportData loadCrashAttachment(Context paramContext, String paramString, CrashReportType paramCrashReportType)
    throws IOException
  {
    return loadCrashReport(paramContext, paramString, paramCrashReportType, paramCrashReportType.defaultMaxSize);
  }

  private CrashReportData loadCrashReport(Context paramContext, String paramString, CrashReportType paramCrashReportType, long paramLong)
    throws IOException
  {
    CrashReportData localCrashReportData = new CrashReportData();
    File localFile = fileForName(this.mFileProvider, paramCrashReportType.directory, paramString);
    if (System.currentTimeMillis() - localFile.lastModified() > 86400000L)
    {
      Log.w("CrashReporting", "crash report " + paramString + " was too old; deleted");
      deleteFile(paramCrashReportType.directory, paramString);
      return null;
    }
    if ((paramString.endsWith(".temp_stacktrace")) && (System.currentTimeMillis() - localFile.lastModified() < 600000L))
    {
      Log.w("CrashReporting", "temp file " + paramString + " is too recent; skipping");
      return null;
    }
    if (localFile.length() > paramLong)
    {
      Log.w("CrashReporting", "" + localFile.length() + "-byte crash report " + paramString + " exceeded max size of " + paramLong + " bytes; deleted");
      deleteFile(paramCrashReportType.directory, paramString);
      return null;
    }
    FileInputStream localFileInputStream = new FileInputStream(localFile);
    int i = 0;
    try
    {
      CrashReportType localCrashReportType = CrashReportType.ACRA_CRASH_REPORT;
      i = 0;
      if (paramCrashReportType == localCrashReportType)
        localCrashReportData.load(localFileInputStream);
      while (true)
      {
        if (0 == 0)
          localFileInputStream.close();
        localCrashReportData.put(ReportField.ACRA_REPORT_FILENAME, paramString);
        backfillCrashReportData(localCrashReportData);
        return localCrashReportData;
        String str = loadAttachment(localFileInputStream, (int)localFile.length());
        localCrashReportData.put(paramCrashReportType.attachmentField, str);
      }
    }
    catch (Throwable localThrowable)
    {
      while (true)
      {
        localCrashReportData.put(ReportField.REPORT_LOAD_THROW, "throwable: " + localThrowable.getMessage());
        Log.e("CrashReporting", "Could not load crash report:" + paramString + " " + localThrowable);
        localFileInputStream.close();
        i = 1;
        paramContext.deleteFile(paramString);
        Log.e("CrashReporting", "Crash report:" + paramString + " deleted");
        if (i != 0)
          continue;
        localFileInputStream.close();
      }
    }
    finally
    {
      if (i == 0)
        localFileInputStream.close();
    }
    throw localObject;
  }

  private void populateConstantDeviceData(CrashReportData paramCrashReportData, Writer paramWriter)
  {
    Iterator localIterator = getConstantDeviceData().entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      put((ReportField)localEntry.getKey(), (String)localEntry.getValue(), paramCrashReportData, paramWriter);
    }
  }

  private void put(ReportField paramReportField, String paramString, CrashReportData paramCrashReportData, Writer paramWriter)
  {
    try
    {
      if (this.sendInMemoryReport)
        paramWriter = null;
      paramCrashReportData.put(paramReportField, paramString, paramWriter);
      return;
    }
    catch (IOException localIOException)
    {
      this.sendInMemoryReport = true;
    }
  }

  private void resetProcessNameByAmsCache()
  {
    this.processNameByAms = null;
    this.processNameByAmsReady = false;
  }

  private void retrieveCrashTimeData(Context paramContext, Throwable paramThrowable, ReportField[] paramArrayOfReportField, CrashReportData paramCrashReportData, Writer paramWriter)
    throws Exception
  {
    List localList = Arrays.asList(paramArrayOfReportField);
    if (localList.contains(ReportField.REPORT_ID))
      put(ReportField.REPORT_ID, UUID.randomUUID().toString(), paramCrashReportData, paramWriter);
    if (localList.contains(ReportField.PROCESS_NAME))
      put(ReportField.PROCESS_NAME, getProcessName(), paramCrashReportData, paramWriter);
    if (localList.contains(ReportField.USER_APP_START_DATE))
      put(ReportField.USER_APP_START_DATE, this.mAppStartDate.format3339(false), paramCrashReportData, paramWriter);
    if (localList.contains(ReportField.PROCESS_UPTIME))
      put(ReportField.PROCESS_UPTIME, Long.toString(getProcessUptime()), paramCrashReportData, paramWriter);
    if (localList.contains(ReportField.DEVICE_UPTIME))
      put(ReportField.DEVICE_UPTIME, Long.toString(getDeviceUptime()), paramCrashReportData, paramWriter);
    if (localList.contains(ReportField.CRASH_CONFIGURATION))
    {
      Configuration localConfiguration = paramContext.getResources().getConfiguration();
      put(ReportField.CRASH_CONFIGURATION, ConfigurationInspector.toString(localConfiguration), paramCrashReportData, paramWriter);
    }
    if (localList.contains(ReportField.AVAILABLE_MEM_SIZE))
    {
      String str3 = Long.toString(getAvailableInternalMemorySize());
      put(ReportField.AVAILABLE_MEM_SIZE, str3, paramCrashReportData, paramWriter);
    }
    if (localList.contains(ReportField.DUMPSYS_MEMINFO))
      put(ReportField.DUMPSYS_MEMINFO, DumpSysCollector.collectMemInfo(paramContext), paramCrashReportData, paramWriter);
    if (localList.contains(ReportField.USER_CRASH_DATE))
    {
      Time localTime = new Time();
      localTime.setToNow();
      put(ReportField.USER_CRASH_DATE, localTime.format3339(false), paramCrashReportData, paramWriter);
    }
    if (localList.contains(ReportField.ACTIVITY_LOG))
      if (!(paramThrowable instanceof OutOfMemoryError))
        break label683;
    label683: for (String str2 = this.activityLogger.toString(); ; str2 = this.activityLogger.toString(DEFAULT_TRACE_COUNT_LIMIT))
    {
      put(ReportField.ACTIVITY_LOG, str2, paramCrashReportData, paramWriter);
      if (localList.contains(ReportField.PROCESS_NAME_BY_AMS))
        put(ReportField.PROCESS_NAME_BY_AMS, getProcessNameFromAms(), paramCrashReportData, paramWriter);
      resetProcessNameByAmsCache();
      if (localList.contains(ReportField.OPEN_FD_COUNT))
        put(ReportField.OPEN_FD_COUNT, String.valueOf(ProcFileReader.getOpenFDCount()), paramCrashReportData, paramWriter);
      if ((localList.contains(ReportField.OPEN_FD_SOFT_LIMIT)) || (localList.contains(ReportField.OPEN_FD_HARD_LIMIT)))
      {
        ProcFileReader.OpenFDLimits localOpenFDLimits = ProcFileReader.getOpenFDLimits();
        if (localOpenFDLimits != null)
        {
          if (localList.contains(ReportField.OPEN_FD_SOFT_LIMIT))
            put(ReportField.OPEN_FD_SOFT_LIMIT, localOpenFDLimits.softLimit, paramCrashReportData, paramWriter);
          if (localList.contains(ReportField.OPEN_FD_HARD_LIMIT))
            put(ReportField.OPEN_FD_HARD_LIMIT, localOpenFDLimits.hardLimit, paramCrashReportData, paramWriter);
        }
      }
      if ((Build.VERSION.SDK_INT >= 16) && (this.mIsInternalBuild))
      {
        if (localList.contains(ReportField.LOGCAT))
          put(ReportField.LOGCAT, LogCatCollector.collectLogCat(null), paramCrashReportData, paramWriter);
        if (localList.contains(ReportField.EVENTSLOG))
          put(ReportField.EVENTSLOG, LogCatCollector.collectLogCat("events"), paramCrashReportData, paramWriter);
        if (localList.contains(ReportField.RADIOLOG))
          put(ReportField.RADIOLOG, LogCatCollector.collectLogCat("radio"), paramCrashReportData, paramWriter);
        if (localList.contains(ReportField.DROPBOX))
        {
          String str1 = DropBoxCollector.read(this.mContext, ACRA.getConfig().additionalDropBoxTags());
          put(ReportField.DROPBOX, str1, paramCrashReportData, paramWriter);
        }
      }
      if ((localList.contains(ReportField.LARGE_MEM_HEAP)) && (Build.VERSION.SDK_INT >= 11))
        put(ReportField.LARGE_MEM_HEAP, DumpSysCollector.collectLargerMemoryInfo(paramContext), paramCrashReportData, paramWriter);
      return;
    }
  }

  private void sendCrashReport(CrashReportData paramCrashReportData)
    throws ReportSenderException
  {
    int i = 0;
    Iterator localIterator = this.mReportSenders.iterator();
    while (localIterator.hasNext())
    {
      ReportSender localReportSender = (ReportSender)localIterator.next();
      try
      {
        localReportSender.send(paramCrashReportData);
        i = 1;
      }
      catch (ReportSenderException localReportSenderException)
      {
        if (i == 0)
          throw localReportSenderException;
        Log.w("CrashReporting", "ReportSender of class " + localReportSender.getClass().getName() + " failed but other senders completed their task. " + "ParseCrashReporting will not send this report again.");
      }
    }
  }

  private boolean shouldContinueProcessingException(Throwable paramThrowable)
  {
    synchronized (this.mShouldContinueProcessingExceptionLock)
    {
      if (this.mCurrentlyProcessingOOM)
        return false;
      if ((paramThrowable instanceof OutOfMemoryError))
        this.mCurrentlyProcessingOOM = true;
      return true;
    }
  }

  private String throwableToString(Throwable paramThrowable)
  {
    if (paramThrowable == null)
      paramThrowable = new Exception("Report requested by developer");
    StringWriter localStringWriter = new StringWriter();
    PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
    paramThrowable.printStackTrace(localPrintWriter);
    localPrintWriter.close();
    return localStringWriter.toString();
  }

  private static String toString(Display paramDisplay)
  {
    DisplayMetrics localDisplayMetrics = new DisplayMetrics();
    paramDisplay.getMetrics(localDisplayMetrics);
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("width=").append(paramDisplay.getWidth()).append('\n').append("height=").append(paramDisplay.getHeight()).append('\n').append("pixelFormat=").append(paramDisplay.getPixelFormat()).append('\n').append("refreshRate=").append(paramDisplay.getRefreshRate()).append("fps").append('\n').append("metrics.density=x").append(localDisplayMetrics.density).append('\n').append("metrics.scaledDensity=x").append(localDisplayMetrics.scaledDensity).append('\n').append("metrics.widthPixels=").append(localDisplayMetrics.widthPixels).append('\n').append("metrics.heightPixels=").append(localDisplayMetrics.heightPixels).append('\n').append("metrics.xdpi=").append(localDisplayMetrics.xdpi).append('\n').append("metrics.ydpi=").append(localDisplayMetrics.ydpi);
    return localStringBuilder.toString();
  }

  private void writeToLogBridge(String paramString1, String paramString2, Throwable paramThrowable, String paramString3)
  {
    LogBridge localLogBridge = getLogBridge();
    if (localLogBridge != null)
    {
      if (paramString3 != null)
      {
        localLogBridge.log(paramString1, paramString2 + "\n" + paramString3, null);
        return;
      }
      localLogBridge.log(paramString1, paramString2, paramThrowable);
      return;
    }
    if (paramString3 != null)
    {
      Log.e(paramString1, paramString2 + "\n" + paramString3);
      return;
    }
    Log.e(paramString1, paramString2, paramThrowable);
  }

  public void addReportSender(ReportSender paramReportSender)
  {
    this.mReportSenders.add(paramReportSender);
  }

  void backfillCrashReportData(CrashReportData paramCrashReportData)
  {
    int i;
    Iterator localIterator;
    if (!parseVersionCodeFromFileName(paramCrashReportData.getProperty(ReportField.ACRA_REPORT_FILENAME)).equals(this.mAppVersionCode))
    {
      i = 1;
      String str1 = (String)paramCrashReportData.get(ReportField.REPORT_ID);
      if ((str1 == null) || (str1.length() == 0))
        localIterator = this.mConstantFields.entrySet().iterator();
    }
    else
    {
      while (true)
      {
        if (!localIterator.hasNext())
          break label175;
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        if (((ReportField)localEntry.getKey()).equals(ReportField.APP_VERSION_NAME))
        {
          if (i != 0)
            continue;
          paramCrashReportData.put((Enum)localEntry.getKey(), localEntry.getValue());
          continue;
          i = 0;
          break;
        }
        if (paramCrashReportData.get(localEntry.getKey()) != null)
          continue;
        paramCrashReportData.put((Enum)localEntry.getKey(), localEntry.getValue());
      }
    }
    label175: String str2 = getUserId();
    String str3 = (String)paramCrashReportData.get(ReportField.UID);
    if ((!TextUtils.isEmpty(str2)) && (TextUtils.isEmpty(str3)))
      paramCrashReportData.put(ReportField.UID, str2);
  }

  void checkAndSendReports(Context paramContext, CrashReportType[] paramArrayOfCrashReportType)
  {
    monitorenter;
    while (true)
    {
      int j;
      try
      {
        Log.d("CrashReporting", "#checkAndSendReports - start");
        int i = paramArrayOfCrashReportType.length;
        j = 0;
        if (j < i)
        {
          CrashReportType localCrashReportType = paramArrayOfCrashReportType[j];
          if (CrashReportType.ACRA_CRASH_REPORT != localCrashReportType)
            continue;
          checkAndSendAcraReports(paramContext);
          break label75;
          checkAndSendCrashAttachments(paramContext, localCrashReportType);
        }
      }
      finally
      {
        monitorexit;
      }
      Log.d("CrashReporting", "#checkAndSendReports - finish");
      monitorexit;
      return;
      label75: j++;
    }
  }

  public ReportsSenderWorker checkReportsOfType(CrashReportType[] paramArrayOfCrashReportType)
  {
    ReportsSenderWorker localReportsSenderWorker = new ReportsSenderWorker(paramArrayOfCrashReportType);
    localReportsSenderWorker.start();
    return localReportsSenderWorker;
  }

  public ReportsSenderWorker checkReportsOnApplicationStart()
  {
    String[] arrayOfString1 = getCrashReportFilesList("cr/reports", new String[] { ".stacktrace" });
    String[] arrayOfString2 = getCrashReportFilesList("cr/minidumps", new String[] { ".dmp" });
    if (((arrayOfString1 != null) && (arrayOfString1.length > 0)) || ((arrayOfString2 != null) && (arrayOfString2.length > 0)))
    {
      Log.v("CrashReporting", "About to start ReportSenderWorker from #checkReportOnApplicationStart");
      if ((arrayOfString2 != null) && (arrayOfString2.length > 0))
        this.mHasNativeCrashDumpOnInit = true;
      return checkReportsOfType(ALL_REPORT_TYPES);
    }
    return null;
  }

  public String dumpCustomDataToString(Map<String, String> paramMap, Throwable paramThrowable)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    dumpCustomDataMap(localStringBuilder, this.mInstanceCustomParameters);
    if (paramMap != null)
      dumpCustomDataMap(localStringBuilder, paramMap);
    dumpLazyCustomDataMap(localStringBuilder, this.mInstanceLazyCustomParameters, paramThrowable);
    return localStringBuilder.toString();
  }

  public String[] getCrashReportFilesList(String paramString, String[] paramArrayOfString)
  {
    String[] arrayOfString;
    if (this.mContext == null)
    {
      Log.e("CrashReporting", "Trying to get crash reports but crash reporting is not initialized.");
      arrayOfString = new String[0];
    }
    while (true)
    {
      return arrayOfString;
      File localFile = this.mFileProvider.getFile(paramString);
      if (localFile == null)
        break;
      Log.d("CrashReporting", "Looking for error files in " + localFile.getAbsolutePath());
      arrayOfString = localFile.list(new FilenameFilter(paramArrayOfString)
      {
        public boolean accept(File paramFile, String paramString)
        {
          String[] arrayOfString = this.val$extensions;
          int i = arrayOfString.length;
          for (int j = 0; j < i; j++)
            if (paramString.endsWith(arrayOfString[j]))
              return true;
          return false;
        }
      });
      if (arrayOfString == null)
        return new String[0];
    }
    Log.w("CrashReporting", "Application files directory does not exist! The application may not be installed correctly. Please try reinstalling.");
    return new String[0];
  }

  public String getCustomData(String paramString)
  {
    return (String)this.mInstanceCustomParameters.get(paramString);
  }

  public LogBridge getLogBridge()
  {
    return this.mLogBridge;
  }

  Throwable getMostSignificantCause(Throwable paramThrowable)
  {
    if ((paramThrowable instanceof NonCrashException))
      return paramThrowable;
    for (Throwable localThrowable = paramThrowable; localThrowable.getCause() != null; localThrowable = localThrowable.getCause());
    return localThrowable;
  }

  public String getUserId()
  {
    return this.mUserId;
  }

  public ReportsSenderWorker handleException(Throwable paramThrowable)
  {
    return handleException(paramThrowable, null);
  }

  public ReportsSenderWorker handleException(Throwable paramThrowable, String paramString, Map<String, String> paramMap)
  {
    return handleExceptionInternal(paramThrowable, paramMap, paramString, getReportFieldsForException(paramThrowable), true);
  }

  public ReportsSenderWorker handleException(Throwable paramThrowable, Map<String, String> paramMap)
  {
    if (!(paramThrowable instanceof OutOfMemoryError));
    for (boolean bool = true; ; bool = false)
      return handleExceptionInternal(paramThrowable, paramMap, null, getReportFieldsForException(paramThrowable), bool);
  }

  public void handleExceptionWithCustomFields(Exception paramException, Map<String, String> paramMap, ReportField[] paramArrayOfReportField)
  {
    handleExceptionInternal(paramException, paramMap, null, paramArrayOfReportField, true);
  }

  public void init(Context paramContext, boolean paramBoolean, FileProvider paramFileProvider)
  {
    PackageInfo localPackageInfo;
    String str3;
    if (this.mDfltExceptionHandler == null)
    {
      this.mDfltExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
      this.mIsInternalBuild = paramBoolean;
      this.mContext = paramContext;
      this.mFileProvider = paramFileProvider;
      localPackageInfo = new PackageManagerWrapper(paramContext).getPackageInfo();
      if (localPackageInfo != null)
      {
        this.mAppVersionCode = Integer.toString(localPackageInfo.versionCode);
        if (localPackageInfo.versionName == null)
          break label424;
        str3 = localPackageInfo.versionName;
      }
    }
    while (true)
    {
      this.mAppVersionName = str3;
      this.mPackageManager = new PackageManagerWrapper(paramContext);
      String str1 = System.getProperty("os.version");
      boolean bool;
      if (str1 != null)
      {
        bool = str1.contains("cyanogenmod");
        this.mAppStartDate.setToNow();
      }
      try
      {
        this.mConstantFields.put(ReportField.ANDROID_ID, Settings.Secure.getString(paramContext.getContentResolver(), "android_id"));
        this.mConstantFields.put(ReportField.APP_VERSION_CODE, this.mAppVersionCode);
        this.mConstantFields.put(ReportField.APP_VERSION_NAME, this.mAppVersionName);
        this.mConstantFields.put(ReportField.PACKAGE_NAME, paramContext.getPackageName());
        this.mConstantFields.put(ReportField.PHONE_MODEL, Build.MODEL);
        this.mConstantFields.put(ReportField.ANDROID_VERSION, Build.VERSION.RELEASE);
        this.mConstantFields.put(ReportField.OS_VERSION, str1);
        this.mConstantFields.put(ReportField.IS_CYANOGENMOD, Boolean.toString(bool));
        this.mConstantFields.put(ReportField.BRAND, Build.BRAND);
        this.mConstantFields.put(ReportField.PRODUCT, Build.PRODUCT);
        String str2 = "n/a";
        File localFile = paramContext.getFilesDir();
        if (localFile != null)
          str2 = localFile.getAbsolutePath();
        this.mConstantFields.put(ReportField.FILE_PATH, str2);
        if (Build.VERSION.SDK_INT >= 9)
        {
          this.mConstantFields.put(ReportField.SERIAL, Build.SERIAL);
          if (localPackageInfo != null)
          {
            this.mConstantFields.put(ReportField.APP_INSTALL_TIME, formatTimestamp(localPackageInfo.firstInstallTime));
            this.mConstantFields.put(ReportField.APP_UPGRADE_TIME, formatTimestamp(localPackageInfo.lastUpdateTime));
          }
        }
        this.preallocFile = fileForName(this.mFileProvider, "cr/reports", "reportfile.prealloc");
        createPreallocatedReportFile();
        return;
        label424: str3 = "not set";
        continue;
        bool = false;
      }
      catch (Exception localException)
      {
        while (true)
          Log.e("CrashReporting", "failed to install constants", localException);
      }
    }
  }

  public boolean isNativeCrashedOnPreviousRun()
  {
    return this.mHasNativeCrashDumpOnInit;
  }

  public String parseVersionCodeFromFileName(String paramString)
  {
    if (paramString != null)
    {
      Matcher localMatcher = VERSION_CODE_REGEX.matcher(paramString);
      if (localMatcher.matches())
        return localMatcher.group(1);
    }
    return "";
  }

  public String putCustomData(String paramString1, String paramString2)
  {
    if (paramString2 != null)
      return (String)this.mInstanceCustomParameters.put(paramString1, paramString2);
    return removeCustomData(paramString1);
  }

  public void putLazyCustomData(String paramString, CustomReportDataSupplier paramCustomReportDataSupplier)
  {
    this.mInstanceLazyCustomParameters.put(paramString, paramCustomReportDataSupplier);
  }

  public void registerActivity(String paramString)
  {
    if (paramString != null)
      this.activityLogger.append(paramString);
  }

  public void removeAllReportSenders()
  {
    this.mReportSenders.clear();
  }

  public String removeCustomData(String paramString)
  {
    return (String)this.mInstanceCustomParameters.remove(paramString);
  }

  void sendInMemoryReport(Context paramContext, CrashReportData paramCrashReportData)
  {
    monitorenter;
    try
    {
      Log.i("CrashReporting", "Sending in-memory report");
      try
      {
        String str1 = getProcessNameFromAms();
        paramCrashReportData.put(ReportField.UPLOADED_BY_PROCESS, str1);
        sendCrashReport(paramCrashReportData);
        String str2 = (String)paramCrashReportData.get(ReportField.ACRA_REPORT_FILENAME);
        if (str2 != null)
        {
          File localFile = fileForName(this.mFileProvider, "cr/reports", str2);
          if (localFile != null)
            localFile.delete();
        }
        monitorexit;
        return;
      }
      catch (Exception localException)
      {
        while (true)
          Log.e("CrashReporting", "Failed to send in-memory crash report: ", localException);
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void setLogBridge(LogBridge paramLogBridge)
  {
    this.mLogBridge = paramLogBridge;
  }

  public void setMaxReportSize(long paramLong)
  {
    this.mMaxReportSize = paramLong;
  }

  public void setReportSender(ReportSender paramReportSender)
  {
    removeAllReportSenders();
    addReportSender(paramReportSender);
  }

  public void setUserId(String paramString)
  {
    this.mUserId = paramString;
  }

  public void uncaughtException(Thread paramThread, Throwable paramThrowable)
  {
    Log.e("CrashReporting", "ParseCrashReporting caught a " + paramThrowable.getClass().getSimpleName() + " exception for " + this.mContext.getPackageName() + ". Building report.");
    this.usePreallocatedFile = true;
    boolean bool = mProcessingCrash.getAndSet(true);
    try
    {
      localHashMap1 = new HashMap();
    }
    catch (OutOfMemoryError localOutOfMemoryError2)
    {
      try
      {
        localHashMap1.put("IS_PROCESSING_ANOTHER_EXCEPTION", String.valueOf(bool));
        for (localHashMap2 = localHashMap1; ; localHashMap2 = null)
        {
          ReportsSenderWorker localReportsSenderWorker = handleException(paramThrowable, localHashMap2);
          if (localReportsSenderWorker != null)
          {
            while (localReportsSenderWorker.isAlive())
              try
              {
                Thread.sleep(100L);
              }
              catch (InterruptedException localInterruptedException)
              {
                Log.e("CrashReporting", "Error : ", localInterruptedException);
              }
            Throwable localThrowable = localReportsSenderWorker.getException();
            if (localThrowable != null)
            {
              Log.e("CrashReporting", "ReportsWorkerSender failed with exception", localThrowable);
              handleExceptionInternal(localThrowable, localHashMap2, null, getReportFieldsForException(paramThrowable), false);
            }
          }
          if (this.mDfltExceptionHandler != null)
            this.mDfltExceptionHandler.uncaughtException(paramThread, paramThrowable);
          return;
          localOutOfMemoryError2 = localOutOfMemoryError2;
        }
      }
      catch (OutOfMemoryError localOutOfMemoryError1)
      {
        while (true)
        {
          HashMap localHashMap1;
          HashMap localHashMap2 = localHashMap1;
        }
      }
    }
  }

  public void writeReportToStream(Throwable paramThrowable, OutputStream paramOutputStream)
    throws Exception
  {
    CrashReportData localCrashReportData = new CrashReportData();
    Writer localWriter = CrashReportData.getWriter(paramOutputStream);
    gatherCrashData(throwableToString(paramThrowable), paramThrowable, ACRA.ALL_CRASH_REPORT_FIELDS, localCrashReportData, localWriter, null);
  }

  private class CrashAttachmentException extends Throwable
  {
    private CrashAttachmentException()
    {
    }
  }

  public static enum CrashReportType
  {
    private final ReportField attachmentField;
    private final long defaultMaxSize;
    private final String directory;
    private final String[] fileExtensions;

    static
    {
      ANR_REPORT = new CrashReportType("ANR_REPORT", 2, "traces", 122880L, ReportField.SIGQUIT, new String[] { ".stacktrace", ".temp_stacktrace" });
      CrashReportType[] arrayOfCrashReportType = new CrashReportType[3];
      arrayOfCrashReportType[0] = ACRA_CRASH_REPORT;
      arrayOfCrashReportType[1] = NATIVE_CRASH_REPORT;
      arrayOfCrashReportType[2] = ANR_REPORT;
      $VALUES = arrayOfCrashReportType;
    }

    private CrashReportType(String paramString, long paramLong, ReportField paramReportField, String[] paramArrayOfString)
    {
      this.directory = paramString;
      this.defaultMaxSize = paramLong;
      this.attachmentField = paramReportField;
      this.fileExtensions = paramArrayOfString;
    }
  }

  final class ReportsSenderWorker extends Thread
  {
    private Throwable exception = null;
    private CrashReportData mInMemoryReportToSend;
    private final ErrorReporter.CrashReportType[] mReportTypesToSend;

    public ReportsSenderWorker(CrashReportData arg2)
    {
      this(new ErrorReporter.CrashReportType[0]);
      Object localObject;
      this.mInMemoryReportToSend = localObject;
    }

    public ReportsSenderWorker(ErrorReporter.CrashReportType[] arg2)
    {
      Object localObject;
      this.mReportTypesToSend = localObject;
    }

    private PowerManager.WakeLock acquireWakeLock()
    {
      if (!new PackageManagerWrapper(ErrorReporter.this.mContext).hasPermission("android.permission.WAKE_LOCK"))
        return null;
      PowerManager.WakeLock localWakeLock = ((PowerManager)ErrorReporter.this.mContext.getSystemService("power")).newWakeLock(1, "crash reporting wakelock");
      localWakeLock.setReferenceCounted(false);
      localWakeLock.acquire();
      return localWakeLock;
    }

    public Throwable getException()
    {
      return this.exception;
    }

    public void run()
    {
      PowerManager.WakeLock localWakeLock = null;
      try
      {
        localWakeLock = acquireWakeLock();
        if (this.mInMemoryReportToSend != null)
          ErrorReporter.this.sendInMemoryReport(ErrorReporter.this.mContext, this.mInMemoryReportToSend);
        while (true)
        {
          return;
          ErrorReporter.this.checkAndSendReports(ErrorReporter.this.mContext, this.mReportTypesToSend);
        }
      }
      catch (Throwable localThrowable)
      {
        this.exception = localThrowable;
        return;
      }
      finally
      {
        if ((localWakeLock != null) && (localWakeLock.isHeld()))
          localWakeLock.release();
      }
      throw localObject;
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.ErrorReporter
 * JD-Core Version:    0.6.0
 */