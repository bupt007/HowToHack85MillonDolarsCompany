package com.parse;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import bolts.Continuation;
import bolts.Task;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class PushRouter
{
  private static final ExecutorService EXECUTOR;
  public static final String GCM_RECEIVE_ACTION = "com.google.android.c2dm.intent.RECEIVE";
  private static final String LEGACY_ROUTE_LOCATION = "persistentCallbacks";
  static int MAX_HISTORY_LENGTH = 0;
  private static final String STATE_LOCATION = "pushState";
  private static final String TAG = "com.parse.ParsePushRouter";
  private static final Integer V1_LATEST_PUSH_STATE_VERSION;
  public static final Integer V2_PUSH_STATE_VERSION = Integer.valueOf(4);
  private static PushRouter instance;
  private static Task<Void> lastTask;
  private static PushListener pushListener;
  private Boolean forceEnabled;
  private final PushHistory history;
  private final AtomicBoolean isRefreshingInstallation = new AtomicBoolean(false);
  private int pushStateVersion;
  private final PushRoutes routes;
  private final String stateLocation;

  static
  {
    V1_LATEST_PUSH_STATE_VERSION = Integer.valueOf(3);
    EXECUTOR = Executors.newSingleThreadExecutor();
    MAX_HISTORY_LENGTH = 10;
  }

  public PushRouter(String paramString, PushRoutes paramPushRoutes, PushHistory paramPushHistory)
  {
    this.stateLocation = paramString;
    this.routes = paramPushRoutes;
    this.history = paramPushHistory;
    this.forceEnabled = null;
    this.pushStateVersion = V1_LATEST_PUSH_STATE_VERSION.intValue();
  }

  private static JSONArray getChannelsArrayFromInstallation(ParseInstallation paramParseInstallation)
  {
    List localList = paramParseInstallation.getList("channels");
    JSONArray localJSONArray = null;
    if (localList != null)
      localJSONArray = (JSONArray)Parse.encode(localList, PointerOrLocalIdEncodingStrategy.get());
    if (localJSONArray != null)
      return localJSONArray;
    return new JSONArray();
  }

  public static Task<Boolean> getForceEnabledStateAsync()
  {
    monitorenter;
    try
    {
      Task localTask = getLastTask().onSuccess(new Continuation()
      {
        public Boolean then(Task<Void> paramTask)
        {
          return PushRouter.access$000().forceEnabled;
        }
      }
      , EXECUTOR);
      lastTask = makeUnhandledExceptionsFatal(localTask.makeVoid());
      return localTask;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  private static PushRouter getInstance()
  {
    if (instance == null)
    {
      JSONObject localJSONObject = migrateV1toV3("persistentCallbacks", "pushState");
      if (localJSONObject == null)
        localJSONObject = migrateV2toV3("pushState", "pushState");
      if (localJSONObject == null)
        localJSONObject = Parse.getDiskObject(Parse.applicationContext, "pushState");
      instance = new PushRouter("pushState", new PushRoutes(localJSONObject), new PushHistory(MAX_HISTORY_LENGTH, localJSONObject));
      if (localJSONObject != null)
      {
        instance.forceEnabled = ((Boolean)localJSONObject.opt("forceEnabled"));
        instance.pushStateVersion = localJSONObject.optInt("version", V1_LATEST_PUSH_STATE_VERSION.intValue());
      }
    }
    return instance;
  }

  private static Task<Void> getLastTask()
  {
    monitorenter;
    try
    {
      if (lastTask == null)
        lastTask = Task.forResult(null).makeVoid();
      Task localTask = lastTask;
      return localTask;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public static Task<JSONObject> getPushRequestJSONAsync()
  {
    monitorenter;
    try
    {
      Task localTask = getLastTask().onSuccess(new Continuation()
      {
        public JSONObject then(Task<Void> paramTask)
        {
          return PushRouter.access$000().getPushRequestJSON();
        }
      }
      , EXECUTOR);
      lastTask = makeUnhandledExceptionsFatal(localTask.makeVoid());
      return localTask;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public static Task<Set<String>> getSubscriptionsAsync(boolean paramBoolean)
  {
    monitorenter;
    try
    {
      Task localTask = getLastTask().onSuccess(new Continuation(paramBoolean)
      {
        public Set<String> then(Task<Void> paramTask)
        {
          return PushRouter.access$000().getSubscriptions(this.val$includeDefaultRoute);
        }
      }
      , EXECUTOR);
      lastTask = makeUnhandledExceptionsFatal(localTask.makeVoid());
      return localTask;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public static void handleGcmPushIntent(Intent paramIntent)
  {
    Semaphore localSemaphore = new Semaphore(0);
    EXECUTOR.submit(new Runnable(paramIntent, localSemaphore)
    {
      public void run()
      {
        PushRouter.access$000().handleGcmPush(this.val$intent);
        this.val$done.release();
      }
    });
    localSemaphore.acquireUninterruptibly();
  }

  public static Task<Void> handlePpnsPushAsync(JSONObject paramJSONObject)
  {
    monitorenter;
    try
    {
      Task localTask = getLastTask().onSuccess(new Continuation(paramJSONObject)
      {
        public Void then(Task<Void> paramTask)
        {
          if (this.val$pushPayload != null)
            PushRouter.access$000().handlePpnsPush(this.val$pushPayload);
          return null;
        }
      }
      , EXECUTOR);
      lastTask = makeUnhandledExceptionsFatal(localTask);
      return localTask;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  private void handlePushInternal(JSONObject paramJSONObject)
  {
    JSONObject localJSONObject = paramJSONObject.optJSONObject("data");
    if (localJSONObject == null)
      localJSONObject = new JSONObject();
    getInstance();
    String str = paramJSONObject.optString("channel", null);
    Bundle localBundle = new Bundle();
    localBundle.putString("com.parse.Data", localJSONObject.toString());
    localBundle.putString("com.parse.Channel", str);
    Context localContext = Parse.applicationContext;
    Intent localIntent = new Intent("com.parse.push.intent.RECEIVE");
    localIntent.putExtras(localBundle);
    localIntent.setPackage(localContext.getPackageName());
    localContext.sendBroadcast(localIntent);
  }

  private HandlePushResult handlePushLegacy(JSONObject paramJSONObject)
  {
    JSONObject localJSONObject = paramJSONObject.optJSONObject("data");
    if (localJSONObject == null)
      localJSONObject = new JSONObject();
    String str1 = paramJSONObject.optString("channel", null);
    String str2 = localJSONObject.optString("action", null);
    Bundle localBundle = new Bundle();
    localBundle.putString("com.parse.Data", localJSONObject.toString());
    localBundle.putString("com.parse.Channel", str1);
    if (str2 != null)
    {
      Intent localIntent = new Intent();
      localIntent.putExtras(localBundle);
      localIntent.setAction(str2);
      localIntent.setPackage(Parse.applicationContext.getPackageName());
      Parse.applicationContext.sendBroadcast(localIntent);
      if ((!localJSONObject.has("alert")) && (!localJSONObject.has("title")))
        return HandlePushResult.BROADCAST_INTENT;
    }
    PushRoutes.Route localRoute = this.routes.get(str1);
    if ((localRoute == null) && (str1 != null))
      localRoute = this.routes.get(null);
    if (localRoute == null)
    {
      Parse.logW("com.parse.ParsePushRouter", "Received push that has no handler. Did you call PushService.setDefaultPushCallback or PushService.subscribe? Push payload: " + paramJSONObject);
      if (str2 != null)
        return HandlePushResult.BROADCAST_INTENT;
      return HandlePushResult.NO_ROUTE_FOUND;
    }
    Class localClass = localRoute.getActivityClass();
    int i = localRoute.getIconId();
    String str3 = localJSONObject.optString("title", ManifestInfo.getDisplayName());
    String str4 = localJSONObject.optString("alert", "Notification received.");
    if (i == 0)
    {
      i = ManifestInfo.getIconId();
      Parse.logW("com.parse.ParsePushRouter", "Icon ID associated with channel " + str1 + "is invalid; defaulting to package icon");
    }
    Context localContext = Parse.applicationContext;
    ParseNotificationManager.getInstance().showNotification(localContext, str3, str4, localClass, i, localBundle);
    if (str2 != null)
      return HandlePushResult.SHOW_NOTIFICATION_AND_BROADCAST_INTENT;
    return HandlePushResult.SHOW_NOTIFICATION;
  }

  public static boolean isGcmPushIntent(Intent paramIntent)
  {
    return (paramIntent != null) && ("com.google.android.c2dm.intent.RECEIVE".equals(paramIntent.getAction()));
  }

  private static Task<Void> makeUnhandledExceptionsFatal(Task<Void> paramTask)
  {
    return paramTask.continueWith(new Continuation()
    {
      public Void then(Task<Void> paramTask)
      {
        if (paramTask.isFaulted())
          Task.UI_THREAD_EXECUTOR.execute(new Runnable(paramTask)
          {
            public void run()
            {
              throw new RuntimeException(this.val$task.getError());
            }
          });
        return null;
      }
    }
    , EXECUTOR);
  }

  private void maybeRefreshInstallation(Date paramDate)
  {
    ParseInstallation localParseInstallation = ParseInstallation.getCurrentInstallation();
    Date localDate = localParseInstallation.getUpdatedAt();
    if ((localDate != null) && (paramDate != null) && (localDate.compareTo(paramDate) < 0) && (this.isRefreshingInstallation.compareAndSet(false, true)))
      localParseInstallation.fetchInBackground().continueWith(new Continuation()
      {
        public Void then(Task<ParseObject> paramTask)
        {
          PushRouter.this.isRefreshingInstallation.set(false);
          return null;
        }
      });
  }

  private static JSONObject merge(JSONObject[] paramArrayOfJSONObject)
    throws JSONException
  {
    JSONObject localJSONObject1 = new JSONObject();
    int i = paramArrayOfJSONObject.length;
    for (int j = 0; j < i; j++)
    {
      JSONObject localJSONObject2 = paramArrayOfJSONObject[j];
      Iterator localIterator = localJSONObject2.keys();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        localJSONObject1.put(str, localJSONObject2.get(str));
      }
    }
    return localJSONObject1;
  }

  static JSONObject migrateV1toV3(String paramString1, String paramString2)
  {
    ParseInstallation localParseInstallation = ParseInstallation.getCurrentInstallation();
    JSONObject localJSONObject1 = Parse.getDiskObject(Parse.applicationContext, paramString1);
    Object localObject = null;
    if (localJSONObject1 != null)
    {
      Parse.logD("com.parse.ParsePushRouter", "Migrating push state from V1 to V3: " + localJSONObject1);
      ArrayList localArrayList = new ArrayList();
      Iterator localIterator = localJSONObject1.keys();
      while (localIterator.hasNext())
        localArrayList.add(localIterator.next());
      Collections.sort(localArrayList);
      localParseInstallation.addAllUnique("channels", localArrayList);
      localParseInstallation.saveEventually();
    }
    try
    {
      JSONObject localJSONObject2 = new JSONObject();
      localJSONObject2.put("version", 3);
      localJSONObject2.put("routes", localJSONObject1);
      localJSONObject2.put("channels", getChannelsArrayFromInstallation(localParseInstallation));
      Parse.saveDiskObject(Parse.applicationContext, paramString2, localJSONObject2);
      localObject = localJSONObject2;
      if (!paramString1.equals(paramString2))
        Parse.deleteDiskObject(Parse.applicationContext, paramString1);
      return localObject;
    }
    catch (JSONException localJSONException)
    {
      while (true)
      {
        Parse.logE("com.parse.ParsePushRouter", "Unexpected JSONException when serializing upgraded v1 push state: ", localJSONException);
        localObject = null;
      }
    }
  }

  static JSONObject migrateV2toV3(String paramString1, String paramString2)
  {
    ParseInstallation localParseInstallation = ParseInstallation.getCurrentInstallation();
    JSONObject localJSONObject1 = Parse.getDiskObject(Parse.applicationContext, paramString1);
    JSONObject localJSONObject2 = null;
    if (localJSONObject1 != null)
    {
      if (localJSONObject1.optInt("version") != 2)
        break label307;
      Parse.logD("com.parse.ParsePushRouter", "Migrating push state from V2 to V3: " + localJSONObject1);
      JSONArray localJSONArray1 = localJSONObject1.optJSONArray("addChannels");
      if (localJSONArray1 != null)
      {
        ArrayList localArrayList1 = new ArrayList();
        for (int j = 0; j < localJSONArray1.length(); j++)
          localArrayList1.add(localJSONArray1.optString(j));
        localParseInstallation.addAllUnique("channels", localArrayList1);
        localParseInstallation.saveEventually();
      }
      JSONArray localJSONArray2 = localJSONObject1.optJSONArray("removeChannels");
      if (localJSONArray2 != null)
      {
        ArrayList localArrayList2 = new ArrayList();
        for (int k = 0; k < localJSONArray2.length(); k++)
          localArrayList2.add(localJSONArray2.optString(k));
        localParseInstallation.removeAll("channels", localArrayList2);
        localParseInstallation.saveEventually();
      }
      if (localJSONObject1.has("installation"))
      {
        localParseInstallation.mergeFromDiskJSON(localJSONObject1.optJSONObject("installation"));
        localParseInstallation.saveEventually();
      }
    }
    label307: int i;
    do
    {
      try
      {
        localJSONObject1.put("version", 3);
        localJSONObject1.remove("addChannels");
        localJSONObject1.remove("removeChannels");
        localJSONObject1.remove("installation");
        localJSONObject1.put("channels", getChannelsArrayFromInstallation(localParseInstallation));
        Parse.saveDiskObject(Parse.applicationContext, paramString2, localJSONObject1);
        localJSONObject2 = localJSONObject1;
        if (!paramString1.equals(paramString2))
          Parse.deleteDiskObject(Parse.applicationContext, paramString1);
        return localJSONObject2;
      }
      catch (JSONException localJSONException)
      {
        while (true)
        {
          Parse.logE("com.parse.ParsePushRouter", "Unexpected JSONException when serializing upgraded v2 push state: ", localJSONException);
          localJSONObject2 = null;
        }
      }
      i = localJSONObject1.optInt("version");
      localJSONObject2 = null;
    }
    while (i != 3);
    return localJSONObject1;
  }

  static void noteHandlePushResult(JSONObject paramJSONObject, HandlePushResult paramHandlePushResult)
  {
    monitorenter;
    try
    {
      PushListener localPushListener = pushListener;
      monitorexit;
      if (localPushListener != null)
        getLastTask().continueWith(new Continuation(localPushListener, paramJSONObject, paramHandlePushResult)
        {
          public Void then(Task<Void> paramTask)
          {
            this.val$finalListener.onPushHandled(this.val$pushData, this.val$result);
            return null;
          }
        }
        , EXECUTOR);
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public static Task<Void> reloadFromDiskAsync(boolean paramBoolean)
  {
    monitorenter;
    try
    {
      Task localTask = getLastTask().onSuccess(new Continuation(paramBoolean)
      {
        public Void then(Task<Void> paramTask)
        {
          PushRouter.access$200(this.val$removeExistingState);
          return null;
        }
      }
      , EXECUTOR);
      lastTask = makeUnhandledExceptionsFatal(localTask);
      return localTask;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  private static PushRouter reloadInstance(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      Parse.deleteDiskObject(Parse.applicationContext, "persistentCallbacks");
      Parse.deleteDiskObject(Parse.applicationContext, "pushState");
    }
    instance = null;
    return getInstance();
  }

  private Date serverInstallationUpdatedAt(JSONObject paramJSONObject)
  {
    String str = paramJSONObject.optString("installation_updated_at", null);
    Date localDate = null;
    if (str != null)
      localDate = Parse.stringToDate(str);
    return localDate;
  }

  public static Task<Void> setForceEnabledAsync(Boolean paramBoolean)
  {
    monitorenter;
    try
    {
      Task localTask = getLastTask().onSuccess(new Continuation(paramBoolean)
      {
        public Void then(Task<Void> paramTask)
        {
          PushRouter.access$000().setForceEnabledState(this.val$forceEnabled);
          return null;
        }
      }
      , EXECUTOR);
      lastTask = makeUnhandledExceptionsFatal(localTask);
      return localTask;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  static void setGlobalPushListener(PushListener paramPushListener)
  {
    monitorenter;
    try
    {
      pushListener = paramPushListener;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public static Task<Void> subscribeAsync(String paramString, Class<? extends Activity> paramClass, int paramInt)
  {
    if ((paramString != null) && (!PushRoutes.isValidChannelName(paramString)))
      throw new IllegalArgumentException("Invalid channel name: + " + paramString + " (must be empty " + "string or a letter followed by alphanumerics or hyphen)");
    if (paramClass == null)
      throw new IllegalArgumentException("Can't subscribe to channel with null activity class.");
    if (paramInt == 0)
      throw new IllegalArgumentException("Must subscribe to channel with a valid icon identifier.");
    monitorenter;
    try
    {
      Task localTask = getLastTask().onSuccess(new Continuation(paramString, paramClass, paramInt)
      {
        public Void then(Task<Void> paramTask)
        {
          PushRouter.access$000().subscribe(this.val$channel, this.val$cls, this.val$iconId);
          return null;
        }
      }
      , EXECUTOR);
      lastTask = makeUnhandledExceptionsFatal(localTask);
      return localTask;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public static Task<Void> unsubscribeAsync(String paramString)
  {
    monitorenter;
    try
    {
      Task localTask = getLastTask().onSuccess(new Continuation(paramString)
      {
        public Void then(Task<Void> paramTask)
        {
          PushRouter.access$000().unsubscribe(this.val$channel);
          return null;
        }
      }
      , EXECUTOR);
      lastTask = makeUnhandledExceptionsFatal(localTask);
      return localTask;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public static Task<Void> wipeRoutingAndUpgradePushStateAsync()
  {
    monitorenter;
    try
    {
      Task localTask = getLastTask().onSuccess(new Continuation()
      {
        public Void then(Task<Void> paramTask)
          throws Exception
        {
          PushRouter.access$000().setPushStateVersion(PushRouter.V2_PUSH_STATE_VERSION.intValue());
          return null;
        }
      }
      , EXECUTOR);
      lastTask = makeUnhandledExceptionsFatal(localTask);
      return localTask;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  // ERROR //
  JSONObject convertGcmIntentToJSONObject(Intent paramIntent)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnull +50 -> 51
    //   4: aload_1
    //   5: ldc_w 580
    //   8: invokevirtual 584	android/content/Intent:getStringExtra	(Ljava/lang/String;)Ljava/lang/String;
    //   11: astore_2
    //   12: aload_2
    //   13: ifnull +40 -> 53
    //   16: ldc 22
    //   18: new 313	java/lang/StringBuilder
    //   21: dup
    //   22: invokespecial 314	java/lang/StringBuilder:<init>	()V
    //   25: ldc_w 586
    //   28: invokevirtual 320	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   31: aload_2
    //   32: invokevirtual 320	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: ldc_w 588
    //   38: invokevirtual 320	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: aload_1
    //   42: invokevirtual 323	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   45: invokevirtual 324	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   48: invokestatic 591	com/parse/Parse:logI	(Ljava/lang/String;Ljava/lang/String;)V
    //   51: aconst_null
    //   52: areturn
    //   53: aload_1
    //   54: ldc 237
    //   56: invokevirtual 584	android/content/Intent:getStringExtra	(Ljava/lang/String;)Ljava/lang/String;
    //   59: astore_3
    //   60: aload_1
    //   61: ldc 244
    //   63: invokevirtual 584	android/content/Intent:getStringExtra	(Ljava/lang/String;)Ljava/lang/String;
    //   66: astore 4
    //   68: aload_1
    //   69: ldc_w 531
    //   72: invokevirtual 584	android/content/Intent:getStringExtra	(Ljava/lang/String;)Ljava/lang/String;
    //   75: astore 5
    //   77: iconst_0
    //   78: istore 6
    //   80: aconst_null
    //   81: astore 7
    //   83: aload_3
    //   84: ifnull +17 -> 101
    //   87: new 183	org/json/JSONObject
    //   90: dup
    //   91: aload_3
    //   92: invokespecial 592	org/json/JSONObject:<init>	(Ljava/lang/String;)V
    //   95: astore 13
    //   97: aload 13
    //   99: astore 7
    //   101: iload 6
    //   103: ifne -52 -> 51
    //   106: new 183	org/json/JSONObject
    //   109: dup
    //   110: invokespecial 242	org/json/JSONObject:<init>	()V
    //   113: astore 8
    //   115: aload 8
    //   117: ldc 237
    //   119: aload 7
    //   121: invokevirtual 595	org/json/JSONObject:putOpt	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   124: pop
    //   125: aload 8
    //   127: ldc 244
    //   129: aload 4
    //   131: invokevirtual 595	org/json/JSONObject:putOpt	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   134: pop
    //   135: aload 8
    //   137: ldc_w 531
    //   140: aload 5
    //   142: invokevirtual 595	org/json/JSONObject:putOpt	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   145: pop
    //   146: aload 8
    //   148: areturn
    //   149: astore 14
    //   151: ldc 22
    //   153: new 313	java/lang/StringBuilder
    //   156: dup
    //   157: invokespecial 314	java/lang/StringBuilder:<init>	()V
    //   160: ldc_w 597
    //   163: invokevirtual 320	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: aload_3
    //   167: invokevirtual 320	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: invokevirtual 324	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   173: aload 14
    //   175: invokestatic 482	com/parse/Parse:logE	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   178: iconst_1
    //   179: istore 6
    //   181: aconst_null
    //   182: astore 7
    //   184: goto -83 -> 101
    //   187: astore 9
    //   189: ldc 22
    //   191: ldc_w 599
    //   194: aload 9
    //   196: invokestatic 482	com/parse/Parse:logE	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   199: aconst_null
    //   200: areturn
    //   201: astore 9
    //   203: goto -14 -> 189
    //
    // Exception table:
    //   from	to	target	type
    //   87	97	149	org/json/JSONException
    //   106	115	187	org/json/JSONException
    //   115	146	201	org/json/JSONException
  }

  public JSONObject getPushRequestJSON()
  {
    JSONObject localJSONObject = new JSONObject();
    ParseInstallation localParseInstallation = ParseInstallation.getCurrentInstallation();
    try
    {
      localJSONObject.put("installation_id", localParseInstallation.getInstallationId());
      localJSONObject.put("oauth_key", ParseObject.getApplicationId());
      localJSONObject.put("v", "a1.9.1");
      Object localObject = this.history.getLastReceivedTimestamp();
      if (localObject != null);
      while (true)
      {
        localJSONObject.put("last", localObject);
        Set localSet = this.history.getPushIds();
        if (localSet.size() > 0)
          localJSONObject.put("last_seen", new JSONArray(localSet));
        localJSONObject.put("ack_keep_alive", true);
        localJSONObject.putOpt("ignore_after", this.history.getCutoffTimestamp());
        return localJSONObject;
        localObject = JSONObject.NULL;
      }
    }
    catch (JSONException localJSONException)
    {
      Parse.logE("com.parse.ParsePushRouter", "Unexpected JSONException serializing push handshake", localJSONException);
    }
    return (JSONObject)null;
  }

  public Set<String> getSubscriptions(boolean paramBoolean)
  {
    HashSet localHashSet = new HashSet();
    List localList = ParseInstallation.getCurrentInstallation().getList("channels");
    if (localList != null)
      localHashSet.addAll(localList);
    localHashSet.addAll(this.routes.getChannels());
    if (!paramBoolean)
      localHashSet.remove(null);
    return Collections.unmodifiableSet(localHashSet);
  }

  public HandlePushResult handleGcmPush(Intent paramIntent)
  {
    JSONObject localJSONObject = convertGcmIntentToJSONObject(paramIntent);
    if (localJSONObject != null)
      return handlePush(localJSONObject);
    return HandlePushResult.INVALID_DATA;
  }

  public HandlePushResult handlePpnsPush(JSONObject paramJSONObject)
  {
    HandlePushResult localHandlePushResult = HandlePushResult.FAILED_HISTORY_TEST;
    String str1 = paramJSONObject.optString("push_id", null);
    String str2 = paramJSONObject.optString("time", null);
    if ((str2 != null) && (this.history.tryInsertPush(str1, str2)))
    {
      localHandlePushResult = handlePush(paramJSONObject);
      saveStateToDisk();
    }
    return localHandlePushResult;
  }

  public HandlePushResult handlePush(JSONObject paramJSONObject)
  {
    if (ManifestInfo.getPushUsesBroadcastReceivers())
      handlePushInternal(paramJSONObject);
    for (HandlePushResult localHandlePushResult = HandlePushResult.INVOKED_PARSE_PUSH_BROADCAST_RECEIVER; ; localHandlePushResult = handlePushLegacy(paramJSONObject))
    {
      maybeRefreshInstallation(serverInstallationUpdatedAt(paramJSONObject));
      noteHandlePushResult(paramJSONObject, localHandlePushResult);
      return localHandlePushResult;
    }
  }

  public boolean saveStateToDisk()
  {
    try
    {
      JSONObject localJSONObject = toJSON();
      Parse.saveDiskObject(Parse.applicationContext, this.stateLocation, localJSONObject);
      return true;
    }
    catch (JSONException localJSONException)
    {
      Parse.logE("com.parse.ParsePushRouter", "Error serializing push state to json", localJSONException);
    }
    return false;
  }

  public void setForceEnabledState(Boolean paramBoolean)
  {
    Boolean localBoolean = this.forceEnabled;
    if ((localBoolean != null) && (localBoolean == paramBoolean))
      return;
    this.forceEnabled = paramBoolean;
    saveStateToDisk();
  }

  public void setPushStateVersion(int paramInt)
  {
    if (paramInt != this.pushStateVersion)
    {
      this.pushStateVersion = paramInt;
      saveStateToDisk();
    }
  }

  public void subscribe(String paramString, Class<? extends Activity> paramClass, int paramInt)
  {
    ParseInstallation localParseInstallation = ParseInstallation.getCurrentInstallation();
    PushRoutes.Route localRoute1 = new PushRoutes.Route(paramClass.getName(), paramInt);
    PushRoutes.Route localRoute2 = this.routes.put(paramString, localRoute1);
    if (!localRoute1.equals(localRoute2))
      saveStateToDisk();
    if ((localRoute2 == null) && (paramString != null))
      localParseInstallation.addUnique("channels", paramString);
    localParseInstallation.saveEventually();
  }

  public JSONObject toJSON()
    throws JSONException
  {
    JSONObject localJSONObject;
    if (V2_PUSH_STATE_VERSION.equals(Integer.valueOf(this.pushStateVersion)))
      localJSONObject = this.history.toJSON();
    while (true)
    {
      localJSONObject.put("version", this.pushStateVersion);
      localJSONObject.putOpt("forceEnabled", this.forceEnabled);
      return localJSONObject;
      JSONObject[] arrayOfJSONObject = new JSONObject[2];
      arrayOfJSONObject[0] = this.routes.toJSON();
      arrayOfJSONObject[1] = this.history.toJSON();
      localJSONObject = merge(arrayOfJSONObject);
      localJSONObject.put("channels", getChannelsArrayFromInstallation(ParseInstallation.getCurrentInstallation()));
    }
  }

  public void unsubscribe(String paramString)
  {
    if (this.routes.remove(paramString) != null)
    {
      saveStateToDisk();
      if (paramString != null)
      {
        ParseInstallation localParseInstallation = ParseInstallation.getCurrentInstallation();
        localParseInstallation.removeAll("channels", Arrays.asList(new String[] { paramString }));
        localParseInstallation.saveEventually();
      }
    }
  }

  static enum HandlePushResult
  {
    static
    {
      FAILED_HISTORY_TEST = new HandlePushResult("FAILED_HISTORY_TEST", 1);
      NO_ROUTE_FOUND = new HandlePushResult("NO_ROUTE_FOUND", 2);
      INVALID_ROUTE = new HandlePushResult("INVALID_ROUTE", 3);
      BROADCAST_INTENT = new HandlePushResult("BROADCAST_INTENT", 4);
      SHOW_NOTIFICATION = new HandlePushResult("SHOW_NOTIFICATION", 5);
      SHOW_NOTIFICATION_AND_BROADCAST_INTENT = new HandlePushResult("SHOW_NOTIFICATION_AND_BROADCAST_INTENT", 6);
      INVOKED_PARSE_PUSH_BROADCAST_RECEIVER = new HandlePushResult("INVOKED_PARSE_PUSH_BROADCAST_RECEIVER", 7);
      HandlePushResult[] arrayOfHandlePushResult = new HandlePushResult[8];
      arrayOfHandlePushResult[0] = INVALID_DATA;
      arrayOfHandlePushResult[1] = FAILED_HISTORY_TEST;
      arrayOfHandlePushResult[2] = NO_ROUTE_FOUND;
      arrayOfHandlePushResult[3] = INVALID_ROUTE;
      arrayOfHandlePushResult[4] = BROADCAST_INTENT;
      arrayOfHandlePushResult[5] = SHOW_NOTIFICATION;
      arrayOfHandlePushResult[6] = SHOW_NOTIFICATION_AND_BROADCAST_INTENT;
      arrayOfHandlePushResult[7] = INVOKED_PARSE_PUSH_BROADCAST_RECEIVER;
      $VALUES = arrayOfHandlePushResult;
    }
  }

  static abstract interface PushListener
  {
    public abstract void onPushHandled(JSONObject paramJSONObject, PushRouter.HandlePushResult paramHandlePushResult);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     com.parse.PushRouter
 * JD-Core Version:    0.6.0
 */