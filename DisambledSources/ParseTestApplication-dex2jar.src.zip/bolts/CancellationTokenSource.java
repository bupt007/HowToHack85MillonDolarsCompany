package bolts;

import java.util.Locale;

public class CancellationTokenSource
{
  private final CancellationToken token = new CancellationToken();

  public void cancel()
  {
    this.token.tryCancel();
  }

  public CancellationToken getToken()
  {
    return this.token;
  }

  public boolean isCancellationRequested()
  {
    return this.token.isCancellationRequested();
  }

  public String toString()
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = getClass().getName();
    arrayOfObject[1] = Integer.toHexString(hashCode());
    arrayOfObject[2] = Boolean.toString(isCancellationRequested());
    return String.format(localLocale, "%s@%s[cancellationRequested=%s]", arrayOfObject);
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     bolts.CancellationTokenSource
 * JD-Core Version:    0.6.0
 */