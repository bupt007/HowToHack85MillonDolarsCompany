package bolts;

import java.util.Locale;
import java.util.concurrent.CancellationException;

public class CancellationToken
{
  private boolean cancellationRequested;
  private final Object lock = new Object();

  public boolean isCancellationRequested()
  {
    synchronized (this.lock)
    {
      boolean bool = this.cancellationRequested;
      return bool;
    }
  }

  public void throwIfCancellationRequested()
    throws CancellationException
  {
    synchronized (this.lock)
    {
      if (this.cancellationRequested)
        throw new CancellationException();
    }
    monitorexit;
  }

  public String toString()
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = getClass().getName();
    arrayOfObject[1] = Integer.toHexString(hashCode());
    arrayOfObject[2] = Boolean.toString(this.cancellationRequested);
    return String.format(localLocale, "%s@%s[cancellationRequested=%s]", arrayOfObject);
  }

  boolean tryCancel()
  {
    synchronized (this.lock)
    {
      if (this.cancellationRequested)
        return false;
      this.cancellationRequested = true;
      return true;
    }
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     bolts.CancellationToken
 * JD-Core Version:    0.6.0
 */