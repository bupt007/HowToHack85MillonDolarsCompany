package bolts;

import android.content.Context;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map<Ljava.lang.String;Ljava.lang.Object;>;
import java.util.concurrent.Callable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class WebViewAppLinkResolver
  implements AppLinkResolver
{
  private static final String KEY_AL_VALUE = "value";
  private static final String KEY_ANDROID = "android";
  private static final String KEY_APP_NAME = "app_name";
  private static final String KEY_CLASS = "class";
  private static final String KEY_PACKAGE = "package";
  private static final String KEY_SHOULD_FALLBACK = "should_fallback";
  private static final String KEY_URL = "url";
  private static final String KEY_WEB = "web";
  private static final String KEY_WEB_URL = "url";
  private static final String META_TAG_PREFIX = "al";
  private static final String PREFER_HEADER = "Prefer-Html-Meta-Tags";
  private static final String TAG_EXTRACTION_JAVASCRIPT = "javascript:boltsWebViewAppLinkResolverResult.setValue((function() {  var metaTags = document.getElementsByTagName('meta');  var results = [];  for (var i = 0; i < metaTags.length; i++) {    var property = metaTags[i].getAttribute('property');    if (property && property.substring(0, 'al:'.length) === 'al:') {      var tag = { \"property\": metaTags[i].getAttribute('property') };      if (metaTags[i].hasAttribute('content')) {        tag['content'] = metaTags[i].getAttribute('content');      }      results.push(tag);    }  }  return JSON.stringify(results);})())";
  private final Context context;

  public WebViewAppLinkResolver(Context paramContext)
  {
    this.context = paramContext;
  }

  private static List<Map<String, Object>> getAlList(Map<String, Object> paramMap, String paramString)
  {
    List localList = (List)paramMap.get(paramString);
    if (localList == null)
      localList = Collections.emptyList();
    return localList;
  }

  private static AppLink makeAppLinkFromAlData(Map<String, Object> paramMap, Uri paramUri)
  {
    ArrayList localArrayList = new ArrayList();
    List localList1 = (List)paramMap.get("android");
    if (localList1 == null)
      localList1 = Collections.emptyList();
    Iterator localIterator = localList1.iterator();
    if (localIterator.hasNext())
    {
      Map localMap2 = (Map)localIterator.next();
      List localList5 = getAlList(localMap2, "url");
      List localList6 = getAlList(localMap2, "package");
      List localList7 = getAlList(localMap2, "class");
      List localList8 = getAlList(localMap2, "app_name");
      int i = Math.max(localList5.size(), Math.max(localList6.size(), Math.max(localList7.size(), localList8.size())));
      int j = 0;
      label136: Object localObject1;
      label176: Uri localUri2;
      Object localObject2;
      label222: String str2;
      Object localObject3;
      label265: String str3;
      if (j < i)
      {
        if (localList5.size() <= j)
          break label350;
        localObject1 = ((Map)localList5.get(j)).get("value");
        localUri2 = tryCreateUrl((String)(String)localObject1);
        if (localList6.size() <= j)
          break label356;
        localObject2 = ((Map)localList6.get(j)).get("value");
        str2 = (String)(String)localObject2;
        if (localList7.size() <= j)
          break label362;
        localObject3 = ((Map)localList7.get(j)).get("value");
        str3 = (String)(String)localObject3;
        if (localList8.size() <= j)
          break label368;
      }
      label350: label356: label362: label368: for (Object localObject4 = ((Map)localList8.get(j)).get("value"); ; localObject4 = null)
      {
        String str4 = (String)(String)localObject4;
        AppLink.Target localTarget = new AppLink.Target(str2, str3, localUri2, str4);
        localArrayList.add(localTarget);
        j++;
        break label136;
        break;
        localObject1 = null;
        break label176;
        localObject2 = null;
        break label222;
        localObject3 = null;
        break label265;
      }
    }
    Uri localUri1 = paramUri;
    List localList2 = (List)paramMap.get("web");
    if ((localList2 != null) && (localList2.size() > 0))
    {
      Map localMap1 = (Map)localList2.get(0);
      List localList3 = (List)localMap1.get("url");
      List localList4 = (List)localMap1.get("should_fallback");
      if ((localList4 != null) && (localList4.size() > 0))
      {
        String str1 = (String)((Map)localList4.get(0)).get("value");
        if (Arrays.asList(new String[] { "no", "false", "0" }).contains(str1.toLowerCase()))
          localUri1 = null;
      }
      if ((localUri1 != null) && (localList3 != null) && (localList3.size() > 0))
        localUri1 = tryCreateUrl((String)((Map)localList3.get(0)).get("value"));
    }
    AppLink localAppLink = new AppLink(paramUri, localArrayList, localUri1);
    return localAppLink;
  }

  private static Map<String, Object> parseAlData(JSONArray paramJSONArray)
    throws JSONException
  {
    HashMap localHashMap = new HashMap();
    int i = 0;
    if (i < paramJSONArray.length())
    {
      JSONObject localJSONObject = paramJSONArray.getJSONObject(i);
      String[] arrayOfString = localJSONObject.getString("property").split(":");
      if (!arrayOfString[0].equals("al"));
      while (true)
      {
        i++;
        break;
        Object localObject1 = localHashMap;
        int j = 1;
        if (j < arrayOfString.length)
        {
          Object localObject2 = (List)((Map)localObject1).get(arrayOfString[j]);
          if (localObject2 == null)
          {
            localObject2 = new ArrayList();
            ((Map)localObject1).put(arrayOfString[j], localObject2);
          }
          if (((List)localObject2).size() > 0);
          for (Object localObject3 = (Map)((List)localObject2).get(-1 + ((List)localObject2).size()); ; localObject3 = null)
          {
            if ((localObject3 == null) || (j == -1 + arrayOfString.length))
            {
              localObject3 = new HashMap();
              ((List)localObject2).add(localObject3);
            }
            localObject1 = localObject3;
            j++;
            break;
          }
        }
        if (!localJSONObject.has("content"))
          continue;
        if (localJSONObject.isNull("content"))
        {
          ((Map)localObject1).put("value", null);
          continue;
        }
        ((Map)localObject1).put("value", localJSONObject.getString("content"));
      }
    }
    return (Map<String, Object>)(Map<String, Object>)(Map<String, Object>)localHashMap;
  }

  private static String readFromConnection(URLConnection paramURLConnection)
    throws IOException
  {
    HttpURLConnection localHttpURLConnection;
    if ((paramURLConnection instanceof HttpURLConnection))
      localHttpURLConnection = (HttpURLConnection)paramURLConnection;
    InputStream localInputStream1;
    ByteArrayOutputStream localByteArrayOutputStream;
    while (true)
    {
      try
      {
        InputStream localInputStream2 = paramURLConnection.getInputStream();
        localInputStream1 = localInputStream2;
        try
        {
          localByteArrayOutputStream = new ByteArrayOutputStream();
          byte[] arrayOfByte = new byte[1024];
          int i = localInputStream1.read(arrayOfByte);
          if (i == -1)
            break;
          localByteArrayOutputStream.write(arrayOfByte, 0, i);
          continue;
        }
        finally
        {
          localInputStream1.close();
        }
      }
      catch (Exception localException)
      {
        localInputStream1 = localHttpURLConnection.getErrorStream();
        continue;
      }
      localInputStream1 = paramURLConnection.getInputStream();
    }
    String str1 = paramURLConnection.getContentEncoding();
    int k;
    if (str1 == null)
    {
      String[] arrayOfString = paramURLConnection.getContentType().split(";");
      int j = arrayOfString.length;
      k = 0;
      if (k >= j)
        break label189;
      String str2 = arrayOfString[k].trim();
      if (!str2.startsWith("charset="))
        break label183;
      str1 = str2.substring("charset=".length());
      break label189;
    }
    while (true)
    {
      String str3 = new String(localByteArrayOutputStream.toByteArray(), str1);
      localInputStream1.close();
      return str3;
      label183: k++;
      break;
      label189: if (str1 != null)
        continue;
      str1 = "UTF-8";
    }
  }

  private static Uri tryCreateUrl(String paramString)
  {
    if (paramString == null)
      return null;
    return Uri.parse(paramString);
  }

  public Task<AppLink> getAppLinkFromUrlInBackground(Uri paramUri)
  {
    Capture localCapture1 = new Capture();
    Capture localCapture2 = new Capture();
    return Task.callInBackground(new Callable(paramUri, localCapture1, localCapture2)
    {
      public Void call()
        throws Exception
      {
        URL localURL = new URL(this.val$url.toString());
        URLConnection localURLConnection = null;
        while (localURL != null)
        {
          localURLConnection = localURL.openConnection();
          if ((localURLConnection instanceof HttpURLConnection))
            ((HttpURLConnection)localURLConnection).setInstanceFollowRedirects(true);
          localURLConnection.setRequestProperty("Prefer-Html-Meta-Tags", "al");
          localURLConnection.connect();
          if ((localURLConnection instanceof HttpURLConnection))
          {
            HttpURLConnection localHttpURLConnection = (HttpURLConnection)localURLConnection;
            if ((localHttpURLConnection.getResponseCode() >= 300) && (localHttpURLConnection.getResponseCode() < 400))
            {
              localURL = new URL(localHttpURLConnection.getHeaderField("Location"));
              localHttpURLConnection.disconnect();
              continue;
            }
            localURL = null;
            continue;
          }
          localURL = null;
        }
        try
        {
          this.val$content.set(WebViewAppLinkResolver.access$300(localURLConnection));
          this.val$contentType.set(localURLConnection.getContentType());
          return null;
        }
        finally
        {
          if ((localURLConnection instanceof HttpURLConnection))
            ((HttpURLConnection)localURLConnection).disconnect();
        }
        throw localObject;
      }
    }).onSuccessTask(new Continuation(localCapture2, paramUri, localCapture1)
    {
      public Task<JSONArray> then(Task<Void> paramTask)
        throws Exception
      {
        Task.TaskCompletionSource localTaskCompletionSource = Task.create();
        WebView localWebView = new WebView(WebViewAppLinkResolver.this.context);
        localWebView.getSettings().setJavaScriptEnabled(true);
        localWebView.setNetworkAvailable(false);
        localWebView.setWebViewClient(new WebViewClient()
        {
          private boolean loaded = false;

          private void runJavaScript(WebView paramWebView)
          {
            if (!this.loaded)
            {
              this.loaded = true;
              paramWebView.loadUrl("javascript:boltsWebViewAppLinkResolverResult.setValue((function() {  var metaTags = document.getElementsByTagName('meta');  var results = [];  for (var i = 0; i < metaTags.length; i++) {    var property = metaTags[i].getAttribute('property');    if (property && property.substring(0, 'al:'.length) === 'al:') {      var tag = { \"property\": metaTags[i].getAttribute('property') };      if (metaTags[i].hasAttribute('content')) {        tag['content'] = metaTags[i].getAttribute('content');      }      results.push(tag);    }  }  return JSON.stringify(results);})())");
            }
          }

          public void onLoadResource(WebView paramWebView, String paramString)
          {
            super.onLoadResource(paramWebView, paramString);
            runJavaScript(paramWebView);
          }

          public void onPageFinished(WebView paramWebView, String paramString)
          {
            super.onPageFinished(paramWebView, paramString);
            runJavaScript(paramWebView);
          }
        });
        localWebView.addJavascriptInterface(new Object(localTaskCompletionSource)
        {
          @JavascriptInterface
          public void setValue(String paramString)
          {
            try
            {
              this.val$tcs.trySetResult(new JSONArray(paramString));
              return;
            }
            catch (JSONException localJSONException)
            {
              this.val$tcs.trySetError(localJSONException);
            }
          }
        }
        , "boltsWebViewAppLinkResolverResult");
        Object localObject = this.val$contentType.get();
        String str = null;
        if (localObject != null)
          str = ((String)this.val$contentType.get()).split(";")[0];
        localWebView.loadDataWithBaseURL(this.val$url.toString(), (String)this.val$content.get(), str, null, null);
        return localTaskCompletionSource.getTask();
      }
    }
    , Task.UI_THREAD_EXECUTOR).onSuccess(new Continuation(paramUri)
    {
      public AppLink then(Task<JSONArray> paramTask)
        throws Exception
      {
        return WebViewAppLinkResolver.access$100(WebViewAppLinkResolver.access$000((JSONArray)paramTask.getResult()), this.val$url);
      }
    });
  }
}

/* Location:           E:\disambler\ParseTestApplication-dex2jar.jar
 * Qualified Name:     bolts.WebViewAppLinkResolver
 * JD-Core Version:    0.6.0
 */