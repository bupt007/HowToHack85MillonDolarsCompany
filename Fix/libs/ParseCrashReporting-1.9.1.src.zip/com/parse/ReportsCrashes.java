package com.parse;

import android.content.Context;

abstract interface ReportsCrashes
{
  public abstract boolean includeDropBoxSystemTags();

  public abstract String[] additionalDropBoxTags();

  public abstract int dropboxCollectionMinutes();

  public abstract String[] logcatArguments();

  public abstract String formPostFormat();

  public abstract int socketTimeout();

  public abstract boolean checkSSLCertsOnCrashReport();

  public abstract Context getApplicationContext();
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ReportsCrashes
 * JD-Core Version:    0.6.0
 */