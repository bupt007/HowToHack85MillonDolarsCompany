/*     */ package com.parse;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ class BoundedLinkedList<E> extends LinkedList<E>
/*     */ {
/*  38 */   private int maxSize = -1;
/*     */ 
/*     */   public BoundedLinkedList(int maxSize)
/*     */   {
/*  42 */     this.maxSize = maxSize;
/*     */   }
/*     */ 
/*     */   public boolean add(E object)
/*     */   {
/*  52 */     if (size() == this.maxSize) {
/*  53 */       removeFirst();
/*     */     }
/*  55 */     return super.add(object);
/*     */   }
/*     */ 
/*     */   public void add(int location, E object)
/*     */   {
/*  65 */     if (size() == this.maxSize) {
/*  66 */       removeFirst();
/*     */     }
/*  68 */     super.add(location, object);
/*     */   }
/*     */ 
/*     */   public boolean addAll(Collection<? extends E> collection)
/*     */   {
/*  78 */     int totalNeededSize = size() + collection.size();
/*  79 */     int overhead = totalNeededSize - this.maxSize;
/*  80 */     if (overhead > 0) {
/*  81 */       removeRange(0, overhead);
/*     */     }
/*  83 */     return super.addAll(collection);
/*     */   }
/*     */ 
/*     */   public boolean addAll(int location, Collection<? extends E> collection)
/*     */   {
/*  99 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void addFirst(E object)
/*     */   {
/* 110 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void addLast(E object)
/*     */   {
/* 120 */     add(object);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 130 */     StringBuilder result = new StringBuilder();
/*     */ 
/* 132 */     for (Iterator i$ = iterator(); i$.hasNext(); ) { Object object = i$.next();
/* 133 */       result.append(object.toString());
/*     */     }
/*     */ 
/* 136 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.BoundedLinkedList
 * JD-Core Version:    0.6.0
 */