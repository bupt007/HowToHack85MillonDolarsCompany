/*     */ package com.parse;
/*     */ 
/*     */ import android.os.SystemClock;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Queue;
/*     */ 
/*     */ class SimpleTraceLogger
/*     */ {
/*     */   public static final String TAG = "SimpleTraceLogger";
/*  20 */   public static int NO_LIMIT = 0;
/*     */   protected final int mTraceCountLimit;
/*     */   private Queue<TraceLogLine> mTrace;
/*     */ 
/*     */   public SimpleTraceLogger(int traceCountLimit)
/*     */   {
/*  48 */     this.mTraceCountLimit = traceCountLimit;
/*  49 */     clear();
/*     */   }
/*     */ 
/*     */   public void append(String str, Object[] args)
/*     */   {
/*  59 */     append(String.format(str, args));
/*     */   }
/*     */ 
/*     */   public void append(String str)
/*     */   {
/*  68 */     synchronized (this) {
/*  69 */       if ((this.mTraceCountLimit > NO_LIMIT) && 
/*  70 */         (this.mTrace.size() == this.mTraceCountLimit)) {
/*  71 */         this.mTrace.remove();
/*     */       }
/*     */ 
/*  75 */       this.mTrace.offer(new TraceLogLine(str, SystemClock.elapsedRealtime()));
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized String toString()
/*     */   {
/*  85 */     return toString(NO_LIMIT);
/*     */   }
/*     */ 
/*     */   public synchronized String toString(int limit)
/*     */   {
/*  96 */     StringBuilder retval = new StringBuilder();
/*     */     int startFrom;
/*     */     int startFrom;
/*  98 */     if (limit <= NO_LIMIT)
/*  99 */       startFrom = 0;
/*     */     else {
/* 101 */       startFrom = Math.max(this.mTrace.size() - limit, 0);
/*     */     }
/* 103 */     int index = 0;
/* 104 */     for (TraceLogLine line : this.mTrace) {
/* 105 */       if (index >= startFrom) {
/* 106 */         retval.append(line.toString()).append('\n');
/*     */       }
/* 108 */       index++;
/*     */     }
/* 110 */     return retval.toString();
/*     */   }
/*     */ 
/*     */   public synchronized void clear()
/*     */   {
/* 117 */     this.mTrace = new LinkedList();
/*     */   }
/*     */ 
/*     */   protected static class TraceLogLine
/*     */   {
/*     */     public final String trace;
/*     */     public final long time;
/*     */ 
/*     */     TraceLogLine(String trace, long time)
/*     */     {
/*  28 */       this.trace = trace;
/*  29 */       this.time = time;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/*  34 */       return String.format("[%d] %s", new Object[] { Long.valueOf(this.time), this.trace });
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.SimpleTraceLogger
 * JD-Core Version:    0.6.0
 */