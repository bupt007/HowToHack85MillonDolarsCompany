/*     */ package com.parse;
/*     */ 
/*     */ import android.content.res.Configuration;
/*     */ import android.util.Log;
/*     */ import android.util.SparseArray;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ class ConfigurationInspector
/*     */ {
/*     */   private static final String SUFFIX_MASK = "_MASK";
/*     */   private static final String FIELD_SCREENLAYOUT = "screenLayout";
/*     */   private static final String FIELD_UIMODE = "uiMode";
/*     */   private static final String FIELD_MNC = "mnc";
/*     */   private static final String FIELD_MCC = "mcc";
/*     */   private static final String PREFIX_UI_MODE = "UI_MODE_";
/*     */   private static final String PREFIX_TOUCHSCREEN = "TOUCHSCREEN_";
/*     */   private static final String PREFIX_SCREENLAYOUT = "SCREENLAYOUT_";
/*     */   private static final String PREFIX_ORIENTATION = "ORIENTATION_";
/*     */   private static final String PREFIX_NAVIGATIONHIDDEN = "NAVIGATIONHIDDEN_";
/*     */   private static final String PREFIX_NAVIGATION = "NAVIGATION_";
/*     */   private static final String PREFIX_KEYBOARDHIDDEN = "KEYBOARDHIDDEN_";
/*     */   private static final String PREFIX_KEYBOARD = "KEYBOARD_";
/*     */   private static final String PREFIX_HARDKEYBOARDHIDDEN = "HARDKEYBOARDHIDDEN_";
/*  58 */   private static SparseArray<String> mHardKeyboardHiddenValues = new SparseArray();
/*  59 */   private static SparseArray<String> mKeyboardValues = new SparseArray();
/*  60 */   private static SparseArray<String> mKeyboardHiddenValues = new SparseArray();
/*  61 */   private static SparseArray<String> mNavigationValues = new SparseArray();
/*  62 */   private static SparseArray<String> mNavigationHiddenValues = new SparseArray();
/*  63 */   private static SparseArray<String> mOrientationValues = new SparseArray();
/*  64 */   private static SparseArray<String> mScreenLayoutValues = new SparseArray();
/*  65 */   private static SparseArray<String> mTouchScreenValues = new SparseArray();
/*  66 */   private static SparseArray<String> mUiModeValues = new SparseArray();
/*     */ 
/*  68 */   private static final HashMap<String, SparseArray<String>> mValueArrays = new HashMap();
/*     */ 
/*     */   public static String toString(Configuration conf)
/*     */   {
/* 124 */     StringBuilder result = new StringBuilder();
/* 125 */     for (Field f : conf.getClass().getFields()) {
/*     */       try {
/* 127 */         if (!Modifier.isStatic(f.getModifiers())) {
/* 128 */           String fieldName = f.getName();
/* 129 */           result.append(fieldName).append('=');
/* 130 */           if (f.getType().equals(Integer.TYPE)) {
/* 131 */             result.append(getFieldValueName(conf, f));
/*     */           } else {
/* 133 */             Object val = f.get(conf);
/* 134 */             if (val == null)
/* 135 */               result.append("null");
/*     */             else {
/* 137 */               result.append(f.get(conf).toString());
/*     */             }
/*     */           }
/* 140 */           result.append('\n');
/*     */         }
/*     */       } catch (IllegalArgumentException e) {
/* 143 */         Log.e("CrashReporting", "Error while inspecting device configuration: ", e);
/*     */       } catch (IllegalAccessException e) {
/* 145 */         Log.e("CrashReporting", "Error while inspecting device configuration: ", e);
/*     */       }
/*     */     }
/* 148 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private static String getFieldValueName(Configuration conf, Field f)
/*     */     throws IllegalArgumentException, IllegalAccessException
/*     */   {
/* 169 */     String fieldName = f.getName();
/* 170 */     if ((fieldName.equals("mcc")) || (fieldName.equals("mnc")))
/* 171 */       return Integer.toString(f.getInt(conf));
/* 172 */     if (fieldName.equals("uiMode"))
/* 173 */       return activeFlags((SparseArray)mValueArrays.get("UI_MODE_"), f.getInt(conf));
/* 174 */     if (fieldName.equals("screenLayout")) {
/* 175 */       return activeFlags((SparseArray)mValueArrays.get("SCREENLAYOUT_"), f.getInt(conf));
/*     */     }
/* 177 */     SparseArray values = (SparseArray)mValueArrays.get(new StringBuilder().append(fieldName.toUpperCase()).append('_').toString());
/* 178 */     if (values == null)
/*     */     {
/* 180 */       return Integer.toString(f.getInt(conf));
/*     */     }
/* 182 */     String value = (String)values.get(f.getInt(conf));
/* 183 */     if (value == null)
/*     */     {
/* 185 */       return Integer.toString(f.getInt(conf));
/*     */     }
/* 187 */     return value;
/*     */   }
/*     */ 
/*     */   private static String activeFlags(SparseArray<String> valueNames, int bitfield)
/*     */   {
/* 205 */     StringBuilder result = new StringBuilder();
/*     */ 
/* 208 */     for (int i = 0; i < valueNames.size(); i++) {
/* 209 */       int maskValue = valueNames.keyAt(i);
/* 210 */       if (((String)valueNames.get(maskValue)).endsWith("_MASK")) {
/* 211 */         int value = bitfield & maskValue;
/* 212 */         if (value > 0) {
/* 213 */           if (result.length() > 0) {
/* 214 */             result.append('+');
/*     */           }
/* 216 */           result.append((String)valueNames.get(value));
/*     */         }
/*     */       }
/*     */     }
/* 220 */     return result.toString();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  72 */     mValueArrays.put("HARDKEYBOARDHIDDEN_", mHardKeyboardHiddenValues);
/*  73 */     mValueArrays.put("KEYBOARD_", mKeyboardValues);
/*  74 */     mValueArrays.put("KEYBOARDHIDDEN_", mKeyboardHiddenValues);
/*  75 */     mValueArrays.put("NAVIGATION_", mNavigationValues);
/*  76 */     mValueArrays.put("NAVIGATIONHIDDEN_", mNavigationHiddenValues);
/*  77 */     mValueArrays.put("ORIENTATION_", mOrientationValues);
/*  78 */     mValueArrays.put("SCREENLAYOUT_", mScreenLayoutValues);
/*  79 */     mValueArrays.put("TOUCHSCREEN_", mTouchScreenValues);
/*  80 */     mValueArrays.put("UI_MODE_", mUiModeValues);
/*     */ 
/*  82 */     for (Field f : Configuration.class.getFields())
/*  83 */       if ((Modifier.isStatic(f.getModifiers())) && (Modifier.isFinal(f.getModifiers()))) {
/*  84 */         String fieldName = f.getName();
/*     */         try {
/*  86 */           if (fieldName.startsWith("HARDKEYBOARDHIDDEN_"))
/*  87 */             mHardKeyboardHiddenValues.put(f.getInt(null), fieldName);
/*  88 */           else if (fieldName.startsWith("KEYBOARD_"))
/*  89 */             mKeyboardValues.put(f.getInt(null), fieldName);
/*  90 */           else if (fieldName.startsWith("KEYBOARDHIDDEN_"))
/*  91 */             mKeyboardHiddenValues.put(f.getInt(null), fieldName);
/*  92 */           else if (fieldName.startsWith("NAVIGATION_"))
/*  93 */             mNavigationValues.put(f.getInt(null), fieldName);
/*  94 */           else if (fieldName.startsWith("NAVIGATIONHIDDEN_"))
/*  95 */             mNavigationHiddenValues.put(f.getInt(null), fieldName);
/*  96 */           else if (fieldName.startsWith("ORIENTATION_"))
/*  97 */             mOrientationValues.put(f.getInt(null), fieldName);
/*  98 */           else if (fieldName.startsWith("SCREENLAYOUT_"))
/*  99 */             mScreenLayoutValues.put(f.getInt(null), fieldName);
/* 100 */           else if (fieldName.startsWith("TOUCHSCREEN_"))
/* 101 */             mTouchScreenValues.put(f.getInt(null), fieldName);
/* 102 */           else if (fieldName.startsWith("UI_MODE_"))
/* 103 */             mUiModeValues.put(f.getInt(null), fieldName);
/*     */         }
/*     */         catch (IllegalArgumentException e) {
/* 106 */           Log.w("CrashReporting", "Error while inspecting device configuration: ", e);
/*     */         } catch (IllegalAccessException e) {
/* 108 */           Log.w("CrashReporting", "Error while inspecting device configuration: ", e);
/*     */         }
/*     */       }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ConfigurationInspector
 * JD-Core Version:    0.6.0
 */