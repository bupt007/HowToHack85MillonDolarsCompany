/*     */ package com.parse;
/*     */ 
/*     */  enum ReportField
/*     */ {
/*  36 */   REPORT_ID, 
/*     */ 
/*  40 */   ANDROID_ID, 
/*     */ 
/*  44 */   UID, 
/*     */ 
/*  50 */   APP_VERSION_CODE, 
/*     */ 
/*  54 */   APP_VERSION_NAME, 
/*     */ 
/*  58 */   PACKAGE_NAME, 
/*     */ 
/*  63 */   FILE_PATH, 
/*     */ 
/*  67 */   PHONE_MODEL, 
/*     */ 
/*  71 */   ANDROID_VERSION, 
/*     */ 
/*  75 */   OS_VERSION, 
/*     */ 
/*  79 */   IS_CYANOGENMOD, 
/*     */ 
/*  83 */   BUILD, 
/*     */ 
/*  87 */   BRAND, 
/*     */ 
/*  91 */   PRODUCT, 
/*     */ 
/*  95 */   TOTAL_MEM_SIZE, 
/*     */ 
/*  99 */   AVAILABLE_MEM_SIZE, 
/*     */ 
/* 104 */   CUSTOM_DATA, 
/*     */ 
/* 108 */   STACK_TRACE, 
/*     */ 
/* 113 */   CRASH_CONFIGURATION, 
/*     */ 
/* 117 */   DISPLAY, 
/*     */ 
/* 121 */   USER_APP_START_DATE, 
/*     */ 
/* 125 */   USER_CRASH_DATE, 
/*     */ 
/* 129 */   DUMPSYS_MEMINFO, 
/*     */ 
/* 134 */   DROPBOX, 
/*     */ 
/* 138 */   LOGCAT, 
/*     */ 
/* 142 */   EVENTSLOG, 
/*     */ 
/* 146 */   RADIOLOG, 
/*     */ 
/* 150 */   IS_SILENT, 
/*     */ 
/* 154 */   DEVICE_ID, 
/*     */ 
/* 159 */   INSTALLATION_ID, 
/*     */ 
/* 164 */   USER_EMAIL, 
/*     */ 
/* 168 */   DEVICE_FEATURES, 
/*     */ 
/* 172 */   ENVIRONMENT, 
/*     */ 
/* 176 */   SETTINGS_SYSTEM, 
/*     */ 
/* 180 */   SETTINGS_SECURE, 
/*     */ 
/* 184 */   PROCESS_NAME, 
/*     */ 
/* 188 */   PROCESS_NAME_BY_AMS, 
/*     */ 
/* 192 */   UPLOADED_BY_PROCESS, 
/*     */ 
/* 196 */   ACTIVITY_LOG, 
/*     */ 
/* 201 */   ACRA_INTERNAL, 
/*     */ 
/* 205 */   PROCESS_UPTIME, 
/*     */ 
/* 209 */   DEVICE_UPTIME, 
/*     */ 
/* 214 */   JAIL_BROKEN, 
/*     */ 
/* 219 */   ACRA_REPORT_FILENAME, 
/*     */ 
/* 223 */   EXCEPTION_CAUSE, 
/*     */ 
/* 227 */   REPORT_LOAD_THROW, 
/*     */ 
/* 231 */   MINIDUMP, 
/*     */ 
/* 235 */   OPEN_FD_COUNT, 
/*     */ 
/* 239 */   OPEN_FD_SOFT_LIMIT, 
/*     */ 
/* 243 */   OPEN_FD_HARD_LIMIT, 
/*     */ 
/* 248 */   APP_INSTALL_TIME, 
/*     */ 
/* 253 */   APP_UPGRADE_TIME, 
/*     */ 
/* 258 */   SERIAL, 
/*     */ 
/* 264 */   IS_LOW_RAM_DEVICE, 
/*     */ 
/* 269 */   SIGQUIT, 
/*     */ 
/* 274 */   LARGE_MEM_HEAP, 
/*     */ 
/* 279 */   ANDROID_RUNTIME;
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ReportField
 * JD-Core Version:    0.6.0
 */