/*      */ package com.parse;
/*      */ 
/*      */ import android.app.ActivityManager;
/*      */ import android.app.ActivityManager.RunningAppProcessInfo;
/*      */ import android.content.Context;
/*      */ import android.content.pm.PackageInfo;
/*      */ import android.content.res.Configuration;
/*      */ import android.content.res.Resources;
/*      */ import android.os.Build;
/*      */ import android.os.Build.VERSION;
/*      */ import android.os.Environment;
/*      */ import android.os.PowerManager;
/*      */ import android.os.PowerManager.WakeLock;
/*      */ import android.os.Process;
/*      */ import android.os.StatFs;
/*      */ import android.os.SystemClock;
/*      */ import android.provider.Settings.Secure;
/*      */ import android.telephony.TelephonyManager;
/*      */ import android.text.TextUtils;
/*      */ import android.text.format.Time;
/*      */ import android.util.Base64;
/*      */ import android.util.DisplayMetrics;
/*      */ import android.util.Log;
/*      */ import android.view.Display;
/*      */ import android.view.WindowManager;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FileReader;
/*      */ import java.io.FilenameFilter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.nio.channels.FileChannel;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.zip.GZIPOutputStream;
/*      */ 
/*      */ class ErrorReporter
/*      */   implements Thread.UncaughtExceptionHandler
/*      */ {
/*      */   public static final String REPORTFILE_EXTENSION = ".stacktrace";
/*      */   public static final String TEMP_REPORTFILE_EXTENSION = ".temp_stacktrace";
/*      */   public static final String ACRA_DIRNAME = "cr/reports";
/*      */   public static final long MAX_REPORT_AGE = 86400000L;
/*      */   public static final long DEFAULT_MAX_REPORT_SIZE = 51200L;
/*      */   public static final String PREALLOCATED_REPORTFILE = "reportfile.prealloc";
/*      */   public static final long PREALLOCATED_FILESIZE = 51200L;
/*      */   public static final String DUMP_DIR = "cr/minidumps";
/*      */   public static final String CRASH_ATTACHMENT_DUMMY_STACKTRACE = "crash attachment";
/*      */   public static final String SIGQUIT_DIR = "traces";
/*      */   public static final String DUMPFILE_EXTENSION = ".dmp";
/*      */   public static final long NATIVE_MAX_REPORT_SIZE = 512000L;
/*      */   public static final long SIGQUIT_MAX_REPORT_SIZE = 122880L;
/*  108 */   private static final Pattern VERSION_CODE_REGEX = Pattern.compile("^\\d+-[a-zA-Z0-9_\\-]+-(\\d+)\\.(temp_stacktrace|stacktrace)$");
/*      */   private static final long MIN_TEMP_REPORT_AGE = 600000L;
/*      */   private long mMaxReportSize;
/*      */   private static final String mInternalException = "ACRA_INTERNAL=java.lang.Exception: An exception occurred while trying to collect data about an ACRA internal error\n\tat com.parse.acra.ErrorReporter.handleException(ErrorReporter.java:810)\n\tat com.parse.acra.ErrorReporter.handleException(ErrorReporter.java:866)\n\tat com.parse.acra.ErrorReporter.uncaughtException(ErrorReporter.java:666)\n\tat java.lang.ThreadGroup.uncaughtException(ThreadGroup.java:693)\n\tat java.lang.ThreadGroup.uncaughtException(ThreadGroup.java:690)\n";
/*      */   private static final String IS_PROCESSING_ANOTHER_EXCEPTION = "IS_PROCESSING_ANOTHER_EXCEPTION";
/*      */   private static final String ANDROID_RUNTIME_DALVIK = "DALVIK";
/*      */   private static final String ANDROID_RUNTIME_ART = "ART";
/*      */   private static final String ANDROID_RUNTIME_UNKNOWN = "UNKNOWN";
/*      */   private static final String KNOWN_ART_JAR = "/system/framework/core-libart.jar";
/*      */   private static final String KNOWN_DALVIK_JAR = "/system/framework/core.jar";
/*      */   private static final String JAVA_BOOT_CLASS_PATH = "java.boot.class.path";
/*      */   private boolean mHasNativeCrashDumpOnInit;
/*      */   private ArrayList<ReportSender> mReportSenders;
/*      */   private final Map<ReportField, String> mConstantFields;
/*      */   private final Map<ReportField, String> mDeviceSpecificFields;
/*      */   private PackageManagerWrapper mPackageManager;
/*  158 */   private static final CrashReportType[] ALL_REPORT_TYPES = { CrashReportType.ACRA_CRASH_REPORT, CrashReportType.NATIVE_CRASH_REPORT, CrashReportType.ANR_REPORT };
/*      */   private FileProvider mFileProvider;
/*      */   public static final int MAX_SEND_REPORTS = 5;
/*      */   Map<String, String> mInstanceCustomParameters;
/*      */   Map<String, CustomReportDataSupplier> mInstanceLazyCustomParameters;
/*      */   private boolean mCurrentlyProcessingOOM;
/*      */   private final Object mShouldContinueProcessingExceptionLock;
/*      */   private Thread.UncaughtExceptionHandler mDfltExceptionHandler;
/*      */   private static ErrorReporter mInstanceSingleton;
/*      */   private Context mContext;
/*      */   private File preallocFile;
/*  321 */   private static int DEFAULT_TRACE_COUNT_LIMIT = 5;
/*  322 */   private static int MAX_TRACE_COUNT_LIMIT = 20;
/*      */   private final SimpleTraceLogger activityLogger;
/*      */   private String mAppVersionCode;
/*      */   private String mAppVersionName;
/*      */   private volatile String mUserId;
/*      */   private volatile boolean sendInMemoryReport;
/*      */   private boolean processNameByAmsReady;
/*      */   private String processNameByAms;
/*      */   private final Time mAppStartDate;
/*      */   private boolean usePreallocatedFile;
/*      */   private boolean mIsInternalBuild;
/*      */   private LogBridge mLogBridge;
/*  350 */   private static AtomicBoolean mProcessingCrash = new AtomicBoolean(false);
/*      */ 
/*      */   ErrorReporter()
/*      */   {
/*  113 */     this.mMaxReportSize = 51200L;
/*      */ 
/*  137 */     this.mHasNativeCrashDumpOnInit = false;
/*      */ 
/*  142 */     this.mReportSenders = new ArrayList();
/*      */ 
/*  148 */     this.mConstantFields = new HashMap();
/*      */ 
/*  153 */     this.mDeviceSpecificFields = new HashMap();
/*      */ 
/*  292 */     this.mInstanceCustomParameters = new ConcurrentHashMap();
/*      */ 
/*  295 */     this.mInstanceLazyCustomParameters = new ConcurrentHashMap();
/*      */ 
/*  302 */     this.mCurrentlyProcessingOOM = false;
/*  303 */     this.mShouldContinueProcessingExceptionLock = new Object();
/*      */ 
/*  317 */     this.preallocFile = null;
/*      */ 
/*  323 */     this.activityLogger = new SimpleTraceLogger(MAX_TRACE_COUNT_LIMIT);
/*      */ 
/*  331 */     this.sendInMemoryReport = false;
/*      */ 
/*  336 */     this.mAppStartDate = new Time();
/*      */ 
/*  338 */     this.usePreallocatedFile = false;
/*      */   }
/*      */ 
/*      */   public LogBridge getLogBridge()
/*      */   {
/*  356 */     return this.mLogBridge;
/*      */   }
/*      */ 
/*      */   public void setLogBridge(LogBridge bridge)
/*      */   {
/*  364 */     this.mLogBridge = bridge;
/*      */   }
/*      */ 
/*      */   public String getUserId()
/*      */   {
/*  372 */     return this.mUserId;
/*      */   }
/*      */ 
/*      */   public void setUserId(String userId)
/*      */   {
/*  380 */     this.mUserId = userId;
/*      */   }
/*      */ 
/*      */   public String putCustomData(String key, String value)
/*      */   {
/*  403 */     if (value != null) {
/*  404 */       return (String)this.mInstanceCustomParameters.put(key, value);
/*      */     }
/*  406 */     return removeCustomData(key);
/*      */   }
/*      */ 
/*      */   public String removeCustomData(String key)
/*      */   {
/*  420 */     return (String)this.mInstanceCustomParameters.remove(key);
/*      */   }
/*      */ 
/*      */   public String getCustomData(String key)
/*      */   {
/*  433 */     return (String)this.mInstanceCustomParameters.get(key);
/*      */   }
/*      */ 
/*      */   public void putLazyCustomData(String key, CustomReportDataSupplier valueSupplier)
/*      */   {
/*  445 */     this.mInstanceLazyCustomParameters.put(key, valueSupplier);
/*      */   }
/*      */ 
/*      */   public String dumpCustomDataToString(Map<String, String> extras, Throwable throwable)
/*      */   {
/*  458 */     StringBuilder customInfo = new StringBuilder();
/*  459 */     dumpCustomDataMap(customInfo, this.mInstanceCustomParameters);
/*  460 */     if (extras != null) {
/*  461 */       dumpCustomDataMap(customInfo, extras);
/*      */     }
/*  463 */     dumpLazyCustomDataMap(customInfo, this.mInstanceLazyCustomParameters, throwable);
/*  464 */     return customInfo.toString();
/*      */   }
/*      */ 
/*      */   private void dumpLazyCustomDataMap(StringBuilder sb, Map<String, CustomReportDataSupplier> params, Throwable throwable)
/*      */   {
/*  471 */     for (Map.Entry entry : params.entrySet()) { String key = (String)entry.getKey();
/*      */       String value;
/*      */       try { value = ((CustomReportDataSupplier)entry.getValue()).getCustomData(throwable);
/*      */       } catch (Throwable th) {
/*  477 */         Log.e("CrashReporting", "Caught throwable while getting custom report data", th);
/*  478 */       }continue;
/*      */ 
/*  480 */       if (value != null)
/*  481 */         dumpCustomDataEntry(sb, key, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void dumpCustomDataMap(StringBuilder sb, Map<String, String> params)
/*      */   {
/*  487 */     for (Map.Entry entry : params.entrySet()) {
/*  488 */       String key = (String)entry.getKey();
/*  489 */       String value = (String)entry.getValue();
/*  490 */       dumpCustomDataEntry(sb, key, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void dumpCustomDataEntry(StringBuilder sb, String key, String value)
/*      */   {
/*  496 */     key = key != null ? key.replace("\n", "\\n") : null;
/*  497 */     value = value != null ? value.replace("\n", "\\n") : null;
/*  498 */     sb.append(key).append(" = ").append(value).append("\n");
/*      */   }
/*      */ 
/*      */   private String getProcessNameFromAmsOrNull()
/*      */   {
/*  505 */     if (this.processNameByAmsReady) {
/*  506 */       return this.processNameByAms;
/*      */     }
/*      */ 
/*  509 */     this.processNameByAms = null;
/*  510 */     int pid = Process.myPid();
/*      */ 
/*  512 */     ActivityManager am = (ActivityManager)this.mContext.getSystemService("activity");
/*  513 */     if (am == null) {
/*  514 */       return this.processNameByAms;
/*      */     }
/*      */ 
/*  517 */     List processes = am.getRunningAppProcesses();
/*  518 */     if (processes == null) {
/*  519 */       return this.processNameByAms;
/*      */     }
/*      */ 
/*  522 */     for (ActivityManager.RunningAppProcessInfo rai : processes) {
/*  523 */       if (rai.pid == pid) {
/*  524 */         this.processNameByAms = rai.processName;
/*  525 */         break;
/*      */       }
/*      */     }
/*      */ 
/*  529 */     this.processNameByAmsReady = true;
/*  530 */     return this.processNameByAms;
/*      */   }
/*      */ 
/*      */   private void resetProcessNameByAmsCache() {
/*  534 */     this.processNameByAms = null;
/*  535 */     this.processNameByAmsReady = false;
/*      */   }
/*      */ 
/*      */   private String getProcessNameFromAms()
/*      */   {
/*  543 */     String processName = getProcessNameFromAmsOrNull();
/*  544 */     if (processName == null) {
/*  545 */       processName = "n/a";
/*      */     }
/*  547 */     return processName;
/*      */   }
/*      */ 
/*      */   private String getProcessName()
/*      */   {
/*  556 */     String processName = getProcessNameFromAmsOrNull();
/*  557 */     if (processName == null) {
/*  558 */       BufferedReader bufferedReader = null;
/*      */       try {
/*  560 */         FileReader reader = new FileReader("/proc/self/cmdline");
/*  561 */         bufferedReader = new BufferedReader(reader, 128);
/*  562 */         processName = bufferedReader.readLine();
/*  563 */         if (processName != null)
/*  564 */           processName = processName.trim();
/*      */       }
/*      */       catch (IOException ex) {
/*  567 */         Log.e("CrashReporting", "Failed to get process name.", ex);
/*      */       }
/*      */ 
/*  570 */       if (bufferedReader != null) {
/*      */         try {
/*  572 */           bufferedReader.close();
/*      */         } catch (IOException ex) {
/*  574 */           Log.e("CrashReporting", "Failed to close file.", ex);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  579 */     if (processName == null) {
/*  580 */       processName = "";
/*      */     }
/*  582 */     return processName;
/*      */   }
/*      */ 
/*      */   private String getJailStatus()
/*      */   {
/*  592 */     String buildTags = Build.TAGS;
/*  593 */     if ((buildTags != null) && (buildTags.contains("test-keys"))) {
/*  594 */       return "yes";
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  599 */       File file = new File("/system/app/Superuser.apk");
/*  600 */       if (file.exists())
/*  601 */         return "yes";
/*      */     }
/*      */     catch (Exception ex) {
/*  604 */       Log.e("CrashReporting", "Failed to find Superuser.pak", ex);
/*      */     }
/*      */ 
/*  608 */     Map env = System.getenv();
/*  609 */     if (env != null) {
/*  610 */       String path = (String)env.get("PATH");
/*  611 */       String[] dirs = path.split(":");
/*      */ 
/*  613 */       for (String dir : dirs) {
/*  614 */         String suPath = new StringBuilder().append(dir).append("/").append("su").toString();
/*      */         try {
/*  616 */           File suFile = new File(suPath);
/*  617 */           if ((suFile != null) && (suFile.exists()))
/*  618 */             return "yes";
/*      */         }
/*      */         catch (Exception ex) {
/*  621 */           Log.e("CrashReporting", "Failed to find su binary in the PATH", ex);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  626 */     return "no";
/*      */   }
/*      */ 
/*      */   private long getProcessUptime()
/*      */   {
/*  633 */     return Process.getElapsedCpuTime();
/*      */   }
/*      */ 
/*      */   private long getDeviceUptime()
/*      */   {
/*  640 */     return SystemClock.elapsedRealtime();
/*      */   }
/*      */ 
/*      */   public static ErrorReporter getInstance()
/*      */   {
/*  649 */     if (mInstanceSingleton == null) {
/*  650 */       mInstanceSingleton = new ErrorReporter();
/*      */     }
/*  652 */     return mInstanceSingleton;
/*      */   }
/*      */ 
/*      */   public void init(Context context, boolean isInternalBuild, FileProvider fileProvider)
/*      */   {
/*  666 */     if (this.mDfltExceptionHandler == null) {
/*  667 */       this.mDfltExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
/*      */ 
/*  669 */       this.mIsInternalBuild = isInternalBuild;
/*      */ 
/*  671 */       this.mContext = context;
/*      */ 
/*  673 */       this.mFileProvider = fileProvider;
/*      */ 
/*  675 */       PackageManagerWrapper pm = new PackageManagerWrapper(context);
/*  676 */       PackageInfo pi = pm.getPackageInfo();
/*      */ 
/*  678 */       if (pi != null) {
/*  679 */         this.mAppVersionCode = Integer.toString(pi.versionCode);
/*  680 */         this.mAppVersionName = (pi.versionName != null ? pi.versionName : "not set");
/*      */       }
/*      */ 
/*  683 */       this.mPackageManager = new PackageManagerWrapper(context);
/*  684 */       String osVersion = System.getProperty("os.version");
/*  685 */       boolean isCyanogenmod = osVersion != null ? osVersion.contains("cyanogenmod") : false;
/*      */ 
/*  687 */       this.mAppStartDate.setToNow();
/*      */       try
/*      */       {
/*  690 */         this.mConstantFields.put(ReportField.ANDROID_ID, Settings.Secure.getString(context.getContentResolver(), "android_id"));
/*      */ 
/*  692 */         this.mConstantFields.put(ReportField.APP_VERSION_CODE, this.mAppVersionCode);
/*  693 */         this.mConstantFields.put(ReportField.APP_VERSION_NAME, this.mAppVersionName);
/*  694 */         this.mConstantFields.put(ReportField.PACKAGE_NAME, context.getPackageName());
/*  695 */         this.mConstantFields.put(ReportField.PHONE_MODEL, Build.MODEL);
/*  696 */         this.mConstantFields.put(ReportField.ANDROID_VERSION, Build.VERSION.RELEASE);
/*  697 */         this.mConstantFields.put(ReportField.OS_VERSION, osVersion);
/*  698 */         this.mConstantFields.put(ReportField.IS_CYANOGENMOD, Boolean.toString(isCyanogenmod));
/*  699 */         this.mConstantFields.put(ReportField.BRAND, Build.BRAND);
/*  700 */         this.mConstantFields.put(ReportField.PRODUCT, Build.PRODUCT);
/*      */ 
/*  702 */         String absolutePath = "n/a";
/*  703 */         File filesDir = context.getFilesDir();
/*  704 */         if (filesDir != null) {
/*  705 */           absolutePath = filesDir.getAbsolutePath();
/*      */         }
/*  707 */         this.mConstantFields.put(ReportField.FILE_PATH, absolutePath);
/*      */ 
/*  709 */         if (Build.VERSION.SDK_INT >= 9) {
/*  710 */           this.mConstantFields.put(ReportField.SERIAL, Build.SERIAL);
/*      */ 
/*  712 */           if (pi != null) {
/*  713 */             this.mConstantFields.put(ReportField.APP_INSTALL_TIME, formatTimestamp(pi.firstInstallTime));
/*  714 */             this.mConstantFields.put(ReportField.APP_UPGRADE_TIME, formatTimestamp(pi.lastUpdateTime));
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  720 */         Log.e("CrashReporting", "failed to install constants", e);
/*      */       }
/*      */ 
/*  723 */       this.preallocFile = fileForName(this.mFileProvider, "cr/reports", "reportfile.prealloc");
/*      */ 
/*  725 */       createPreallocatedReportFile();
/*      */     }
/*      */   }
/*      */ 
/*      */   private String formatTimestamp(long time) {
/*  730 */     Time t = new Time();
/*  731 */     t.set(time);
/*  732 */     return t.format3339(false);
/*      */   }
/*      */ 
/*      */   private void createPreallocatedReportFile()
/*      */   {
/*  742 */     FileOutputStream fos = null;
/*      */     try {
/*  744 */       if (!this.preallocFile.exists()) {
/*  745 */         byte[] buf = new byte[10240];
/*  746 */         fos = new FileOutputStream(this.preallocFile);
/*  747 */         for (int i = 0; i < 51200L; i += buf.length)
/*  748 */           fos.write(buf);
/*      */       }
/*      */     }
/*      */     catch (IOException e) {
/*  752 */       Log.e("CrashReporting", "Failed to pre-allocate crash report file", e);
/*      */     } finally {
/*      */       try {
/*  755 */         if (fos != null)
/*  756 */           fos.close();
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static long getAvailableInternalMemorySize()
/*      */   {
/*      */     try
/*      */     {
/*  770 */       File path = Environment.getDataDirectory();
/*  771 */       StatFs stat = new StatFs(path.getPath());
/*  772 */       long blockSize = stat.getBlockSize();
/*  773 */       long availableBlocks = stat.getAvailableBlocks();
/*  774 */       return availableBlocks * blockSize; } catch (Exception e) {
/*      */     }
/*  776 */     return -1L;
/*      */   }
/*      */ 
/*      */   private static long getTotalInternalMemorySize()
/*      */   {
/*      */     try
/*      */     {
/*  788 */       File path = Environment.getDataDirectory();
/*  789 */       StatFs stat = new StatFs(path.getPath());
/*  790 */       long blockSize = stat.getBlockSize();
/*  791 */       long totalBlocks = stat.getBlockCount();
/*  792 */       return totalBlocks * blockSize; } catch (Exception e) {
/*      */     }
/*  794 */     return -1L;
/*      */   }
/*      */ 
/*      */   private void populateConstantDeviceData(CrashReportData crashReport, Writer writer)
/*      */   {
/*  807 */     Map deviceData = getConstantDeviceData();
/*  808 */     for (Map.Entry entry : deviceData.entrySet())
/*  809 */       put((ReportField)entry.getKey(), (String)entry.getValue(), crashReport, writer);
/*      */   }
/*      */ 
/*      */   private Map<ReportField, String> getConstantDeviceData()
/*      */   {
/*  821 */     synchronized (this.mDeviceSpecificFields) {
/*  822 */       if (this.mDeviceSpecificFields.isEmpty())
/*      */       {
/*  824 */         this.mDeviceSpecificFields.put(ReportField.BUILD, ReflectionCollector.collectConstants(Build.class));
/*  825 */         this.mDeviceSpecificFields.put(ReportField.JAIL_BROKEN, getJailStatus());
/*  826 */         this.mDeviceSpecificFields.put(ReportField.INSTALLATION_ID, Installation.id(this.mFileProvider));
/*  827 */         this.mDeviceSpecificFields.put(ReportField.TOTAL_MEM_SIZE, Long.toString(getTotalInternalMemorySize()));
/*      */ 
/*  829 */         if (this.mPackageManager.hasPermission("android.permission.READ_PHONE_STATE")) {
/*  830 */           TelephonyManager tm = (TelephonyManager)this.mContext.getSystemService("phone");
/*      */ 
/*  832 */           String deviceId = tm.getDeviceId();
/*  833 */           if (deviceId != null) {
/*  834 */             this.mDeviceSpecificFields.put(ReportField.DEVICE_ID, deviceId);
/*      */           }
/*      */         }
/*      */ 
/*  838 */         Display display = ((WindowManager)this.mContext.getSystemService("window")).getDefaultDisplay();
/*      */ 
/*  841 */         this.mDeviceSpecificFields.put(ReportField.DISPLAY, toString(display));
/*  842 */         this.mDeviceSpecificFields.put(ReportField.ENVIRONMENT, ReflectionCollector.collectStaticGettersResults(Environment.class));
/*      */ 
/*  846 */         this.mDeviceSpecificFields.put(ReportField.DEVICE_FEATURES, DeviceFeaturesCollector.getFeatures(this.mContext));
/*  847 */         this.mDeviceSpecificFields.put(ReportField.SETTINGS_SYSTEM, SettingsCollector.collectSystemSettings(this.mContext));
/*      */ 
/*  851 */         this.mDeviceSpecificFields.put(ReportField.SETTINGS_SECURE, SettingsCollector.collectSecureSettings(this.mContext));
/*      */ 
/*  856 */         if (Build.VERSION.SDK_INT >= 19) {
/*  857 */           ActivityManager am = (ActivityManager)this.mContext.getSystemService("activity");
/*      */ 
/*  859 */           this.mDeviceSpecificFields.put(ReportField.IS_LOW_RAM_DEVICE, Boolean.toString(am.isLowRamDevice()));
/*      */         }
/*      */ 
/*  862 */         this.mDeviceSpecificFields.put(ReportField.ANDROID_RUNTIME, getAndroidRuntime());
/*      */       }
/*      */ 
/*  865 */       return this.mDeviceSpecificFields;
/*      */     }
/*      */   }
/*      */ 
/*      */   private String getAndroidRuntime()
/*      */   {
/*  873 */     if (Build.VERSION.SDK_INT < 19) {
/*  874 */       return "DALVIK";
/*      */     }
/*  876 */     String bootClassPath = System.getProperty("java.boot.class.path");
/*  877 */     if (bootClassPath != null) {
/*  878 */       if (bootClassPath.contains("/system/framework/core-libart.jar"))
/*  879 */         return "ART";
/*  880 */       if (bootClassPath.contains("/system/framework/core.jar")) {
/*  881 */         return "DALVIK";
/*      */       }
/*      */     }
/*  884 */     return "UNKNOWN";
/*      */   }
/*      */ 
/*      */   private void retrieveCrashTimeData(Context context, Throwable e, ReportField[] fields, CrashReportData crashReport, Writer writer)
/*      */     throws Exception
/*      */   {
/*  902 */     List fieldsList = Arrays.asList(fields);
/*      */ 
/*  905 */     if (fieldsList.contains(ReportField.REPORT_ID)) {
/*  906 */       put(ReportField.REPORT_ID, UUID.randomUUID().toString(), crashReport, writer);
/*      */     }
/*      */ 
/*  910 */     if (fieldsList.contains(ReportField.PROCESS_NAME)) {
/*  911 */       put(ReportField.PROCESS_NAME, getProcessName(), crashReport, writer);
/*      */     }
/*      */ 
/*  915 */     if (fieldsList.contains(ReportField.USER_APP_START_DATE)) {
/*  916 */       put(ReportField.USER_APP_START_DATE, this.mAppStartDate.format3339(false), crashReport, writer);
/*      */     }
/*      */ 
/*  920 */     if (fieldsList.contains(ReportField.PROCESS_UPTIME)) {
/*  921 */       put(ReportField.PROCESS_UPTIME, Long.toString(getProcessUptime()), crashReport, writer);
/*      */     }
/*      */ 
/*  925 */     if (fieldsList.contains(ReportField.DEVICE_UPTIME)) {
/*  926 */       put(ReportField.DEVICE_UPTIME, Long.toString(getDeviceUptime()), crashReport, writer);
/*      */     }
/*      */ 
/*  929 */     if (fieldsList.contains(ReportField.CRASH_CONFIGURATION)) {
/*  930 */       Configuration crashConf = context.getResources().getConfiguration();
/*  931 */       put(ReportField.CRASH_CONFIGURATION, ConfigurationInspector.toString(crashConf), crashReport, writer);
/*      */     }
/*      */ 
/*  935 */     if (fieldsList.contains(ReportField.AVAILABLE_MEM_SIZE)) {
/*  936 */       String internalMemorySize = Long.toString(getAvailableInternalMemorySize());
/*  937 */       put(ReportField.AVAILABLE_MEM_SIZE, internalMemorySize, crashReport, writer);
/*      */     }
/*      */ 
/*  941 */     if (fieldsList.contains(ReportField.DUMPSYS_MEMINFO)) {
/*  942 */       put(ReportField.DUMPSYS_MEMINFO, DumpSysCollector.collectMemInfo(context), crashReport, writer);
/*      */     }
/*      */ 
/*  946 */     if (fieldsList.contains(ReportField.USER_CRASH_DATE)) {
/*  947 */       Time curDate = new Time();
/*  948 */       curDate.setToNow();
/*  949 */       put(ReportField.USER_CRASH_DATE, curDate.format3339(false), crashReport, writer);
/*      */     }
/*      */ 
/*  953 */     if (fieldsList.contains(ReportField.ACTIVITY_LOG))
/*      */     {
/*      */       String activityLogDump;
/*      */       String activityLogDump;
/*  955 */       if ((e instanceof OutOfMemoryError))
/*  956 */         activityLogDump = this.activityLogger.toString();
/*      */       else {
/*  958 */         activityLogDump = this.activityLogger.toString(DEFAULT_TRACE_COUNT_LIMIT);
/*      */       }
/*  960 */       put(ReportField.ACTIVITY_LOG, activityLogDump, crashReport, writer);
/*      */     }
/*      */ 
/*  964 */     if (fieldsList.contains(ReportField.PROCESS_NAME_BY_AMS)) {
/*  965 */       put(ReportField.PROCESS_NAME_BY_AMS, getProcessNameFromAms(), crashReport, writer);
/*      */     }
/*  967 */     resetProcessNameByAmsCache();
/*      */ 
/*  970 */     if (fieldsList.contains(ReportField.OPEN_FD_COUNT)) {
/*  971 */       put(ReportField.OPEN_FD_COUNT, String.valueOf(ProcFileReader.getOpenFDCount()), crashReport, writer);
/*      */     }
/*      */ 
/*  974 */     if ((fieldsList.contains(ReportField.OPEN_FD_SOFT_LIMIT)) || (fieldsList.contains(ReportField.OPEN_FD_HARD_LIMIT))) {
/*  975 */       ProcFileReader.OpenFDLimits limits = ProcFileReader.getOpenFDLimits();
/*  976 */       if (limits != null) {
/*  977 */         if (fieldsList.contains(ReportField.OPEN_FD_SOFT_LIMIT)) {
/*  978 */           put(ReportField.OPEN_FD_SOFT_LIMIT, limits.softLimit, crashReport, writer);
/*      */         }
/*  980 */         if (fieldsList.contains(ReportField.OPEN_FD_HARD_LIMIT)) {
/*  981 */           put(ReportField.OPEN_FD_HARD_LIMIT, limits.hardLimit, crashReport, writer);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  989 */     if ((Build.VERSION.SDK_INT >= 16) && (this.mIsInternalBuild)) {
/*  990 */       if (fieldsList.contains(ReportField.LOGCAT)) {
/*  991 */         put(ReportField.LOGCAT, LogCatCollector.collectLogCat(null), crashReport, writer);
/*      */       }
/*  993 */       if (fieldsList.contains(ReportField.EVENTSLOG)) {
/*  994 */         put(ReportField.EVENTSLOG, LogCatCollector.collectLogCat("events"), crashReport, writer);
/*      */       }
/*  996 */       if (fieldsList.contains(ReportField.RADIOLOG)) {
/*  997 */         put(ReportField.RADIOLOG, LogCatCollector.collectLogCat("radio"), crashReport, writer);
/*      */       }
/*  999 */       if (fieldsList.contains(ReportField.DROPBOX)) {
/* 1000 */         String dropBoxDump = DropBoxCollector.read(this.mContext, ACRA.getConfig().additionalDropBoxTags());
/*      */ 
/* 1002 */         put(ReportField.DROPBOX, dropBoxDump, crashReport, writer);
/*      */       }
/*      */     }
/* 1005 */     if ((fieldsList.contains(ReportField.LARGE_MEM_HEAP)) && (Build.VERSION.SDK_INT >= 11))
/*      */     {
/* 1007 */       put(ReportField.LARGE_MEM_HEAP, DumpSysCollector.collectLargerMemoryInfo(context), crashReport, writer);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static String toString(Display display)
/*      */   {
/* 1020 */     DisplayMetrics metrics = new DisplayMetrics();
/* 1021 */     display.getMetrics(metrics);
/* 1022 */     StringBuilder result = new StringBuilder();
/* 1023 */     result.append("width=").append(display.getWidth()).append('\n').append("height=").append(display.getHeight()).append('\n').append("pixelFormat=").append(display.getPixelFormat()).append('\n').append("refreshRate=").append(display.getRefreshRate()).append("fps").append('\n').append("metrics.density=x").append(metrics.density).append('\n').append("metrics.scaledDensity=x").append(metrics.scaledDensity).append('\n').append("metrics.widthPixels=").append(metrics.widthPixels).append('\n').append("metrics.heightPixels=").append(metrics.heightPixels).append('\n').append("metrics.xdpi=").append(metrics.xdpi).append('\n').append("metrics.ydpi=").append(metrics.ydpi);
/*      */ 
/* 1031 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public void uncaughtException(Thread t, Throwable e)
/*      */   {
/* 1040 */     Log.e("CrashReporting", new StringBuilder().append("ParseCrashReporting caught a ").append(e.getClass().getSimpleName()).append(" exception for ").append(this.mContext.getPackageName()).append(". Building report.").toString());
/*      */ 
/* 1045 */     this.usePreallocatedFile = true;
/*      */ 
/* 1047 */     boolean wasProcessingCrash = mProcessingCrash.getAndSet(true);
/* 1048 */     Map extra = null;
/*      */     try
/*      */     {
/* 1051 */       extra = new HashMap();
/* 1052 */       extra.put("IS_PROCESSING_ANOTHER_EXCEPTION", String.valueOf(wasProcessingCrash));
/*      */     }
/*      */     catch (OutOfMemoryError ex)
/*      */     {
/*      */     }
/*      */ 
/* 1059 */     ReportsSenderWorker worker = handleException(e, extra);
/*      */ 
/* 1061 */     if (worker != null) {
/* 1062 */       while (worker.isAlive())
/*      */       {
/*      */         try
/*      */         {
/* 1066 */           Thread.sleep(100L);
/*      */         } catch (InterruptedException e1) {
/* 1068 */           Log.e("CrashReporting", "Error : ", e1);
/*      */         }
/*      */       }
/*      */ 
/* 1072 */       Throwable workerException = worker.getException();
/* 1073 */       if (workerException != null) {
/* 1074 */         Log.e("CrashReporting", "ReportsWorkerSender failed with exception", workerException);
/*      */ 
/* 1078 */         ReportField[] fields = getReportFieldsForException(e);
/* 1079 */         handleExceptionInternal(workerException, extra, null, fields, false);
/*      */       }
/*      */     }
/*      */ 
/* 1083 */     if (this.mDfltExceptionHandler != null)
/* 1084 */       this.mDfltExceptionHandler.uncaughtException(t, e);
/*      */   }
/*      */ 
/*      */   private void writeToLogBridge(String tag, String message, Throwable t, String overrideStackTrace)
/*      */   {
/* 1103 */     LogBridge logBridge = getLogBridge();
/* 1104 */     if (logBridge != null)
/*      */     {
/* 1107 */       if (overrideStackTrace != null)
/* 1108 */         logBridge.log(tag, new StringBuilder().append(message).append("\n").append(overrideStackTrace).toString(), null);
/*      */       else {
/* 1110 */         logBridge.log(tag, message, t);
/*      */       }
/*      */ 
/*      */     }
/* 1115 */     else if (overrideStackTrace != null)
/* 1116 */       Log.e(tag, new StringBuilder().append(message).append("\n").append(overrideStackTrace).toString());
/*      */     else
/* 1118 */       Log.e(tag, message, t);
/*      */   }
/*      */ 
/*      */   private String throwableToString(Throwable e)
/*      */   {
/* 1129 */     if (e == null) {
/* 1130 */       e = new Exception("Report requested by developer");
/*      */     }
/*      */ 
/* 1133 */     Writer result = new StringWriter();
/* 1134 */     PrintWriter printWriter = new PrintWriter(result);
/* 1135 */     e.printStackTrace(printWriter);
/* 1136 */     printWriter.close();
/*      */ 
/* 1138 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private void gatherCrashData(String stackTrace, Throwable e, ReportField[] fields, CrashReportData crashReport, Writer w, Map<String, String> extras)
/*      */     throws Exception
/*      */   {
/* 1150 */     if (fields == null) {
/* 1151 */       fields = ACRA.MINIMAL_REPORT_FIELDS;
/*      */     }
/*      */ 
/* 1155 */     put(ReportField.UID, getUserId(), crashReport, w);
/*      */ 
/* 1159 */     put(ReportField.STACK_TRACE, stackTrace, crashReport, w);
/*      */ 
/* 1161 */     for (Map.Entry entry : this.mConstantFields.entrySet()) {
/* 1162 */       put((ReportField)entry.getKey(), (String)entry.getValue(), crashReport, w);
/*      */     }
/*      */ 
/* 1165 */     retrieveCrashTimeData(this.mContext, e, fields, crashReport, w);
/* 1166 */     populateConstantDeviceData(crashReport, w);
/*      */ 
/* 1168 */     put(ReportField.CUSTOM_DATA, dumpCustomDataToString(extras, e), crashReport, w);
/*      */   }
/*      */ 
/*      */   private void put(ReportField key, String value, CrashReportData crashReport, Writer writer)
/*      */   {
/*      */     try
/*      */     {
/* 1186 */       crashReport.put(key, value, this.sendInMemoryReport ? null : writer);
/*      */     }
/*      */     catch (IOException ex) {
/* 1189 */       this.sendInMemoryReport = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeReportToStream(Throwable e, OutputStream os)
/*      */     throws Exception
/*      */   {
/* 1200 */     CrashReportData crashReport = new CrashReportData();
/* 1201 */     Writer w = CrashReportData.getWriter(os);
/* 1202 */     String stackTrace = throwableToString(e);
/* 1203 */     gatherCrashData(stackTrace, e, ACRA.ALL_CRASH_REPORT_FIELDS, crashReport, w, null);
/*      */   }
/*      */ 
/*      */   public ReportsSenderWorker handleException(Throwable e)
/*      */   {
/* 1212 */     return handleException(e, null);
/*      */   }
/*      */ 
/*      */   public ReportsSenderWorker handleException(Throwable e, Map<String, String> extras)
/*      */   {
/* 1225 */     boolean sendImmediately = !(e instanceof OutOfMemoryError);
/* 1226 */     ReportField[] fields = getReportFieldsForException(e);
/* 1227 */     return handleExceptionInternal(e, extras, null, fields, sendImmediately);
/*      */   }
/*      */ 
/*      */   private ReportsSenderWorker handleExceptionInternal(Throwable e, Map<String, String> extras, String overrideStackTrace, ReportField[] fields, boolean shouldSendImmediately)
/*      */   {
/* 1259 */     Throwable mostSignificantCause = getMostSignificantCause(e);
/* 1260 */     Class causeClass = mostSignificantCause.getClass();
/*      */ 
/* 1263 */     if (!shouldContinueProcessingException(mostSignificantCause)) {
/* 1264 */       return null;
/*      */     }
/*      */ 
/* 1269 */     CrashReportData crashReport = new CrashReportData();
/*      */ 
/* 1273 */     String description = (e instanceof NonCrashException) ? ((NonCrashException)e).getExceptionFriendlyName() : "crash";
/*      */ 
/* 1275 */     writeToLogBridge("CrashReporting", new StringBuilder().append("Handling exception for ").append(description).toString(), e, overrideStackTrace);
/*      */ 
/* 1284 */     Log.d("CrashReporting", new StringBuilder().append("Generating report file for ").append(description).toString());
/* 1285 */     String tempReportFileName = genCrashReportFileName(causeClass, ".temp_stacktrace");
/* 1286 */     File tempReportFile = fileForName(this.mFileProvider, "cr/reports", tempReportFileName);
/* 1287 */     String reportFileName = genCrashReportFileName(causeClass, ".stacktrace");
/* 1288 */     File reportFile = fileForName(this.mFileProvider, "cr/reports", reportFileName);
/*      */ 
/* 1290 */     RandomAccessFile outputFile = null;
/* 1291 */     Writer tempReportWriter = null;
/*      */     try
/*      */     {
/* 1297 */       if (this.usePreallocatedFile) {
/* 1298 */         this.preallocFile.renameTo(tempReportFile);
/*      */       }
/*      */ 
/* 1309 */       outputFile = new RandomAccessFile(tempReportFile, "rw");
/*      */ 
/* 1311 */       tempReportWriter = CrashReportData.getWriter(new FileOutputStream(outputFile.getFD()));
/*      */     } catch (Exception ex) {
/* 1313 */       Log.e("CrashReporting", "An error occurred while creating the report file ...", ex);
/*      */ 
/* 1315 */       this.sendInMemoryReport = true;
/*      */     }
/*      */     try
/*      */     {
/* 1319 */       put(ReportField.ACRA_REPORT_FILENAME, reportFileName, crashReport, tempReportWriter);
/* 1320 */       put(ReportField.EXCEPTION_CAUSE, causeClass.getName(), crashReport, tempReportWriter);
/*      */ 
/* 1326 */       if (overrideStackTrace == null) {
/* 1327 */         overrideStackTrace = throwableToString(e);
/*      */       }
/* 1329 */       gatherCrashData(overrideStackTrace, e, fields, crashReport, tempReportWriter, extras);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       try
/*      */       {
/*      */         FileChannel chan;
/* 1337 */         Log.e("CrashReporting", "An error occurred while gathering crash data ...", ex);
/* 1338 */         put(ReportField.ACRA_INTERNAL, throwableToString(ex), crashReport, tempReportWriter);
/*      */       }
/*      */       catch (Exception ex1)
/*      */       {
/* 1344 */         Log.e("CrashReporting", "An error occurred while gathering internal crash data ...", ex1);
/* 1345 */         put(ReportField.ACRA_INTERNAL, "ACRA_INTERNAL=java.lang.Exception: An exception occurred while trying to collect data about an ACRA internal error\n\tat com.parse.acra.ErrorReporter.handleException(ErrorReporter.java:810)\n\tat com.parse.acra.ErrorReporter.handleException(ErrorReporter.java:866)\n\tat com.parse.acra.ErrorReporter.uncaughtException(ErrorReporter.java:666)\n\tat java.lang.ThreadGroup.uncaughtException(ThreadGroup.java:693)\n\tat java.lang.ThreadGroup.uncaughtException(ThreadGroup.java:690)\n", crashReport, tempReportWriter);
/*      */       } finally {
/* 1347 */         Log.e("CrashReporting", "An error occurred while gathering crash data ...", ex);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*      */         FileChannel chan;
/* 1353 */         if (outputFile != null) {
/* 1354 */           FileChannel chan = outputFile.getChannel();
/* 1355 */           chan.truncate(chan.position());
/*      */ 
/* 1357 */           outputFile.close();
/* 1358 */           tempReportFile.renameTo(reportFile);
/*      */         }
/*      */       } catch (Exception ex) {
/* 1361 */         Log.e("CrashReporting", "An error occurred while deleting closing the report file ...", ex);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1366 */     if (shouldSendImmediately) {
/* 1367 */       ReportsSenderWorker wk = this.sendInMemoryReport ? new ReportsSenderWorker(crashReport) : new ReportsSenderWorker(new CrashReportType[] { CrashReportType.ACRA_CRASH_REPORT });
/*      */ 
/* 1370 */       Log.v("CrashReporting", "About to start ReportSenderWorker from #handleException");
/* 1371 */       wk.start();
/*      */ 
/* 1373 */       return wk;
/*      */     }
/*      */ 
/* 1380 */     Log.v("CrashReporting", "ParseCrashReporting caught an OutOfMemoryError. Report upload deferred until next ParseCrashReporting launch.");
/*      */ 
/* 1383 */     return null;
/*      */   }
/*      */ 
/*      */   public ReportsSenderWorker handleException(Throwable e, String stackTrace, Map<String, String> extras)
/*      */   {
/* 1404 */     ReportField[] fields = getReportFieldsForException(e);
/* 1405 */     return handleExceptionInternal(e, extras, stackTrace, fields, true);
/*      */   }
/*      */ 
/*      */   public void handleExceptionWithCustomFields(Exception e, Map<String, String> data, ReportField[] fields)
/*      */   {
/* 1422 */     handleExceptionInternal(e, data, null, fields, true);
/*      */   }
/*      */ 
/*      */   private void sendCrashReport(CrashReportData errorContent)
/*      */     throws ReportSenderException
/*      */   {
/* 1436 */     boolean sentAtLeastOnce = false;
/* 1437 */     for (ReportSender sender : this.mReportSenders)
/*      */       try {
/* 1439 */         sender.send(errorContent);
/*      */ 
/* 1442 */         sentAtLeastOnce = true;
/*      */       } catch (ReportSenderException e) {
/* 1444 */         if (!sentAtLeastOnce) {
/* 1445 */           throw e;
/*      */         }
/* 1447 */         Log.w("CrashReporting", new StringBuilder().append("ReportSender of class ").append(sender.getClass().getName()).append(" failed but other senders completed their task. ").append("ParseCrashReporting will not send this report again.").toString());
/*      */       }
/*      */   }
/*      */ 
/*      */   private String genCrashReportFileName(Class cause, String fileExtension)
/*      */   {
/* 1456 */     return new StringBuilder().append(Long.toString(System.currentTimeMillis())).append("-").append(cause.getSimpleName()).append(this.mAppVersionCode != null ? new StringBuilder().append("-").append(this.mAppVersionCode).toString() : "").append(fileExtension).toString();
/*      */   }
/*      */ 
/*      */   public String[] getCrashReportFilesList(String path, String[] extensions)
/*      */   {
/* 1469 */     if (this.mContext == null) {
/* 1470 */       Log.e("CrashReporting", "Trying to get crash reports but crash reporting is not initialized.");
/* 1471 */       return new String[0];
/*      */     }
/*      */ 
/* 1474 */     File dir = this.mFileProvider.getFile(path);
/* 1475 */     if (dir != null) {
/* 1476 */       Log.d("CrashReporting", new StringBuilder().append("Looking for error files in ").append(dir.getAbsolutePath()).toString());
/*      */ 
/* 1479 */       FilenameFilter filter = new FilenameFilter(extensions) {
/*      */         public boolean accept(File dir, String name) {
/* 1481 */           for (String extension : this.val$extensions) {
/* 1482 */             if (name.endsWith(extension)) {
/* 1483 */               return true;
/*      */             }
/*      */           }
/* 1486 */           return false;
/*      */         }
/*      */       };
/* 1489 */       String[] result = dir.list(filter);
/* 1490 */       return result == null ? new String[0] : result;
/*      */     }
/* 1492 */     Log.w("CrashReporting", "Application files directory does not exist! The application may not be installed correctly. Please try reinstalling.");
/*      */ 
/* 1495 */     return new String[0];
/*      */   }
/*      */ 
/*      */   synchronized void checkAndSendReports(Context context, CrashReportType[] types)
/*      */   {
/* 1507 */     Log.d("CrashReporting", "#checkAndSendReports - start");
/* 1508 */     for (CrashReportType reportType : types) {
/* 1509 */       if (CrashReportType.ACRA_CRASH_REPORT == reportType)
/* 1510 */         checkAndSendAcraReports(context);
/*      */       else {
/* 1512 */         checkAndSendCrashAttachments(context, reportType);
/*      */       }
/*      */     }
/* 1515 */     Log.d("CrashReporting", "#checkAndSendReports - finish");
/*      */   }
/*      */ 
/*      */   private void checkAndSendAcraReports(Context context) {
/* 1519 */     String[] reportFiles = getCrashReportFilesList("cr/reports", new String[] { ".stacktrace", ".temp_stacktrace" });
/*      */ 
/* 1521 */     Arrays.sort(reportFiles);
/*      */ 
/* 1523 */     int reportsSentCount = 0;
/*      */ 
/* 1528 */     String uploadedByProcess = getProcessNameFromAms();
/* 1529 */     for (String curFileName : reportFiles)
/* 1530 */       if (reportsSentCount >= 5)
/*      */       {
/* 1538 */         deleteFile("cr/reports", curFileName);
/*      */       }
/*      */       else
/*      */       {
/* 1542 */         Log.d("CrashReporting", new StringBuilder().append("Loading file ").append(curFileName).toString());
/*      */         try {
/* 1544 */           CrashReportData previousCrashReport = loadAcraCrashReport(context, curFileName);
/*      */ 
/* 1546 */           if (previousCrashReport != null) {
/* 1547 */             previousCrashReport.put(ReportField.ACRA_REPORT_FILENAME, curFileName);
/*      */ 
/* 1550 */             previousCrashReport.put(ReportField.UPLOADED_BY_PROCESS, uploadedByProcess);
/*      */ 
/* 1552 */             Log.i("CrashReporting", new StringBuilder().append("Sending file ").append(curFileName).toString());
/* 1553 */             sendCrashReport(previousCrashReport);
/* 1554 */             deleteFile("cr/reports", curFileName);
/*      */           }
/*      */         } catch (RuntimeException e) {
/* 1557 */           Log.e("CrashReporting", "Failed to send crash reports", e);
/* 1558 */           deleteFile("cr/reports", curFileName);
/* 1559 */           break;
/*      */         } catch (IOException e) {
/* 1561 */           Log.e("CrashReporting", new StringBuilder().append("Failed to load crash report for ").append(curFileName).toString(), e);
/* 1562 */           deleteFile("cr/reports", curFileName);
/* 1563 */           break;
/*      */         } catch (ReportSenderException e) {
/* 1565 */           Log.e("CrashReporting", new StringBuilder().append("Failed to send crash report for ").append(curFileName).toString(), e);
/* 1566 */           break;
/*      */         }
/* 1568 */         reportsSentCount++;
/*      */       }
/*      */   }
/*      */ 
/*      */   private int checkAndSendCrashAttachments(Context context, CrashReportType type)
/*      */   {
/* 1583 */     Log.d("CrashReporting", "#checkAndSendCrashAttachments - start");
/* 1584 */     int dumpsSend = 0;
/*      */ 
/* 1586 */     String[] dumpFiles = getCrashReportFilesList(type.directory, type.fileExtensions);
/* 1587 */     if ((dumpFiles != null) && (dumpFiles.length > 0)) {
/* 1588 */       Arrays.sort(dumpFiles);
/*      */ 
/* 1591 */       CrashReportData tempCrashReportData = new CrashReportData();
/*      */       try {
/* 1593 */         gatherCrashData("crash attachment", new CrashAttachmentException(null), ACRA.ALL_CRASH_REPORT_FIELDS, tempCrashReportData, null, null);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 1603 */         String message = new StringBuilder().append("retrieve exception: ").append(e.getMessage()).toString();
/* 1604 */         put(ReportField.REPORT_LOAD_THROW, message, tempCrashReportData, null);
/*      */       }
/*      */ 
/* 1607 */       for (String fname : dumpFiles) {
/* 1608 */         if (dumpsSend >= 5)
/* 1609 */           deleteFile("cr/minidumps", fname);
/*      */         else {
/*      */           try
/*      */           {
/* 1613 */             CrashReportData reportData = loadCrashAttachment(context, fname, type);
/* 1614 */             String attachment = "load failed";
/* 1615 */             if (reportData != null) {
/* 1616 */               attachment = (String)reportData.get(type.attachmentField);
/*      */             }
/*      */ 
/* 1619 */             tempCrashReportData.put(ReportField.REPORT_ID, fname.substring(0, fname.lastIndexOf(46)), null);
/* 1620 */             tempCrashReportData.put(type.attachmentField, attachment, null);
/* 1621 */             tempCrashReportData.put(ReportField.EXCEPTION_CAUSE, "crash attachment", null);
/* 1622 */             sendCrashReport(tempCrashReportData);
/* 1623 */             deleteFile(type.directory, fname);
/* 1624 */             dumpsSend++;
/*      */           }
/*      */           catch (ReportSenderException e) {
/* 1627 */             Log.e("CrashReporting", new StringBuilder().append("Failed to send crash attachment report ").append(fname).toString(), e);
/* 1628 */             break;
/*      */           } catch (Throwable e) {
/* 1630 */             Log.e("CrashReporting", new StringBuilder().append("Failed on crash attachment file ").append(fname).toString(), e);
/* 1631 */             deleteFile(type.directory, fname);
/* 1632 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1638 */     Log.d("CrashReporting", new StringBuilder().append("#checkAndSendCrashAttachments - finish, sent: ").append(Integer.toString(dumpsSend)).toString());
/*      */ 
/* 1640 */     return dumpsSend;
/*      */   }
/*      */ 
/*      */   synchronized void sendInMemoryReport(Context context, CrashReportData crashReport)
/*      */   {
/* 1650 */     Log.i("CrashReporting", "Sending in-memory report");
/*      */     try {
/* 1652 */       String uploadedByProcess = getProcessNameFromAms();
/* 1653 */       crashReport.put(ReportField.UPLOADED_BY_PROCESS, uploadedByProcess);
/* 1654 */       sendCrashReport(crashReport);
/*      */ 
/* 1661 */       String reportName = (String)crashReport.get(ReportField.ACRA_REPORT_FILENAME);
/* 1662 */       if (reportName != null) {
/* 1663 */         File reportFile = fileForName(this.mFileProvider, "cr/reports", reportName);
/* 1664 */         if (reportFile != null)
/* 1665 */           reportFile.delete();
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1669 */       Log.e("CrashReporting", "Failed to send in-memory crash report: ", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private CrashReportData loadAcraCrashReport(Context context, String fileName) throws IOException
/*      */   {
/* 1675 */     return loadCrashReport(context, fileName, CrashReportType.ACRA_CRASH_REPORT, this.mMaxReportSize);
/*      */   }
/*      */ 
/*      */   private CrashReportData loadCrashAttachment(Context context, String fileName, CrashReportType type)
/*      */     throws IOException
/*      */   {
/* 1683 */     return loadCrashReport(context, fileName, type, type.defaultMaxSize);
/*      */   }
/*      */ 
/*      */   private CrashReportData loadCrashReport(Context context, String fileName, CrashReportType crashReportType, long maxSize)
/*      */     throws IOException
/*      */   {
/* 1693 */     CrashReportData crashReport = new CrashReportData();
/* 1694 */     File rptfp = fileForName(this.mFileProvider, crashReportType.directory, fileName);
/* 1695 */     if (System.currentTimeMillis() - rptfp.lastModified() > 86400000L) {
/* 1696 */       Log.w("CrashReporting", new StringBuilder().append("crash report ").append(fileName).append(" was too old; deleted").toString());
/* 1697 */       deleteFile(crashReportType.directory, fileName);
/* 1698 */       return null;
/*      */     }
/*      */ 
/* 1702 */     if ((fileName.endsWith(".temp_stacktrace")) && (System.currentTimeMillis() - rptfp.lastModified() < 600000L))
/*      */     {
/* 1704 */       Log.w("CrashReporting", new StringBuilder().append("temp file ").append(fileName).append(" is too recent; skipping").toString());
/* 1705 */       return null;
/*      */     }
/* 1707 */     if (rptfp.length() > maxSize) {
/* 1708 */       Log.w("CrashReporting", new StringBuilder().append("").append(rptfp.length()).append("-byte crash report ").append(fileName).append(" exceeded max size of ").append(maxSize).append(" bytes; deleted").toString());
/*      */ 
/* 1710 */       deleteFile(crashReportType.directory, fileName);
/* 1711 */       return null;
/*      */     }
/*      */ 
/* 1714 */     FileInputStream input = new FileInputStream(rptfp);
/* 1715 */     boolean closed = false;
/*      */     try
/*      */     {
/* 1718 */       if (crashReportType == CrashReportType.ACRA_CRASH_REPORT) {
/* 1719 */         crashReport.load(input);
/*      */       }
/*      */       else {
/* 1722 */         int nbytes = (int)rptfp.length();
/* 1723 */         String attachment = loadAttachment(input, nbytes);
/* 1724 */         crashReport.put(crashReportType.attachmentField, attachment);
/*      */       }
/*      */     } catch (Throwable th) {
/* 1727 */       crashReport.put(ReportField.REPORT_LOAD_THROW, new StringBuilder().append("throwable: ").append(th.getMessage()).toString());
/* 1728 */       Log.e("CrashReporting", new StringBuilder().append("Could not load crash report:").append(fileName).append(" ").append(th).toString());
/* 1729 */       input.close();
/* 1730 */       closed = true;
/* 1731 */       context.deleteFile(fileName);
/* 1732 */       Log.e("CrashReporting", new StringBuilder().append("Crash report:").append(fileName).append(" deleted").toString());
/*      */     } finally {
/* 1734 */       if (!closed) {
/* 1735 */         input.close();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1741 */     crashReport.put(ReportField.ACRA_REPORT_FILENAME, fileName);
/* 1742 */     backfillCrashReportData(crashReport);
/* 1743 */     return crashReport;
/*      */   }
/*      */ 
/*      */   void backfillCrashReportData(CrashReportData crashReport)
/*      */   {
/* 1755 */     String versionCode = parseVersionCodeFromFileName(crashReport.getProperty(ReportField.ACRA_REPORT_FILENAME));
/*      */ 
/* 1757 */     boolean hasAppBeenUpgraded = !versionCode.equals(this.mAppVersionCode);
/*      */ 
/* 1759 */     String reportID = (String)crashReport.get(ReportField.REPORT_ID);
/* 1760 */     if ((reportID == null) || (reportID.length() == 0)) {
/* 1761 */       for (Map.Entry e : this.mConstantFields.entrySet()) {
/* 1762 */         if (((ReportField)e.getKey()).equals(ReportField.APP_VERSION_NAME))
/*      */         {
/* 1764 */           if (hasAppBeenUpgraded) {
/*      */             continue;
/*      */           }
/* 1767 */           crashReport.put((Enum)e.getKey(), e.getValue());
/* 1768 */           continue;
/*      */         }
/*      */ 
/* 1771 */         if (crashReport.get(e.getKey()) == null) {
/* 1772 */           crashReport.put((Enum)e.getKey(), e.getValue());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1779 */     String currentUserId = getUserId();
/* 1780 */     String previousUid = (String)crashReport.get(ReportField.UID);
/* 1781 */     if ((!TextUtils.isEmpty(currentUserId)) && (TextUtils.isEmpty(previousUid)))
/* 1782 */       crashReport.put(ReportField.UID, currentUserId);
/*      */   }
/*      */ 
/*      */   public String parseVersionCodeFromFileName(String fileName)
/*      */   {
/* 1794 */     if (fileName != null) {
/* 1795 */       Matcher matcher = VERSION_CODE_REGEX.matcher(fileName);
/* 1796 */       if (matcher.matches()) {
/* 1797 */         return matcher.group(1);
/*      */       }
/*      */     }
/* 1800 */     return "";
/*      */   }
/*      */ 
/*      */   private String loadAttachment(InputStream in, int nbytes)
/*      */     throws IOException
/*      */   {
/* 1810 */     int offset = 0;
/* 1811 */     int nbytesread = 0;
/* 1812 */     byte[] attachment = new byte[nbytes];
/* 1813 */     while (nbytes - offset > 0) {
/* 1814 */       nbytesread = in.read(attachment, offset, nbytes - offset);
/* 1815 */       if (nbytesread == -1) {
/*      */         break;
/*      */       }
/* 1818 */       offset += nbytesread;
/*      */     }
/*      */ 
/* 1821 */     if (nbytesread == 0) {
/* 1822 */       return "";
/*      */     }
/*      */ 
/* 1826 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1827 */     GZIPOutputStream gzipOutputStream = null;
/*      */     try {
/* 1829 */       gzipOutputStream = new GZIPOutputStream(baos);
/* 1830 */       gzipOutputStream.write(attachment, 0, attachment.length);
/* 1831 */       gzipOutputStream.finish();
/* 1832 */       String str = Base64.encodeToString(baos.toByteArray(), 0);
/*      */       return str;
/*      */     }
/*      */     finally
/*      */     {
/* 1834 */       if (gzipOutputStream != null)
/* 1835 */         gzipOutputStream.close(); 
/* 1835 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   private static File fileForName(FileProvider fileProvider, String path, String fileName)
/*      */   {
/* 1842 */     File cdir = fileProvider.getFile(path);
/* 1843 */     return new File(cdir, fileName);
/*      */   }
/*      */ 
/*      */   private void deleteFile(String path, String fileName) {
/* 1847 */     boolean deleted = fileForName(this.mFileProvider, path, fileName).delete();
/* 1848 */     if (!deleted)
/* 1849 */       Log.w("CrashReporting", new StringBuilder().append("Could not delete error report : ").append(fileName).toString());
/*      */   }
/*      */ 
/*      */   public ReportsSenderWorker checkReportsOnApplicationStart()
/*      */   {
/* 1857 */     String[] filesList = getCrashReportFilesList("cr/reports", new String[] { ".stacktrace" });
/* 1858 */     String[] nativeCrashFileList = getCrashReportFilesList("cr/minidumps", new String[] { ".dmp" });
/* 1859 */     if (((filesList != null) && (filesList.length > 0)) || ((nativeCrashFileList != null) && (nativeCrashFileList.length > 0)))
/*      */     {
/* 1861 */       Log.v("CrashReporting", "About to start ReportSenderWorker from #checkReportOnApplicationStart");
/* 1862 */       if ((nativeCrashFileList != null) && (nativeCrashFileList.length > 0)) {
/* 1863 */         this.mHasNativeCrashDumpOnInit = true;
/*      */       }
/* 1865 */       return checkReportsOfType(ALL_REPORT_TYPES);
/*      */     }
/* 1867 */     return null;
/*      */   }
/*      */ 
/*      */   public ReportsSenderWorker checkReportsOfType(CrashReportType[] types)
/*      */   {
/* 1879 */     ReportsSenderWorker worker = new ReportsSenderWorker(types);
/* 1880 */     worker.start();
/* 1881 */     return worker;
/*      */   }
/*      */ 
/*      */   public boolean isNativeCrashedOnPreviousRun()
/*      */   {
/* 1888 */     return this.mHasNativeCrashDumpOnInit;
/*      */   }
/*      */ 
/*      */   public void addReportSender(ReportSender sender)
/*      */   {
/* 1898 */     this.mReportSenders.add(sender);
/*      */   }
/*      */ 
/*      */   public void removeAllReportSenders()
/*      */   {
/* 1906 */     this.mReportSenders.clear();
/*      */   }
/*      */ 
/*      */   public void setMaxReportSize(long size)
/*      */   {
/* 1915 */     this.mMaxReportSize = size;
/*      */   }
/*      */ 
/*      */   public void setReportSender(ReportSender sender)
/*      */   {
/* 1924 */     removeAllReportSenders();
/* 1925 */     addReportSender(sender);
/*      */   }
/*      */ 
/*      */   public void registerActivity(String activityName)
/*      */   {
/* 1935 */     if (activityName != null)
/* 1936 */       this.activityLogger.append(activityName);
/*      */   }
/*      */ 
/*      */   private ReportField[] getReportFieldsForException(Throwable e)
/*      */   {
/* 1948 */     return (e instanceof OutOfMemoryError) ? ACRA.MINIMAL_REPORT_FIELDS : ACRA.ALL_CRASH_REPORT_FIELDS;
/*      */   }
/*      */ 
/*      */   Throwable getMostSignificantCause(Throwable e)
/*      */   {
/* 1964 */     if ((e instanceof NonCrashException)) {
/* 1965 */       return e;
/*      */     }
/*      */ 
/* 1968 */     Throwable cause = e;
/* 1969 */     while (cause.getCause() != null) {
/* 1970 */       cause = cause.getCause();
/*      */     }
/*      */ 
/* 1973 */     return cause;
/*      */   }
/*      */ 
/*      */   private boolean shouldContinueProcessingException(Throwable t)
/*      */   {
/* 1984 */     synchronized (this.mShouldContinueProcessingExceptionLock) {
/* 1985 */       if (this.mCurrentlyProcessingOOM)
/*      */       {
/* 1987 */         return false;
/*      */       }
/*      */ 
/* 1990 */       if ((t instanceof OutOfMemoryError))
/*      */       {
/* 1992 */         this.mCurrentlyProcessingOOM = true;
/*      */       }
/* 1994 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class CrashAttachmentException extends Throwable
/*      */   {
/*      */     private CrashAttachmentException()
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   final class ReportsSenderWorker extends Thread
/*      */   {
/*  217 */     private Throwable exception = null;
/*      */     private CrashReportData mInMemoryReportToSend;
/*      */     private final ErrorReporter.CrashReportType[] mReportTypesToSend;
/*      */ 
/*      */     public ReportsSenderWorker(CrashReportData inMemoryReportToSend)
/*      */     {
/*  227 */       this(new ErrorReporter.CrashReportType[0]);
/*  228 */       this.mInMemoryReportToSend = inMemoryReportToSend;
/*      */     }
/*      */ 
/*      */     public ReportsSenderWorker(ErrorReporter.CrashReportType[] reportTypesToSend)
/*      */     {
/*  236 */       this.mReportTypesToSend = reportTypesToSend;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*  241 */       PowerManager.WakeLock wakeLock = null;
/*      */       try {
/*  243 */         wakeLock = acquireWakeLock();
/*  244 */         if (this.mInMemoryReportToSend != null)
/*  245 */           ErrorReporter.this.sendInMemoryReport(ErrorReporter.this.mContext, this.mInMemoryReportToSend);
/*      */         else {
/*  247 */           ErrorReporter.this.checkAndSendReports(ErrorReporter.this.mContext, this.mReportTypesToSend);
/*      */         }
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/*  252 */         this.exception = e;
/*      */       } finally {
/*  254 */         if ((wakeLock != null) && (wakeLock.isHeld()))
/*  255 */           wakeLock.release();
/*      */       }
/*      */     }
/*      */ 
/*      */     public Throwable getException()
/*      */     {
/*  261 */       return this.exception;
/*      */     }
/*      */ 
/*      */     private PowerManager.WakeLock acquireWakeLock()
/*      */     {
/*  268 */       PackageManagerWrapper pm = new PackageManagerWrapper(ErrorReporter.this.mContext);
/*  269 */       if (!pm.hasPermission("android.permission.WAKE_LOCK")) {
/*  270 */         return null;
/*      */       }
/*      */ 
/*  273 */       PowerManager powerManager = (PowerManager)ErrorReporter.this.mContext.getSystemService("power");
/*  274 */       PowerManager.WakeLock wakeLock = powerManager.newWakeLock(1, "crash reporting wakelock");
/*      */ 
/*  278 */       wakeLock.setReferenceCounted(false);
/*  279 */       wakeLock.acquire();
/*  280 */       return wakeLock;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum CrashReportType
/*      */   {
/*  175 */     ACRA_CRASH_REPORT("cr/reports", 51200L, null, new String[] { ".stacktrace", ".temp_stacktrace" }), 
/*      */ 
/*  182 */     NATIVE_CRASH_REPORT("cr/minidumps", 512000L, ReportField.MINIDUMP, new String[] { ".dmp" }), 
/*      */ 
/*  188 */     ANR_REPORT("traces", 122880L, ReportField.SIGQUIT, new String[] { ".stacktrace", ".temp_stacktrace" });
/*      */ 
/*      */     private final String directory;
/*      */     private final long defaultMaxSize;
/*      */     private final ReportField attachmentField;
/*      */     private final String[] fileExtensions;
/*      */ 
/*  199 */     private CrashReportType(String directory, long maxSize, ReportField attachmentField, String[] fileExtensions) { this.directory = directory;
/*  200 */       this.defaultMaxSize = maxSize;
/*  201 */       this.attachmentField = attachmentField;
/*  202 */       this.fileExtensions = fileExtensions;
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ErrorReporter
 * JD-Core Version:    0.6.0
 */