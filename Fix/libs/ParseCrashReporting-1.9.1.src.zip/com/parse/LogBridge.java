package com.parse;

abstract interface LogBridge
{
  public abstract void log(String paramString1, String paramString2, Throwable paramThrowable);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.LogBridge
 * JD-Core Version:    0.6.0
 */