/*    */ package com.parse;
/*    */ 
/*    */ import android.content.Context;
/*    */ 
/*    */ class BaseCrashReporter
/*    */   implements ReportsCrashes
/*    */ {
/*    */   protected Context mApplicationContext;
/*    */ 
/*    */   public BaseCrashReporter(Context applicationContext)
/*    */   {
/* 19 */     if (applicationContext == null) {
/* 20 */       throw new IllegalArgumentException("Application context cannot be null");
/*    */     }
/* 22 */     this.mApplicationContext = applicationContext;
/*    */   }
/*    */ 
/*    */   public boolean includeDropBoxSystemTags()
/*    */   {
/* 27 */     return false;
/*    */   }
/*    */ 
/*    */   public String[] additionalDropBoxTags()
/*    */   {
/* 32 */     String[] tags = new String[0];
/* 33 */     return tags;
/*    */   }
/*    */ 
/*    */   public int dropboxCollectionMinutes()
/*    */   {
/* 38 */     return 5;
/*    */   }
/*    */ 
/*    */   public String[] logcatArguments()
/*    */   {
/* 43 */     String[] args = { "-t", "200", "-v", "time" };
/* 44 */     return args;
/*    */   }
/*    */ 
/*    */   public String formPostFormat()
/*    */   {
/* 49 */     return "application/x-www-form-urlencoded";
/*    */   }
/*    */ 
/*    */   public int socketTimeout()
/*    */   {
/* 54 */     return 3000;
/*    */   }
/*    */ 
/*    */   public boolean checkSSLCertsOnCrashReport() {
/* 58 */     return true;
/*    */   }
/*    */ 
/*    */   public Context getApplicationContext()
/*    */   {
/* 63 */     return this.mApplicationContext;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.BaseCrashReporter
 * JD-Core Version:    0.6.0
 */