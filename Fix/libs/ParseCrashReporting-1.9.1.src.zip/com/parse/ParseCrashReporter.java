/*    */ package com.parse;
/*    */ 
/*    */ import android.content.Context;
/*    */ import java.io.File;
/*    */ 
/*    */ class ParseCrashReporter
/*    */ {
/*    */   private static ParseCrashReporter defaultInstance;
/* 20 */   private static final Object defaultInstanceLock = new Object();
/*    */   private static final String REPORT_ENDPOINT = "http://dev/null";
/*    */   private ErrorReporter innerCrashReporter;
/*    */ 
/*    */   static void enableCrashReporting(Context applicationContext)
/*    */   {
/* 31 */     synchronized (defaultInstanceLock) {
/* 32 */       if (defaultInstance == null)
/* 33 */         defaultInstance = new ParseCrashReporter(applicationContext);
/*    */       else
/* 35 */         throw new RuntimeException("enableCrashReporting() called multiple times.");
/*    */     }
/*    */   }
/*    */ 
/*    */   static boolean isEnabled()
/*    */   {
/* 45 */     synchronized (defaultInstanceLock) {
/* 46 */       return defaultInstance != null;
/*    */     }
/*    */   }
/*    */ 
/*    */   static ParseCrashReporter getCurrent()
/*    */   {
/* 56 */     synchronized (defaultInstanceLock) {
/* 57 */       return defaultInstance;
/*    */     }
/*    */   }
/*    */ 
/*    */   private ParseCrashReporter(Context applicationContext)
/*    */   {
/* 67 */     FileProvider fileProvider = new FileProvider()
/*    */     {
/*    */       public File getFile(String path) {
/* 70 */         return Parse.getParseFilesDir(path);
/*    */       }
/*    */     };
/* 74 */     Parse.ParseCallbacks callbacks = new Parse.ParseCallbacks(applicationContext, fileProvider)
/*    */     {
/*    */       public void onParseInitialized() {
/* 77 */         ParseCrashReporter.access$002(ParseCrashReporter.this, ACRA.init(new BaseCrashReporter(this.val$applicationContext), "http://dev/null", true, this.val$fileProvider));
/*    */ 
/* 82 */         ParseCrashReporter.this.innerCrashReporter.setReportSender(new ParseCrashReportHandler());
/*    */       }
/*    */     };
/*    */     try {
/* 87 */       Parse.registerParseCallbacks(callbacks);
/*    */     } catch (IllegalStateException e) {
/* 89 */       throw new IllegalStateException("You must enable crash reporting before calling Parse.initialize(context, applicationId, clientKey");
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ParseCrashReporter
 * JD-Core Version:    0.6.0
 */