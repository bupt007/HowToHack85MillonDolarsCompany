/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.provider.Settings.Secure;
/*     */ import android.provider.Settings.System;
/*     */ import android.util.Log;
/*     */ import java.lang.reflect.Field;
/*     */ 
/*     */ class SettingsCollector
/*     */ {
/*     */   public static String collectSystemSettings(Context ctx)
/*     */   {
/*  51 */     StringBuilder result = new StringBuilder();
/*  52 */     Field[] keys = Settings.System.class.getFields();
/*  53 */     for (Field key : keys)
/*     */     {
/*  57 */       if ((key.isAnnotationPresent(Deprecated.class)) || (key.getType() != String.class)) continue;
/*     */       try {
/*  59 */         Object value = Settings.System.getString(ctx.getContentResolver(), (String)key.get(null));
/*  60 */         if (value != null)
/*  61 */           result.append(key.getName()).append("=").append(value).append("\n");
/*     */       }
/*     */       catch (IllegalArgumentException e) {
/*  64 */         Log.w("CrashReporting", "Error : ", e);
/*     */       } catch (IllegalAccessException e) {
/*  66 */         Log.w("CrashReporting", "Error : ", e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  71 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String collectSecureSettings(Context ctx)
/*     */   {
/*  84 */     StringBuilder result = new StringBuilder();
/*  85 */     Field[] keys = Settings.Secure.class.getFields();
/*  86 */     for (Field key : keys) {
/*  87 */       if ((key.isAnnotationPresent(Deprecated.class)) || (key.getType() != String.class) || (!isAuthorized(key))) continue;
/*     */       try {
/*  89 */         Object value = Settings.Secure.getString(ctx.getContentResolver(), (String)key.get(null));
/*  90 */         if (value != null)
/*  91 */           result.append(key.getName()).append("=").append(value).append("\n");
/*     */       }
/*     */       catch (IllegalArgumentException e) {
/*  94 */         Log.w("CrashReporting", "Error : ", e);
/*     */       } catch (IllegalAccessException e) {
/*  96 */         Log.w("CrashReporting", "Error : ", e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 101 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private static boolean isAuthorized(Field key)
/*     */   {
/* 106 */     return (key != null) && (!key.getName().startsWith("WIFI_AP"));
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.SettingsCollector
 * JD-Core Version:    0.6.0
 */