/*    */ package com.parse;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ class ReflectionCollector
/*    */ {
/*    */   public static String collectConstants(Class<?> someClass)
/*    */   {
/* 45 */     StringBuilder result = new StringBuilder();
/*    */ 
/* 47 */     Field[] fields = someClass.getFields();
/* 48 */     for (Field field : fields) {
/* 49 */       result.append(field.getName()).append("=");
/*    */       try {
/* 51 */         result.append(field.get(null).toString());
/*    */       } catch (Exception e) {
/* 53 */         result.append("N/A");
/*    */       }
/* 55 */       result.append("\n");
/*    */     }
/*    */ 
/* 58 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public static String collectStaticGettersResults(Class<?> someClass)
/*    */   {
/* 67 */     StringBuilder result = new StringBuilder();
/* 68 */     Method[] methods = someClass.getMethods();
/* 69 */     for (Method method : methods) {
/* 70 */       if ((method.getParameterTypes().length != 0) || ((!method.getName().startsWith("get")) && (!method.getName().startsWith("is"))) || (method.getName().equals("getClass")))
/*    */         continue;
/*    */       try
/*    */       {
/* 74 */         result.append(method.getName()).append('=').append(method.invoke(null, (Object[])null)).append("\n");
/*    */       }
/*    */       catch (IllegalArgumentException e)
/*    */       {
/*    */       }
/*    */       catch (IllegalAccessException e)
/*    */       {
/*    */       }
/*    */       catch (InvocationTargetException e)
/*    */       {
/*    */       }
/*    */     }
/* 86 */     return result.toString();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ReflectionCollector
 * JD-Core Version:    0.6.0
 */