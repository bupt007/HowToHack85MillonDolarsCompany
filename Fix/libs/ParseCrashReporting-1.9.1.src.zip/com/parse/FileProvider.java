package com.parse;

import java.io.File;

abstract interface FileProvider
{
  public abstract File getFile(String paramString);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.FileProvider
 * JD-Core Version:    0.6.0
 */