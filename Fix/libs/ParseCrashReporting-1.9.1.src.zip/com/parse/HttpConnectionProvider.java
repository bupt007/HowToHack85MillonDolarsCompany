package com.parse;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

abstract interface HttpConnectionProvider
{
  public abstract HttpURLConnection getConnection(URL paramURL)
    throws IOException;
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.HttpConnectionProvider
 * JD-Core Version:    0.6.0
 */