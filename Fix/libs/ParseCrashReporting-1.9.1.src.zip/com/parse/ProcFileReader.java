/*    */ package com.parse;
/*    */ 
/*    */ import android.os.Process;
/*    */ import android.util.Log;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.NoSuchElementException;
/*    */ import java.util.Scanner;
/*    */ 
/*    */ class ProcFileReader
/*    */ {
/* 18 */   private static final Class<?> TAG = ProcFileReader.class;
/*    */   public static final int CANNOT_DETERMINE_OPEN_FDS = -1;
/*    */   public static final int SECURITY_EXCEPTION = -2;
/*    */ 
/*    */   public static int getOpenFDCount()
/*    */   {
/*    */     try
/*    */     {
/* 40 */       String[] FD_DIRS = { String.format("/proc/%s/fd", new Object[] { Integer.valueOf(Process.myPid()) }), "/proc/self/fd", String.format("/proc/%s/fd", new Object[] { Integer.valueOf(Process.myTid()) }) };
/*    */ 
/* 45 */       for (int i = 0; i < FD_DIRS.length; i++) {
/* 46 */         String[] fdFiles = new File(FD_DIRS[i]).list();
/* 47 */         if (fdFiles != null) {
/* 48 */           return fdFiles.length;
/*    */         }
/*    */       }
/* 51 */       return -1;
/*    */     }
/*    */     catch (SecurityException e) {
/* 54 */       Log.e(TAG.toString(), e.getMessage());
/* 55 */     }return -2;
/*    */   }
/*    */ 
/*    */   public static OpenFDLimits getOpenFDLimits()
/*    */   {
/* 63 */     Scanner s = null;
/*    */     try {
/* 65 */       s = new Scanner(new File("/proc/self/limits"));
/*    */ 
/* 68 */       if (s.findWithinHorizon("Max open files", 5000) == null) {
/* 69 */         localOpenFDLimits = null;
/*    */         return localOpenFDLimits;
/*    */       }
/* 72 */       OpenFDLimits localOpenFDLimits = new OpenFDLimits(s.next(), s.next());
/*    */       return localOpenFDLimits;
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/* 74 */       localObject1 = null;
/*    */       return localObject1;
/*    */     }
/*    */     catch (NoSuchElementException e)
/*    */     {
/* 76 */       Object localObject1 = null;
/*    */       return localObject1;
/*    */     }
/*    */     finally
/*    */     {
/* 78 */       if (s != null)
/* 79 */         s.close(); 
/* 79 */     }throw localObject2;
/*    */   }
/*    */ 
/*    */   public static class OpenFDLimits
/*    */   {
/*    */     public final String softLimit;
/*    */     public final String hardLimit;
/*    */ 
/*    */     public OpenFDLimits(String softLimit, String hardLimit) {
/* 90 */       this.softLimit = softLimit;
/* 91 */       this.hardLimit = hardLimit;
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ProcFileReader
 * JD-Core Version:    0.6.0
 */