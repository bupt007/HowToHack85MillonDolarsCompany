/*    */ package com.parse;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.RandomAccessFile;
/*    */ import java.util.UUID;
/*    */ 
/*    */ class Installation
/*    */ {
/* 33 */   private static String sID = null;
/*    */   private static final String INSTALLATION = "installation";
/*    */ 
/*    */   public static synchronized String id(FileProvider fileProvider)
/*    */   {
/* 37 */     if (sID == null) {
/* 38 */       File filesDir = fileProvider.getFile("cr");
/* 39 */       if (filesDir == null) {
/* 40 */         return "n/a";
/*    */       }
/*    */ 
/* 43 */       File installation = new File(filesDir, "installation");
/*    */       try {
/* 45 */         if (!installation.exists())
/* 46 */           writeInstallationFile(installation);
/* 47 */         sID = readInstallationFile(installation);
/*    */       } catch (Exception e) {
/* 49 */         return "n/a";
/*    */       }
/*    */     }
/* 52 */     return sID;
/*    */   }
/*    */ 
/*    */   private static String readInstallationFile(File installation) throws IOException {
/* 56 */     RandomAccessFile f = new RandomAccessFile(installation, "r");
/*    */     try {
/* 58 */       byte[] bytes = new byte[(int)f.length()];
/* 59 */       f.readFully(bytes);
/* 60 */       String str = new String(bytes);
/*    */       return str; } finally { f.close(); } throw localObject;
/*    */   }
/*    */ 
/*    */   private static void writeInstallationFile(File installation) throws IOException
/*    */   {
/* 67 */     FileOutputStream out = new FileOutputStream(installation);
/*    */     try {
/* 69 */       String id = UUID.randomUUID().toString();
/* 70 */       out.write(id.getBytes());
/*    */     } finally {
/* 72 */       out.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.Installation
 * JD-Core Version:    0.6.0
 */