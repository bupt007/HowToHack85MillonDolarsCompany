/*    */ package com.parse;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLEncoder;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class HttpUtils
/*    */ {
/*    */   public static void doPost(Map<?, ?> parameters, URL url)
/*    */     throws IOException
/*    */   {
/* 44 */     doPost(parameters, url, "application/x-www-form-urlencoded");
/*    */   }
/*    */ 
/*    */   public static void doPost(Map<?, ?> parameters, URL url, String contentType)
/*    */     throws IOException
/*    */   {
/*    */     String content;
/*    */     String content;
/* 59 */     if (contentType == "application/json")
/* 60 */       content = encodeParametersJson(parameters);
/*    */     else {
/* 62 */       content = encodeParametersFormUrlEncoded(parameters);
/*    */     }
/*    */ 
/* 65 */     HttpConnectionProvider provider = null;
/* 66 */     if (ACRA.getConfig().checkSSLCertsOnCrashReport())
/* 67 */       provider = new SSLConnectionProvider();
/*    */     else {
/* 69 */       provider = new UnsafeConnectionProvider();
/*    */     }
/*    */ 
/* 72 */     HttpRequest req = new HttpRequest(provider);
/* 73 */     req.sendPost(url, content, new ACRAResponse(), contentType);
/*    */   }
/*    */ 
/*    */   public static String encodeParametersFormUrlEncoded(Map<?, ?> parameters) throws IOException {
/* 77 */     StringBuilder dataBfr = new StringBuilder();
/* 78 */     for (Iterator i$ = parameters.keySet().iterator(); i$.hasNext(); ) { Object key = i$.next();
/* 79 */       if (dataBfr.length() != 0) {
/* 80 */         dataBfr.append('&');
/*    */       }
/* 82 */       Object value = parameters.get(key);
/* 83 */       if (value == null) {
/* 84 */         value = "";
/*    */       }
/* 86 */       dataBfr.append(URLEncoder.encode(key.toString(), "UTF-8")).append('=').append(URLEncoder.encode(value.toString(), "UTF-8"));
/*    */     }
/*    */ 
/* 91 */     return dataBfr.toString();
/*    */   }
/*    */ 
/*    */   public static String encodeParametersJson(Map<?, ?> parameters) throws IOException {
/* 95 */     JSONObject jsonParams = new JSONObject(parameters);
/* 96 */     return jsonParams.toString();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.HttpUtils
 * JD-Core Version:    0.6.0
 */