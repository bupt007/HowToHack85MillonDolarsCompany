/*    */ package com.parse;
/*    */ 
/*    */ import android.content.Context;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ public final class ParseCrashReporting
/*    */ {
/*    */   static final String CRASH_REPORT = "_CrashReport";
/*    */ 
/*    */   public static void enable(Context context)
/*    */   {
/* 43 */     ParseCrashReporter.enableCrashReporting(context.getApplicationContext());
/*    */   }
/*    */ 
/*    */   public static boolean isCrashReportingEnabled()
/*    */   {
/* 52 */     return ParseCrashReporter.isEnabled();
/*    */   }
/*    */ 
/*    */   static void trackCrashReport(JSONObject crashReportData)
/*    */   {
/* 62 */     Map parameters = new HashMap();
/* 63 */     parameters.put("acraDump", crashReportData);
/* 64 */     ParseRESTCommand command = ParseRESTAnalyticsCommand.trackEventCommand("_CrashReport", parameters, ParseUser.getCurrentSessionToken());
/*    */ 
/* 66 */     Parse.getEventuallyQueue().enqueueEventuallyAsync(command, null);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ParseCrashReporting
 * JD-Core Version:    0.6.0
 */