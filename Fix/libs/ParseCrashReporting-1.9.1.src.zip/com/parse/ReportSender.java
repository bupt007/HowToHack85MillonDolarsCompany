package com.parse;

abstract interface ReportSender
{
  public abstract void send(CrashReportData paramCrashReportData)
    throws ReportSenderException;
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ReportSender
 * JD-Core Version:    0.6.0
 */