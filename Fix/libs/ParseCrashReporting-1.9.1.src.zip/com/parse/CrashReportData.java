/*     */ package com.parse;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.IllegalCharsetNameException;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ class CrashReportData extends EnumMap<ReportField, String>
/*     */ {
/*     */   private static final long serialVersionUID = 4112578634029874840L;
/*     */   private static final String PROP_DTD_NAME = "http://java.sun.com/dtd/properties.dtd";
/*     */   protected CrashReportData defaults;
/*     */   private static final int NONE = 0;
/*     */   private static final int SLASH = 1;
/*     */   private static final int UNICODE = 2;
/*     */   private static final int CONTINUE = 3;
/*     */   private static final int KEY_DONE = 4;
/*     */   private static final int IGNORE = 5;
/* 541 */   private static String lineSeparator = "\n";
/*     */ 
/*     */   public CrashReportData()
/*     */   {
/*  84 */     super(ReportField.class);
/*     */   }
/*     */ 
/*     */   public CrashReportData(CrashReportData properties)
/*     */   {
/*  95 */     super(ReportField.class);
/*  96 */     this.defaults = properties;
/*     */   }
/*     */ 
/*     */   private void dumpString(Appendable sb, String string, boolean key) throws IOException {
/* 100 */     int i = 0;
/* 101 */     int length = string.length();
/* 102 */     if ((!key) && (i < length) && (string.charAt(i) == ' ')) {
/* 103 */       sb.append("\\ ");
/* 104 */       i++;
/*     */     }
/*     */ 
/* 107 */     for (; i < length; i++) {
/* 108 */       char ch = string.charAt(i);
/* 109 */       switch (ch) {
/*     */       case '\t':
/* 111 */         sb.append("\\t");
/* 112 */         break;
/*     */       case '\n':
/* 114 */         sb.append("\\n");
/* 115 */         break;
/*     */       case '\f':
/* 117 */         sb.append("\\f");
/* 118 */         break;
/*     */       case '\r':
/* 120 */         sb.append("\\r");
/* 121 */         break;
/*     */       case '\013':
/*     */       default:
/* 123 */         if (((key) && (ch == ' ')) || (ch == '\\') || (ch == '#') || (ch == '!') || (ch == ':'))
/*     */         {
/* 128 */           sb.append('\\');
/*     */         }
/* 130 */         if ((ch >= ' ') && (ch <= '~')) {
/* 131 */           sb.append(ch);
/*     */         } else {
/* 133 */           String hex = Integer.toHexString(ch);
/* 134 */           sb.append("\\u");
/* 135 */           for (int j = 0; j < 4 - hex.length(); j++) {
/* 136 */             sb.append('0');
/*     */           }
/* 138 */           sb.append(hex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getProperty(ReportField key)
/*     */   {
/* 154 */     String result = (String)super.get(key);
/* 155 */     if ((result == null) && (this.defaults != null)) {
/* 156 */       result = this.defaults.getProperty(key);
/*     */     }
/* 158 */     return result;
/*     */   }
/*     */ 
/*     */   public String getProperty(ReportField key, String defaultValue)
/*     */   {
/* 174 */     String property = (String)super.get(key);
/* 175 */     if ((property == null) && (this.defaults != null)) {
/* 176 */       property = this.defaults.getProperty(key);
/*     */     }
/* 178 */     if (property == null) {
/* 179 */       return defaultValue;
/*     */     }
/* 181 */     return property;
/*     */   }
/*     */ 
/*     */   public void list(PrintStream out)
/*     */   {
/* 193 */     if (out == null) {
/* 194 */       throw new NullPointerException();
/*     */     }
/* 196 */     StringBuilder buffer = new StringBuilder(80);
/* 197 */     Enumeration keys = keys();
/* 198 */     while (keys.hasMoreElements()) {
/* 199 */       ReportField key = (ReportField)keys.nextElement();
/* 200 */       buffer.append(key);
/* 201 */       buffer.append('=');
/* 202 */       String property = (String)super.get(key);
/* 203 */       CrashReportData def = this.defaults;
/* 204 */       while (property == null) {
/* 205 */         property = (String)def.get(key);
/* 206 */         def = def.defaults;
/*     */       }
/* 208 */       if (property.length() > 40) {
/* 209 */         buffer.append(property.substring(0, 37));
/* 210 */         buffer.append("...");
/*     */       } else {
/* 212 */         buffer.append(property);
/*     */       }
/* 214 */       out.println(buffer.toString());
/* 215 */       buffer.setLength(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void list(PrintWriter writer)
/*     */   {
/* 228 */     if (writer == null) {
/* 229 */       throw new NullPointerException();
/*     */     }
/* 231 */     StringBuilder buffer = new StringBuilder(80);
/* 232 */     Enumeration keys = keys();
/* 233 */     while (keys.hasMoreElements()) {
/* 234 */       ReportField key = (ReportField)keys.nextElement();
/* 235 */       buffer.append(key);
/* 236 */       buffer.append('=');
/* 237 */       String property = (String)super.get(key);
/* 238 */       CrashReportData def = this.defaults;
/* 239 */       while (property == null) {
/* 240 */         property = (String)def.get(key);
/* 241 */         def = def.defaults;
/*     */       }
/* 243 */       if (property.length() > 40) {
/* 244 */         buffer.append(property.substring(0, 37));
/* 245 */         buffer.append("...");
/*     */       } else {
/* 247 */         buffer.append(property);
/*     */       }
/* 249 */       writer.println(buffer.toString());
/* 250 */       buffer.setLength(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void load(InputStream in)
/*     */     throws IOException
/*     */   {
/* 264 */     if (in == null) {
/* 265 */       throw new NullPointerException();
/*     */     }
/* 267 */     BufferedInputStream bis = new BufferedInputStream(in);
/* 268 */     bis.mark(2147483647);
/* 269 */     boolean isEbcdic = isEbcdic(bis);
/* 270 */     bis.reset();
/*     */ 
/* 272 */     if (!isEbcdic)
/* 273 */       load(new InputStreamReader(bis, "ISO8859-1"));
/*     */     else
/* 275 */       load(new InputStreamReader(bis));
/*     */   }
/*     */ 
/*     */   private boolean isEbcdic(BufferedInputStream in)
/*     */     throws IOException
/*     */   {
/*     */     byte b;
/* 281 */     while ((b = (byte)in.read()) != -1) {
/* 282 */       if ((b == 35) || (b == 10) || (b == 61)) {
/* 283 */         return false;
/*     */       }
/* 285 */       if (b == 21) {
/* 286 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 294 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized void load(Reader reader)
/*     */     throws IOException
/*     */   {
/* 326 */     int mode = 0; int unicode = 0; int count = 0;
/* 327 */     char[] buf = new char[40];
/* 328 */     int offset = 0; int keyLength = -1;
/* 329 */     boolean firstChar = true;
/* 330 */     BufferedReader br = new BufferedReader(reader);
/*     */     while (true)
/*     */     {
/* 333 */       int intVal = br.read();
/*     */ 
/* 336 */       if ((intVal == -1) || (intVal == 0)) {
/*     */         break;
/*     */       }
/* 339 */       char nextChar = (char)intVal;
/*     */ 
/* 341 */       if (offset == buf.length) {
/* 342 */         char[] newBuf = new char[buf.length * 2];
/* 343 */         System.arraycopy(buf, 0, newBuf, 0, offset);
/* 344 */         buf = newBuf;
/*     */       }
/* 346 */       if (mode == 2) {
/* 347 */         int digit = Character.digit(nextChar, 16);
/* 348 */         if (digit >= 0) {
/* 349 */           unicode = (unicode << 4) + digit;
/* 350 */           count++; if (count < 4)
/* 351 */             continue;
/*     */         }
/* 353 */         else if (count <= 4)
/*     */         {
/* 355 */           throw new IllegalArgumentException("luni.09");
/*     */         }
/* 357 */         mode = 0;
/* 358 */         buf[(offset++)] = (char)unicode;
/* 359 */         if ((nextChar != '\n') && (nextChar != '')) {
/*     */           continue;
/*     */         }
/*     */       }
/* 363 */       if (mode == 1) {
/* 364 */         mode = 0;
/* 365 */         switch (nextChar) {
/*     */         case '\r':
/* 367 */           mode = 3;
/* 368 */           break;
/*     */         case '\n':
/*     */         case '':
/* 371 */           mode = 5;
/* 372 */           break;
/*     */         case 'b':
/* 374 */           nextChar = '\b';
/* 375 */           break;
/*     */         case 'f':
/* 377 */           nextChar = '\f';
/* 378 */           break;
/*     */         case 'n':
/* 380 */           nextChar = '\n';
/* 381 */           break;
/*     */         case 'r':
/* 383 */           nextChar = '\r';
/* 384 */           break;
/*     */         case 't':
/* 386 */           nextChar = '\t';
/* 387 */           break;
/*     */         case 'u':
/* 389 */           mode = 2;
/* 390 */           unicode = count = 0;
/* 391 */           break;
/*     */         default:
/* 391 */           break;
/*     */         }
/*     */       }
/* 394 */       switch (nextChar) {
/*     */       case '!':
/*     */       case '#':
/* 397 */         if (firstChar)
/*     */           do {
/* 399 */             intVal = br.read();
/* 400 */             if (intVal == -1)
/*     */               break;
/* 402 */             nextChar = (char)intVal;
/*     */ 
/* 405 */             if ((nextChar == '\r') || (nextChar == '\n')) break; 
/* 405 */           }while (nextChar != '');
/* 406 */         break;
/*     */       case '\n':
/* 413 */         if (mode == 3)
/* 414 */           mode = 5;
/* 415 */         break;
/*     */       case '\r':
/*     */       case '':
/* 420 */         mode = 0;
/* 421 */         firstChar = true;
/* 422 */         if ((offset > 0) || ((offset == 0) && (keyLength == 0))) {
/* 423 */           if (keyLength == -1) {
/* 424 */             keyLength = offset;
/*     */           }
/* 426 */           String temp = new String(buf, 0, offset);
/* 427 */           put(Enum.valueOf(ReportField.class, temp.substring(0, keyLength)), temp.substring(keyLength));
/*     */         }
/* 429 */         keyLength = -1;
/* 430 */         offset = 0;
/* 431 */         break;
/*     */       case '\\':
/* 433 */         if (mode == 4) {
/* 434 */           keyLength = offset;
/*     */         }
/* 436 */         mode = 1;
/* 437 */         break;
/*     */       case ':':
/*     */       case '=':
/* 440 */         if (keyLength == -1) {
/* 441 */           mode = 0;
/* 442 */           keyLength = offset;
/* 443 */         }break;
/*     */       default:
/* 447 */         if (Character.isWhitespace(nextChar)) {
/* 448 */           if (mode == 3) {
/* 449 */             mode = 5;
/*     */           }
/*     */ 
/* 452 */           if ((offset == 0) || (offset == keyLength) || (mode == 5)) {
/*     */             continue;
/*     */           }
/* 455 */           if (keyLength == -1) {
/* 456 */             mode = 4;
/* 457 */             continue;
/*     */           }
/*     */         }
/* 460 */         if ((mode == 5) || (mode == 3)) {
/* 461 */           mode = 0;
/*     */         }
/*     */ 
/* 464 */         firstChar = false;
/* 465 */         if (mode == 4) {
/* 466 */           keyLength = offset;
/* 467 */           mode = 0;
/*     */         }
/* 469 */         buf[(offset++)] = nextChar;
/*     */       }
/*     */     }
/* 471 */     if ((mode == 2) && (count <= 4))
/*     */     {
/* 473 */       throw new IllegalArgumentException("luni.08");
/*     */     }
/* 475 */     if ((keyLength == -1) && (offset > 0)) {
/* 476 */       keyLength = offset;
/*     */     }
/* 478 */     if (keyLength >= 0) {
/* 479 */       String temp = new String(buf, 0, offset);
/* 480 */       ReportField key = (ReportField)Enum.valueOf(ReportField.class, temp.substring(0, keyLength));
/* 481 */       String value = temp.substring(keyLength);
/* 482 */       if (mode == 1) {
/* 483 */         value = new StringBuilder().append(value).append("").toString();
/*     */       }
/* 485 */       put(key, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String put(ReportField key, String value, Writer writer)
/*     */     throws IOException
/*     */   {
/* 492 */     String result = (String)put(key, value);
/* 493 */     if (writer != null) {
/* 494 */       storeKeyValuePair(writer, key, value);
/*     */     }
/* 496 */     return result;
/*     */   }
/*     */ 
/*     */   private Enumeration<ReportField> keys() {
/* 500 */     return Collections.enumeration(keySet());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void save(OutputStream out, String comment)
/*     */   {
/*     */     try
/*     */     {
/* 522 */       store(out, comment);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object setProperty(ReportField key, String value)
/*     */   {
/* 538 */     return put(key, value);
/*     */   }
/*     */ 
/*     */   public synchronized void store(OutputStream out, String comment)
/*     */     throws IOException
/*     */   {
/* 558 */     store(getWriter(out), comment);
/*     */   }
/*     */ 
/*     */   public static Writer getWriter(OutputStream out) {
/*     */     try {
/* 563 */       return new OutputStreamWriter(out, "ISO8859_1"); } catch (UnsupportedEncodingException ux) {
/*     */     }
/* 565 */     return null;
/*     */   }
/*     */ 
/*     */   public synchronized void store(Writer writer, String comment)
/*     */     throws IOException
/*     */   {
/* 583 */     if (comment != null) {
/* 584 */       storeComment(writer, comment);
/*     */     }
/* 586 */     for (Map.Entry entry : entrySet()) {
/* 587 */       storeKeyValuePair(writer, (ReportField)entry.getKey(), (String)entry.getValue());
/*     */     }
/* 589 */     writer.flush();
/*     */   }
/*     */ 
/*     */   public synchronized void storeComment(Writer writer, String comment) throws IOException {
/* 593 */     writer.write("#");
/* 594 */     writer.write(comment);
/* 595 */     writer.write(lineSeparator);
/*     */   }
/*     */ 
/*     */   public synchronized void storeKeyValuePair(Writer writer, ReportField key, String value) throws IOException
/*     */   {
/* 600 */     String keyString = key.toString();
/* 601 */     String valueString = value == null ? "" : value;
/*     */ 
/* 603 */     int totalLength = keyString.length() + valueString.length() + 1;
/*     */ 
/* 605 */     StringBuilder sb = new StringBuilder(totalLength + totalLength / 5);
/*     */ 
/* 607 */     dumpString(sb, keyString, true);
/* 608 */     sb.append('=');
/* 609 */     dumpString(sb, valueString, false);
/* 610 */     sb.append(lineSeparator);
/*     */ 
/* 612 */     writer.write(sb.toString());
/* 613 */     writer.flush();
/*     */   }
/*     */ 
/*     */   public void storeToXML(OutputStream os, String comment)
/*     */     throws IOException
/*     */   {
/* 729 */     storeToXML(os, comment, "UTF-8");
/*     */   }
/*     */ 
/*     */   public synchronized void storeToXML(OutputStream os, String comment, String encoding)
/*     */     throws IOException
/*     */   {
/* 756 */     if ((os == null) || (encoding == null)) {
/* 757 */       throw new NullPointerException();
/*     */     }
/*     */ 
/*     */     String encodingCanonicalName;
/*     */     try
/*     */     {
/* 769 */       encodingCanonicalName = Charset.forName(encoding).name();
/*     */     } catch (IllegalCharsetNameException e) {
/* 771 */       System.out.println(new StringBuilder().append("Warning: encoding name ").append(encoding).append(" is illegal, using UTF-8 as default encoding").toString());
/* 772 */       encodingCanonicalName = "UTF-8";
/*     */     } catch (UnsupportedCharsetException e) {
/* 774 */       System.out.println(new StringBuilder().append("Warning: encoding ").append(encoding).append(" is not supported, using UTF-8 as default encoding").toString());
/* 775 */       encodingCanonicalName = "UTF-8";
/*     */     }
/*     */ 
/* 778 */     PrintStream printStream = new PrintStream(os, false, encodingCanonicalName);
/*     */ 
/* 780 */     printStream.print("<?xml version=\"1.0\" encoding=\"");
/* 781 */     printStream.print(encodingCanonicalName);
/* 782 */     printStream.println("\"?>");
/*     */ 
/* 784 */     printStream.print("<!DOCTYPE properties SYSTEM \"");
/* 785 */     printStream.print("http://java.sun.com/dtd/properties.dtd");
/* 786 */     printStream.println("\">");
/*     */ 
/* 788 */     printStream.println("<properties>");
/*     */ 
/* 790 */     if (comment != null) {
/* 791 */       printStream.print("<comment>");
/* 792 */       printStream.print(substitutePredefinedEntries(comment));
/* 793 */       printStream.println("</comment>");
/*     */     }
/*     */ 
/* 796 */     for (Map.Entry entry : entrySet()) {
/* 797 */       String keyValue = ((ReportField)entry.getKey()).toString();
/* 798 */       String entryValue = (String)entry.getValue();
/* 799 */       printStream.print("<entry key=\"");
/* 800 */       printStream.print(substitutePredefinedEntries(keyValue));
/* 801 */       printStream.print("\">");
/* 802 */       printStream.print(substitutePredefinedEntries(entryValue));
/* 803 */       printStream.println("</entry>");
/*     */     }
/* 805 */     printStream.println("</properties>");
/* 806 */     printStream.flush();
/*     */   }
/*     */ 
/*     */   private String substitutePredefinedEntries(String s)
/*     */   {
/* 815 */     return s.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("'", "&apos;").replaceAll("\"", "&quot;");
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.CrashReportData
 * JD-Core Version:    0.6.0
 */