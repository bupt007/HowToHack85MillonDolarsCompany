/*    */ package com.parse;
/*    */ 
/*    */ import android.util.Log;
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseCrashReportHandler
/*    */   implements ReportSender
/*    */ {
/* 18 */   private static final ReportField[] CRASH_REPORT_FIELDS = { ReportField.REPORT_ID, ReportField.APP_INSTALL_TIME, ReportField.APP_UPGRADE_TIME, ReportField.AVAILABLE_MEM_SIZE, ReportField.BRAND, ReportField.BUILD, ReportField.CRASH_CONFIGURATION, ReportField.DEVICE_FEATURES, ReportField.DEVICE_UPTIME, ReportField.DUMPSYS_MEMINFO, ReportField.EXCEPTION_CAUSE, ReportField.IS_LOW_RAM_DEVICE, ReportField.IS_SILENT, ReportField.OPEN_FD_COUNT, ReportField.OPEN_FD_HARD_LIMIT, ReportField.OPEN_FD_SOFT_LIMIT, ReportField.PACKAGE_NAME, ReportField.PHONE_MODEL, ReportField.PROCESS_NAME, ReportField.PROCESS_UPTIME, ReportField.PRODUCT, ReportField.SIGQUIT, ReportField.STACK_TRACE, ReportField.TOTAL_MEM_SIZE, ReportField.USER_APP_START_DATE, ReportField.USER_CRASH_DATE };
/*    */ 
/*    */   public void send(CrashReportData crashReportData)
/*    */     throws ReportSenderException
/*    */   {
/*    */     JSONObject payload;
/*    */     try
/*    */     {
/* 56 */       payload = getCrashReportEventPayload(crashReportData);
/*    */     } catch (JSONException e) {
/* 58 */       throw new ReportSenderException("Failed to convert crash report into event payload", e);
/*    */     }
/* 60 */     Log.d("CrashReporting", "Sending crash report to Parse...");
/* 61 */     ParseCrashReporting.trackCrashReport(payload);
/*    */   }
/*    */ 
/*    */   private JSONObject getCrashReportEventPayload(CrashReportData crashReportData)
/*    */     throws JSONException
/*    */   {
/* 73 */     JSONObject jsonObject = new JSONObject();
/* 74 */     for (ReportField field : CRASH_REPORT_FIELDS) {
/* 75 */       jsonObject.put(field.toString(), crashReportData.get(field));
/*    */     }
/* 77 */     return jsonObject;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ParseCrashReportHandler
 * JD-Core Version:    0.6.0
 */