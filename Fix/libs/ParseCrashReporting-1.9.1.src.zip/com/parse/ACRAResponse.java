/*    */ package com.parse;
/*    */ 
/*    */ class ACRAResponse
/*    */ {
/*    */   private int mStatus;
/*    */ 
/*    */   public void setStatusCode(int status)
/*    */   {
/* 15 */     this.mStatus = status;
/*    */   }
/*    */ 
/*    */   public int getStatusCode() {
/* 19 */     return this.mStatus;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ACRAResponse
 * JD-Core Version:    0.6.0
 */