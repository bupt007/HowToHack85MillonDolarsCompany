/*    */ package com.parse;
/*    */ 
/*    */ class ReportSenderException extends Exception
/*    */ {
/*    */   public ReportSenderException(String detailMessage, Throwable throwable)
/*    */   {
/* 42 */     super(detailMessage, throwable);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.ReportSenderException
 * JD-Core Version:    0.6.0
 */