/*     */ package com.parse;
/*     */ 
/*     */ import android.app.ActivityManager;
/*     */ import android.app.ActivityManager.MemoryInfo;
/*     */ import android.content.Context;
/*     */ import android.os.Build.VERSION;
/*     */ import android.os.Debug;
/*     */ import android.os.Debug.MemoryInfo;
/*     */ import java.util.Locale;
/*     */ 
/*     */ class DumpSysCollector
/*     */ {
/*     */   protected static String collectMemInfo(Context context)
/*     */   {
/*  51 */     StringBuilder meminfo = new StringBuilder();
/*  52 */     ActivityManager am = (ActivityManager)context.getSystemService("activity");
/*  53 */     ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
/*  54 */     am.getMemoryInfo(mi);
/*  55 */     Debug.MemoryInfo dmi = new Debug.MemoryInfo();
/*  56 */     Debug.getMemoryInfo(dmi);
/*  57 */     int memclass = am.getMemoryClass();
/*  58 */     int pct_dn = (int)(100.0F * ((dmi.nativePrivateDirty + dmi.dalvikPrivateDirty) / (1024.0F * memclass)));
/*     */ 
/*  60 */     int pct_n = (int)(100 * dmi.nativePrivateDirty / (1024.0F * memclass));
/*  61 */     int pct_dno = (int)(100 * (dmi.nativePrivateDirty + dmi.dalvikPrivateDirty + dmi.otherPrivateDirty) / (1024.0F * memclass));
/*     */ 
/*  64 */     int pct_o = (int)(100 * dmi.otherPrivateDirty / (1024.0F * memclass));
/*     */ 
/*  66 */     meminfo.append(String.format(Locale.US, "percent dalvik+native / native / d+n+other / other %d / %d / %d / %d", new Object[] { Integer.valueOf(pct_dn), Integer.valueOf(pct_n), Integer.valueOf(pct_dno), Integer.valueOf(pct_o) }));
/*     */ 
/*  68 */     meminfo.append("avail/thresh/low? " + mi.availMem + "/" + mi.threshold + "/" + mi.lowMemory + "/" + "(" + (int)((float)(100L * mi.threshold) / (float)mi.availMem) + "%) memclass=" + memclass);
/*     */ 
/*  72 */     meminfo.append("DebugMemInfo(kB): Private / Proportional / Shared");
/*  73 */     meminfo.append(String.format(Locale.US, "          dalvik: %7d / %7d / %7d", new Object[] { Integer.valueOf(dmi.dalvikPrivateDirty), Integer.valueOf(dmi.dalvikPss), Integer.valueOf(dmi.dalvikSharedDirty) }));
/*     */ 
/*  76 */     meminfo.append(String.format(Locale.US, "          native: %7d / %7d / %7d", new Object[] { Integer.valueOf(dmi.dalvikPrivateDirty), Integer.valueOf(dmi.nativePss), Integer.valueOf(dmi.nativeSharedDirty) }));
/*     */ 
/*  79 */     meminfo.append(String.format(Locale.US, "           other: %7d / %7d / %7d", new Object[] { Integer.valueOf(dmi.otherPrivateDirty), Integer.valueOf(dmi.otherPss), Integer.valueOf(dmi.otherSharedDirty) }));
/*     */ 
/*  82 */     meminfo.append(String.format(Locale.US, "GC: %d GCs, %d freed, %d free count", new Object[] { Integer.valueOf(Debug.getGlobalGcInvocationCount()), Integer.valueOf(Debug.getGlobalFreedSize()), Integer.valueOf(Debug.getGlobalFreedCount()) }));
/*     */ 
/*  87 */     meminfo.append(String.format(Locale.US, "Native Heap: size/allocated/free %7d / %7d / %7d", new Object[] { Long.valueOf(Debug.getNativeHeapSize()), Long.valueOf(Debug.getNativeHeapAllocatedSize()), Long.valueOf(Debug.getNativeHeapFreeSize()) }));
/*     */ 
/*  92 */     meminfo.append(String.format(Locale.US, "Threads: alloc count/alloc size/ext ac/ext as %7d / %7d / %7d / %7d", new Object[] { Integer.valueOf(Debug.getThreadAllocCount()), Integer.valueOf(Debug.getThreadAllocSize()), Integer.valueOf(Debug.getThreadExternalAllocCount()), Integer.valueOf(Debug.getThreadExternalAllocSize()) }));
/*     */ 
/*  98 */     Runtime runtime = Runtime.getRuntime();
/*  99 */     meminfo.append(String.format(Locale.US, "Java Heap: size/allocated/free %7d / %7d / %7d", new Object[] { Long.valueOf(runtime.maxMemory()), Long.valueOf(runtime.totalMemory() - runtime.freeMemory()), Long.valueOf(runtime.freeMemory()) }));
/*     */ 
/* 104 */     return meminfo.toString();
/*     */   }
/*     */ 
/*     */   protected static String collectLargerMemoryInfo(Context context)
/*     */   {
/* 114 */     if (Build.VERSION.SDK_INT >= 11) {
/* 115 */       StringBuilder writer = new StringBuilder();
/* 116 */       ActivityManager am = (ActivityManager)context.getSystemService("activity");
/* 117 */       writer.append("Large heap size =" + am.getLargeMemoryClass());
/* 118 */       return writer.toString();
/*     */     }
/* 120 */     return "";
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.DumpSysCollector
 * JD-Core Version:    0.6.0
 */