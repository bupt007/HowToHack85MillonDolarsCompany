/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.text.format.Time;
/*     */ import android.util.Log;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ class DropBoxCollector
/*     */ {
/*  44 */   private static final String[] SYSTEM_TAGS = { "system_app_anr", "system_app_wtf", "system_app_crash", "system_server_anr", "system_server_wtf", "system_server_crash", "BATTERY_DISCHARGE_INFO", "SYSTEM_RECOVERY_LOG", "SYSTEM_BOOT", "SYSTEM_LAST_KMSG", "APANIC_CONSOLE", "APANIC_THREADS", "SYSTEM_RESTART", "SYSTEM_TOMBSTONE", "data_app_strictmode" };
/*     */ 
/*     */   public static String read(Context context, String[] additionalTags)
/*     */   {
/*     */     try
/*     */     {
/*  62 */       String serviceName = Compatibility.getDropBoxServiceName();
/*  63 */       if (serviceName != null) {
/*  64 */         StringBuilder dropboxContent = new StringBuilder();
/*  65 */         Object dropbox = context.getSystemService(serviceName);
/*  66 */         Method getNextEntry = dropbox.getClass().getMethod("getNextEntry", new Class[] { String.class, Long.TYPE });
/*  67 */         if (getNextEntry != null) {
/*  68 */           Time timer = new Time();
/*  69 */           timer.setToNow();
/*  70 */           timer.minute -= ACRA.getConfig().dropboxCollectionMinutes();
/*  71 */           timer.normalize(false);
/*  72 */           long time = timer.toMillis(false);
/*     */           ArrayList tags;
/*     */           ArrayList tags;
/*  74 */           if (ACRA.getConfig().includeDropBoxSystemTags())
/*  75 */             tags = new ArrayList(Arrays.asList(SYSTEM_TAGS));
/*     */           else {
/*  77 */             tags = new ArrayList();
/*     */           }
/*  79 */           if ((additionalTags != null) && (additionalTags.length > 0)) {
/*  80 */             tags.addAll(Arrays.asList(additionalTags));
/*     */           }
/*  82 */           String text = null;
/*  83 */           Object entry = null;
/*  84 */           if (tags.size() > 0) {
/*  85 */             for (String tag : tags) {
/*  86 */               long msec = time;
/*  87 */               dropboxContent.append("Tag: ").append(tag).append('\n');
/*  88 */               entry = getNextEntry.invoke(dropbox, new Object[] { tag, Long.valueOf(msec) });
/*  89 */               if (entry != null) {
/*  90 */                 Method getText = entry.getClass().getMethod("getText", new Class[] { Integer.TYPE });
/*  91 */                 Method getTimeMillis = entry.getClass().getMethod("getTimeMillis", (Class[])null);
/*  92 */                 Method close = entry.getClass().getMethod("close", (Class[])null);
/*  93 */                 while (entry != null) {
/*  94 */                   msec = ((Long)getTimeMillis.invoke(entry, (Object[])null)).longValue();
/*  95 */                   timer.set(msec);
/*  96 */                   dropboxContent.append("@").append(timer.format2445()).append('\n');
/*  97 */                   text = (String)getText.invoke(entry, new Object[] { Integer.valueOf(500) });
/*  98 */                   if (text != null)
/*  99 */                     dropboxContent.append("Text: ").append(text).append('\n');
/*     */                   else {
/* 101 */                     dropboxContent.append("Not Text!").append('\n');
/*     */                   }
/* 103 */                   close.invoke(entry, (Object[])null);
/* 104 */                   entry = getNextEntry.invoke(dropbox, new Object[] { tag, Long.valueOf(msec) });
/*     */                 }
/*     */               } else {
/* 107 */                 dropboxContent.append("Nothing.").append('\n');
/*     */               }
/*     */             }
/*     */           }
/*     */           else {
/* 112 */             dropboxContent.append("No tag configured for collection.");
/*     */           }
/*     */         }
/* 115 */         return dropboxContent.toString();
/*     */       }
/*     */     } catch (SecurityException e) {
/* 118 */       Log.i("CrashReporting", "DropBoxManager not available.");
/*     */     } catch (NoSuchMethodException e) {
/* 120 */       Log.i("CrashReporting", "DropBoxManager not available.");
/*     */     } catch (IllegalArgumentException e) {
/* 122 */       Log.i("CrashReporting", "DropBoxManager not available.");
/*     */     } catch (IllegalAccessException e) {
/* 124 */       Log.i("CrashReporting", "DropBoxManager not available.");
/*     */     } catch (InvocationTargetException e) {
/* 126 */       Log.i("CrashReporting", "DropBoxManager not available.");
/*     */     } catch (NoSuchFieldException e) {
/* 128 */       Log.i("CrashReporting", "DropBoxManager not available.");
/*     */     }
/* 130 */     return "N/A";
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.DropBoxCollector
 * JD-Core Version:    0.6.0
 */