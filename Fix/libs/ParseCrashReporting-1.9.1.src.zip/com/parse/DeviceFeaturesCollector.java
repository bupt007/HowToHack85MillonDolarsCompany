/*    */ package com.parse;
/*    */ 
/*    */ import android.content.Context;
/*    */ import android.content.pm.PackageManager;
/*    */ import android.util.Log;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ class DeviceFeaturesCollector
/*    */ {
/*    */   public static String getFeatures(Context ctx)
/*    */   {
/* 39 */     if (Compatibility.getAPILevel() >= 5) {
/* 40 */       StringBuffer result = new StringBuffer();
/*    */       try {
/* 42 */         PackageManager pm = ctx.getPackageManager();
/* 43 */         Method getSystemAvailableFeatures = PackageManager.class.getMethod("getSystemAvailableFeatures", (Class[])null);
/*    */ 
/* 45 */         Object[] features = (Object[])(Object[])getSystemAvailableFeatures.invoke(pm, new Object[0]);
/* 46 */         if (features != null)
/* 47 */           for (Object feature : features) {
/* 48 */             String featureName = (String)feature.getClass().getField("name").get(feature);
/* 49 */             if (featureName != null) {
/* 50 */               result.append(featureName);
/*    */             } else {
/* 52 */               Method getGlEsVersion = feature.getClass().getMethod("getGlEsVersion", (Class[])null);
/*    */ 
/* 54 */               String glEsVersion = (String)getGlEsVersion.invoke(feature, new Object[0]);
/* 55 */               result.append("glEsVersion = ");
/* 56 */               result.append(glEsVersion);
/*    */             }
/* 58 */             result.append("\n");
/*    */           }
/*    */       }
/*    */       catch (Throwable e) {
/* 62 */         Log.w("CrashReporting", "Couldn't retrieve device features for " + ctx.getPackageName(), e);
/* 63 */         result.append("Could not retrieve data: ");
/* 64 */         result.append(e.getMessage());
/*    */       }
/*    */ 
/* 67 */       return result.toString();
/*    */     }
/* 69 */     return "Data available only with API Level > 5";
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.DeviceFeaturesCollector
 * JD-Core Version:    0.6.0
 */