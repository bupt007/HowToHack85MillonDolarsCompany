/*    */ package com.parse;
/*    */ 
/*    */ import android.content.Context;
/*    */ import android.content.pm.PackageInfo;
/*    */ import android.content.pm.PackageManager;
/*    */ import android.content.pm.PackageManager.NameNotFoundException;
/*    */ import android.util.Log;
/*    */ 
/*    */ final class PackageManagerWrapper
/*    */ {
/*    */   private final Context context;
/*    */ 
/*    */   public PackageManagerWrapper(Context context)
/*    */   {
/* 37 */     this.context = context;
/*    */   }
/*    */ 
/*    */   public boolean hasPermission(String permission)
/*    */   {
/* 45 */     PackageManager pm = this.context.getPackageManager();
/* 46 */     if (pm == null) {
/* 47 */       return false;
/*    */     }
/*    */     try
/*    */     {
/* 51 */       return pm.checkPermission(permission, this.context.getPackageName()) == 0;
/*    */     }
/*    */     catch (RuntimeException e) {
/*    */     }
/* 55 */     return false;
/*    */   }
/*    */ 
/*    */   public PackageInfo getPackageInfo()
/*    */   {
/* 63 */     PackageManager pm = this.context.getPackageManager();
/* 64 */     if (pm == null) {
/* 65 */       return null;
/*    */     }
/*    */     try
/*    */     {
/* 69 */       return pm.getPackageInfo(this.context.getPackageName(), 0);
/*    */     } catch (PackageManager.NameNotFoundException e) {
/* 71 */       Log.v("CrashReporting", "Failed to find PackageInfo for current App : " + this.context.getPackageName());
/* 72 */       return null;
/*    */     }
/*    */     catch (RuntimeException e) {
/*    */     }
/* 76 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.PackageManagerWrapper
 * JD-Core Version:    0.6.0
 */