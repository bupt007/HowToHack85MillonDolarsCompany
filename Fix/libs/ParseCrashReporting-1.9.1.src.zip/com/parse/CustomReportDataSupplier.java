package com.parse;

abstract interface CustomReportDataSupplier
{
  public abstract String getCustomData(Throwable paramThrowable);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.CustomReportDataSupplier
 * JD-Core Version:    0.6.0
 */