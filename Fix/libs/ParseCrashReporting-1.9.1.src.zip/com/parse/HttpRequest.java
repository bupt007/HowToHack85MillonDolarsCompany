/*    */ package com.parse;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URL;
/*    */ import java.util.zip.GZIPOutputStream;
/*    */ 
/*    */ class HttpRequest
/*    */ {
/*    */   private HttpConnectionProvider mConnectionProvider;
/*    */   public static final String POST_CONTENT_TYPE_FORM_URLENCODED = "application/x-www-form-urlencoded";
/*    */   public static final String POST_CONTENT_TYPE_JSON = "application/json";
/*    */ 
/*    */   public HttpRequest(HttpConnectionProvider connectionProvider)
/*    */   {
/* 22 */     this.mConnectionProvider = connectionProvider;
/*    */   }
/*    */ 
/*    */   public void sendPost(URL url, String data, ACRAResponse response)
/*    */     throws IOException
/*    */   {
/* 33 */     sendPost(url, data, response, "application/x-www-form-urlencoded");
/*    */   }
/*    */ 
/*    */   public void sendPost(URL url, String data, ACRAResponse response, String contentType)
/*    */     throws IOException
/*    */   {
/* 45 */     HttpURLConnection urlConnection = null;
/* 46 */     urlConnection = this.mConnectionProvider.getConnection(url);
/*    */ 
/* 48 */     urlConnection.setRequestMethod("POST");
/* 49 */     urlConnection.setRequestProperty("User-Agent", "Android");
/* 50 */     urlConnection.setRequestProperty("Content-Type", contentType);
/* 51 */     urlConnection.setRequestProperty("Content-Encoding", "gzip");
/* 52 */     urlConnection.setDoOutput(true);
/*    */     try
/*    */     {
/* 55 */       GZIPOutputStream gzipStream = new GZIPOutputStream(urlConnection.getOutputStream());
/* 56 */       gzipStream.write(data.getBytes());
/* 57 */       gzipStream.close();
/* 58 */       int responseCode = urlConnection.getResponseCode();
/* 59 */       response.setStatusCode(responseCode);
/* 60 */       urlConnection.getInputStream().close();
/*    */     } finally {
/* 62 */       urlConnection.disconnect();
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.HttpRequest
 * JD-Core Version:    0.6.0
 */