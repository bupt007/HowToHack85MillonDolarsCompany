/*    */ package com.parse;
/*    */ 
/*    */ import android.content.Context;
/*    */ import android.os.Build.VERSION;
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ class Compatibility
/*    */ {
/*    */   static int getAPILevel()
/*    */   {
/*    */     int apiLevel;
/*    */     try
/*    */     {
/* 46 */       Field SDK_INT = Build.VERSION.class.getField("SDK_INT");
/* 47 */       apiLevel = SDK_INT.getInt(null);
/*    */     } catch (SecurityException e) {
/* 49 */       apiLevel = Integer.parseInt(Build.VERSION.SDK);
/*    */     } catch (NoSuchFieldException e) {
/* 51 */       apiLevel = Integer.parseInt(Build.VERSION.SDK);
/*    */     } catch (IllegalArgumentException e) {
/* 53 */       apiLevel = Integer.parseInt(Build.VERSION.SDK);
/*    */     } catch (IllegalAccessException e) {
/* 55 */       apiLevel = Integer.parseInt(Build.VERSION.SDK);
/*    */     }
/*    */ 
/* 58 */     return apiLevel;
/*    */   }
/*    */ 
/*    */   static String getDropBoxServiceName()
/*    */     throws SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException
/*    */   {
/* 72 */     Field serviceName = Context.class.getField("DROPBOX_SERVICE");
/* 73 */     if (serviceName != null) {
/* 74 */       return (String)serviceName.get(null);
/*    */     }
/* 76 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.Compatibility
 * JD-Core Version:    0.6.0
 */