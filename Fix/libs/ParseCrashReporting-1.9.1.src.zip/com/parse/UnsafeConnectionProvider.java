/*    */ package com.parse;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URL;
/*    */ import java.security.KeyManagementException;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import javax.net.ssl.HostnameVerifier;
/*    */ import javax.net.ssl.HttpsURLConnection;
/*    */ import javax.net.ssl.SSLContext;
/*    */ import javax.net.ssl.SSLSession;
/*    */ import javax.net.ssl.SSLSocketFactory;
/*    */ import javax.net.ssl.TrustManager;
/*    */ 
/*    */ class UnsafeConnectionProvider
/*    */   implements HttpConnectionProvider
/*    */ {
/*    */   public HttpURLConnection getConnection(URL url)
/*    */     throws IOException
/*    */   {
/* 29 */     HttpURLConnection conn = (HttpURLConnection)url.openConnection();
/* 30 */     if ((conn instanceof HttpsURLConnection))
/*    */       try {
/* 32 */         SSLContext ctx = SSLContext.getInstance("TLS");
/* 33 */         TrustManager[] manager = { new TrustEveryoneTrustManager() };
/* 34 */         ctx.init(null, manager, null);
/* 35 */         SSLSocketFactory trustEveryoneSocketFactory = ctx.getSocketFactory();
/* 36 */         HttpsURLConnection httpsConnection = (HttpsURLConnection)conn;
/* 37 */         httpsConnection.setSSLSocketFactory(trustEveryoneSocketFactory);
/* 38 */         httpsConnection.setHostnameVerifier(new HostnameVerifier()
/*    */         {
/*    */           public boolean verify(String s, SSLSession sslSession) {
/* 41 */             return true;
/*    */           }
/*    */         });
/*    */       }
/*    */       catch (NoSuchAlgorithmException e)
/*    */       {
/*    */       }
/*    */       catch (KeyManagementException e) {
/*    */       }
/* 51 */     return initializeConnectionParameters(conn);
/*    */   }
/*    */ 
/*    */   public HttpURLConnection initializeConnectionParameters(HttpURLConnection conn) {
/* 55 */     conn.setConnectTimeout(ACRA.getConfig().socketTimeout());
/* 56 */     conn.setReadTimeout(ACRA.getConfig().socketTimeout());
/* 57 */     return conn;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.UnsafeConnectionProvider
 * JD-Core Version:    0.6.0
 */