/*    */ package com.parse;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URL;
/*    */ 
/*    */ class SSLConnectionProvider
/*    */   implements HttpConnectionProvider
/*    */ {
/*    */   public HttpURLConnection getConnection(URL url)
/*    */     throws IOException
/*    */   {
/* 16 */     HttpURLConnection conn = (HttpURLConnection)url.openConnection();
/* 17 */     return initializeConnectionParameters(conn);
/*    */   }
/*    */ 
/*    */   public HttpURLConnection initializeConnectionParameters(HttpURLConnection conn) {
/* 21 */     conn.setConnectTimeout(ACRA.getConfig().socketTimeout());
/* 22 */     conn.setReadTimeout(ACRA.getConfig().socketTimeout());
/* 23 */     return conn;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.SSLConnectionProvider
 * JD-Core Version:    0.6.0
 */