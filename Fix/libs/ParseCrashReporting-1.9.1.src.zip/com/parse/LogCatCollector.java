/*     */ package com.parse;
/*     */ 
/*     */ import android.util.Log;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ class LogCatCollector
/*     */ {
/*     */   private static final int DEFAULT_TAIL_COUNT = 100;
/*     */ 
/*     */   protected static String collectLogCat(String bufferName)
/*     */   {
/*  62 */     BoundedLinkedList logcatBuf = null;
/*     */     try {
/*  64 */       ArrayList commandLine = new ArrayList();
/*  65 */       commandLine.add("logcat");
/*  66 */       if (bufferName != null) {
/*  67 */         commandLine.add("-b");
/*  68 */         commandLine.add(bufferName);
/*     */       }
/*     */ 
/*  72 */       int tailCount = -1;
/*  73 */       List logcatArgumentsList = new ArrayList(Arrays.asList(ACRA.getConfig().logcatArguments()));
/*     */ 
/*  75 */       int tailIndex = logcatArgumentsList.indexOf("-t");
/*  76 */       if ((tailIndex > -1) && (tailIndex < logcatArgumentsList.size())) {
/*  77 */         tailCount = Integer.parseInt((String)logcatArgumentsList.get(tailIndex + 1));
/*  78 */         if (Compatibility.getAPILevel() < 8) {
/*  79 */           logcatArgumentsList.remove(tailIndex + 1);
/*  80 */           logcatArgumentsList.remove(tailIndex);
/*  81 */           logcatArgumentsList.add("-d");
/*     */         }
/*     */       }
/*  84 */       logcatBuf = new BoundedLinkedList(tailCount > 0 ? tailCount : 100);
/*  85 */       commandLine.addAll(logcatArgumentsList);
/*     */ 
/*  87 */       Process process = Runtime.getRuntime().exec((String[])commandLine.toArray(new String[commandLine.size()]));
/*  88 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
/*     */ 
/*  90 */       Log.d("CrashReporting", "Retrieving logcat output...");
/*     */       String line;
/*  92 */       while ((line = bufferedReader.readLine()) != null)
/*  93 */         logcatBuf.add(line + "\n");
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  97 */       Log.e("CrashReporting", "LogCatCollector.collectLogcat could not retrieve data.", e);
/*     */     }
/*     */ 
/* 100 */     return logcatBuf.toString();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.LogCatCollector
 * JD-Core Version:    0.6.0
 */