/*     */ package com.parse;
/*     */ 
/*     */ import android.net.Uri;
/*     */ import android.util.Log;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ class HttpPostSender
/*     */   implements ReportSender
/*     */ {
/*  74 */   private Uri mFormUri = null;
/*     */ 
/*     */   public HttpPostSender(String formUri)
/*     */   {
/*  86 */     this.mFormUri = Uri.parse(formUri);
/*     */   }
/*     */ 
/*     */   public void send(CrashReportData report)
/*     */     throws ReportSenderException
/*     */   {
/*     */     try
/*     */     {
/*  94 */       Map finalReport = remap(report);
/*  95 */       URL reportUrl = new URL(this.mFormUri.toString());
/*  96 */       Log.d("CrashReporting", "Connect to " + reportUrl.toString());
/*  97 */       HttpUtils.doPost(finalReport, reportUrl, ACRA.getConfig().formPostFormat());
/*     */     } catch (Exception e) {
/*  99 */       throw new ReportSenderException("Error while sending report to Http Post Form.", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Map<String, String> remap(Map<ReportField, String> report)
/*     */   {
/* 105 */     Map finalReport = new HashMap(report.size());
/* 106 */     for (ReportField field : ACRA.ALL_CRASH_REPORT_FIELDS) {
/* 107 */       finalReport.put(field.toString(), report.get(field));
/*     */     }
/* 109 */     return finalReport;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\ParseCrashReporting-1.9.1.jar
 * Qualified Name:     com.parse.HttpPostSender
 * JD-Core Version:    0.6.0
 */