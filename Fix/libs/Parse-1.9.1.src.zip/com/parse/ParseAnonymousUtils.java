/*    */ package com.parse;
/*    */ 
/*    */ import bolts.Task;
/*    */ import org.json.JSONException;
/*    */ 
/*    */ public final class ParseAnonymousUtils
/*    */ {
/*    */   private static AnonymousAuthenticationProvider provider;
/*    */   static final String AUTH_TYPE = "anonymous";
/*    */   static final String SERVICE_NAME = "anonymous";
/*    */ 
/*    */   private static AnonymousAuthenticationProvider getProvider()
/*    */   {
/* 35 */     if (provider == null) {
/* 36 */       provider = new AnonymousAuthenticationProvider();
/* 37 */       ParseUser.registerAuthenticationProvider(provider);
/*    */     }
/* 39 */     return provider;
/*    */   }
/*    */ 
/*    */   public static boolean isLinked(ParseUser user)
/*    */   {
/* 51 */     return user.isLinked("anonymous");
/*    */   }
/*    */ 
/*    */   public static Task<ParseUser> logInInBackground()
/*    */   {
/* 60 */     return getProvider().logInAsync();
/*    */   }
/*    */ 
/*    */   public static void logIn(LogInCallback callback)
/*    */   {
/* 70 */     Parse.callbackOnMainThreadAsync(logInInBackground(), callback);
/*    */   }
/*    */ 
/*    */   static ParseUser lazyLogIn() {
/*    */     try {
/* 75 */       AnonymousAuthenticationProvider provider = getProvider();
/* 76 */       return ParseUser.logInLazyUser(provider.getAuthType(), provider.getAuthData()); } catch (JSONException e) {
/*    */     }
/* 78 */     throw new RuntimeException(e);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseAnonymousUtils
 * JD-Core Version:    0.6.0
 */