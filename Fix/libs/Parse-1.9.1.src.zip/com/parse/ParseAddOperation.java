/*    */ package com.parse;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.json.JSONArray;
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseAddOperation
/*    */   implements ParseFieldOperation
/*    */ {
/* 15 */   protected final ArrayList<Object> objects = new ArrayList();
/*    */ 
/*    */   public ParseAddOperation(Collection<?> coll) {
/* 18 */     this.objects.addAll(coll);
/*    */   }
/*    */ 
/*    */   public JSONObject encode(ParseObjectEncodingStrategy objectEncoder) throws JSONException
/*    */   {
/* 23 */     JSONObject output = new JSONObject();
/* 24 */     output.put("__op", "Add");
/* 25 */     output.put("objects", Parse.encode(this.objects, objectEncoder));
/* 26 */     return output;
/*    */   }
/*    */ 
/*    */   public ParseFieldOperation mergeWithPrevious(ParseFieldOperation previous)
/*    */   {
/* 31 */     if (previous == null)
/* 32 */       return this;
/* 33 */     if ((previous instanceof ParseDeleteOperation))
/* 34 */       return new ParseSetOperation(this.objects);
/* 35 */     if ((previous instanceof ParseSetOperation)) {
/* 36 */       Object value = ((ParseSetOperation)previous).getValue();
/* 37 */       if ((value instanceof JSONArray)) {
/* 38 */         ArrayList result = ParseFieldOperations.jsonArrayAsArrayList((JSONArray)value);
/* 39 */         result.addAll(this.objects);
/* 40 */         return new ParseSetOperation(new JSONArray(result));
/* 41 */       }if ((value instanceof List)) {
/* 42 */         ArrayList result = new ArrayList((List)value);
/* 43 */         result.addAll(this.objects);
/* 44 */         return new ParseSetOperation(result);
/*    */       }
/* 46 */       throw new IllegalArgumentException("You can only add an item to a List or JSONArray.");
/*    */     }
/* 48 */     if ((previous instanceof ParseAddOperation)) {
/* 49 */       ArrayList result = new ArrayList(((ParseAddOperation)previous).objects);
/* 50 */       result.addAll(this.objects);
/* 51 */       return new ParseAddOperation(result);
/*    */     }
/* 53 */     throw new IllegalArgumentException("Operation is invalid after previous operation.");
/*    */   }
/*    */ 
/*    */   public Object apply(Object oldValue, ParseObject object, String key)
/*    */   {
/* 59 */     if (oldValue == null)
/* 60 */       return this.objects;
/* 61 */     if ((oldValue instanceof JSONArray)) {
/* 62 */       ArrayList old = ParseFieldOperations.jsonArrayAsArrayList((JSONArray)oldValue);
/*    */ 
/* 64 */       ArrayList newValue = (ArrayList)apply(old, object, key);
/* 65 */       return new JSONArray(newValue);
/* 66 */     }if ((oldValue instanceof List)) {
/* 67 */       ArrayList result = new ArrayList((List)oldValue);
/* 68 */       result.addAll(this.objects);
/* 69 */       return result;
/*    */     }
/* 71 */     throw new IllegalArgumentException("Operation is invalid after previous operation.");
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseAddOperation
 * JD-Core Version:    0.6.0
 */