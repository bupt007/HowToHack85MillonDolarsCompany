/*      */ package com.parse;
/*      */ 
/*      */ import android.content.Context;
/*      */ import android.content.pm.ActivityInfo;
/*      */ import android.content.pm.ResolveInfo;
/*      */ import android.os.Bundle;
/*      */ import android.util.Log;
/*      */ import bolts.AggregateException;
/*      */ import bolts.Continuation;
/*      */ import bolts.Task;
/*      */ import bolts.Task.TaskCompletionSource;
/*      */ import com.parse.codec.binary.Base64;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.SimpleTimeZone;
/*      */ import java.util.concurrent.CancellationException;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import org.json.JSONArray;
/*      */ import org.json.JSONException;
/*      */ import org.json.JSONObject;
/*      */ import org.json.JSONTokener;
/*      */ 
/*      */ public class Parse
/*      */ {
/*      */   private static final String TAG = "com.parse.Parse";
/*      */   private static final String PARSE_APPLICATION_ID = "com.parse.APPLICATION_ID";
/*      */   private static final String PARSE_CLIENT_KEY = "com.parse.CLIENT_KEY";
/*      */   public static final int LOG_LEVEL_VERBOSE = 2;
/*      */   public static final int LOG_LEVEL_DEBUG = 3;
/*      */   public static final int LOG_LEVEL_INFO = 4;
/*      */   public static final int LOG_LEVEL_WARNING = 5;
/*      */   public static final int LOG_LEVEL_ERROR = 6;
/*      */   public static final int LOG_LEVEL_NONE = 2147483647;
/*   59 */   private static int logLevel = 6;
/*      */   static Context applicationContext;
/*      */   static String applicationId;
/*      */   static String clientKey;
/*   66 */   static int maxParseFileSize = 10485760;
/*      */ 
/*   68 */   private static final Object MUTEX = new Object();
/*   69 */   static ParseEventuallyQueue eventuallyQueue = null;
/*      */   private static final DateFormat dateFormat;
/*      */   private static ScheduledExecutorService scheduledExecutor;
/*      */   private static final Object SCHEDULED_EXECUTOR_LOCK;
/*      */   private static final Object MUTEX_CALLBACKS;
/*      */   private static Set<ParseCallbacks> callbacks;
/*      */ 
/*      */   private Parse()
/*      */   {
/*   73 */     throw new AssertionError();
/*      */   }
/*      */ 
/*      */   public static void enableLocalDatastore(Context context)
/*      */   {
/*  103 */     if (isInitialized()) {
/*  104 */       throw new IllegalStateException("`Parse#enableLocalDatastore(Context)` must be invoked before `Parse#initialize(Context)`");
/*      */     }
/*      */ 
/*  107 */     OfflineStore.enableOfflineStore(context);
/*      */   }
/*      */ 
/*      */   public static void initialize(Context context)
/*      */   {
/*  150 */     applicationContext = context.getApplicationContext();
/*      */ 
/*  153 */     Bundle metaData = ManifestInfo.getApplicationMetadata(applicationContext);
/*  154 */     if (metaData != null) {
/*  155 */       String applicationId = metaData.getString("com.parse.APPLICATION_ID");
/*  156 */       String clientKey = metaData.getString("com.parse.CLIENT_KEY");
/*      */ 
/*  158 */       if (applicationId == null) {
/*  159 */         throw new RuntimeException("ApplicationId not defined. You must provide ApplicationId in AndroidManifest.xml.\n<meta-data\n    android:name=\"com.parse.APPLICATION_ID\"\n    android:value=\"<Your Application Id>\" />");
/*      */       }
/*      */ 
/*  165 */       if (clientKey == null) {
/*  166 */         throw new RuntimeException("ClientKey not defined. You must provide ClientKey in AndroidManifest.xml.\n<meta-data\n    android:name=\"com.parse.CLIENT_KEY\"\n    android:value=\"<Your Client Key>\" />");
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  173 */       throw new RuntimeException("Can't get Application Metadata");
/*      */     }
/*      */     String clientKey;
/*      */     String applicationId;
/*  175 */     initialize(context, applicationId, clientKey);
/*      */   }
/*      */ 
/*      */   public static void initialize(Context context, String applicationId, String clientKey)
/*      */   {
/*  205 */     ParseRequest.initialize(context);
/*  206 */     ParseKeyValueCache.initialize(context);
/*  207 */     ParseObject.registerParseSubclasses();
/*      */ 
/*  213 */     applicationId = applicationId;
/*  214 */     clientKey = clientKey;
/*  215 */     if (context != null) {
/*  216 */       applicationContext = context.getApplicationContext();
/*      */ 
/*  219 */       checkCacheApplicationId();
/*  220 */       new Thread("Parse.initialize Disk Check & Starting Command Cache")
/*      */       {
/*      */         public void run()
/*      */         {
/*  224 */           Parse.getEventuallyQueue();
/*      */         }
/*      */       }
/*  220 */       .start();
/*      */     }
/*      */ 
/*  229 */     ParseFieldOperations.registerDefaultDecoders();
/*      */ 
/*  231 */     if (!allParsePushIntentReceiversInternal()) {
/*  232 */       throw new SecurityException("To prevent external tampering to your app's notifications, all receivers registered to handle the following actions must have their exported attributes set to false: com.parse.push.intent.RECEIVE, com.parse.push.intent.OPEN, com.parse.push.intent.DELETE");
/*      */     }
/*      */ 
/*  240 */     GcmRegistrar.getInstance().updateAsync().continueWithTask(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception
/*      */       {
/*  244 */         return ParseUser.getCurrentUserAsync().makeVoid();
/*      */       }
/*      */     }).continueWith(new Continuation()
/*      */     {
/*      */       public Void then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/*  250 */         ParseConfig.getCurrentConfig();
/*  251 */         return null;
/*      */       }
/*      */     }
/*      */     , Task.BACKGROUND_EXECUTOR);
/*      */ 
/*  255 */     dispatchOnParseInitialized();
/*      */ 
/*  258 */     synchronized (MUTEX_CALLBACKS) {
/*  259 */       callbacks = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   static void destroy()
/*      */   {
/*      */     ParseEventuallyQueue queue;
/*  265 */     synchronized (MUTEX) {
/*  266 */       queue = eventuallyQueue;
/*  267 */       eventuallyQueue = null;
/*      */     }
/*  269 */     if (queue != null) {
/*  270 */       queue.onDestroy();
/*      */     }
/*      */ 
/*  273 */     synchronized (MUTEX) {
/*  274 */       applicationId = null;
/*  275 */       clientKey = null;
/*  276 */       applicationContext = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static boolean isInitialized()
/*      */   {
/*  284 */     return (applicationId != null) || (clientKey != null);
/*      */   }
/*      */ 
/*      */   private static boolean allParsePushIntentReceiversInternal()
/*      */   {
/*  298 */     List intentReceivers = ManifestInfo.getIntentReceivers(new String[] { "com.parse.push.intent.RECEIVE", "com.parse.push.intent.DELETE", "com.parse.push.intent.OPEN" });
/*      */ 
/*  303 */     for (ResolveInfo resolveInfo : intentReceivers) {
/*  304 */       if (resolveInfo.activityInfo.exported) {
/*  305 */         return false;
/*      */       }
/*      */     }
/*  308 */     return true;
/*      */   }
/*      */ 
/*      */   static Context getApplicationContext() {
/*  312 */     checkContext();
/*  313 */     return applicationContext;
/*      */   }
/*      */ 
/*      */   public static void setLogLevel(int logLevel)
/*      */   {
/*  334 */     logLevel = logLevel;
/*      */   }
/*      */ 
/*      */   public static int getLogLevel()
/*      */   {
/*  341 */     return logLevel;
/*      */   }
/*      */ 
/*      */   private static void log(int messageLogLevel, String tag, String message, Throwable tr) {
/*  345 */     if (messageLogLevel >= logLevel)
/*  346 */       if (tr == null)
/*  347 */         Log.println(logLevel, tag, message);
/*      */       else
/*  349 */         Log.println(logLevel, tag, new StringBuilder().append(message).append('\n').append(Log.getStackTraceString(tr)).toString());
/*      */   }
/*      */ 
/*      */   static void logV(String tag, String message, Throwable tr)
/*      */   {
/*  355 */     log(2, tag, message, tr);
/*      */   }
/*      */ 
/*      */   static void logV(String tag, String message) {
/*  359 */     logV(tag, message, null);
/*      */   }
/*      */ 
/*      */   static void logD(String tag, String message, Throwable tr) {
/*  363 */     log(3, tag, message, tr);
/*      */   }
/*      */ 
/*      */   static void logD(String tag, String message) {
/*  367 */     logD(tag, message, null);
/*      */   }
/*      */ 
/*      */   static void logI(String tag, String message, Throwable tr) {
/*  371 */     log(4, tag, message, tr);
/*      */   }
/*      */ 
/*      */   static void logI(String tag, String message) {
/*  375 */     logI(tag, message, null);
/*      */   }
/*      */ 
/*      */   static void logW(String tag, String message, Throwable tr) {
/*  379 */     log(5, tag, message, tr);
/*      */   }
/*      */ 
/*      */   static void logW(String tag, String message) {
/*  383 */     logW(tag, message, null);
/*      */   }
/*      */ 
/*      */   static void logE(String tag, String message, Throwable tr) {
/*  387 */     log(6, tag, message, tr);
/*      */   }
/*      */ 
/*      */   static void logE(String tag, String message) {
/*  391 */     logE(tag, message, null);
/*      */   }
/*      */ 
/*      */   static void setContextIfNeeded(Context context)
/*      */   {
/*  399 */     if (applicationContext == null)
/*  400 */       applicationContext = context;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   static File getParseDir()
/*      */   {
/*  410 */     synchronized (MUTEX) {
/*  411 */       checkContext();
/*  412 */       return applicationContext.getDir("Parse", 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   static File getParseCacheDir() {
/*  417 */     synchronized (MUTEX) {
/*  418 */       checkContext();
/*  419 */       File dir = new File(applicationContext.getCacheDir(), "com.parse");
/*  420 */       if (!dir.exists()) {
/*  421 */         dir.mkdirs();
/*      */       }
/*  423 */       return dir;
/*      */     }
/*      */   }
/*      */ 
/*      */   static File getParseCacheDir(String subDir) {
/*  428 */     synchronized (MUTEX) {
/*  429 */       File dir = new File(getParseCacheDir(), subDir);
/*  430 */       if (!dir.exists()) {
/*  431 */         dir.mkdirs();
/*      */       }
/*  433 */       return dir;
/*      */     }
/*      */   }
/*      */ 
/*      */   static File getParseFilesDir() {
/*  438 */     synchronized (MUTEX) {
/*  439 */       checkContext();
/*  440 */       File dir = new File(applicationContext.getFilesDir(), "com.parse");
/*  441 */       if (!dir.exists()) {
/*  442 */         dir.mkdirs();
/*      */       }
/*  444 */       return dir;
/*      */     }
/*      */   }
/*      */ 
/*      */   static File getParseFilesDir(String subDir) {
/*  449 */     synchronized (MUTEX) {
/*  450 */       File dir = new File(getParseFilesDir(), subDir);
/*  451 */       if (!dir.exists()) {
/*  452 */         dir.mkdirs();
/*      */       }
/*  454 */       return dir;
/*      */     }
/*      */   }
/*      */ 
/*      */   static void recursiveDelete(File file)
/*      */   {
/*  460 */     synchronized (MUTEX) {
/*  461 */       if (file.isDirectory()) {
/*  462 */         for (File f : file.listFiles()) {
/*  463 */           recursiveDelete(f);
/*      */         }
/*      */       }
/*  466 */       file.delete();
/*      */     }
/*      */   }
/*      */ 
/*      */   static void checkCacheApplicationId()
/*      */   {
/*  475 */     synchronized (MUTEX) {
/*  476 */       if (applicationId != null)
/*      */       {
/*  478 */         File applicationIdFile = new File(getParseDir(), "applicationId");
/*  479 */         if (applicationIdFile.exists())
/*      */         {
/*  481 */           boolean matches = false;
/*      */           try {
/*  483 */             RandomAccessFile f = new RandomAccessFile(applicationIdFile, "r");
/*  484 */             byte[] bytes = new byte[(int)f.length()];
/*  485 */             f.readFully(bytes);
/*  486 */             f.close();
/*  487 */             String diskApplicationId = new String(bytes, "UTF-8");
/*  488 */             matches = diskApplicationId.equals(applicationId);
/*      */           }
/*      */           catch (FileNotFoundException e)
/*      */           {
/*      */           }
/*      */           catch (IOException e) {
/*      */           }
/*  495 */           if (!matches)
/*      */           {
/*  497 */             recursiveDelete(getParseDir());
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  502 */         applicationIdFile = new File(getParseDir(), "applicationId");
/*      */         try {
/*  504 */           FileOutputStream out = new FileOutputStream(applicationIdFile);
/*  505 */           out.write(applicationId.getBytes("UTF-8"));
/*  506 */           out.close();
/*      */         }
/*      */         catch (FileNotFoundException e)
/*      */         {
/*      */         }
/*      */         catch (UnsupportedEncodingException e)
/*      */         {
/*      */         }
/*      */         catch (IOException e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static ParseEventuallyQueue getEventuallyQueue()
/*      */   {
/*  526 */     synchronized (MUTEX) {
/*  527 */       boolean isLocalDatastoreEnabled = OfflineStore.isEnabled();
/*  528 */       if ((eventuallyQueue == null) || ((isLocalDatastoreEnabled) && ((eventuallyQueue instanceof ParseCommandCache))) || ((!isLocalDatastoreEnabled) && ((eventuallyQueue instanceof ParsePinningEventuallyQueue))))
/*      */       {
/*  531 */         checkContext();
/*  532 */         eventuallyQueue = isLocalDatastoreEnabled ? new ParsePinningEventuallyQueue(applicationContext) : new ParseCommandCache(applicationContext);
/*      */ 
/*  539 */         if ((isLocalDatastoreEnabled) && (ParseCommandCache.getPendingCount() > 0)) {
/*  540 */           new ParseCommandCache(applicationContext);
/*      */         }
/*      */       }
/*  543 */       return eventuallyQueue;
/*      */     }
/*      */   }
/*      */ 
/*      */   static void checkInit() {
/*  548 */     if (applicationId == null) {
/*  549 */       throw new RuntimeException("applicationId is null. You must call Parse.initialize(Context) before using the Parse library.");
/*      */     }
/*      */ 
/*  553 */     if (clientKey == null)
/*  554 */       throw new RuntimeException("clientKey is null. You must call Parse.initialize(Context) before using the Parse library.");
/*      */   }
/*      */ 
/*      */   static void checkContext()
/*      */   {
/*  561 */     if (applicationContext == null)
/*  562 */       throw new RuntimeException("applicationContext is null. You must call Parse.initialize(Context) before using the Parse library.");
/*      */   }
/*      */ 
/*      */   static boolean hasPermission(String permission)
/*      */   {
/*  569 */     checkContext();
/*  570 */     return applicationContext.checkCallingOrSelfPermission(permission) == 0;
/*      */   }
/*      */ 
/*      */   static void requirePermission(String permission) {
/*  574 */     if (!hasPermission(permission))
/*  575 */       throw new IllegalStateException(new StringBuilder().append("To use this functionality, add this to your AndroidManifest.xml:\n<uses-permission android:name=\"").append(permission).append("\" />").toString());
/*      */   }
/*      */ 
/*      */   static boolean isValidType(Object value)
/*      */   {
/*  587 */     return ((value instanceof JSONObject)) || ((value instanceof JSONArray)) || ((value instanceof String)) || ((value instanceof Number)) || ((value instanceof Boolean)) || (value == JSONObject.NULL) || ((value instanceof ParseObject)) || ((value instanceof ParseACL)) || ((value instanceof ParseFile)) || ((value instanceof ParseGeoPoint)) || ((value instanceof Date)) || ((value instanceof byte[])) || ((value instanceof List)) || ((value instanceof Map)) || ((value instanceof ParseRelation));
/*      */   }
/*      */ 
/*      */   static Object encode(Object object, ParseObjectEncodingStrategy objectEncoder)
/*      */   {
/*      */     try
/*      */     {
/*  596 */       if ((object instanceof ParseObject)) {
/*  597 */         return objectEncoder.encodeRelatedObject((ParseObject)object);
/*      */       }
/*      */ 
/*  600 */       if ((object instanceof ParseQuery)) {
/*  601 */         ParseQuery query = (ParseQuery)object;
/*  602 */         return query.toREST();
/*      */       }
/*      */ 
/*  605 */       if ((object instanceof Date)) {
/*  606 */         return encodeDate((Date)object);
/*      */       }
/*      */ 
/*  609 */       if ((object instanceof byte[])) {
/*  610 */         JSONObject json = new JSONObject();
/*  611 */         json.put("__type", "Bytes");
/*  612 */         json.put("base64", Base64.encodeBase64String((byte[])(byte[])object));
/*  613 */         return json;
/*      */       }
/*      */ 
/*  616 */       if ((object instanceof ParseFile)) {
/*  617 */         return ((ParseFile)object).encode();
/*      */       }
/*      */ 
/*  620 */       if ((object instanceof ParseGeoPoint)) {
/*  621 */         ParseGeoPoint point = (ParseGeoPoint)object;
/*  622 */         JSONObject json = new JSONObject();
/*  623 */         json.put("__type", "GeoPoint");
/*  624 */         json.put("latitude", point.getLatitude());
/*  625 */         json.put("longitude", point.getLongitude());
/*  626 */         return json;
/*      */       }
/*      */ 
/*  629 */       if ((object instanceof ParseACL)) {
/*  630 */         ParseACL acl = (ParseACL)object;
/*  631 */         return acl.toJSONObject(objectEncoder);
/*      */       }
/*      */ 
/*  634 */       if ((object instanceof Map))
/*      */       {
/*  636 */         Map map = (Map)object;
/*  637 */         JSONObject json = new JSONObject();
/*  638 */         for (Map.Entry pair : map.entrySet()) {
/*  639 */           json.put((String)pair.getKey(), encode(pair.getValue(), objectEncoder));
/*      */         }
/*  641 */         return json;
/*      */       }
/*      */ 
/*  644 */       if ((object instanceof JSONObject)) {
/*  645 */         JSONObject map = (JSONObject)object;
/*  646 */         JSONObject json = new JSONObject();
/*  647 */         Iterator keys = map.keys();
/*  648 */         while (keys.hasNext()) {
/*  649 */           String key = (String)keys.next();
/*  650 */           json.put(key, encode(map.opt(key), objectEncoder));
/*      */         }
/*  652 */         return json;
/*      */       }
/*      */ 
/*  655 */       if ((object instanceof List)) {
/*  656 */         JSONArray array = new JSONArray();
/*  657 */         for (Iterator i$ = ((List)object).iterator(); i$.hasNext(); ) { Object item = i$.next();
/*  658 */           array.put(encode(item, objectEncoder));
/*      */         }
/*  660 */         return array;
/*      */       }
/*      */ 
/*  663 */       if ((object instanceof JSONArray)) {
/*  664 */         JSONArray array = (JSONArray)object;
/*  665 */         JSONArray json = new JSONArray();
/*  666 */         for (int i = 0; i < array.length(); i++) {
/*  667 */           json.put(encode(array.opt(i), objectEncoder));
/*      */         }
/*  669 */         return json;
/*      */       }
/*      */ 
/*  672 */       if ((object instanceof ParseRelation)) {
/*  673 */         ParseRelation relation = (ParseRelation)object;
/*  674 */         return relation.encodeToJSON(objectEncoder);
/*      */       }
/*      */ 
/*  677 */       if ((object instanceof ParseFieldOperation)) {
/*  678 */         return ((ParseFieldOperation)object).encode(objectEncoder);
/*      */       }
/*      */ 
/*  681 */       if ((object instanceof ParseQuery.RelationConstraint)) {
/*  682 */         return ((ParseQuery.RelationConstraint)object).encode(objectEncoder);
/*      */       }
/*      */ 
/*  685 */       if (object == null)
/*  686 */         return JSONObject.NULL;
/*      */     }
/*      */     catch (JSONException e)
/*      */     {
/*  690 */       throw new RuntimeException(e);
/*      */     }
/*      */ 
/*  693 */     if (isValidType(object)) {
/*  694 */       return object;
/*      */     }
/*      */ 
/*  697 */     throw new IllegalArgumentException(new StringBuilder().append("invalid type for ParseObject: ").append(object.getClass().toString()).toString());
/*      */   }
/*      */ 
/*      */   static Date stringToDate(String dateString)
/*      */   {
/*  706 */     synchronized (MUTEX) {
/*      */       try {
/*  708 */         return dateFormat.parse(dateString);
/*      */       }
/*      */       catch (java.text.ParseException e) {
/*  711 */         logE("com.parse.Parse", new StringBuilder().append("could not parse date: ").append(dateString).toString(), e);
/*  712 */         return null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static String dateToString(Date date) {
/*  718 */     synchronized (MUTEX) {
/*  719 */       return dateFormat.format(date);
/*      */     }
/*      */   }
/*      */ 
/*      */   static JSONObject encodeDate(Date date) {
/*  724 */     JSONObject object = new JSONObject();
/*  725 */     String iso = dateToString(date);
/*      */     try {
/*  727 */       object.put("__type", "Date");
/*  728 */       object.put("iso", iso);
/*      */     }
/*      */     catch (JSONException e) {
/*  731 */       throw new RuntimeException(e);
/*      */     }
/*  733 */     return object;
/*      */   }
/*      */ 
/*      */   static <T> List<List<T>> partitionList(List<T> list, int partitionSize) {
/*  737 */     List lists = new ArrayList();
/*  738 */     int index = 0;
/*  739 */     while (index < list.size()) {
/*  740 */       int length = Math.min(list.size() - index, partitionSize);
/*      */ 
/*  742 */       List sublist = list.subList(index, length);
/*  743 */       lists.add(sublist);
/*      */ 
/*  745 */       index += length;
/*      */     }
/*  747 */     return lists;
/*      */   }
/*      */ 
/*      */   static Iterable<String> keys(JSONObject object)
/*      */   {
/*  752 */     JSONObject finalObject = object;
/*  753 */     return new Iterable(finalObject)
/*      */     {
/*      */       public Iterator<String> iterator() {
/*  756 */         return this.val$finalObject.keys();
/*      */       } } ;
/*      */   }
/*      */ 
/*      */   static boolean isContainerObject(Object object) {
/*  762 */     return ((object instanceof JSONObject)) || ((object instanceof JSONArray)) || ((object instanceof ParseACL)) || ((object instanceof ParseGeoPoint)) || ((object instanceof List)) || ((object instanceof Map));
/*      */   }
/*      */ 
/*      */   static Number addNumbers(Number first, Number second)
/*      */   {
/*  767 */     if (((first instanceof Double)) || ((second instanceof Double)))
/*  768 */       return Double.valueOf(first.doubleValue() + second.doubleValue());
/*  769 */     if (((first instanceof Float)) || ((second instanceof Float)))
/*  770 */       return Float.valueOf(first.floatValue() + second.floatValue());
/*  771 */     if (((first instanceof Long)) || ((second instanceof Long)))
/*  772 */       return Long.valueOf(first.longValue() + second.longValue());
/*  773 */     if (((first instanceof Integer)) || ((second instanceof Integer)))
/*  774 */       return Integer.valueOf(first.intValue() + second.intValue());
/*  775 */     if (((first instanceof Short)) || ((second instanceof Short)))
/*  776 */       return Integer.valueOf(first.shortValue() + second.shortValue());
/*  777 */     if (((first instanceof Byte)) || ((second instanceof Byte))) {
/*  778 */       return Integer.valueOf(first.byteValue() + second.byteValue());
/*      */     }
/*  780 */     throw new RuntimeException("Unknown number type.");
/*      */   }
/*      */ 
/*      */   static Number subtractNumbers(Number first, Number second)
/*      */   {
/*  785 */     if (((first instanceof Double)) || ((second instanceof Double)))
/*  786 */       return Double.valueOf(first.doubleValue() - second.doubleValue());
/*  787 */     if (((first instanceof Float)) || ((second instanceof Float)))
/*  788 */       return Float.valueOf(first.floatValue() - second.floatValue());
/*  789 */     if (((first instanceof Long)) || ((second instanceof Long)))
/*  790 */       return Long.valueOf(first.longValue() - second.longValue());
/*  791 */     if (((first instanceof Integer)) || ((second instanceof Integer)))
/*  792 */       return Integer.valueOf(first.intValue() - second.intValue());
/*  793 */     if (((first instanceof Short)) || ((second instanceof Short)))
/*  794 */       return Integer.valueOf(first.shortValue() - second.shortValue());
/*  795 */     if (((first instanceof Byte)) || ((second instanceof Byte))) {
/*  796 */       return Integer.valueOf(first.byteValue() - second.byteValue());
/*      */     }
/*  798 */     throw new RuntimeException("Unknown number type.");
/*      */   }
/*      */ 
/*      */   static int compareNumbers(Number first, Number second)
/*      */   {
/*  803 */     if (((first instanceof Double)) || ((second instanceof Double)))
/*  804 */       return (int)Math.signum(first.doubleValue() - second.doubleValue());
/*  805 */     if (((first instanceof Float)) || ((second instanceof Float)))
/*  806 */       return (int)Math.signum(first.floatValue() - second.floatValue());
/*  807 */     if (((first instanceof Long)) || ((second instanceof Long))) {
/*  808 */       long diff = first.longValue() - second.longValue();
/*  809 */       return diff > 0L ? 1 : diff < 0L ? -1 : 0;
/*  810 */     }if (((first instanceof Integer)) || ((second instanceof Integer)))
/*  811 */       return first.intValue() - second.intValue();
/*  812 */     if (((first instanceof Short)) || ((second instanceof Short)))
/*  813 */       return first.shortValue() - second.shortValue();
/*  814 */     if (((first instanceof Byte)) || ((second instanceof Byte))) {
/*  815 */       return first.byteValue() - second.byteValue();
/*      */     }
/*  817 */     throw new RuntimeException("Unknown number type.");
/*      */   }
/*      */ 
/*      */   static String join(CharSequence delimiter, Iterable tokens)
/*      */   {
/*  826 */     StringBuilder sb = new StringBuilder();
/*  827 */     boolean firstTime = true;
/*  828 */     for (Iterator i$ = tokens.iterator(); i$.hasNext(); ) { Object item = i$.next();
/*  829 */       if (firstTime)
/*  830 */         firstTime = false;
/*      */       else {
/*  832 */         sb.append(delimiter);
/*      */       }
/*  834 */       sb.append(item);
/*      */     }
/*  836 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   static <T> T waitForTask(Task<T> task)
/*      */     throws ParseException
/*      */   {
/*      */     try
/*      */     {
/*  844 */       task.waitForCompletion();
/*  845 */       if (task.isFaulted()) {
/*  846 */         Exception error = task.getError();
/*  847 */         if ((error instanceof ParseException)) {
/*  848 */           throw ((ParseException)error);
/*      */         }
/*  850 */         if ((error instanceof AggregateException)) {
/*  851 */           throw new ParseException(error);
/*      */         }
/*  853 */         if ((error instanceof RuntimeException)) {
/*  854 */           throw ((RuntimeException)error);
/*      */         }
/*  856 */         throw new RuntimeException(error);
/*  857 */       }if (task.isCancelled()) {
/*  858 */         throw new RuntimeException(new CancellationException());
/*      */       }
/*  860 */       return task.getResult(); } catch (InterruptedException e) {
/*      */     }
/*  862 */     throw new RuntimeException(e);
/*      */   }
/*      */ 
/*      */   static ScheduledExecutorService getScheduledExecutor()
/*      */   {
/*  872 */     synchronized (SCHEDULED_EXECUTOR_LOCK) {
/*  873 */       if (scheduledExecutor == null) {
/*  874 */         scheduledExecutor = Executors.newScheduledThreadPool(1);
/*      */       }
/*      */     }
/*  877 */     return scheduledExecutor;
/*      */   }
/*      */ 
/*      */   static Task<Void> callbackOnMainThreadAsync(Task<Void> task, ParseCallback1<ParseException> callback)
/*      */   {
/*  887 */     return callbackOnMainThreadAsync(task, callback, false);
/*      */   }
/*      */ 
/*      */   static Task<Void> callbackOnMainThreadAsync(Task<Void> task, ParseCallback1<ParseException> callback, boolean reportCancellation)
/*      */   {
/*  897 */     if (callback == null) {
/*  898 */       return task;
/*      */     }
/*  900 */     return callbackOnMainThreadAsync(task, new ParseCallback2(callback)
/*      */     {
/*      */       public void done(Void aVoid, ParseException e) {
/*  903 */         this.val$callback.done(e);
/*      */       }
/*      */     }
/*      */     , reportCancellation);
/*      */   }
/*      */ 
/*      */   static <T> Task<T> callbackOnMainThreadAsync(Task<T> task, ParseCallback2<T, ParseException> callback)
/*      */   {
/*  915 */     return callbackOnMainThreadAsync(task, callback, false);
/*      */   }
/*      */ 
/*      */   static <T> Task<T> callbackOnMainThreadAsync(Task<T> task, ParseCallback2<T, ParseException> callback, boolean reportCancellation)
/*      */   {
/*  925 */     if (callback == null) {
/*  926 */       return task;
/*      */     }
/*  928 */     Task.TaskCompletionSource tcs = Task.create();
/*  929 */     task.continueWith(new Continuation(reportCancellation, tcs, callback)
/*      */     {
/*      */       public Void then(Task<T> task) throws Exception {
/*  932 */         if ((task.isCancelled()) && (!this.val$reportCancellation)) {
/*  933 */           this.val$tcs.setCancelled();
/*  934 */           return null;
/*      */         }
/*  936 */         Task.UI_THREAD_EXECUTOR.execute(new Runnable(task)
/*      */         {
/*      */           public void run() {
/*      */             try {
/*  940 */               Exception error = this.val$task.getError();
/*  941 */               if ((error != null) && (!(error instanceof ParseException))) {
/*  942 */                 error = new ParseException(error);
/*      */               }
/*  944 */               Parse.6.this.val$callback.done(this.val$task.getResult(), (ParseException)error);
/*      */             } finally {
/*  946 */               if (this.val$task.isCancelled())
/*  947 */                 Parse.6.this.val$tcs.setCancelled();
/*  948 */               else if (this.val$task.isFaulted())
/*  949 */                 Parse.6.this.val$tcs.setError(this.val$task.getError());
/*      */               else
/*  951 */                 Parse.6.this.val$tcs.setResult(this.val$task.getResult());
/*      */             }
/*      */           }
/*      */         });
/*  956 */         return null;
/*      */       }
/*      */     });
/*  959 */     return tcs.getTask();
/*      */   }
/*      */ 
/*      */   static synchronized void saveDiskObject(File file, JSONObject object)
/*      */   {
/*      */     try
/*      */     {
/*  967 */       ParseFileUtils.writeByteArrayToFile(file, object.toString().getBytes(Charset.forName("UTF-8")));
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   static synchronized JSONObject getDiskObject(File file)
/*      */   {
/*      */     try
/*      */     {
/*  982 */       String fileContent = new String(ParseFileUtils.readFileToByteArray(file), "UTF-8");
/*      */ 
/*  984 */       JSONTokener tokener = new JSONTokener(fileContent);
/*  985 */       return new JSONObject(tokener);
/*      */     } catch (IOException e) {
/*  987 */       return null; } catch (JSONException e) {
/*      */     }
/*  989 */     return null;
/*      */   }
/*      */ 
/*      */   static void registerParseCallbacks(ParseCallbacks listener)
/*      */   {
/* 1005 */     if (isInitialized()) {
/* 1006 */       throw new IllegalStateException("You must register callbacks before Parse.initialize(Context)");
/*      */     }
/*      */ 
/* 1010 */     synchronized (MUTEX_CALLBACKS) {
/* 1011 */       if (callbacks == null) {
/* 1012 */         return;
/*      */       }
/* 1014 */       callbacks.add(listener);
/*      */     }
/*      */   }
/*      */ 
/*      */   static void unregisterParseCallbacks(ParseCallbacks listener)
/*      */   {
/* 1024 */     synchronized (MUTEX_CALLBACKS) {
/* 1025 */       if (callbacks == null) {
/* 1026 */         return;
/*      */       }
/* 1028 */       callbacks.remove(listener);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void dispatchOnParseInitialized() {
/* 1033 */     ParseCallbacks[] callbacks = collectParseCallbacks();
/* 1034 */     if (callbacks != null)
/* 1035 */       for (ParseCallbacks callback : callbacks)
/* 1036 */         callback.onParseInitialized();
/*      */   }
/*      */ 
/*      */   private static ParseCallbacks[] collectParseCallbacks()
/*      */   {
/*      */     ParseCallbacks[] callbacks;
/* 1043 */     synchronized (MUTEX_CALLBACKS) {
/* 1044 */       if (callbacks == null) {
/* 1045 */         return null;
/*      */       }
/* 1047 */       callbacks = new ParseCallbacks[callbacks.size()];
/* 1048 */       if (callbacks.size() > 0) {
/* 1049 */         callbacks = (ParseCallbacks[])callbacks.toArray(callbacks);
/*      */       }
/*      */     }
/* 1052 */     return callbacks;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   static synchronized void saveDiskObject(Context context, String filename, JSONObject object)
/*      */   {
/* 1070 */     setContextIfNeeded(context);
/* 1071 */     File file = new File(getParseDir(), filename);
/* 1072 */     saveDiskObject(file, object);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   static synchronized JSONObject getDiskObject(Context context, String filename)
/*      */   {
/* 1087 */     setContextIfNeeded(context);
/* 1088 */     File file = new File(getParseDir(), filename);
/* 1089 */     return getDiskObject(file);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   static synchronized boolean deleteDiskObject(Context context, String filename)
/*      */   {
/* 1104 */     setContextIfNeeded(context);
/* 1105 */     return ParseFileUtils.deleteQuietly(new File(getParseDir(), filename));
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   80 */     DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
/*   81 */     format.setTimeZone(new SimpleTimeZone(0, "GMT"));
/*   82 */     dateFormat = format;
/*      */ 
/*  867 */     SCHEDULED_EXECUTOR_LOCK = new Object();
/*      */ 
/*  994 */     MUTEX_CALLBACKS = new Object();
/*  995 */     callbacks = new HashSet();
/*      */   }
/*      */ 
/*      */   static abstract interface ParseCallbacks
/*      */   {
/*      */     public abstract void onParseInitialized();
/*      */   }
/*      */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.Parse
 * JD-Core Version:    0.6.0
 */