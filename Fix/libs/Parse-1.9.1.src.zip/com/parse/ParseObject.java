/*      */ package com.parse;
/*      */ 
/*      */ import android.content.Context;
/*      */ import android.util.Pair;
/*      */ import bolts.Capture;
/*      */ import bolts.Continuation;
/*      */ import bolts.Task;
/*      */ import bolts.Task.TaskCompletionSource;
/*      */ import java.io.File;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.SimpleTimeZone;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import org.json.JSONArray;
/*      */ import org.json.JSONException;
/*      */ import org.json.JSONObject;
/*      */ 
/*      */ public class ParseObject
/*      */ {
/*      */   private static final String TAG = "com.parse.ParseObject";
/*   54 */   static String server = "https://api.parse.com";
/*      */   static final String API_VERSION = "2";
/*      */   private static final String AUTO_CLASS_NAME = "_Automatic";
/*      */   static final String VERSION_NAME = "1.9.1";
/*      */   private static final String KEY_TYPE = "__type";
/*      */   private static final String KEY_COMPLETE = "__complete";
/*      */   private static final String KEY_OPERATIONS = "__operations";
/*      */   private static final String KEY_OBJECT_ID = "objectId";
/*      */   private static final String KEY_CLASS_NAME = "className";
/*      */   private static final String KEY_ACL = "ACL";
/*      */   private static final String KEY_CREATED_AT = "createdAt";
/*      */   private static final String KEY_UPDATED_AT = "updatedAt";
/*   68 */   private static final Map<Class<? extends ParseObject>, String> classNames = new ConcurrentHashMap();
/*      */ 
/*   70 */   private static final Map<String, Class<? extends ParseObject>> objectTypes = new ConcurrentHashMap();
/*      */   private static final DateFormat impreciseDateFormat;
/*      */   private String objectId;
/*      */   private String localId;
/*      */   private String className;
/*   86 */   private final ParseMulticastDelegate<ParseObject> saveEvent = new ParseMulticastDelegate();
/*      */   private final Map<String, Object> serverData;
/*      */   final LinkedList<ParseOperationSet> operationSetQueue;
/*      */   private final Map<String, Object> estimatedData;
/*      */   private final Map<String, Boolean> dataAvailability;
/*   92 */   final Object mutex = new Object();
/*   93 */   final TaskQueue taskQueue = new TaskQueue();
/*      */   private final Map<Object, ParseJSONCacheItem> hashedObjects;
/*      */   boolean hasBeenFetched;
/*      */   boolean isDeleted;
/*      */   int isDeletingEventually;
/*      */   private Date updatedAt;
/*      */   private Date createdAt;
/*      */   private static final ThreadLocal<String> isCreatingPointerForObjectId;
/*      */   private static final String NEW_OFFLINE_OBJECT_ID_PLACEHOLDER = "*** Offline Object ***";
/*      */   public static final String DEFAULT_PIN = "_default";
/*      */ 
/*      */   protected ParseObject()
/*      */   {
/*  127 */     this("_Automatic");
/*      */   }
/*      */ 
/*      */   public ParseObject(String theClassName)
/*      */   {
/*  146 */     String objectIdForPointer = (String)isCreatingPointerForObjectId.get();
/*      */ 
/*  148 */     if (theClassName == null) {
/*  149 */       throw new IllegalArgumentException("You must specify a Parse class name when creating a new ParseObject.");
/*      */     }
/*      */ 
/*  152 */     if ("_Automatic".equals(theClassName)) {
/*  153 */       theClassName = getClassName(getClass());
/*      */     }
/*      */ 
/*  157 */     if ((getClass().equals(ParseObject.class)) && (objectTypes.containsKey(theClassName)) && (!((Class)objectTypes.get(theClassName)).isInstance(this)))
/*      */     {
/*  159 */       throw new IllegalArgumentException("You must create this type of ParseObject using ParseObject.create() or the proper subclass.");
/*      */     }
/*      */ 
/*  164 */     if ((!getClass().equals(ParseObject.class)) && (!getClass().equals(objectTypes.get(theClassName))))
/*      */     {
/*  166 */       throw new IllegalArgumentException("You must register this ParseObject subclass before instantiating it.");
/*      */     }
/*      */ 
/*  170 */     this.localId = null;
/*  171 */     this.serverData = new HashMap();
/*  172 */     this.operationSetQueue = new LinkedList();
/*  173 */     this.operationSetQueue.add(new ParseOperationSet());
/*  174 */     this.estimatedData = new HashMap();
/*  175 */     this.hashedObjects = new IdentityHashMap();
/*  176 */     this.dataAvailability = new HashMap();
/*      */ 
/*  179 */     this.className = theClassName;
/*  180 */     if (objectIdForPointer == null) {
/*  181 */       setDefaultValues();
/*  182 */       this.hasBeenFetched = true;
/*      */     } else {
/*  184 */       if (!objectIdForPointer.equals("*** Offline Object ***")) {
/*  185 */         this.objectId = objectIdForPointer;
/*      */       }
/*  187 */       this.hasBeenFetched = false;
/*      */     }
/*      */ 
/*  190 */     OfflineStore store = OfflineStore.getCurrent();
/*  191 */     if (store != null)
/*  192 */       store.registerNewObject(this);
/*      */   }
/*      */ 
/*      */   public static ParseObject create(String className)
/*      */   {
/*  205 */     if (objectTypes.containsKey(className)) {
/*      */       try {
/*  207 */         return (ParseObject)((Class)objectTypes.get(className)).newInstance();
/*      */       } catch (Exception e) {
/*  209 */         if ((e instanceof RuntimeException)) {
/*  210 */           throw ((RuntimeException)e);
/*      */         }
/*  212 */         throw new RuntimeException("Failed to create instance of subclass.", e);
/*      */       }
/*      */     }
/*  215 */     return new ParseObject(className);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> T create(Class<T> subclass)
/*      */   {
/*  229 */     return create(getClassName(subclass));
/*      */   }
/*      */ 
/*      */   public static ParseObject createWithoutData(String className, String objectId)
/*      */   {
/*  245 */     OfflineStore store = OfflineStore.getCurrent();
/*      */     try {
/*  247 */       if (objectId == null)
/*  248 */         isCreatingPointerForObjectId.set("*** Offline Object ***");
/*      */       else
/*  250 */         isCreatingPointerForObjectId.set(objectId);
/*      */       boolean isNew;
/*      */       ParseObject object;
/*      */       boolean isNew;
/*  254 */       if ((store != null) && (objectId != null)) {
/*  255 */         objectAndIsNew = store.getOrCreateObjectWithoutData(className, objectId);
/*      */ 
/*  257 */         ParseObject object = (ParseObject)objectAndIsNew.first;
/*  258 */         isNew = ((Boolean)objectAndIsNew.second).booleanValue();
/*      */       } else {
/*  260 */         object = create(className);
/*  261 */         isNew = true;
/*      */       }
/*      */ 
/*  264 */       if ((isNew) && (object.hasChanges())) {
/*  265 */         throw new IllegalStateException("A ParseObject subclass default constructor must not make changes to the object that cause it to be dirty.");
/*      */       }
/*      */ 
/*  271 */       Pair objectAndIsNew = object;
/*      */       return objectAndIsNew;
/*      */     }
/*      */     catch (RuntimeException e)
/*      */     {
/*  274 */       throw e;
/*      */     } catch (Exception e) {
/*  276 */       throw new RuntimeException("Failed to create instance of subclass.", e);
/*      */     } finally {
/*  278 */       isCreatingPointerForObjectId.set(null); } throw localObject;
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> T createWithoutData(Class<T> subclass, String objectId)
/*      */   {
/*  296 */     return createWithoutData(getClassName(subclass), objectId);
/*      */   }
/*      */ 
/*      */   private static boolean isAccessible(Member m) {
/*  300 */     return (Modifier.isPublic(m.getModifiers())) || ((m.getDeclaringClass().getPackage().getName().equals("com.parse")) && (!Modifier.isPrivate(m.getModifiers())) && (!Modifier.isProtected(m.getModifiers())));
/*      */   }
/*      */ 
/*      */   public static void registerSubclass(Class<? extends ParseObject> subclass)
/*      */   {
/*  314 */     String className = getClassName(subclass);
/*  315 */     if (className == null) {
/*  316 */       throw new IllegalArgumentException("No ParseClassName annoation provided on " + subclass);
/*      */     }
/*  318 */     if (subclass.getDeclaredConstructors().length > 0) {
/*      */       try {
/*  320 */         if (!isAccessible(subclass.getDeclaredConstructor(new Class[0])))
/*  321 */           throw new IllegalArgumentException("Default constructor for " + subclass + " is not accessible.");
/*      */       }
/*      */       catch (NoSuchMethodException e)
/*      */       {
/*  325 */         throw new IllegalArgumentException("No default constructor provided for " + subclass);
/*      */       }
/*      */     }
/*  328 */     Class oldValue = (Class)objectTypes.get(className);
/*  329 */     if ((oldValue != null) && (subclass.isAssignableFrom(oldValue)))
/*      */     {
/*  331 */       return;
/*      */     }
/*  333 */     objectTypes.put(className, subclass);
/*  334 */     if ((oldValue != null) && (!subclass.equals(oldValue)))
/*  335 */       if (className.equals(getClassName(ParseUser.class)))
/*  336 */         ParseUser.clearCurrentUserFromMemory();
/*  337 */       else if (className.equals(getClassName(ParseInstallation.class)))
/*  338 */         ParseInstallation.clearCurrentInstallationFromMemory();
/*      */   }
/*      */ 
/*      */   static void unregisterSubclass(String className)
/*      */   {
/*  344 */     objectTypes.remove(className);
/*      */   }
/*      */ 
/*      */   static String getApplicationId() {
/*  348 */     Parse.checkInit();
/*  349 */     return Parse.applicationId;
/*      */   }
/*      */ 
/*      */   static <T> Task<T> enqueueForAll(List<? extends ParseObject> objects, Continuation<Void, Task<T>> taskStart)
/*      */   {
/*  358 */     Task.TaskCompletionSource readyToStart = Task.create();
/*      */ 
/*  365 */     List locks = new ArrayList(objects.size());
/*  366 */     for (ParseObject obj : objects) {
/*  367 */       locks.add(obj.taskQueue.getLock());
/*      */     }
/*  369 */     LockSet lock = new LockSet(locks);
/*      */ 
/*  371 */     lock.lock();
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/*  378 */         fullTask = (Task)taskStart.then(readyToStart.getTask());
/*      */       } catch (RuntimeException e) {
/*  380 */         throw e;
/*      */       }
/*      */     }
/*      */     catch (Exception childTasks)
/*      */     {
/*      */       Task fullTask;
/*  382 */       throw new RuntimeException(e);
/*      */ 
/*  386 */       List childTasks = new ArrayList();
/*  387 */       for (ParseObject obj : objects) {
/*  388 */         obj.taskQueue.enqueue(new Continuation(childTasks, fullTask)
/*      */         {
/*      */           public Task<T> then(Task<Void> task) throws Exception {
/*  391 */             this.val$childTasks.add(task);
/*  392 */             return this.val$fullTask;
/*      */           }
/*      */         });
/*      */       }
/*      */ 
/*  398 */       Task.whenAll(childTasks).continueWith(new Continuation(readyToStart)
/*      */       {
/*      */         public Void then(Task<Void> task) throws Exception {
/*  401 */           this.val$readyToStart.setResult(null);
/*  402 */           return null;
/*      */         }
/*      */       });
/*  405 */       ??? = fullTask;
/*      */       return ???; } finally { lock.unlock(); } throw localObject;
/*      */   }
/*      */ 
/*      */   private static synchronized Date impreciseParseDate(String encoded)
/*      */   {
/*      */     try
/*      */     {
/*  414 */       return impreciseDateFormat.parse(encoded);
/*      */     }
/*      */     catch (java.text.ParseException e) {
/*  417 */       Parse.logE("com.parse.ParseObject", "could not parse date: " + encoded, e);
/*  418 */     }return null;
/*      */   }
/*      */ 
/*      */   static Task<ParseObject> migrateFromDiskToLDS(String filename, String pinName)
/*      */   {
/*  423 */     ParseObject disk = getFromDisk(Parse.applicationContext, filename);
/*  424 */     if (disk == null) {
/*  425 */       return Task.forResult(null);
/*      */     }
/*      */ 
/*  428 */     return disk.pinInBackground(pinName).continueWith(new Continuation(filename, disk)
/*      */     {
/*      */       public ParseObject then(Task<Void> task) throws Exception {
/*  431 */         if (!task.isFaulted())
/*      */         {
/*  434 */           ParseFileUtils.deleteQuietly(new File(Parse.getParseDir(), this.val$filename));
/*      */         }
/*  436 */         return this.val$disk;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   void saveToDisk(Context context, String filename)
/*      */   {
/*  450 */     if (OfflineStore.isEnabled()) {
/*  451 */       throw new IllegalStateException("ParseObject#saveToDisk is not allowed when OfflineStore is enabled");
/*      */     }
/*  453 */     synchronized (this.mutex) {
/*  454 */       JSONObject object = toJSONObjectForDataFile(false, PointerEncodingStrategy.get());
/*  455 */       Parse.saveDiskObject(context, filename, object);
/*      */     }
/*      */   }
/*      */ 
/*      */   void addToHashedObjects(Object object) {
/*  460 */     synchronized (this.mutex) {
/*      */       try {
/*  462 */         this.hashedObjects.put(object, new ParseJSONCacheItem(object));
/*      */       } catch (JSONException e) {
/*  464 */         throw new IllegalArgumentException("Couldn't serialize container value to JSON.");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static ParseObject getFromDisk(Context context, String filename)
/*      */   {
/*  480 */     JSONObject object = Parse.getDiskObject(context, filename);
/*  481 */     if (object == null) {
/*  482 */       return null;
/*      */     }
/*  484 */     return fromDiskJSON(object);
/*      */   }
/*      */ 
/*      */   static <T extends ParseObject> T fromDiskJSON(JSONObject json) {
/*  488 */     String className = json.optString("classname", null);
/*  489 */     if (className == null) {
/*  490 */       return null;
/*      */     }
/*  492 */     String objectId = json.optString("objectId", null);
/*      */ 
/*  494 */     ParseObject object = createWithoutData(className, objectId);
/*  495 */     object.mergeFromDiskJSON(json);
/*  496 */     return object;
/*      */   }
/*      */ 
/*      */   static <T extends ParseObject> T fromJSON(JSONObject json, String defaultClassName, boolean isComplete)
/*      */   {
/*  511 */     return fromJSON(json, defaultClassName, isComplete, new ParseDecoder());
/*      */   }
/*      */ 
/*      */   static <T extends ParseObject> T fromJSON(JSONObject json, String defaultClassName, boolean isComplete, ParseDecoder decoder)
/*      */   {
/*  528 */     String objectId = json.optString("objectId", null);
/*  529 */     String className = json.optString("classname", defaultClassName);
/*      */ 
/*  531 */     ParseObject object = createWithoutData(className, objectId);
/*  532 */     object.mergeAfterFetch(json, decoder, isComplete);
/*  533 */     return object;
/*      */   }
/*      */ 
/*      */   public String getClassName()
/*      */   {
/*  542 */     synchronized (this.mutex) {
/*  543 */       return this.className;
/*      */     }
/*      */   }
/*      */ 
/*      */   public Date getUpdatedAt()
/*      */   {
/*  555 */     synchronized (this.mutex) {
/*  556 */       return this.updatedAt;
/*      */     }
/*      */   }
/*      */ 
/*      */   public Date getCreatedAt()
/*      */   {
/*  568 */     synchronized (this.mutex) {
/*  569 */       return this.createdAt;
/*      */     }
/*      */   }
/*      */ 
/*      */   public Set<String> keySet()
/*      */   {
/*  580 */     synchronized (this.mutex) {
/*  581 */       return Collections.unmodifiableSet(this.estimatedData.keySet());
/*      */     }
/*      */   }
/*      */ 
/*      */   void copyChangesFrom(ParseObject other)
/*      */   {
/*      */     ParseOperationSet operations;
/*  590 */     synchronized (this.mutex) {
/*  591 */       operations = (ParseOperationSet)other.operationSetQueue.getFirst();
/*  592 */       for (String key : operations.keySet())
/*  593 */         performOperation(key, (ParseFieldOperation)operations.get(key));
/*      */     }
/*      */   }
/*      */ 
/*      */   void mergeFromObject(ParseObject other)
/*      */   {
/*  599 */     synchronized (this.mutex)
/*      */     {
/*  601 */       if (this == other) {
/*  602 */         return;
/*      */       }
/*      */ 
/*  605 */       this.objectId = other.objectId;
/*  606 */       this.createdAt = other.createdAt;
/*  607 */       this.updatedAt = other.updatedAt;
/*  608 */       this.serverData.clear();
/*  609 */       this.serverData.putAll(other.serverData);
/*      */ 
/*  612 */       if (this.operationSetQueue.size() != 1) {
/*  613 */         throw new IllegalStateException("Attempt to mergeFromObject during a save.");
/*      */       }
/*  615 */       this.operationSetQueue.clear();
/*  616 */       this.operationSetQueue.add(new ParseOperationSet());
/*      */ 
/*  618 */       rebuildEstimatedData();
/*  619 */       checkpointAllMutableContainers();
/*      */     }
/*      */   }
/*      */ 
/*      */   void revert()
/*      */   {
/*  628 */     synchronized (this.mutex) {
/*  629 */       currentOperations().clear();
/*  630 */       rebuildEstimatedData();
/*  631 */       checkpointAllMutableContainers();
/*      */     }
/*      */   }
/*      */ 
/*      */   void mergeAfterFetch(JSONObject result, ParseDecoder decoder, boolean completeData) {
/*  636 */     synchronized (this.mutex) {
/*  637 */       mergeFromServer(result, decoder, completeData);
/*  638 */       rebuildEstimatedData();
/*  639 */       checkpointAllMutableContainers();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void mergeAfterSave(JSONObject result, ParseDecoder decoder, ParseOperationSet operationsBeforeSave)
/*      */   {
/*  645 */     synchronized (this.mutex)
/*      */     {
/*  648 */       ListIterator opIterator = this.operationSetQueue.listIterator(this.operationSetQueue.indexOf(operationsBeforeSave));
/*      */ 
/*  650 */       opIterator.next();
/*  651 */       opIterator.remove();
/*  652 */       ParseOperationSet nextOperation = (ParseOperationSet)opIterator.next();
/*      */ 
/*  654 */       if (result == null)
/*      */       {
/*  656 */         nextOperation.mergeFrom(operationsBeforeSave);
/*      */       }
/*      */       else {
/*  659 */         applyOperations(operationsBeforeSave, this.serverData);
/*  660 */         mergeFromServer(result, decoder, false);
/*  661 */         rebuildEstimatedData();
/*  662 */         checkpointAllMutableContainers();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private Map<String, ParseObject> collectFetchedObjects()
/*      */   {
/*  675 */     Map fetchedObjects = new HashMap();
/*  676 */     ParseTraverser traverser = new ParseTraverser(fetchedObjects)
/*      */     {
/*      */       protected boolean visit(Object object) {
/*  679 */         if ((object instanceof ParseObject)) {
/*  680 */           ParseObject parseObj = (ParseObject)object;
/*  681 */           if ((parseObj.objectId != null) && (parseObj.isDataAvailable())) {
/*  682 */             this.val$fetchedObjects.put(parseObj.objectId, parseObj);
/*      */           }
/*      */         }
/*  685 */         return true;
/*      */       }
/*      */     };
/*  688 */     traverser.traverse(this.estimatedData);
/*  689 */     return fetchedObjects;
/*      */   }
/*      */ 
/*      */   void mergeFromDiskJSON(JSONObject object) {
/*  693 */     synchronized (this.mutex)
/*      */     {
/*      */       try
/*      */       {
/*  697 */         if ((object.has("id")) && 
/*  698 */           (this.objectId == null)) {
/*  699 */           setObjectIdInternal(object.getString("id"));
/*      */         }
/*      */ 
/*  702 */         if (object.has("created_at")) {
/*  703 */           String createdAtString = object.getString("created_at");
/*  704 */           if (createdAtString != null) {
/*  705 */             this.createdAt = impreciseParseDate(createdAtString);
/*      */           }
/*      */         }
/*  708 */         if (object.has("updated_at")) {
/*  709 */           String updatedAtString = object.getString("updated_at");
/*  710 */           if (updatedAtString != null) {
/*  711 */             this.updatedAt = impreciseParseDate(updatedAtString);
/*      */           }
/*      */         }
/*  714 */         if (object.has("pointers")) {
/*  715 */           JSONObject newPointers = object.getJSONObject("pointers");
/*  716 */           Iterator keys = newPointers.keys();
/*  717 */           while (keys.hasNext()) {
/*  718 */             String key = (String)keys.next();
/*  719 */             JSONArray pointerArray = newPointers.getJSONArray(key);
/*  720 */             this.serverData.put(key, createWithoutData(pointerArray.optString(0), pointerArray.optString(1)));
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (JSONException e) {
/*  725 */         throw new RuntimeException(e);
/*      */       }
/*  727 */       JSONObject data = object.optJSONObject("data");
/*  728 */       mergeAfterFetch(data, new ParseDecoder(), true);
/*      */     }
/*      */   }
/*      */ 
/*      */   void mergeFromServer(JSONObject object, ParseDecoder decoder, boolean completeData)
/*      */   {
/*  734 */     synchronized (this.mutex)
/*      */     {
/*  736 */       this.hasBeenFetched = ((this.hasBeenFetched) || (completeData));
/*      */       try {
/*  738 */         Iterator keys = object.keys();
/*  739 */         while (keys.hasNext()) {
/*  740 */           String key = (String)keys.next();
/*  741 */           this.dataAvailability.put(key, Boolean.valueOf(true));
/*      */ 
/*  743 */           if (key.equals("objectId")) {
/*  744 */             setObjectIdInternal(object.getString(key));
/*  745 */             continue;
/*      */           }
/*  747 */           if (key.equals("createdAt")) {
/*  748 */             this.createdAt = Parse.stringToDate(object.getString(key));
/*  749 */             continue;
/*      */           }
/*  751 */           if (key.equals("updatedAt")) {
/*  752 */             this.updatedAt = Parse.stringToDate(object.getString(key));
/*  753 */             continue;
/*      */           }
/*  755 */           if (key.equals("ACL")) {
/*  756 */             ParseACL acl = ParseACL.createACLFromJSONObject(object.getJSONObject(key), decoder);
/*  757 */             this.serverData.put("ACL", acl);
/*  758 */             addToHashedObjects(acl);
/*  759 */             continue;
/*      */           }
/*  761 */           if ((key.equals("__type")) || (key.equals("className")))
/*      */           {
/*      */             continue;
/*      */           }
/*  765 */           Object value = object.get(key);
/*  766 */           Object decodedObject = decoder.decode(value);
/*      */ 
/*  768 */           if (Parse.isContainerObject(decodedObject)) {
/*  769 */             addToHashedObjects(decodedObject);
/*      */           }
/*  771 */           this.serverData.put(key, decodedObject);
/*      */         }
/*      */ 
/*  774 */         if ((this.updatedAt == null) && (this.createdAt != null))
/*  775 */           this.updatedAt = this.createdAt;
/*      */       }
/*      */       catch (JSONException e)
/*      */       {
/*  779 */         throw new RuntimeException(e);
/*      */       }
/*  781 */       rebuildEstimatedData();
/*  782 */       checkpointAllMutableContainers();
/*      */     }
/*      */   }
/*      */ 
/*      */   JSONObject toRest(ParseObjectEncodingStrategy objectEncoder)
/*      */   {
/*  791 */     synchronized (this.mutex) {
/*  792 */       checkForChangesToMutableContainers();
/*      */ 
/*  795 */       JSONObject json = new JSONObject();
/*      */       try
/*      */       {
/*  798 */         json.put("className", this.className);
/*      */ 
/*  801 */         for (String key : this.serverData.keySet()) {
/*  802 */           Object value = this.serverData.get(key);
/*  803 */           json.put(key, Parse.encode(value, objectEncoder));
/*      */         }
/*      */ 
/*  806 */         if (this.objectId != null) {
/*  807 */           json.put("objectId", this.objectId);
/*      */         }
/*  809 */         if (this.createdAt != null) {
/*  810 */           json.put("createdAt", Parse.dateToString(this.createdAt));
/*      */         }
/*  812 */         if (this.updatedAt != null) {
/*  813 */           json.put("updatedAt", Parse.dateToString(this.updatedAt));
/*      */         }
/*      */ 
/*  816 */         json.put("isDeletingEventually", this.isDeletingEventually);
/*      */ 
/*  823 */         JSONArray operations = new JSONArray();
/*  824 */         for (ParseOperationSet operationSet : this.operationSetQueue) {
/*  825 */           operations.put(operationSet.toRest(objectEncoder));
/*      */         }
/*  827 */         json.put("__operations", operations);
/*      */ 
/*  829 */         json.put("__complete", this.hasBeenFetched);
/*      */       }
/*      */       catch (JSONException e) {
/*  832 */         throw new RuntimeException("could not serialize object to JSON");
/*      */       }
/*      */ 
/*  835 */       return json;
/*      */     }
/*      */   }
/*      */ 
/*      */   void mergeREST(JSONObject object, ParseDecoder decoder) {
/*  840 */     ArrayList saveEventuallyOperationSets = new ArrayList();
/*      */ 
/*  842 */     synchronized (this.mutex) {
/*      */       try {
/*  844 */         Iterator keys = object.keys();
/*  845 */         while (keys.hasNext()) {
/*  846 */           String key = (String)keys.next();
/*  847 */           this.dataAvailability.put(key, Boolean.valueOf(true));
/*      */ 
/*  849 */           if ((key.equals("__type")) || (key.equals("className"))) {
/*      */             continue;
/*      */           }
/*  852 */           if (key.equals("objectId")) {
/*  853 */             setObjectIdInternal(object.getString(key));
/*  854 */             continue;
/*      */           }
/*  856 */           if (key.equals("createdAt")) {
/*  857 */             this.createdAt = Parse.stringToDate(object.getString(key));
/*  858 */             continue;
/*      */           }
/*  860 */           if (key.equals("updatedAt")) {
/*  861 */             this.updatedAt = Parse.stringToDate(object.getString(key));
/*  862 */             continue;
/*      */           }
/*  864 */           if (key.equals("isDeletingEventually")) {
/*  865 */             this.isDeletingEventually = object.getInt(key);
/*  866 */             continue;
/*      */           }
/*  868 */           if (key.equals("ACL")) {
/*  869 */             ParseACL acl = ParseACL.createACLFromJSONObject(object.getJSONObject(key), decoder);
/*  870 */             this.serverData.put("ACL", acl);
/*  871 */             addToHashedObjects(acl);
/*  872 */             continue;
/*      */           }
/*  874 */           if (key.equals("__complete"))
/*      */           {
/*  876 */             this.hasBeenFetched = ((this.hasBeenFetched) || (object.getBoolean(key)));
/*  877 */             continue;
/*      */           }
/*  879 */           if (key.equals("__operations")) {
/*  880 */             ParseOperationSet newerOperations = currentOperations();
/*      */ 
/*  882 */             JSONArray operations = object.getJSONArray("__operations");
/*  883 */             if (operations != null) {
/*  884 */               this.operationSetQueue.clear();
/*      */ 
/*  889 */               ParseOperationSet current = null;
/*  890 */               for (int i = 0; i < operations.length(); i++) {
/*  891 */                 JSONObject operationSetJSON = operations.getJSONObject(i);
/*  892 */                 ParseOperationSet operationSet = ParseOperationSet.fromRest(operationSetJSON, decoder);
/*      */ 
/*  894 */                 if (operationSet.isSaveEventually()) {
/*  895 */                   if (current != null) {
/*  896 */                     this.operationSetQueue.add(current);
/*  897 */                     current = null;
/*      */                   }
/*  899 */                   saveEventuallyOperationSets.add(operationSet);
/*  900 */                   this.operationSetQueue.add(operationSet);
/*      */                 }
/*      */                 else
/*      */                 {
/*  904 */                   if (current != null) {
/*  905 */                     operationSet.mergeFrom(current);
/*      */                   }
/*  907 */                   current = operationSet;
/*      */                 }
/*      */               }
/*  909 */               if (current != null) {
/*  910 */                 this.operationSetQueue.add(current);
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*  915 */             currentOperations().mergeFrom(newerOperations);
/*      */ 
/*  917 */             continue;
/*      */           }
/*      */ 
/*  920 */           Object value = object.get(key);
/*  921 */           Object decodedObject = decoder.decode(value);
/*      */ 
/*  923 */           if (Parse.isContainerObject(decodedObject)) {
/*  924 */             addToHashedObjects(decodedObject);
/*      */           }
/*  926 */           this.serverData.put(key, decodedObject);
/*      */         }
/*      */ 
/*  929 */         if ((this.updatedAt == null) && (this.createdAt != null))
/*  930 */           this.updatedAt = this.createdAt;
/*      */       }
/*      */       catch (JSONException e) {
/*  933 */         throw new RuntimeException(e);
/*      */       }
/*  935 */       rebuildEstimatedData();
/*  936 */       checkpointAllMutableContainers();
/*      */     }
/*      */ 
/*  940 */     for (ParseOperationSet operationSet : saveEventuallyOperationSets)
/*  941 */       enqueueSaveEventuallyOperationAsync(operationSet);
/*      */   }
/*      */ 
/*      */   private boolean hasDirtyChildren()
/*      */   {
/*  946 */     synchronized (this.mutex)
/*      */     {
/*  950 */       List unsavedChildren = new ArrayList();
/*  951 */       collectDirtyChildren(this.estimatedData, unsavedChildren, null);
/*  952 */       return unsavedChildren.size() > 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isDirty()
/*      */   {
/*  963 */     return isDirty(true);
/*      */   }
/*      */ 
/*      */   boolean isDirty(boolean considerChildren) {
/*  967 */     synchronized (this.mutex) {
/*  968 */       checkForChangesToMutableContainers();
/*  969 */       return (this.isDeleted) || (getObjectId() == null) || (hasChanges()) || ((considerChildren) && (hasDirtyChildren()));
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean hasChanges() {
/*  974 */     synchronized (this.mutex) {
/*  975 */       return currentOperations().size() > 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean hasOutstandingOperations()
/*      */   {
/*  984 */     synchronized (this.mutex)
/*      */     {
/*  986 */       return this.operationSetQueue.size() > 1;
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isDirty(String key)
/*      */   {
/*  998 */     synchronized (this.mutex) {
/*  999 */       return currentOperations().containsKey(key);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkpointAllMutableContainers()
/*      */   {
/*      */     Iterator i$;
/* 1007 */     synchronized (this.mutex) {
/* 1008 */       for (i$ = this.estimatedData.values().iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 1009 */         checkpointMutableContainer(o);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkpointMutableContainer(Object object)
/*      */   {
/* 1018 */     synchronized (this.mutex) {
/* 1019 */       if (Parse.isContainerObject(object)) {
/*      */         ParseJSONCacheItem newCacheItem;
/*      */         try { newCacheItem = new ParseJSONCacheItem(object);
/*      */         } catch (JSONException e) {
/* 1024 */           throw new RuntimeException(e);
/*      */         }
/* 1026 */         this.hashedObjects.put(object, newCacheItem);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkForChangesToMutableContainer(String key, Object object)
/*      */   {
/* 1036 */     synchronized (this.mutex) {
/* 1037 */       if (Parse.isContainerObject(object)) {
/* 1038 */         ParseJSONCacheItem oldCacheItem = (ParseJSONCacheItem)this.hashedObjects.get(object);
/* 1039 */         if (oldCacheItem == null)
/* 1040 */           throw new IllegalArgumentException("ParseObject contains container item that isn't cached.");
/*      */         ParseJSONCacheItem newCacheItem;
/*      */         try
/*      */         {
/* 1045 */           newCacheItem = new ParseJSONCacheItem(object);
/*      */         } catch (JSONException e) {
/* 1047 */           throw new RuntimeException(e);
/*      */         }
/* 1049 */         if (!oldCacheItem.equals(newCacheItem))
/*      */         {
/* 1051 */           performOperation(key, new ParseSetOperation(object));
/*      */         }
/*      */       }
/*      */       else {
/* 1055 */         this.hashedObjects.remove(object);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void checkForChangesToMutableContainers()
/*      */   {
/* 1065 */     synchronized (this.mutex) {
/* 1066 */       for (String key : this.estimatedData.keySet()) {
/* 1067 */         checkForChangesToMutableContainer(key, this.estimatedData.get(key));
/*      */       }
/* 1069 */       this.hashedObjects.keySet().retainAll(this.estimatedData.values());
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getObjectId()
/*      */   {
/* 1081 */     synchronized (this.mutex) {
/* 1082 */       return this.objectId;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setObjectId(String newObjectId)
/*      */   {
/* 1092 */     synchronized (this.mutex) {
/* 1093 */       setObjectIdInternal(newObjectId);
/*      */     }
/*      */   }
/*      */ 
/*      */   String getOrCreateLocalId()
/*      */   {
/* 1102 */     synchronized (this.mutex) {
/* 1103 */       if (this.localId == null) {
/* 1104 */         if (this.objectId != null) {
/* 1105 */           throw new IllegalStateException("Attempted to get a localId for an object with an objectId.");
/*      */         }
/*      */ 
/* 1108 */         this.localId = LocalIdManager.getDefaultInstance().createLocalId();
/*      */       }
/* 1110 */       return this.localId;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setObjectIdInternal(String newObjectId)
/*      */   {
/* 1116 */     synchronized (this.mutex) {
/* 1117 */       String oldObjectId = this.objectId;
/*      */ 
/* 1120 */       OfflineStore store = OfflineStore.getCurrent();
/* 1121 */       if (store != null) {
/* 1122 */         store.updateObjectId(this, oldObjectId, newObjectId);
/*      */       }
/*      */ 
/* 1125 */       this.objectId = newObjectId;
/* 1126 */       if (this.localId != null) {
/* 1127 */         LocalIdManager.getDefaultInstance().setObjectId(this.localId, this.objectId);
/* 1128 */         this.localId = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   ParseRESTObjectCommand currentSaveCommand(ParseOperationSet operations, ParseObjectEncodingStrategy objectEncoder, String sessionToken) throws ParseException
/*      */   {
/* 1135 */     synchronized (this.mutex)
/*      */     {
/* 1140 */       JSONObject objectJSON = toJSONObjectForSaving(operations, objectEncoder);
/*      */       ParseRESTObjectCommand command;
/*      */       ParseRESTObjectCommand command;
/* 1144 */       if (this.objectId == null)
/* 1145 */         command = ParseRESTObjectCommand.createObjectCommand(this.className, objectJSON, sessionToken);
/*      */       else {
/* 1147 */         command = ParseRESTObjectCommand.updateObjectCommand(this.objectId, this.className, objectJSON, sessionToken);
/*      */       }
/*      */ 
/* 1150 */       command.enableRetrying();
/* 1151 */       return command;
/*      */     }
/*      */   }
/*      */ 
/*      */   JSONObject toJSONObjectForDataFile(boolean includeOperations, ParseObjectEncodingStrategy objectEncoder)
/*      */   {
/* 1172 */     synchronized (this.mutex) {
/* 1173 */       checkForChangesToMutableContainers();
/*      */ 
/* 1176 */       JSONObject objectJSON = new JSONObject();
/* 1177 */       JSONObject dataJSON = new JSONObject();
/*      */       try
/*      */       {
/* 1181 */         for (String key : this.serverData.keySet()) {
/* 1182 */           Object object = this.serverData.get(key);
/*      */ 
/* 1185 */           if ((Parse.isContainerObject(object)) && (this.hashedObjects.containsKey(object)))
/* 1186 */             dataJSON.put(key, ((ParseJSONCacheItem)this.hashedObjects.get(object)).getJSONObject());
/*      */           else {
/* 1188 */             dataJSON.put(key, Parse.encode(object, objectEncoder));
/*      */           }
/*      */         }
/*      */ 
/* 1192 */         if (this.createdAt != null) {
/* 1193 */           dataJSON.put("createdAt", Parse.dateToString(this.createdAt));
/*      */         }
/* 1195 */         if (this.updatedAt != null) {
/* 1196 */           dataJSON.put("updatedAt", Parse.dateToString(this.updatedAt));
/*      */         }
/* 1198 */         if (this.objectId != null) {
/* 1199 */           dataJSON.put("objectId", this.objectId);
/*      */         }
/*      */ 
/* 1202 */         objectJSON.put("data", dataJSON);
/* 1203 */         objectJSON.put("classname", this.className);
/*      */ 
/* 1205 */         if (includeOperations) {
/* 1206 */           JSONArray operations = new JSONArray();
/* 1207 */           for (ParseOperationSet operationSet : this.operationSetQueue) {
/* 1208 */             JSONObject operationSetJSON = new JSONObject();
/* 1209 */             for (String key : operationSet.keySet()) {
/* 1210 */               ParseFieldOperation op = (ParseFieldOperation)operationSet.get(key);
/* 1211 */               operationSetJSON.put(key, op.encode(objectEncoder));
/*      */             }
/* 1213 */             operations.put(operationSetJSON);
/*      */           }
/* 1215 */           objectJSON.put("operations", operations);
/*      */         }
/*      */       } catch (JSONException e) {
/* 1218 */         throw new RuntimeException("could not serialize object to JSON");
/*      */       }
/*      */ 
/* 1221 */       return objectJSON;
/*      */     }
/*      */   }
/*      */ 
/*      */   JSONObject toJSONObjectForSaving(ParseOperationSet operations, ParseObjectEncodingStrategy objectEncoder)
/*      */   {
/* 1239 */     synchronized (this.mutex)
/*      */     {
/* 1241 */       JSONObject objectJSON = new JSONObject();
/*      */       try
/*      */       {
/* 1245 */         for (String key : operations.keySet()) {
/* 1246 */           ParseFieldOperation operation = (ParseFieldOperation)operations.get(key);
/*      */ 
/* 1248 */           Object encoded = Parse.encode(operation, objectEncoder);
/* 1249 */           objectJSON.put(key, encoded);
/*      */ 
/* 1251 */           if ((operation instanceof ParseSetOperation)) {
/* 1252 */             Object object = ((ParseSetOperation)operation).getValue();
/* 1253 */             if ((Parse.isContainerObject(object)) && (this.hashedObjects.containsKey(object)))
/*      */             {
/* 1255 */               this.hashedObjects.put(object, new ParseJSONCacheItem(object));
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1261 */         if (this.objectId != null)
/* 1262 */           objectJSON.put("objectId", this.objectId);
/*      */       }
/*      */       catch (JSONException e) {
/* 1265 */         throw new RuntimeException("could not serialize object to JSON");
/*      */       }
/*      */ 
/* 1268 */       return objectJSON;
/*      */     }
/*      */   }
/*      */ 
/*      */   Task<Void> handleSaveResultAsync(JSONObject result, ParseOperationSet operationsBeforeSave)
/*      */   {
/* 1274 */     Task task = Task.forResult((Void)null);
/*      */ 
/* 1276 */     Map fetchedObjects = collectFetchedObjects();
/*      */ 
/* 1282 */     OfflineStore store = OfflineStore.getCurrent();
/* 1283 */     if (store != null) {
/* 1284 */       task = task.onSuccessTask(new Continuation(store)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task) throws Exception {
/* 1287 */           return this.val$store.fetchLocallyAsync(ParseObject.this).makeVoid();
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/* 1293 */     task = task.continueWith(new Object(fetchedObjects, result, operationsBeforeSave)
/*      */     {
/*      */       public Void then(Task<Void> task) throws Exception {
/* 1296 */         synchronized (ParseObject.this.mutex) {
/* 1297 */           ParseDecoder decoder = new KnownParseObjectDecoder(this.val$fetchedObjects);
/* 1298 */           ParseObject.this.mergeAfterSave(this.val$result, decoder, this.val$operationsBeforeSave);
/*      */         }
/* 1300 */         return null;
/*      */       }
/*      */     });
/* 1304 */     if (store != null) {
/* 1305 */       task = task.onSuccessTask(new Continuation(store)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task) throws Exception {
/* 1308 */           return this.val$store.updateDataForObjectAsync(ParseObject.this);
/*      */         }
/*      */       });
/*      */     }
/* 1313 */     task = task.onSuccess(new Continuation()
/*      */     {
/*      */       public Void then(Task<Void> task) throws Exception {
/* 1316 */         ParseObject.this.saveEvent.invoke(ParseObject.this, null);
/* 1317 */         return null;
/*      */       }
/*      */     });
/* 1321 */     return task;
/*      */   }
/*      */ 
/*      */   ParseOperationSet startSave() {
/* 1325 */     synchronized (this.mutex) {
/* 1326 */       ParseOperationSet currentOperations = currentOperations();
/* 1327 */       this.operationSetQueue.addLast(new ParseOperationSet());
/* 1328 */       return currentOperations;
/*      */     }
/*      */   }
/*      */ 
/*      */   void validateSave()
/*      */   {
/*      */   }
/*      */ 
/*      */   public final void save()
/*      */     throws ParseException
/*      */   {
/* 1344 */     Parse.waitForTask(saveInBackground());
/*      */   }
/*      */ 
/*      */   public final Task<Void> saveInBackground()
/*      */   {
/* 1354 */     return this.taskQueue.enqueue(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 1357 */         ParseObject.this.updateBeforeSave();
/* 1358 */         return ParseObject.this.saveAsync(toAwait);
/*      */       } } );
/*      */   }
/*      */ 
/*      */   Task<Void> saveAsync(Task<Void> toAwait) {
/* 1364 */     if (!isDirty()) {
/* 1365 */       return Task.forResult(null);
/*      */     }
/*      */ 
/* 1368 */     Capture operations = new Capture();
/* 1369 */     String sessionToken = ParseUser.getCurrentSessionToken();
/*      */ 
/* 1371 */     return Task.forResult(null).onSuccessTask(new Object(operations)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 1374 */         synchronized (ParseObject.this.mutex) {
/* 1375 */           ParseObject.this.validateSave();
/* 1376 */           this.val$operations.set(ParseObject.this.startSave());
/* 1377 */           if ((ParseObject.this.isDataAvailable("ACL")) && (ParseObject.this.getACL(false) != null) && (ParseObject.this.getACL(false).hasUnresolvedUser()))
/*      */           {
/* 1379 */             return ParseUser.getCurrentUser().saveInBackground().onSuccess(new Continuation()
/*      */             {
/*      */               public Void then(Task<Void> task) throws Exception {
/* 1382 */                 if (ParseObject.this.getACL(false).hasUnresolvedUser()) {
/* 1383 */                   throw new IllegalStateException("ACL has an unresolved ParseUser. Save or sign up before attempting to serialize the ACL.");
/*      */                 }
/*      */ 
/* 1386 */                 return null;
/*      */               } } );
/*      */           }
/* 1390 */           return task;
/*      */         }
/*      */       }
/*      */     }).onSuccessTask(new Object(sessionToken)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1396 */         synchronized (ParseObject.this.mutex)
/*      */         {
/* 1403 */           return ParseObject.access$400(ParseObject.this.estimatedData, this.val$sessionToken);
/*      */         }
/*      */       }
/*      */     }).onSuccessTask(TaskQueue.waitFor(toAwait)).onSuccessTask(new Continuation(operations, sessionToken)
/*      */     {
/*      */       public Task<Object> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1411 */         return ParseObject.this.saveAsync((ParseOperationSet)this.val$operations.get(), this.val$sessionToken);
/*      */       }
/*      */     }).continueWithTask(new Continuation(operations)
/*      */     {
/*      */       public Task<Void> then(Task<Object> saveTask)
/*      */         throws Exception
/*      */       {
/* 1416 */         JSONObject json = (JSONObject)saveTask.getResult();
/* 1417 */         return ParseObject.this.handleSaveResultAsync(json, (ParseOperationSet)this.val$operations.get()).continueWithTask(new Continuation(saveTask)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task) throws Exception {
/* 1420 */             return this.val$saveTask.makeVoid();
/*      */           } } );
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   Task<Object> saveAsync(ParseOperationSet operationSet, String sessionToken) throws ParseException {
/* 1429 */     ParseRESTCommand command = currentSaveCommand(operationSet, PointerEncodingStrategy.get(), sessionToken);
/*      */ 
/* 1431 */     return command.executeAsync();
/*      */   }
/*      */ 
/*      */   public final void saveInBackground(SaveCallback callback)
/*      */   {
/* 1442 */     Parse.callbackOnMainThreadAsync(saveInBackground(), callback);
/*      */   }
/*      */ 
/*      */   public final void saveEventually(SaveCallback callback)
/*      */   {
/* 1462 */     Parse.callbackOnMainThreadAsync(saveEventually(), callback);
/*      */   }
/*      */ 
/*      */   public final Task<Void> saveEventually()
/*      */   {
/* 1481 */     if (!isDirty()) {
/* 1482 */       Parse.getEventuallyQueue().fakeObjectUpdate();
/* 1483 */       return Task.forResult(null);
/*      */     }
/*      */     ParseOperationSet operationSet;
/*      */     ParseRESTCommand command;
/* 1490 */     synchronized (this.mutex) {
/* 1491 */       updateBeforeSave();
/*      */ 
/* 1498 */       List unsavedChildren = new ArrayList();
/* 1499 */       collectDirtyChildren(this.estimatedData, unsavedChildren, null);
/*      */ 
/* 1501 */       String localId = null;
/* 1502 */       if (getObjectId() == null) {
/* 1503 */         localId = getOrCreateLocalId();
/*      */       }
/*      */ 
/* 1506 */       operationSet = startSave();
/* 1507 */       operationSet.setIsSaveEventually(true);
/*      */ 
/* 1509 */       String sessionToken = ParseUser.getCurrentSessionToken();
/*      */       try {
/* 1511 */         command = currentSaveCommand(operationSet, PointerOrLocalIdEncodingStrategy.get(), sessionToken);
/*      */ 
/* 1515 */         command.setLocalId(localId);
/*      */ 
/* 1518 */         command.setOperationSetUUID(operationSet.getUUID());
/*      */ 
/* 1521 */         command.retainLocalIds();
/*      */ 
/* 1523 */         for (ParseObject object : unsavedChildren)
/* 1524 */           object.saveEventually();
/*      */       }
/*      */       catch (ParseException exception) {
/* 1527 */         throw new IllegalStateException("Unable to saveEventually.", exception);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1532 */     ParseEventuallyQueue cache = Parse.getEventuallyQueue();
/* 1533 */     Task runEventuallyTask = cache.enqueueEventuallyAsync(command, this);
/* 1534 */     enqueueSaveEventuallyOperationAsync(operationSet);
/*      */ 
/* 1537 */     command.releaseLocalIds();
/*      */     Task handleSaveResultTask;
/*      */     Task handleSaveResultTask;
/* 1540 */     if (OfflineStore.isEnabled())
/*      */     {
/* 1542 */       handleSaveResultTask = runEventuallyTask.makeVoid();
/*      */     }
/* 1544 */     else handleSaveResultTask = runEventuallyTask.onSuccessTask(new Continuation(operationSet)
/*      */       {
/*      */         public Task<Void> then(Task<Object> task) throws Exception {
/* 1547 */           JSONObject json = (JSONObject)task.getResult();
/* 1548 */           return ParseObject.this.handleSaveEventuallyResultAsync(json, this.val$operationSet);
/*      */         }
/*      */       });
/* 1552 */     return handleSaveResultTask;
/*      */   }
/*      */ 
/*      */   private Task<Void> enqueueSaveEventuallyOperationAsync(ParseOperationSet operationSet)
/*      */   {
/* 1559 */     if (!operationSet.isSaveEventually()) {
/* 1560 */       throw new IllegalStateException("This should only be used to enqueue saveEventually operation sets");
/*      */     }
/*      */ 
/* 1564 */     return this.taskQueue.enqueue(new Continuation(operationSet)
/*      */     {
/*      */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 1567 */         return toAwait.continueWithTask(new Continuation()
/*      */         {
/*      */           public Task<Void> then(Task<Void> task) throws Exception {
/* 1570 */             ParseEventuallyQueue cache = Parse.getEventuallyQueue();
/* 1571 */             return cache.waitForOperationSetAndEventuallyPin(ParseObject.16.this.val$operationSet, null).makeVoid();
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   Task<Void> handleSaveEventuallyResultAsync(JSONObject json, ParseOperationSet operationSet)
/*      */   {
/* 1584 */     Task handleSaveResultTask = handleSaveResultAsync(json, operationSet);
/*      */ 
/* 1586 */     return handleSaveResultTask.onSuccessTask(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 1589 */         Parse.getEventuallyQueue().notifyTestHelper(5);
/*      */ 
/* 1591 */         return task;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   void updateBeforeSave()
/*      */   {
/*      */   }
/*      */ 
/*      */   public final void deleteEventually(DeleteCallback callback)
/*      */   {
/* 1622 */     Parse.callbackOnMainThreadAsync(deleteEventually(), callback);
/*      */   }
/*      */ 
/*      */   public final Task<Void> deleteEventually()
/*      */   {
/*      */     Task runEventuallyTask;
/* 1643 */     synchronized (this.mutex) {
/* 1644 */       validateDelete();
/* 1645 */       this.isDeletingEventually += 1;
/*      */ 
/* 1647 */       String localId = null;
/* 1648 */       if (getObjectId() == null) {
/* 1649 */         localId = getOrCreateLocalId();
/*      */       }
/*      */ 
/* 1653 */       OfflineStore store = OfflineStore.getCurrent();
/*      */       Task updateDataTask;
/*      */       Task updateDataTask;
/* 1654 */       if (store != null)
/* 1655 */         updateDataTask = store.updateDataForObjectAsync(this);
/*      */       else {
/* 1657 */         updateDataTask = Task.forResult(null);
/*      */       }
/*      */ 
/* 1661 */       String sessionToken = ParseUser.getCurrentSessionToken();
/*      */ 
/* 1663 */       ParseRESTCommand command = currentDeleteCommand(sessionToken);
/* 1664 */       command.setLocalId(localId);
/*      */ 
/* 1666 */       runEventuallyTask = updateDataTask.continueWithTask(new Continuation(command)
/*      */       {
/*      */         public Task<Object> then(Task<Void> task) throws Exception {
/* 1669 */           ParseEventuallyQueue cache = Parse.getEventuallyQueue();
/* 1670 */           return cache.enqueueEventuallyAsync(this.val$command, ParseObject.this);
/*      */         }
/*      */       });
/*      */     }
/*      */     Task handleDeleteResultTask;
/*      */     Task handleDeleteResultTask;
/* 1677 */     if (OfflineStore.isEnabled())
/*      */     {
/* 1679 */       handleDeleteResultTask = runEventuallyTask.makeVoid();
/*      */     }
/* 1681 */     else handleDeleteResultTask = runEventuallyTask.onSuccessTask(new Continuation()
/*      */       {
/*      */         public Task<Void> then(Task<Object> task) throws Exception {
/* 1684 */           return ParseObject.this.handleDeleteEventuallyResultAsync(task.getResult());
/*      */         }
/*      */       });
/*      */ 
/* 1689 */     return handleDeleteResultTask;
/*      */   }
/*      */ 
/*      */   Task<Void> handleDeleteEventuallyResultAsync(Object result) {
/* 1693 */     synchronized (this.mutex) {
/* 1694 */       this.isDeletingEventually -= 1;
/*      */     }
/* 1696 */     Task handleDeleteResultTask = handleDeleteResultAsync(result);
/*      */ 
/* 1698 */     return handleDeleteResultTask.onSuccessTask(new Continuation(result)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 1701 */         boolean success = this.val$result != null;
/* 1702 */         if (success) {
/* 1703 */           Parse.getEventuallyQueue().notifyTestHelper(6);
/*      */         }
/*      */ 
/* 1706 */         return task;
/*      */       } } );
/*      */   }
/*      */ 
/*      */   Task<Void> handleFetchResultAsync(JSONObject result) {
/* 1712 */     Task task = Task.forResult((Void)null);
/*      */ 
/* 1714 */     Map fetchedObjects = collectFetchedObjects();
/*      */ 
/* 1720 */     OfflineStore store = OfflineStore.getCurrent();
/* 1721 */     if (store != null) {
/* 1722 */       task = task.onSuccessTask(new Continuation(store)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task) throws Exception {
/* 1725 */           return this.val$store.fetchLocallyAsync(ParseObject.this).makeVoid();
/*      */         }
/*      */       }).continueWithTask(new Continuation()
/*      */       {
/*      */         public Task<Void> then(Task<Void> task)
/*      */           throws Exception
/*      */         {
/* 1731 */           if (((task.getError() instanceof ParseException)) && (((ParseException)task.getError()).getCode() == 120))
/*      */           {
/* 1733 */             return null;
/*      */           }
/* 1735 */           return task;
/*      */         }
/*      */       });
/*      */     }
/* 1740 */     task = task.onSuccessTask(new Object(fetchedObjects, result)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 1743 */         synchronized (ParseObject.this.mutex) {
/* 1744 */           ParseObject.this.serverData.clear();
/* 1745 */           ParseObject.this.dataAvailability.clear();
/* 1746 */           ParseDecoder decoder = new KnownParseObjectDecoder(this.val$fetchedObjects);
/* 1747 */           ParseObject.this.mergeAfterFetch(this.val$result, decoder, true);
/*      */         }
/* 1749 */         return null;
/*      */       }
/*      */     });
/* 1753 */     if (store != null) {
/* 1754 */       task = task.onSuccessTask(new Continuation(store)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task) throws Exception {
/* 1757 */           return this.val$store.updateDataForObjectAsync(ParseObject.this);
/*      */         }
/*      */       }).continueWithTask(new Continuation()
/*      */       {
/*      */         public Task<Void> then(Task<Void> task)
/*      */           throws Exception
/*      */         {
/* 1763 */           if (((task.getError() instanceof ParseException)) && (((ParseException)task.getError()).getCode() == 120))
/*      */           {
/* 1765 */             return null;
/*      */           }
/* 1767 */           return task;
/*      */         }
/*      */       });
/*      */     }
/* 1772 */     return task;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public final void refresh()
/*      */     throws ParseException
/*      */   {
/* 1786 */     fetch();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public final void refreshInBackground(RefreshCallback callback)
/*      */   {
/* 1800 */     Parse.callbackOnMainThreadAsync(fetchInBackground(), callback);
/*      */   }
/*      */ 
/*      */   public <T extends ParseObject> T fetch()
/*      */     throws ParseException
/*      */   {
/* 1812 */     return (ParseObject)Parse.waitForTask(fetchInBackground());
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> Task<T> fetchAsync(Task<Void> toAwait)
/*      */   {
/* 1817 */     String sessionToken = ParseUser.getCurrentSessionToken();
/*      */ 
/* 1819 */     return Task.call(new Object(sessionToken)
/*      */     {
/*      */       public ParseRESTCommand call() throws Exception {
/* 1822 */         synchronized (ParseObject.this.mutex) {
/* 1823 */           ParseRESTCommand command = ParseRESTObjectCommand.getObjectCommand(ParseObject.this.objectId, ParseObject.this.className, this.val$sessionToken);
/*      */ 
/* 1825 */           command.enableRetrying();
/* 1826 */           return command;
/*      */         }
/*      */       }
/*      */     }).onSuccessTask(TaskQueue.waitFor(toAwait)).onSuccessTask(new Continuation()
/*      */     {
/*      */       public Task<JSONObject> then(Task<ParseRESTCommand> task)
/*      */         throws Exception
/*      */       {
/* 1834 */         return ((ParseRESTCommand)task.getResult()).executeAsync().cast();
/*      */       }
/*      */     }).onSuccessTask(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<JSONObject> task)
/*      */         throws Exception
/*      */       {
/* 1839 */         JSONObject result = (JSONObject)task.getResult();
/* 1840 */         return ParseObject.this.handleFetchResultAsync(result);
/*      */       }
/*      */     }).onSuccess(new Continuation()
/*      */     {
/*      */       public T then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1845 */         return ParseObject.this;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public final <T extends ParseObject> Task<T> fetchInBackground()
/*      */   {
/* 1857 */     return this.taskQueue.enqueue(new Continuation()
/*      */     {
/*      */       public Task<T> then(Task<Void> task) throws Exception {
/* 1860 */         return ParseObject.this.fetchAsync(task);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public final <T extends ParseObject> void fetchInBackground(GetCallback<T> callback)
/*      */   {
/* 1873 */     Parse.callbackOnMainThreadAsync(fetchInBackground(), callback);
/*      */   }
/*      */ 
/*      */   public final <T extends ParseObject> Task<T> fetchIfNeededInBackground()
/*      */   {
/* 1884 */     synchronized (this.mutex) {
/* 1885 */       if (isDataAvailable()) {
/* 1886 */         return Task.forResult(this);
/*      */       }
/* 1888 */       return fetchInBackground();
/*      */     }
/*      */   }
/*      */ 
/*      */   public <T extends ParseObject> T fetchIfNeeded()
/*      */     throws ParseException
/*      */   {
/* 1901 */     return (ParseObject)Parse.waitForTask(fetchIfNeededInBackground());
/*      */   }
/*      */ 
/*      */   public final <T extends ParseObject> void fetchIfNeededInBackground(GetCallback<T> callback)
/*      */   {
/* 1913 */     Parse.callbackOnMainThreadAsync(fetchIfNeededInBackground(), callback);
/*      */   }
/*      */ 
/*      */   private ParseRESTObjectCommand currentDeleteCommand(String sessionToken) {
/* 1917 */     synchronized (this.mutex) {
/* 1918 */       ParseRESTObjectCommand command = ParseRESTObjectCommand.deleteObjectCommand(this.objectId, this.className, sessionToken);
/*      */ 
/* 1920 */       command.enableRetrying();
/* 1921 */       return command;
/*      */     }
/*      */   }
/*      */ 
/*      */   void validateDelete()
/*      */   {
/*      */   }
/*      */ 
/*      */   private Task<Void> deleteAsync(Task<Void> toAwait)
/*      */   {
/* 1931 */     String sessionToken = ParseUser.getCurrentSessionToken();
/* 1932 */     return Task.forResult(null).onSuccessTask(new Object()
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 1935 */         synchronized (ParseObject.this.mutex) {
/* 1936 */           ParseObject.this.validateDelete();
/* 1937 */           if (ParseObject.this.objectId == null) {
/* 1938 */             return null;
/*      */           }
/* 1940 */           return task;
/*      */         }
/*      */       }
/*      */     }).onSuccessTask(TaskQueue.waitFor(toAwait)).onSuccessTask(new Continuation(sessionToken)
/*      */     {
/*      */       public Task<Object> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1947 */         return ParseObject.this.deleteAsync(this.val$sessionToken);
/*      */       }
/*      */     }).onSuccessTask(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<Object> task)
/*      */         throws Exception
/*      */       {
/* 1952 */         return ParseObject.this.handleDeleteResultAsync(task.getResult());
/*      */       } } );
/*      */   }
/*      */ 
/*      */   Task<Object> deleteAsync(String sessionToken) throws ParseException {
/* 1958 */     return currentDeleteCommand(sessionToken).executeAsync();
/*      */   }
/*      */ 
/*      */   private Task<Void> handleDeleteResultAsync(Object result) {
/* 1962 */     Task task = Task.forResult(null);
/*      */ 
/* 1964 */     synchronized (this.mutex) {
/* 1965 */       boolean success = result != null;
/* 1966 */       if (success) {
/* 1967 */         this.isDeleted = true;
/*      */       }
/*      */     }
/*      */ 
/* 1971 */     OfflineStore store = OfflineStore.getCurrent();
/* 1972 */     if (store != null) {
/* 1973 */       task = task.continueWithTask(new Object(store)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task) throws Exception {
/* 1976 */           synchronized (ParseObject.this.mutex) {
/* 1977 */             if (ParseObject.this.isDeleted) {
/* 1978 */               return this.val$store.deleteDataForObjectAsync(ParseObject.this);
/*      */             }
/* 1980 */             return this.val$store.updateDataForObjectAsync(ParseObject.this);
/*      */           }
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/* 1987 */     return task;
/*      */   }
/*      */ 
/*      */   public final Task<Void> deleteInBackground()
/*      */   {
/* 1997 */     return this.taskQueue.enqueue(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 2000 */         return ParseObject.this.deleteAsync(task);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public final void delete()
/*      */     throws ParseException
/*      */   {
/* 2012 */     Parse.waitForTask(deleteInBackground());
/*      */   }
/*      */ 
/*      */   public final void deleteInBackground(DeleteCallback callback)
/*      */   {
/* 2023 */     Parse.callbackOnMainThreadAsync(deleteInBackground(), callback);
/*      */   }
/*      */ 
/*      */   private static <T extends ParseObject> Task<Void> deleteAllAsync(List<T> objects, String sessionToken)
/*      */   {
/* 2031 */     if (objects.size() == 0) {
/* 2032 */       return Task.forResult(null);
/*      */     }
/*      */ 
/* 2035 */     return Task.callInBackground(new Callable(objects)
/*      */     {
/*      */       public List<ParseObject> call() {
/* 2038 */         List uniqueObjects = new ArrayList();
/* 2039 */         HashSet idSet = new HashSet();
/* 2040 */         for (ParseObject obj : this.val$objects) {
/* 2041 */           if (!idSet.contains(obj.getObjectId())) {
/* 2042 */             idSet.add(obj.getObjectId());
/* 2043 */             uniqueObjects.add(obj);
/*      */           }
/*      */         }
/* 2046 */         return uniqueObjects;
/*      */       }
/*      */     }).continueWithTask(new Continuation(sessionToken)
/*      */     {
/*      */       public Task<Void> then(Task<List<ParseObject>> task)
/*      */         throws Exception
/*      */       {
/* 2051 */         List uniqueObjects = (List)task.getResult();
/* 2052 */         return ParseObject.enqueueForAll(uniqueObjects, new Continuation(uniqueObjects)
/*      */         {
/*      */           public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 2055 */             return toAwait.continueWithTask(new Continuation()
/*      */             {
/*      */               public Task<Void> then(Task<Void> task) throws Exception {
/* 2058 */                 List commands = new ArrayList();
/* 2059 */                 for (ParseObject uniqueObject : ParseObject.36.1.this.val$uniqueObjects) {
/* 2060 */                   ParseRESTObjectCommand command = uniqueObject.currentDeleteCommand(ParseObject.36.this.val$sessionToken);
/*      */ 
/* 2062 */                   commands.add(command);
/*      */                 }
/*      */ 
/* 2065 */                 List batchCommands = ParseRESTObjectBatchCommand.batchCommands(commands, ParseObject.36.this.val$sessionToken);
/*      */ 
/* 2067 */                 List tasks = new ArrayList();
/* 2068 */                 for (ParseRESTCommand command : batchCommands) {
/* 2069 */                   Task batchTask = command.executeAsync().makeVoid();
/* 2070 */                   tasks.add(batchTask);
/*      */                 }
/* 2072 */                 return Task.whenAll(tasks).makeVoid();
/*      */               }
/*      */             });
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void deleteAll(List<T> objects)
/*      */     throws ParseException
/*      */   {
/* 2091 */     Parse.waitForTask(deleteAllAsync(objects, ParseUser.getCurrentSessionToken()));
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void deleteAllInBackground(List<T> objects, DeleteCallback callback)
/*      */   {
/* 2104 */     Parse.callbackOnMainThreadAsync(deleteAllInBackground(objects), callback);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> Task<Void> deleteAllInBackground(List<T> objects)
/*      */   {
/* 2117 */     String sessionToken = ParseUser.getCurrentSessionToken();
/* 2118 */     return deleteAllAsync(objects, sessionToken);
/*      */   }
/*      */ 
/*      */   private static void collectDirtyChildren(Object node, List<ParseObject> dirtyChildren, List<ParseFile> dirtyFiles, IdentityHashMap<ParseObject, ParseObject> alreadySeen, IdentityHashMap<ParseObject, ParseObject> alreadySeenNew)
/*      */   {
/* 2141 */     new ParseTraverser(dirtyFiles, dirtyChildren, alreadySeen, alreadySeenNew)
/*      */     {
/*      */       protected boolean visit(Object node)
/*      */       {
/* 2145 */         if ((node instanceof ParseFile)) {
/* 2146 */           if (this.val$dirtyFiles == null) {
/* 2147 */             return true;
/*      */           }
/*      */ 
/* 2150 */           ParseFile file = (ParseFile)node;
/* 2151 */           if (file.getUrl() == null) {
/* 2152 */             this.val$dirtyFiles.add(file);
/*      */           }
/* 2154 */           return true;
/*      */         }
/*      */ 
/* 2158 */         if (!(node instanceof ParseObject)) {
/* 2159 */           return true;
/*      */         }
/*      */ 
/* 2162 */         if (this.val$dirtyChildren == null) {
/* 2163 */           return true;
/*      */         }
/*      */ 
/* 2167 */         ParseObject object = (ParseObject)node;
/* 2168 */         IdentityHashMap seen = this.val$alreadySeen;
/* 2169 */         IdentityHashMap seenNew = this.val$alreadySeenNew;
/*      */ 
/* 2173 */         if (object.getObjectId() != null) {
/* 2174 */           seenNew = new IdentityHashMap();
/*      */         } else {
/* 2176 */           if (seenNew.containsKey(object)) {
/* 2177 */             throw new RuntimeException("Found a circular dependency while saving.");
/*      */           }
/* 2179 */           seenNew = new IdentityHashMap(seenNew);
/* 2180 */           seenNew.put(object, object);
/*      */         }
/*      */ 
/* 2186 */         if (seen.containsKey(object)) {
/* 2187 */           return true;
/*      */         }
/* 2189 */         seen = new IdentityHashMap(seen);
/* 2190 */         seen.put(object, object);
/*      */ 
/* 2195 */         ParseObject.access$1300(object.estimatedData, this.val$dirtyChildren, this.val$dirtyFiles, seen, seenNew);
/*      */ 
/* 2197 */         if (object.isDirty(false)) {
/* 2198 */           this.val$dirtyChildren.add(object);
/*      */         }
/*      */ 
/* 2201 */         return true;
/*      */       }
/*      */     }
/* 2141 */     .setYieldRoot(true).traverse(node);
/*      */   }
/*      */ 
/*      */   private static void collectDirtyChildren(Object node, List<ParseObject> dirtyChildren, List<ParseFile> dirtyFiles)
/*      */   {
/* 2212 */     collectDirtyChildren(node, dirtyChildren, dirtyFiles, new IdentityHashMap(), new IdentityHashMap());
/*      */   }
/*      */ 
/*      */   private boolean canBeSerialized()
/*      */   {
/* 2221 */     synchronized (this.mutex) {
/* 2222 */       Capture result = new Capture(Boolean.valueOf(true));
/*      */ 
/* 2228 */       new ParseTraverser(result)
/*      */       {
/*      */         protected boolean visit(Object value) {
/* 2231 */           if ((value instanceof ParseObject)) {
/* 2232 */             ParseObject object = (ParseObject)value;
/* 2233 */             if (object.getObjectId() == null) {
/* 2234 */               this.val$result.set(Boolean.valueOf(false));
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 2239 */           return ((Boolean)this.val$result.get()).booleanValue();
/*      */         }
/*      */       }
/* 2228 */       .setYieldRoot(false).setTraverseParseObjects(true).traverse(this);
/*      */ 
/* 2243 */       return ((Boolean)result.get()).booleanValue();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static Task<Void> deepSaveAsync(Object object, String sessionToken)
/*      */   {
/* 2253 */     ParseUser currentUser = ParseUser.getCurrentUser();
/* 2254 */     List objects = new ArrayList();
/* 2255 */     List files = new ArrayList();
/* 2256 */     collectDirtyChildren(object, objects, files);
/*      */ 
/* 2258 */     List fileSaveTasks = new ArrayList();
/* 2259 */     for (ParseFile file : files) {
/* 2260 */       fileSaveTasks.add(file.saveAsync(sessionToken, null));
/*      */     }
/*      */ 
/* 2263 */     return Task.whenAll(fileSaveTasks).onSuccessTask(new Continuation(objects, currentUser, sessionToken)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 2266 */         IdentityHashMap uniqueObjects = new IdentityHashMap();
/*      */ 
/* 2268 */         for (ParseObject obj : this.val$objects) {
/* 2269 */           uniqueObjects.put(obj, Boolean.valueOf(true));
/*      */         }
/*      */ 
/* 2272 */         Capture remaining = new Capture(new ArrayList(uniqueObjects.keySet()));
/*      */ 
/* 2274 */         return Task.forResult(null).continueWhile(new Callable(remaining)
/*      */         {
/*      */           public Boolean call() throws Exception {
/* 2277 */             return Boolean.valueOf(((List)this.val$remaining.get()).size() > 0);
/*      */           }
/*      */         }
/*      */         , new Continuation(remaining)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task)
/*      */             throws Exception
/*      */           {
/* 2284 */             List current = new ArrayList();
/* 2285 */             List nextBatch = new ArrayList();
/* 2286 */             for (ParseObject obj : (List)this.val$remaining.get()) {
/* 2287 */               if (obj.canBeSerialized())
/* 2288 */                 current.add(obj);
/*      */               else {
/* 2290 */                 nextBatch.add(obj);
/*      */               }
/*      */             }
/* 2293 */             this.val$remaining.set(nextBatch);
/*      */ 
/* 2295 */             if (current.size() == 0)
/*      */             {
/* 2299 */               throw new RuntimeException("Unable to save a ParseObject with a relation to a cycle.");
/*      */             }
/*      */ 
/* 2304 */             Task result = Task.forResult(null);
/*      */ 
/* 2312 */             if ((ParseObject.40.this.val$currentUser != null) && (ParseObject.40.this.val$currentUser.isLazy()) && (current.contains(ParseObject.40.this.val$currentUser))) {
/* 2313 */               result = result.onSuccessTask(new Continuation()
/*      */               {
/*      */                 public Task<Void> then(Task<Void> task) throws Exception {
/* 2316 */                   return ParseObject.40.this.val$currentUser.saveInBackground();
/*      */                 }
/*      */               }).onSuccess(new Continuation(current)
/*      */               {
/*      */                 public Void then(Task<Void> task)
/*      */                   throws Exception
/*      */                 {
/* 2321 */                   this.val$current.remove(ParseObject.40.this.val$currentUser);
/* 2322 */                   return null;
/*      */                 }
/*      */               });
/*      */             }
/*      */ 
/* 2328 */             result = result.onSuccessTask(new Continuation(current)
/*      */             {
/*      */               public Task<Void> then(Task<Void> task) throws Exception {
/* 2331 */                 if (this.val$current.size() == 0) {
/* 2332 */                   return Task.forResult(null);
/*      */                 }
/*      */ 
/* 2335 */                 List objectBatches = Parse.partitionList(this.val$current, 50);
/*      */ 
/* 2337 */                 List tasks = new ArrayList();
/* 2338 */                 for (List batch : objectBatches) {
/* 2339 */                   Task batchTask = ParseObject.enqueueForAll(batch, new Continuation(batch)
/*      */                   {
/*      */                     public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 2342 */                       return toAwait.continueWithTask(new Object()
/*      */                       {
/*      */                         public Task<Void> then(Task<Void> task) throws Exception {
/* 2345 */                           List commands = new ArrayList();
/* 2346 */                           List operations = new ArrayList();
/* 2347 */                           for (ParseObject obj : ParseObject.40.2.3.1.this.val$batch)
/*      */                           {
/*      */                             ParseOperationSet operationSet;
/* 2349 */                             synchronized (obj.mutex) {
/* 2350 */                               obj.validateSave();
/* 2351 */                               operationSet = obj.startSave();
/*      */                             }
/* 2353 */                             operations.add(operationSet);
/* 2354 */                             ParseRESTObjectCommand command = obj.currentSaveCommand(operationSet, PointerEncodingStrategy.get(), ParseObject.40.this.val$sessionToken);
/*      */ 
/* 2356 */                             commands.add(command);
/*      */                           }
/*      */ 
/* 2359 */                           ParseRESTObjectBatchCommand batchCommand = ParseRESTObjectBatchCommand.batchCommand(commands, ParseObject.40.this.val$sessionToken);
/*      */ 
/* 2361 */                           return batchCommand.executeAsync().cast().continueWithTask(new Continuation(operations)
/*      */                           {
/*      */                             public Task<Void> then(Task<JSONArray> commandTask)
/*      */                               throws Exception
/*      */                             {
/* 2366 */                               JSONArray commandResult = (JSONArray)commandTask.getResult();
/*      */ 
/* 2368 */                               List tasks = new ArrayList();
/* 2369 */                               for (int i = 0; i < ParseObject.40.2.3.this.val$current.size(); i++) {
/* 2370 */                                 JSONObject result = null;
/* 2371 */                                 if (!commandTask.isFaulted()) {
/* 2372 */                                   JSONObject objectResult = commandResult.getJSONObject(i);
/* 2373 */                                   result = objectResult.optJSONObject("success");
/*      */                                 }
/* 2375 */                                 tasks.add(((ParseObject)ParseObject.40.2.3.this.val$current.get(i)).handleSaveResultAsync(result, (ParseOperationSet)this.val$operations.get(i)));
/*      */                               }
/*      */ 
/* 2378 */                               return Task.whenAll(tasks).continueWithTask(new Continuation(commandTask, tasks)
/*      */                               {
/*      */                                 public Task<Void> then(Task<Void> task) throws Exception
/*      */                                 {
/* 2382 */                                   if ((this.val$commandTask.isFaulted()) || (this.val$commandTask.isCancelled()))
/*      */                                   {
/* 2384 */                                     return this.val$commandTask.makeVoid();
/*      */                                   }
/*      */ 
/* 2387 */                                   if (task.isFaulted())
/*      */                                   {
/* 2393 */                                     for (Task t : this.val$tasks) {
/* 2394 */                                       if (t.isFaulted()) {
/* 2395 */                                         return t;
/*      */                                       }
/*      */                                     }
/*      */                                   }
/* 2399 */                                   return task;
/*      */                                 }
/*      */                               });
/*      */                             }
/*      */                           });
/*      */                         }
/*      */                       });
/*      */                     }
/*      */                   });
/* 2408 */                   tasks.add(batchTask);
/*      */                 }
/* 2410 */                 return Task.whenAll(tasks);
/*      */               }
/*      */             });
/* 2413 */             return result;
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void saveAll(List<T> objects)
/*      */     throws ParseException
/*      */   {
/* 2430 */     Parse.waitForTask(saveAllInBackground(objects));
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void saveAllInBackground(List<T> objects, SaveCallback callback)
/*      */   {
/* 2443 */     Parse.callbackOnMainThreadAsync(saveAllInBackground(objects), callback);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> Task<Void> saveAllInBackground(List<T> objects)
/*      */   {
/* 2456 */     return deepSaveAsync(objects, ParseUser.getCurrentSessionToken());
/*      */   }
/*      */ 
/*      */   private static <T extends ParseObject> Task<List<T>> fetchAllIfNeededAsync(List<T> objects, ParseUser user, Task<Void> toAwait)
/*      */   {
/* 2461 */     List ids = new ArrayList();
/* 2462 */     String className = null;
/* 2463 */     for (ParseObject object : objects) {
/* 2464 */       if (!object.isDataAvailable()) {
/* 2465 */         if ((className != null) && (!className.equals(object.getClassName()))) {
/* 2466 */           throw new IllegalArgumentException("All objects should have the same class");
/*      */         }
/* 2468 */         className = object.getClassName();
/* 2469 */         String id = object.getObjectId();
/* 2470 */         if (id != null) {
/* 2471 */           ids.add(id);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2476 */     if (ids.size() == 0) {
/* 2477 */       return Task.forResult(objects);
/*      */     }
/*      */ 
/* 2480 */     ParseQuery query = ParseQuery.getQuery(className);
/* 2481 */     query.whereContainedIn("objectId", ids);
/* 2482 */     return toAwait.continueWithTask(new Continuation(query, user)
/*      */     {
/*      */       public Task<List<T>> then(Task<Void> task) throws Exception {
/* 2485 */         return this.val$query.findWithCachePolicyAsync(ParseQuery.CachePolicy.IGNORE_CACHE, this.val$user);
/*      */       }
/*      */     }).onSuccess(new Continuation(objects)
/*      */     {
/*      */       public List<T> then(Task<List<T>> task)
/*      */         throws Exception
/*      */       {
/* 2490 */         Map resultMap = new HashMap();
/* 2491 */         for (ParseObject o : (List)task.getResult()) {
/* 2492 */           resultMap.put(o.getObjectId(), o);
/*      */         }
/* 2494 */         for (ParseObject object : this.val$objects) {
/* 2495 */           if (object.isDataAvailable()) {
/*      */             continue;
/*      */           }
/* 2498 */           ParseObject newObject = (ParseObject)resultMap.get(object.getObjectId());
/* 2499 */           if (newObject == null) {
/* 2500 */             throw new RuntimeException("Object id " + object.getObjectId() + " does not exist");
/*      */           }
/*      */ 
/* 2504 */           object.mergeFromObject(newObject);
/* 2505 */           object.hasBeenFetched = true;
/*      */         }
/* 2507 */         return this.val$objects;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> Task<List<T>> fetchAllIfNeededInBackground(List<T> objects)
/*      */   {
/* 2521 */     ParseUser user = ParseUser.getCurrentUser();
/* 2522 */     return enqueueForAll(objects, new Continuation(objects, user)
/*      */     {
/*      */       public Task<List<T>> then(Task<Void> task) throws Exception {
/* 2525 */         return ParseObject.access$1500(this.val$objects, this.val$user, task);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> List<T> fetchAllIfNeeded(List<T> objects)
/*      */     throws ParseException
/*      */   {
/* 2541 */     return (List)Parse.waitForTask(fetchAllIfNeededInBackground(objects));
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void fetchAllIfNeededInBackground(List<T> objects, FindCallback<T> callback)
/*      */   {
/* 2554 */     Parse.callbackOnMainThreadAsync(fetchAllIfNeededInBackground(objects), callback);
/*      */   }
/*      */ 
/*      */   private static <T extends ParseObject> Task<List<T>> fetchAllAsync(List<T> objects, ParseUser user, Task<Void> toAwait)
/*      */   {
/* 2559 */     if (objects.size() == 0) {
/* 2560 */       return Task.forResult(objects);
/*      */     }
/*      */ 
/* 2563 */     List ids = new ArrayList();
/* 2564 */     String className = ((ParseObject)objects.get(0)).getClassName();
/* 2565 */     for (ParseObject object : objects) {
/* 2566 */       if (!object.getClassName().equals(className)) {
/* 2567 */         throw new IllegalArgumentException("All objects should have the same class");
/*      */       }
/* 2569 */       String id = object.getObjectId();
/* 2570 */       if (id == null) {
/* 2571 */         throw new IllegalArgumentException("All objects must exist on the server");
/*      */       }
/*      */ 
/* 2574 */       ids.add(object.getObjectId());
/*      */     }
/* 2576 */     ParseQuery query = ParseQuery.getQuery(className);
/* 2577 */     query.whereContainedIn("objectId", ids);
/* 2578 */     return toAwait.continueWithTask(new Continuation(query, user)
/*      */     {
/*      */       public Task<List<T>> then(Task<Void> task) throws Exception {
/* 2581 */         return this.val$query.findWithCachePolicyAsync(ParseQuery.CachePolicy.IGNORE_CACHE, this.val$user);
/*      */       }
/*      */     }).onSuccess(new Continuation(objects)
/*      */     {
/*      */       public List<T> then(Task<List<T>> task)
/*      */         throws Exception
/*      */       {
/* 2586 */         Map resultMap = new HashMap();
/* 2587 */         for (ParseObject o : (List)task.getResult()) {
/* 2588 */           resultMap.put(o.getObjectId(), o);
/*      */         }
/* 2590 */         for (ParseObject object : this.val$objects) {
/* 2591 */           ParseObject newObject = (ParseObject)resultMap.get(object.getObjectId());
/* 2592 */           if (newObject == null) {
/* 2593 */             throw new RuntimeException("Object id " + object.getObjectId() + " does not exist");
/*      */           }
/*      */ 
/* 2596 */           object.mergeFromObject(newObject);
/* 2597 */           object.hasBeenFetched = true;
/*      */         }
/* 2599 */         return this.val$objects;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> Task<List<T>> fetchAllInBackground(List<T> objects)
/*      */   {
/* 2613 */     ParseUser user = ParseUser.getCurrentUser();
/* 2614 */     return enqueueForAll(objects, new Continuation(objects, user)
/*      */     {
/*      */       public Task<List<T>> then(Task<Void> task) throws Exception {
/* 2617 */         return ParseObject.access$1600(this.val$objects, this.val$user, task);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> List<T> fetchAll(List<T> objects)
/*      */     throws ParseException
/*      */   {
/* 2632 */     return (List)Parse.waitForTask(fetchAllInBackground(objects));
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void fetchAllInBackground(List<T> objects, FindCallback<T> callback)
/*      */   {
/* 2645 */     Parse.callbackOnMainThreadAsync(fetchAllInBackground(objects), callback);
/*      */   }
/*      */ 
/*      */   private ParseOperationSet currentOperations()
/*      */   {
/* 2652 */     synchronized (this.mutex) {
/* 2653 */       return (ParseOperationSet)this.operationSetQueue.getLast();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void applyOperations(ParseOperationSet operations, Map<String, Object> map)
/*      */   {
/* 2661 */     synchronized (this.mutex) {
/* 2662 */       for (String key : operations.keySet()) {
/* 2663 */         ParseFieldOperation operation = (ParseFieldOperation)operations.get(key);
/* 2664 */         Object oldValue = map.get(key);
/* 2665 */         Object newValue = operation.apply(oldValue, this, key);
/* 2666 */         if (newValue != null)
/* 2667 */           map.put(key, newValue);
/*      */         else
/* 2669 */           map.remove(key);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void rebuildEstimatedData()
/*      */   {
/* 2679 */     synchronized (this.mutex) {
/* 2680 */       this.estimatedData.clear();
/* 2681 */       this.estimatedData.putAll(this.serverData);
/* 2682 */       for (ParseOperationSet operations : this.operationSetQueue)
/* 2683 */         applyOperations(operations, this.estimatedData);
/*      */     }
/*      */   }
/*      */ 
/*      */   void performOperation(String key, ParseFieldOperation operation)
/*      */   {
/* 2693 */     synchronized (this.mutex) {
/* 2694 */       Object oldValue = this.estimatedData.get(key);
/* 2695 */       Object newValue = operation.apply(oldValue, this, key);
/* 2696 */       if (newValue != null)
/* 2697 */         this.estimatedData.put(key, newValue);
/*      */       else {
/* 2699 */         this.estimatedData.remove(key);
/*      */       }
/*      */ 
/* 2702 */       ParseFieldOperation oldOperation = (ParseFieldOperation)currentOperations().get(key);
/* 2703 */       ParseFieldOperation newOperation = operation.mergeWithPrevious(oldOperation);
/* 2704 */       currentOperations().put(key, newOperation);
/*      */ 
/* 2706 */       checkpointMutableContainer(newValue);
/* 2707 */       this.dataAvailability.put(key, Boolean.TRUE);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void put(String key, Object value)
/*      */   {
/* 2722 */     checkKeyIsMutable(key);
/*      */ 
/* 2724 */     performPut(key, value);
/*      */   }
/*      */ 
/*      */   void performPut(String key, Object value) {
/* 2728 */     if (key == null) {
/* 2729 */       throw new IllegalArgumentException("key may not be null.");
/*      */     }
/*      */ 
/* 2732 */     if (value == null) {
/* 2733 */       throw new IllegalArgumentException("value may not be null.");
/*      */     }
/*      */ 
/* 2736 */     if (!Parse.isValidType(value)) {
/* 2737 */       throw new IllegalArgumentException("invalid type for value: " + value.getClass().toString());
/*      */     }
/*      */ 
/* 2740 */     performOperation(key, new ParseSetOperation(value));
/*      */   }
/*      */ 
/*      */   public boolean has(String key)
/*      */   {
/* 2751 */     return containsKey(key);
/*      */   }
/*      */ 
/*      */   public void increment(String key)
/*      */   {
/* 2761 */     increment(key, Integer.valueOf(1));
/*      */   }
/*      */ 
/*      */   public void increment(String key, Number amount)
/*      */   {
/* 2773 */     ParseIncrementOperation operation = new ParseIncrementOperation(amount);
/* 2774 */     performOperation(key, operation);
/*      */   }
/*      */ 
/*      */   public void add(String key, Object value)
/*      */   {
/* 2786 */     addAll(key, Arrays.asList(new Object[] { value }));
/*      */   }
/*      */ 
/*      */   public void addAll(String key, Collection<?> values)
/*      */   {
/* 2799 */     ParseAddOperation operation = new ParseAddOperation(values);
/* 2800 */     performOperation(key, operation);
/*      */   }
/*      */ 
/*      */   public void addUnique(String key, Object value)
/*      */   {
/* 2813 */     addAllUnique(key, Arrays.asList(new Object[] { value }));
/*      */   }
/*      */ 
/*      */   public void addAllUnique(String key, Collection<?> values)
/*      */   {
/* 2827 */     ParseAddUniqueOperation operation = new ParseAddUniqueOperation(values);
/* 2828 */     performOperation(key, operation);
/*      */   }
/*      */ 
/*      */   public void remove(String key)
/*      */   {
/* 2838 */     checkKeyIsMutable(key);
/*      */ 
/* 2840 */     performRemove(key);
/*      */   }
/*      */ 
/*      */   void performRemove(String key) {
/* 2844 */     synchronized (this.mutex) {
/* 2845 */       Object object = get(key);
/*      */ 
/* 2847 */       if (object != null)
/* 2848 */         performOperation(key, ParseDeleteOperation.getInstance());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void removeAll(String key, Collection<?> values)
/*      */   {
/* 2865 */     checkKeyIsMutable(key);
/*      */ 
/* 2867 */     ParseRemoveOperation operation = new ParseRemoveOperation(values);
/* 2868 */     performOperation(key, operation);
/*      */   }
/*      */ 
/*      */   private void checkKeyIsMutable(String key) {
/* 2872 */     if (!isKeyMutable(key))
/* 2873 */       throw new IllegalArgumentException("Cannot modify `" + key + "` property of an " + getClassName() + " object.");
/*      */   }
/*      */ 
/*      */   boolean isKeyMutable(String key)
/*      */   {
/* 2879 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean containsKey(String key)
/*      */   {
/* 2890 */     synchronized (this.mutex) {
/* 2891 */       return this.estimatedData.containsKey(key);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getString(String key)
/*      */   {
/* 2903 */     synchronized (this.mutex) {
/* 2904 */       checkGetAccess(key);
/* 2905 */       Object value = this.estimatedData.get(key);
/* 2906 */       if (!(value instanceof String)) {
/* 2907 */         return null;
/*      */       }
/* 2909 */       return (String)value;
/*      */     }
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(String key)
/*      */   {
/* 2921 */     synchronized (this.mutex) {
/* 2922 */       checkGetAccess(key);
/* 2923 */       Object value = this.estimatedData.get(key);
/* 2924 */       if (!(value instanceof byte[])) {
/* 2925 */         return null;
/*      */       }
/*      */ 
/* 2928 */       return (byte[])(byte[])value;
/*      */     }
/*      */   }
/*      */ 
/*      */   public Number getNumber(String key)
/*      */   {
/* 2940 */     synchronized (this.mutex) {
/* 2941 */       checkGetAccess(key);
/* 2942 */       Object value = this.estimatedData.get(key);
/* 2943 */       if (!(value instanceof Number)) {
/* 2944 */         return null;
/*      */       }
/* 2946 */       return (Number)value;
/*      */     }
/*      */   }
/*      */ 
/*      */   public JSONArray getJSONArray(String key)
/*      */   {
/* 2962 */     synchronized (this.mutex) {
/* 2963 */       checkGetAccess(key);
/* 2964 */       Object value = this.estimatedData.get(key);
/*      */ 
/* 2966 */       if ((value instanceof List)) {
/* 2967 */         value = Parse.encode(value, PointerOrLocalIdEncodingStrategy.get());
/* 2968 */         put(key, value);
/*      */       }
/*      */ 
/* 2971 */       if (!(value instanceof JSONArray)) {
/* 2972 */         return null;
/*      */       }
/* 2974 */       return (JSONArray)value;
/*      */     }
/*      */   }
/*      */ 
/*      */   public <T> List<T> getList(String key)
/*      */   {
/* 2988 */     synchronized (this.mutex) {
/* 2989 */       Object value = this.estimatedData.get(key);
/*      */ 
/* 2991 */       if ((value instanceof JSONArray)) {
/* 2992 */         ParseDecoder decoder = new ParseDecoder();
/* 2993 */         value = decoder.convertJSONArrayToList((JSONArray)value);
/* 2994 */         put(key, value);
/*      */       }
/*      */ 
/* 2997 */       if (!(value instanceof List)) {
/* 2998 */         return null;
/*      */       }
/*      */ 
/* 3001 */       List returnValue = (List)value;
/* 3002 */       return returnValue;
/*      */     }
/*      */   }
/*      */ 
/*      */   public <V> Map<String, V> getMap(String key)
/*      */   {
/* 3016 */     synchronized (this.mutex) {
/* 3017 */       Object value = this.estimatedData.get(key);
/*      */ 
/* 3019 */       if ((value instanceof JSONObject)) {
/* 3020 */         ParseDecoder decoder = new ParseDecoder();
/* 3021 */         value = decoder.convertJSONObjectToMap((JSONObject)value);
/* 3022 */         put(key, value);
/*      */       }
/*      */ 
/* 3025 */       if (!(value instanceof Map)) {
/* 3026 */         return null;
/*      */       }
/*      */ 
/* 3029 */       Map returnValue = (Map)value;
/* 3030 */       return returnValue;
/*      */     }
/*      */   }
/*      */ 
/*      */   public JSONObject getJSONObject(String key)
/*      */   {
/* 3046 */     synchronized (this.mutex) {
/* 3047 */       checkGetAccess(key);
/* 3048 */       Object value = this.estimatedData.get(key);
/*      */ 
/* 3050 */       if ((value instanceof Map)) {
/* 3051 */         value = Parse.encode(value, PointerOrLocalIdEncodingStrategy.get());
/* 3052 */         put(key, value);
/*      */       }
/*      */ 
/* 3055 */       if (!(value instanceof JSONObject)) {
/* 3056 */         return null;
/*      */       }
/*      */ 
/* 3059 */       return (JSONObject)value;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getInt(String key)
/*      */   {
/* 3071 */     Number number = getNumber(key);
/* 3072 */     if (number == null) {
/* 3073 */       return 0;
/*      */     }
/* 3075 */     return number.intValue();
/*      */   }
/*      */ 
/*      */   public double getDouble(String key)
/*      */   {
/* 3086 */     Number number = getNumber(key);
/* 3087 */     if (number == null) {
/* 3088 */       return 0.0D;
/*      */     }
/* 3090 */     return number.doubleValue();
/*      */   }
/*      */ 
/*      */   public long getLong(String key)
/*      */   {
/* 3101 */     Number number = getNumber(key);
/* 3102 */     if (number == null) {
/* 3103 */       return 0L;
/*      */     }
/* 3105 */     return number.longValue();
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(String key)
/*      */   {
/* 3116 */     synchronized (this.mutex) {
/* 3117 */       checkGetAccess(key);
/* 3118 */       Object value = this.estimatedData.get(key);
/* 3119 */       if (!(value instanceof Boolean)) {
/* 3120 */         return false;
/*      */       }
/* 3122 */       return ((Boolean)value).booleanValue();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Date getDate(String key)
/*      */   {
/* 3134 */     synchronized (this.mutex) {
/* 3135 */       checkGetAccess(key);
/* 3136 */       Object value = this.estimatedData.get(key);
/* 3137 */       if (!(value instanceof Date)) {
/* 3138 */         return null;
/*      */       }
/* 3140 */       return (Date)value;
/*      */     }
/*      */   }
/*      */ 
/*      */   public ParseObject getParseObject(String key)
/*      */   {
/* 3155 */     Object value = get(key);
/* 3156 */     if (!(value instanceof ParseObject)) {
/* 3157 */       return null;
/*      */     }
/* 3159 */     return (ParseObject)value;
/*      */   }
/*      */ 
/*      */   public ParseUser getParseUser(String key)
/*      */   {
/* 3173 */     Object value = get(key);
/* 3174 */     if (!(value instanceof ParseUser)) {
/* 3175 */       return null;
/*      */     }
/* 3177 */     return (ParseUser)value;
/*      */   }
/*      */ 
/*      */   public ParseFile getParseFile(String key)
/*      */   {
/* 3190 */     Object value = get(key);
/* 3191 */     if (!(value instanceof ParseFile)) {
/* 3192 */       return null;
/*      */     }
/* 3194 */     return (ParseFile)value;
/*      */   }
/*      */ 
/*      */   public ParseGeoPoint getParseGeoPoint(String key)
/*      */   {
/* 3205 */     synchronized (this.mutex) {
/* 3206 */       checkGetAccess(key);
/* 3207 */       Object value = this.estimatedData.get(key);
/* 3208 */       if (!(value instanceof ParseGeoPoint)) {
/* 3209 */         return null;
/*      */       }
/* 3211 */       return (ParseGeoPoint)value;
/*      */     }
/*      */   }
/*      */ 
/*      */   public ParseACL getACL()
/*      */   {
/* 3219 */     return getACL(true);
/*      */   }
/*      */ 
/*      */   private ParseACL getACL(boolean mayCopy) {
/* 3223 */     synchronized (this.mutex) {
/* 3224 */       checkGetAccess("ACL");
/* 3225 */       Object acl = this.estimatedData.get("ACL");
/* 3226 */       if (acl == null) {
/* 3227 */         return null;
/*      */       }
/* 3229 */       if (!(acl instanceof ParseACL)) {
/* 3230 */         throw new RuntimeException("only ACLs can be stored in the ACL key");
/*      */       }
/* 3232 */       if ((mayCopy) && (((ParseACL)acl).isShared())) {
/* 3233 */         ParseACL copy = ((ParseACL)acl).copy();
/* 3234 */         this.estimatedData.put("ACL", copy);
/* 3235 */         addToHashedObjects(copy);
/* 3236 */         return copy;
/*      */       }
/* 3238 */       return (ParseACL)acl;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setACL(ParseACL acl)
/*      */   {
/* 3246 */     put("ACL", acl);
/*      */   }
/*      */ 
/*      */   public boolean isDataAvailable()
/*      */   {
/* 3256 */     synchronized (this.mutex) {
/* 3257 */       return this.hasBeenFetched;
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean isDataAvailable(String key) {
/* 3262 */     synchronized (this.mutex) {
/* 3263 */       return (isDataAvailable()) || ((this.dataAvailability.containsKey(key)) && (((Boolean)this.dataAvailability.get(key)).booleanValue()));
/*      */     }
/*      */   }
/*      */ 
/*      */   public <T extends ParseObject> ParseRelation<T> getRelation(String key)
/*      */   {
/* 3277 */     synchronized (this.mutex)
/*      */     {
/* 3279 */       Object value = this.estimatedData.get(key);
/* 3280 */       if ((value instanceof ParseRelation))
/*      */       {
/* 3282 */         ParseRelation relation = (ParseRelation)value;
/* 3283 */         relation.ensureParentAndKey(this, key);
/* 3284 */         return relation;
/*      */       }
/* 3286 */       ParseRelation relation = new ParseRelation(this, key);
/*      */ 
/* 3295 */       this.estimatedData.put(key, relation);
/* 3296 */       return relation;
/*      */     }
/*      */   }
/*      */ 
/*      */   public Object get(String key)
/*      */   {
/* 3310 */     synchronized (this.mutex) {
/* 3311 */       checkGetAccess(key);
/* 3312 */       Object value = this.estimatedData.get(key);
/*      */ 
/* 3314 */       if (((value instanceof ParseACL)) && (key.equals("ACL"))) {
/* 3315 */         ParseACL acl = (ParseACL)value;
/* 3316 */         if (acl.isShared()) {
/* 3317 */           ParseACL copy = acl.copy();
/* 3318 */           this.estimatedData.put("ACL", copy);
/* 3319 */           addToHashedObjects(copy);
/* 3320 */           return getACL();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3326 */       if ((value instanceof ParseRelation)) {
/* 3327 */         ((ParseRelation)value).ensureParentAndKey(this, key);
/*      */       }
/*      */ 
/* 3330 */       return value;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkGetAccess(String key) {
/* 3335 */     if (!isDataAvailable(key))
/* 3336 */       throw new IllegalStateException("ParseObject has no data for this key.  Call fetchIfNeeded() to get the data.");
/*      */   }
/*      */ 
/*      */   public boolean hasSameId(ParseObject other)
/*      */   {
/* 3342 */     synchronized (this.mutex) {
/* 3343 */       return (getClassName() != null) && (getObjectId() != null) && (getClassName().equals(other.getClassName())) && (getObjectId().equals(other.getObjectId()));
/*      */     }
/*      */   }
/*      */ 
/*      */   void registerSaveListener(GetCallback<ParseObject> callback)
/*      */   {
/* 3350 */     synchronized (this.mutex) {
/* 3351 */       this.saveEvent.subscribe(callback);
/*      */     }
/*      */   }
/*      */ 
/*      */   void unregisterSaveListener(GetCallback<ParseObject> callback) {
/* 3356 */     synchronized (this.mutex) {
/* 3357 */       this.saveEvent.unsubscribe(callback);
/*      */     }
/*      */   }
/*      */ 
/*      */   static String getClassName(Class<? extends ParseObject> clazz)
/*      */   {
/* 3369 */     String name = (String)classNames.get(clazz);
/* 3370 */     if (name == null) {
/* 3371 */       ParseClassName info = (ParseClassName)clazz.getAnnotation(ParseClassName.class);
/* 3372 */       if (info == null) {
/* 3373 */         return null;
/*      */       }
/* 3375 */       name = info.value();
/* 3376 */       classNames.put(clazz, name);
/*      */     }
/* 3378 */     return name;
/*      */   }
/*      */ 
/*      */   void setDefaultValues()
/*      */   {
/* 3385 */     if ((needsDefaultACL()) && (ParseACL.getDefaultACL() != null))
/* 3386 */       setACL(ParseACL.getDefaultACL());
/*      */   }
/*      */ 
/*      */   boolean needsDefaultACL()
/*      */   {
/* 3395 */     return true;
/*      */   }
/*      */ 
/*      */   static void registerParseSubclasses()
/*      */   {
/* 3404 */     registerSubclass(ParseUser.class);
/* 3405 */     registerSubclass(ParseRole.class);
/* 3406 */     registerSubclass(ParseInstallation.class);
/* 3407 */     registerSubclass(ParseSession.class);
/*      */ 
/* 3409 */     registerSubclass(ParsePin.class);
/* 3410 */     registerSubclass(EventuallyPin.class);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void pinAllInBackground(String name, List<T> objects, SaveCallback callback)
/*      */   {
/* 3439 */     Parse.callbackOnMainThreadAsync(pinAllInBackground(name, objects), callback);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> Task<Void> pinAllInBackground(String name, List<T> objects)
/*      */   {
/* 3460 */     return pinAllInBackground(name, objects, true);
/*      */   }
/*      */ 
/*      */   private static <T extends ParseObject> Task<Void> pinAllInBackground(String name, List<T> objects, boolean includeAllChildren)
/*      */   {
/* 3465 */     if (!OfflineStore.isEnabled()) {
/* 3466 */       throw new IllegalStateException("Method requires Local Datastore. Please refer to `Parse#enableLocalDatastore(Context)`.");
/*      */     }
/*      */ 
/* 3471 */     Task task = Task.forResult(null);
/* 3472 */     for (ParseObject object : objects) {
/* 3473 */       task = task.onSuccessTask(new Continuation(object)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task) throws Exception {
/* 3476 */           if (!this.val$object.isDataAvailable("ACL")) {
/* 3477 */             return Task.forResult(null);
/*      */           }
/*      */ 
/* 3480 */           ParseACL acl = this.val$object.getACL(false);
/* 3481 */           if (acl == null) {
/* 3482 */             return Task.forResult(null);
/*      */           }
/*      */ 
/* 3485 */           if (!acl.hasUnresolvedUser()) {
/* 3486 */             return Task.forResult(null);
/*      */           }
/*      */ 
/* 3489 */           return ParseUser.getCurrentUserAsync().onSuccessTask(new Continuation()
/*      */           {
/*      */             public Task<Void> then(Task<ParseUser> task) throws Exception {
/* 3492 */               return ParseUser.pinCurrentUserIfNeededAsync((ParseUser)task.getResult());
/*      */             }
/*      */ 
/*      */           });
/*      */         }
/*      */ 
/*      */       });
/*      */     }
/*      */ 
/* 3505 */     return task.onSuccessTask(new Continuation(name, objects, includeAllChildren)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 3508 */         return ParsePin.pinAllObjectsAsync(this.val$name != null ? this.val$name : "_default", this.val$objects, this.val$includeAllChildren);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void pinAll(String name, List<T> objects)
/*      */     throws ParseException
/*      */   {
/* 3535 */     Parse.waitForTask(pinAllInBackground(name, objects));
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void pinAllInBackground(List<T> objects, SaveCallback callback)
/*      */   {
/* 3555 */     Parse.callbackOnMainThreadAsync(pinAllInBackground("_default", objects), callback);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> Task<Void> pinAllInBackground(List<T> objects)
/*      */   {
/* 3574 */     return pinAllInBackground("_default", objects);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void pinAll(List<T> objects)
/*      */     throws ParseException
/*      */   {
/* 3592 */     Parse.waitForTask(pinAllInBackground("_default", objects));
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void unpinAllInBackground(String name, List<T> objects, DeleteCallback callback)
/*      */   {
/* 3609 */     Parse.callbackOnMainThreadAsync(unpinAllInBackground(name, objects), callback);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> Task<Void> unpinAllInBackground(String name, List<T> objects)
/*      */   {
/* 3626 */     if (!OfflineStore.isEnabled()) {
/* 3627 */       throw new IllegalStateException("Method requires Local Datastore. Please refer to `Parse#enableLocalDatastore(Context)`.");
/*      */     }
/*      */ 
/* 3630 */     if (name == null) {
/* 3631 */       name = "_default";
/*      */     }
/* 3633 */     return ParsePin.unpinAllObjectsAsync(name, objects);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void unpinAll(String name, List<T> objects)
/*      */     throws ParseException
/*      */   {
/* 3650 */     Parse.waitForTask(unpinAllInBackground(name, objects));
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void unpinAllInBackground(List<T> objects, DeleteCallback callback)
/*      */   {
/* 3666 */     Parse.callbackOnMainThreadAsync(unpinAllInBackground("_default", objects), callback);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> Task<Void> unpinAllInBackground(List<T> objects)
/*      */   {
/* 3681 */     return unpinAllInBackground("_default", objects);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> void unpinAll(List<T> objects)
/*      */     throws ParseException
/*      */   {
/* 3696 */     Parse.waitForTask(unpinAllInBackground("_default", objects));
/*      */   }
/*      */ 
/*      */   public static void unpinAllInBackground(String name, DeleteCallback callback)
/*      */   {
/* 3710 */     Parse.callbackOnMainThreadAsync(unpinAllInBackground(name), callback);
/*      */   }
/*      */ 
/*      */   public static Task<Void> unpinAllInBackground(String name)
/*      */   {
/* 3724 */     if (!OfflineStore.isEnabled()) {
/* 3725 */       throw new IllegalStateException("Method requires Local Datastore. Please refer to `Parse#enableLocalDatastore(Context)`.");
/*      */     }
/*      */ 
/* 3728 */     if (name == null) {
/* 3729 */       name = "_default";
/*      */     }
/* 3731 */     return ParsePin.unpinAllObjectsAsync(name);
/*      */   }
/*      */ 
/*      */   public static void unpinAll(String name)
/*      */     throws ParseException
/*      */   {
/* 3745 */     Parse.waitForTask(unpinAllInBackground(name));
/*      */   }
/*      */ 
/*      */   public static void unpinAllInBackground(DeleteCallback callback)
/*      */   {
/* 3758 */     Parse.callbackOnMainThreadAsync(unpinAllInBackground(), callback);
/*      */   }
/*      */ 
/*      */   public static Task<Void> unpinAllInBackground()
/*      */   {
/* 3770 */     return unpinAllInBackground("_default");
/*      */   }
/*      */ 
/*      */   public static void unpinAll()
/*      */     throws ParseException
/*      */   {
/* 3782 */     Parse.waitForTask(unpinAllInBackground());
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> Task<T> fetchFromLocalDatastoreAsync()
/*      */   {
/* 3792 */     if (!OfflineStore.isEnabled()) {
/* 3793 */       throw new IllegalStateException("Method requires Local Datastore. Please refer to `Parse#enableLocalDatastore(Context)`.");
/*      */     }
/*      */ 
/* 3796 */     return OfflineStore.getCurrent().fetchLocallyAsync(this);
/*      */   }
/*      */ 
/*      */   public <T extends ParseObject> void fetchFromLocalDatastoreInBackground(GetCallback<T> callback)
/*      */   {
/* 3805 */     Parse.callbackOnMainThreadAsync(fetchFromLocalDatastoreAsync(), callback);
/*      */   }
/*      */ 
/*      */   public void fetchFromLocalDatastore()
/*      */     throws ParseException
/*      */   {
/* 3816 */     Parse.waitForTask(fetchFromLocalDatastoreAsync());
/*      */   }
/*      */ 
/*      */   public void pinInBackground(String name, SaveCallback callback)
/*      */   {
/* 3833 */     Parse.callbackOnMainThreadAsync(pinInBackground(name), callback);
/*      */   }
/*      */ 
/*      */   public Task<Void> pinInBackground(String name)
/*      */   {
/* 3849 */     return pinAllInBackground(name, Arrays.asList(new ParseObject[] { this }));
/*      */   }
/*      */ 
/*      */   Task<Void> pinInBackground(String name, boolean includeAllChildren) {
/* 3853 */     return pinAllInBackground(name, Arrays.asList(new ParseObject[] { this }), includeAllChildren);
/*      */   }
/*      */ 
/*      */   public void pin(String name)
/*      */     throws ParseException
/*      */   {
/* 3869 */     Parse.waitForTask(pinInBackground(name));
/*      */   }
/*      */ 
/*      */   public void pinInBackground(SaveCallback callback)
/*      */   {
/* 3887 */     Parse.callbackOnMainThreadAsync(pinInBackground(), callback);
/*      */   }
/*      */ 
/*      */   public Task<Void> pinInBackground()
/*      */   {
/* 3904 */     return pinAllInBackground("_default", Arrays.asList(new ParseObject[] { this }));
/*      */   }
/*      */ 
/*      */   public void pin()
/*      */     throws ParseException
/*      */   {
/* 3921 */     Parse.waitForTask(pinInBackground());
/*      */   }
/*      */ 
/*      */   public void unpinInBackground(String name, DeleteCallback callback)
/*      */   {
/* 3933 */     Parse.callbackOnMainThreadAsync(unpinInBackground(name), callback);
/*      */   }
/*      */ 
/*      */   public Task<Void> unpinInBackground(String name)
/*      */   {
/* 3944 */     return unpinAllInBackground(name, Arrays.asList(new ParseObject[] { this }));
/*      */   }
/*      */ 
/*      */   public void unpin(String name)
/*      */     throws ParseException
/*      */   {
/* 3953 */     Parse.waitForTask(unpinInBackground(name));
/*      */   }
/*      */ 
/*      */   public void unpinInBackground(DeleteCallback callback)
/*      */   {
/* 3966 */     Parse.callbackOnMainThreadAsync(unpinInBackground(), callback);
/*      */   }
/*      */ 
/*      */   public Task<Void> unpinInBackground()
/*      */   {
/* 3978 */     return unpinAllInBackground("_default", Arrays.asList(new ParseObject[] { this }));
/*      */   }
/*      */ 
/*      */   public void unpin()
/*      */     throws ParseException
/*      */   {
/* 3988 */     Parse.waitForTask(unpinInBackground());
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   77 */     DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
/*   78 */     format.setTimeZone(new SimpleTimeZone(0, "GMT"));
/*   79 */     impreciseDateFormat = format;
/*      */ 
/*  105 */     isCreatingPointerForObjectId = new ThreadLocal()
/*      */     {
/*      */       protected String initialValue()
/*      */       {
/*  109 */         return null;
/*      */       }
/*      */     };
/*      */   }
/*      */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseObject
 * JD-Core Version:    0.6.0
 */