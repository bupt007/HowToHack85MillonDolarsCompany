/*     */ package com.parse;
/*     */ 
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ @ParseClassName("_EventuallyPin")
/*     */ class EventuallyPin extends ParseObject
/*     */ {
/*     */   public static final String PIN_NAME = "_eventuallyPin";
/*     */   public static final int TYPE_SAVE = 1;
/*     */   public static final int TYPE_DELETE = 2;
/*     */   public static final int TYPE_COMMAND = 3;
/*     */ 
/*     */   public EventuallyPin()
/*     */   {
/*  38 */     super("_EventuallyPin");
/*     */   }
/*     */ 
/*     */   public String getUUID() {
/*  42 */     return getString("uuid");
/*     */   }
/*     */ 
/*     */   public int getType() {
/*  46 */     return getInt("type");
/*     */   }
/*     */ 
/*     */   public ParseObject getObject() {
/*  50 */     return getParseObject("object");
/*     */   }
/*     */ 
/*     */   public String getOperationSetUUID() {
/*  54 */     return getString("operationSetUUID");
/*     */   }
/*     */ 
/*     */   public String getSessionToken() {
/*  58 */     return getString("sessionToken");
/*     */   }
/*     */ 
/*     */   public ParseNetworkCommand getCommand() throws JSONException {
/*  62 */     JSONObject json = getJSONObject("command");
/*     */     ParseNetworkCommand command;
/*  64 */     if (ParseRESTCommand.isValidCommandJSONObject(json)) {
/*  65 */       command = ParseRESTCommand.fromJSONObject(json);
/*     */     }
/*     */     else
/*     */     {
/*     */       ParseNetworkCommand command;
/*  66 */       if (ParseCommand.isValidCommandJSONObject(json))
/*  67 */         command = new ParseCommand(json);
/*     */       else
/*  69 */         throw new JSONException("Failed to load command from JSON.");
/*     */     }
/*     */     ParseNetworkCommand command;
/*  71 */     return command;
/*     */   }
/*     */ 
/*     */   public static Task<EventuallyPin> pinEventuallyCommand(ParseObject object, ParseNetworkCommand command)
/*     */   {
/*  76 */     int type = 3;
/*  77 */     JSONObject json = null;
/*  78 */     if ((command instanceof ParseRESTCommand)) {
/*  79 */       ParseRESTCommand restCommand = (ParseRESTCommand)command;
/*  80 */       if (restCommand.httpPath.startsWith("classes")) {
/*  81 */         if ((restCommand.method == ParseRequest.Method.POST) || (restCommand.method == ParseRequest.Method.PUT))
/*     */         {
/*  83 */           type = 1;
/*  84 */         } else if (restCommand.method == ParseRequest.Method.DELETE)
/*  85 */           type = 2;
/*     */       }
/*     */       else
/*  88 */         json = restCommand.toJSONObject();
/*     */     }
/*  90 */     else if ((command instanceof ParseCommand)) {
/*  91 */       ParseCommand oldCommand = (ParseCommand)command;
/*  92 */       String op = oldCommand.getOp();
/*  93 */       switch (op) {
/*     */       case "create":
/*     */       case "update":
/*  96 */         type = 1;
/*  97 */         break;
/*     */       case "delete":
/*  99 */         type = 2;
/* 100 */         break;
/*     */       default:
/* 102 */         json = command.toJSONObject();
/*     */       }
/*     */     }
/*     */ 
/* 106 */     return pinEventuallyCommand(type, object, command.getOperationSetUUID(), command.getSessionToken(), json);
/*     */   }
/*     */ 
/*     */   private static Task<EventuallyPin> pinEventuallyCommand(int type, ParseObject obj, String operationSetUUID, String sessionToken, JSONObject command)
/*     */   {
/* 132 */     EventuallyPin pin = new EventuallyPin();
/* 133 */     pin.put("uuid", UUID.randomUUID().toString());
/* 134 */     pin.put("time", new Date());
/* 135 */     pin.put("type", Integer.valueOf(type));
/* 136 */     if (obj != null) {
/* 137 */       pin.put("object", obj);
/*     */     }
/* 139 */     if (operationSetUUID != null) {
/* 140 */       pin.put("operationSetUUID", operationSetUUID);
/*     */     }
/* 142 */     if (sessionToken != null) {
/* 143 */       pin.put("sessionToken", sessionToken);
/*     */     }
/* 145 */     if (command != null) {
/* 146 */       pin.put("command", command);
/*     */     }
/* 148 */     return pin.pinInBackground("_eventuallyPin").continueWith(new Continuation(pin)
/*     */     {
/*     */       public EventuallyPin then(Task<Void> task) throws Exception {
/* 151 */         return this.val$pin;
/*     */       } } );
/*     */   }
/*     */ 
/*     */   public static Task<List<EventuallyPin>> findAllPinned() {
/* 157 */     return findAllPinned(null);
/*     */   }
/*     */ 
/*     */   public static Task<List<EventuallyPin>> findAllPinned(Collection<String> excludeUUIDs) {
/* 161 */     ParseQuery query = new ParseQuery(EventuallyPin.class).fromPin("_eventuallyPin").ignoreACLs().orderByAscending("time");
/*     */ 
/* 166 */     if (excludeUUIDs != null) {
/* 167 */       query.whereNotContainedIn("uuid", excludeUUIDs);
/*     */     }
/*     */ 
/* 172 */     return query.findInBackground().continueWithTask(new Continuation()
/*     */     {
/*     */       public Task<List<EventuallyPin>> then(Task<List<EventuallyPin>> task) throws Exception {
/* 175 */         List pins = (List)task.getResult();
/* 176 */         List tasks = new ArrayList();
/*     */ 
/* 178 */         for (EventuallyPin pin : pins) {
/* 179 */           ParseObject object = pin.getObject();
/* 180 */           if (object != null) {
/* 181 */             tasks.add(object.fetchFromLocalDatastoreAsync().makeVoid());
/*     */           }
/*     */         }
/*     */ 
/* 185 */         return Task.whenAll(tasks).continueWithTask(new Continuation(pins)
/*     */         {
/*     */           public Task<List<EventuallyPin>> then(Task<Void> task) throws Exception {
/* 188 */             return Task.forResult(this.val$pins);
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.EventuallyPin
 * JD-Core Version:    0.6.0
 */