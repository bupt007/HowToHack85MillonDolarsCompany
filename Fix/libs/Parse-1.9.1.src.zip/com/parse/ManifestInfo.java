/*     */ package com.parse;
/*     */ 
/*     */ import android.app.Service;
/*     */ import android.content.BroadcastReceiver;
/*     */ import android.content.ComponentName;
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import android.content.pm.ActivityInfo;
/*     */ import android.content.pm.ApplicationInfo;
/*     */ import android.content.pm.PackageInfo;
/*     */ import android.content.pm.PackageManager;
/*     */ import android.content.pm.PackageManager.NameNotFoundException;
/*     */ import android.content.pm.ResolveInfo;
/*     */ import android.content.pm.ServiceInfo;
/*     */ import android.os.Build.VERSION;
/*     */ import android.os.Bundle;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ class ManifestInfo
/*     */ {
/*     */   private static final String TAG = "com.parse.ManifestInfo";
/*     */   private static final int NUMBER_OF_PUSH_INTENTS = 3;
/*  32 */   private static final Object lock = new Object();
/*  33 */   private static long lastModified = -1L;
/*  34 */   static int versionCode = -1;
/*  35 */   static String versionName = null;
/*  36 */   private static int iconId = 0;
/*  37 */   private static String displayName = null;
/*     */   private static PushType pushType;
/* 157 */   private static Boolean pushUsesBroadcastReceivers = null;
/*     */ 
/*     */   public static long getLastModified()
/*     */   {
/*  45 */     synchronized (lock) {
/*  46 */       if (lastModified == -1L) {
/*  47 */         File apkPath = new File(getApplicationInfo().sourceDir);
/*  48 */         lastModified = apkPath.lastModified();
/*     */       }
/*     */     }
/*     */ 
/*  52 */     return lastModified;
/*     */   }
/*     */ 
/*     */   public static int getVersionCode()
/*     */   {
/*  60 */     synchronized (lock) {
/*  61 */       if (versionCode == -1) {
/*     */         try {
/*  63 */           versionCode = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
/*     */         } catch (PackageManager.NameNotFoundException e) {
/*  65 */           Parse.logE("com.parse.ManifestInfo", "Couldn't find info about own package", e);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  70 */     return versionCode;
/*     */   }
/*     */ 
/*     */   public static String getVersionName()
/*     */   {
/*  78 */     synchronized (lock) {
/*  79 */       if (versionName == null) {
/*     */         try {
/*  81 */           versionName = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
/*     */         } catch (PackageManager.NameNotFoundException e) {
/*  83 */           Parse.logE("com.parse.ManifestInfo", "Couldn't find info about own package", e);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  88 */     return versionName;
/*     */   }
/*     */ 
/*     */   public static String getDisplayName()
/*     */   {
/*  96 */     synchronized (lock) {
/*  97 */       if (displayName == null) {
/*  98 */         displayName = getPackageManager().getApplicationLabel(getApplicationInfo()).toString();
/*     */       }
/*     */     }
/*     */ 
/* 102 */     return displayName;
/*     */   }
/*     */ 
/*     */   public static int getIconId()
/*     */   {
/* 110 */     synchronized (lock) {
/* 111 */       if (iconId == 0) {
/* 112 */         iconId = getApplicationInfo().icon;
/*     */       }
/*     */     }
/*     */ 
/* 116 */     return iconId;
/*     */   }
/*     */ 
/*     */   static boolean hasIntentReceiver(String action)
/*     */   {
/* 123 */     return !getIntentReceivers(new String[] { action }).isEmpty();
/*     */   }
/*     */ 
/*     */   static List<ResolveInfo> getIntentReceivers(String[] actions)
/*     */   {
/* 131 */     String packageName = getPackageName();
/* 132 */     List list = new ArrayList();
/*     */ 
/* 134 */     for (String action : actions) {
/* 135 */       list.addAll(getPackageManager().queryBroadcastReceivers(new Intent(action), 32));
/*     */     }
/*     */ 
/* 141 */     for (int i = list.size() - 1; i >= 0; i--) {
/* 142 */       String receiverPackageName = ((ResolveInfo)list.get(i)).activityInfo.packageName;
/* 143 */       if (!receiverPackageName.equals(packageName)) {
/* 144 */         list.remove(i);
/*     */       }
/*     */     }
/* 147 */     return list;
/*     */   }
/*     */ 
/*     */   public static void setPushUsesBroadcastReceivers(boolean value)
/*     */   {
/* 160 */     pushUsesBroadcastReceivers = Boolean.valueOf(value);
/*     */   }
/*     */ 
/*     */   static boolean getPushUsesBroadcastReceivers()
/*     */   {
/* 169 */     if (pushUsesBroadcastReceivers != null) {
/* 170 */       return pushUsesBroadcastReceivers.booleanValue();
/*     */     }
/*     */ 
/* 173 */     int intentsRegistered = 0;
/* 174 */     if (hasIntentReceiver("com.parse.push.intent.RECEIVE")) {
/* 175 */       intentsRegistered++;
/*     */     }
/*     */ 
/* 178 */     if (hasIntentReceiver("com.parse.push.intent.OPEN")) {
/* 179 */       intentsRegistered++;
/*     */     }
/*     */ 
/* 182 */     if (hasIntentReceiver("com.parse.push.intent.DELETE")) {
/* 183 */       intentsRegistered++;
/*     */     }
/*     */ 
/* 186 */     if ((intentsRegistered != 0) && (intentsRegistered != 3)) {
/* 187 */       throw new SecurityException("The Parse Push BroadcastReceiver must implement a filter for all of com.parse.push.intent.RECEIVE, com.parse.push.intent.OPEN, and com.parse.push.intent.DELETE");
/*     */     }
/*     */ 
/* 192 */     pushUsesBroadcastReceivers = Boolean.valueOf(intentsRegistered == 3);
/* 193 */     return pushUsesBroadcastReceivers.booleanValue();
/*     */   }
/*     */ 
/*     */   static void setPushType(PushType newPushType)
/*     */   {
/* 198 */     synchronized (lock) {
/* 199 */       pushType = newPushType;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static PushType getPushType()
/*     */   {
/* 208 */     synchronized (lock) {
/* 209 */       if (pushType == null) {
/* 210 */         boolean deviceSupportsGcm = deviceSupportsGcm();
/* 211 */         boolean hasAnyGcmSpecificDeclaration = hasAnyGcmSpecificDeclaration();
/* 212 */         ManifestCheckResult gcmSupportLevel = gcmSupportLevel();
/* 213 */         ManifestCheckResult ppnsSupportLevel = ppnsSupportLevel();
/*     */ 
/* 215 */         if ((deviceSupportsGcm) && (gcmSupportLevel != ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS)) {
/* 216 */           pushType = PushType.GCM;
/*     */         }
/* 232 */         else if (((!hasAnyGcmSpecificDeclaration) || (!deviceSupportsGcm)) && (ppnsSupportLevel != ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS))
/*     */         {
/* 234 */           pushType = PushType.PPNS;
/*     */         }
/* 236 */         else pushType = PushType.NONE;
/*     */ 
/* 243 */         if (Parse.getLogLevel() <= 5) {
/* 244 */           if ((pushType == PushType.GCM) && (gcmSupportLevel == ManifestCheckResult.MISSING_OPTIONAL_DECLARATIONS)) {
/* 245 */             Parse.logW("com.parse.ManifestInfo", "Using GCM for push, but the app manifest is missing some optional declarations that should be added for maximum reliability. Please " + getGcmManifestMessage());
/*     */           }
/* 248 */           else if ((pushType == PushType.PPNS) && (ppnsSupportLevel == ManifestCheckResult.MISSING_OPTIONAL_DECLARATIONS)) {
/* 249 */             Parse.logW("com.parse.ManifestInfo", "Using PPNS for push, but the app manifest is missing some optional declarations that should be added for maximum reliability. Please " + getPpnsManifestMessage());
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 260 */         if ((Parse.getLogLevel() <= 6) && 
/* 261 */           (pushType == PushType.NONE) && (hasAnyGcmSpecificDeclaration)) {
/* 262 */           if (!deviceSupportsGcm) {
/* 263 */             Parse.logE("com.parse.ManifestInfo", "Cannot use GCM for push on this device because Google Play Services is not installed. Install Google Play Service from the Play Store, or enable PPNS as a fallback push service. To enable PPNS as a fallback push service on devices without Google Play support, please " + getPpnsManifestMessage());
/*     */           }
/*     */ 
/* 270 */           if (gcmSupportLevel != ManifestCheckResult.HAS_ALL_DECLARATIONS) {
/* 271 */             Parse.logE("com.parse.ManifestInfo", "Cannot use GCM for push because the app manifest is missing some required declarations. Please " + getGcmManifestMessage());
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 277 */         if (Parse.getLogLevel() <= 2) {
/* 278 */           Parse.logV("com.parse.ManifestInfo", "Using " + pushType + " for push.");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 283 */     return pushType;
/*     */   }
/*     */ 
/*     */   public static String getNonePushTypeLogMessage()
/*     */   {
/* 291 */     synchronized (lock) {
/* 292 */       if (pushType == PushType.NONE) {
/* 293 */         return "Push is not configured for this app because the app manifest is missing required declarations. Please add the following declarations to your app manifest to support either GCM or PPNS for push (or both). To enable GCM support, please " + getGcmManifestMessage() + "To enable PPNS support, please " + getPpnsManifestMessage();
/*     */       }
/*     */ 
/* 298 */       return "";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Context getContext()
/*     */   {
/* 322 */     return Parse.getApplicationContext();
/*     */   }
/*     */ 
/*     */   private static String getPackageName() {
/* 326 */     return getPackageName(getContext());
/*     */   }
/*     */ 
/*     */   private static String getPackageName(Context context) {
/* 330 */     return context.getPackageName();
/*     */   }
/*     */ 
/*     */   private static PackageManager getPackageManager() {
/* 334 */     return getPackageManager(getContext());
/*     */   }
/*     */ 
/*     */   private static PackageManager getPackageManager(Context context) {
/* 338 */     return context.getPackageManager();
/*     */   }
/*     */ 
/*     */   private static ApplicationInfo getApplicationInfo() {
/* 342 */     return getContext().getApplicationInfo();
/*     */   }
/*     */ 
/*     */   private static ApplicationInfo getApplicationInfo(Context context, int flags) {
/*     */     try {
/* 347 */       return getPackageManager(context).getApplicationInfo(getPackageName(context), flags); } catch (PackageManager.NameNotFoundException e) {
/*     */     }
/* 349 */     return null;
/*     */   }
/*     */ 
/*     */   public static Bundle getApplicationMetadata(Context context)
/*     */   {
/* 357 */     ApplicationInfo info = getApplicationInfo(context, 128);
/* 358 */     if (info != null) {
/* 359 */       return info.metaData;
/*     */     }
/* 361 */     return null;
/*     */   }
/*     */ 
/*     */   private static PackageInfo getPackageInfo(String name) {
/* 365 */     PackageInfo info = null;
/*     */     try
/*     */     {
/* 368 */       info = getPackageManager().getPackageInfo(name, 0);
/*     */     }
/*     */     catch (PackageManager.NameNotFoundException e)
/*     */     {
/*     */     }
/* 373 */     return info;
/*     */   }
/*     */ 
/*     */   private static ServiceInfo getServiceInfo(Class<? extends Service> clazz) {
/* 377 */     ServiceInfo info = null;
/*     */     try
/*     */     {
/* 380 */       info = getPackageManager().getServiceInfo(new ComponentName(getContext(), clazz), 0);
/*     */     }
/*     */     catch (PackageManager.NameNotFoundException e)
/*     */     {
/*     */     }
/* 385 */     return info;
/*     */   }
/*     */ 
/*     */   private static ActivityInfo getReceiverInfo(Class<? extends BroadcastReceiver> clazz) {
/* 389 */     ActivityInfo info = null;
/*     */     try
/*     */     {
/* 392 */       info = getPackageManager().getReceiverInfo(new ComponentName(getContext(), clazz), 0);
/*     */     }
/*     */     catch (PackageManager.NameNotFoundException e)
/*     */     {
/*     */     }
/* 397 */     return info;
/*     */   }
/*     */ 
/*     */   private static boolean hasPermissions(String[] permissions) {
/* 401 */     for (String permission : permissions) {
/* 402 */       if (getPackageManager().checkPermission(permission, getPackageName()) != 0) {
/* 403 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 407 */     return true;
/*     */   }
/*     */ 
/*     */   private static boolean checkResolveInfo(Class<? extends BroadcastReceiver> clazz, List<ResolveInfo> infoList) {
/* 411 */     for (ResolveInfo info : infoList) {
/* 412 */       if ((info.activityInfo != null) && (clazz.getCanonicalName().equals(info.activityInfo.name))) {
/* 413 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 417 */     return false;
/*     */   }
/*     */ 
/*     */   private static boolean checkReceiver(Class<? extends BroadcastReceiver> clazz, String permission, Intent[] intents) {
/* 421 */     ActivityInfo receiver = getReceiverInfo(clazz);
/*     */ 
/* 423 */     if (receiver == null) {
/* 424 */       return false;
/*     */     }
/*     */ 
/* 427 */     if ((permission != null) && (!permission.equals(receiver.permission))) {
/* 428 */       return false;
/*     */     }
/*     */ 
/* 431 */     for (Intent intent : intents) {
/* 432 */       List receivers = getPackageManager().queryBroadcastReceivers(intent, 0);
/* 433 */       if (receivers.isEmpty()) {
/* 434 */         return false;
/*     */       }
/*     */ 
/* 437 */       if (!checkResolveInfo(clazz, receivers)) {
/* 438 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 442 */     return true;
/*     */   }
/*     */ 
/*     */   private static boolean hasAnyGcmSpecificDeclaration() {
/* 446 */     if (!hasPermissions(new String[] { "com.google.android.c2dm.permission.RECEIVE" }));
/* 449 */     return (hasPermissions(new String[] { getPackageName() + ".permission.C2D_MESSAGE" })) || (getReceiverInfo(GcmBroadcastReceiver.class) != null);
/*     */   }
/*     */ 
/*     */   private static boolean deviceSupportsGcm()
/*     */   {
/* 456 */     return (Build.VERSION.SDK_INT >= 8) && (getPackageInfo("com.google.android.gsf") != null);
/*     */   }
/*     */ 
/*     */   private static ManifestCheckResult gcmSupportLevel() {
/* 460 */     if (getServiceInfo(PushService.class) == null) {
/* 461 */       return ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS;
/*     */     }
/*     */ 
/* 464 */     String[] requiredPermissions = { "android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.WAKE_LOCK", "android.permission.GET_ACCOUNTS", "com.google.android.c2dm.permission.RECEIVE", getPackageName() + ".permission.C2D_MESSAGE" };
/*     */ 
/* 473 */     if (!hasPermissions(requiredPermissions)) {
/* 474 */       return ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS;
/*     */     }
/*     */ 
/* 477 */     String packageName = getPackageName();
/* 478 */     String rcvrPermission = "com.google.android.c2dm.permission.SEND";
/* 479 */     Intent[] intents = { new Intent("com.google.android.c2dm.intent.RECEIVE").setPackage(packageName).addCategory(packageName), new Intent("com.google.android.c2dm.intent.REGISTRATION").setPackage(packageName).addCategory(packageName) };
/*     */ 
/* 488 */     if (!checkReceiver(GcmBroadcastReceiver.class, rcvrPermission, intents)) {
/* 489 */       return ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS;
/*     */     }
/*     */ 
/* 492 */     String[] optionalPermissions = { "android.permission.VIBRATE" };
/*     */ 
/* 496 */     if (!hasPermissions(optionalPermissions)) {
/* 497 */       return ManifestCheckResult.MISSING_OPTIONAL_DECLARATIONS;
/*     */     }
/*     */ 
/* 500 */     return ManifestCheckResult.HAS_ALL_DECLARATIONS;
/*     */   }
/*     */ 
/*     */   private static ManifestCheckResult ppnsSupportLevel()
/*     */   {
/* 508 */     if (getServiceInfo(PushService.class) == null) {
/* 509 */       return ManifestCheckResult.MISSING_REQUIRED_DECLARATIONS;
/*     */     }
/*     */ 
/* 512 */     String[] optionalPermissions = { "android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.VIBRATE", "android.permission.WAKE_LOCK", "android.permission.RECEIVE_BOOT_COMPLETED" };
/*     */ 
/* 520 */     if (!hasPermissions(optionalPermissions)) {
/* 521 */       return ManifestCheckResult.MISSING_OPTIONAL_DECLARATIONS;
/*     */     }
/*     */ 
/* 524 */     Intent[] intents = { new Intent("android.intent.action.BOOT_COMPLETED").setPackage(getPackageName()), new Intent("android.intent.action.USER_PRESENT").setPackage(getPackageName()) };
/*     */ 
/* 529 */     if (!checkReceiver(ParseBroadcastReceiver.class, null, intents)) {
/* 530 */       return ManifestCheckResult.MISSING_OPTIONAL_DECLARATIONS;
/*     */     }
/*     */ 
/* 533 */     return ManifestCheckResult.HAS_ALL_DECLARATIONS;
/*     */   }
/*     */ 
/*     */   private static String getGcmManifestMessage() {
/* 537 */     String gcmPackagePermission = getPackageName() + ".permission.C2D_MESSAGE";
/* 538 */     return "make sure that these permissions are declared as children of the root <manifest> element:\n\n<uses-permission android:name=\"android.permission.INTERNET\" />\n<uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\" />\n<uses-permission android:name=\"android.permission.VIBRATE\" />\n<uses-permission android:name=\"android.permission.WAKE_LOCK\" />\n<uses-permission android:name=\"android.permission.GET_ACCOUNTS\" />\n<uses-permission android:name=\"com.google.android.c2dm.permission.RECEIVE\" />\n<permission android:name=\"" + gcmPackagePermission + "\" " + "android:protectionLevel=\"signature\" />\n" + "<uses-permission android:name=\"" + gcmPackagePermission + "\" />\n" + "\n" + "Also, please make sure that these services and broadcast receivers are declared as " + "children of the <application> element:\n" + "\n" + "<service android:name=\"com.parse.PushService\" />\n" + "<receiver android:name=\"com.parse.GcmBroadcastReceiver\" " + "android:permission=\"com.google.android.c2dm.permission.SEND\">\n" + "  <intent-filter>\n" + "    <action android:name=\"com.google.android.c2dm.intent.RECEIVE\" />\n" + "    <action android:name=\"com.google.android.c2dm.intent.REGISTRATION\" />\n" + "    <category android:name=\"" + getPackageName() + "\" />\n" + "  </intent-filter>\n" + "</receiver>\n";
/*     */   }
/*     */ 
/*     */   private static String getPpnsManifestMessage()
/*     */   {
/* 566 */     return "make sure that these permissions are declared as children of the root <manifest> element:\n\n<uses-permission android:name=\"android.permission.INTERNET\" />\n<uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\" />\n<uses-permission android:name=\"android.permission.RECEIVE_BOOT_COMPLETED\" />\n<uses-permission android:name=\"android.permission.VIBRATE\" />\n<uses-permission android:name=\"android.permission.WAKE_LOCK\" />\n\nAlso, please make sure that these services and broadcast receivers are declared as children of the <application> element:\n\n<service android:name=\"com.parse.PushService\" />\n<receiver android:name=\"com.parse.ParseBroadcastReceiver\">\n  <intent-filter>\n    <action android:name=\"android.intent.action.BOOT_COMPLETED\" />\n    <action android:name=\"android.intent.action.USER_PRESENT\" />\n  </intent-filter>\n</receiver>\n";
/*     */   }
/*     */ 
/*     */   static enum ManifestCheckResult
/*     */   {
/* 307 */     HAS_ALL_DECLARATIONS, 
/*     */ 
/* 313 */     MISSING_OPTIONAL_DECLARATIONS, 
/*     */ 
/* 318 */     MISSING_REQUIRED_DECLARATIONS;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ManifestInfo
 * JD-Core Version:    0.6.0
 */