/*    */ package com.parse;
/*    */ 
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseDeleteOperation
/*    */   implements ParseFieldOperation
/*    */ {
/* 10 */   private static final ParseDeleteOperation defaultInstance = new ParseDeleteOperation();
/*    */ 
/*    */   public static ParseDeleteOperation getInstance() {
/* 13 */     return defaultInstance;
/*    */   }
/*    */ 
/*    */   public JSONObject encode(ParseObjectEncodingStrategy objectEncoder)
/*    */     throws JSONException
/*    */   {
/* 21 */     JSONObject output = new JSONObject();
/* 22 */     output.put("__op", "Delete");
/* 23 */     return output;
/*    */   }
/*    */ 
/*    */   public ParseFieldOperation mergeWithPrevious(ParseFieldOperation previous)
/*    */   {
/* 28 */     return this;
/*    */   }
/*    */ 
/*    */   public Object apply(Object oldValue, ParseObject object, String key)
/*    */   {
/* 33 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseDeleteOperation
 * JD-Core Version:    0.6.0
 */