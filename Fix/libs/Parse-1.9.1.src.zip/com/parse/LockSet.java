/*    */ package com.parse;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Comparator;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ import java.util.WeakHashMap;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ class LockSet
/*    */ {
/* 11 */   private static WeakHashMap<Lock, Long> stableIds = new WeakHashMap();
/* 12 */   private static long nextStableId = 0L;
/*    */   private final Set<Lock> locks;
/*    */ 
/*    */   public LockSet(Collection<Lock> locks)
/*    */   {
/* 17 */     this.locks = new TreeSet(new Comparator()
/*    */     {
/*    */       public int compare(Lock lhs, Lock rhs) {
/* 20 */         Long lhsId = LockSet.access$000(lhs);
/* 21 */         Long rhsId = LockSet.access$000(rhs);
/* 22 */         return lhsId.compareTo(rhsId);
/*    */       }
/*    */     });
/* 25 */     this.locks.addAll(locks);
/*    */   }
/*    */ 
/*    */   private static Long getStableId(Lock lock) {
/* 29 */     synchronized (stableIds) {
/* 30 */       if (stableIds.containsKey(lock)) {
/* 31 */         return (Long)stableIds.get(lock);
/*    */       }
/* 33 */       long id = nextStableId++;
/* 34 */       stableIds.put(lock, Long.valueOf(id));
/* 35 */       return Long.valueOf(id);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void lock() {
/* 40 */     for (Lock l : this.locks)
/* 41 */       l.lock();
/*    */   }
/*    */ 
/*    */   public void unlock()
/*    */   {
/* 46 */     for (Lock l : this.locks)
/* 47 */       l.unlock();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.LockSet
 * JD-Core Version:    0.6.0
 */