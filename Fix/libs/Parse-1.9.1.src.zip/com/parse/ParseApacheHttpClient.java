/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.content.pm.PackageInfo;
/*     */ import android.content.pm.PackageManager;
/*     */ import android.content.pm.PackageManager.NameNotFoundException;
/*     */ import android.net.SSLCertificateSocketFactory;
/*     */ import android.net.SSLSessionCache;
/*     */ import android.os.Build.VERSION;
/*     */ import java.io.IOException;
/*     */ import org.apache.http.HttpHost;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.client.params.HttpClientParams;
/*     */ import org.apache.http.conn.ClientConnectionManager;
/*     */ import org.apache.http.conn.params.ConnManagerParams;
/*     */ import org.apache.http.conn.params.ConnPerRouteBean;
/*     */ import org.apache.http.conn.scheme.PlainSocketFactory;
/*     */ import org.apache.http.conn.scheme.Scheme;
/*     */ import org.apache.http.conn.scheme.SchemeRegistry;
/*     */ import org.apache.http.impl.client.DefaultHttpClient;
/*     */ import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
/*     */ import org.apache.http.params.BasicHttpParams;
/*     */ import org.apache.http.params.HttpConnectionParams;
/*     */ import org.apache.http.params.HttpParams;
/*     */ import org.apache.http.params.HttpProtocolParams;
/*     */ 
/*     */ class ParseApacheHttpClient extends ParseHttpClient
/*     */ {
/*     */   private static final int SOCKET_OPERATION_TIMEOUT = 10000;
/*     */   private DefaultHttpClient httpClient;
/*     */ 
/*     */   public ParseApacheHttpClient(Context context)
/*     */   {
/*  41 */     if (context == null) {
/*  42 */       throw new IllegalArgumentException("Context passed to newHttpClient should not be null.");
/*     */     }
/*  44 */     context = context.getApplicationContext();
/*     */ 
/*  47 */     HttpParams params = new BasicHttpParams();
/*     */ 
/*  51 */     HttpConnectionParams.setStaleCheckingEnabled(params, false);
/*     */ 
/*  53 */     HttpConnectionParams.setConnectionTimeout(params, 10000);
/*  54 */     HttpConnectionParams.setSoTimeout(params, 10000);
/*  55 */     HttpConnectionParams.setSocketBufferSize(params, 8192);
/*     */ 
/*  59 */     HttpClientParams.setRedirecting(params, false);
/*     */ 
/*  62 */     SSLSessionCache sessionCache = new SSLSessionCache(context);
/*     */ 
/*  65 */     HttpProtocolParams.setUserAgent(params, getUserAgent(context));
/*  66 */     SchemeRegistry schemeRegistry = new SchemeRegistry();
/*  67 */     schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
/*  68 */     schemeRegistry.register(new Scheme("https", SSLCertificateSocketFactory.getHttpSocketFactory(10000, sessionCache), 443));
/*     */ 
/*  73 */     ConnManagerParams.setMaxConnectionsPerRoute(params, new ConnPerRouteBean(20));
/*  74 */     ConnManagerParams.setMaxTotalConnections(params, 20);
/*     */ 
/*  77 */     String host = System.getProperty("http.proxyHost");
/*  78 */     String portString = System.getProperty("http.proxyPort");
/*  79 */     if ((host != null) && (host.length() != 0) && (portString != null) && (portString.length() != 0)) {
/*  80 */       int port = Integer.parseInt(portString);
/*  81 */       HttpHost proxy = new HttpHost(host, port, "http");
/*  82 */       params.setParameter("http.route.default-proxy", proxy);
/*     */     }
/*     */ 
/*  85 */     ClientConnectionManager manager = new ThreadSafeClientConnManager(params, schemeRegistry);
/*  86 */     this.httpClient = new DefaultHttpClient(manager, params);
/*     */   }
/*     */ 
/*     */   private String getUserAgent(Context context) {
/*  90 */     String packageVersion = "unknown";
/*     */     try {
/*  92 */       String packageName = context.getPackageName();
/*  93 */       int versionCode = context.getPackageManager().getPackageInfo(packageName, 0).versionCode;
/*  94 */       packageVersion = packageName + "/" + versionCode;
/*     */     }
/*     */     catch (PackageManager.NameNotFoundException e) {
/*     */     }
/*  98 */     return "Parse Android SDK 1.9.1 (" + packageVersion + ") API Level " + Build.VERSION.SDK_INT;
/*     */   }
/*     */ 
/*     */   public ParseHttpResponse execute(HttpUriRequest request)
/*     */     throws IOException
/*     */   {
/* 105 */     HttpResponse response = this.httpClient.execute(request);
/* 106 */     return ParseHttpResponse.createParseApacheHttpResponse(response);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseApacheHttpClient
 * JD-Core Version:    0.6.0
 */