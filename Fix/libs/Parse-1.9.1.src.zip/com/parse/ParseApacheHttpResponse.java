/*    */ package com.parse;
/*    */ 
/*    */ import android.net.http.AndroidHttpClient;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.http.Header;
/*    */ import org.apache.http.HttpResponse;
/*    */ import org.apache.http.StatusLine;
/*    */ 
/*    */ class ParseApacheHttpResponse extends ParseHttpResponse
/*    */ {
/*    */   private HttpResponse response;
/*    */ 
/*    */   public ParseApacheHttpResponse(HttpResponse response)
/*    */   {
/* 15 */     this.response = response;
/*    */   }
/*    */ 
/*    */   public int getStatusCode()
/*    */   {
/* 20 */     return this.response.getStatusLine().getStatusCode();
/*    */   }
/*    */ 
/*    */   public InputStream getContent() throws IOException
/*    */   {
/* 25 */     return AndroidHttpClient.getUngzippedContent(this.response.getEntity());
/*    */   }
/*    */ 
/*    */   public int getTotalSize()
/*    */   {
/* 30 */     int totalSize = -1;
/* 31 */     Header[] contentLengthHeader = this.response.getHeaders("Content-Length");
/*    */ 
/* 34 */     if (contentLengthHeader.length > 0) {
/* 35 */       totalSize = Integer.parseInt(contentLengthHeader[0].getValue());
/*    */     }
/* 37 */     return totalSize;
/*    */   }
/*    */ 
/*    */   public String getReasonPhrase()
/*    */   {
/* 42 */     return this.response.getStatusLine().getReasonPhrase();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseApacheHttpResponse
 * JD-Core Version:    0.6.0
 */