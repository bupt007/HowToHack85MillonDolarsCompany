/*    */ package com.parse;
/*    */ 
/*    */ import bolts.Task;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.apache.http.entity.ByteArrayEntity;
/*    */ 
/*    */ class CountingByteArrayEntity extends ByteArrayEntity
/*    */ {
/*    */   private static final int DEFAULT_CHUNK_SIZE = 4096;
/*    */   private final ParseCallback2<Integer, ParseException> progressCallback;
/*    */ 
/*    */   public CountingByteArrayEntity(byte[] b, ProgressCallback progressCallback)
/*    */   {
/* 18 */     super(b);
/*    */ 
/* 21 */     if (progressCallback != null)
/* 22 */       this.progressCallback = new ParseCallback2(progressCallback) {
/* 23 */         Integer maxProgressSoFar = Integer.valueOf(0);
/*    */ 
/*    */         public void done(Integer percentDone, ParseException e) {
/* 26 */           if (percentDone.intValue() > this.maxProgressSoFar.intValue()) {
/* 27 */             this.maxProgressSoFar = percentDone;
/* 28 */             this.val$progressCallback.done(percentDone);
/*    */           }
/*    */         }
/*    */       };
/* 33 */     else this.progressCallback = null;
/*    */   }
/*    */ 
/*    */   public void writeTo(OutputStream outstream)
/*    */     throws IOException
/*    */   {
/* 39 */     if (outstream == null) {
/* 40 */       throw new IllegalArgumentException("Output stream may not be null");
/*    */     }
/*    */ 
/* 43 */     int position = 0;
/* 44 */     int totalLength = this.content.length;
/* 45 */     while (position < totalLength) {
/* 46 */       int length = totalLength - position;
/* 47 */       length = Math.min(length, 4096);
/*    */ 
/* 49 */       outstream.write(this.content, position, length);
/* 50 */       outstream.flush();
/*    */ 
/* 52 */       position += length;
/*    */ 
/* 54 */       int progress = 100 * position / totalLength;
/* 55 */       reportProgressIfNeeded(progress);
/*    */     }
/*    */   }
/*    */ 
/*    */   private void reportProgressIfNeeded(int progress) {
/* 60 */     Parse.callbackOnMainThreadAsync(Task.forResult(Integer.valueOf(progress)), this.progressCallback);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.CountingByteArrayEntity
 * JD-Core Version:    0.6.0
 */