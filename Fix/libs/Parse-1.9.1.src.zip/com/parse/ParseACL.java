/*     */ package com.parse;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class ParseACL
/*     */ {
/*     */   private static final String PUBLIC_KEY = "*";
/*     */   private static final String UNRESOLVED_KEY = "*unresolved";
/*     */   private static ParseACL defaultACL;
/*     */   private static boolean defaultACLUsesCurrentUser;
/*     */   private static WeakReference<ParseUser> lastCurrentUser;
/*     */   private static ParseACL defaultACLWithCurrentUser;
/*     */   private boolean shared;
/*     */   private ParseUser unresolvedUser;
/*     */   private JSONObject permissionsById;
/*     */ 
/*     */   public static void setDefaultACL(ParseACL acl, boolean withAccessForCurrentUser)
/*     */   {
/*  40 */     defaultACLWithCurrentUser = null;
/*  41 */     lastCurrentUser = null;
/*  42 */     if (acl != null) {
/*  43 */       ParseACL newDefaultACL = acl.copy();
/*  44 */       newDefaultACL.setShared(true);
/*  45 */       defaultACL = newDefaultACL;
/*  46 */       defaultACLUsesCurrentUser = withAccessForCurrentUser;
/*     */     } else {
/*  48 */       defaultACL = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   static ParseACL getDefaultACL() {
/*  53 */     if ((defaultACLUsesCurrentUser) && (defaultACL != null)) {
/*  54 */       ParseUser currentUser = ParseUser.getCurrentUser();
/*  55 */       if (currentUser != null)
/*     */       {
/*  57 */         ParseUser last = lastCurrentUser != null ? (ParseUser)lastCurrentUser.get() : null;
/*  58 */         if (last != currentUser) {
/*  59 */           ParseACL newDefaultACLWithCurrentUser = defaultACL.copy();
/*  60 */           newDefaultACLWithCurrentUser.setShared(true);
/*  61 */           newDefaultACLWithCurrentUser.setReadAccess(currentUser, true);
/*  62 */           newDefaultACLWithCurrentUser.setWriteAccess(currentUser, true);
/*  63 */           defaultACLWithCurrentUser = newDefaultACLWithCurrentUser;
/*  64 */           lastCurrentUser = new WeakReference(currentUser);
/*     */         }
/*  66 */         return defaultACLWithCurrentUser;
/*     */       }
/*     */     }
/*  69 */     return defaultACL;
/*     */   }
/*     */ 
/*     */   public ParseACL()
/*     */   {
/*  80 */     this.permissionsById = new JSONObject();
/*     */   }
/*     */ 
/*     */   ParseACL copy() {
/*  84 */     ParseACL copy = new ParseACL();
/*     */     try {
/*  86 */       copy.permissionsById = new JSONObject(this.permissionsById.toString());
/*     */     } catch (JSONException e) {
/*  88 */       throw new RuntimeException(e);
/*     */     }
/*  90 */     copy.unresolvedUser = this.unresolvedUser;
/*  91 */     if (this.unresolvedUser != null) {
/*  92 */       this.unresolvedUser.registerSaveListener(new UserResolutionListener(copy));
/*     */     }
/*  94 */     return copy;
/*     */   }
/*     */ 
/*     */   boolean isShared() {
/*  98 */     return this.shared;
/*     */   }
/*     */ 
/*     */   void setShared(boolean shared) {
/* 102 */     this.shared = shared;
/*     */   }
/*     */ 
/*     */   JSONObject toJSONObject(ParseObjectEncodingStrategy objectEncoder) {
/*     */     JSONObject json;
/*     */     try {
/* 109 */       json = new JSONObject(this.permissionsById.toString());
/* 110 */       if (this.unresolvedUser != null) {
/* 111 */         Object encoded = Parse.encode(this.unresolvedUser, objectEncoder);
/* 112 */         json.put("unresolvedUser", encoded);
/*     */       }
/*     */     } catch (JSONException e) {
/* 115 */       throw new RuntimeException(e);
/*     */     }
/* 117 */     return json;
/*     */   }
/*     */ 
/*     */   static ParseACL createACLFromJSONObject(JSONObject object, ParseDecoder decoder)
/*     */   {
/* 124 */     ParseACL acl = new ParseACL();
/*     */ 
/* 126 */     for (String key : Parse.keys(object))
/* 127 */       if (key.equals("unresolvedUser")) {
/*     */         JSONObject unresolvedUser;
/*     */         try { unresolvedUser = object.getJSONObject(key);
/*     */         } catch (JSONException e) {
/* 132 */           throw new RuntimeException(e);
/*     */         }
/* 134 */         acl.unresolvedUser = ((ParseUser)decoder.decode(unresolvedUser)); } else { userId = key;
/*     */         JSONObject permissions;
/*     */         try {
/* 139 */           permissions = object.getJSONObject(userId);
/*     */         } catch (JSONException e) {
/* 141 */           throw new RuntimeException("could not decode ACL: " + e.getMessage());
/*     */         }
/* 143 */         for (String accessType : Parse.keys(permissions))
/* 144 */           acl.setAccess(accessType, userId, true);
/*     */       }
/*     */     String userId;
/* 148 */     return acl;
/*     */   }
/*     */ 
/*     */   public ParseACL(ParseUser owner)
/*     */   {
/* 158 */     this();
/* 159 */     setReadAccess(owner, true);
/* 160 */     setWriteAccess(owner, true);
/*     */   }
/*     */ 
/*     */   private void resolveUser(ParseUser user) {
/* 164 */     if (user != this.unresolvedUser)
/* 165 */       return;
/*     */     try
/*     */     {
/* 168 */       if (this.permissionsById.has("*unresolved")) {
/* 169 */         this.permissionsById.put(user.getObjectId(), this.permissionsById.get("*unresolved"));
/* 170 */         this.permissionsById.remove("*unresolved");
/*     */       }
/* 172 */       this.unresolvedUser = null;
/*     */     } catch (JSONException e) {
/* 174 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean hasUnresolvedUser() {
/* 179 */     return this.unresolvedUser != null;
/*     */   }
/*     */ 
/*     */   private void setAccess(String accessType, String userId, boolean allowed)
/*     */   {
/*     */     try {
/* 185 */       JSONObject permissions = this.permissionsById.optJSONObject(userId);
/* 186 */       if (permissions == null) {
/* 187 */         if (!allowed)
/*     */         {
/* 190 */           return;
/*     */         }
/* 192 */         permissions = new JSONObject();
/* 193 */         this.permissionsById.put(userId, permissions);
/*     */       }
/*     */ 
/* 196 */       if (allowed) {
/* 197 */         permissions.put(accessType, true);
/*     */       } else {
/* 199 */         permissions.remove(accessType);
/* 200 */         if (permissions.length() == 0)
/* 201 */           this.permissionsById.remove(userId);
/*     */       }
/*     */     }
/*     */     catch (JSONException e) {
/* 205 */       throw new RuntimeException("JSON failure with ACL: " + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean getAccess(String accessType, String userId)
/*     */   {
/*     */     try {
/* 212 */       JSONObject permissions = this.permissionsById.optJSONObject(userId);
/* 213 */       if (permissions == null) {
/* 214 */         return false;
/*     */       }
/*     */ 
/* 217 */       if (!permissions.has(accessType)) {
/* 218 */         return false;
/*     */       }
/*     */ 
/* 221 */       return permissions.getBoolean(accessType); } catch (JSONException e) {
/*     */     }
/* 223 */     throw new RuntimeException("JSON failure with ACL: " + e.getMessage());
/*     */   }
/*     */ 
/*     */   public void setPublicReadAccess(boolean allowed)
/*     */   {
/* 231 */     setReadAccess("*", allowed);
/*     */   }
/*     */ 
/*     */   public boolean getPublicReadAccess()
/*     */   {
/* 238 */     return getReadAccess("*");
/*     */   }
/*     */ 
/*     */   public void setPublicWriteAccess(boolean allowed)
/*     */   {
/* 245 */     setWriteAccess("*", allowed);
/*     */   }
/*     */ 
/*     */   public boolean getPublicWriteAccess()
/*     */   {
/* 252 */     return getWriteAccess("*");
/*     */   }
/*     */ 
/*     */   public void setReadAccess(String userId, boolean allowed)
/*     */   {
/* 259 */     if (userId == null) {
/* 260 */       throw new IllegalArgumentException("cannot setReadAccess for null userId");
/*     */     }
/* 262 */     setAccess("read", userId, allowed);
/*     */   }
/*     */ 
/*     */   public boolean getReadAccess(String userId)
/*     */   {
/* 271 */     if (userId == null) {
/* 272 */       throw new IllegalArgumentException("cannot getReadAccess for null userId");
/*     */     }
/* 274 */     return getAccess("read", userId);
/*     */   }
/*     */ 
/*     */   public void setWriteAccess(String userId, boolean allowed)
/*     */   {
/* 281 */     if (userId == null) {
/* 282 */       throw new IllegalArgumentException("cannot setWriteAccess for null userId");
/*     */     }
/* 284 */     setAccess("write", userId, allowed);
/*     */   }
/*     */ 
/*     */   public boolean getWriteAccess(String userId)
/*     */   {
/* 293 */     if (userId == null) {
/* 294 */       throw new IllegalArgumentException("cannot getWriteAccess for null userId");
/*     */     }
/* 296 */     return getAccess("write", userId);
/*     */   }
/*     */ 
/*     */   public void setReadAccess(ParseUser user, boolean allowed)
/*     */   {
/* 303 */     if (user.getObjectId() == null) {
/* 304 */       if (user.isLazy()) {
/* 305 */         setUnresolvedReadAccess(user, allowed);
/* 306 */         return;
/*     */       }
/* 308 */       throw new IllegalArgumentException("cannot setReadAccess for a user with null id");
/*     */     }
/* 310 */     setReadAccess(user.getObjectId(), allowed);
/*     */   }
/*     */ 
/*     */   private void setUnresolvedReadAccess(ParseUser user, boolean allowed) {
/* 314 */     prepareUnresolvedUser(user);
/* 315 */     setReadAccess("*unresolved", allowed);
/*     */   }
/*     */ 
/*     */   private void setUnresolvedWriteAccess(ParseUser user, boolean allowed) {
/* 319 */     prepareUnresolvedUser(user);
/* 320 */     setWriteAccess("*unresolved", allowed);
/*     */   }
/*     */ 
/*     */   private void prepareUnresolvedUser(ParseUser user)
/*     */   {
/* 326 */     if (this.unresolvedUser != user) {
/* 327 */       this.permissionsById.remove("*unresolved");
/* 328 */       this.unresolvedUser = user;
/* 329 */       user.registerSaveListener(new UserResolutionListener(this));
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean getReadAccess(ParseUser user)
/*     */   {
/* 339 */     if (user == this.unresolvedUser) {
/* 340 */       return getReadAccess("*unresolved");
/*     */     }
/* 342 */     if (user.isLazy()) {
/* 343 */       return false;
/*     */     }
/* 345 */     if (user.getObjectId() == null) {
/* 346 */       throw new IllegalArgumentException("cannot getReadAccess for a user with null id");
/*     */     }
/* 348 */     return getReadAccess(user.getObjectId());
/*     */   }
/*     */ 
/*     */   public void setWriteAccess(ParseUser user, boolean allowed)
/*     */   {
/* 355 */     if (user.getObjectId() == null) {
/* 356 */       if (user.isLazy()) {
/* 357 */         setUnresolvedWriteAccess(user, allowed);
/* 358 */         return;
/*     */       }
/* 360 */       throw new IllegalArgumentException("cannot setWriteAccess for a user with null id");
/*     */     }
/* 362 */     setWriteAccess(user.getObjectId(), allowed);
/*     */   }
/*     */ 
/*     */   public boolean getWriteAccess(ParseUser user)
/*     */   {
/* 371 */     if (user == this.unresolvedUser) {
/* 372 */       return getWriteAccess("*unresolved");
/*     */     }
/* 374 */     if (user.isLazy()) {
/* 375 */       return false;
/*     */     }
/* 377 */     if (user.getObjectId() == null) {
/* 378 */       throw new IllegalArgumentException("cannot getWriteAccess for a user with null id");
/*     */     }
/* 380 */     return getWriteAccess(user.getObjectId());
/*     */   }
/*     */ 
/*     */   public boolean getRoleReadAccess(String roleName)
/*     */   {
/* 393 */     return getReadAccess("role:" + roleName);
/*     */   }
/*     */ 
/*     */   public void setRoleReadAccess(String roleName, boolean allowed)
/*     */   {
/* 406 */     setReadAccess("role:" + roleName, allowed);
/*     */   }
/*     */ 
/*     */   public boolean getRoleWriteAccess(String roleName)
/*     */   {
/* 419 */     return getWriteAccess("role:" + roleName);
/*     */   }
/*     */ 
/*     */   public void setRoleWriteAccess(String roleName, boolean allowed)
/*     */   {
/* 432 */     setWriteAccess("role:" + roleName, allowed);
/*     */   }
/*     */ 
/*     */   private static void validateRoleState(ParseRole role) {
/* 436 */     if (role.getObjectId() == null)
/* 437 */       throw new IllegalArgumentException("Roles must be saved to the server before they can be used in an ACL.");
/*     */   }
/*     */ 
/*     */   public boolean getRoleReadAccess(ParseRole role)
/*     */   {
/* 453 */     validateRoleState(role);
/* 454 */     return getRoleReadAccess(role.getName());
/*     */   }
/*     */ 
/*     */   public void setRoleReadAccess(ParseRole role, boolean allowed)
/*     */   {
/* 467 */     validateRoleState(role);
/* 468 */     setRoleReadAccess(role.getName(), allowed);
/*     */   }
/*     */ 
/*     */   public boolean getRoleWriteAccess(ParseRole role)
/*     */   {
/* 482 */     validateRoleState(role);
/* 483 */     return getRoleWriteAccess(role.getName());
/*     */   }
/*     */ 
/*     */   public void setRoleWriteAccess(ParseRole role, boolean allowed)
/*     */   {
/* 496 */     validateRoleState(role);
/* 497 */     setRoleWriteAccess(role.getName(), allowed);
/*     */   }
/*     */   private static class UserResolutionListener implements GetCallback<ParseObject> {
/*     */     private final WeakReference<ParseACL> parent;
/*     */ 
/*     */     public UserResolutionListener(ParseACL parent) {
/* 504 */       this.parent = new WeakReference(parent);
/*     */     }
/*     */ 
/*     */     public void done(ParseObject object, ParseException e)
/*     */     {
/*     */       try
/*     */       {
/* 512 */         ParseACL parent = (ParseACL)this.parent.get();
/* 513 */         if (parent != null)
/* 514 */           parent.resolveUser((ParseUser)object);
/*     */       }
/*     */       finally {
/* 517 */         object.unregisterSaveListener(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseACL
 * JD-Core Version:    0.6.0
 */