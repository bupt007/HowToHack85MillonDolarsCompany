/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class ParseConfig
/*     */ {
/*     */   static final String CURRENT_CONFIG_FILENAME = "currentConfig";
/*  25 */   private static final TaskQueue taskQueue = new TaskQueue();
/*     */ 
/*  27 */   private static final Object currentConfigMutex = new Object();
/*     */   private static ParseConfig currentConfig;
/*     */   private final Map<String, Object> params;
/*     */ 
/*     */   public static ParseConfig getCurrentConfig()
/*     */   {
/*  40 */     if (currentConfig == null) {
/*  41 */       synchronized (currentConfigMutex) {
/*  42 */         ParseConfig config = getFromDisk(Parse.applicationContext, "currentConfig");
/*  43 */         currentConfig = config != null ? config : new ParseConfig();
/*     */       }
/*     */     }
/*  46 */     return currentConfig;
/*     */   }
/*     */ 
/*     */   public static ParseConfig get()
/*     */     throws ParseException
/*     */   {
/*  57 */     return (ParseConfig)Parse.waitForTask(getInBackground());
/*     */   }
/*     */ 
/*     */   public static void getInBackground(ConfigCallback callback)
/*     */   {
/*  68 */     Parse.callbackOnMainThreadAsync(getInBackground(), callback);
/*     */   }
/*     */ 
/*     */   public static Task<ParseConfig> getInBackground()
/*     */   {
/*  78 */     return taskQueue.enqueue(new Continuation()
/*     */     {
/*     */       public Task<ParseConfig> then(Task<Void> toAwait) throws Exception {
/*  81 */         return ParseConfig.access$000(toAwait);
/*     */       } } );
/*     */   }
/*     */ 
/*     */   private static Task<ParseConfig> getAsync(Task<Void> toAwait) {
/*  87 */     return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation(toAwait)
/*     */     {
/*     */       public Task<JSONObject> then(Task<String> task) throws Exception {
/*  90 */         String sessionToken = (String)task.getResult();
/*  91 */         ParseRESTCommand command = ParseRESTConfigCommand.fetchConfigCommand(sessionToken);
/*  92 */         command.enableRetrying();
/*     */ 
/*  94 */         return this.val$toAwait.continueWithTask(new Continuation(command)
/*     */         {
/*     */           public Task<JSONObject> then(Task<Void> task) throws Exception {
/*  97 */             return this.val$command.executeAsync().cast();
/*     */           }
/*     */         });
/*     */       }
/*     */     }).onSuccess(new Object()
/*     */     {
/*     */       public ParseConfig then(Task<JSONObject> task)
/*     */         throws Exception
/*     */       {
/* 104 */         JSONObject result = (JSONObject)task.getResult();
/*     */ 
/* 106 */         ParseConfig config = new ParseConfig(result, new ParseDecoder());
/* 107 */         config.saveToDisk(Parse.applicationContext, "currentConfig");
/* 108 */         synchronized (ParseConfig.currentConfigMutex) {
/* 109 */           ParseConfig.access$302(config);
/* 110 */           return ParseConfig.currentConfig;
/*     */         }
/*     */       }
/*     */     }
/*     */     , Task.BACKGROUND_EXECUTOR);
/*     */   }
/*     */ 
/*     */   static void clearCurrentConfigForTesting()
/*     */   {
/* 117 */     synchronized (currentConfigMutex) {
/* 118 */       currentConfig = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static ParseConfig getFromDisk(Context context, String filename)
/*     */   {
/* 133 */     JSONObject object = Parse.getDiskObject(context, filename);
/* 134 */     if (object == null)
/* 135 */       return null;
/*     */     try
/*     */     {
/* 138 */       return new ParseConfig(object, new ParseDecoder()); } catch (JSONException e) {
/*     */     }
/* 140 */     return null;
/*     */   }
/*     */ 
/*     */   ParseConfig(JSONObject object, ParseDecoder decoder) throws JSONException
/*     */   {
/* 145 */     Map decodedObject = (Map)decoder.decode(object);
/* 146 */     Map decodedParams = (Map)decodedObject.get("params");
/* 147 */     if (decodedParams == null) {
/* 148 */       throw new RuntimeException("Object did not contain the 'params' key.");
/*     */     }
/* 150 */     this.params = Collections.unmodifiableMap(decodedParams);
/*     */   }
/*     */ 
/*     */   ParseConfig() {
/* 154 */     this.params = Collections.unmodifiableMap(new HashMap());
/*     */   }
/*     */ 
/*     */   public Object get(String key)
/*     */   {
/* 166 */     return get(key, null);
/*     */   }
/*     */ 
/*     */   public Object get(String key, Object defaultValue)
/*     */   {
/* 180 */     if (!this.params.containsKey(key)) {
/* 181 */       return defaultValue;
/*     */     }
/* 183 */     Object value = this.params.get(key);
/* 184 */     if (value == JSONObject.NULL) {
/* 185 */       return null;
/*     */     }
/* 187 */     return this.params.get(key);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String key)
/*     */   {
/* 198 */     return getBoolean(key, false);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String key, boolean defaultValue)
/*     */   {
/* 211 */     if (!this.params.containsKey(key)) {
/* 212 */       return defaultValue;
/*     */     }
/* 214 */     Object value = this.params.get(key);
/* 215 */     return (value instanceof Boolean) ? ((Boolean)value).booleanValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   public Date getDate(String key)
/*     */   {
/* 226 */     return getDate(key, null);
/*     */   }
/*     */ 
/*     */   public Date getDate(String key, Date defaultValue)
/*     */   {
/* 239 */     if (!this.params.containsKey(key)) {
/* 240 */       return defaultValue;
/*     */     }
/* 242 */     Object value = this.params.get(key);
/* 243 */     if ((value == null) || (value == JSONObject.NULL)) {
/* 244 */       return null;
/*     */     }
/* 246 */     return (value instanceof Date) ? (Date)value : defaultValue;
/*     */   }
/*     */ 
/*     */   public double getDouble(String key)
/*     */   {
/* 257 */     return getDouble(key, 0.0D);
/*     */   }
/*     */ 
/*     */   public double getDouble(String key, double defaultValue)
/*     */   {
/* 270 */     Number number = getNumber(key);
/* 271 */     return number != null ? number.doubleValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   public int getInt(String key)
/*     */   {
/* 282 */     return getInt(key, 0);
/*     */   }
/*     */ 
/*     */   public int getInt(String key, int defaultValue)
/*     */   {
/* 295 */     Number number = getNumber(key);
/* 296 */     return number != null ? number.intValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   public JSONArray getJSONArray(String key)
/*     */   {
/* 307 */     return getJSONArray(key, null);
/*     */   }
/*     */ 
/*     */   public JSONArray getJSONArray(String key, JSONArray defaultValue)
/*     */   {
/* 320 */     List list = getList(key);
/* 321 */     Object encoded = list != null ? Parse.encode(list, PointerEncodingStrategy.get()) : null;
/* 322 */     return (encoded == null) || ((encoded instanceof JSONArray)) ? (JSONArray)encoded : defaultValue;
/*     */   }
/*     */ 
/*     */   public JSONObject getJSONObject(String key)
/*     */   {
/* 334 */     return getJSONObject(key, null);
/*     */   }
/*     */ 
/*     */   public JSONObject getJSONObject(String key, JSONObject defaultValue)
/*     */   {
/* 347 */     Map map = getMap(key);
/* 348 */     Object encoded = map != null ? Parse.encode(map, PointerEncodingStrategy.get()) : null;
/* 349 */     return (encoded == null) || ((encoded instanceof JSONObject)) ? (JSONObject)encoded : defaultValue;
/*     */   }
/*     */ 
/*     */   public <T> List<T> getList(String key)
/*     */   {
/* 361 */     return getList(key, null);
/*     */   }
/*     */ 
/*     */   public <T> List<T> getList(String key, List<T> defaultValue)
/*     */   {
/* 375 */     if (!this.params.containsKey(key)) {
/* 376 */       return defaultValue;
/*     */     }
/* 378 */     Object value = this.params.get(key);
/*     */ 
/* 380 */     if ((value == null) || (value == JSONObject.NULL)) {
/* 381 */       return null;
/*     */     }
/*     */ 
/* 384 */     List returnValue = (value instanceof List) ? (List)value : defaultValue;
/* 385 */     return returnValue;
/*     */   }
/*     */ 
/*     */   public long getLong(String key)
/*     */   {
/* 396 */     return getLong(key, 0L);
/*     */   }
/*     */ 
/*     */   public long getLong(String key, long defaultValue)
/*     */   {
/* 409 */     Number number = getNumber(key);
/* 410 */     return number != null ? number.longValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   public <V> Map<String, V> getMap(String key)
/*     */   {
/* 422 */     return getMap(key, null);
/*     */   }
/*     */ 
/*     */   public <V> Map<String, V> getMap(String key, Map<String, V> defaultValue)
/*     */   {
/* 436 */     if (!this.params.containsKey(key)) {
/* 437 */       return defaultValue;
/*     */     }
/* 439 */     Object value = this.params.get(key);
/*     */ 
/* 441 */     if ((value == null) || (value == JSONObject.NULL)) {
/* 442 */       return null;
/*     */     }
/*     */ 
/* 445 */     Map returnValue = (value instanceof Map) ? (Map)value : defaultValue;
/* 446 */     return returnValue;
/*     */   }
/*     */ 
/*     */   public Number getNumber(String key)
/*     */   {
/* 457 */     return getNumber(key, null);
/*     */   }
/*     */ 
/*     */   public Number getNumber(String key, Number defaultValue)
/*     */   {
/* 470 */     if (!this.params.containsKey(key)) {
/* 471 */       return defaultValue;
/*     */     }
/* 473 */     Object value = this.params.get(key);
/* 474 */     if ((value == null) || (value == JSONObject.NULL)) {
/* 475 */       return null;
/*     */     }
/* 477 */     return (value instanceof Number) ? (Number)value : defaultValue;
/*     */   }
/*     */ 
/*     */   public ParseFile getParseFile(String key)
/*     */   {
/* 490 */     return getParseFile(key, null);
/*     */   }
/*     */ 
/*     */   public ParseFile getParseFile(String key, ParseFile defaultValue)
/*     */   {
/* 506 */     if (!this.params.containsKey(key)) {
/* 507 */       return defaultValue;
/*     */     }
/* 509 */     Object value = this.params.get(key);
/* 510 */     if ((value == null) || (value == JSONObject.NULL)) {
/* 511 */       return null;
/*     */     }
/* 513 */     return (value instanceof ParseFile) ? (ParseFile)value : defaultValue;
/*     */   }
/*     */ 
/*     */   public ParseGeoPoint getParseGeoPoint(String key)
/*     */   {
/* 524 */     return getParseGeoPoint(key, null);
/*     */   }
/*     */ 
/*     */   public ParseGeoPoint getParseGeoPoint(String key, ParseGeoPoint defaultValue)
/*     */   {
/* 537 */     if (!this.params.containsKey(key)) {
/* 538 */       return defaultValue;
/*     */     }
/* 540 */     Object value = this.params.get(key);
/* 541 */     if ((value == null) || (value == JSONObject.NULL)) {
/* 542 */       return null;
/*     */     }
/* 544 */     return (value instanceof ParseGeoPoint) ? (ParseGeoPoint)value : defaultValue;
/*     */   }
/*     */ 
/*     */   public String getString(String key)
/*     */   {
/* 555 */     return getString(key, null);
/*     */   }
/*     */ 
/*     */   public String getString(String key, String defaultValue)
/*     */   {
/* 568 */     if (!this.params.containsKey(key)) {
/* 569 */       return defaultValue;
/*     */     }
/* 571 */     Object value = this.params.get(key);
/* 572 */     if ((value == null) || (value == JSONObject.NULL)) {
/* 573 */       return null;
/*     */     }
/* 575 */     return (value instanceof String) ? (String)value : defaultValue;
/*     */   }
/*     */ 
/*     */   private void saveToDisk(Context context, String filename)
/*     */   {
/* 587 */     JSONObject object = new JSONObject();
/*     */     try {
/* 589 */       JSONObject jsonParams = (JSONObject)Parse.encode(this.params, PointerEncodingStrategy.get());
/* 590 */       object.put("params", jsonParams);
/*     */     } catch (JSONException e) {
/* 592 */       throw new RuntimeException("could not serialize config to JSON");
/*     */     }
/* 594 */     Parse.saveDiskObject(context, filename, object);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 599 */     return "ParseConfig[" + this.params.toString() + "]";
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseConfig
 * JD-Core Version:    0.6.0
 */