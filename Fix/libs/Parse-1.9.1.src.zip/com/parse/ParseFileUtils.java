/*     */ package com.parse;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.channels.FileChannel;
/*     */ 
/*     */ class ParseFileUtils
/*     */ {
/*     */   public static final long ONE_KB = 1024L;
/*     */   public static final long ONE_MB = 1048576L;
/*     */   private static final long FILE_COPY_BUFFER_SIZE = 31457280L;
/*     */ 
/*     */   public static byte[] readFileToByteArray(File file)
/*     */     throws IOException
/*     */   {
/*  44 */     InputStream in = null;
/*     */     try {
/*  46 */       in = openInputStream(file);
/*  47 */       byte[] arrayOfByte = ParseIOUtils.toByteArray(in);
/*     */       return arrayOfByte; } finally { ParseIOUtils.closeQuietly(in); } throw localObject;
/*     */   }
/*     */ 
/*     */   public static FileInputStream openInputStream(File file)
/*     */     throws IOException
/*     */   {
/*  73 */     if (file.exists()) {
/*  74 */       if (file.isDirectory()) {
/*  75 */         throw new IOException("File '" + file + "' exists but is a directory");
/*     */       }
/*  77 */       if (!file.canRead())
/*  78 */         throw new IOException("File '" + file + "' cannot be read");
/*     */     }
/*     */     else {
/*  81 */       throw new FileNotFoundException("File '" + file + "' does not exist");
/*     */     }
/*  83 */     return new FileInputStream(file);
/*     */   }
/*     */ 
/*     */   public static void writeByteArrayToFile(File file, byte[] data)
/*     */     throws IOException
/*     */   {
/*  98 */     OutputStream out = null;
/*     */     try {
/* 100 */       out = openOutputStream(file);
/* 101 */       out.write(data);
/*     */     } finally {
/* 103 */       ParseIOUtils.closeQuietly(out);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static FileOutputStream openOutputStream(File file)
/*     */     throws IOException
/*     */   {
/* 129 */     if (file.exists()) {
/* 130 */       if (file.isDirectory()) {
/* 131 */         throw new IOException("File '" + file + "' exists but is a directory");
/*     */       }
/* 133 */       if (!file.canWrite())
/* 134 */         throw new IOException("File '" + file + "' cannot be written to");
/*     */     }
/*     */     else {
/* 137 */       File parent = file.getParentFile();
/* 138 */       if ((parent != null) && (!parent.exists()) && 
/* 139 */         (!parent.mkdirs())) {
/* 140 */         throw new IOException("File '" + file + "' could not be created");
/*     */       }
/*     */     }
/*     */ 
/* 144 */     return new FileOutputStream(file);
/*     */   }
/*     */ 
/*     */   public static void moveFile(File srcFile, File destFile)
/*     */     throws IOException
/*     */   {
/* 161 */     if (srcFile == null) {
/* 162 */       throw new NullPointerException("Source must not be null");
/*     */     }
/* 164 */     if (destFile == null) {
/* 165 */       throw new NullPointerException("Destination must not be null");
/*     */     }
/* 167 */     if (!srcFile.exists()) {
/* 168 */       throw new FileNotFoundException("Source '" + srcFile + "' does not exist");
/*     */     }
/* 170 */     if (srcFile.isDirectory()) {
/* 171 */       throw new IOException("Source '" + srcFile + "' is a directory");
/*     */     }
/* 173 */     if (destFile.exists()) {
/* 174 */       throw new IOException("Destination '" + destFile + "' already exists");
/*     */     }
/* 176 */     if (destFile.isDirectory()) {
/* 177 */       throw new IOException("Destination '" + destFile + "' is a directory");
/*     */     }
/* 179 */     boolean rename = srcFile.renameTo(destFile);
/* 180 */     if (!rename) {
/* 181 */       copyFile(srcFile, destFile);
/* 182 */       if (!srcFile.delete()) {
/* 183 */         deleteQuietly(destFile);
/* 184 */         throw new IOException("Failed to delete original file '" + srcFile + "' after copy to '" + destFile + "'");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void copyFile(File srcFile, File destFile)
/*     */     throws IOException
/*     */   {
/* 214 */     copyFile(srcFile, destFile, true);
/*     */   }
/*     */ 
/*     */   public static void copyFile(File srcFile, File destFile, boolean preserveFileDate)
/*     */     throws IOException
/*     */   {
/* 245 */     if (srcFile == null) {
/* 246 */       throw new NullPointerException("Source must not be null");
/*     */     }
/* 248 */     if (destFile == null) {
/* 249 */       throw new NullPointerException("Destination must not be null");
/*     */     }
/* 251 */     if (!srcFile.exists()) {
/* 252 */       throw new FileNotFoundException("Source '" + srcFile + "' does not exist");
/*     */     }
/* 254 */     if (srcFile.isDirectory()) {
/* 255 */       throw new IOException("Source '" + srcFile + "' exists but is a directory");
/*     */     }
/* 257 */     if (srcFile.getCanonicalPath().equals(destFile.getCanonicalPath())) {
/* 258 */       throw new IOException("Source '" + srcFile + "' and destination '" + destFile + "' are the same");
/*     */     }
/* 260 */     File parentFile = destFile.getParentFile();
/* 261 */     if ((parentFile != null) && 
/* 262 */       (!parentFile.mkdirs()) && (!parentFile.isDirectory())) {
/* 263 */       throw new IOException("Destination '" + parentFile + "' directory cannot be created");
/*     */     }
/*     */ 
/* 266 */     if ((destFile.exists()) && (!destFile.canWrite())) {
/* 267 */       throw new IOException("Destination '" + destFile + "' exists but is read-only");
/*     */     }
/* 269 */     doCopyFile(srcFile, destFile, preserveFileDate);
/*     */   }
/*     */ 
/*     */   private static void doCopyFile(File srcFile, File destFile, boolean preserveFileDate)
/*     */     throws IOException
/*     */   {
/* 288 */     if ((destFile.exists()) && (destFile.isDirectory())) {
/* 289 */       throw new IOException("Destination '" + destFile + "' exists but is a directory");
/*     */     }
/*     */ 
/* 292 */     FileInputStream fis = null;
/* 293 */     FileOutputStream fos = null;
/* 294 */     FileChannel input = null;
/* 295 */     FileChannel output = null;
/*     */     try {
/* 297 */       fis = new FileInputStream(srcFile);
/* 298 */       fos = new FileOutputStream(destFile);
/* 299 */       input = fis.getChannel();
/* 300 */       output = fos.getChannel();
/* 301 */       long size = input.size();
/* 302 */       long pos = 0L;
/* 303 */       long count = 0L;
/* 304 */       while (pos < size) {
/* 305 */         long remain = size - pos;
/* 306 */         count = remain > 31457280L ? 31457280L : remain;
/* 307 */         long bytesCopied = output.transferFrom(input, pos, count);
/* 308 */         if (bytesCopied == 0L) {
/*     */           break;
/*     */         }
/* 311 */         pos += bytesCopied;
/*     */       }
/*     */     } finally {
/* 314 */       ParseIOUtils.closeQuietly(output);
/* 315 */       ParseIOUtils.closeQuietly(fos);
/* 316 */       ParseIOUtils.closeQuietly(input);
/* 317 */       ParseIOUtils.closeQuietly(fis);
/*     */     }
/*     */ 
/* 320 */     long srcLen = srcFile.length();
/* 321 */     long dstLen = destFile.length();
/* 322 */     if (srcLen != dstLen) {
/* 323 */       throw new IOException("Failed to copy full contents from '" + srcFile + "' to '" + destFile + "' Expected length: " + srcLen + " Actual: " + dstLen);
/*     */     }
/*     */ 
/* 326 */     if (preserveFileDate)
/* 327 */       destFile.setLastModified(srcFile.lastModified());
/*     */   }
/*     */ 
/*     */   public static void deleteDirectory(File directory)
/*     */     throws IOException
/*     */   {
/* 339 */     if (!directory.exists()) {
/* 340 */       return;
/*     */     }
/*     */ 
/* 343 */     if (!isSymlink(directory)) {
/* 344 */       cleanDirectory(directory);
/*     */     }
/*     */ 
/* 347 */     if (!directory.delete()) {
/* 348 */       String message = "Unable to delete directory " + directory + ".";
/*     */ 
/* 350 */       throw new IOException(message);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean deleteQuietly(File file)
/*     */   {
/* 370 */     if (file == null)
/* 371 */       return false;
/*     */     try
/*     */     {
/* 374 */       if (file.isDirectory())
/* 375 */         cleanDirectory(file);
/*     */     }
/*     */     catch (Exception ignored)
/*     */     {
/*     */     }
/*     */     try {
/* 381 */       return file.delete(); } catch (Exception ignored) {
/*     */     }
/* 383 */     return false;
/*     */   }
/*     */ 
/*     */   public static void cleanDirectory(File directory)
/*     */     throws IOException
/*     */   {
/* 394 */     if (!directory.exists()) {
/* 395 */       String message = directory + " does not exist";
/* 396 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */ 
/* 399 */     if (!directory.isDirectory()) {
/* 400 */       String message = directory + " is not a directory";
/* 401 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */ 
/* 404 */     File[] files = directory.listFiles();
/* 405 */     if (files == null) {
/* 406 */       throw new IOException("Failed to list contents of " + directory);
/*     */     }
/*     */ 
/* 409 */     IOException exception = null;
/* 410 */     for (File file : files) {
/*     */       try {
/* 412 */         forceDelete(file);
/*     */       } catch (IOException ioe) {
/* 414 */         exception = ioe;
/*     */       }
/*     */     }
/*     */ 
/* 418 */     if (null != exception)
/* 419 */       throw exception;
/*     */   }
/*     */ 
/*     */   public static void forceDelete(File file)
/*     */     throws IOException
/*     */   {
/* 440 */     if (file.isDirectory()) {
/* 441 */       deleteDirectory(file);
/*     */     } else {
/* 443 */       boolean filePresent = file.exists();
/* 444 */       if (!file.delete()) {
/* 445 */         if (!filePresent) {
/* 446 */           throw new FileNotFoundException("File does not exist: " + file);
/*     */         }
/* 448 */         String message = "Unable to delete file: " + file;
/*     */ 
/* 450 */         throw new IOException(message);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isSymlink(File file)
/*     */     throws IOException
/*     */   {
/* 473 */     if (file == null) {
/* 474 */       throw new NullPointerException("File must not be null");
/*     */     }
/*     */ 
/* 479 */     File fileInCanonicalDir = null;
/* 480 */     if (file.getParent() == null) {
/* 481 */       fileInCanonicalDir = file;
/*     */     } else {
/* 483 */       File canonicalDir = file.getParentFile().getCanonicalFile();
/* 484 */       fileInCanonicalDir = new File(canonicalDir, file.getName());
/*     */     }
/*     */ 
/* 488 */     return !fileInCanonicalDir.getCanonicalFile().equals(fileInCanonicalDir.getAbsoluteFile());
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseFileUtils
 * JD-Core Version:    0.6.0
 */