/*     */ package com.parse;
/*     */ 
/*     */ import android.os.Build.VERSION;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import com.parse.codec.digest.DigestUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.entity.StringEntity;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ import org.json.JSONStringer;
/*     */ 
/*     */ class ParseRESTCommand extends ParseNetworkCommand<JSONObject, Object>
/*     */ {
/*     */   private static final String HEADER_APPLICATION_ID = "X-Parse-Application-Id";
/*     */   private static final String HEADER_CLIENT_KEY = "X-Parse-Client-Key";
/*     */   private static final String HEADER_CLIENT_VERSION = "X-Parse-Client-Version";
/*     */   private static final String HEADER_INSTALLATION_ID = "X-Parse-Installation-Id";
/*     */   private static final String HEADER_APP_BUILD_VERSION = "X-Parse-App-Build-Version";
/*     */   private static final String HEADER_APP_DISPLAY_VERSION = "X-Parse-App-Display-Version";
/*     */   private static final String HEADER_OS_VERSION = "X-Parse-OS-Version";
/*     */   private static final String HEADER_SESSION_TOKEN = "X-Parse-Session-Token";
/*     */   private static final String HEADER_MASTER_KEY = "X-Parse-Master-Key";
/*     */   private static final String PARAMETER_METHOD_OVERRIDE = "_method";
/*     */   protected String httpPath;
/*     */   protected final JSONObject jsonParameters;
/*     */   protected final String sessionToken;
/*     */   private String installationId;
/*     */   private String operationSetUUID;
/*     */   private String localId;
/*     */   public String masterKey;
/*     */ 
/*     */   public ParseRESTCommand(String httpPath, ParseRequest.Method httpMethod, Map<String, ?> parameters, String sessionToken)
/*     */   {
/*  56 */     super(httpMethod, createUrl(httpPath));
/*     */ 
/*  58 */     this.httpPath = httpPath;
/*  59 */     if (parameters != null)
/*  60 */       this.jsonParameters = ((JSONObject)Parse.encode(parameters, NoObjectsEncodingStrategy.get()));
/*     */     else {
/*  62 */       this.jsonParameters = null;
/*     */     }
/*  64 */     this.sessionToken = sessionToken;
/*     */   }
/*     */ 
/*     */   protected ParseRESTCommand(String httpPath, ParseRequest.Method httpMethod, JSONObject jsonParameters, String sessionToken)
/*     */   {
/*  69 */     this(httpPath, httpMethod, jsonParameters, null, sessionToken);
/*     */   }
/*     */ 
/*     */   private ParseRESTCommand(String httpPath, ParseRequest.Method httpMethod, JSONObject jsonParameters, String localId, String sessionToken)
/*     */   {
/*  74 */     super(httpMethod, createUrl(httpPath));
/*     */ 
/*  76 */     this.httpPath = httpPath;
/*  77 */     this.jsonParameters = jsonParameters;
/*  78 */     this.localId = localId;
/*  79 */     this.sessionToken = sessionToken;
/*     */   }
/*     */ 
/*     */   public static ParseRESTCommand fromJSONObject(JSONObject jsonObject) {
/*  83 */     String httpPath = jsonObject.optString("httpPath");
/*  84 */     ParseRequest.Method httpMethod = ParseRequest.Method.fromString(jsonObject.optString("httpMethod"));
/*  85 */     String sessionToken = jsonObject.optString("sessionToken", null);
/*  86 */     String localId = jsonObject.optString("localId", null);
/*  87 */     JSONObject jsonParameters = jsonObject.optJSONObject("parameters");
/*     */ 
/*  89 */     return new ParseRESTCommand(httpPath, httpMethod, jsonParameters, localId, sessionToken);
/*     */   }
/*     */ 
/*     */   void enableRetrying() {
/*  93 */     this.maxRetries = 4;
/*     */   }
/*     */ 
/*     */   private static String createUrl(String httpPath)
/*     */   {
/*  99 */     return String.format("%s/1/%s", new Object[] { ParseObject.server, httpPath });
/*     */   }
/*     */ 
/*     */   private static void addDefaultHeaders(HttpUriRequest request) {
/* 103 */     request.addHeader("X-Parse-Application-Id", Parse.applicationId);
/* 104 */     request.addHeader("X-Parse-Client-Key", Parse.clientKey);
/* 105 */     request.addHeader("X-Parse-Client-Version", "a1.9.1");
/* 106 */     request.addHeader("X-Parse-App-Build-Version", String.valueOf(ManifestInfo.getVersionCode()));
/* 107 */     request.addHeader("X-Parse-App-Display-Version", ManifestInfo.getVersionName());
/* 108 */     request.addHeader("X-Parse-OS-Version", Build.VERSION.RELEASE);
/*     */   }
/*     */ 
/*     */   protected HttpUriRequest newRequest(ParseRequest.Method method, ProgressCallback uploadProgressCallback)
/*     */     throws ParseException
/*     */   {
/*     */     HttpUriRequest request;
/*     */     HttpUriRequest request;
/* 115 */     if ((this.jsonParameters != null) && (method != ParseRequest.Method.POST) && (method != ParseRequest.Method.PUT))
/*     */     {
/* 118 */       request = super.newRequest(ParseRequest.Method.POST, uploadProgressCallback);
/*     */     }
/* 120 */     else request = super.newRequest(method, uploadProgressCallback);
/*     */ 
/* 123 */     addDefaultHeaders(request);
/* 124 */     request.addHeader("X-Parse-Installation-Id", this.installationId);
/* 125 */     if (this.sessionToken != null) {
/* 126 */       request.addHeader("X-Parse-Session-Token", this.sessionToken);
/*     */     }
/* 128 */     if (this.masterKey != null) {
/* 129 */       request.addHeader("X-Parse-Master-Key", this.masterKey);
/*     */     }
/*     */ 
/* 132 */     return request;
/*     */   }
/*     */ 
/*     */   protected HttpEntity newEntity(ProgressCallback uploadProgressCallback)
/*     */   {
/* 137 */     if (this.jsonParameters == null) {
/* 138 */       String message = String.format("Trying to execute a %s command without body parameters.", new Object[] { this.method.toString() });
/*     */ 
/* 140 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */     try
/*     */     {
/* 144 */       JSONObject parameters = this.jsonParameters;
/* 145 */       if ((this.method == ParseRequest.Method.GET) || (this.method == ParseRequest.Method.DELETE))
/*     */       {
/* 150 */         parameters = new JSONObject(this.jsonParameters.toString());
/* 151 */         parameters.put("_method", this.method.toString());
/*     */       }
/* 153 */       StringEntity entity = new StringEntity(parameters.toString(), "UTF8");
/* 154 */       entity.setContentType("application/json");
/* 155 */       return entity; } catch (Exception e) {
/*     */     }
/* 157 */     throw new RuntimeException(e.getMessage());
/*     */   }
/*     */ 
/*     */   protected Task<Void> onPreExecute(Task<Void> task)
/*     */   {
/* 163 */     Parse.checkInit();
/* 164 */     resolveLocalIds();
/* 165 */     return task.onSuccessTask(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<Void> task) throws Exception {
/* 168 */         ParseRESTCommand.access$002(ParseRESTCommand.this, ParseInstallation.getOrCreateCurrentInstallationId());
/* 169 */         return task;
/*     */       }
/*     */     }
/*     */     , Task.BACKGROUND_EXECUTOR);
/*     */   }
/*     */ 
/*     */   protected Task<JSONObject> onResponse(ParseHttpResponse response, ProgressCallback downloadProgressCallback)
/*     */   {
/* 177 */     InputStream responseStream = null;
/* 178 */     String content = null;
/*     */     try {
/* 180 */       responseStream = response.getContent();
/* 181 */       content = new String(ParseIOUtils.toByteArray(responseStream));
/*     */     } catch (IOException e) {
/* 183 */       return Task.forError(e);
/*     */     }
/*     */ 
/* 190 */     int statusCode = response.getStatusCode();
/* 191 */     if ((statusCode >= 200) && (statusCode < 600)) {
/*     */       try
/*     */       {
/* 194 */         JSONObject json = new JSONObject(content);
/*     */ 
/* 196 */         if ((statusCode >= 400) && (statusCode < 500))
/* 197 */           return Task.forError(newPermanentException(json.optInt("code"), json.optString("error")));
/* 198 */         if (statusCode >= 500) {
/* 199 */           return Task.forError(newTemporaryException(json.optInt("code"), json.optString("error")));
/*     */         }
/*     */ 
/* 202 */         return Task.forResult(json);
/*     */       } catch (JSONException e) {
/* 204 */         return Task.forError(newTemporaryException("bad json response", e));
/*     */       }
/*     */     }
/*     */ 
/* 208 */     return Task.forError(newPermanentException(-1, content));
/*     */   }
/*     */ 
/*     */   public String getCacheKey()
/*     */   {
/*     */     String json;
/* 214 */     if (this.jsonParameters != null)
/*     */       try {
/* 216 */         json = toDeterministicString(this.jsonParameters);
/*     */       } catch (JSONException e) {
/* 218 */         throw new RuntimeException(e.getMessage());
/*     */       }
/*     */     else {
/* 221 */       json = "";
/*     */     }
/*     */ 
/* 225 */     if (this.sessionToken != null) {
/* 226 */       json = json + this.sessionToken;
/*     */     }
/*     */ 
/* 229 */     return String.format("ParseRESTCommand.%s.%s.%s", new Object[] { this.method.toString(), DigestUtils.md5Hex(this.httpPath), DigestUtils.md5Hex(json) });
/*     */   }
/*     */ 
/*     */   private static String toDeterministicString(Object o)
/*     */     throws JSONException
/*     */   {
/* 240 */     JSONStringer stringer = new JSONStringer();
/* 241 */     addToStringer(stringer, o);
/* 242 */     return stringer.toString();
/*     */   }
/*     */ 
/*     */   private static void addToStringer(JSONStringer stringer, Object o)
/*     */     throws JSONException
/*     */   {
/* 248 */     if ((o instanceof JSONObject)) {
/* 249 */       stringer.object();
/* 250 */       JSONObject object = (JSONObject)o;
/* 251 */       Iterator keyIterator = object.keys();
/* 252 */       ArrayList keys = new ArrayList();
/* 253 */       while (keyIterator.hasNext()) {
/* 254 */         keys.add(keyIterator.next());
/*     */       }
/* 256 */       Collections.sort(keys);
/*     */ 
/* 258 */       for (String key : keys) {
/* 259 */         stringer.key(key);
/* 260 */         addToStringer(stringer, object.opt(key));
/*     */       }
/*     */ 
/* 263 */       stringer.endObject();
/* 264 */       return;
/*     */     }
/*     */ 
/* 267 */     if ((o instanceof JSONArray)) {
/* 268 */       JSONArray array = (JSONArray)o;
/* 269 */       stringer.array();
/* 270 */       for (int i = 0; i < array.length(); i++) {
/* 271 */         addToStringer(stringer, array.get(i));
/*     */       }
/* 273 */       stringer.endArray();
/* 274 */       return;
/*     */     }
/*     */ 
/* 277 */     stringer.value(o);
/*     */   }
/*     */ 
/*     */   static boolean isValidCommandJSONObject(JSONObject jsonObject) {
/* 281 */     return jsonObject.has("httpPath");
/*     */   }
/*     */ 
/*     */   public JSONObject toJSONObject() {
/* 285 */     JSONObject jsonObject = new JSONObject();
/*     */     try {
/* 287 */       if (this.httpPath != null) {
/* 288 */         jsonObject.put("httpPath", this.httpPath);
/*     */       }
/* 290 */       jsonObject.put("httpMethod", this.method.toString());
/* 291 */       if (this.jsonParameters != null) {
/* 292 */         jsonObject.put("parameters", this.jsonParameters);
/*     */       }
/* 294 */       if (this.sessionToken != null) {
/* 295 */         jsonObject.put("sessionToken", this.sessionToken);
/*     */       }
/* 297 */       if (this.localId != null)
/* 298 */         jsonObject.put("localId", this.localId);
/*     */     }
/*     */     catch (JSONException e) {
/* 301 */       throw new RuntimeException(e.getMessage());
/*     */     }
/* 303 */     return jsonObject;
/*     */   }
/*     */ 
/*     */   public String getSessionToken() {
/* 307 */     return this.sessionToken;
/*     */   }
/*     */ 
/*     */   public String getOperationSetUUID() {
/* 311 */     return this.operationSetUUID;
/*     */   }
/*     */ 
/*     */   void setOperationSetUUID(String operationSetUUID) {
/* 315 */     this.operationSetUUID = operationSetUUID;
/*     */   }
/*     */ 
/*     */   public void setLocalId(String localId) {
/* 319 */     this.localId = localId;
/*     */   }
/*     */ 
/*     */   public String getLocalId() {
/* 323 */     return this.localId;
/*     */   }
/*     */ 
/*     */   private void maybeChangeServerOperation()
/*     */     throws JSONException
/*     */   {
/* 335 */     if (this.localId != null) {
/* 336 */       String objectId = LocalIdManager.getDefaultInstance().getObjectId(this.localId);
/* 337 */       if (objectId != null) {
/* 338 */         this.localId = null;
/* 339 */         this.httpPath += String.format("/%s", new Object[] { objectId });
/* 340 */         this.url = createUrl(this.httpPath);
/*     */ 
/* 342 */         if ((this.httpPath.startsWith("classes")) && (this.method == ParseRequest.Method.POST))
/* 343 */           this.method = ParseRequest.Method.PUT;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resolveLocalIds()
/*     */   {
/*     */     try {
/* 351 */       ArrayList localPointers = new ArrayList();
/* 352 */       getLocalPointersIn(this.jsonParameters, localPointers);
/* 353 */       for (JSONObject pointer : localPointers) {
/* 354 */         String localId = (String)pointer.get("localId");
/* 355 */         String objectId = LocalIdManager.getDefaultInstance().getObjectId(localId);
/* 356 */         if (objectId == null) {
/* 357 */           throw new IllegalStateException("Tried to serialize a command referencing a new, unsaved object.");
/*     */         }
/*     */ 
/* 360 */         pointer.put("objectId", objectId);
/* 361 */         pointer.remove("localId");
/*     */       }
/* 363 */       maybeChangeServerOperation();
/*     */     }
/*     */     catch (JSONException e) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void retainLocalIds() {
/* 370 */     if (this.localId != null) {
/* 371 */       LocalIdManager.getDefaultInstance().retainLocalIdOnDisk(this.localId);
/*     */     }
/*     */     try
/*     */     {
/* 375 */       ArrayList localPointers = new ArrayList();
/* 376 */       getLocalPointersIn(this.jsonParameters, localPointers);
/* 377 */       for (JSONObject pointer : localPointers) {
/* 378 */         String localId = (String)pointer.get("localId");
/* 379 */         LocalIdManager.getDefaultInstance().retainLocalIdOnDisk(localId);
/*     */       }
/*     */     }
/*     */     catch (JSONException e) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void releaseLocalIds() {
/* 387 */     if (this.localId != null)
/* 388 */       LocalIdManager.getDefaultInstance().releaseLocalIdOnDisk(this.localId);
/*     */     try
/*     */     {
/* 391 */       ArrayList localPointers = new ArrayList();
/* 392 */       getLocalPointersIn(this.jsonParameters, localPointers);
/* 393 */       for (JSONObject pointer : localPointers) {
/* 394 */         String localId = (String)pointer.get("localId");
/* 395 */         LocalIdManager.getDefaultInstance().releaseLocalIdOnDisk(localId);
/*     */       }
/*     */     }
/*     */     catch (JSONException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTCommand
 * JD-Core Version:    0.6.0
 */