package com.parse;

public abstract interface LocationCallback extends ParseCallback2<ParseGeoPoint, ParseException>
{
  public abstract void done(ParseGeoPoint paramParseGeoPoint, ParseException paramParseException);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.LocationCallback
 * JD-Core Version:    0.6.0
 */