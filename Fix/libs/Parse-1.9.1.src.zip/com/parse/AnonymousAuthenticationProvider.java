/*    */ package com.parse;
/*    */ 
/*    */ import bolts.Task;
/*    */ import java.util.UUID;
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class AnonymousAuthenticationProvider extends ParseAuthenticationProvider
/*    */ {
/*    */   public Task<JSONObject> authenticateAsync()
/*    */   {
/*    */     try
/*    */     {
/* 19 */       return Task.forResult(getAuthData()); } catch (JSONException e) {
/*    */     }
/* 21 */     return Task.forError(e);
/*    */   }
/*    */ 
/*    */   public JSONObject getAuthData() throws JSONException
/*    */   {
/* 26 */     JSONObject authData = new JSONObject();
/* 27 */     authData.put("id", UUID.randomUUID().toString());
/* 28 */     return authData;
/*    */   }
/*    */ 
/*    */   public void deauthenticate()
/*    */   {
/*    */   }
/*    */ 
/*    */   public boolean restoreAuthentication(JSONObject authData)
/*    */   {
/* 38 */     return true;
/*    */   }
/*    */ 
/*    */   public void cancel()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getAuthType()
/*    */   {
/* 48 */     return "anonymous";
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.AnonymousAuthenticationProvider
 * JD-Core Version:    0.6.0
 */