/*    */ package com.parse;
/*    */ 
/*    */ import android.app.Activity;
/*    */ import android.app.TaskStackBuilder;
/*    */ import android.content.Context;
/*    */ import android.content.Intent;
/*    */ 
/*    */ class TaskStackBuilderHelper
/*    */ {
/*    */   public static void startActivities(Context context, Class<? extends Activity> cls, Intent activityIntent)
/*    */   {
/* 16 */     TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
/* 17 */     stackBuilder.addParentStack(cls);
/* 18 */     stackBuilder.addNextIntent(activityIntent);
/* 19 */     stackBuilder.startActivities();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.TaskStackBuilderHelper
 * JD-Core Version:    0.6.0
 */