/*     */ package com.parse;
/*     */ 
/*     */ import android.app.Activity;
/*     */ import android.app.Service;
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import android.content.pm.ApplicationInfo;
/*     */ import android.os.IBinder;
/*     */ import bolts.Capture;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ 
/*     */ public final class PushService extends Service
/*     */ {
/*     */   private static final String TAG = "com.parse.PushService";
/*     */   private static final String START_IF_REQUIRED_ACTION = "com.parse.PushService.startIfRequired";
/*     */   private static final int WAKE_LOCK_TIMEOUT_MS = 20000;
/* 119 */   private static String host = "push.parse.com";
/* 120 */   private static int port = 443;
/* 121 */   private static boolean loggedStartError = false;
/*     */ 
/* 125 */   private static List<ServiceLifecycleCallbacks> serviceLifecycleCallbacks = null;
/*     */   static final String CANNOT_USE_PUSH_V1_ERROR_MESSAGE = "PushService.subscribe, PushService.unsubscribe, and PushService.setDefaultPushCallback methods cannot be used in conjunction with ParsePushBroadcastReceiver. See ParsePush.subscribe and ParsePush.unsubscribe.";
/*     */   private PushConnection connection;
/*     */   private ExecutorService executor;
/*     */ 
/*     */   static void registerServiceLifecycleCallbacks(ServiceLifecycleCallbacks callbacks)
/*     */   {
/* 133 */     synchronized (PushService.class) {
/* 134 */       if (serviceLifecycleCallbacks == null) {
/* 135 */         serviceLifecycleCallbacks = new ArrayList();
/*     */       }
/* 137 */       serviceLifecycleCallbacks.add(callbacks);
/*     */     }
/*     */   }
/*     */ 
/*     */   static void unregisterServiceLifecycleCallbacks(ServiceLifecycleCallbacks callbacks)
/*     */   {
/* 143 */     synchronized (PushService.class) {
/* 144 */       serviceLifecycleCallbacks.remove(callbacks);
/* 145 */       if (serviceLifecycleCallbacks.size() <= 0)
/* 146 */         serviceLifecycleCallbacks = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void dispatchOnServiceCreated(Service service)
/*     */   {
/* 152 */     Object[] callbacks = collectServiceLifecycleCallbacks();
/* 153 */     if (callbacks != null)
/* 154 */       for (Object callback : callbacks)
/* 155 */         ((ServiceLifecycleCallbacks)callback).onServiceCreated(service);
/*     */   }
/*     */ 
/*     */   private static void dispatchOnServiceDestroyed(Service service)
/*     */   {
/* 161 */     Object[] callbacks = collectServiceLifecycleCallbacks();
/* 162 */     if (callbacks != null)
/* 163 */       for (Object callback : callbacks)
/* 164 */         ((ServiceLifecycleCallbacks)callback).onServiceDestroyed(service);
/*     */   }
/*     */ 
/*     */   private static Object[] collectServiceLifecycleCallbacks()
/*     */   {
/* 170 */     Object[] callbacks = null;
/* 171 */     synchronized (PushService.class) {
/* 172 */       if (serviceLifecycleCallbacks == null) {
/* 173 */         return null;
/*     */       }
/* 175 */       if (serviceLifecycleCallbacks.size() > 0) {
/* 176 */         callbacks = serviceLifecycleCallbacks.toArray();
/*     */       }
/*     */     }
/* 179 */     return callbacks;
/*     */   }
/*     */ 
/*     */   static void runGcmIntentInService(Context context, Intent intent)
/*     */   {
/* 192 */     ServiceUtils.runWakefulIntentInService(context, intent, PushService.class, 20000L);
/*     */   }
/*     */ 
/*     */   static void stopPpnsService(Context context) {
/* 196 */     if (ManifestInfo.getPushType() == PushType.PPNS)
/* 197 */       context.stopService(new Intent(context, PushService.class));
/*     */   }
/*     */ 
/*     */   private static void startPpnsServiceIfRequired(Context context)
/*     */   {
/* 202 */     if (ManifestInfo.getPushType() == PushType.PPNS) {
/* 203 */       ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/*     */ 
/* 207 */       if (installation.getPushType() == PushType.GCM) {
/* 208 */         Parse.logW("com.parse.PushService", "Detected a client that used to use GCM and is now using PPNS.");
/*     */ 
/* 210 */         installation.removePushType();
/* 211 */         installation.removeDeviceToken();
/* 212 */         installation.saveEventually();
/*     */       }
/*     */ 
/* 215 */       ServiceUtils.runIntentInService(context, new Intent("com.parse.PushService.startIfRequired"), PushService.class);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void startServiceIfRequired(Context context)
/*     */   {
/* 222 */     switch (8.$SwitchMap$com$parse$PushType[ManifestInfo.getPushType().ordinal()]) {
/*     */     case 1:
/* 224 */       startPpnsServiceIfRequired(context);
/* 225 */       break;
/*     */     case 2:
/* 227 */       GcmRegistrar.getInstance().register();
/* 228 */       break;
/*     */     default:
/* 230 */       if (loggedStartError) break;
/* 231 */       Parse.logE("com.parse.PushService", "Tried to use push, but this app is not configured for push due to: " + ManifestInfo.getNonePushTypeLogMessage());
/*     */ 
/* 233 */       loggedStartError = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void subscribe(Context context, String channel, Class<? extends Activity> cls)
/*     */   {
/* 262 */     subscribe(context, channel, cls, context.getApplicationInfo().icon);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static synchronized void subscribe(Context context, String channel, Class<? extends Activity> cls, int icon)
/*     */   {
/* 297 */     checkManifestAndThrowExceptionIfNeeded();
/* 298 */     if (channel == null) {
/* 299 */       throw new IllegalArgumentException("Can't subscribe to null channel.");
/*     */     }
/*     */ 
/* 302 */     PushRouter.subscribeAsync(channel, cls, icon).onSuccess(new Continuation()
/*     */     {
/*     */       public Void then(Task<Void> task) {
/* 305 */         PushService.startServiceIfRequired(Parse.applicationContext);
/* 306 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static synchronized void unsubscribe(Context context, String channel)
/*     */   {
/* 326 */     if (channel == null) {
/* 327 */       throw new IllegalArgumentException("Can't unsubscribe from null channel.");
/*     */     }
/*     */ 
/* 330 */     unsubscribeInternal(channel);
/*     */   }
/*     */ 
/*     */   private static void unsubscribeInternal(String channel) {
/* 334 */     checkManifestAndThrowExceptionIfNeeded();
/* 335 */     PushRouter.unsubscribeAsync(channel).onSuccessTask(new Continuation()
/*     */     {
/*     */       public Task<Set<String>> then(Task<Void> task) {
/* 338 */         return PushRouter.getSubscriptionsAsync(true);
/*     */       }
/*     */     }).onSuccess(new Continuation()
/*     */     {
/*     */       public Void then(Task<Set<String>> task)
/*     */       {
/* 343 */         if (((Set)task.getResult()).size() == 0) {
/* 344 */           PushService.stopPpnsService(Parse.applicationContext);
/*     */         }
/* 346 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void setDefaultPushCallback(Context context, Class<? extends Activity> cls)
/*     */   {
/* 369 */     setDefaultPushCallback(context, cls, context.getApplicationInfo().icon);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void setDefaultPushCallback(Context context, Class<? extends Activity> cls, int icon)
/*     */   {
/* 394 */     if (icon == 0) {
/* 395 */       throw new IllegalArgumentException("Must subscribe to channel with a valid icon identifier.");
/*     */     }
/*     */ 
/* 398 */     if (cls == null)
/* 399 */       unsubscribeInternal(null);
/*     */     else
/* 401 */       PushRouter.subscribeAsync(null, cls, icon).onSuccess(new Continuation()
/*     */       {
/*     */         public Void then(Task<Void> task) {
/* 404 */           PushService.startServiceIfRequired(Parse.applicationContext);
/* 405 */           return null;
/*     */         }
/*     */       });
/*     */   }
/*     */ 
/*     */   private static void checkManifestAndThrowExceptionIfNeeded()
/*     */   {
/* 416 */     if (ManifestInfo.getPushUsesBroadcastReceivers())
/* 417 */       throw new IllegalStateException("PushService.subscribe, PushService.unsubscribe, and PushService.setDefaultPushCallback methods cannot be used in conjunction with ParsePushBroadcastReceiver. See ParsePush.subscribe and ParsePush.unsubscribe.");
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static Set<String> getSubscriptions(Context context)
/*     */   {
/*     */     try
/*     */     {
/* 437 */       return (Set)Parse.waitForTask(PushRouter.getSubscriptionsAsync(false)); } catch (ParseException e) {
/*     */     }
/* 439 */     throw new RuntimeException(e);
/*     */   }
/*     */ 
/*     */   static void useServer(String theHost, int thePort)
/*     */   {
/* 444 */     host = theHost;
/* 445 */     port = thePort;
/*     */   }
/*     */ 
/*     */   public void onCreate()
/*     */   {
/* 456 */     super.onCreate();
/* 457 */     if (Parse.applicationContext == null) {
/* 458 */       Parse.logE("com.parse.PushService", "The Parse push service cannot start because Parse.initialize has not yet been called. If you call Parse.initialize from an Activity's onCreate, that call should instead be in the Application.onCreate. Be sure your Application class is registered in your AndroidManifest.xml with the android:name property of your <application> tag.");
/*     */ 
/* 464 */       stopSelf();
/* 465 */       return;
/*     */     }
/*     */ 
/* 468 */     switch (8.$SwitchMap$com$parse$PushType[ManifestInfo.getPushType().ordinal()]) {
/*     */     case 1:
/* 470 */       this.connection = new PushConnection(this, host, port);
/* 471 */       break;
/*     */     case 2:
/* 473 */       this.executor = Executors.newSingleThreadExecutor();
/* 474 */       break;
/*     */     default:
/* 476 */       Parse.logE("com.parse.PushService", "PushService somehow started even though this device doesn't support push.");
/*     */     }
/*     */ 
/* 480 */     dispatchOnServiceCreated(this);
/*     */   }
/*     */ 
/*     */   public int onStartCommand(Intent intent, int flags, int startId)
/*     */   {
/* 485 */     wipeRoutingAndUpgradePushStateIfNeeded();
/* 486 */     switch (8.$SwitchMap$com$parse$PushType[ManifestInfo.getPushType().ordinal()]) {
/*     */     case 1:
/* 488 */       return onPpnsStartCommand(intent, flags, startId);
/*     */     case 2:
/* 490 */       return onGcmStartCommand(intent, flags, startId);
/*     */     }
/* 492 */     Parse.logE("com.parse.PushService", "Started push service even though no push service is enabled: " + intent);
/* 493 */     ServiceUtils.completeWakefulIntent(intent);
/* 494 */     return 2;
/*     */   }
/*     */ 
/*     */   private void wipeRoutingAndUpgradePushStateIfNeeded()
/*     */   {
/* 504 */     if (ManifestInfo.getPushUsesBroadcastReceivers())
/* 505 */       PushRouter.wipeRoutingAndUpgradePushStateAsync();
/*     */   }
/*     */ 
/*     */   private int onPpnsStartCommand(Intent intent, int flags, int startId)
/*     */   {
/* 510 */     PushConnection conn = this.connection;
/*     */ 
/* 512 */     if ((intent == null) || (intent.getAction() == null) || (intent.getAction().equals("com.parse.PushService.startIfRequired"))) {
/* 513 */       Parse.logI("com.parse.PushService", "Received request to start service if required");
/* 514 */       Capture forceEnabledCapture = new Capture();
/* 515 */       PushRouter.getForceEnabledStateAsync().onSuccessTask(new Continuation(forceEnabledCapture)
/*     */       {
/*     */         public Task<Set<String>> then(Task<Boolean> task) throws Exception {
/* 518 */           this.val$forceEnabledCapture.set(task.getResult());
/* 519 */           return PushRouter.getSubscriptionsAsync(true);
/*     */         }
/*     */       }).onSuccess(new Continuation(forceEnabledCapture, conn)
/*     */       {
/*     */         public Void then(Task<Set<String>> task)
/*     */           throws Exception
/*     */         {
/* 524 */           Boolean forceEnabled = (Boolean)this.val$forceEnabledCapture.get();
/* 525 */           boolean isPushV2 = ManifestInfo.getPushUsesBroadcastReceivers();
/* 526 */           Set subscriptions = (Set)task.getResult();
/*     */ 
/* 528 */           String error = null;
/*     */ 
/* 531 */           if (!isPushV2) {
/* 532 */             if ((subscriptions != null) && (subscriptions.size() == 0)) {
/* 533 */               error = "Not starting PushService because this device has no subscriptions";
/*     */             }
/*     */ 
/*     */           }
/* 539 */           else if (ParseInstallation.getCurrentInstallation().getObjectId() == null) {
/* 540 */             error = "Not starting PushService because this device is not registered for push notifications.";
/*     */           }
/* 542 */           else if ((forceEnabled != null) && (!forceEnabled.booleanValue())) {
/* 543 */             error = "Not starting PushService because push has been manually disabled.";
/*     */           }
/*     */ 
/* 547 */           if (error != null) {
/* 548 */             Parse.logI("com.parse.PushService", error);
/* 549 */             PushService.this.stopSelf();
/*     */           } else {
/* 551 */             Parse.logD("com.parse.PushService", "Starting PushService.");
/* 552 */             this.val$conn.start();
/*     */           }
/* 554 */           return null;
/*     */         } } );
/*     */     }
/* 558 */     return 1;
/*     */   }
/*     */ 
/*     */   private int onGcmStartCommand(Intent intent, int flags, int startId) {
/* 562 */     this.executor.execute(new Runnable(intent, startId)
/*     */     {
/*     */       public void run() {
/*     */         try {
/* 566 */           PushService.this.onHandleGcmIntent(this.val$intent);
/*     */         } finally {
/* 568 */           ServiceUtils.completeWakefulIntent(this.val$intent);
/* 569 */           PushService.this.stopSelf(this.val$startId);
/*     */         }
/*     */       }
/*     */     });
/* 574 */     return 2;
/*     */   }
/*     */ 
/*     */   private void onHandleGcmIntent(Intent intent) {
/* 578 */     if (intent != null) {
/* 579 */       GcmRegistrar registrar = GcmRegistrar.getInstance();
/* 580 */       if (registrar.isRegistrationIntent(intent))
/* 581 */         registrar.handleRegistrationIntent(intent);
/* 582 */       else if (PushRouter.isGcmPushIntent(intent))
/* 583 */         PushRouter.handleGcmPushIntent(intent);
/*     */       else
/* 585 */         Parse.logE("com.parse.PushService", "PushService got unknown intent in GCM mode: " + intent);
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBinder onBind(Intent intent)
/*     */   {
/* 595 */     throw new IllegalArgumentException("You cannot bind directly to the PushService. Use PushService.subscribe instead.");
/*     */   }
/*     */ 
/*     */   public void onDestroy()
/*     */   {
/* 604 */     if (this.connection != null) {
/* 605 */       this.connection.stop();
/*     */     }
/*     */ 
/* 608 */     if (this.executor != null) {
/* 609 */       this.executor.shutdown();
/*     */     }
/*     */ 
/* 612 */     dispatchOnServiceDestroyed(this);
/*     */ 
/* 614 */     super.onDestroy();
/*     */   }
/*     */ 
/*     */   static abstract interface ServiceLifecycleCallbacks
/*     */   {
/*     */     public abstract void onServiceCreated(Service paramService);
/*     */ 
/*     */     public abstract void onServiceDestroyed(Service paramService);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.PushService
 * JD-Core Version:    0.6.0
 */