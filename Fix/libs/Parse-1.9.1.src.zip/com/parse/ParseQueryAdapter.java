/*     */ package com.parse;
/*     */ 
/*     */ import android.annotation.SuppressLint;
/*     */ import android.content.Context;
/*     */ import android.database.DataSetObserver;
/*     */ import android.graphics.drawable.Drawable;
/*     */ import android.view.View;
/*     */ import android.view.View.OnClickListener;
/*     */ import android.view.ViewGroup;
/*     */ import android.widget.BaseAdapter;
/*     */ import android.widget.LinearLayout;
/*     */ import android.widget.LinearLayout.LayoutParams;
/*     */ import android.widget.TextView;
/*     */ import bolts.Capture;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ public class ParseQueryAdapter<T extends ParseObject> extends BaseAdapter
/*     */ {
/*     */   private String textKey;
/*     */   private String imageKey;
/*  99 */   private int objectsPerPage = 25;
/*     */ 
/* 103 */   private boolean paginationEnabled = true;
/*     */   private Drawable placeholder;
/* 111 */   private WeakHashMap<ParseImageView, Void> imageViewSet = new WeakHashMap();
/*     */ 
/* 114 */   private WeakHashMap<DataSetObserver, Void> dataSetObservers = new WeakHashMap();
/*     */ 
/* 118 */   private boolean autoload = true;
/*     */   private Context context;
/* 122 */   private List<T> objects = new ArrayList();
/*     */ 
/* 126 */   private List<List<T>> objectPages = new ArrayList();
/*     */ 
/* 128 */   private int currentPage = 0;
/*     */   private Integer itemResourceId;
/* 132 */   private boolean hasNextPage = true;
/*     */   private QueryFactory<T> queryFactory;
/* 136 */   private List<OnQueryLoadListener<T>> onQueryLoadListeners = new ArrayList();
/*     */   private static final int VIEW_TYPE_ITEM = 0;
/*     */   private static final int VIEW_TYPE_NEXT_PAGE = 1;
/*     */ 
/*     */   public ParseQueryAdapter(Context context, Class<? extends ParseObject> clazz)
/*     */   {
/* 152 */     this(context, ParseObject.getClassName(clazz));
/*     */   }
/*     */ 
/*     */   public ParseQueryAdapter(Context context, String className)
/*     */   {
/* 165 */     this(context, new QueryFactory()
/*     */     {
/*     */       public ParseQuery<T> create() {
/* 168 */         ParseQuery query = ParseQuery.getQuery(ParseQueryAdapter.this);
/* 169 */         query.orderByDescending("createdAt");
/*     */ 
/* 171 */         return query;
/*     */       }
/*     */     });
/* 175 */     if (className == null)
/* 176 */       throw new RuntimeException("You need to specify a className for the ParseQueryAdapter");
/*     */   }
/*     */ 
/*     */   public ParseQueryAdapter(Context context, Class<? extends ParseObject> clazz, int itemViewResource)
/*     */   {
/* 193 */     this(context, ParseObject.getClassName(clazz), itemViewResource);
/*     */   }
/*     */ 
/*     */   public ParseQueryAdapter(Context context, String className, int itemViewResource)
/*     */   {
/* 208 */     this(context, new QueryFactory()
/*     */     {
/*     */       public ParseQuery<T> create() {
/* 211 */         ParseQuery query = ParseQuery.getQuery(ParseQueryAdapter.this);
/* 212 */         query.orderByDescending("createdAt");
/*     */ 
/* 214 */         return query;
/*     */       }
/*     */     }
/*     */     , itemViewResource);
/*     */ 
/* 218 */     if (className == null)
/* 219 */       throw new RuntimeException("You need to specify a className for the ParseQueryAdapter");
/*     */   }
/*     */ 
/*     */   public ParseQueryAdapter(Context context, QueryFactory<T> queryFactory)
/*     */   {
/* 232 */     this(context, queryFactory, null);
/*     */   }
/*     */ 
/*     */   public ParseQueryAdapter(Context context, QueryFactory<T> queryFactory, int itemViewResource)
/*     */   {
/* 247 */     this(context, queryFactory, Integer.valueOf(itemViewResource));
/*     */   }
/*     */ 
/*     */   private ParseQueryAdapter(Context context, QueryFactory<T> queryFactory, Integer itemViewResource)
/*     */   {
/* 252 */     this.context = context;
/* 253 */     this.queryFactory = queryFactory;
/* 254 */     this.itemResourceId = itemViewResource;
/*     */   }
/*     */ 
/*     */   public Context getContext()
/*     */   {
/* 263 */     return this.context;
/*     */   }
/*     */ 
/*     */   public T getItem(int index)
/*     */   {
/* 269 */     if (index == getPaginationCellRow()) {
/* 270 */       return null;
/*     */     }
/* 272 */     return (ParseObject)this.objects.get(index);
/*     */   }
/*     */ 
/*     */   public long getItemId(int position)
/*     */   {
/* 278 */     return position;
/*     */   }
/*     */ 
/*     */   public int getItemViewType(int position)
/*     */   {
/* 283 */     if (position == getPaginationCellRow()) {
/* 284 */       return 1;
/*     */     }
/* 286 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getViewTypeCount()
/*     */   {
/* 291 */     return 2;
/*     */   }
/*     */ 
/*     */   public void registerDataSetObserver(DataSetObserver observer)
/*     */   {
/* 296 */     super.registerDataSetObserver(observer);
/* 297 */     this.dataSetObservers.put(observer, null);
/* 298 */     if (this.autoload)
/* 299 */       loadObjects();
/*     */   }
/*     */ 
/*     */   public void unregisterDataSetObserver(DataSetObserver observer)
/*     */   {
/* 305 */     super.unregisterDataSetObserver(observer);
/* 306 */     this.dataSetObservers.remove(observer);
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 313 */     this.objectPages.clear();
/* 314 */     syncObjectsWithPages();
/* 315 */     notifyDataSetChanged();
/* 316 */     this.currentPage = 0;
/*     */   }
/*     */ 
/*     */   public void loadObjects()
/*     */   {
/* 327 */     loadObjects(0, true);
/*     */   }
/*     */ 
/*     */   private void loadObjects(int page, boolean shouldClear) {
/* 331 */     ParseQuery query = this.queryFactory.create();
/*     */ 
/* 333 */     if ((this.objectsPerPage > 0) && (this.paginationEnabled)) {
/* 334 */       setPageOnQuery(page, query);
/*     */     }
/*     */ 
/* 337 */     notifyOnLoadingListeners();
/*     */ 
/* 340 */     if (page >= this.objectPages.size()) {
/* 341 */       this.objectPages.add(page, new ArrayList());
/*     */     }
/*     */ 
/* 345 */     Capture firstCallBack = new Capture(Boolean.valueOf(true));
/*     */ 
/* 347 */     query.findInBackground(new FindCallback(query, shouldClear, firstCallBack, page) {
/*     */       @SuppressLint({"ShowToast"})
/*     */       public void done(List<T> foundObjects, ParseException e) {
/* 351 */         if ((!OfflineStore.isEnabled()) && (this.val$query.getCachePolicy() == ParseQuery.CachePolicy.CACHE_ONLY) && (e != null) && (e.getCode() == 120))
/*     */         {
/* 354 */           return;
/*     */         }
/*     */ 
/* 357 */         if ((e != null) && ((e.getCode() == 100) || (e.getCode() != 120)))
/*     */         {
/* 359 */           ParseQueryAdapter.access$002(ParseQueryAdapter.this, true);
/* 360 */         } else if (foundObjects != null) {
/* 361 */           if ((this.val$shouldClear) && (((Boolean)this.val$firstCallBack.get()).booleanValue())) {
/* 362 */             ParseQueryAdapter.this.objectPages.clear();
/* 363 */             ParseQueryAdapter.this.objectPages.add(new ArrayList());
/* 364 */             ParseQueryAdapter.access$202(ParseQueryAdapter.this, this.val$page);
/* 365 */             this.val$firstCallBack.set(Boolean.valueOf(false));
/*     */           }
/*     */ 
/* 370 */           if (this.val$page >= ParseQueryAdapter.this.currentPage) {
/* 371 */             ParseQueryAdapter.access$202(ParseQueryAdapter.this, this.val$page);
/*     */ 
/* 374 */             ParseQueryAdapter.access$002(ParseQueryAdapter.this, foundObjects.size() > ParseQueryAdapter.this.objectsPerPage);
/*     */           }
/*     */ 
/* 377 */           if ((ParseQueryAdapter.this.paginationEnabled) && (foundObjects.size() > ParseQueryAdapter.this.objectsPerPage))
/*     */           {
/* 379 */             foundObjects.remove(ParseQueryAdapter.this.objectsPerPage);
/*     */           }
/*     */ 
/* 382 */           List currentPage = (List)ParseQueryAdapter.this.objectPages.get(this.val$page);
/* 383 */           currentPage.clear();
/* 384 */           currentPage.addAll(foundObjects);
/*     */ 
/* 386 */           ParseQueryAdapter.this.syncObjectsWithPages();
/*     */ 
/* 389 */           ParseQueryAdapter.this.notifyDataSetChanged();
/*     */         }
/*     */ 
/* 392 */         ParseQueryAdapter.this.notifyOnLoadedListeners(foundObjects, e);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private void syncObjectsWithPages()
/*     */   {
/* 402 */     this.objects.clear();
/* 403 */     for (List pageOfObjects : this.objectPages)
/* 404 */       this.objects.addAll(pageOfObjects);
/*     */   }
/*     */ 
/*     */   public void loadNextPage()
/*     */   {
/* 413 */     loadObjects(this.currentPage + 1, false);
/*     */   }
/*     */ 
/*     */   public int getCount()
/*     */   {
/* 425 */     int count = this.objects.size();
/*     */ 
/* 427 */     if (shouldShowPaginationCell()) {
/* 428 */       count++;
/*     */     }
/*     */ 
/* 431 */     return count;
/*     */   }
/*     */ 
/*     */   public View getItemView(T object, View v, ViewGroup parent)
/*     */   {
/* 459 */     if (v == null)
/* 460 */       v = getDefaultView(this.context);
/*     */     TextView textView;
/*     */     try
/*     */     {
/* 465 */       textView = (TextView)v.findViewById(16908308);
/*     */     } catch (ClassCastException ex) {
/* 467 */       throw new IllegalStateException("Your object views must have a TextView whose id attribute is 'android.R.id.text1'", ex);
/*     */     }
/*     */ 
/* 471 */     if (textView != null) {
/* 472 */       if (this.textKey == null)
/* 473 */         textView.setText(object.getObjectId());
/* 474 */       else if (object.get(this.textKey) != null)
/* 475 */         textView.setText(object.get(this.textKey).toString());
/*     */       else {
/* 477 */         textView.setText(null);
/*     */       }
/*     */     }
/*     */ 
/* 481 */     if (this.imageKey != null) {
/*     */       ParseImageView imageView;
/*     */       try { imageView = (ParseImageView)v.findViewById(16908294);
/*     */       } catch (ClassCastException ex) {
/* 486 */         throw new IllegalStateException("Your object views must have a ParseImageView whose id attribute is 'android.R.id.icon'", ex);
/*     */       }
/*     */ 
/* 490 */       if (imageView == null) {
/* 491 */         throw new IllegalStateException("Your object views must have a ParseImageView whose id attribute is 'android.R.id.icon' if an imageKey is specified");
/*     */       }
/*     */ 
/* 494 */       if (!this.imageViewSet.containsKey(imageView)) {
/* 495 */         this.imageViewSet.put(imageView, null);
/*     */       }
/* 497 */       imageView.setPlaceholder(this.placeholder);
/* 498 */       imageView.setParseFile((ParseFile)object.get(this.imageKey));
/* 499 */       imageView.loadInBackground();
/*     */     }
/*     */ 
/* 502 */     return v;
/*     */   }
/*     */ 
/*     */   public View getNextPageView(View v, ViewGroup parent)
/*     */   {
/* 519 */     if (v == null) {
/* 520 */       v = getDefaultView(this.context);
/*     */     }
/* 522 */     TextView textView = (TextView)v.findViewById(16908308);
/* 523 */     textView.setText("Load more...");
/* 524 */     return v;
/*     */   }
/*     */ 
/*     */   public final View getView(int position, View convertView, ViewGroup parent)
/*     */   {
/* 536 */     if (getItemViewType(position) == 1) {
/* 537 */       View nextPageView = getNextPageView(convertView, parent);
/* 538 */       nextPageView.setOnClickListener(new View.OnClickListener()
/*     */       {
/*     */         public void onClick(View view) {
/* 541 */           ParseQueryAdapter.this.loadNextPage();
/*     */         }
/*     */       });
/* 544 */       return nextPageView;
/*     */     }
/* 546 */     return getItemView(getItem(position), convertView, parent);
/*     */   }
/*     */ 
/*     */   protected void setPageOnQuery(int page, ParseQuery<T> query)
/*     */   {
/* 563 */     query.setLimit(this.objectsPerPage + 1);
/* 564 */     query.setSkip(page * this.objectsPerPage);
/*     */   }
/*     */ 
/*     */   public void setTextKey(String textKey) {
/* 568 */     this.textKey = textKey;
/*     */   }
/*     */ 
/*     */   public void setImageKey(String imageKey) {
/* 572 */     this.imageKey = imageKey;
/*     */   }
/*     */ 
/*     */   public void setObjectsPerPage(int objectsPerPage) {
/* 576 */     this.objectsPerPage = objectsPerPage;
/*     */   }
/*     */ 
/*     */   public int getObjectsPerPage() {
/* 580 */     return this.objectsPerPage;
/*     */   }
/*     */ 
/*     */   public void setPaginationEnabled(boolean paginationEnabled)
/*     */   {
/* 590 */     this.paginationEnabled = paginationEnabled;
/*     */   }
/*     */ 
/*     */   public void setPlaceholder(Drawable placeholder)
/*     */   {
/* 604 */     if (this.placeholder == placeholder) {
/* 605 */       return;
/*     */     }
/* 607 */     this.placeholder = placeholder;
/* 608 */     Iterator iter = this.imageViewSet.keySet().iterator();
/*     */ 
/* 610 */     while (iter.hasNext()) {
/* 611 */       ParseImageView imageView = (ParseImageView)iter.next();
/* 612 */       if (imageView != null)
/* 613 */         imageView.setPlaceholder(this.placeholder);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAutoload(boolean autoload)
/*     */   {
/* 626 */     if (this.autoload == autoload)
/*     */     {
/* 629 */       return;
/*     */     }
/* 631 */     this.autoload = autoload;
/* 632 */     if ((this.autoload) && (!this.dataSetObservers.isEmpty()) && (this.objects.isEmpty()))
/* 633 */       loadObjects();
/*     */   }
/*     */ 
/*     */   public void addOnQueryLoadListener(OnQueryLoadListener<T> listener)
/*     */   {
/* 638 */     this.onQueryLoadListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeOnQueryLoadListener(OnQueryLoadListener<T> listener) {
/* 642 */     this.onQueryLoadListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   private View getDefaultView(Context context) {
/* 646 */     if (this.itemResourceId != null) {
/* 647 */       return View.inflate(context, this.itemResourceId.intValue(), null);
/*     */     }
/* 649 */     LinearLayout view = new LinearLayout(context);
/* 650 */     view.setPadding(8, 4, 8, 4);
/*     */ 
/* 652 */     ParseImageView imageView = new ParseImageView(context);
/* 653 */     imageView.setId(16908294);
/* 654 */     imageView.setLayoutParams(new LinearLayout.LayoutParams(50, 50));
/* 655 */     view.addView(imageView);
/*     */ 
/* 657 */     TextView textView = new TextView(context);
/* 658 */     textView.setId(16908308);
/* 659 */     textView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
/*     */ 
/* 661 */     textView.setPadding(8, 0, 0, 0);
/* 662 */     view.addView(textView);
/*     */ 
/* 664 */     return view;
/*     */   }
/*     */ 
/*     */   private int getPaginationCellRow() {
/* 668 */     return this.objects.size();
/*     */   }
/*     */ 
/*     */   private boolean shouldShowPaginationCell() {
/* 672 */     return (this.paginationEnabled) && (this.objects.size() > 0) && (this.hasNextPage);
/*     */   }
/*     */ 
/*     */   private void notifyOnLoadingListeners() {
/* 676 */     for (OnQueryLoadListener listener : this.onQueryLoadListeners)
/* 677 */       listener.onLoading();
/*     */   }
/*     */ 
/*     */   private void notifyOnLoadedListeners(List<T> objects, Exception e)
/*     */   {
/* 682 */     for (OnQueryLoadListener listener : this.onQueryLoadListeners)
/* 683 */       listener.onLoaded(objects, e);
/*     */   }
/*     */ 
/*     */   public static abstract interface OnQueryLoadListener<T extends ParseObject>
/*     */   {
/*     */     public abstract void onLoading();
/*     */ 
/*     */     public abstract void onLoaded(List<T> paramList, Exception paramException);
/*     */   }
/*     */ 
/*     */   public static abstract interface QueryFactory<T extends ParseObject>
/*     */   {
/*     */     public abstract ParseQuery<T> create();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseQueryAdapter
 * JD-Core Version:    0.6.0
 */