/*    */ package com.parse;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.json.JSONArray;
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseRemoveOperation
/*    */   implements ParseFieldOperation
/*    */ {
/* 17 */   protected HashSet<Object> objects = new HashSet();
/*    */ 
/*    */   public ParseRemoveOperation(Collection<?> coll) {
/* 20 */     this.objects.addAll(coll);
/*    */   }
/*    */ 
/*    */   public JSONObject encode(ParseObjectEncodingStrategy objectEncoder) throws JSONException
/*    */   {
/* 25 */     JSONObject output = new JSONObject();
/* 26 */     output.put("__op", "Remove");
/* 27 */     output.put("objects", Parse.encode(new ArrayList(this.objects), objectEncoder));
/* 28 */     return output;
/*    */   }
/*    */ 
/*    */   public ParseFieldOperation mergeWithPrevious(ParseFieldOperation previous)
/*    */   {
/* 33 */     if (previous == null)
/* 34 */       return this;
/* 35 */     if ((previous instanceof ParseDeleteOperation))
/* 36 */       return new ParseSetOperation(this.objects);
/* 37 */     if ((previous instanceof ParseSetOperation)) {
/* 38 */       Object value = ((ParseSetOperation)previous).getValue();
/* 39 */       if (((value instanceof JSONArray)) || ((value instanceof List))) {
/* 40 */         return new ParseSetOperation(apply(value, null, null));
/*    */       }
/* 42 */       throw new IllegalArgumentException("You can only add an item to a List or JSONArray.");
/*    */     }
/* 44 */     if ((previous instanceof ParseRemoveOperation)) {
/* 45 */       HashSet result = new HashSet(((ParseRemoveOperation)previous).objects);
/* 46 */       result.addAll(this.objects);
/* 47 */       return new ParseRemoveOperation(result);
/*    */     }
/* 49 */     throw new IllegalArgumentException("Operation is invalid after previous operation.");
/*    */   }
/*    */ 
/*    */   public Object apply(Object oldValue, ParseObject object, String key)
/*    */   {
/* 55 */     if (oldValue == null)
/* 56 */       return new ArrayList();
/* 57 */     if ((oldValue instanceof JSONArray)) {
/* 58 */       ArrayList old = ParseFieldOperations.jsonArrayAsArrayList((JSONArray)oldValue);
/*    */ 
/* 60 */       ArrayList newValue = (ArrayList)apply(old, object, key);
/* 61 */       return new JSONArray(newValue);
/* 62 */     }if ((oldValue instanceof List)) {
/* 63 */       ArrayList result = new ArrayList((List)oldValue);
/* 64 */       result.removeAll(this.objects);
/*    */ 
/* 68 */       ArrayList objectsToBeRemoved = new ArrayList(this.objects);
/* 69 */       objectsToBeRemoved.removeAll(result);
/*    */ 
/* 72 */       HashSet objectIds = new HashSet();
/* 73 */       for (Iterator i$ = objectsToBeRemoved.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/* 74 */         if ((obj instanceof ParseObject)) {
/* 75 */           objectIds.add(((ParseObject)obj).getObjectId());
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 80 */       Iterator resultIterator = result.iterator();
/* 81 */       while (resultIterator.hasNext()) {
/* 82 */         Object obj = resultIterator.next();
/* 83 */         if (((obj instanceof ParseObject)) && (objectIds.contains(((ParseObject)obj).getObjectId()))) {
/* 84 */           resultIterator.remove();
/*    */         }
/*    */       }
/* 87 */       return result;
/*    */     }
/* 89 */     throw new IllegalArgumentException("Operation is invalid after previous operation.");
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRemoveOperation
 * JD-Core Version:    0.6.0
 */