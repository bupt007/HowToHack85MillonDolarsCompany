/*     */ package com.parse;
/*     */ 
/*     */ import bolts.Task;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class ParseRESTUserCommand extends ParseRESTCommand
/*     */ {
/*     */   private static final String HEADER_REVOCABLE_SESSION = "X-Parse-Revocable-Session";
/*     */   private static final String HEADER_TRUE = "1";
/*     */   private boolean isRevocableSessionEnabled;
/*     */   private int statusCode;
/*     */ 
/*     */   public static ParseRESTUserCommand getCurrentUserCommand(String sessionToken)
/*     */   {
/*  19 */     return new ParseRESTUserCommand("users/me", ParseRequest.Method.GET, (Map)null, sessionToken);
/*     */   }
/*     */ 
/*     */   public static ParseRESTUserCommand signUpUserCommand(JSONObject parameters, String sessionToken, boolean revocableSession)
/*     */   {
/*  26 */     return new ParseRESTUserCommand("classes/_User", ParseRequest.Method.POST, parameters, sessionToken, revocableSession);
/*     */   }
/*     */ 
/*     */   public static ParseRESTUserCommand logInUserCommand(String username, String password, boolean revocableSession)
/*     */   {
/*  32 */     Map parameters = new HashMap();
/*  33 */     parameters.put("username", username);
/*  34 */     parameters.put("password", password);
/*  35 */     return new ParseRESTUserCommand("login", ParseRequest.Method.GET, parameters, null, revocableSession);
/*     */   }
/*     */ 
/*     */   public static ParseRESTUserCommand serviceLogInUserCommand(String authType, JSONObject authData, boolean revocableSession) throws JSONException
/*     */   {
/*  40 */     JSONObject authenticationData = new JSONObject();
/*  41 */     authenticationData.put(authType, authData);
/*     */ 
/*  43 */     JSONObject parameters = new JSONObject();
/*  44 */     parameters.put("authData", authenticationData);
/*     */ 
/*  46 */     return serviceLogInUserCommand(parameters, null, revocableSession);
/*     */   }
/*     */ 
/*     */   public static ParseRESTUserCommand serviceLogInUserCommand(JSONObject parameters, String sessionToken, boolean revocableSession)
/*     */   {
/*  51 */     return new ParseRESTUserCommand("users", ParseRequest.Method.POST, parameters, sessionToken, revocableSession);
/*     */   }
/*     */ 
/*     */   public static ParseRESTUserCommand resetUserPasswordCommand(String email)
/*     */   {
/*  58 */     Map parameters = new HashMap();
/*  59 */     parameters.put("email", email);
/*  60 */     return new ParseRESTUserCommand("requestPasswordReset", ParseRequest.Method.POST, parameters, null);
/*     */   }
/*     */ 
/*     */   public static ParseRESTUserCommand upgradeRevocableSessionCommand(String sessionToken) {
/*  64 */     return new ParseRESTUserCommand("upgradeToRevocableSession", ParseRequest.Method.POST, new JSONObject(), sessionToken);
/*     */   }
/*     */ 
/*     */   public static ParseRESTUserCommand logOutUserCommand(String sessionToken)
/*     */   {
/*  69 */     return new ParseRESTUserCommand("logout", ParseRequest.Method.POST, new JSONObject(), sessionToken);
/*     */   }
/*     */ 
/*     */   private ParseRESTUserCommand(String httpPath, ParseRequest.Method httpMethod, Map<String, ?> parameters, String sessionToken)
/*     */   {
/*  77 */     this(httpPath, httpMethod, parameters, sessionToken, false);
/*     */   }
/*     */ 
/*     */   private ParseRESTUserCommand(String httpPath, ParseRequest.Method httpMethod, JSONObject parameters, String sessionToken)
/*     */   {
/*  82 */     this(httpPath, httpMethod, parameters, sessionToken, false);
/*     */   }
/*     */ 
/*     */   private ParseRESTUserCommand(String httpPath, ParseRequest.Method httpMethod, Map<String, ?> parameters, String sessionToken, boolean isRevocableSessionEnabled)
/*     */   {
/*  87 */     super(httpPath, httpMethod, parameters, sessionToken);
/*  88 */     this.isRevocableSessionEnabled = isRevocableSessionEnabled;
/*     */   }
/*     */ 
/*     */   private ParseRESTUserCommand(String httpPath, ParseRequest.Method httpMethod, JSONObject parameters, String sessionToken, boolean isRevocableSessionEnabled)
/*     */   {
/*  93 */     super(httpPath, httpMethod, parameters, sessionToken);
/*  94 */     this.isRevocableSessionEnabled = isRevocableSessionEnabled;
/*     */   }
/*     */ 
/*     */   public int getStatusCode() {
/*  98 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */   protected HttpUriRequest newRequest(ParseRequest.Method method, ProgressCallback uploadProgressCallback) throws ParseException
/*     */   {
/* 103 */     HttpUriRequest request = super.newRequest(method, uploadProgressCallback);
/* 104 */     if (this.isRevocableSessionEnabled) {
/* 105 */       request.addHeader("X-Parse-Revocable-Session", "1");
/*     */     }
/* 107 */     return request;
/*     */   }
/*     */ 
/*     */   protected Task<JSONObject> onResponse(ParseHttpResponse response, ProgressCallback progressCallback)
/*     */   {
/* 113 */     this.statusCode = response.getStatusCode();
/* 114 */     return super.onResponse(response, progressCallback);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTUserCommand
 * JD-Core Version:    0.6.0
 */