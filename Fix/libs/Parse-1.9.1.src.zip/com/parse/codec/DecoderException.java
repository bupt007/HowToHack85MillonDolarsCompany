/*    */ package com.parse.codec;
/*    */ 
/*    */ public class DecoderException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public DecoderException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DecoderException(String message)
/*    */   {
/* 55 */     super(message);
/*    */   }
/*    */ 
/*    */   public DecoderException(String message, Throwable cause)
/*    */   {
/* 74 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public DecoderException(Throwable cause)
/*    */   {
/* 88 */     super(cause);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.DecoderException
 * JD-Core Version:    0.6.0
 */