/*     */ package com.parse.codec.net;
/*     */ 
/*     */ import com.parse.codec.DecoderException;
/*     */ import com.parse.codec.EncoderException;
/*     */ import com.parse.codec.StringDecoder;
/*     */ import com.parse.codec.StringEncoder;
/*     */ import com.parse.codec.binary.Base64;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ public class BCodec extends RFC1522Codec
/*     */   implements StringEncoder, StringDecoder
/*     */ {
/*     */   private final String charset;
/*     */ 
/*     */   public BCodec()
/*     */   {
/*  59 */     this("UTF-8");
/*     */   }
/*     */ 
/*     */   public BCodec(String charset)
/*     */   {
/*  72 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   protected String getEncoding() {
/*  76 */     return "B";
/*     */   }
/*     */ 
/*     */   protected byte[] doEncoding(byte[] bytes) {
/*  80 */     if (bytes == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     return Base64.encodeBase64(bytes);
/*     */   }
/*     */ 
/*     */   protected byte[] doDecoding(byte[] bytes) {
/*  87 */     if (bytes == null) {
/*  88 */       return null;
/*     */     }
/*  90 */     return Base64.decodeBase64(bytes);
/*     */   }
/*     */ 
/*     */   public String encode(String value, String charset)
/*     */     throws EncoderException
/*     */   {
/* 106 */     if (value == null)
/* 107 */       return null;
/*     */     try
/*     */     {
/* 110 */       return encodeText(value, charset); } catch (UnsupportedEncodingException e) {
/*     */     }
/* 112 */     throw new EncoderException(e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public String encode(String value)
/*     */     throws EncoderException
/*     */   {
/* 127 */     if (value == null) {
/* 128 */       return null;
/*     */     }
/* 130 */     return encode(value, getDefaultCharset());
/*     */   }
/*     */ 
/*     */   public String decode(String value)
/*     */     throws DecoderException
/*     */   {
/* 144 */     if (value == null)
/* 145 */       return null;
/*     */     try
/*     */     {
/* 148 */       return decodeText(value); } catch (UnsupportedEncodingException e) {
/*     */     }
/* 150 */     throw new DecoderException(e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public Object encode(Object value)
/*     */     throws EncoderException
/*     */   {
/* 165 */     if (value == null)
/* 166 */       return null;
/* 167 */     if ((value instanceof String)) {
/* 168 */       return encode((String)value);
/*     */     }
/* 170 */     throw new EncoderException("Objects of type " + value.getClass().getName() + " cannot be encoded using BCodec");
/*     */   }
/*     */ 
/*     */   public Object decode(Object value)
/*     */     throws DecoderException
/*     */   {
/* 190 */     if (value == null)
/* 191 */       return null;
/* 192 */     if ((value instanceof String)) {
/* 193 */       return decode((String)value);
/*     */     }
/* 195 */     throw new DecoderException("Objects of type " + value.getClass().getName() + " cannot be decoded using BCodec");
/*     */   }
/*     */ 
/*     */   public String getDefaultCharset()
/*     */   {
/* 207 */     return this.charset;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.net.BCodec
 * JD-Core Version:    0.6.0
 */