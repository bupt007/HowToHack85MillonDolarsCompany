/*    */ package com.parse.codec.net;
/*    */ 
/*    */ import com.parse.codec.DecoderException;
/*    */ 
/*    */ class Utils
/*    */ {
/*    */   static int digit16(byte b)
/*    */     throws DecoderException
/*    */   {
/* 43 */     int i = Character.digit((char)b, 16);
/* 44 */     if (i == -1) {
/* 45 */       throw new DecoderException("Invalid URL encoding: not a valid digit (radix 16): " + b);
/*    */     }
/* 47 */     return i;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.net.Utils
 * JD-Core Version:    0.6.0
 */