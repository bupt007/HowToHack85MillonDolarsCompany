/*     */ package com.parse.codec.net;
/*     */ 
/*     */ import com.parse.codec.DecoderException;
/*     */ import com.parse.codec.EncoderException;
/*     */ import com.parse.codec.StringDecoder;
/*     */ import com.parse.codec.StringEncoder;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.BitSet;
/*     */ 
/*     */ public class QCodec extends RFC1522Codec
/*     */   implements StringEncoder, StringDecoder
/*     */ {
/*     */   private final String charset;
/*  59 */   private static final BitSet PRINTABLE_CHARS = new BitSet(256);
/*     */   private static final byte BLANK = 32;
/*     */   private static final byte UNDERSCORE = 95;
/* 108 */   private boolean encodeBlanks = false;
/*     */ 
/*     */   public QCodec()
/*     */   {
/* 114 */     this("UTF-8");
/*     */   }
/*     */ 
/*     */   public QCodec(String charset)
/*     */   {
/* 127 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   protected String getEncoding() {
/* 131 */     return "Q";
/*     */   }
/*     */ 
/*     */   protected byte[] doEncoding(byte[] bytes) {
/* 135 */     if (bytes == null) {
/* 136 */       return null;
/*     */     }
/* 138 */     byte[] data = QuotedPrintableCodec.encodeQuotedPrintable(PRINTABLE_CHARS, bytes);
/* 139 */     if (this.encodeBlanks) {
/* 140 */       for (int i = 0; i < data.length; i++) {
/* 141 */         if (data[i] == 32) {
/* 142 */           data[i] = 95;
/*     */         }
/*     */       }
/*     */     }
/* 146 */     return data;
/*     */   }
/*     */ 
/*     */   protected byte[] doDecoding(byte[] bytes) throws DecoderException {
/* 150 */     if (bytes == null) {
/* 151 */       return null;
/*     */     }
/* 153 */     boolean hasUnderscores = false;
/* 154 */     for (int i = 0; i < bytes.length; i++) {
/* 155 */       if (bytes[i] == 95) {
/* 156 */         hasUnderscores = true;
/* 157 */         break;
/*     */       }
/*     */     }
/* 160 */     if (hasUnderscores) {
/* 161 */       byte[] tmp = new byte[bytes.length];
/* 162 */       for (int i = 0; i < bytes.length; i++) {
/* 163 */         byte b = bytes[i];
/* 164 */         if (b != 95)
/* 165 */           tmp[i] = b;
/*     */         else {
/* 167 */           tmp[i] = 32;
/*     */         }
/*     */       }
/* 170 */       return QuotedPrintableCodec.decodeQuotedPrintable(tmp);
/*     */     }
/* 172 */     return QuotedPrintableCodec.decodeQuotedPrintable(bytes);
/*     */   }
/*     */ 
/*     */   public String encode(String pString, String charset)
/*     */     throws EncoderException
/*     */   {
/* 188 */     if (pString == null)
/* 189 */       return null;
/*     */     try
/*     */     {
/* 192 */       return encodeText(pString, charset); } catch (UnsupportedEncodingException e) {
/*     */     }
/* 194 */     throw new EncoderException(e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public String encode(String pString)
/*     */     throws EncoderException
/*     */   {
/* 209 */     if (pString == null) {
/* 210 */       return null;
/*     */     }
/* 212 */     return encode(pString, getDefaultCharset());
/*     */   }
/*     */ 
/*     */   public String decode(String pString)
/*     */     throws DecoderException
/*     */   {
/* 228 */     if (pString == null)
/* 229 */       return null;
/*     */     try
/*     */     {
/* 232 */       return decodeText(pString); } catch (UnsupportedEncodingException e) {
/*     */     }
/* 234 */     throw new DecoderException(e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 249 */     if (pObject == null)
/* 250 */       return null;
/* 251 */     if ((pObject instanceof String)) {
/* 252 */       return encode((String)pObject);
/*     */     }
/* 254 */     throw new EncoderException("Objects of type " + pObject.getClass().getName() + " cannot be encoded using Q codec");
/*     */   }
/*     */ 
/*     */   public Object decode(Object pObject)
/*     */     throws DecoderException
/*     */   {
/* 274 */     if (pObject == null)
/* 275 */       return null;
/* 276 */     if ((pObject instanceof String)) {
/* 277 */       return decode((String)pObject);
/*     */     }
/* 279 */     throw new DecoderException("Objects of type " + pObject.getClass().getName() + " cannot be decoded using Q codec");
/*     */   }
/*     */ 
/*     */   public String getDefaultCharset()
/*     */   {
/* 291 */     return this.charset;
/*     */   }
/*     */ 
/*     */   public boolean isEncodeBlanks()
/*     */   {
/* 300 */     return this.encodeBlanks;
/*     */   }
/*     */ 
/*     */   public void setEncodeBlanks(boolean b)
/*     */   {
/* 310 */     this.encodeBlanks = b;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  63 */     PRINTABLE_CHARS.set(32);
/*  64 */     PRINTABLE_CHARS.set(33);
/*  65 */     PRINTABLE_CHARS.set(34);
/*  66 */     PRINTABLE_CHARS.set(35);
/*  67 */     PRINTABLE_CHARS.set(36);
/*  68 */     PRINTABLE_CHARS.set(37);
/*  69 */     PRINTABLE_CHARS.set(38);
/*  70 */     PRINTABLE_CHARS.set(39);
/*  71 */     PRINTABLE_CHARS.set(40);
/*  72 */     PRINTABLE_CHARS.set(41);
/*  73 */     PRINTABLE_CHARS.set(42);
/*  74 */     PRINTABLE_CHARS.set(43);
/*  75 */     PRINTABLE_CHARS.set(44);
/*  76 */     PRINTABLE_CHARS.set(45);
/*  77 */     PRINTABLE_CHARS.set(46);
/*  78 */     PRINTABLE_CHARS.set(47);
/*  79 */     for (int i = 48; i <= 57; i++) {
/*  80 */       PRINTABLE_CHARS.set(i);
/*     */     }
/*  82 */     PRINTABLE_CHARS.set(58);
/*  83 */     PRINTABLE_CHARS.set(59);
/*  84 */     PRINTABLE_CHARS.set(60);
/*  85 */     PRINTABLE_CHARS.set(62);
/*  86 */     PRINTABLE_CHARS.set(64);
/*  87 */     for (int i = 65; i <= 90; i++) {
/*  88 */       PRINTABLE_CHARS.set(i);
/*     */     }
/*  90 */     PRINTABLE_CHARS.set(91);
/*  91 */     PRINTABLE_CHARS.set(92);
/*  92 */     PRINTABLE_CHARS.set(93);
/*  93 */     PRINTABLE_CHARS.set(94);
/*  94 */     PRINTABLE_CHARS.set(96);
/*  95 */     for (int i = 97; i <= 122; i++) {
/*  96 */       PRINTABLE_CHARS.set(i);
/*     */     }
/*  98 */     PRINTABLE_CHARS.set(123);
/*  99 */     PRINTABLE_CHARS.set(124);
/* 100 */     PRINTABLE_CHARS.set(125);
/* 101 */     PRINTABLE_CHARS.set(126);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.net.QCodec
 * JD-Core Version:    0.6.0
 */