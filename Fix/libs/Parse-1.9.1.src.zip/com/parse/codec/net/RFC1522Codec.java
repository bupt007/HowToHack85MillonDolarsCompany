/*     */ package com.parse.codec.net;
/*     */ 
/*     */ import com.parse.codec.DecoderException;
/*     */ import com.parse.codec.EncoderException;
/*     */ import com.parse.codec.binary.StringUtils;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ abstract class RFC1522Codec
/*     */ {
/*     */   protected static final char SEP = '?';
/*     */   protected static final String POSTFIX = "?=";
/*     */   protected static final String PREFIX = "=?";
/*     */ 
/*     */   protected String encodeText(String text, String charset)
/*     */     throws EncoderException, UnsupportedEncodingException
/*     */   {
/*  85 */     if (text == null) {
/*  86 */       return null;
/*     */     }
/*  88 */     StringBuffer buffer = new StringBuffer();
/*  89 */     buffer.append("=?");
/*  90 */     buffer.append(charset);
/*  91 */     buffer.append('?');
/*  92 */     buffer.append(getEncoding());
/*  93 */     buffer.append('?');
/*  94 */     byte[] rawdata = doEncoding(text.getBytes(charset));
/*  95 */     buffer.append(StringUtils.newStringUsAscii(rawdata));
/*  96 */     buffer.append("?=");
/*  97 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   protected String decodeText(String text)
/*     */     throws DecoderException, UnsupportedEncodingException
/*     */   {
/* 116 */     if (text == null) {
/* 117 */       return null;
/*     */     }
/* 119 */     if ((!text.startsWith("=?")) || (!text.endsWith("?="))) {
/* 120 */       throw new DecoderException("RFC 1522 violation: malformed encoded content");
/*     */     }
/* 122 */     int terminator = text.length() - 2;
/* 123 */     int from = 2;
/* 124 */     int to = text.indexOf(63, from);
/* 125 */     if (to == terminator) {
/* 126 */       throw new DecoderException("RFC 1522 violation: charset token not found");
/*     */     }
/* 128 */     String charset = text.substring(from, to);
/* 129 */     if (charset.equals("")) {
/* 130 */       throw new DecoderException("RFC 1522 violation: charset not specified");
/*     */     }
/* 132 */     from = to + 1;
/* 133 */     to = text.indexOf(63, from);
/* 134 */     if (to == terminator) {
/* 135 */       throw new DecoderException("RFC 1522 violation: encoding token not found");
/*     */     }
/* 137 */     String encoding = text.substring(from, to);
/* 138 */     if (!getEncoding().equalsIgnoreCase(encoding)) {
/* 139 */       throw new DecoderException("This codec cannot decode " + encoding + " encoded content");
/*     */     }
/*     */ 
/* 142 */     from = to + 1;
/* 143 */     to = text.indexOf(63, from);
/* 144 */     byte[] data = StringUtils.getBytesUsAscii(text.substring(from, to));
/* 145 */     data = doDecoding(data);
/* 146 */     return new String(data, charset);
/*     */   }
/*     */ 
/*     */   protected abstract String getEncoding();
/*     */ 
/*     */   protected abstract byte[] doEncoding(byte[] paramArrayOfByte)
/*     */     throws EncoderException;
/*     */ 
/*     */   protected abstract byte[] doDecoding(byte[] paramArrayOfByte)
/*     */     throws DecoderException;
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.net.RFC1522Codec
 * JD-Core Version:    0.6.0
 */