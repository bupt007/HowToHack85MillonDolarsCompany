/*     */ package com.parse.codec.net;
/*     */ 
/*     */ import com.parse.codec.BinaryDecoder;
/*     */ import com.parse.codec.BinaryEncoder;
/*     */ import com.parse.codec.DecoderException;
/*     */ import com.parse.codec.EncoderException;
/*     */ import com.parse.codec.StringDecoder;
/*     */ import com.parse.codec.StringEncoder;
/*     */ import com.parse.codec.binary.StringUtils;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.BitSet;
/*     */ 
/*     */ public class QuotedPrintableCodec
/*     */   implements BinaryEncoder, BinaryDecoder, StringEncoder, StringDecoder
/*     */ {
/*     */   private final String charset;
/*  73 */   private static final BitSet PRINTABLE_CHARS = new BitSet(256);
/*     */   private static final byte ESCAPE_CHAR = 61;
/*     */   private static final byte TAB = 9;
/*     */   private static final byte SPACE = 32;
/*     */ 
/*     */   public QuotedPrintableCodec()
/*     */   {
/*  97 */     this("UTF-8");
/*     */   }
/*     */ 
/*     */   public QuotedPrintableCodec(String charset)
/*     */   {
/* 108 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   private static final void encodeQuotedPrintable(int b, ByteArrayOutputStream buffer)
/*     */   {
/* 120 */     buffer.write(61);
/* 121 */     char hex1 = Character.toUpperCase(Character.forDigit(b >> 4 & 0xF, 16));
/* 122 */     char hex2 = Character.toUpperCase(Character.forDigit(b & 0xF, 16));
/* 123 */     buffer.write(hex1);
/* 124 */     buffer.write(hex2);
/*     */   }
/*     */ 
/*     */   public static final byte[] encodeQuotedPrintable(BitSet printable, byte[] bytes)
/*     */   {
/* 142 */     if (bytes == null) {
/* 143 */       return null;
/*     */     }
/* 145 */     if (printable == null) {
/* 146 */       printable = PRINTABLE_CHARS;
/*     */     }
/* 148 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/* 149 */     for (int i = 0; i < bytes.length; i++) {
/* 150 */       int b = bytes[i];
/* 151 */       if (b < 0) {
/* 152 */         b = 256 + b;
/*     */       }
/* 154 */       if (printable.get(b))
/* 155 */         buffer.write(b);
/*     */       else {
/* 157 */         encodeQuotedPrintable(b, buffer);
/*     */       }
/*     */     }
/* 160 */     return buffer.toByteArray();
/*     */   }
/*     */ 
/*     */   public static final byte[] decodeQuotedPrintable(byte[] bytes)
/*     */     throws DecoderException
/*     */   {
/* 179 */     if (bytes == null) {
/* 180 */       return null;
/*     */     }
/* 182 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/* 183 */     for (int i = 0; i < bytes.length; i++) {
/* 184 */       int b = bytes[i];
/* 185 */       if (b == 61)
/*     */         try {
/* 187 */           i++; int u = Utils.digit16(bytes[i]);
/* 188 */           i++; int l = Utils.digit16(bytes[i]);
/* 189 */           buffer.write((char)((u << 4) + l));
/*     */         } catch (ArrayIndexOutOfBoundsException e) {
/* 191 */           throw new DecoderException("Invalid quoted-printable encoding", e);
/*     */         }
/*     */       else {
/* 194 */         buffer.write(b);
/*     */       }
/*     */     }
/* 197 */     return buffer.toByteArray();
/*     */   }
/*     */ 
/*     */   public byte[] encode(byte[] bytes)
/*     */   {
/* 213 */     return encodeQuotedPrintable(PRINTABLE_CHARS, bytes);
/*     */   }
/*     */ 
/*     */   public byte[] decode(byte[] bytes)
/*     */     throws DecoderException
/*     */   {
/* 232 */     return decodeQuotedPrintable(bytes);
/*     */   }
/*     */ 
/*     */   public String encode(String pString)
/*     */     throws EncoderException
/*     */   {
/* 253 */     if (pString == null)
/* 254 */       return null;
/*     */     try
/*     */     {
/* 257 */       return encode(pString, getDefaultCharset()); } catch (UnsupportedEncodingException e) {
/*     */     }
/* 259 */     throw new EncoderException(e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public String decode(String pString, String charset)
/*     */     throws DecoderException, UnsupportedEncodingException
/*     */   {
/* 278 */     if (pString == null) {
/* 279 */       return null;
/*     */     }
/* 281 */     return new String(decode(StringUtils.getBytesUsAscii(pString)), charset);
/*     */   }
/*     */ 
/*     */   public String decode(String pString)
/*     */     throws DecoderException
/*     */   {
/* 297 */     if (pString == null)
/* 298 */       return null;
/*     */     try
/*     */     {
/* 301 */       return decode(pString, getDefaultCharset()); } catch (UnsupportedEncodingException e) {
/*     */     }
/* 303 */     throw new DecoderException(e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 318 */     if (pObject == null)
/* 319 */       return null;
/* 320 */     if ((pObject instanceof byte[]))
/* 321 */       return encode((byte[])(byte[])pObject);
/* 322 */     if ((pObject instanceof String)) {
/* 323 */       return encode((String)pObject);
/*     */     }
/* 325 */     throw new EncoderException("Objects of type " + pObject.getClass().getName() + " cannot be quoted-printable encoded");
/*     */   }
/*     */ 
/*     */   public Object decode(Object pObject)
/*     */     throws DecoderException
/*     */   {
/* 343 */     if (pObject == null)
/* 344 */       return null;
/* 345 */     if ((pObject instanceof byte[]))
/* 346 */       return decode((byte[])(byte[])pObject);
/* 347 */     if ((pObject instanceof String)) {
/* 348 */       return decode((String)pObject);
/*     */     }
/* 350 */     throw new DecoderException("Objects of type " + pObject.getClass().getName() + " cannot be quoted-printable decoded");
/*     */   }
/*     */ 
/*     */   public String getDefaultCharset()
/*     */   {
/* 362 */     return this.charset;
/*     */   }
/*     */ 
/*     */   public String encode(String pString, String charset)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 383 */     if (pString == null) {
/* 384 */       return null;
/*     */     }
/* 386 */     return StringUtils.newStringUsAscii(encode(pString.getBytes(charset)));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  83 */     for (int i = 33; i <= 60; i++) {
/*  84 */       PRINTABLE_CHARS.set(i);
/*     */     }
/*  86 */     for (int i = 62; i <= 126; i++) {
/*  87 */       PRINTABLE_CHARS.set(i);
/*     */     }
/*  89 */     PRINTABLE_CHARS.set(9);
/*  90 */     PRINTABLE_CHARS.set(32);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.net.QuotedPrintableCodec
 * JD-Core Version:    0.6.0
 */