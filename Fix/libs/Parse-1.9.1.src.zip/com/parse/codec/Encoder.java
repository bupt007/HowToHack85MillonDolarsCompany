package com.parse.codec;

public abstract interface Encoder
{
  public abstract Object encode(Object paramObject)
    throws EncoderException;
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.Encoder
 * JD-Core Version:    0.6.0
 */