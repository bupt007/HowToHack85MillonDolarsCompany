/*     */ package com.parse.codec.binary;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class BaseNCodecOutputStream extends FilterOutputStream
/*     */ {
/*     */   private final boolean doEncode;
/*     */   private final BaseNCodec baseNCodec;
/*  36 */   private final byte[] singleByte = new byte[1];
/*     */ 
/*     */   public BaseNCodecOutputStream(OutputStream out, BaseNCodec basedCodec, boolean doEncode) {
/*  39 */     super(out);
/*  40 */     this.baseNCodec = basedCodec;
/*  41 */     this.doEncode = doEncode;
/*     */   }
/*     */ 
/*     */   public void write(int i)
/*     */     throws IOException
/*     */   {
/*  53 */     this.singleByte[0] = (byte)i;
/*  54 */     write(this.singleByte, 0, 1);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int offset, int len)
/*     */     throws IOException
/*     */   {
/*  76 */     if (b == null)
/*  77 */       throw new NullPointerException();
/*  78 */     if ((offset < 0) || (len < 0))
/*  79 */       throw new IndexOutOfBoundsException();
/*  80 */     if ((offset > b.length) || (offset + len > b.length))
/*  81 */       throw new IndexOutOfBoundsException();
/*  82 */     if (len > 0) {
/*  83 */       if (this.doEncode)
/*  84 */         this.baseNCodec.encode(b, offset, len);
/*     */       else {
/*  86 */         this.baseNCodec.decode(b, offset, len);
/*     */       }
/*  88 */       flush(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void flush(boolean propogate)
/*     */     throws IOException
/*     */   {
/* 102 */     int avail = this.baseNCodec.available();
/* 103 */     if (avail > 0) {
/* 104 */       byte[] buf = new byte[avail];
/* 105 */       int c = this.baseNCodec.readResults(buf, 0, avail);
/* 106 */       if (c > 0) {
/* 107 */         this.out.write(buf, 0, c);
/*     */       }
/*     */     }
/* 110 */     if (propogate)
/* 111 */       this.out.flush();
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 122 */     flush(true);
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 133 */     if (this.doEncode)
/* 134 */       this.baseNCodec.encode(this.singleByte, 0, -1);
/*     */     else {
/* 136 */       this.baseNCodec.decode(this.singleByte, 0, -1);
/*     */     }
/* 138 */     flush();
/* 139 */     this.out.close();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.binary.BaseNCodecOutputStream
 * JD-Core Version:    0.6.0
 */