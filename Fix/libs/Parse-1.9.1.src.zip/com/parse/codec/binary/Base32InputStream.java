/*    */ package com.parse.codec.binary;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public class Base32InputStream extends BaseNCodecInputStream
/*    */ {
/*    */   public Base32InputStream(InputStream in)
/*    */   {
/* 49 */     this(in, false);
/*    */   }
/*    */ 
/*    */   public Base32InputStream(InputStream in, boolean doEncode)
/*    */   {
/* 62 */     super(in, new Base32(false), doEncode);
/*    */   }
/*    */ 
/*    */   public Base32InputStream(InputStream in, boolean doEncode, int lineLength, byte[] lineSeparator)
/*    */   {
/* 82 */     super(in, new Base32(lineLength, lineSeparator), doEncode);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.binary.Base32InputStream
 * JD-Core Version:    0.6.0
 */