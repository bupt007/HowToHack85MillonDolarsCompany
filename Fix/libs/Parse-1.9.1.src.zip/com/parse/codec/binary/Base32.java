/*     */ package com.parse.codec.binary;
/*     */ 
/*     */ public class Base32 extends BaseNCodec
/*     */ {
/*     */   private static final int BITS_PER_ENCODED_BYTE = 5;
/*     */   private static final int BYTES_PER_ENCODED_BLOCK = 8;
/*     */   private static final int BYTES_PER_UNENCODED_BLOCK = 5;
/*  61 */   private static final byte[] CHUNK_SEPARATOR = { 13, 10 };
/*     */ 
/*  69 */   private static final byte[] DECODE_TABLE = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 63, -1, -1, 26, 27, 28, 29, 30, 31, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25 };
/*     */ 
/*  83 */   private static final byte[] ENCODE_TABLE = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 50, 51, 52, 53, 54, 55 };
/*     */ 
/*  95 */   private static final byte[] HEX_DECODE_TABLE = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 63, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32 };
/*     */ 
/* 109 */   private static final byte[] HEX_ENCODE_TABLE = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86 };
/*     */   private static final int MASK_5BITS = 31;
/*     */   private long bitWorkArea;
/*     */   private final int decodeSize;
/*     */   private final byte[] decodeTable;
/*     */   private final int encodeSize;
/*     */   private final byte[] encodeTable;
/*     */   private final byte[] lineSeparator;
/*     */ 
/*     */   public Base32()
/*     */   {
/* 163 */     this(false);
/*     */   }
/*     */ 
/*     */   public Base32(boolean useHex)
/*     */   {
/* 174 */     this(0, null, useHex);
/*     */   }
/*     */ 
/*     */   public Base32(int lineLength)
/*     */   {
/* 188 */     this(lineLength, CHUNK_SEPARATOR);
/*     */   }
/*     */ 
/*     */   public Base32(int lineLength, byte[] lineSeparator)
/*     */   {
/* 209 */     this(lineLength, lineSeparator, false);
/*     */   }
/*     */ 
/*     */   public Base32(int lineLength, byte[] lineSeparator, boolean useHex)
/*     */   {
/* 232 */     super(5, 8, lineLength, lineSeparator == null ? 0 : lineSeparator.length);
/*     */ 
/* 235 */     if (useHex) {
/* 236 */       this.encodeTable = HEX_ENCODE_TABLE;
/* 237 */       this.decodeTable = HEX_DECODE_TABLE;
/*     */     } else {
/* 239 */       this.encodeTable = ENCODE_TABLE;
/* 240 */       this.decodeTable = DECODE_TABLE;
/*     */     }
/* 242 */     if (lineLength > 0) {
/* 243 */       if (lineSeparator == null) {
/* 244 */         throw new IllegalArgumentException("lineLength " + lineLength + " > 0, but lineSeparator is null");
/*     */       }
/*     */ 
/* 247 */       if (containsAlphabetOrPad(lineSeparator)) {
/* 248 */         String sep = StringUtils.newStringUtf8(lineSeparator);
/* 249 */         throw new IllegalArgumentException("lineSeparator must not contain Base32 characters: [" + sep + "]");
/*     */       }
/* 251 */       this.encodeSize = (8 + lineSeparator.length);
/* 252 */       this.lineSeparator = new byte[lineSeparator.length];
/* 253 */       System.arraycopy(lineSeparator, 0, this.lineSeparator, 0, lineSeparator.length);
/*     */     } else {
/* 255 */       this.encodeSize = 8;
/* 256 */       this.lineSeparator = null;
/*     */     }
/* 258 */     this.decodeSize = (this.encodeSize - 1);
/*     */   }
/*     */ 
/*     */   void decode(byte[] in, int inPos, int inAvail)
/*     */   {
/* 283 */     if (this.eof) {
/* 284 */       return;
/*     */     }
/* 286 */     if (inAvail < 0) {
/* 287 */       this.eof = true;
/*     */     }
/* 289 */     for (int i = 0; i < inAvail; i++) {
/* 290 */       byte b = in[(inPos++)];
/* 291 */       if (b == 61)
/*     */       {
/* 293 */         this.eof = true;
/* 294 */         break;
/*     */       }
/* 296 */       ensureBufferSize(this.decodeSize);
/* 297 */       if ((b >= 0) && (b < this.decodeTable.length)) {
/* 298 */         int result = this.decodeTable[b];
/* 299 */         if (result >= 0) {
/* 300 */           this.modulus = ((this.modulus + 1) % 8);
/* 301 */           this.bitWorkArea = ((this.bitWorkArea << 5) + result);
/* 302 */           if (this.modulus == 0) {
/* 303 */             this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 32 & 0xFF);
/* 304 */             this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 24 & 0xFF);
/* 305 */             this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 16 & 0xFF);
/* 306 */             this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 8 & 0xFF);
/* 307 */             this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea & 0xFF);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 317 */     if ((this.eof) && (this.modulus >= 2)) {
/* 318 */       ensureBufferSize(this.decodeSize);
/*     */ 
/* 321 */       switch (this.modulus) {
/*     */       case 2:
/* 323 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 2 & 0xFF);
/* 324 */         break;
/*     */       case 3:
/* 326 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 7 & 0xFF);
/* 327 */         break;
/*     */       case 4:
/* 329 */         this.bitWorkArea >>= 4;
/* 330 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 8 & 0xFF);
/* 331 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea & 0xFF);
/* 332 */         break;
/*     */       case 5:
/* 334 */         this.bitWorkArea >>= 1;
/* 335 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 16 & 0xFF);
/* 336 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 8 & 0xFF);
/* 337 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea & 0xFF);
/* 338 */         break;
/*     */       case 6:
/* 340 */         this.bitWorkArea >>= 6;
/* 341 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 16 & 0xFF);
/* 342 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 8 & 0xFF);
/* 343 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea & 0xFF);
/* 344 */         break;
/*     */       case 7:
/* 346 */         this.bitWorkArea >>= 3;
/* 347 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 24 & 0xFF);
/* 348 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 16 & 0xFF);
/* 349 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea >> 8 & 0xFF);
/* 350 */         this.buffer[(this.pos++)] = (byte)(int)(this.bitWorkArea & 0xFF);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   void encode(byte[] in, int inPos, int inAvail)
/*     */   {
/* 371 */     if (this.eof) {
/* 372 */       return;
/*     */     }
/*     */ 
/* 376 */     if (inAvail < 0) {
/* 377 */       this.eof = true;
/* 378 */       if ((0 == this.modulus) && (this.lineLength == 0)) {
/* 379 */         return;
/*     */       }
/* 381 */       ensureBufferSize(this.encodeSize);
/* 382 */       int savedPos = this.pos;
/* 383 */       switch (this.modulus) {
/*     */       case 1:
/* 385 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 3) & 0x1F)];
/* 386 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea << 2) & 0x1F)];
/* 387 */         this.buffer[(this.pos++)] = 61;
/* 388 */         this.buffer[(this.pos++)] = 61;
/* 389 */         this.buffer[(this.pos++)] = 61;
/* 390 */         this.buffer[(this.pos++)] = 61;
/* 391 */         this.buffer[(this.pos++)] = 61;
/* 392 */         this.buffer[(this.pos++)] = 61;
/* 393 */         break;
/*     */       case 2:
/* 396 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 11) & 0x1F)];
/* 397 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 6) & 0x1F)];
/* 398 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 1) & 0x1F)];
/* 399 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea << 4) & 0x1F)];
/* 400 */         this.buffer[(this.pos++)] = 61;
/* 401 */         this.buffer[(this.pos++)] = 61;
/* 402 */         this.buffer[(this.pos++)] = 61;
/* 403 */         this.buffer[(this.pos++)] = 61;
/* 404 */         break;
/*     */       case 3:
/* 406 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 19) & 0x1F)];
/* 407 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 14) & 0x1F)];
/* 408 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 9) & 0x1F)];
/* 409 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 4) & 0x1F)];
/* 410 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea << 1) & 0x1F)];
/* 411 */         this.buffer[(this.pos++)] = 61;
/* 412 */         this.buffer[(this.pos++)] = 61;
/* 413 */         this.buffer[(this.pos++)] = 61;
/* 414 */         break;
/*     */       case 4:
/* 416 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 27) & 0x1F)];
/* 417 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 22) & 0x1F)];
/* 418 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 17) & 0x1F)];
/* 419 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 12) & 0x1F)];
/* 420 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 7) & 0x1F)];
/* 421 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 2) & 0x1F)];
/* 422 */         this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea << 3) & 0x1F)];
/* 423 */         this.buffer[(this.pos++)] = 61;
/*     */       }
/*     */ 
/* 426 */       this.currentLinePos += this.pos - savedPos;
/*     */ 
/* 428 */       if ((this.lineLength > 0) && (this.currentLinePos > 0)) {
/* 429 */         System.arraycopy(this.lineSeparator, 0, this.buffer, this.pos, this.lineSeparator.length);
/* 430 */         this.pos += this.lineSeparator.length;
/*     */       }
/*     */     } else {
/* 433 */       for (int i = 0; i < inAvail; i++) {
/* 434 */         ensureBufferSize(this.encodeSize);
/* 435 */         this.modulus = ((this.modulus + 1) % 5);
/* 436 */         int b = in[(inPos++)];
/* 437 */         if (b < 0) {
/* 438 */           b += 256;
/*     */         }
/* 440 */         this.bitWorkArea = ((this.bitWorkArea << 8) + b);
/* 441 */         if (0 == this.modulus) {
/* 442 */           this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 35) & 0x1F)];
/* 443 */           this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 30) & 0x1F)];
/* 444 */           this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 25) & 0x1F)];
/* 445 */           this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 20) & 0x1F)];
/* 446 */           this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 15) & 0x1F)];
/* 447 */           this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 10) & 0x1F)];
/* 448 */           this.buffer[(this.pos++)] = this.encodeTable[((int)(this.bitWorkArea >> 5) & 0x1F)];
/* 449 */           this.buffer[(this.pos++)] = this.encodeTable[((int)this.bitWorkArea & 0x1F)];
/* 450 */           this.currentLinePos += 8;
/* 451 */           if ((this.lineLength > 0) && (this.lineLength <= this.currentLinePos)) {
/* 452 */             System.arraycopy(this.lineSeparator, 0, this.buffer, this.pos, this.lineSeparator.length);
/* 453 */             this.pos += this.lineSeparator.length;
/* 454 */             this.currentLinePos = 0;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isInAlphabet(byte octet)
/*     */   {
/* 469 */     return (octet >= 0) && (octet < this.decodeTable.length) && (this.decodeTable[octet] != -1);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.binary.Base32
 * JD-Core Version:    0.6.0
 */