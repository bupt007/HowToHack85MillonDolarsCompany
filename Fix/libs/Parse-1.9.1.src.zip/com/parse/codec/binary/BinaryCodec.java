/*     */ package com.parse.codec.binary;
/*     */ 
/*     */ import com.parse.codec.BinaryDecoder;
/*     */ import com.parse.codec.BinaryEncoder;
/*     */ import com.parse.codec.DecoderException;
/*     */ import com.parse.codec.EncoderException;
/*     */ 
/*     */ public class BinaryCodec
/*     */   implements BinaryDecoder, BinaryEncoder
/*     */ {
/*  42 */   private static final char[] EMPTY_CHAR_ARRAY = new char[0];
/*     */ 
/*  45 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */   private static final int BIT_0 = 1;
/*     */   private static final int BIT_1 = 2;
/*     */   private static final int BIT_2 = 4;
/*     */   private static final int BIT_3 = 8;
/*     */   private static final int BIT_4 = 16;
/*     */   private static final int BIT_5 = 32;
/*     */   private static final int BIT_6 = 64;
/*     */   private static final int BIT_7 = 128;
/*  71 */   private static final int[] BITS = { 1, 2, 4, 8, 16, 32, 64, 128 };
/*     */ 
/*     */   public byte[] encode(byte[] raw)
/*     */   {
/*  82 */     return toAsciiBytes(raw);
/*     */   }
/*     */ 
/*     */   public Object encode(Object raw)
/*     */     throws EncoderException
/*     */   {
/*  96 */     if (!(raw instanceof byte[])) {
/*  97 */       throw new EncoderException("argument not a byte array");
/*     */     }
/*  99 */     return toAsciiChars((byte[])(byte[])raw);
/*     */   }
/*     */ 
/*     */   public Object decode(Object ascii)
/*     */     throws DecoderException
/*     */   {
/* 113 */     if (ascii == null) {
/* 114 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 116 */     if ((ascii instanceof byte[])) {
/* 117 */       return fromAscii((byte[])(byte[])ascii);
/*     */     }
/* 119 */     if ((ascii instanceof char[])) {
/* 120 */       return fromAscii((char[])(char[])ascii);
/*     */     }
/* 122 */     if ((ascii instanceof String)) {
/* 123 */       return fromAscii(((String)ascii).toCharArray());
/*     */     }
/* 125 */     throw new DecoderException("argument not a byte array");
/*     */   }
/*     */ 
/*     */   public byte[] decode(byte[] ascii)
/*     */   {
/* 137 */     return fromAscii(ascii);
/*     */   }
/*     */ 
/*     */   public byte[] toByteArray(String ascii)
/*     */   {
/* 149 */     if (ascii == null) {
/* 150 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 152 */     return fromAscii(ascii.toCharArray());
/*     */   }
/*     */ 
/*     */   public static byte[] fromAscii(char[] ascii)
/*     */   {
/* 168 */     if ((ascii == null) || (ascii.length == 0)) {
/* 169 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/*     */ 
/* 172 */     byte[] l_raw = new byte[ascii.length >> 3];
/*     */ 
/* 177 */     int ii = 0; for (int jj = ascii.length - 1; ii < l_raw.length; jj -= 8) {
/* 178 */       for (int bits = 0; bits < BITS.length; bits++)
/* 179 */         if (ascii[(jj - bits)] == '1')
/*     */         {
/*     */           int tmp58_57 = ii;
/*     */           byte[] tmp58_56 = l_raw; tmp58_56[tmp58_57] = (byte)(tmp58_56[tmp58_57] | BITS[bits]);
/*     */         }
/* 177 */       ii++;
/*     */     }
/*     */ 
/* 184 */     return l_raw;
/*     */   }
/*     */ 
/*     */   public static byte[] fromAscii(byte[] ascii)
/*     */   {
/* 195 */     if (isEmpty(ascii)) {
/* 196 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/*     */ 
/* 199 */     byte[] l_raw = new byte[ascii.length >> 3];
/*     */ 
/* 204 */     int ii = 0; for (int jj = ascii.length - 1; ii < l_raw.length; jj -= 8) {
/* 205 */       for (int bits = 0; bits < BITS.length; bits++)
/* 206 */         if (ascii[(jj - bits)] == 49)
/*     */         {
/*     */           int tmp56_55 = ii;
/*     */           byte[] tmp56_54 = l_raw; tmp56_54[tmp56_55] = (byte)(tmp56_54[tmp56_55] | BITS[bits]);
/*     */         }
/* 204 */       ii++;
/*     */     }
/*     */ 
/* 211 */     return l_raw;
/*     */   }
/*     */ 
/*     */   private static boolean isEmpty(byte[] array)
/*     */   {
/* 222 */     return (array == null) || (array.length == 0);
/*     */   }
/*     */ 
/*     */   public static byte[] toAsciiBytes(byte[] raw)
/*     */   {
/* 235 */     if (isEmpty(raw)) {
/* 236 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/*     */ 
/* 239 */     byte[] l_ascii = new byte[raw.length << 3];
/*     */ 
/* 244 */     int ii = 0; for (int jj = l_ascii.length - 1; ii < raw.length; jj -= 8) {
/* 245 */       for (int bits = 0; bits < BITS.length; bits++)
/* 246 */         if ((raw[ii] & BITS[bits]) == 0)
/* 247 */           l_ascii[(jj - bits)] = 48;
/*     */         else
/* 249 */           l_ascii[(jj - bits)] = 49;
/* 244 */       ii++;
/*     */     }
/*     */ 
/* 253 */     return l_ascii;
/*     */   }
/*     */ 
/*     */   public static char[] toAsciiChars(byte[] raw)
/*     */   {
/* 265 */     if (isEmpty(raw)) {
/* 266 */       return EMPTY_CHAR_ARRAY;
/*     */     }
/*     */ 
/* 269 */     char[] l_ascii = new char[raw.length << 3];
/*     */ 
/* 274 */     int ii = 0; for (int jj = l_ascii.length - 1; ii < raw.length; jj -= 8) {
/* 275 */       for (int bits = 0; bits < BITS.length; bits++)
/* 276 */         if ((raw[ii] & BITS[bits]) == 0)
/* 277 */           l_ascii[(jj - bits)] = '0';
/*     */         else
/* 279 */           l_ascii[(jj - bits)] = '1';
/* 274 */       ii++;
/*     */     }
/*     */ 
/* 283 */     return l_ascii;
/*     */   }
/*     */ 
/*     */   public static String toAsciiString(byte[] raw)
/*     */   {
/* 295 */     return new String(toAsciiChars(raw));
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.binary.BinaryCodec
 * JD-Core Version:    0.6.0
 */