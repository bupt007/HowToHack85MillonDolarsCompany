/*    */ package com.parse.codec.binary;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class Base32OutputStream extends BaseNCodecOutputStream
/*    */ {
/*    */   public Base32OutputStream(OutputStream out)
/*    */   {
/* 49 */     this(out, true);
/*    */   }
/*    */ 
/*    */   public Base32OutputStream(OutputStream out, boolean doEncode)
/*    */   {
/* 62 */     super(out, new Base32(false), doEncode);
/*    */   }
/*    */ 
/*    */   public Base32OutputStream(OutputStream out, boolean doEncode, int lineLength, byte[] lineSeparator)
/*    */   {
/* 82 */     super(out, new Base32(lineLength, lineSeparator), doEncode);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.binary.Base32OutputStream
 * JD-Core Version:    0.6.0
 */