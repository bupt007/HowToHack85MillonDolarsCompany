/*     */ package com.parse.codec.binary;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class BaseNCodecInputStream extends FilterInputStream
/*     */ {
/*     */   private final boolean doEncode;
/*     */   private final BaseNCodec baseNCodec;
/*  36 */   private final byte[] singleByte = new byte[1];
/*     */ 
/*     */   protected BaseNCodecInputStream(InputStream in, BaseNCodec baseNCodec, boolean doEncode) {
/*  39 */     super(in);
/*  40 */     this.doEncode = doEncode;
/*  41 */     this.baseNCodec = baseNCodec;
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  52 */     int r = read(this.singleByte, 0, 1);
/*  53 */     while (r == 0) {
/*  54 */       r = read(this.singleByte, 0, 1);
/*     */     }
/*  56 */     if (r > 0) {
/*  57 */       return this.singleByte[0] < 0 ? 256 + this.singleByte[0] : this.singleByte[0];
/*     */     }
/*  59 */     return -1;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int offset, int len)
/*     */     throws IOException
/*     */   {
/*  82 */     if (b == null)
/*  83 */       throw new NullPointerException();
/*  84 */     if ((offset < 0) || (len < 0))
/*  85 */       throw new IndexOutOfBoundsException();
/*  86 */     if ((offset > b.length) || (offset + len > b.length))
/*  87 */       throw new IndexOutOfBoundsException();
/*  88 */     if (len == 0) {
/*  89 */       return 0;
/*     */     }
/*  91 */     int readLen = 0;
/*     */ 
/* 108 */     while (readLen == 0) {
/* 109 */       if (!this.baseNCodec.hasData()) {
/* 110 */         byte[] buf = new byte[this.doEncode ? 4096 : 8192];
/* 111 */         int c = this.in.read(buf);
/* 112 */         if (this.doEncode)
/* 113 */           this.baseNCodec.encode(buf, 0, c);
/*     */         else {
/* 115 */           this.baseNCodec.decode(buf, 0, c);
/*     */         }
/*     */       }
/* 118 */       readLen = this.baseNCodec.readResults(b, offset, len);
/*     */     }
/* 120 */     return readLen;
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 129 */     return false;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.binary.BaseNCodecInputStream
 * JD-Core Version:    0.6.0
 */