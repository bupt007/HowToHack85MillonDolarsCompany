/*     */ package com.parse.codec.binary;
/*     */ 
/*     */ import com.parse.codec.BinaryDecoder;
/*     */ import com.parse.codec.BinaryEncoder;
/*     */ import com.parse.codec.DecoderException;
/*     */ import com.parse.codec.EncoderException;
/*     */ 
/*     */ public abstract class BaseNCodec
/*     */   implements BinaryEncoder, BinaryDecoder
/*     */ {
/*     */   public static final int MIME_CHUNK_SIZE = 76;
/*     */   public static final int PEM_CHUNK_SIZE = 64;
/*     */   private static final int DEFAULT_BUFFER_RESIZE_FACTOR = 2;
/*     */   private static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */   protected static final int MASK_8BITS = 255;
/*     */   protected static final byte PAD_DEFAULT = 61;
/*  76 */   protected final byte PAD = 61;
/*     */   private final int unencodedBlockSize;
/*     */   private final int encodedBlockSize;
/*     */   protected final int lineLength;
/*     */   private final int chunkSeparatorLength;
/*     */   protected byte[] buffer;
/*     */   protected int pos;
/*     */   private int readPos;
/*     */   protected boolean eof;
/*     */   protected int currentLinePos;
/*     */   protected int modulus;
/*     */ 
/*     */   protected BaseNCodec(int unencodedBlockSize, int encodedBlockSize, int lineLength, int chunkSeparatorLength)
/*     */   {
/* 138 */     this.unencodedBlockSize = unencodedBlockSize;
/* 139 */     this.encodedBlockSize = encodedBlockSize;
/* 140 */     this.lineLength = ((lineLength > 0) && (chunkSeparatorLength > 0) ? lineLength / encodedBlockSize * encodedBlockSize : 0);
/* 141 */     this.chunkSeparatorLength = chunkSeparatorLength;
/*     */   }
/*     */ 
/*     */   boolean hasData()
/*     */   {
/* 150 */     return this.buffer != null;
/*     */   }
/*     */ 
/*     */   int available()
/*     */   {
/* 159 */     return this.buffer != null ? this.pos - this.readPos : 0;
/*     */   }
/*     */ 
/*     */   protected int getDefaultBufferSize()
/*     */   {
/* 168 */     return 8192;
/*     */   }
/*     */ 
/*     */   private void resizeBuffer()
/*     */   {
/* 173 */     if (this.buffer == null) {
/* 174 */       this.buffer = new byte[getDefaultBufferSize()];
/* 175 */       this.pos = 0;
/* 176 */       this.readPos = 0;
/*     */     } else {
/* 178 */       byte[] b = new byte[this.buffer.length * 2];
/* 179 */       System.arraycopy(this.buffer, 0, b, 0, this.buffer.length);
/* 180 */       this.buffer = b;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void ensureBufferSize(int size)
/*     */   {
/* 190 */     if ((this.buffer == null) || (this.buffer.length < this.pos + size))
/* 191 */       resizeBuffer();
/*     */   }
/*     */ 
/*     */   int readResults(byte[] b, int bPos, int bAvail)
/*     */   {
/* 208 */     if (this.buffer != null) {
/* 209 */       int len = Math.min(available(), bAvail);
/* 210 */       System.arraycopy(this.buffer, this.readPos, b, bPos, len);
/* 211 */       this.readPos += len;
/* 212 */       if (this.readPos >= this.pos) {
/* 213 */         this.buffer = null;
/*     */       }
/* 215 */       return len;
/*     */     }
/* 217 */     return this.eof ? -1 : 0;
/*     */   }
/*     */ 
/*     */   protected static boolean isWhiteSpace(byte byteToCheck)
/*     */   {
/* 228 */     switch (byteToCheck) {
/*     */     case 9:
/*     */     case 10:
/*     */     case 13:
/*     */     case 32:
/* 233 */       return true;
/*     */     }
/* 235 */     return false;
/*     */   }
/*     */ 
/*     */   private void reset()
/*     */   {
/* 243 */     this.buffer = null;
/* 244 */     this.pos = 0;
/* 245 */     this.readPos = 0;
/* 246 */     this.currentLinePos = 0;
/* 247 */     this.modulus = 0;
/* 248 */     this.eof = false;
/*     */   }
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 262 */     if (!(pObject instanceof byte[])) {
/* 263 */       throw new EncoderException("Parameter supplied to Base-N encode is not a byte[]");
/*     */     }
/* 265 */     return encode((byte[])(byte[])pObject);
/*     */   }
/*     */ 
/*     */   public String encodeToString(byte[] pArray)
/*     */   {
/* 276 */     return StringUtils.newStringUtf8(encode(pArray));
/*     */   }
/*     */ 
/*     */   public Object decode(Object pObject)
/*     */     throws DecoderException
/*     */   {
/* 290 */     if ((pObject instanceof byte[]))
/* 291 */       return decode((byte[])(byte[])pObject);
/* 292 */     if ((pObject instanceof String)) {
/* 293 */       return decode((String)pObject);
/*     */     }
/* 295 */     throw new DecoderException("Parameter supplied to Base-N decode is not a byte[] or a String");
/*     */   }
/*     */ 
/*     */   public byte[] decode(String pArray)
/*     */   {
/* 307 */     return decode(StringUtils.getBytesUtf8(pArray));
/*     */   }
/*     */ 
/*     */   public byte[] decode(byte[] pArray)
/*     */   {
/* 318 */     reset();
/* 319 */     if ((pArray == null) || (pArray.length == 0)) {
/* 320 */       return pArray;
/*     */     }
/* 322 */     decode(pArray, 0, pArray.length);
/* 323 */     decode(pArray, 0, -1);
/* 324 */     byte[] result = new byte[this.pos];
/* 325 */     readResults(result, 0, result.length);
/* 326 */     return result;
/*     */   }
/*     */ 
/*     */   public byte[] encode(byte[] pArray)
/*     */   {
/* 337 */     reset();
/* 338 */     if ((pArray == null) || (pArray.length == 0)) {
/* 339 */       return pArray;
/*     */     }
/* 341 */     encode(pArray, 0, pArray.length);
/* 342 */     encode(pArray, 0, -1);
/* 343 */     byte[] buf = new byte[this.pos - this.readPos];
/* 344 */     readResults(buf, 0, buf.length);
/* 345 */     return buf;
/*     */   }
/*     */ 
/*     */   public String encodeAsString(byte[] pArray)
/*     */   {
/* 356 */     return StringUtils.newStringUtf8(encode(pArray));
/*     */   }
/*     */ 
/*     */   abstract void encode(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*     */ 
/*     */   abstract void decode(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*     */ 
/*     */   protected abstract boolean isInAlphabet(byte paramByte);
/*     */ 
/*     */   public boolean isInAlphabet(byte[] arrayOctet, boolean allowWSPad)
/*     */   {
/* 384 */     for (int i = 0; i < arrayOctet.length; i++) {
/* 385 */       if ((!isInAlphabet(arrayOctet[i])) && ((!allowWSPad) || ((arrayOctet[i] != 61) && (!isWhiteSpace(arrayOctet[i])))))
/*     */       {
/* 387 */         return false;
/*     */       }
/*     */     }
/* 390 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isInAlphabet(String basen)
/*     */   {
/* 403 */     return isInAlphabet(StringUtils.getBytesUtf8(basen), true);
/*     */   }
/*     */ 
/*     */   protected boolean containsAlphabetOrPad(byte[] arrayOctet)
/*     */   {
/* 416 */     if (arrayOctet == null) {
/* 417 */       return false;
/*     */     }
/* 419 */     for (int i = 0; i < arrayOctet.length; i++) {
/* 420 */       if ((61 == arrayOctet[i]) || (isInAlphabet(arrayOctet[i]))) {
/* 421 */         return true;
/*     */       }
/*     */     }
/* 424 */     return false;
/*     */   }
/*     */ 
/*     */   public long getEncodedLength(byte[] pArray)
/*     */   {
/* 438 */     long len = (pArray.length + this.unencodedBlockSize - 1) / this.unencodedBlockSize * this.encodedBlockSize;
/* 439 */     if (this.lineLength > 0)
/*     */     {
/* 441 */       len += (len + this.lineLength - 1L) / this.lineLength * this.chunkSeparatorLength;
/*     */     }
/* 443 */     return len;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.binary.BaseNCodec
 * JD-Core Version:    0.6.0
 */