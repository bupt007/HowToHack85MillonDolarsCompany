/*    */ package com.parse.codec.binary;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public class Base64InputStream extends BaseNCodecInputStream
/*    */ {
/*    */   public Base64InputStream(InputStream in)
/*    */   {
/* 54 */     this(in, false);
/*    */   }
/*    */ 
/*    */   public Base64InputStream(InputStream in, boolean doEncode)
/*    */   {
/* 67 */     super(in, new Base64(false), doEncode);
/*    */   }
/*    */ 
/*    */   public Base64InputStream(InputStream in, boolean doEncode, int lineLength, byte[] lineSeparator)
/*    */   {
/* 87 */     super(in, new Base64(lineLength, lineSeparator), doEncode);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.binary.Base64InputStream
 * JD-Core Version:    0.6.0
 */