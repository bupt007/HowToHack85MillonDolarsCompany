/*    */ package com.parse.codec.binary;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class Base64OutputStream extends BaseNCodecOutputStream
/*    */ {
/*    */   public Base64OutputStream(OutputStream out)
/*    */   {
/* 54 */     this(out, true);
/*    */   }
/*    */ 
/*    */   public Base64OutputStream(OutputStream out, boolean doEncode)
/*    */   {
/* 67 */     super(out, new Base64(false), doEncode);
/*    */   }
/*    */ 
/*    */   public Base64OutputStream(OutputStream out, boolean doEncode, int lineLength, byte[] lineSeparator)
/*    */   {
/* 87 */     super(out, new Base64(lineLength, lineSeparator), doEncode);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.binary.Base64OutputStream
 * JD-Core Version:    0.6.0
 */