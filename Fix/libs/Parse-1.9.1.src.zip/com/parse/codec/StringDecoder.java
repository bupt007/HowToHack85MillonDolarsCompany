package com.parse.codec;

public abstract interface StringDecoder extends Decoder
{
  public abstract String decode(String paramString)
    throws DecoderException;
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.StringDecoder
 * JD-Core Version:    0.6.0
 */