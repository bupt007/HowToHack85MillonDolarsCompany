/*     */ package com.parse.codec.language;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class Caverphone2 extends AbstractCaverphone
/*     */ {
/*     */   private static final String TEN_1 = "1111111111";
/*     */ 
/*     */   public String encode(String source)
/*     */   {
/*  45 */     String txt = source;
/*  46 */     if ((txt == null) || (txt.length() == 0)) {
/*  47 */       return "1111111111";
/*     */     }
/*     */ 
/*  51 */     txt = txt.toLowerCase(Locale.ENGLISH);
/*     */ 
/*  54 */     txt = txt.replaceAll("[^a-z]", "");
/*     */ 
/*  57 */     txt = txt.replaceAll("e$", "");
/*     */ 
/*  60 */     txt = txt.replaceAll("^cough", "cou2f");
/*  61 */     txt = txt.replaceAll("^rough", "rou2f");
/*  62 */     txt = txt.replaceAll("^tough", "tou2f");
/*  63 */     txt = txt.replaceAll("^enough", "enou2f");
/*  64 */     txt = txt.replaceAll("^trough", "trou2f");
/*  65 */     txt = txt.replaceAll("^gn", "2n");
/*     */ 
/*  68 */     txt = txt.replaceAll("mb$", "m2");
/*     */ 
/*  71 */     txt = txt.replaceAll("cq", "2q");
/*  72 */     txt = txt.replaceAll("ci", "si");
/*  73 */     txt = txt.replaceAll("ce", "se");
/*  74 */     txt = txt.replaceAll("cy", "sy");
/*  75 */     txt = txt.replaceAll("tch", "2ch");
/*  76 */     txt = txt.replaceAll("c", "k");
/*  77 */     txt = txt.replaceAll("q", "k");
/*  78 */     txt = txt.replaceAll("x", "k");
/*  79 */     txt = txt.replaceAll("v", "f");
/*  80 */     txt = txt.replaceAll("dg", "2g");
/*  81 */     txt = txt.replaceAll("tio", "sio");
/*  82 */     txt = txt.replaceAll("tia", "sia");
/*  83 */     txt = txt.replaceAll("d", "t");
/*  84 */     txt = txt.replaceAll("ph", "fh");
/*  85 */     txt = txt.replaceAll("b", "p");
/*  86 */     txt = txt.replaceAll("sh", "s2");
/*  87 */     txt = txt.replaceAll("z", "s");
/*  88 */     txt = txt.replaceAll("^[aeiou]", "A");
/*  89 */     txt = txt.replaceAll("[aeiou]", "3");
/*  90 */     txt = txt.replaceAll("j", "y");
/*  91 */     txt = txt.replaceAll("^y3", "Y3");
/*  92 */     txt = txt.replaceAll("^y", "A");
/*  93 */     txt = txt.replaceAll("y", "3");
/*  94 */     txt = txt.replaceAll("3gh3", "3kh3");
/*  95 */     txt = txt.replaceAll("gh", "22");
/*  96 */     txt = txt.replaceAll("g", "k");
/*  97 */     txt = txt.replaceAll("s+", "S");
/*  98 */     txt = txt.replaceAll("t+", "T");
/*  99 */     txt = txt.replaceAll("p+", "P");
/* 100 */     txt = txt.replaceAll("k+", "K");
/* 101 */     txt = txt.replaceAll("f+", "F");
/* 102 */     txt = txt.replaceAll("m+", "M");
/* 103 */     txt = txt.replaceAll("n+", "N");
/* 104 */     txt = txt.replaceAll("w3", "W3");
/* 105 */     txt = txt.replaceAll("wh3", "Wh3");
/* 106 */     txt = txt.replaceAll("w$", "3");
/* 107 */     txt = txt.replaceAll("w", "2");
/* 108 */     txt = txt.replaceAll("^h", "A");
/* 109 */     txt = txt.replaceAll("h", "2");
/* 110 */     txt = txt.replaceAll("r3", "R3");
/* 111 */     txt = txt.replaceAll("r$", "3");
/* 112 */     txt = txt.replaceAll("r", "2");
/* 113 */     txt = txt.replaceAll("l3", "L3");
/* 114 */     txt = txt.replaceAll("l$", "3");
/* 115 */     txt = txt.replaceAll("l", "2");
/*     */ 
/* 118 */     txt = txt.replaceAll("2", "");
/* 119 */     txt = txt.replaceAll("3$", "A");
/* 120 */     txt = txt.replaceAll("3", "");
/*     */ 
/* 123 */     txt = txt + "1111111111";
/*     */ 
/* 126 */     return txt.substring(0, "1111111111".length());
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.language.Caverphone2
 * JD-Core Version:    0.6.0
 */