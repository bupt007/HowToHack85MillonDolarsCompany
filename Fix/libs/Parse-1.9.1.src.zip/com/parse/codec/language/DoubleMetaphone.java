/*      */ package com.parse.codec.language;
/*      */ 
/*      */ import com.parse.codec.EncoderException;
/*      */ import com.parse.codec.StringEncoder;
/*      */ import java.util.Locale;
/*      */ 
/*      */ public class DoubleMetaphone
/*      */   implements StringEncoder
/*      */ {
/*      */   private static final String VOWELS = "AEIOUY";
/*   48 */   private static final String[] SILENT_START = { "GN", "KN", "PN", "WR", "PS" };
/*      */ 
/*   50 */   private static final String[] L_R_N_M_B_H_F_V_W_SPACE = { "L", "R", "N", "M", "B", "H", "F", "V", "W", " " };
/*      */ 
/*   52 */   private static final String[] ES_EP_EB_EL_EY_IB_IL_IN_IE_EI_ER = { "ES", "EP", "EB", "EL", "EY", "IB", "IL", "IN", "IE", "EI", "ER" };
/*      */ 
/*   54 */   private static final String[] L_T_K_S_N_M_B_Z = { "L", "T", "K", "S", "N", "M", "B", "Z" };
/*      */ 
/*   60 */   private int maxCodeLen = 4;
/*      */ 
/*      */   public String doubleMetaphone(String value)
/*      */   {
/*   76 */     return doubleMetaphone(value, false);
/*      */   }
/*      */ 
/*      */   public String doubleMetaphone(String value, boolean alternate)
/*      */   {
/*   88 */     value = cleanInput(value);
/*   89 */     if (value == null) {
/*   90 */       return null;
/*      */     }
/*      */ 
/*   93 */     boolean slavoGermanic = isSlavoGermanic(value);
/*   94 */     int index = isSilentStart(value) ? 1 : 0;
/*      */ 
/*   96 */     DoubleMetaphoneResult result = new DoubleMetaphoneResult(getMaxCodeLen());
/*      */ 
/*   98 */     while ((!result.isComplete()) && (index <= value.length() - 1)) {
/*   99 */       switch (value.charAt(index)) {
/*      */       case 'A':
/*      */       case 'E':
/*      */       case 'I':
/*      */       case 'O':
/*      */       case 'U':
/*      */       case 'Y':
/*  106 */         index = handleAEIOUY(result, index);
/*  107 */         break;
/*      */       case 'B':
/*  109 */         result.append('P');
/*  110 */         index = charAt(value, index + 1) == 'B' ? index + 2 : index + 1;
/*  111 */         break;
/*      */       case 'Ç':
/*  114 */         result.append('S');
/*  115 */         index++;
/*  116 */         break;
/*      */       case 'C':
/*  118 */         index = handleC(value, result, index);
/*  119 */         break;
/*      */       case 'D':
/*  121 */         index = handleD(value, result, index);
/*  122 */         break;
/*      */       case 'F':
/*  124 */         result.append('F');
/*  125 */         index = charAt(value, index + 1) == 'F' ? index + 2 : index + 1;
/*  126 */         break;
/*      */       case 'G':
/*  128 */         index = handleG(value, result, index, slavoGermanic);
/*  129 */         break;
/*      */       case 'H':
/*  131 */         index = handleH(value, result, index);
/*  132 */         break;
/*      */       case 'J':
/*  134 */         index = handleJ(value, result, index, slavoGermanic);
/*  135 */         break;
/*      */       case 'K':
/*  137 */         result.append('K');
/*  138 */         index = charAt(value, index + 1) == 'K' ? index + 2 : index + 1;
/*  139 */         break;
/*      */       case 'L':
/*  141 */         index = handleL(value, result, index);
/*  142 */         break;
/*      */       case 'M':
/*  144 */         result.append('M');
/*  145 */         index = conditionM0(value, index) ? index + 2 : index + 1;
/*  146 */         break;
/*      */       case 'N':
/*  148 */         result.append('N');
/*  149 */         index = charAt(value, index + 1) == 'N' ? index + 2 : index + 1;
/*  150 */         break;
/*      */       case 'Ñ':
/*  153 */         result.append('N');
/*  154 */         index++;
/*  155 */         break;
/*      */       case 'P':
/*  157 */         index = handleP(value, result, index);
/*  158 */         break;
/*      */       case 'Q':
/*  160 */         result.append('K');
/*  161 */         index = charAt(value, index + 1) == 'Q' ? index + 2 : index + 1;
/*  162 */         break;
/*      */       case 'R':
/*  164 */         index = handleR(value, result, index, slavoGermanic);
/*  165 */         break;
/*      */       case 'S':
/*  167 */         index = handleS(value, result, index, slavoGermanic);
/*  168 */         break;
/*      */       case 'T':
/*  170 */         index = handleT(value, result, index);
/*  171 */         break;
/*      */       case 'V':
/*  173 */         result.append('F');
/*  174 */         index = charAt(value, index + 1) == 'V' ? index + 2 : index + 1;
/*  175 */         break;
/*      */       case 'W':
/*  177 */         index = handleW(value, result, index);
/*  178 */         break;
/*      */       case 'X':
/*  180 */         index = handleX(value, result, index);
/*  181 */         break;
/*      */       case 'Z':
/*  183 */         index = handleZ(value, result, index, slavoGermanic);
/*  184 */         break;
/*      */       default:
/*  186 */         index++;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  191 */     return alternate ? result.getAlternate() : result.getPrimary();
/*      */   }
/*      */ 
/*      */   public Object encode(Object obj)
/*      */     throws EncoderException
/*      */   {
/*  203 */     if (!(obj instanceof String)) {
/*  204 */       throw new EncoderException("DoubleMetaphone encode parameter is not of type String");
/*      */     }
/*  206 */     return doubleMetaphone((String)obj);
/*      */   }
/*      */ 
/*      */   public String encode(String value)
/*      */   {
/*  216 */     return doubleMetaphone(value);
/*      */   }
/*      */ 
/*      */   public boolean isDoubleMetaphoneEqual(String value1, String value2)
/*      */   {
/*  230 */     return isDoubleMetaphoneEqual(value1, value2, false);
/*      */   }
/*      */ 
/*      */   public boolean isDoubleMetaphoneEqual(String value1, String value2, boolean alternate)
/*      */   {
/*  246 */     return doubleMetaphone(value1, alternate).equals(doubleMetaphone(value2, alternate));
/*      */   }
/*      */ 
/*      */   public int getMaxCodeLen()
/*      */   {
/*  255 */     return this.maxCodeLen;
/*      */   }
/*      */ 
/*      */   public void setMaxCodeLen(int maxCodeLen)
/*      */   {
/*  263 */     this.maxCodeLen = maxCodeLen;
/*      */   }
/*      */ 
/*      */   private int handleAEIOUY(DoubleMetaphoneResult result, int index)
/*      */   {
/*  273 */     if (index == 0) {
/*  274 */       result.append('A');
/*      */     }
/*  276 */     return index + 1;
/*      */   }
/*      */ 
/*      */   private int handleC(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  285 */     if (conditionC0(value, index)) {
/*  286 */       result.append('K');
/*  287 */       index += 2;
/*  288 */     } else if ((index == 0) && (contains(value, index, 6, "CAESAR"))) {
/*  289 */       result.append('S');
/*  290 */       index += 2;
/*  291 */     } else if (contains(value, index, 2, "CH")) {
/*  292 */       index = handleCH(value, result, index);
/*  293 */     } else if ((contains(value, index, 2, "CZ")) && (!contains(value, index - 2, 4, "WICZ")))
/*      */     {
/*  296 */       result.append('S', 'X');
/*  297 */       index += 2;
/*  298 */     } else if (contains(value, index + 1, 3, "CIA"))
/*      */     {
/*  300 */       result.append('X');
/*  301 */       index += 3; } else {
/*  302 */       if ((contains(value, index, 2, "CC")) && ((index != 1) || (charAt(value, 0) != 'M')))
/*      */       {
/*  305 */         return handleCC(value, result, index);
/*  306 */       }if (contains(value, index, 2, "CK", "CG", "CQ")) {
/*  307 */         result.append('K');
/*  308 */         index += 2;
/*  309 */       } else if (contains(value, index, 2, "CI", "CE", "CY"))
/*      */       {
/*  311 */         if (contains(value, index, 3, "CIO", "CIE", "CIA"))
/*  312 */           result.append('S', 'X');
/*      */         else {
/*  314 */           result.append('S');
/*      */         }
/*  316 */         index += 2;
/*      */       } else {
/*  318 */         result.append('K');
/*  319 */         if (contains(value, index + 1, 2, " C", " Q", " G"))
/*      */         {
/*  321 */           index += 3;
/*  322 */         } else if ((contains(value, index + 1, 1, "C", "K", "Q")) && (!contains(value, index + 1, 2, "CE", "CI")))
/*      */         {
/*  324 */           index += 2;
/*      */         }
/*  326 */         else index++;
/*      */       }
/*      */     }
/*      */ 
/*  330 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleCC(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  339 */     if ((contains(value, index + 2, 1, "I", "E", "H")) && (!contains(value, index + 2, 2, "HU")))
/*      */     {
/*  342 */       if (((index == 1) && (charAt(value, index - 1) == 'A')) || (contains(value, index - 1, 5, "UCCEE", "UCCES")))
/*      */       {
/*  345 */         result.append("KS");
/*      */       }
/*      */       else {
/*  348 */         result.append('X');
/*      */       }
/*  350 */       index += 3;
/*      */     } else {
/*  352 */       result.append('K');
/*  353 */       index += 2;
/*      */     }
/*      */ 
/*  356 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleCH(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  365 */     if ((index > 0) && (contains(value, index, 4, "CHAE"))) {
/*  366 */       result.append('K', 'X');
/*  367 */       return index + 2;
/*  368 */     }if (conditionCH0(value, index))
/*      */     {
/*  370 */       result.append('K');
/*  371 */       return index + 2;
/*  372 */     }if (conditionCH1(value, index))
/*      */     {
/*  374 */       result.append('K');
/*  375 */       return index + 2;
/*      */     }
/*  377 */     if (index > 0) {
/*  378 */       if (contains(value, 0, 2, "MC"))
/*  379 */         result.append('K');
/*      */       else
/*  381 */         result.append('X', 'K');
/*      */     }
/*      */     else {
/*  384 */       result.append('X');
/*      */     }
/*  386 */     return index + 2;
/*      */   }
/*      */ 
/*      */   private int handleD(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  396 */     if (contains(value, index, 2, "DG"))
/*      */     {
/*  398 */       if (contains(value, index + 2, 1, "I", "E", "Y")) {
/*  399 */         result.append('J');
/*  400 */         index += 3;
/*      */       }
/*      */       else {
/*  403 */         result.append("TK");
/*  404 */         index += 2;
/*      */       }
/*  406 */     } else if (contains(value, index, 2, "DT", "DD")) {
/*  407 */       result.append('T');
/*  408 */       index += 2;
/*      */     } else {
/*  410 */       result.append('T');
/*  411 */       index++;
/*      */     }
/*  413 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleG(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic)
/*      */   {
/*  423 */     if (charAt(value, index + 1) == 'H') {
/*  424 */       index = handleGH(value, result, index);
/*  425 */     } else if (charAt(value, index + 1) == 'N') {
/*  426 */       if ((index == 1) && (isVowel(charAt(value, 0))) && (!slavoGermanic))
/*  427 */         result.append("KN", "N");
/*  428 */       else if ((!contains(value, index + 2, 2, "EY")) && (charAt(value, index + 1) != 'Y') && (!slavoGermanic))
/*      */       {
/*  430 */         result.append("N", "KN");
/*      */       }
/*  432 */       else result.append("KN");
/*      */ 
/*  434 */       index += 2;
/*  435 */     } else if ((contains(value, index + 1, 2, "LI")) && (!slavoGermanic)) {
/*  436 */       result.append("KL", "L");
/*  437 */       index += 2;
/*  438 */     } else if ((index == 0) && ((charAt(value, index + 1) == 'Y') || (contains(value, index + 1, 2, ES_EP_EB_EL_EY_IB_IL_IN_IE_EI_ER))))
/*      */     {
/*  440 */       result.append('K', 'J');
/*  441 */       index += 2;
/*  442 */     } else if (((contains(value, index + 1, 2, "ER")) || (charAt(value, index + 1) == 'Y')) && (!contains(value, 0, 6, "DANGER", "RANGER", "MANGER")) && (!contains(value, index - 1, 1, "E", "I")) && (!contains(value, index - 1, 3, "RGY", "OGY")))
/*      */     {
/*  448 */       result.append('K', 'J');
/*  449 */       index += 2;
/*  450 */     } else if ((contains(value, index + 1, 1, "E", "I", "Y")) || (contains(value, index - 1, 4, "AGGI", "OGGI")))
/*      */     {
/*  453 */       if ((contains(value, 0, 4, "VAN ", "VON ")) || (contains(value, 0, 3, "SCH")) || (contains(value, index + 1, 2, "ET")))
/*      */       {
/*  455 */         result.append('K');
/*  456 */       } else if (contains(value, index + 1, 3, "IER"))
/*  457 */         result.append('J');
/*      */       else {
/*  459 */         result.append('J', 'K');
/*      */       }
/*  461 */       index += 2;
/*  462 */     } else if (charAt(value, index + 1) == 'G') {
/*  463 */       index += 2;
/*  464 */       result.append('K');
/*      */     } else {
/*  466 */       index++;
/*  467 */       result.append('K');
/*      */     }
/*  469 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleGH(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  478 */     if ((index > 0) && (!isVowel(charAt(value, index - 1)))) {
/*  479 */       result.append('K');
/*  480 */       index += 2;
/*  481 */     } else if (index == 0) {
/*  482 */       if (charAt(value, index + 2) == 'I')
/*  483 */         result.append('J');
/*      */       else {
/*  485 */         result.append('K');
/*      */       }
/*  487 */       index += 2;
/*  488 */     } else if (((index > 1) && (contains(value, index - 2, 1, "B", "H", "D"))) || ((index > 2) && (contains(value, index - 3, 1, "B", "H", "D"))) || ((index > 3) && (contains(value, index - 4, 1, "B", "H"))))
/*      */     {
/*  492 */       index += 2;
/*      */     } else {
/*  494 */       if ((index > 2) && (charAt(value, index - 1) == 'U') && (contains(value, index - 3, 1, "C", "G", "L", "R", "T")))
/*      */       {
/*  497 */         result.append('F');
/*  498 */       } else if ((index > 0) && (charAt(value, index - 1) != 'I')) {
/*  499 */         result.append('K');
/*      */       }
/*  501 */       index += 2;
/*      */     }
/*  503 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleH(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  513 */     if (((index == 0) || (isVowel(charAt(value, index - 1)))) && (isVowel(charAt(value, index + 1))))
/*      */     {
/*  515 */       result.append('H');
/*  516 */       index += 2;
/*      */     }
/*      */     else {
/*  519 */       index++;
/*      */     }
/*  521 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleJ(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic)
/*      */   {
/*  529 */     if ((contains(value, index, 4, "JOSE")) || (contains(value, 0, 4, "SAN ")))
/*      */     {
/*  531 */       if (((index == 0) && (charAt(value, index + 4) == ' ')) || (value.length() == 4) || (contains(value, 0, 4, "SAN ")))
/*      */       {
/*  533 */         result.append('H');
/*      */       }
/*  535 */       else result.append('J', 'H');
/*      */ 
/*  537 */       index++;
/*      */     } else {
/*  539 */       if ((index == 0) && (!contains(value, index, 4, "JOSE")))
/*  540 */         result.append('J', 'A');
/*  541 */       else if ((isVowel(charAt(value, index - 1))) && (!slavoGermanic) && ((charAt(value, index + 1) == 'A') || (charAt(value, index + 1) == 'O')))
/*      */       {
/*  543 */         result.append('J', 'H');
/*  544 */       } else if (index == value.length() - 1)
/*  545 */         result.append('J', ' ');
/*  546 */       else if ((!contains(value, index + 1, 1, L_T_K_S_N_M_B_Z)) && (!contains(value, index - 1, 1, "S", "K", "L"))) {
/*  547 */         result.append('J');
/*      */       }
/*      */ 
/*  550 */       if (charAt(value, index + 1) == 'J')
/*  551 */         index += 2;
/*      */       else {
/*  553 */         index++;
/*      */       }
/*      */     }
/*  556 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleL(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  565 */     if (charAt(value, index + 1) == 'L') {
/*  566 */       if (conditionL0(value, index))
/*  567 */         result.appendPrimary('L');
/*      */       else {
/*  569 */         result.append('L');
/*      */       }
/*  571 */       index += 2;
/*      */     } else {
/*  573 */       index++;
/*  574 */       result.append('L');
/*      */     }
/*  576 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleP(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  585 */     if (charAt(value, index + 1) == 'H') {
/*  586 */       result.append('F');
/*  587 */       index += 2;
/*      */     } else {
/*  589 */       result.append('P');
/*  590 */       index = contains(value, index + 1, 1, "P", "B") ? index + 2 : index + 1;
/*      */     }
/*  592 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleR(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic)
/*      */   {
/*  602 */     if ((index == value.length() - 1) && (!slavoGermanic) && (contains(value, index - 2, 2, "IE")) && (!contains(value, index - 4, 2, "ME", "MA")))
/*      */     {
/*  605 */       result.appendAlternate('R');
/*      */     }
/*  607 */     else result.append('R');
/*      */ 
/*  609 */     return charAt(value, index + 1) == 'R' ? index + 2 : index + 1;
/*      */   }
/*      */ 
/*      */   private int handleS(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic)
/*      */   {
/*  619 */     if (contains(value, index - 1, 3, "ISL", "YSL"))
/*      */     {
/*  621 */       index++;
/*  622 */     } else if ((index == 0) && (contains(value, index, 5, "SUGAR")))
/*      */     {
/*  624 */       result.append('X', 'S');
/*  625 */       index++;
/*  626 */     } else if (contains(value, index, 2, "SH")) {
/*  627 */       if (contains(value, index + 1, 4, "HEIM", "HOEK", "HOLM", "HOLZ"))
/*      */       {
/*  630 */         result.append('S');
/*      */       }
/*  632 */       else result.append('X');
/*      */ 
/*  634 */       index += 2;
/*  635 */     } else if ((contains(value, index, 3, "SIO", "SIA")) || (contains(value, index, 4, "SIAN")))
/*      */     {
/*  637 */       if (slavoGermanic)
/*  638 */         result.append('S');
/*      */       else {
/*  640 */         result.append('S', 'X');
/*      */       }
/*  642 */       index += 3;
/*  643 */     } else if (((index == 0) && (contains(value, index + 1, 1, "M", "N", "L", "W"))) || (contains(value, index + 1, 1, "Z")))
/*      */     {
/*  648 */       result.append('S', 'X');
/*  649 */       index = contains(value, index + 1, 1, "Z") ? index + 2 : index + 1;
/*  650 */     } else if (contains(value, index, 2, "SC")) {
/*  651 */       index = handleSC(value, result, index);
/*      */     } else {
/*  653 */       if ((index == value.length() - 1) && (contains(value, index - 2, 2, "AI", "OI")))
/*      */       {
/*  656 */         result.appendAlternate('S');
/*      */       }
/*  658 */       else result.append('S');
/*      */ 
/*  660 */       index = contains(value, index + 1, 1, "S", "Z") ? index + 2 : index + 1;
/*      */     }
/*  662 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleSC(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  671 */     if (charAt(value, index + 2) == 'H')
/*      */     {
/*  673 */       if (contains(value, index + 3, 2, "OO", "ER", "EN", "UY", "ED", "EM"))
/*      */       {
/*  676 */         if (contains(value, index + 3, 2, "ER", "EN"))
/*      */         {
/*  678 */           result.append("X", "SK");
/*      */         }
/*  680 */         else result.append("SK");
/*      */ 
/*      */       }
/*  683 */       else if ((index == 0) && (!isVowel(charAt(value, 3))) && (charAt(value, 3) != 'W'))
/*  684 */         result.append('X', 'S');
/*      */       else {
/*  686 */         result.append('X');
/*      */       }
/*      */     }
/*  689 */     else if (contains(value, index + 2, 1, "I", "E", "Y"))
/*  690 */       result.append('S');
/*      */     else {
/*  692 */       result.append("SK");
/*      */     }
/*  694 */     return index + 3;
/*      */   }
/*      */ 
/*      */   private int handleT(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  703 */     if (contains(value, index, 4, "TION")) {
/*  704 */       result.append('X');
/*  705 */       index += 3;
/*  706 */     } else if (contains(value, index, 3, "TIA", "TCH")) {
/*  707 */       result.append('X');
/*  708 */       index += 3;
/*  709 */     } else if ((contains(value, index, 2, "TH")) || (contains(value, index, 3, "TTH")))
/*      */     {
/*  711 */       if ((contains(value, index + 2, 2, "OM", "AM")) || (contains(value, 0, 4, "VAN ", "VON ")) || (contains(value, 0, 3, "SCH")))
/*      */       {
/*  715 */         result.append('T');
/*      */       }
/*  717 */       else result.append('0', 'T');
/*      */ 
/*  719 */       index += 2;
/*      */     } else {
/*  721 */       result.append('T');
/*  722 */       index = contains(value, index + 1, 1, "T", "D") ? index + 2 : index + 1;
/*      */     }
/*  724 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleW(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  733 */     if (contains(value, index, 2, "WR"))
/*      */     {
/*  735 */       result.append('R');
/*  736 */       index += 2;
/*      */     }
/*  738 */     else if ((index == 0) && ((isVowel(charAt(value, index + 1))) || (contains(value, index, 2, "WH"))))
/*      */     {
/*  740 */       if (isVowel(charAt(value, index + 1)))
/*      */       {
/*  742 */         result.append('A', 'F');
/*      */       }
/*      */       else {
/*  745 */         result.append('A');
/*      */       }
/*  747 */       index++;
/*  748 */     } else if (((index == value.length() - 1) && (isVowel(charAt(value, index - 1)))) || (contains(value, index - 1, 5, "EWSKI", "EWSKY", "OWSKI", "OWSKY")) || (contains(value, 0, 3, "SCH")))
/*      */     {
/*  753 */       result.appendAlternate('F');
/*  754 */       index++;
/*  755 */     } else if (contains(value, index, 4, "WICZ", "WITZ"))
/*      */     {
/*  757 */       result.append("TS", "FX");
/*  758 */       index += 4;
/*      */     } else {
/*  760 */       index++;
/*      */     }
/*      */ 
/*  763 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleX(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  772 */     if (index == 0) {
/*  773 */       result.append('S');
/*  774 */       index++;
/*      */     } else {
/*  776 */       if ((index != value.length() - 1) || ((!contains(value, index - 3, 3, "IAU", "EAU")) && (!contains(value, index - 2, 2, "AU", "OU"))))
/*      */       {
/*  780 */         result.append("KS");
/*      */       }
/*  782 */       index = contains(value, index + 1, 1, "C", "X") ? index + 2 : index + 1;
/*      */     }
/*  784 */     return index;
/*      */   }
/*      */ 
/*      */   private int handleZ(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic)
/*      */   {
/*  792 */     if (charAt(value, index + 1) == 'H')
/*      */     {
/*  794 */       result.append('J');
/*  795 */       index += 2;
/*      */     } else {
/*  797 */       if ((contains(value, index + 1, 2, "ZO", "ZI", "ZA")) || ((slavoGermanic) && (index > 0) && (charAt(value, index - 1) != 'T')))
/*  798 */         result.append("S", "TS");
/*      */       else {
/*  800 */         result.append('S');
/*      */       }
/*  802 */       index = charAt(value, index + 1) == 'Z' ? index + 2 : index + 1;
/*      */     }
/*  804 */     return index;
/*      */   }
/*      */ 
/*      */   private boolean conditionC0(String value, int index)
/*      */   {
/*  813 */     if (contains(value, index, 4, "CHIA"))
/*  814 */       return true;
/*  815 */     if (index <= 1)
/*  816 */       return false;
/*  817 */     if (isVowel(charAt(value, index - 2)))
/*  818 */       return false;
/*  819 */     if (!contains(value, index - 1, 3, "ACH")) {
/*  820 */       return false;
/*      */     }
/*  822 */     char c = charAt(value, index + 2);
/*  823 */     return ((c != 'I') && (c != 'E')) || (contains(value, index - 2, 6, "BACHER", "MACHER"));
/*      */   }
/*      */ 
/*      */   private boolean conditionCH0(String value, int index)
/*      */   {
/*  832 */     if (index != 0)
/*  833 */       return false;
/*  834 */     if ((!contains(value, index + 1, 5, "HARAC", "HARIS")) && (!contains(value, index + 1, 3, "HOR", "HYM", "HIA", "HEM")))
/*      */     {
/*  836 */       return false;
/*      */     }
/*  838 */     return !contains(value, 0, 5, "CHORE");
/*      */   }
/*      */ 
/*      */   private boolean conditionCH1(String value, int index)
/*      */   {
/*  848 */     return (contains(value, 0, 4, "VAN ", "VON ")) || (contains(value, 0, 3, "SCH")) || (contains(value, index - 2, 6, "ORCHES", "ARCHIT", "ORCHID")) || (contains(value, index + 2, 1, "T", "S")) || (((contains(value, index - 1, 1, "A", "O", "U", "E")) || (index == 0)) && ((contains(value, index + 2, 1, L_R_N_M_B_H_F_V_W_SPACE)) || (index + 1 == value.length() - 1)));
/*      */   }
/*      */ 
/*      */   private boolean conditionL0(String value, int index)
/*      */   {
/*  860 */     if ((index == value.length() - 3) && (contains(value, index - 1, 4, "ILLO", "ILLA", "ALLE")))
/*      */     {
/*  862 */       return true;
/*      */     }
/*      */ 
/*  866 */     return ((contains(value, value.length() - 2, 2, "AS", "OS")) || (contains(value, value.length() - 1, 1, "A", "O"))) && (contains(value, index - 1, 4, "ALLE"));
/*      */   }
/*      */ 
/*      */   private boolean conditionM0(String value, int index)
/*      */   {
/*  876 */     if (charAt(value, index + 1) == 'M') {
/*  877 */       return true;
/*      */     }
/*  879 */     return (contains(value, index - 1, 3, "UMB")) && ((index + 1 == value.length() - 1) || (contains(value, index + 2, 2, "ER")));
/*      */   }
/*      */ 
/*      */   private boolean isSlavoGermanic(String value)
/*      */   {
/*  891 */     return (value.indexOf(87) > -1) || (value.indexOf(75) > -1) || (value.indexOf("CZ") > -1) || (value.indexOf("WITZ") > -1);
/*      */   }
/*      */ 
/*      */   private boolean isVowel(char ch)
/*      */   {
/*  899 */     return "AEIOUY".indexOf(ch) != -1;
/*      */   }
/*      */ 
/*      */   private boolean isSilentStart(String value)
/*      */   {
/*  908 */     boolean result = false;
/*  909 */     for (int i = 0; i < SILENT_START.length; i++) {
/*  910 */       if (value.startsWith(SILENT_START[i])) {
/*  911 */         result = true;
/*  912 */         break;
/*      */       }
/*      */     }
/*  915 */     return result;
/*      */   }
/*      */ 
/*      */   private String cleanInput(String input)
/*      */   {
/*  922 */     if (input == null) {
/*  923 */       return null;
/*      */     }
/*  925 */     input = input.trim();
/*  926 */     if (input.length() == 0) {
/*  927 */       return null;
/*      */     }
/*  929 */     return input.toUpperCase(Locale.ENGLISH);
/*      */   }
/*      */ 
/*      */   protected char charAt(String value, int index)
/*      */   {
/*  938 */     if ((index < 0) || (index >= value.length())) {
/*  939 */       return '\000';
/*      */     }
/*  941 */     return value.charAt(index);
/*      */   }
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria)
/*      */   {
/*  949 */     return contains(value, start, length, new String[] { criteria });
/*      */   }
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria1, String criteria2)
/*      */   {
/*  958 */     return contains(value, start, length, new String[] { criteria1, criteria2 });
/*      */   }
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria1, String criteria2, String criteria3)
/*      */   {
/*  968 */     return contains(value, start, length, new String[] { criteria1, criteria2, criteria3 });
/*      */   }
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria1, String criteria2, String criteria3, String criteria4)
/*      */   {
/*  978 */     return contains(value, start, length, new String[] { criteria1, criteria2, criteria3, criteria4 });
/*      */   }
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria1, String criteria2, String criteria3, String criteria4, String criteria5)
/*      */   {
/*  990 */     return contains(value, start, length, new String[] { criteria1, criteria2, criteria3, criteria4, criteria5 });
/*      */   }
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria1, String criteria2, String criteria3, String criteria4, String criteria5, String criteria6)
/*      */   {
/* 1002 */     return contains(value, start, length, new String[] { criteria1, criteria2, criteria3, criteria4, criteria5, criteria6 });
/*      */   }
/*      */ 
/*      */   protected static boolean contains(String value, int start, int length, String[] criteria)
/*      */   {
/* 1013 */     boolean result = false;
/* 1014 */     if ((start >= 0) && (start + length <= value.length())) {
/* 1015 */       String target = value.substring(start, start + length);
/*      */ 
/* 1017 */       for (int i = 0; i < criteria.length; i++) {
/* 1018 */         if (target.equals(criteria[i])) {
/* 1019 */           result = true;
/* 1020 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1024 */     return result;
/*      */   }
/*      */   public class DoubleMetaphoneResult {
/* 1035 */     private StringBuffer primary = new StringBuffer(DoubleMetaphone.this.getMaxCodeLen());
/* 1036 */     private StringBuffer alternate = new StringBuffer(DoubleMetaphone.this.getMaxCodeLen());
/*      */     private int maxLength;
/*      */ 
/* 1040 */     public DoubleMetaphoneResult(int maxLength) { this.maxLength = maxLength; }
/*      */ 
/*      */     public void append(char value)
/*      */     {
/* 1044 */       appendPrimary(value);
/* 1045 */       appendAlternate(value);
/*      */     }
/*      */ 
/*      */     public void append(char primary, char alternate) {
/* 1049 */       appendPrimary(primary);
/* 1050 */       appendAlternate(alternate);
/*      */     }
/*      */ 
/*      */     public void appendPrimary(char value) {
/* 1054 */       if (this.primary.length() < this.maxLength)
/* 1055 */         this.primary.append(value);
/*      */     }
/*      */ 
/*      */     public void appendAlternate(char value)
/*      */     {
/* 1060 */       if (this.alternate.length() < this.maxLength)
/* 1061 */         this.alternate.append(value);
/*      */     }
/*      */ 
/*      */     public void append(String value)
/*      */     {
/* 1066 */       appendPrimary(value);
/* 1067 */       appendAlternate(value);
/*      */     }
/*      */ 
/*      */     public void append(String primary, String alternate) {
/* 1071 */       appendPrimary(primary);
/* 1072 */       appendAlternate(alternate);
/*      */     }
/*      */ 
/*      */     public void appendPrimary(String value) {
/* 1076 */       int addChars = this.maxLength - this.primary.length();
/* 1077 */       if (value.length() <= addChars)
/* 1078 */         this.primary.append(value);
/*      */       else
/* 1080 */         this.primary.append(value.substring(0, addChars));
/*      */     }
/*      */ 
/*      */     public void appendAlternate(String value)
/*      */     {
/* 1085 */       int addChars = this.maxLength - this.alternate.length();
/* 1086 */       if (value.length() <= addChars)
/* 1087 */         this.alternate.append(value);
/*      */       else
/* 1089 */         this.alternate.append(value.substring(0, addChars));
/*      */     }
/*      */ 
/*      */     public String getPrimary()
/*      */     {
/* 1094 */       return this.primary.toString();
/*      */     }
/*      */ 
/*      */     public String getAlternate() {
/* 1098 */       return this.alternate.toString();
/*      */     }
/*      */ 
/*      */     public boolean isComplete() {
/* 1102 */       return (this.primary.length() >= this.maxLength) && (this.alternate.length() >= this.maxLength);
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.language.DoubleMetaphone
 * JD-Core Version:    0.6.0
 */