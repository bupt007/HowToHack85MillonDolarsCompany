/*     */ package com.parse.codec.language;
/*     */ 
/*     */ import com.parse.codec.EncoderException;
/*     */ import com.parse.codec.StringEncoder;
/*     */ 
/*     */ public class RefinedSoundex
/*     */   implements StringEncoder
/*     */ {
/*     */   public static final String US_ENGLISH_MAPPING_STRING = "01360240043788015936020505";
/*  44 */   private static final char[] US_ENGLISH_MAPPING = "01360240043788015936020505".toCharArray();
/*     */   private final char[] soundexMapping;
/*  57 */   public static final RefinedSoundex US_ENGLISH = new RefinedSoundex();
/*     */ 
/*     */   public RefinedSoundex()
/*     */   {
/*  64 */     this.soundexMapping = US_ENGLISH_MAPPING;
/*     */   }
/*     */ 
/*     */   public RefinedSoundex(char[] mapping)
/*     */   {
/*  77 */     this.soundexMapping = new char[mapping.length];
/*  78 */     System.arraycopy(mapping, 0, this.soundexMapping, 0, mapping.length);
/*     */   }
/*     */ 
/*     */   public RefinedSoundex(String mapping)
/*     */   {
/*  90 */     this.soundexMapping = mapping.toCharArray();
/*     */   }
/*     */ 
/*     */   public int difference(String s1, String s2)
/*     */     throws EncoderException
/*     */   {
/* 116 */     return SoundexUtils.difference(this, s1, s2);
/*     */   }
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 133 */     if (!(pObject instanceof String)) {
/* 134 */       throw new EncoderException("Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
/*     */     }
/* 136 */     return soundex((String)pObject);
/*     */   }
/*     */ 
/*     */   public String encode(String pString)
/*     */   {
/* 147 */     return soundex(pString);
/*     */   }
/*     */ 
/*     */   char getMappingCode(char c)
/*     */   {
/* 160 */     if (!Character.isLetter(c)) {
/* 161 */       return '\000';
/*     */     }
/* 163 */     return this.soundexMapping[(Character.toUpperCase(c) - 'A')];
/*     */   }
/*     */ 
/*     */   public String soundex(String str)
/*     */   {
/* 174 */     if (str == null) {
/* 175 */       return null;
/*     */     }
/* 177 */     str = SoundexUtils.clean(str);
/* 178 */     if (str.length() == 0) {
/* 179 */       return str;
/*     */     }
/*     */ 
/* 182 */     StringBuffer sBuf = new StringBuffer();
/* 183 */     sBuf.append(str.charAt(0));
/*     */ 
/* 186 */     char last = '*';
/*     */ 
/* 188 */     for (int i = 0; i < str.length(); i++)
/*     */     {
/* 190 */       char current = getMappingCode(str.charAt(i));
/* 191 */       if (current == last)
/*     */         continue;
/* 193 */       if (current != 0) {
/* 194 */         sBuf.append(current);
/*     */       }
/*     */ 
/* 197 */       last = current;
/*     */     }
/*     */ 
/* 201 */     return sBuf.toString();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.language.RefinedSoundex
 * JD-Core Version:    0.6.0
 */