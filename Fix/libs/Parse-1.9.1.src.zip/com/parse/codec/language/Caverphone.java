/*     */ package com.parse.codec.language;
/*     */ 
/*     */ import com.parse.codec.EncoderException;
/*     */ import com.parse.codec.StringEncoder;
/*     */ 
/*     */ /** @deprecated */
/*     */ public class Caverphone
/*     */   implements StringEncoder
/*     */ {
/*  42 */   private final Caverphone2 encoder = new Caverphone2();
/*     */ 
/*     */   public String caverphone(String source)
/*     */   {
/*  59 */     return this.encoder.encode(source);
/*     */   }
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/*  74 */     if (!(pObject instanceof String)) {
/*  75 */       throw new EncoderException("Parameter supplied to Caverphone encode is not of type java.lang.String");
/*     */     }
/*  77 */     return caverphone((String)pObject);
/*     */   }
/*     */ 
/*     */   public String encode(String pString)
/*     */   {
/*  88 */     return caverphone(pString);
/*     */   }
/*     */ 
/*     */   public boolean isCaverphoneEqual(String str1, String str2)
/*     */   {
/* 101 */     return caverphone(str1).equals(caverphone(str2));
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.language.Caverphone
 * JD-Core Version:    0.6.0
 */