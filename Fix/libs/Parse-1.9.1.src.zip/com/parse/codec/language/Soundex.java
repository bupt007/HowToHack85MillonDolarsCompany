/*     */ package com.parse.codec.language;
/*     */ 
/*     */ import com.parse.codec.EncoderException;
/*     */ import com.parse.codec.StringEncoder;
/*     */ 
/*     */ public class Soundex
/*     */   implements StringEncoder
/*     */ {
/*     */   public static final String US_ENGLISH_MAPPING_STRING = "01230120022455012623010202";
/*  51 */   private static final char[] US_ENGLISH_MAPPING = "01230120022455012623010202".toCharArray();
/*     */ 
/*  58 */   public static final Soundex US_ENGLISH = new Soundex();
/*     */ 
/*     */   /** @deprecated */
/*  89 */   private int maxLength = 4;
/*     */   private final char[] soundexMapping;
/*     */ 
/*     */   public int difference(String s1, String s2)
/*     */     throws EncoderException
/*     */   {
/*  81 */     return SoundexUtils.difference(this, s1, s2);
/*     */   }
/*     */ 
/*     */   public Soundex()
/*     */   {
/* 104 */     this.soundexMapping = US_ENGLISH_MAPPING;
/*     */   }
/*     */ 
/*     */   public Soundex(char[] mapping)
/*     */   {
/* 118 */     this.soundexMapping = new char[mapping.length];
/* 119 */     System.arraycopy(mapping, 0, this.soundexMapping, 0, mapping.length);
/*     */   }
/*     */ 
/*     */   public Soundex(String mapping)
/*     */   {
/* 131 */     this.soundexMapping = mapping.toCharArray();
/*     */   }
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 148 */     if (!(pObject instanceof String)) {
/* 149 */       throw new EncoderException("Parameter supplied to Soundex encode is not of type java.lang.String");
/*     */     }
/* 151 */     return soundex((String)pObject);
/*     */   }
/*     */ 
/*     */   public String encode(String pString)
/*     */   {
/* 164 */     return soundex(pString);
/*     */   }
/*     */ 
/*     */   private char getMappingCode(String str, int index)
/*     */   {
/* 182 */     char mappedChar = map(str.charAt(index));
/*     */ 
/* 184 */     if ((index > 1) && (mappedChar != '0')) {
/* 185 */       char hwChar = str.charAt(index - 1);
/* 186 */       if (('H' == hwChar) || ('W' == hwChar)) {
/* 187 */         char preHWChar = str.charAt(index - 2);
/* 188 */         char firstCode = map(preHWChar);
/* 189 */         if ((firstCode == mappedChar) || ('H' == preHWChar) || ('W' == preHWChar)) {
/* 190 */           return '\000';
/*     */         }
/*     */       }
/*     */     }
/* 194 */     return mappedChar;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public int getMaxLength()
/*     */   {
/* 204 */     return this.maxLength;
/*     */   }
/*     */ 
/*     */   private char[] getSoundexMapping()
/*     */   {
/* 213 */     return this.soundexMapping;
/*     */   }
/*     */ 
/*     */   private char map(char ch)
/*     */   {
/* 226 */     int index = ch - 'A';
/* 227 */     if ((index < 0) || (index >= getSoundexMapping().length)) {
/* 228 */       throw new IllegalArgumentException("The character is not mapped: " + ch);
/*     */     }
/* 230 */     return getSoundexMapping()[index];
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setMaxLength(int maxLength)
/*     */   {
/* 241 */     this.maxLength = maxLength;
/*     */   }
/*     */ 
/*     */   public String soundex(String str)
/*     */   {
/* 254 */     if (str == null) {
/* 255 */       return null;
/*     */     }
/* 257 */     str = SoundexUtils.clean(str);
/* 258 */     if (str.length() == 0) {
/* 259 */       return str;
/*     */     }
/* 261 */     char[] out = { '0', '0', '0', '0' };
/*     */ 
/* 263 */     int incount = 1; int count = 1;
/* 264 */     out[0] = str.charAt(0);
/*     */ 
/* 266 */     char last = getMappingCode(str, 0);
/* 267 */     while ((incount < str.length()) && (count < out.length)) {
/* 268 */       char mapped = getMappingCode(str, incount++);
/* 269 */       if (mapped != 0) {
/* 270 */         if ((mapped != '0') && (mapped != last)) {
/* 271 */           out[(count++)] = mapped;
/*     */         }
/* 273 */         last = mapped;
/*     */       }
/*     */     }
/* 276 */     return new String(out);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.language.Soundex
 * JD-Core Version:    0.6.0
 */