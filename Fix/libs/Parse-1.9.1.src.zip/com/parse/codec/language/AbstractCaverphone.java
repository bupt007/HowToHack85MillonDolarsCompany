/*    */ package com.parse.codec.language;
/*    */ 
/*    */ import com.parse.codec.EncoderException;
/*    */ import com.parse.codec.StringEncoder;
/*    */ 
/*    */ public abstract class AbstractCaverphone
/*    */   implements StringEncoder
/*    */ {
/*    */   public Object encode(Object source)
/*    */     throws EncoderException
/*    */   {
/* 56 */     if (!(source instanceof String)) {
/* 57 */       throw new EncoderException("Parameter supplied to Caverphone encode is not of type java.lang.String");
/*    */     }
/* 59 */     return encode((String)source);
/*    */   }
/*    */ 
/*    */   public boolean isEncodeEqual(String str1, String str2)
/*    */     throws EncoderException
/*    */   {
/* 75 */     return encode(str1).equals(encode(str2));
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.language.AbstractCaverphone
 * JD-Core Version:    0.6.0
 */