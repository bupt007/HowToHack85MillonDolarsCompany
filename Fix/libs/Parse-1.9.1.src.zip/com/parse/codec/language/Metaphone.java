/*     */ package com.parse.codec.language;
/*     */ 
/*     */ import com.parse.codec.EncoderException;
/*     */ import com.parse.codec.StringEncoder;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class Metaphone
/*     */   implements StringEncoder
/*     */ {
/*     */   private static final String VOWELS = "AEIOU";
/*     */   private static final String FRONTV = "EIY";
/*     */   private static final String VARSON = "CSPTG";
/*  64 */   private int maxCodeLen = 4;
/*     */ 
/*     */   public String metaphone(String txt)
/*     */   {
/*  84 */     boolean hard = false;
/*  85 */     if ((txt == null) || (txt.length() == 0)) {
/*  86 */       return "";
/*     */     }
/*     */ 
/*  89 */     if (txt.length() == 1) {
/*  90 */       return txt.toUpperCase(Locale.ENGLISH);
/*     */     }
/*     */ 
/*  93 */     char[] inwd = txt.toUpperCase(Locale.ENGLISH).toCharArray();
/*     */ 
/*  95 */     StringBuffer local = new StringBuffer(40);
/*  96 */     StringBuffer code = new StringBuffer(10);
/*     */ 
/*  98 */     switch (inwd[0]) {
/*     */     case 'G':
/*     */     case 'K':
/*     */     case 'P':
/* 102 */       if (inwd[1] == 'N')
/* 103 */         local.append(inwd, 1, inwd.length - 1);
/*     */       else {
/* 105 */         local.append(inwd);
/*     */       }
/* 107 */       break;
/*     */     case 'A':
/* 109 */       if (inwd[1] == 'E')
/* 110 */         local.append(inwd, 1, inwd.length - 1);
/*     */       else {
/* 112 */         local.append(inwd);
/*     */       }
/* 114 */       break;
/*     */     case 'W':
/* 116 */       if (inwd[1] == 'R') {
/* 117 */         local.append(inwd, 1, inwd.length - 1);
/*     */       }
/* 120 */       else if (inwd[1] == 'H') {
/* 121 */         local.append(inwd, 1, inwd.length - 1);
/* 122 */         local.setCharAt(0, 'W');
/*     */       } else {
/* 124 */         local.append(inwd);
/*     */       }
/* 126 */       break;
/*     */     case 'X':
/* 128 */       inwd[0] = 'S';
/* 129 */       local.append(inwd);
/* 130 */       break;
/*     */     default:
/* 132 */       local.append(inwd);
/*     */     }
/*     */ 
/* 135 */     int wdsz = local.length();
/* 136 */     int n = 0;
/*     */ 
/* 138 */     while ((code.length() < getMaxCodeLen()) && (n < wdsz))
/*     */     {
/* 140 */       char symb = local.charAt(n);
/*     */ 
/* 142 */       if ((symb != 'C') && (isPreviousChar(local, n, symb))) {
/* 143 */         n++;
/*     */       } else {
/* 145 */         switch (symb) { case 'A':
/*     */         case 'E':
/*     */         case 'I':
/*     */         case 'O':
/*     */         case 'U':
/* 147 */           if (n != 0) break;
/* 148 */           code.append(symb); break;
/*     */         case 'B':
/* 152 */           if ((isPreviousChar(local, n, 'M')) && (isLastChar(wdsz, n)))
/*     */           {
/*     */             break;
/*     */           }
/* 156 */           code.append(symb);
/* 157 */           break;
/*     */         case 'C':
/* 160 */           if ((isPreviousChar(local, n, 'S')) && (!isLastChar(wdsz, n)) && ("EIY".indexOf(local.charAt(n + 1)) >= 0))
/*     */           {
/*     */             break;
/*     */           }
/*     */ 
/* 165 */           if (regionMatch(local, n, "CIA")) {
/* 166 */             code.append('X');
/*     */           }
/* 169 */           else if ((!isLastChar(wdsz, n)) && ("EIY".indexOf(local.charAt(n + 1)) >= 0))
/*     */           {
/* 171 */             code.append('S');
/*     */           }
/* 174 */           else if ((isPreviousChar(local, n, 'S')) && (isNextChar(local, n, 'H')))
/*     */           {
/* 176 */             code.append('K');
/*     */           }
/* 179 */           else if (isNextChar(local, n, 'H')) {
/* 180 */             if ((n == 0) && (wdsz >= 3) && (isVowel(local, 2)))
/*     */             {
/* 183 */               code.append('K');
/*     */             }
/* 185 */             else code.append('X');
/*     */           }
/*     */           else {
/* 188 */             code.append('K');
/*     */           }
/* 190 */           break;
/*     */         case 'D':
/* 192 */           if ((!isLastChar(wdsz, n + 1)) && (isNextChar(local, n, 'G')) && ("EIY".indexOf(local.charAt(n + 2)) >= 0))
/*     */           {
/* 195 */             code.append('J'); n += 2;
/*     */           } else {
/* 197 */             code.append('T');
/*     */           }
/* 199 */           break;
/*     */         case 'G':
/* 201 */           if ((isLastChar(wdsz, n + 1)) && (isNextChar(local, n, 'H')))
/*     */           {
/*     */             break;
/*     */           }
/* 205 */           if ((!isLastChar(wdsz, n + 1)) && (isNextChar(local, n, 'H')) && (!isVowel(local, n + 2)))
/*     */           {
/*     */             break;
/*     */           }
/*     */ 
/* 210 */           if ((n > 0) && ((regionMatch(local, n, "GN")) || (regionMatch(local, n, "GNED"))))
/*     */           {
/*     */             break;
/*     */           }
/*     */ 
/* 215 */           if (isPreviousChar(local, n, 'G'))
/*     */           {
/* 217 */             hard = true;
/*     */           }
/* 219 */           else hard = false;
/*     */ 
/* 221 */           if ((!isLastChar(wdsz, n)) && ("EIY".indexOf(local.charAt(n + 1)) >= 0) && (!hard))
/*     */           {
/* 224 */             code.append('J');
/*     */           }
/* 226 */           else code.append('K');
/*     */ 
/* 228 */           break;
/*     */         case 'H':
/* 230 */           if (isLastChar(wdsz, n)) {
/*     */             break;
/*     */           }
/* 233 */           if ((n > 0) && ("CSPTG".indexOf(local.charAt(n - 1)) >= 0))
/*     */           {
/*     */             break;
/*     */           }
/* 237 */           if (!isVowel(local, n + 1)) break;
/* 238 */           code.append('H'); break;
/*     */         case 'F':
/*     */         case 'J':
/*     */         case 'L':
/*     */         case 'M':
/*     */         case 'N':
/*     */         case 'R':
/* 247 */           code.append(symb);
/* 248 */           break;
/*     */         case 'K':
/* 250 */           if (n > 0) {
/* 251 */             if (isPreviousChar(local, n, 'C')) break;
/* 252 */             code.append(symb);
/*     */           }
/*     */           else {
/* 255 */             code.append(symb);
/*     */           }
/* 257 */           break;
/*     */         case 'P':
/* 259 */           if (isNextChar(local, n, 'H'))
/*     */           {
/* 261 */             code.append('F');
/*     */           }
/* 263 */           else code.append(symb);
/*     */ 
/* 265 */           break;
/*     */         case 'Q':
/* 267 */           code.append('K');
/* 268 */           break;
/*     */         case 'S':
/* 270 */           if ((regionMatch(local, n, "SH")) || (regionMatch(local, n, "SIO")) || (regionMatch(local, n, "SIA")))
/*     */           {
/* 273 */             code.append('X');
/*     */           }
/* 275 */           else code.append('S');
/*     */ 
/* 277 */           break;
/*     */         case 'T':
/* 279 */           if ((regionMatch(local, n, "TIA")) || (regionMatch(local, n, "TIO")))
/*     */           {
/* 281 */             code.append('X');
/*     */           }
/*     */           else {
/* 284 */             if (regionMatch(local, n, "TCH"))
/*     */             {
/*     */               break;
/*     */             }
/*     */ 
/* 289 */             if (regionMatch(local, n, "TH"))
/* 290 */               code.append('0');
/*     */             else
/* 292 */               code.append('T');
/*     */           }
/* 294 */           break;
/*     */         case 'V':
/* 296 */           code.append('F'); break;
/*     */         case 'W':
/*     */         case 'Y':
/* 298 */           if ((isLastChar(wdsz, n)) || (!isVowel(local, n + 1)))
/*     */             break;
/* 300 */           code.append(symb); break;
/*     */         case 'X':
/* 304 */           code.append('K'); code.append('S');
/* 305 */           break;
/*     */         case 'Z':
/* 307 */           code.append('S');
/*     */         }
/* 309 */         n++;
/*     */       }
/* 311 */       if (code.length() > getMaxCodeLen()) {
/* 312 */         code.setLength(getMaxCodeLen());
/*     */       }
/*     */     }
/* 315 */     return code.toString();
/*     */   }
/*     */ 
/*     */   private boolean isVowel(StringBuffer string, int index) {
/* 319 */     return "AEIOU".indexOf(string.charAt(index)) >= 0;
/*     */   }
/*     */ 
/*     */   private boolean isPreviousChar(StringBuffer string, int index, char c) {
/* 323 */     boolean matches = false;
/* 324 */     if ((index > 0) && (index < string.length()))
/*     */     {
/* 326 */       matches = string.charAt(index - 1) == c;
/*     */     }
/* 328 */     return matches;
/*     */   }
/*     */ 
/*     */   private boolean isNextChar(StringBuffer string, int index, char c) {
/* 332 */     boolean matches = false;
/* 333 */     if ((index >= 0) && (index < string.length() - 1))
/*     */     {
/* 335 */       matches = string.charAt(index + 1) == c;
/*     */     }
/* 337 */     return matches;
/*     */   }
/*     */ 
/*     */   private boolean regionMatch(StringBuffer string, int index, String test) {
/* 341 */     boolean matches = false;
/* 342 */     if ((index >= 0) && (index + test.length() - 1 < string.length()))
/*     */     {
/* 344 */       String substring = string.substring(index, index + test.length());
/* 345 */       matches = substring.equals(test);
/*     */     }
/* 347 */     return matches;
/*     */   }
/*     */ 
/*     */   private boolean isLastChar(int wdsz, int n) {
/* 351 */     return n + 1 == wdsz;
/*     */   }
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 368 */     if (!(pObject instanceof String)) {
/* 369 */       throw new EncoderException("Parameter supplied to Metaphone encode is not of type java.lang.String");
/*     */     }
/* 371 */     return metaphone((String)pObject);
/*     */   }
/*     */ 
/*     */   public String encode(String pString)
/*     */   {
/* 381 */     return metaphone(pString);
/*     */   }
/*     */ 
/*     */   public boolean isMetaphoneEqual(String str1, String str2)
/*     */   {
/* 393 */     return metaphone(str1).equals(metaphone(str2));
/*     */   }
/*     */ 
/*     */   public int getMaxCodeLen()
/*     */   {
/* 400 */     return this.maxCodeLen;
/*     */   }
/*     */ 
/*     */   public void setMaxCodeLen(int maxCodeLen)
/*     */   {
/* 406 */     this.maxCodeLen = maxCodeLen;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.language.Metaphone
 * JD-Core Version:    0.6.0
 */