/*     */ package com.parse.codec.language;
/*     */ 
/*     */ import com.parse.codec.EncoderException;
/*     */ import com.parse.codec.StringEncoder;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class ColognePhonetic
/*     */   implements StringEncoder
/*     */ {
/* 263 */   private static final char[][] PREPROCESS_MAP = { { 'Ä', 'A' }, { 'Ü', 'U' }, { 'Ö', 'O' }, { 'ß', 'S' } };
/*     */ 
/*     */   private static boolean arrayContains(char[] arr, char key)
/*     */   {
/* 273 */     for (int i = 0; i < arr.length; i++) {
/* 274 */       if (arr[i] == key) {
/* 275 */         return true;
/*     */       }
/*     */     }
/* 278 */     return false;
/*     */   }
/*     */ 
/*     */   public String colognePhonetic(String text)
/*     */   {
/* 293 */     if (text == null) {
/* 294 */       return null;
/*     */     }
/*     */ 
/* 297 */     text = preprocess(text);
/*     */ 
/* 299 */     CologneOutputBuffer output = new CologneOutputBuffer(text.length() * 2);
/* 300 */     CologneInputBuffer input = new CologneInputBuffer(text.toCharArray());
/*     */ 
/* 304 */     char lastChar = '-';
/* 305 */     char lastCode = '/';
/*     */ 
/* 309 */     int rightLength = input.length();
/*     */ 
/* 311 */     while (rightLength > 0) {
/* 312 */       char chr = input.removeNext();
/*     */       char nextChar;
/*     */       char nextChar;
/* 314 */       if ((rightLength = input.length()) > 0)
/* 315 */         nextChar = input.getNextChar();
/*     */       else
/* 317 */         nextChar = '-';
/*     */       char code;
/*     */       char code;
/* 320 */       if (arrayContains(new char[] { 'A', 'E', 'I', 'J', 'O', 'U', 'Y' }, chr)) {
/* 321 */         code = '0';
/*     */       }
/*     */       else
/*     */       {
/*     */         char code;
/* 322 */         if ((chr == 'H') || (chr < 'A') || (chr > 'Z')) {
/* 323 */           if (lastCode == '/') {
/*     */             continue;
/*     */           }
/* 326 */           code = '-';
/*     */         }
/*     */         else
/*     */         {
/*     */           char code;
/* 327 */           if ((chr == 'B') || ((chr == 'P') && (nextChar != 'H'))) {
/* 328 */             code = '1'; } else {
/* 329 */             if ((chr == 'D') || (chr == 'T')) if (!arrayContains(new char[] { 'S', 'C', 'Z' }, nextChar)) {
/* 330 */                 char code = '2'; break label654;
/*     */               }
/*     */             char code;
/* 331 */             if (arrayContains(new char[] { 'W', 'F', 'P', 'V' }, chr)) {
/* 332 */               code = '3';
/*     */             }
/*     */             else
/*     */             {
/*     */               char code;
/* 333 */               if (arrayContains(new char[] { 'G', 'K', 'Q' }, chr)) {
/* 334 */                 code = '4'; } else {
/* 335 */                 if (chr == 'X') if (!arrayContains(new char[] { 'C', 'K', 'Q' }, lastChar)) {
/* 336 */                     char code = '4';
/* 337 */                     input.addLeft('S');
/* 338 */                     rightLength++; break label654;
/*     */                   }
/*     */                 char code;
/* 339 */                 if ((chr == 'S') || (chr == 'Z')) {
/* 340 */                   code = '8';
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   char code;
/* 341 */                   if (chr == 'C')
/*     */                   {
/*     */                     char code;
/* 342 */                     if (lastCode == '/')
/*     */                     {
/*     */                       char code;
/* 343 */                       if (arrayContains(new char[] { 'A', 'H', 'K', 'L', 'O', 'Q', 'R', 'U', 'X' }, nextChar))
/* 344 */                         code = '4';
/*     */                       else
/* 346 */                         code = '8';
/*     */                     }
/*     */                     else {
/* 349 */                       if (!arrayContains(new char[] { 'S', 'Z' }, lastChar)) { if (arrayContains(new char[] { 'A', 'H', 'O', 'U', 'K', 'Q', 'X' }, nextChar)); } else {
/* 351 */                         char code = '8'; break label654;
/*     */                       }
/* 353 */                       code = '4';
/*     */                     }
/*     */                   }
/*     */                   else
/*     */                   {
/*     */                     char code;
/* 356 */                     if (arrayContains(new char[] { 'T', 'D', 'X' }, chr)) {
/* 357 */                       code = '8';
/*     */                     }
/*     */                     else
/*     */                     {
/*     */                       char code;
/* 358 */                       if (chr == 'R') {
/* 359 */                         code = '7';
/*     */                       }
/*     */                       else
/*     */                       {
/*     */                         char code;
/* 360 */                         if (chr == 'L') {
/* 361 */                           code = '5';
/*     */                         }
/*     */                         else
/*     */                         {
/*     */                           char code;
/* 362 */                           if ((chr == 'M') || (chr == 'N'))
/* 363 */                             code = '6';
/*     */                           else
/* 365 */                             code = chr; 
/*     */                         }
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 368 */       label654: if ((code != '-') && (((lastCode != code) && ((code != '0') || (lastCode == '/'))) || (code < '0') || (code > '8'))) {
/* 369 */         output.addRight(code);
/*     */       }
/*     */ 
/* 372 */       lastChar = chr;
/* 373 */       lastCode = code;
/*     */     }
/* 375 */     return output.toString();
/*     */   }
/*     */ 
/*     */   public Object encode(Object object) throws EncoderException {
/* 379 */     if (!(object instanceof String)) {
/* 380 */       throw new EncoderException("This method’s parameter was expected to be of the type " + String.class.getName() + ". But actually it was of the type " + object.getClass().getName() + ".");
/*     */     }
/*     */ 
/* 386 */     return encode((String)object);
/*     */   }
/*     */ 
/*     */   public String encode(String text) {
/* 390 */     return colognePhonetic(text);
/*     */   }
/*     */ 
/*     */   public boolean isEncodeEqual(String text1, String text2) {
/* 394 */     return colognePhonetic(text1).equals(colognePhonetic(text2));
/*     */   }
/*     */ 
/*     */   private String preprocess(String text)
/*     */   {
/* 401 */     text = text.toUpperCase(Locale.GERMAN);
/*     */ 
/* 403 */     char[] chrs = text.toCharArray();
/*     */ 
/* 405 */     for (int index = 0; index < chrs.length; index++) {
/* 406 */       if (chrs[index] > 'Z') {
/* 407 */         for (int replacement = 0; replacement < PREPROCESS_MAP.length; replacement++) {
/* 408 */           if (chrs[index] == PREPROCESS_MAP[replacement][0]) {
/* 409 */             chrs[index] = PREPROCESS_MAP[replacement][1];
/* 410 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 415 */     return new String(chrs);
/*     */   }
/*     */ 
/*     */   private class CologneInputBuffer extends ColognePhonetic.CologneBuffer
/*     */   {
/*     */     public CologneInputBuffer(char[] data)
/*     */     {
/* 234 */       super(data);
/*     */     }
/*     */ 
/*     */     public void addLeft(char ch) {
/* 238 */       this.length += 1;
/* 239 */       this.data[getNextPos()] = ch;
/*     */     }
/*     */ 
/*     */     protected char[] copyData(int start, int length) {
/* 243 */       char[] newData = new char[length];
/* 244 */       System.arraycopy(this.data, this.data.length - this.length + start, newData, 0, length);
/* 245 */       return newData;
/*     */     }
/*     */ 
/*     */     public char getNextChar() {
/* 249 */       return this.data[getNextPos()];
/*     */     }
/*     */ 
/*     */     protected int getNextPos() {
/* 253 */       return this.data.length - this.length;
/*     */     }
/*     */ 
/*     */     public char removeNext() {
/* 257 */       char ch = getNextChar();
/* 258 */       this.length -= 1;
/* 259 */       return ch;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class CologneOutputBuffer extends ColognePhonetic.CologneBuffer
/*     */   {
/*     */     public CologneOutputBuffer(int buffSize)
/*     */     {
/* 216 */       super(buffSize);
/*     */     }
/*     */ 
/*     */     public void addRight(char chr) {
/* 220 */       this.data[this.length] = chr;
/* 221 */       this.length += 1;
/*     */     }
/*     */ 
/*     */     protected char[] copyData(int start, int length) {
/* 225 */       char[] newData = new char[length];
/* 226 */       System.arraycopy(this.data, start, newData, 0, length);
/* 227 */       return newData;
/*     */     }
/*     */   }
/*     */ 
/*     */   private abstract class CologneBuffer
/*     */   {
/*     */     protected final char[] data;
/* 190 */     protected int length = 0;
/*     */ 
/*     */     public CologneBuffer(char[] data) {
/* 193 */       this.data = data;
/* 194 */       this.length = data.length;
/*     */     }
/*     */ 
/*     */     public CologneBuffer(int buffSize) {
/* 198 */       this.data = new char[buffSize];
/* 199 */       this.length = 0;
/*     */     }
/*     */     protected abstract char[] copyData(int paramInt1, int paramInt2);
/*     */ 
/*     */     public int length() {
/* 205 */       return this.length;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 209 */       return new String(copyData(0, this.length));
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.language.ColognePhonetic
 * JD-Core Version:    0.6.0
 */