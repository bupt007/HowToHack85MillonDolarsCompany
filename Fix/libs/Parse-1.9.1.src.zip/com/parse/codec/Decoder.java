package com.parse.codec;

public abstract interface Decoder
{
  public abstract Object decode(Object paramObject)
    throws DecoderException;
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.Decoder
 * JD-Core Version:    0.6.0
 */