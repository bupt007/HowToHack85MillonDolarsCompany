/*     */ package com.parse.codec.digest;
/*     */ 
/*     */ import com.parse.codec.binary.Hex;
/*     */ import com.parse.codec.binary.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ 
/*     */ public class DigestUtils
/*     */ {
/*     */   private static final int STREAM_BUFFER_LENGTH = 1024;
/*     */ 
/*     */   private static byte[] digest(MessageDigest digest, InputStream data)
/*     */     throws IOException
/*     */   {
/*  51 */     byte[] buffer = new byte[1024];
/*  52 */     int read = data.read(buffer, 0, 1024);
/*     */ 
/*  54 */     while (read > -1) {
/*  55 */       digest.update(buffer, 0, read);
/*  56 */       read = data.read(buffer, 0, 1024);
/*     */     }
/*     */ 
/*  59 */     return digest.digest();
/*     */   }
/*     */ 
/*     */   private static byte[] getBytesUtf8(String data)
/*     */   {
/*  70 */     return StringUtils.getBytesUtf8(data);
/*     */   }
/*     */ 
/*     */   static MessageDigest getDigest(String algorithm)
/*     */   {
/*     */     try
/*     */     {
/*  88 */       return MessageDigest.getInstance(algorithm); } catch (NoSuchAlgorithmException e) {
/*     */     }
/*  90 */     throw new RuntimeException(e.getMessage());
/*     */   }
/*     */ 
/*     */   private static MessageDigest getMd5Digest()
/*     */   {
/* 102 */     return getDigest("MD5");
/*     */   }
/*     */ 
/*     */   private static MessageDigest getSha256Digest()
/*     */   {
/* 116 */     return getDigest("SHA-256");
/*     */   }
/*     */ 
/*     */   private static MessageDigest getSha384Digest()
/*     */   {
/* 130 */     return getDigest("SHA-384");
/*     */   }
/*     */ 
/*     */   private static MessageDigest getSha512Digest()
/*     */   {
/* 144 */     return getDigest("SHA-512");
/*     */   }
/*     */ 
/*     */   private static MessageDigest getShaDigest()
/*     */   {
/* 155 */     return getDigest("SHA");
/*     */   }
/*     */ 
/*     */   public static byte[] md5(byte[] data)
/*     */   {
/* 166 */     return getMd5Digest().digest(data);
/*     */   }
/*     */ 
/*     */   public static byte[] md5(InputStream data)
/*     */     throws IOException
/*     */   {
/* 180 */     return digest(getMd5Digest(), data);
/*     */   }
/*     */ 
/*     */   public static byte[] md5(String data)
/*     */   {
/* 191 */     return md5(getBytesUtf8(data));
/*     */   }
/*     */ 
/*     */   public static String md5Hex(byte[] data)
/*     */   {
/* 202 */     return Hex.encodeHexString(md5(data));
/*     */   }
/*     */ 
/*     */   public static String md5Hex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 216 */     return Hex.encodeHexString(md5(data));
/*     */   }
/*     */ 
/*     */   public static String md5Hex(String data)
/*     */   {
/* 227 */     return Hex.encodeHexString(md5(data));
/*     */   }
/*     */ 
/*     */   public static byte[] sha(byte[] data)
/*     */   {
/* 238 */     return getShaDigest().digest(data);
/*     */   }
/*     */ 
/*     */   public static byte[] sha(InputStream data)
/*     */     throws IOException
/*     */   {
/* 252 */     return digest(getShaDigest(), data);
/*     */   }
/*     */ 
/*     */   public static byte[] sha(String data)
/*     */   {
/* 263 */     return sha(getBytesUtf8(data));
/*     */   }
/*     */ 
/*     */   public static byte[] sha256(byte[] data)
/*     */   {
/* 278 */     return getSha256Digest().digest(data);
/*     */   }
/*     */ 
/*     */   public static byte[] sha256(InputStream data)
/*     */     throws IOException
/*     */   {
/* 295 */     return digest(getSha256Digest(), data);
/*     */   }
/*     */ 
/*     */   public static byte[] sha256(String data)
/*     */   {
/* 310 */     return sha256(getBytesUtf8(data));
/*     */   }
/*     */ 
/*     */   public static String sha256Hex(byte[] data)
/*     */   {
/* 325 */     return Hex.encodeHexString(sha256(data));
/*     */   }
/*     */ 
/*     */   public static String sha256Hex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 342 */     return Hex.encodeHexString(sha256(data));
/*     */   }
/*     */ 
/*     */   public static String sha256Hex(String data)
/*     */   {
/* 357 */     return Hex.encodeHexString(sha256(data));
/*     */   }
/*     */ 
/*     */   public static byte[] sha384(byte[] data)
/*     */   {
/* 372 */     return getSha384Digest().digest(data);
/*     */   }
/*     */ 
/*     */   public static byte[] sha384(InputStream data)
/*     */     throws IOException
/*     */   {
/* 389 */     return digest(getSha384Digest(), data);
/*     */   }
/*     */ 
/*     */   public static byte[] sha384(String data)
/*     */   {
/* 404 */     return sha384(getBytesUtf8(data));
/*     */   }
/*     */ 
/*     */   public static String sha384Hex(byte[] data)
/*     */   {
/* 419 */     return Hex.encodeHexString(sha384(data));
/*     */   }
/*     */ 
/*     */   public static String sha384Hex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 436 */     return Hex.encodeHexString(sha384(data));
/*     */   }
/*     */ 
/*     */   public static String sha384Hex(String data)
/*     */   {
/* 451 */     return Hex.encodeHexString(sha384(data));
/*     */   }
/*     */ 
/*     */   public static byte[] sha512(byte[] data)
/*     */   {
/* 466 */     return getSha512Digest().digest(data);
/*     */   }
/*     */ 
/*     */   public static byte[] sha512(InputStream data)
/*     */     throws IOException
/*     */   {
/* 483 */     return digest(getSha512Digest(), data);
/*     */   }
/*     */ 
/*     */   public static byte[] sha512(String data)
/*     */   {
/* 498 */     return sha512(getBytesUtf8(data));
/*     */   }
/*     */ 
/*     */   public static String sha512Hex(byte[] data)
/*     */   {
/* 513 */     return Hex.encodeHexString(sha512(data));
/*     */   }
/*     */ 
/*     */   public static String sha512Hex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 530 */     return Hex.encodeHexString(sha512(data));
/*     */   }
/*     */ 
/*     */   public static String sha512Hex(String data)
/*     */   {
/* 545 */     return Hex.encodeHexString(sha512(data));
/*     */   }
/*     */ 
/*     */   public static String shaHex(byte[] data)
/*     */   {
/* 556 */     return Hex.encodeHexString(sha(data));
/*     */   }
/*     */ 
/*     */   public static String shaHex(InputStream data)
/*     */     throws IOException
/*     */   {
/* 570 */     return Hex.encodeHexString(sha(data));
/*     */   }
/*     */ 
/*     */   public static String shaHex(String data)
/*     */   {
/* 581 */     return Hex.encodeHexString(sha(data));
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.digest.DigestUtils
 * JD-Core Version:    0.6.0
 */