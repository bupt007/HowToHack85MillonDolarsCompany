/*    */ package com.parse.codec;
/*    */ 
/*    */ public class EncoderException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public EncoderException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public EncoderException(String message)
/*    */   {
/* 56 */     super(message);
/*    */   }
/*    */ 
/*    */   public EncoderException(String message, Throwable cause)
/*    */   {
/* 75 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public EncoderException(Throwable cause)
/*    */   {
/* 89 */     super(cause);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.codec.EncoderException
 * JD-Core Version:    0.6.0
 */