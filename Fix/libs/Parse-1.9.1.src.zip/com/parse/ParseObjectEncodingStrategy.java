package com.parse;

import org.json.JSONObject;

abstract interface ParseObjectEncodingStrategy
{
  public abstract JSONObject encodeRelatedObject(ParseObject paramParseObject);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseObjectEncodingStrategy
 * JD-Core Version:    0.6.0
 */