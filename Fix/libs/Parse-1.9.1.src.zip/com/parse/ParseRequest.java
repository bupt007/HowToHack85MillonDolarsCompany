/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.net.http.AndroidHttpClient;
/*     */ import android.os.Build.VERSION;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import bolts.Task.TaskCompletionSource;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.client.ClientProtocolException;
/*     */ import org.apache.http.client.methods.HttpDelete;
/*     */ import org.apache.http.client.methods.HttpGet;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpPut;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ 
/*     */ abstract class ParseRequest<Response, Result>
/*     */ {
/*  36 */   private static final ThreadFactory sThreadFactory = new ThreadFactory() {
/*  37 */     private final AtomicInteger mCount = new AtomicInteger(1);
/*     */ 
/*     */     public Thread newThread(Runnable r) {
/*  40 */       return new Thread(r, "ParseRequest.NETWORK_EXECUTOR-thread-" + this.mCount.getAndIncrement());
/*     */     }
/*  36 */   };
/*     */ 
/*  48 */   private static final int CPU_COUNT = Runtime.getRuntime().availableProcessors();
/*  49 */   private static final int CORE_POOL_SIZE = CPU_COUNT * 2 + 1;
/*  50 */   private static final int MAX_POOL_SIZE = CPU_COUNT * 2 * 2 + 1;
/*     */   private static final long KEEP_ALIVE_TIME = 1L;
/*     */   private static final int MAX_QUEUE_SIZE = 128;
/*  65 */   static final ExecutorService NETWORK_EXECUTOR = newThreadPoolExecutor(CORE_POOL_SIZE, MAX_POOL_SIZE, 1L, TimeUnit.SECONDS, new LinkedBlockingQueue(128), sThreadFactory);
/*     */   private static final int SOCKET_OPERATION_TIMEOUT = 10000;
/*     */   protected static final int DEFAULT_MAX_RETRIES = 4;
/*     */   static final long DEFAULT_INITIAL_RETRY_DELAY = 1000L;
/* 121 */   private static ParseHttpClient defaultClient = null;
/* 122 */   private static long defaultInitialRetryDelay = 1000L;
/*     */   private ParseHttpClient client;
/*     */   private HttpUriRequest request;
/* 151 */   protected int maxRetries = 4;
/*     */   protected Method method;
/*     */   protected String url;
/* 156 */   private AtomicReference<Task<Result>.TaskCompletionSource> currentTask = new AtomicReference();
/*     */ 
/*     */   private static ThreadPoolExecutor newThreadPoolExecutor(int corePoolSize, int maxPoolSize, long keepAliveTime, TimeUnit timeUnit, BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory)
/*     */   {
/*  57 */     ThreadPoolExecutor executor = new ThreadPoolExecutor(corePoolSize, maxPoolSize, keepAliveTime, timeUnit, workQueue, threadFactory);
/*     */ 
/*  59 */     if (Build.VERSION.SDK_INT >= 9) {
/*  60 */       executor.allowCoreThreadTimeOut(true);
/*     */     }
/*  62 */     return executor;
/*     */   }
/*     */ 
/*     */   public static void setDefaultClient(ParseHttpClient client)
/*     */   {
/* 125 */     defaultClient = client;
/*     */   }
/*     */ 
/*     */   public static ParseHttpClient getDefaultClient() {
/* 129 */     if (defaultClient == null) {
/* 130 */       throw new IllegalStateException("Can't send Parse HTTPS request before Parse.initialize()");
/*     */     }
/* 132 */     return defaultClient;
/*     */   }
/*     */ 
/*     */   public static void setDefaultInitialRetryDelay(long delay) {
/* 136 */     defaultInitialRetryDelay = delay;
/*     */   }
/*     */   public static long getDefaultInitialRetryDelay() {
/* 139 */     return defaultInitialRetryDelay;
/*     */   }
/*     */ 
/*     */   public static void initialize(Context context)
/*     */   {
/* 144 */     if (defaultClient == null)
/* 145 */       defaultClient = ParseHttpClient.create(context);
/*     */   }
/*     */ 
/*     */   public ParseRequest(String url)
/*     */   {
/* 160 */     this(Method.GET, url);
/*     */   }
/*     */ 
/*     */   public ParseRequest(Method method, String url) {
/* 164 */     this.client = defaultClient;
/* 165 */     this.method = method;
/* 166 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public void setClient(ParseHttpClient client) {
/* 170 */     this.client = client;
/*     */   }
/*     */ 
/*     */   public void setMethod(Method method) {
/* 174 */     this.method = method;
/*     */   }
/*     */ 
/*     */   public void setUrl(String url) {
/* 178 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public void setMaxRetries(int max) {
/* 182 */     this.maxRetries = max;
/*     */   }
/*     */ 
/*     */   protected Task<Void> onPreExecute(Task<Void> task)
/*     */   {
/* 187 */     return task;
/*     */   }
/*     */ 
/*     */   protected HttpEntity newEntity(ProgressCallback uploadProgressCallback)
/*     */   {
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */   protected HttpUriRequest newRequest(Method method, ProgressCallback uploadProgressCallback)
/*     */     throws ParseException
/*     */   {
/*     */     HttpUriRequest request;
/* 198 */     switch (9.$SwitchMap$com$parse$ParseRequest$Method[method.ordinal()]) {
/*     */     case 1:
/* 200 */       request = new HttpGet(this.url);
/* 201 */       break;
/*     */     case 4:
/* 203 */       request = new HttpDelete(this.url);
/* 204 */       break;
/*     */     case 2:
/* 211 */       String hostHeader = null;
/* 212 */       if (this.url.contains(".s3.amazonaws.com")) {
/* 213 */         Pattern s3UrlPattern = Pattern.compile("^https://([a-zA-Z0-9.]*\\.s3\\.amazonaws\\.com)/?.*");
/* 214 */         Matcher s3UrlMatcher = s3UrlPattern.matcher(this.url);
/* 215 */         if (s3UrlMatcher.matches()) {
/* 216 */           String hostname = s3UrlMatcher.group(1);
/* 217 */           this.url = this.url.replace(hostname, "s3.amazonaws.com");
/* 218 */           hostHeader = hostname;
/*     */         }
/*     */       }
/*     */ 
/* 222 */       HttpPost post = new HttpPost(this.url);
/* 223 */       post.setEntity(newEntity(uploadProgressCallback));
/*     */ 
/* 225 */       if (hostHeader != null) {
/* 226 */         post.addHeader("Host", hostHeader);
/*     */       }
/* 228 */       request = post;
/* 229 */       break;
/*     */     case 3:
/* 231 */       HttpPut put = new HttpPut(this.url);
/* 232 */       put.setEntity(newEntity(uploadProgressCallback));
/* 233 */       request = put;
/* 234 */       break;
/*     */     default:
/* 236 */       throw new IllegalStateException("Invalid method " + method);
/*     */     }
/* 238 */     AndroidHttpClient.modifyRequestToAcceptGzipResponse(request);
/* 239 */     return request;
/*     */   }
/*     */ 
/*     */   protected Task<Result> onPostExecute(Task<Response> task) throws ParseException {
/* 243 */     return task.cast();
/*     */   }
/*     */ 
/*     */   private Task<Response> sendOneRequestAsync(ProgressCallback downloadProgressCallback)
/*     */   {
/* 250 */     if (((Task.TaskCompletionSource)this.currentTask.get()).getTask().isCancelled()) {
/* 251 */       return Task.cancelled();
/*     */     }
/*     */ 
/* 254 */     return Task.forResult(null).onSuccessTask(new Continuation(downloadProgressCallback)
/*     */     {
/*     */       public Task<Response> then(Task<Void> task) throws Exception {
/* 257 */         ParseHttpResponse response = ParseRequest.this.client.execute(ParseRequest.this.request);
/* 258 */         return ParseRequest.this.onResponse(response, this.val$downloadProgressCallback);
/*     */       }
/*     */     }
/*     */     , NETWORK_EXECUTOR).continueWithTask(new Continuation()
/*     */     {
/*     */       public Task<Response> then(Task<Response> task)
/*     */         throws Exception
/*     */       {
/* 263 */         if (task.isFaulted()) {
/* 264 */           Exception error = task.getError();
/* 265 */           if ((error instanceof ClientProtocolException))
/* 266 */             return Task.forError(ParseRequest.this.newTemporaryException("bad protocol", error));
/* 267 */           if ((error instanceof IOException)) {
/* 268 */             return Task.forError(ParseRequest.this.newTemporaryException("i/o failure", error));
/*     */           }
/*     */         }
/* 271 */         return task;
/*     */       }
/*     */     }
/*     */     , Task.BACKGROUND_EXECUTOR);
/*     */   }
/*     */ 
/*     */   protected abstract Task<Response> onResponse(ParseHttpResponse paramParseHttpResponse, ProgressCallback paramProgressCallback);
/*     */ 
/*     */   public Task<Result> executeAsync()
/*     */   {
/* 280 */     return executeAsync(null, null);
/*     */   }
/*     */ 
/*     */   public Task<Result> executeAsync(ProgressCallback uploadProgressCallback, ProgressCallback downloadProgressCallback)
/*     */   {
/* 288 */     Task.TaskCompletionSource tcs = Task.create();
/* 289 */     this.currentTask.set(tcs);
/*     */ 
/* 291 */     Task.forResult(null).continueWithTask(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<Void> task) throws Exception {
/* 294 */         return ParseRequest.this.onPreExecute(task);
/*     */       }
/*     */     }).onSuccessTask(new Continuation(uploadProgressCallback, downloadProgressCallback)
/*     */     {
/*     */       public Task<Response> then(Task<Void> task)
/*     */         throws Exception
/*     */       {
/* 299 */         long delay = ParseRequest.defaultInitialRetryDelay + ()(ParseRequest.defaultInitialRetryDelay * Math.random());
/*     */ 
/* 301 */         if (ParseRequest.this.request == null) {
/* 302 */           ParseRequest.access$002(ParseRequest.this, ParseRequest.this.newRequest(ParseRequest.this.method, this.val$uploadProgressCallback));
/*     */         }
/* 304 */         return ParseRequest.this.executeAsync(0, delay, this.val$downloadProgressCallback);
/*     */       }
/*     */     }).onSuccessTask(new Continuation()
/*     */     {
/*     */       public Task<Result> then(Task<Response> task)
/*     */         throws Exception
/*     */       {
/* 309 */         return ParseRequest.this.onPostExecute(task);
/*     */       }
/*     */     }).continueWithTask(new Continuation(tcs)
/*     */     {
/*     */       public Task<Void> then(Task<Result> task)
/*     */         throws Exception
/*     */       {
/* 314 */         if (task.isCancelled())
/* 315 */           this.val$tcs.trySetCancelled();
/* 316 */         else if (task.isFaulted())
/* 317 */           this.val$tcs.trySetError(task.getError());
/*     */         else {
/* 319 */           this.val$tcs.trySetResult(task.getResult());
/*     */         }
/* 321 */         return null;
/*     */       }
/*     */     });
/* 324 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   private Task<Response> executeAsync(int attemptsMade, long delay, ProgressCallback downloadProgressCallback)
/*     */   {
/* 329 */     return sendOneRequestAsync(downloadProgressCallback).continueWithTask(new Continuation(attemptsMade, delay, downloadProgressCallback)
/*     */     {
/*     */       public Task<Response> then(Task<Response> task) throws Exception {
/* 332 */         Exception e = task.getError();
/* 333 */         if ((task.isFaulted()) && ((e instanceof ParseException))) {
/* 334 */           if (((Task.TaskCompletionSource)ParseRequest.this.currentTask.get()).getTask().isCancelled()) {
/* 335 */             return Task.cancelled();
/*     */           }
/*     */ 
/* 338 */           if (((e instanceof ParseRequest.ParseRequestException)) && (((ParseRequest.ParseRequestException)e).isPermanentFailure))
/*     */           {
/* 340 */             return task;
/*     */           }
/*     */ 
/* 343 */           if (this.val$attemptsMade < ParseRequest.this.maxRetries) {
/* 344 */             Parse.logI("com.parse.ParseRequest", "Request failed. Waiting " + this.val$delay + " milliseconds before attempt #" + (this.val$attemptsMade + 1));
/*     */ 
/* 347 */             Task.TaskCompletionSource retryTask = Task.create();
/* 348 */             Parse.getScheduledExecutor().schedule(new Runnable(retryTask)
/*     */             {
/*     */               public void run() {
/* 351 */                 ParseRequest.this.executeAsync(ParseRequest.8.this.val$attemptsMade + 1, ParseRequest.8.this.val$delay * 2L, ParseRequest.8.this.val$downloadProgressCallback).continueWithTask(new Continuation()
/*     */                 {
/*     */                   public Task<Void> then(Task<Response> task) throws Exception
/*     */                   {
/* 355 */                     if (task.isCancelled())
/* 356 */                       ParseRequest.8.1.this.val$retryTask.setCancelled();
/* 357 */                     else if (task.isFaulted())
/* 358 */                       ParseRequest.8.1.this.val$retryTask.setError(task.getError());
/*     */                     else {
/* 360 */                       ParseRequest.8.1.this.val$retryTask.setResult(task.getResult());
/*     */                     }
/* 362 */                     return null;
/*     */                   }
/*     */                 });
/*     */               }
/*     */             }
/*     */             , this.val$delay, TimeUnit.MILLISECONDS);
/*     */ 
/* 367 */             return retryTask.getTask();
/* 368 */           }if (!ParseRequest.this.request.isAborted()) {
/* 369 */             Parse.logI("com.parse.ParseRequest", "Request failed. Giving up.");
/*     */           }
/*     */         }
/* 372 */         return task;
/*     */       } } );
/*     */   }
/*     */ 
/*     */   public void cancel() {
/* 378 */     Task.TaskCompletionSource curr = (Task.TaskCompletionSource)this.currentTask.get();
/* 379 */     if (curr != null) {
/* 380 */       curr.trySetCancelled();
/*     */     }
/* 382 */     if (this.request != null)
/* 383 */       this.request.abort();
/*     */   }
/*     */ 
/*     */   protected ParseException newPermanentException(int code, String message)
/*     */   {
/* 391 */     ParseRequestException e = new ParseRequestException(code, message);
/* 392 */     e.isPermanentFailure = true;
/* 393 */     return e;
/*     */   }
/*     */ 
/*     */   protected ParseException newTemporaryException(int code, String message)
/*     */   {
/* 400 */     ParseRequestException e = new ParseRequestException(code, message);
/* 401 */     e.isPermanentFailure = false;
/* 402 */     return e;
/*     */   }
/*     */ 
/*     */   protected ParseException newTemporaryException(String message, Throwable t)
/*     */   {
/* 411 */     ParseRequestException e = new ParseRequestException(100, message, t);
/*     */ 
/* 413 */     e.isPermanentFailure = false;
/* 414 */     return e;
/*     */   }
/*     */ 
/*     */   private static class ParseRequestException extends ParseException {
/* 418 */     boolean isPermanentFailure = false;
/*     */ 
/*     */     public ParseRequestException(int theCode, String theMessage) {
/* 421 */       super(theMessage);
/*     */     }
/*     */ 
/*     */     public ParseRequestException(int theCode, String message, Throwable cause) {
/* 425 */       super(message, cause);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum Method
/*     */   {
/*  72 */     GET, POST, PUT, DELETE;
/*     */ 
/*     */     public static Method fromString(String string) {
/*  75 */       Method method = null;
/*  76 */       switch (string) {
/*     */       case "GET":
/*  78 */         method = GET;
/*  79 */         break;
/*     */       case "POST":
/*  81 */         method = POST;
/*  82 */         break;
/*     */       case "PUT":
/*  84 */         method = PUT;
/*  85 */         break;
/*     */       case "DELETE":
/*  87 */         method = DELETE;
/*  88 */         break;
/*     */       }
/*     */ 
/*  92 */       return method;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/*  97 */       String string = null;
/*  98 */       switch (ParseRequest.9.$SwitchMap$com$parse$ParseRequest$Method[ordinal()]) {
/*     */       case 1:
/* 100 */         string = "GET";
/* 101 */         break;
/*     */       case 2:
/* 103 */         string = "POST";
/* 104 */         break;
/*     */       case 3:
/* 106 */         string = "PUT";
/* 107 */         break;
/*     */       case 4:
/* 109 */         string = "DELETE";
/* 110 */         break;
/*     */       }
/*     */ 
/* 114 */       return string;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRequest
 * JD-Core Version:    0.6.0
 */