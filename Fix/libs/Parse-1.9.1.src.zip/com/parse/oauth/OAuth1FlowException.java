/*    */ package com.parse.oauth;
/*    */ 
/*    */ public class OAuth1FlowException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 4272662026279290823L;
/*    */   private final int errorCode;
/*    */   private final String description;
/*    */   private final String failingUrl;
/*    */ 
/*    */   public OAuth1FlowException(int errorCode, String description, String failingUrl)
/*    */   {
/* 13 */     super(String.format("OAuth Flow Error %d: Url: %s Description: %s", new Object[] { Integer.valueOf(errorCode), failingUrl, description }));
/*    */ 
/* 15 */     this.errorCode = errorCode;
/* 16 */     this.description = description;
/* 17 */     this.failingUrl = failingUrl;
/*    */   }
/*    */ 
/*    */   public int getErrorCode() {
/* 21 */     return this.errorCode;
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 25 */     return this.description;
/*    */   }
/*    */ 
/*    */   public String getFailingUrl() {
/* 29 */     return this.failingUrl;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.oauth.OAuth1FlowException
 * JD-Core Version:    0.6.0
 */