/*     */ package com.parse.oauth;
/*     */ 
/*     */ import android.app.Dialog;
/*     */ import android.app.ProgressDialog;
/*     */ import android.content.Context;
/*     */ import android.content.DialogInterface;
/*     */ import android.content.DialogInterface.OnCancelListener;
/*     */ import android.content.Intent;
/*     */ import android.content.res.Resources;
/*     */ import android.graphics.Bitmap;
/*     */ import android.graphics.drawable.Drawable;
/*     */ import android.net.Uri;
/*     */ import android.os.Bundle;
/*     */ import android.view.View;
/*     */ import android.view.View.OnClickListener;
/*     */ import android.view.ViewGroup.LayoutParams;
/*     */ import android.webkit.WebSettings;
/*     */ import android.webkit.WebView;
/*     */ import android.webkit.WebViewClient;
/*     */ import android.widget.FrameLayout;
/*     */ import android.widget.FrameLayout.LayoutParams;
/*     */ import android.widget.ImageView;
/*     */ import android.widget.LinearLayout;
/*     */ 
/*     */ public class OAuth1FlowDialog extends Dialog
/*     */ {
/*  27 */   private static final FrameLayout.LayoutParams FILL = new FrameLayout.LayoutParams(-1, -1);
/*     */   private final String callbackUrl;
/*     */   private final String requestUrl;
/*     */   private final String serviceUrlIdentifier;
/*     */   private final FlowResultHandler handler;
/*     */   private ProgressDialog progressDialog;
/*     */   private ImageView closeImage;
/*     */   private WebView webView;
/*     */   private FrameLayout content;
/*     */ 
/*     */   public OAuth1FlowDialog(Context context, String requestUrl, String callbackUrl, String serviceUrlIdentifier, FlowResultHandler resultHandler)
/*     */   {
/*  40 */     super(context, 16973840);
/*  41 */     this.requestUrl = requestUrl;
/*  42 */     this.callbackUrl = callbackUrl;
/*  43 */     this.serviceUrlIdentifier = serviceUrlIdentifier;
/*  44 */     this.handler = resultHandler;
/*     */ 
/*  46 */     setOnCancelListener(new DialogInterface.OnCancelListener()
/*     */     {
/*     */       public void onCancel(DialogInterface dialog) {
/*  49 */         OAuth1FlowDialog.this.handler.onCancel();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   protected void onCreate(Bundle savedInstanceState) {
/*  56 */     super.onCreate(savedInstanceState);
/*  57 */     this.progressDialog = new ProgressDialog(getContext());
/*  58 */     this.progressDialog.requestWindowFeature(1);
/*  59 */     this.progressDialog.setMessage("Loading...");
/*     */ 
/*  61 */     requestWindowFeature(1);
/*  62 */     this.content = new FrameLayout(getContext());
/*     */ 
/*  64 */     createCloseImage();
/*     */ 
/*  67 */     int webViewMargin = this.closeImage.getDrawable().getIntrinsicWidth() / 2;
/*  68 */     setUpWebView(webViewMargin);
/*     */ 
/*  71 */     this.content.addView(this.closeImage, new ViewGroup.LayoutParams(-2, -2));
/*     */ 
/*  73 */     addContentView(this.content, new ViewGroup.LayoutParams(-1, -1));
/*     */   }
/*     */ 
/*     */   private void createCloseImage() {
/*  77 */     this.closeImage = new ImageView(getContext());
/*     */ 
/*  79 */     this.closeImage.setOnClickListener(new View.OnClickListener()
/*     */     {
/*     */       public void onClick(View v) {
/*  82 */         OAuth1FlowDialog.this.cancel();
/*     */       }
/*     */     });
/*  85 */     Drawable closeDrawable = getContext().getResources().getDrawable(17301527);
/*  86 */     this.closeImage.setImageDrawable(closeDrawable);
/*     */ 
/*  89 */     this.closeImage.setVisibility(4);
/*     */   }
/*     */ 
/*     */   private void setUpWebView(int margin) {
/*  93 */     LinearLayout webViewContainer = new LinearLayout(getContext());
/*  94 */     this.webView = new WebView(getContext());
/*  95 */     this.webView.setVerticalScrollBarEnabled(false);
/*  96 */     this.webView.setHorizontalScrollBarEnabled(false);
/*  97 */     this.webView.setWebViewClient(new OAuth1WebViewClient(null));
/*  98 */     this.webView.getSettings().setJavaScriptEnabled(true);
/*  99 */     this.webView.loadUrl(this.requestUrl);
/* 100 */     this.webView.setLayoutParams(FILL);
/* 101 */     this.webView.setVisibility(4);
/*     */ 
/* 103 */     webViewContainer.setPadding(margin, margin, margin, margin);
/* 104 */     webViewContainer.addView(this.webView);
/* 105 */     this.content.addView(webViewContainer);
/*     */   }
/*     */ 
/*     */   private class OAuth1WebViewClient extends WebViewClient
/*     */   {
/*     */     private OAuth1WebViewClient()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean shouldOverrideUrlLoading(WebView view, String url)
/*     */     {
/* 132 */       if (url.startsWith(OAuth1FlowDialog.this.callbackUrl)) {
/* 133 */         OAuth1FlowDialog.this.dismiss();
/* 134 */         OAuth1FlowDialog.this.handler.onComplete(url);
/* 135 */         return true;
/* 136 */       }if (url.contains(OAuth1FlowDialog.this.serviceUrlIdentifier)) {
/* 137 */         return false;
/*     */       }
/*     */ 
/* 140 */       OAuth1FlowDialog.this.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
/* 141 */       return true;
/*     */     }
/*     */ 
/*     */     public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
/*     */     {
/* 146 */       super.onReceivedError(view, errorCode, description, failingUrl);
/* 147 */       OAuth1FlowDialog.this.dismiss();
/* 148 */       OAuth1FlowDialog.this.handler.onError(errorCode, description, failingUrl);
/*     */     }
/*     */ 
/*     */     public void onPageStarted(WebView view, String url, Bitmap favicon)
/*     */     {
/* 153 */       super.onPageStarted(view, url, favicon);
/* 154 */       OAuth1FlowDialog.this.progressDialog.show();
/*     */     }
/*     */ 
/*     */     public void onPageFinished(WebView view, String url)
/*     */     {
/* 159 */       super.onPageFinished(view, url);
/*     */       try {
/* 161 */         OAuth1FlowDialog.this.progressDialog.dismiss();
/*     */       }
/*     */       catch (IllegalArgumentException e)
/*     */       {
/*     */       }
/*     */ 
/* 171 */       OAuth1FlowDialog.this.content.setBackgroundColor(0);
/* 172 */       OAuth1FlowDialog.this.webView.setVisibility(0);
/* 173 */       OAuth1FlowDialog.this.closeImage.setVisibility(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface FlowResultHandler
/*     */   {
/*     */     public abstract void onCancel();
/*     */ 
/*     */     public abstract void onError(int paramInt, String paramString1, String paramString2);
/*     */ 
/*     */     public abstract void onComplete(String paramString);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.oauth.OAuth1FlowDialog
 * JD-Core Version:    0.6.0
 */