package com.parse;

public abstract interface SendCallback extends ParseCallback1<ParseException>
{
  public abstract void done(ParseException paramParseException);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.SendCallback
 * JD-Core Version:    0.6.0
 */