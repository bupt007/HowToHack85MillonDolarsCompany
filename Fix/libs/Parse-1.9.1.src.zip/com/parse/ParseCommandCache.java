/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import bolts.Capture;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import bolts.Task.TaskCompletionSource;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class ParseCommandCache extends ParseEventuallyQueue
/*     */ {
/*     */   private static final String TAG = "com.parse.ParseCommandCache";
/*  33 */   private static int filenameCounter = 0;
/*     */ 
/*  42 */   private static final Object lock = new Object();
/*     */   private File cachePath;
/*  63 */   private int timeoutMaxRetries = 5;
/*  64 */   private double timeoutRetryWaitSeconds = 600.0D;
/*     */ 
/*  66 */   private int maxCacheSizeBytes = 10485760;
/*     */   private boolean shouldStop;
/*     */   private boolean unprocessedCommandsExist;
/*  75 */   private HashMap<File, Task<Object>.TaskCompletionSource> pendingTasks = new HashMap();
/*     */   private boolean running;
/*     */   private final Object runningLock;
/*     */   private Logger log;
/*     */   ConnectivityNotifier notifier;
/*  88 */   ConnectivityNotifier.ConnectivityListener listener = new ConnectivityNotifier.ConnectivityListener()
/*     */   {
/*     */     public void networkConnectivityStatusChanged(Context context, Intent intent) {
/*  91 */       boolean connectionLost = intent.getBooleanExtra("noConnectivity", false);
/*     */ 
/*  93 */       if (connectionLost)
/*  94 */         ParseCommandCache.this.setConnected(false);
/*     */       else
/*  96 */         ParseCommandCache.this.setConnected(ConnectivityNotifier.isConnected(context));
/*     */     }
/*  88 */   };
/*     */ 
/*     */   private static File getCacheDir()
/*     */   {
/*  46 */     File parseDir = Parse.getParseDir();
/*  47 */     File cacheDir = new File(parseDir, "CommandCache");
/*     */ 
/*  50 */     cacheDir.mkdirs();
/*     */ 
/*  52 */     return cacheDir;
/*     */   }
/*     */ 
/*     */   public static int getPendingCount() {
/*  56 */     synchronized (lock) {
/*  57 */       String[] files = getCacheDir().list();
/*  58 */       return files == null ? 0 : files.length;
/*     */     }
/*     */   }
/*     */ 
/*     */   public ParseCommandCache(Context context)
/*     */   {
/* 102 */     setConnected(false);
/* 103 */     this.shouldStop = false;
/* 104 */     this.running = false;
/*     */ 
/* 106 */     this.runningLock = new Object();
/*     */ 
/* 108 */     this.log = Logger.getLogger("com.parse.ParseCommandCache");
/*     */ 
/* 110 */     this.cachePath = getCacheDir();
/*     */ 
/* 112 */     if (!Parse.hasPermission("android.permission.ACCESS_NETWORK_STATE"))
/*     */     {
/* 114 */       return;
/*     */     }
/*     */ 
/* 117 */     setConnected(ConnectivityNotifier.isConnected(context));
/* 118 */     this.notifier = ConnectivityNotifier.getNotifier(context);
/* 119 */     this.notifier.addListener(this.listener);
/*     */ 
/* 121 */     resume();
/*     */   }
/*     */ 
/*     */   public void onDestroy()
/*     */   {
/* 128 */     this.notifier.removeListener(this.listener);
/*     */   }
/*     */ 
/*     */   public void setTimeoutMaxRetries(int tries)
/*     */   {
/* 134 */     synchronized (lock) {
/* 135 */       this.timeoutMaxRetries = tries;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setTimeoutRetryWaitSeconds(double seconds)
/*     */   {
/* 141 */     synchronized (lock) {
/* 142 */       this.timeoutRetryWaitSeconds = seconds;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setMaxCacheSizeBytes(int bytes)
/*     */   {
/* 148 */     synchronized (lock) {
/* 149 */       this.maxCacheSizeBytes = bytes;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resume()
/*     */   {
/* 155 */     synchronized (this.runningLock) {
/* 156 */       if (!this.running) {
/* 157 */         new Thread("ParseCommandCache.runLoop()")
/*     */         {
/*     */           public void run() {
/* 160 */             ParseCommandCache.this.runLoop();
/*     */           }
/*     */         }
/* 157 */         .start();
/*     */         try
/*     */         {
/* 164 */           this.runningLock.wait();
/*     */         }
/*     */         catch (InterruptedException e) {
/* 167 */           synchronized (lock) {
/* 168 */             this.shouldStop = true;
/* 169 */             lock.notifyAll();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void pause()
/*     */   {
/* 179 */     synchronized (this.runningLock) {
/* 180 */       if (this.running) {
/* 181 */         synchronized (lock) {
/* 182 */           this.shouldStop = true;
/* 183 */           lock.notifyAll();
/*     */         }
/*     */       }
/* 186 */       while (this.running)
/*     */         try {
/* 188 */           this.runningLock.wait();
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void removeFile(File file)
/*     */   {
/* 202 */     synchronized (lock)
/*     */     {
/* 204 */       this.pendingTasks.remove(file);
/*     */       try
/*     */       {
/* 210 */         byte[] data = ParseFileUtils.readFileToByteArray(file);
/* 211 */         JSONObject json = new JSONObject(new String(data, "UTF-8"));
/*     */ 
/* 213 */         ParseNetworkCommand command = commandFromJSON(json);
/* 214 */         command.releaseLocalIds();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*     */ 
/* 220 */       ParseFileUtils.deleteQuietly(file);
/*     */     }
/*     */   }
/*     */ 
/*     */   void simulateReboot()
/*     */   {
/* 229 */     synchronized (lock) {
/* 230 */       this.pendingTasks.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   void fakeObjectUpdate()
/*     */   {
/* 240 */     notifyTestHelper(3);
/* 241 */     notifyTestHelper(1);
/* 242 */     notifyTestHelper(5);
/*     */   }
/*     */ 
/*     */   public Task<Object> enqueueEventuallyAsync(ParseNetworkCommand command, ParseObject object)
/*     */   {
/* 248 */     return enqueueEventuallyAsync(command, false, object);
/*     */   }
/*     */ 
/*     */   private Task<Object> enqueueEventuallyAsync(ParseNetworkCommand command, boolean preferOldest, ParseObject object) {
/* 265 */     Parse.requirePermission("android.permission.ACCESS_NETWORK_STATE");
/* 266 */     Task.TaskCompletionSource tcs = Task.create();
/*     */     byte[] json;
/*     */     try {
/* 271 */       if ((object != null) && (object.getObjectId() == null)) {
/* 272 */         command.setLocalId(object.getOrCreateLocalId());
/*     */       }
/* 274 */       JSONObject jsonObject = command.toJSONObject();
/* 275 */       json = jsonObject.toString().getBytes("UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/* 277 */       if (5 >= Parse.getLogLevel()) {
/* 278 */         this.log.log(Level.WARNING, "UTF-8 isn't supported.  This shouldn't happen.", e);
/*     */       }
/* 280 */       notifyTestHelper(4);
/* 281 */       return Task.forResult(null);
/*     */     }
/*     */ 
/* 286 */     if (json.length > this.maxCacheSizeBytes) {
/* 287 */       if (5 >= Parse.getLogLevel()) {
/* 288 */         this.log.warning("Unable to save command for later because it's too big.");
/*     */       }
/* 290 */       notifyTestHelper(4);
/* 291 */       return Task.forResult(null);
/*     */     }
/*     */ 
/* 294 */     synchronized (lock)
/*     */     {
/*     */       try {
/* 297 */         String[] fileNames = this.cachePath.list();
/* 298 */         if (fileNames != null) {
/* 299 */           Arrays.sort(fileNames);
/* 300 */           int size = 0;
/* 301 */           for (String fileName : fileNames) {
/* 302 */             File file = new File(this.cachePath, fileName);
/*     */ 
/* 305 */             size += (int)file.length();
/*     */           }
/* 307 */           size += json.length;
/* 308 */           if (size > this.maxCacheSizeBytes) {
/* 309 */             if (preferOldest) {
/* 310 */               if (5 >= Parse.getLogLevel()) {
/* 311 */                 this.log.warning("Unable to save command for later because storage is full.");
/*     */               }
/* 313 */               ??? = Task.forResult(null);
/*     */ 
/* 363 */               lock.notifyAll(); return ???;
/*     */             }
/* 315 */             if (5 >= Parse.getLogLevel()) {
/* 316 */               this.log.warning("Deleting old commands to make room in command cache.");
/*     */             }
/* 318 */             int indexToDelete = 0;
/* 319 */             while ((size > this.maxCacheSizeBytes) && (indexToDelete < fileNames.length)) {
/* 320 */               File file = new File(this.cachePath, fileNames[(indexToDelete++)]);
/* 321 */               size -= (int)file.length();
/* 322 */               removeFile(file);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 329 */         String prefix1 = Long.toHexString(System.currentTimeMillis());
/* 330 */         if (prefix1.length() < 16) {
/* 331 */           char[] zeroes = new char[16 - prefix1.length()];
/* 332 */           Arrays.fill(zeroes, '0');
/* 333 */           prefix1 = new String(zeroes) + prefix1;
/*     */         }
/*     */ 
/* 338 */         String prefix2 = Integer.toHexString(filenameCounter++);
/* 339 */         if (prefix2.length() < 8) {
/* 340 */           char[] zeroes = new char[8 - prefix2.length()];
/* 341 */           Arrays.fill(zeroes, '0');
/* 342 */           prefix2 = new String(zeroes) + prefix2;
/*     */         }
/*     */ 
/* 345 */         String prefix = "CachedCommand_" + prefix1 + "_" + prefix2 + "_";
/*     */ 
/* 348 */         File path = File.createTempFile(prefix, "", this.cachePath);
/*     */ 
/* 351 */         this.pendingTasks.put(path, tcs);
/* 352 */         command.retainLocalIds();
/* 353 */         ParseFileUtils.writeByteArrayToFile(path, json);
/*     */ 
/* 355 */         notifyTestHelper(3);
/*     */ 
/* 357 */         this.unprocessedCommandsExist = true;
/*     */       } catch (IOException e) {
/* 359 */         if (5 >= Parse.getLogLevel())
/* 360 */           this.log.log(Level.WARNING, "Unable to save command for later.", e);
/*     */       }
/*     */       finally {
/* 363 */         lock.notifyAll();
/*     */       }
/*     */     }
/* 366 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public int pendingCount()
/*     */   {
/* 374 */     return getPendingCount();
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 381 */     synchronized (lock) {
/* 382 */       File[] files = this.cachePath.listFiles();
/* 383 */       if (files == null) {
/* 384 */         return;
/*     */       }
/* 386 */       for (File file : files) {
/* 387 */         removeFile(file);
/*     */       }
/* 389 */       this.pendingTasks.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setConnected(boolean connected)
/*     */   {
/* 397 */     synchronized (lock) {
/* 398 */       if ((isConnected() != connected) && 
/* 399 */         (connected)) {
/* 400 */         lock.notifyAll();
/*     */       }
/*     */ 
/* 403 */       super.setConnected(connected);
/*     */     }
/*     */   }
/*     */ 
/*     */   private <T> T waitForTaskWithoutLock(Task<T> task)
/*     */     throws ParseException
/*     */   {
/* 412 */     synchronized (lock) {
/* 413 */       Capture finished = new Capture(Boolean.valueOf(false));
/* 414 */       task.continueWith(new Object(finished)
/*     */       {
/*     */         public Void then(Task<T> task) throws Exception {
/* 417 */           this.val$finished.set(Boolean.valueOf(true));
/* 418 */           synchronized (ParseCommandCache.lock) {
/* 419 */             ParseCommandCache.lock.notifyAll();
/*     */           }
/* 421 */           return null;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR);
/*     */ 
/* 424 */       while (!((Boolean)finished.get()).booleanValue()) {
/*     */         try {
/* 426 */           lock.wait();
/*     */         } catch (InterruptedException ie) {
/* 428 */           this.shouldStop = true;
/*     */         }
/*     */       }
/* 431 */       return Parse.waitForTask(task);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void maybeRunAllCommandsNow(int retriesRemaining)
/*     */   {
/* 443 */     synchronized (lock) {
/* 444 */       this.unprocessedCommandsExist = false;
/*     */ 
/* 446 */       if (!isConnected())
/*     */       {
/* 448 */         return;
/*     */       }
/*     */ 
/* 451 */       String[] fileNames = this.cachePath.list();
/* 452 */       if ((fileNames == null) || (fileNames.length == 0)) {
/* 453 */         return;
/*     */       }
/* 455 */       Arrays.sort(fileNames);
/* 456 */       for (String fileName : fileNames) {
/* 457 */         File file = new File(this.cachePath, fileName);
/*     */         JSONObject json;
/*     */         try {
/* 462 */           byte[] data = ParseFileUtils.readFileToByteArray(file);
/* 463 */           json = new JSONObject(new String(data, "UTF-8"));
/*     */         }
/*     */         catch (FileNotFoundException e) {
/* 466 */           if (6 >= Parse.getLogLevel()) {
/* 467 */             this.log.log(Level.SEVERE, "File disappeared from cache while being read.", e);
/*     */           }
/* 469 */           continue;
/*     */         } catch (IOException e) {
/* 471 */           if (6 >= Parse.getLogLevel()) {
/* 472 */             this.log.log(Level.SEVERE, "Unable to read contents of file in cache.", e);
/*     */           }
/* 474 */           removeFile(file);
/* 475 */           continue;
/*     */         } catch (JSONException e) {
/* 477 */           if (6 >= Parse.getLogLevel()) {
/* 478 */             this.log.log(Level.SEVERE, "Error parsing JSON found in cache.", e);
/*     */           }
/* 480 */           removeFile(file);
/* 481 */           continue;
/*     */         }
/*     */ 
/* 486 */         Task.TaskCompletionSource tcs = this.pendingTasks.containsKey(file) ? (Task.TaskCompletionSource)this.pendingTasks.get(file) : null;
/*     */         ParseNetworkCommand command;
/*     */         try
/*     */         {
/* 490 */           command = commandFromJSON(json);
/*     */         } catch (JSONException e) {
/* 492 */           if (6 >= Parse.getLogLevel()) {
/* 493 */             this.log.log(Level.SEVERE, "Unable to create ParseCommand from JSON.", e);
/*     */           }
/* 495 */           removeFile(file);
/* 496 */           continue;
/*     */         }
/*     */         try
/*     */         {
/* 500 */           String localId = command.getLocalId();
/* 501 */           Task commandTask = command.executeAsync().continueWithTask(new Object(tcs, localId, command)
/*     */           {
/*     */             public Task<Object> then(Task<Object> task) throws Exception
/*     */             {
/* 505 */               Exception error = task.getError();
/* 506 */               if (error != null) {
/* 507 */                 if ((!(error instanceof ParseException)) || (((ParseException)error).getCode() != 100))
/*     */                 {
/* 511 */                   if (this.val$tcs != null) {
/* 512 */                     this.val$tcs.setError(error);
/*     */                   }
/*     */                 }
/* 515 */                 return task;
/*     */               }
/*     */ 
/* 518 */               Object result = task.getResult();
/* 519 */               if (this.val$tcs != null)
/* 520 */                 this.val$tcs.setResult(result);
/* 521 */               else if (this.val$localId != null)
/*     */               {
/* 523 */                 if ((result instanceof JSONObject)) {
/* 524 */                   JSONObject json = (JSONObject)result;
/* 525 */                   String objectId = null;
/* 526 */                   if ((this.val$command instanceof ParseRESTCommand)) {
/* 527 */                     objectId = json.optString("objectId", null);
/*     */                   } else {
/* 529 */                     JSONObject data = json.optJSONObject("data");
/* 530 */                     if (data != null) {
/* 531 */                       objectId = data.optString("objectId", null);
/*     */                     }
/*     */                   }
/* 534 */                   if (objectId != null) {
/* 535 */                     LocalIdManager.getDefaultInstance().setObjectId(this.val$localId, objectId);
/*     */                   }
/*     */                 }
/*     */               }
/* 539 */               return task;
/*     */             }
/*     */           });
/* 543 */           waitForTaskWithoutLock(commandTask);
/* 544 */           if (tcs != null) {
/* 545 */             waitForTaskWithoutLock(tcs.getTask());
/*     */           }
/*     */ 
/* 549 */           removeFile(file);
/* 550 */           notifyTestHelper(1);
/*     */         } catch (ParseException e) {
/* 552 */           if (e.getCode() == 100) {
/* 553 */             if (retriesRemaining > 0)
/*     */             {
/* 556 */               if (4 >= Parse.getLogLevel()) {
/* 557 */                 this.log.info("Network timeout in command cache. Waiting for " + this.timeoutRetryWaitSeconds + " seconds and then retrying " + retriesRemaining + " times.");
/*     */               }
/*     */ 
/* 560 */               long currentTime = System.currentTimeMillis();
/* 561 */               long waitUntil = currentTime + ()(this.timeoutRetryWaitSeconds * 1000.0D);
/* 562 */               while (currentTime < waitUntil)
/*     */               {
/* 565 */                 if ((!isConnected()) || (this.shouldStop)) {
/* 566 */                   if (4 >= Parse.getLogLevel()) {
/* 567 */                     this.log.info("Aborting wait because runEventually thread should stop.");
/*     */                   }
/* 569 */                   return;
/*     */                 }
/*     */                 try {
/* 572 */                   lock.wait(waitUntil - currentTime);
/*     */                 } catch (InterruptedException ie) {
/* 574 */                   this.shouldStop = true;
/*     */                 }
/* 576 */                 currentTime = System.currentTimeMillis();
/* 577 */                 if (currentTime >= waitUntil - ()(this.timeoutRetryWaitSeconds * 1000.0D))
/*     */                   continue;
/* 579 */                 currentTime = waitUntil - ()(this.timeoutRetryWaitSeconds * 1000.0D);
/*     */               }
/*     */ 
/* 582 */               maybeRunAllCommandsNow(retriesRemaining - 1);
/*     */             } else {
/* 584 */               setConnected(false);
/*     */ 
/* 586 */               notifyTestHelper(7);
/*     */             }
/*     */           } else {
/* 589 */             if (6 >= Parse.getLogLevel()) {
/* 590 */               this.log.log(Level.SEVERE, "Failed to run command.", e);
/*     */             }
/*     */ 
/* 594 */             removeFile(file);
/* 595 */             notifyTestHelper(2, e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void runLoop()
/*     */   {
/* 611 */     if (4 >= Parse.getLogLevel()) {
/* 612 */       this.log.info("Parse command cache has started processing queued commands.");
/*     */     }
/*     */ 
/* 615 */     synchronized (this.runningLock) {
/* 616 */       if (this.running)
/*     */       {
/* 618 */         return;
/*     */       }
/* 620 */       this.running = true;
/* 621 */       this.runningLock.notifyAll();
/*     */     }
/*     */     boolean shouldRun;
/* 626 */     synchronized (lock) {
/* 627 */       shouldRun = (!this.shouldStop) && (!Thread.interrupted());
/*     */     }
/* 629 */     while (shouldRun) {
/* 630 */       synchronized (lock) {
/*     */         try {
/* 632 */           maybeRunAllCommandsNow(this.timeoutMaxRetries);
/* 633 */           if (!this.shouldStop)
/*     */           {
/*     */             try
/*     */             {
/* 639 */               if (!this.unprocessedCommandsExist)
/* 640 */                 lock.wait();
/*     */             }
/*     */             catch (InterruptedException e) {
/* 643 */               this.shouldStop = true;
/*     */             }
/*     */           }
/*     */         } catch (Exception e) {
/* 647 */           if (6 >= Parse.getLogLevel())
/* 648 */             this.log.log(Level.SEVERE, "saveEventually thread had an error.", e);
/*     */         }
/*     */         finally {
/* 651 */           shouldRun = !this.shouldStop;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 656 */     synchronized (this.runningLock) {
/* 657 */       this.running = false;
/* 658 */       this.runningLock.notifyAll();
/*     */     }
/* 660 */     if (4 >= Parse.getLogLevel())
/* 661 */       this.log.info("saveEventually thread has stopped processing commands.");
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseCommandCache
 * JD-Core Version:    0.6.0
 */