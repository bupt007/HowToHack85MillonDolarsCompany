/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONTokener;
/*     */ 
/*     */ class ParseKeyValueCache
/*     */ {
/*     */   private static final String TAG = "ParseKeyValueCache";
/*     */   private static final String DIR_NAME = "ParseKeyValueCache";
/*     */   static final int DEFAULT_MAX_KEY_VALUE_CACHE_BYTES = 2097152;
/*     */   static final int DEFAULT_MAX_KEY_VALUE_CACHE_FILES = 1000;
/*  36 */   private static final Object MUTEX_IO = new Object();
/*     */ 
/*  38 */   static int maxKeyValueCacheBytes = 2097152;
/*  39 */   static int maxKeyValueCacheFiles = 1000;
/*     */   private static File directory;
/*     */ 
/*     */   static void initialize(Context context)
/*     */   {
/*  47 */     File appCacheDir = context.getCacheDir();
/*  48 */     directory = new File(appCacheDir, "ParseKeyValueCache");
/*  49 */     if ((!directory.isDirectory()) && (!directory.mkdir()))
/*  50 */       throw new RuntimeException("Could not create ParseKeyValueCache directory");
/*     */   }
/*     */ 
/*     */   static File getKeyValueCacheDir()
/*     */   {
/*  55 */     return directory;
/*     */   }
/*     */ 
/*     */   private static File getKeyValueCacheFile(String key) {
/*  59 */     String suffix = '.' + key;
/*  60 */     File[] matches = getKeyValueCacheDir().listFiles(new FilenameFilter(suffix)
/*     */     {
/*     */       public boolean accept(File dir, String filename) {
/*  63 */         return filename.endsWith(this.val$suffix);
/*     */       }
/*     */     });
/*  66 */     return (matches == null) || (matches.length == 0) ? null : matches[0];
/*     */   }
/*     */ 
/*     */   private static long getKeyValueCacheAge(File cacheFile)
/*     */   {
/*  72 */     String name = cacheFile.getName();
/*     */     try {
/*  74 */       return Long.parseLong(name.substring(0, name.indexOf(46))); } catch (NumberFormatException e) {
/*     */     }
/*  76 */     return 0L;
/*     */   }
/*     */ 
/*     */   private static File createKeyValueCacheFile(String key)
/*     */   {
/*  81 */     String filename = String.valueOf(new Date().getTime()) + '.' + key;
/*  82 */     return new File(getKeyValueCacheDir(), filename);
/*     */   }
/*     */ 
/*     */   static void clearKeyValueCacheDir()
/*     */   {
/*  87 */     synchronized (MUTEX_IO) {
/*  88 */       File dir = getKeyValueCacheDir();
/*  89 */       File[] entries = dir.listFiles();
/*  90 */       if (entries == null) {
/*  91 */         return;
/*     */       }
/*  93 */       for (File entry : entries)
/*  94 */         entry.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */   static void saveToKeyValueCache(String key, String value)
/*     */   {
/* 101 */     synchronized (MUTEX_IO) {
/* 102 */       File prior = getKeyValueCacheFile(key);
/* 103 */       if (prior != null) {
/* 104 */         prior.delete();
/*     */       }
/* 106 */       File f = createKeyValueCacheFile(key);
/*     */       try {
/* 108 */         FileOutputStream out = new FileOutputStream(f);
/* 109 */         out.write(value.getBytes("UTF-8"));
/* 110 */         out.close();
/*     */       }
/*     */       catch (UnsupportedEncodingException e)
/*     */       {
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */       }
/* 118 */       File[] files = getKeyValueCacheDir().listFiles();
/* 119 */       int numFiles = files.length;
/* 120 */       int numBytes = 0;
/* 121 */       for (File file : files) {
/* 122 */         numBytes = (int)(numBytes + file.length());
/*     */       }
/* 124 */       if ((numFiles > maxKeyValueCacheFiles) || (numBytes > maxKeyValueCacheBytes))
/*     */       {
/* 130 */         Arrays.sort(files, new Comparator()
/*     */         {
/*     */           public int compare(File f1, File f2) {
/* 133 */             int dateCompare = Long.valueOf(f1.lastModified()).compareTo(Long.valueOf(f2.lastModified()));
/* 134 */             if (dateCompare != 0) {
/* 135 */               return dateCompare;
/*     */             }
/* 137 */             return f1.getName().compareTo(f2.getName());
/*     */           }
/*     */         });
/* 142 */         for (File file : files) {
/* 143 */           numFiles--;
/* 144 */           numBytes = (int)(numBytes - file.length());
/* 145 */           file.delete();
/*     */ 
/* 147 */           if ((numFiles <= maxKeyValueCacheFiles) && (numBytes <= maxKeyValueCacheBytes))
/*     */             break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static void clearFromKeyValueCache(String key)
/*     */   {
/* 158 */     synchronized (MUTEX_IO) {
/* 159 */       File file = getKeyValueCacheFile(key);
/* 160 */       if (file != null)
/* 161 */         file.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */   static String loadFromKeyValueCache(String key, long maxAgeMilliseconds)
/*     */   {
/* 169 */     synchronized (MUTEX_IO) {
/* 170 */       File file = getKeyValueCacheFile(key);
/* 171 */       if (file == null) {
/* 172 */         return null;
/*     */       }
/*     */ 
/* 175 */       Date now = new Date();
/* 176 */       long oldestAcceptableAge = Math.max(0L, now.getTime() - maxAgeMilliseconds);
/* 177 */       if (getKeyValueCacheAge(file) < oldestAcceptableAge) {
/* 178 */         return null;
/*     */       }
/*     */ 
/* 182 */       file.setLastModified(now.getTime());
/*     */       try
/*     */       {
/* 185 */         RandomAccessFile f = new RandomAccessFile(file, "r");
/* 186 */         byte[] bytes = new byte[(int)f.length()];
/* 187 */         f.readFully(bytes);
/* 188 */         f.close();
/* 189 */         return new String(bytes, "UTF-8");
/*     */       } catch (IOException e) {
/* 191 */         Parse.logE("ParseKeyValueCache", "error reading from cache", e);
/* 192 */         return null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static Object jsonFromKeyValueCache(String key, long maxAgeMilliseconds)
/*     */   {
/* 199 */     String raw = loadFromKeyValueCache(key, maxAgeMilliseconds);
/* 200 */     if (raw == null) {
/* 201 */       return null;
/*     */     }
/* 203 */     JSONTokener tokener = new JSONTokener(raw);
/*     */     try
/*     */     {
/* 206 */       return tokener.nextValue();
/*     */     } catch (JSONException e) {
/* 208 */       Parse.logE("ParseKeyValueCache", "corrupted cache for " + key, e);
/* 209 */       clearFromKeyValueCache(key);
/* 210 */     }return null;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseKeyValueCache
 * JD-Core Version:    0.6.0
 */