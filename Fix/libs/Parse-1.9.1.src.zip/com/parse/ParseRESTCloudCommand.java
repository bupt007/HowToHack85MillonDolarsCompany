/*    */ package com.parse;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ class ParseRESTCloudCommand extends ParseRESTCommand
/*    */ {
/*    */   private ParseRESTCloudCommand(String httpPath, ParseRequest.Method httpMethod, Map<String, ?> parameters, String sessionToken)
/*    */   {
/*  9 */     super(httpPath, httpMethod, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTCloudCommand callFunctionCommand(String functionName, Map<String, ?> parameters, String sessionToken)
/*    */   {
/* 14 */     String httpPath = String.format("functions/%s", new Object[] { functionName });
/* 15 */     return new ParseRESTCloudCommand(httpPath, ParseRequest.Method.POST, parameters, sessionToken);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTCloudCommand
 * JD-Core Version:    0.6.0
 */