/*     */ package com.parse;
/*     */ 
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ @ParseClassName("_Pin")
/*     */ class ParsePin extends ParseObject
/*     */ {
/*     */   private static final String KEY_NAME = "_name";
/*     */   private static final String KEY_OBJECTS = "_objects";
/*     */ 
/*     */   static Task<ParsePin> getParsePin(String name)
/*     */   {
/*  16 */     ParseQuery query = ParseQuery.getQuery(ParsePin.class).whereEqualTo("_name", name);
/*     */ 
/*  22 */     return OfflineStore.getCurrent().findAsync(query, null, null).onSuccess(new Continuation(name)
/*     */     {
/*     */       public ParsePin then(Task<List<ParsePin>> task) throws Exception {
/*  25 */         ParsePin pin = null;
/*  26 */         if ((task.getResult() != null) && (((List)task.getResult()).size() > 0)) {
/*  27 */           pin = (ParsePin)((List)task.getResult()).get(0);
/*     */         }
/*     */ 
/*  32 */         if (pin == null) {
/*  33 */           pin = (ParsePin)ParseObject.create(ParsePin.class);
/*  34 */           pin.setName(this.val$name);
/*     */         }
/*  36 */         return pin;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   static <T extends ParseObject> Task<Void> pinAllObjectsAsync(String name, List<T> objects, boolean includeChildren) {
/*  43 */     if ((objects == null) || (objects.size() == 0)) {
/*  44 */       return Task.forResult(null);
/*     */     }
/*     */ 
/*  47 */     return getParsePin(name).onSuccessTask(new Continuation(objects, includeChildren)
/*     */     {
/*     */       public Task<Void> then(Task<ParsePin> task) throws Exception {
/*  50 */         ParsePin pin = (ParsePin)task.getResult();
/*  51 */         OfflineStore store = OfflineStore.getCurrent();
/*     */ 
/*  62 */         List modified = pin.getObjects();
/*  63 */         if (modified == null)
/*  64 */           modified = new ArrayList(this.val$objects);
/*     */         else {
/*  66 */           for (ParseObject object : this.val$objects) {
/*  67 */             if (!modified.contains(object)) {
/*  68 */               modified.add(object);
/*     */             }
/*     */           }
/*     */         }
/*  72 */         pin.setObjects(modified);
/*     */ 
/*  74 */         if (this.val$includeChildren) {
/*  75 */           return store.saveLocallyAsync(pin);
/*     */         }
/*  77 */         return store.saveLocallyAsync(pin, pin.getObjects());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   static <T extends ParseObject> Task<Void> unpinAllObjectsAsync(String name, List<T> objects) {
/*  84 */     if ((objects == null) || (objects.size() == 0)) {
/*  85 */       return Task.forResult(null);
/*     */     }
/*     */ 
/*  88 */     return getParsePin(name).onSuccessTask(new Continuation(objects)
/*     */     {
/*     */       public Task<Void> then(Task<ParsePin> task) throws Exception {
/*  91 */         ParsePin pin = (ParsePin)task.getResult();
/*  92 */         OfflineStore store = OfflineStore.getCurrent();
/*     */ 
/* 103 */         List modified = pin.getObjects();
/* 104 */         if (modified == null)
/*     */         {
/* 106 */           return Task.forResult(null);
/*     */         }
/*     */ 
/* 109 */         modified.removeAll(this.val$objects);
/* 110 */         if (modified.size() == 0) {
/* 111 */           return store.unpinAsync(pin);
/*     */         }
/* 113 */         pin.setObjects(modified);
/*     */ 
/* 115 */         return store.saveLocallyAsync(pin);
/*     */       } } );
/*     */   }
/*     */ 
/*     */   static Task<Void> unpinAllObjectsAsync(String name) {
/* 121 */     return getParsePin(name).continueWithTask(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<ParsePin> task) throws Exception {
/* 124 */         if (task.isFaulted()) {
/* 125 */           return task.makeVoid();
/*     */         }
/* 127 */         ParsePin pin = (ParsePin)task.getResult();
/* 128 */         return OfflineStore.getCurrent().unpinAsync(pin);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   boolean needsDefaultACL()
/*     */   {
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 142 */     return getString("_name");
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 146 */     put("_name", name);
/*     */   }
/*     */ 
/*     */   public List<ParseObject> getObjects() {
/* 150 */     return getList("_objects");
/*     */   }
/*     */ 
/*     */   public void setObjects(List<ParseObject> objects) {
/* 154 */     put("_objects", objects);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParsePin
 * JD-Core Version:    0.6.0
 */