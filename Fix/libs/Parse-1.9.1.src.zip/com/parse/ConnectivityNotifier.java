/*    */ package com.parse;
/*    */ 
/*    */ import android.content.BroadcastReceiver;
/*    */ import android.content.Context;
/*    */ import android.content.Intent;
/*    */ import android.content.IntentFilter;
/*    */ import android.content.ReceiverCallNotAllowedException;
/*    */ import android.net.ConnectivityManager;
/*    */ import android.net.NetworkInfo;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ class ConnectivityNotifier extends BroadcastReceiver
/*    */ {
/*    */   private static final String TAG = "com.parse.ConnectivityNotifier";
/* 22 */   private static final ConnectivityNotifier singleton = new ConnectivityNotifier();
/*    */ 
/* 39 */   private Set<ConnectivityListener> listeners = new HashSet();
/* 40 */   private boolean hasRegisteredReceiver = false;
/* 41 */   private final Object lock = new Object();
/*    */ 
/*    */   public static ConnectivityNotifier getNotifier(Context context)
/*    */   {
/* 24 */     singleton.tryToRegisterForNetworkStatusNotifications(context);
/* 25 */     return singleton;
/*    */   }
/*    */ 
/*    */   public static boolean isConnected(Context context) {
/* 29 */     ConnectivityManager connectivityManager = (ConnectivityManager)context.getSystemService("connectivity");
/*    */ 
/* 31 */     if (connectivityManager == null) {
/* 32 */       return false;
/*    */     }
/*    */ 
/* 35 */     NetworkInfo network = connectivityManager.getActiveNetworkInfo();
/* 36 */     return (network != null) && (network.isConnected());
/*    */   }
/*    */ 
/*    */   public void addListener(ConnectivityListener delegate)
/*    */   {
/* 44 */     synchronized (this.lock) {
/* 45 */       this.listeners.add(delegate);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void removeListener(ConnectivityListener delegate) {
/* 50 */     synchronized (this.lock) {
/* 51 */       this.listeners.remove(delegate);
/*    */     }
/*    */   }
/*    */ 
/*    */   private boolean tryToRegisterForNetworkStatusNotifications(Context context) {
/* 56 */     synchronized (this.lock) {
/* 57 */       if (this.hasRegisteredReceiver) {
/* 58 */         return true;
/*    */       }
/*    */       try
/*    */       {
/* 62 */         if (context == null) {
/* 63 */           return false;
/*    */         }
/* 65 */         context = context.getApplicationContext();
/* 66 */         context.registerReceiver(this, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
/* 67 */         this.hasRegisteredReceiver = true;
/* 68 */         return true;
/*    */       }
/*    */       catch (ReceiverCallNotAllowedException e) {
/* 71 */         Parse.logV("com.parse.ConnectivityNotifier", "Cannot register a broadcast receiver because the executing thread is currently in a broadcast receiver. Will try again later.");
/*    */ 
/* 73 */         return false;
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public void onReceive(Context context, Intent intent)
/*    */   {
/*    */     List listenersCopy;
/* 81 */     synchronized (this.lock) {
/* 82 */       listenersCopy = new ArrayList(this.listeners);
/*    */     }
/* 84 */     for (ConnectivityListener delegate : listenersCopy)
/* 85 */       delegate.networkConnectivityStatusChanged(context, intent);
/*    */   }
/*    */ 
/*    */   public static abstract interface ConnectivityListener
/*    */   {
/*    */     public abstract void networkConnectivityStatusChanged(Context paramContext, Intent paramIntent);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ConnectivityNotifier
 * JD-Core Version:    0.6.0
 */