/*    */ package com.parse;
/*    */ 
/*    */ import java.lang.ref.WeakReference;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ class WeakValueHashMap<K, V>
/*    */ {
/*    */   private HashMap<K, WeakReference<V>> map;
/*    */ 
/*    */   public WeakValueHashMap()
/*    */   {
/* 13 */     this.map = new HashMap();
/*    */   }
/*    */ 
/*    */   public void put(K key, V value) {
/* 17 */     this.map.put(key, new WeakReference(value));
/*    */   }
/*    */ 
/*    */   public V get(K key)
/*    */   {
/* 25 */     WeakReference reference = (WeakReference)this.map.get(key);
/* 26 */     if (reference == null) {
/* 27 */       return null;
/*    */     }
/*    */ 
/* 30 */     Object value = reference.get();
/* 31 */     if (value == null) {
/* 32 */       this.map.remove(key);
/*    */     }
/*    */ 
/* 35 */     return value;
/*    */   }
/*    */ 
/*    */   public void remove(K key) {
/* 39 */     this.map.remove(key);
/*    */   }
/*    */ 
/*    */   public void clear() {
/* 43 */     this.map.clear();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.WeakValueHashMap
 * JD-Core Version:    0.6.0
 */