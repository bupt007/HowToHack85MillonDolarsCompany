/*     */ package com.parse;
/*     */ 
/*     */ import bolts.Task;
/*     */ import com.parse.entity.mime.HttpMultipartMode;
/*     */ import com.parse.entity.mime.content.ByteArrayBody;
/*     */ import com.parse.entity.mime.content.StringBody;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Iterator;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class ParseAWSRequest extends ParseRequest<byte[], byte[]>
/*     */ {
/*     */   private String mimeType;
/*     */   private JSONObject postParams;
/*     */   private byte[] data;
/*     */ 
/*     */   public ParseAWSRequest(String url)
/*     */   {
/*  30 */     super(url);
/*     */   }
/*     */ 
/*     */   public ParseAWSRequest(ParseRequest.Method method, String url) {
/*  34 */     super(method, url);
/*     */   }
/*     */ 
/*     */   public void setMimeType(String mimeType) {
/*  38 */     this.mimeType = mimeType;
/*     */   }
/*     */ 
/*     */   public void setPostParams(JSONObject postParams) {
/*  42 */     this.postParams = postParams;
/*     */   }
/*     */ 
/*     */   public void setData(byte[] data) {
/*  46 */     this.data = data;
/*     */   }
/*     */ 
/*     */   protected HttpEntity newEntity(ProgressCallback uploadProgressCallback)
/*     */   {
/*  51 */     CountingMultipartEntity entity = new CountingMultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE, uploadProgressCallback);
/*     */     try
/*     */     {
/*  55 */       entity.addPart("Content-Type", new StringBody(this.mimeType));
/*     */     } catch (UnsupportedEncodingException e) {
/*  57 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */ 
/*  60 */     Iterator keys = this.postParams.keys();
/*  61 */     while (keys.hasNext()) {
/*  62 */       String key = (String)keys.next();
/*     */       try
/*     */       {
/*  65 */         entity.addPart(key, new StringBody(this.postParams.getString(key)));
/*     */       } catch (UnsupportedEncodingException e) {
/*  67 */         throw new RuntimeException(e.getMessage());
/*     */       } catch (JSONException e) {
/*  69 */         throw new RuntimeException(e.getMessage());
/*     */       }
/*     */     }
/*     */ 
/*  73 */     entity.addPart("file", new ByteArrayBody(this.data, this.mimeType, "file"));
/*  74 */     return entity;
/*     */   }
/*     */ 
/*     */   protected Task<byte[]> onResponse(ParseHttpResponse response, ProgressCallback downloadProgressCallback)
/*     */   {
/*  80 */     int statusCode = response.getStatusCode();
/*  81 */     if (((statusCode < 200) || (statusCode >= 300)) && (statusCode != 304))
/*     */     {
/*  84 */       String action = this.method == ParseRequest.Method.GET ? "Download from" : "Upload to";
/*  85 */       return Task.forError(new ParseException(100, String.format("%s S3 failed. %s", new Object[] { action, Integer.valueOf(statusCode) })));
/*     */     }
/*     */ 
/*  89 */     if (this.method != ParseRequest.Method.GET) {
/*  90 */       return null;
/*     */     }
/*     */ 
/*  93 */     int totalSize = response.getTotalSize();
/*  94 */     int downloadedSize = 0;
/*  95 */     InputStream responseStream = null;
/*     */     try {
/*  97 */       responseStream = response.getContent();
/*  98 */       ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/*     */ 
/* 101 */       byte[] data = new byte[32768];
/*     */ 
/* 104 */       ParseCallback2 c = null;
/* 105 */       if (downloadProgressCallback != null) {
/* 106 */         c = new ParseCallback2(downloadProgressCallback) {
/* 107 */           Integer maxProgressSoFar = Integer.valueOf(0);
/*     */ 
/*     */           public void done(Integer percentDone, ParseException e)
/*     */           {
/* 111 */             if (percentDone.intValue() > this.maxProgressSoFar.intValue()) {
/* 112 */               this.maxProgressSoFar = percentDone;
/* 113 */               this.val$downloadProgressCallback.done(percentDone);
/*     */             }
/*     */           }
/*     */         };
/*     */       }
/* 119 */       while ((nRead = responseStream.read(data, 0, data.length)) != -1) {
/* 120 */         buffer.write(data, 0, nRead);
/* 121 */         downloadedSize += nRead;
/* 122 */         if ((c != null) && (totalSize != -1)) {
/* 123 */           progressToReport = Math.round(downloadedSize / totalSize * 100.0F);
/*     */ 
/* 125 */           Parse.callbackOnMainThreadAsync(Task.forResult(Integer.valueOf(progressToReport)), c);
/*     */         }
/*     */       }
/* 128 */       int progressToReport = Task.forResult(buffer.toByteArray());
/*     */       return progressToReport;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 130 */       int nRead = Task.forError(e);
/*     */       return nRead; } finally { ParseIOUtils.closeQuietly(responseStream); } throw localObject;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseAWSRequest
 * JD-Core Version:    0.6.0
 */