/*    */ package com.parse;
/*    */ 
/*    */ import bolts.Continuation;
/*    */ import bolts.Task;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ @ParseClassName("_Session")
/*    */ public class ParseSession extends ParseObject
/*    */ {
/*    */   private static final String KEY_SESSION_TOKEN = "sessionToken";
/*    */   private static final String KEY_CREATED_WITH = "createdWith";
/*    */   private static final String KEY_RESTRICTED = "restricted";
/*    */   private static final String KEY_USER = "user";
/*    */   private static final String KEY_EXPIRES_AT = "expiresAt";
/*    */   private static final String KEY_INSTALLATION_ID = "installationId";
/* 26 */   private static final List<String> READ_ONLY_KEYS = Collections.unmodifiableList(Arrays.asList(new String[] { "sessionToken", "createdWith", "restricted", "user", "expiresAt", "installationId" }));
/*    */ 
/*    */   public static Task<ParseSession> getCurrentSessionInBackground()
/*    */   {
/* 37 */     return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation()
/*    */     {
/*    */       public Task<JSONObject> then(Task<String> task) throws Exception {
/* 40 */         String sessionToken = (String)task.getResult();
/* 41 */         if (sessionToken == null) {
/* 42 */           return Task.forResult(null);
/*    */         }
/* 44 */         return ParseRESTSessionCommand.getCurrentSessionCommand(sessionToken).executeAsync().cast();
/*    */       }
/*    */     }).onSuccess(new Continuation()
/*    */     {
/*    */       public ParseSession then(Task<JSONObject> task)
/*    */         throws Exception
/*    */       {
/* 49 */         JSONObject json = (JSONObject)task.getResult();
/* 50 */         if (json == null) {
/* 51 */           return null;
/*    */         }
/* 53 */         return (ParseSession)ParseObject.fromJSON(json, "_Session", true);
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   public static void getCurrentSessionInBackground(GetCallback<ParseSession> callback)
/*    */   {
/* 65 */     Parse.callbackOnMainThreadAsync(getCurrentSessionInBackground(), callback);
/*    */   }
/*    */ 
/*    */   public static ParseQuery<ParseSession> getQuery()
/*    */   {
/* 74 */     return ParseQuery.getQuery(ParseSession.class);
/*    */   }
/*    */ 
/*    */   boolean needsDefaultACL()
/*    */   {
/* 79 */     return false;
/*    */   }
/*    */ 
/*    */   boolean isKeyMutable(String key)
/*    */   {
/* 84 */     return !READ_ONLY_KEYS.contains(key);
/*    */   }
/*    */ 
/*    */   public String getSessionToken()
/*    */   {
/* 91 */     return getString("sessionToken");
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseSession
 * JD-Core Version:    0.6.0
 */