/*    */ package com.parse;
/*    */ 
/*    */ import bolts.Continuation;
/*    */ import bolts.Task;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ abstract class ParseAuthenticationProvider
/*    */ {
/*    */   public abstract String getAuthType();
/*    */ 
/*    */   public abstract Task<JSONObject> authenticateAsync();
/*    */ 
/*    */   public abstract void deauthenticate();
/*    */ 
/*    */   public abstract boolean restoreAuthentication(JSONObject paramJSONObject);
/*    */ 
/*    */   public abstract void cancel();
/*    */ 
/*    */   public Task<ParseUser> logInAsync()
/*    */   {
/* 50 */     return authenticateAsync().onSuccessTask(new Continuation()
/*    */     {
/*    */       public Task<ParseUser> then(Task<JSONObject> task) throws Exception {
/* 53 */         return ParseAuthenticationProvider.this.logInAsync((JSONObject)task.getResult());
/*    */       } } );
/*    */   }
/*    */ 
/*    */   public Task<ParseUser> logInAsync(JSONObject authData) {
/* 59 */     return ParseUser.logInWithAsync(getAuthType(), authData);
/*    */   }
/*    */ 
/*    */   public Task<Void> linkAsync(ParseUser user) {
/* 63 */     return authenticateAsync().onSuccessTask(new Continuation(user)
/*    */     {
/*    */       public Task<Void> then(Task<JSONObject> task) throws Exception {
/* 66 */         return ParseAuthenticationProvider.this.linkAsync(this.val$user, (JSONObject)task.getResult());
/*    */       } } );
/*    */   }
/*    */ 
/*    */   public Task<Void> linkAsync(ParseUser user, JSONObject authData) {
/* 72 */     return user.linkWithAsync(getAuthType(), authData);
/*    */   }
/*    */ 
/*    */   public Task<Void> unlinkAsync(ParseUser user) {
/* 76 */     return user.unlinkFromAsync(getAuthType());
/*    */   }
/*    */ 
/*    */   static abstract interface ParseAuthenticationCallback
/*    */   {
/*    */     public abstract void onSuccess(JSONObject paramJSONObject);
/*    */ 
/*    */     public abstract void onCancel();
/*    */ 
/*    */     public abstract void onError(Throwable paramThrowable);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseAuthenticationProvider
 * JD-Core Version:    0.6.0
 */