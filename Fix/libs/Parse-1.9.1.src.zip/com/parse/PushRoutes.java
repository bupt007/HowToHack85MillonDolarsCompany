/*     */ package com.parse;
/*     */ 
/*     */ import android.app.Activity;
/*     */ import android.content.Context;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class PushRoutes
/*     */ {
/*     */   private static final String TAG = "com.parse.PushRoutes";
/*  22 */   private static final Pattern CHANNEL_PATTERN = Pattern.compile("^$|^[a-zA-Z][A-Za-z0-9_-]*$");
/*     */ 
/*  28 */   private final HashMap<String, Route> channels = new HashMap();
/*     */ 
/*     */   public static synchronized boolean isValidChannelName(String channel)
/*     */   {
/*  25 */     return CHANNEL_PATTERN.matcher(channel).matches();
/*     */   }
/*     */ 
/*     */   public PushRoutes(JSONObject json)
/*     */   {
/*  66 */     if (json != null) {
/*  67 */       JSONObject jsonRoutes = json.optJSONObject("routes");
/*     */ 
/*  69 */       if (jsonRoutes != null) {
/*  70 */         Iterator it = jsonRoutes.keys();
/*     */ 
/*  72 */         while (it.hasNext()) {
/*  73 */           String channel = (String)it.next();
/*  74 */           Route route = Route.newFromJSON(jsonRoutes.optJSONObject(channel));
/*     */ 
/*  76 */           if ((channel != null) && (route != null)) {
/*  77 */             put(channel, route);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  82 */       JSONObject defaultRoute = json.optJSONObject("defaultRoute");
/*  83 */       if (defaultRoute != null) {
/*  84 */         Route route = Route.newFromJSON(defaultRoute);
/*     */ 
/*  86 */         if (route != null)
/*  87 */           put(null, route);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public JSONObject toJSON()
/*     */     throws JSONException
/*     */   {
/*  97 */     JSONObject json = new JSONObject();
/*  98 */     JSONObject namedRoutes = new JSONObject();
/*     */ 
/* 100 */     for (Map.Entry channelRoute : this.channels.entrySet()) {
/* 101 */       String channel = (String)channelRoute.getKey();
/* 102 */       Route route = (Route)channelRoute.getValue();
/*     */ 
/* 104 */       if (channel == null)
/* 105 */         json.put("defaultRoute", route.toJSON());
/*     */       else {
/* 107 */         namedRoutes.put(channel, route.toJSON());
/*     */       }
/*     */     }
/*     */ 
/* 111 */     json.put("routes", namedRoutes);
/*     */ 
/* 113 */     return json;
/*     */   }
/*     */ 
/*     */   public Set<String> getChannels()
/*     */   {
/* 120 */     return Collections.unmodifiableSet(this.channels.keySet());
/*     */   }
/*     */ 
/*     */   public Route get(String channel)
/*     */   {
/* 127 */     return (Route)this.channels.get(channel);
/*     */   }
/*     */ 
/*     */   public Route put(String channel, Route route)
/*     */   {
/* 135 */     if (route == null) {
/* 136 */       throw new IllegalArgumentException("Can't insert null route");
/*     */     }
/*     */ 
/* 139 */     if ((channel != null) && (!isValidChannelName(channel))) {
/* 140 */       throw new IllegalArgumentException("invalid channel name: " + channel);
/*     */     }
/*     */ 
/* 143 */     return (Route)this.channels.put(channel, route);
/*     */   }
/*     */ 
/*     */   public Route remove(String channel) {
/* 147 */     return (Route)this.channels.remove(channel);
/*     */   }
/*     */ 
/*     */   public static final class Route
/*     */   {
/*     */     private final String activityClassName;
/*     */     private final int iconId;
/*     */ 
/*     */     public static Route newFromJSON(JSONObject json)
/*     */     {
/* 160 */       Route route = null;
/* 161 */       String activityClassName = null;
/* 162 */       int iconId = 0;
/*     */ 
/* 164 */       if (json != null) {
/* 165 */         JSONObject data = json.optJSONObject("data");
/*     */ 
/* 167 */         if (data != null) {
/* 168 */           activityClassName = data.optString("activityClass", null);
/* 169 */           iconId = data.optInt("icon", 0);
/*     */         }
/*     */       }
/*     */ 
/* 173 */       if ((activityClassName != null) && (iconId != 0)) {
/* 174 */         route = new Route(activityClassName, iconId);
/*     */       }
/*     */ 
/* 177 */       return route;
/*     */     }
/*     */ 
/*     */     public Route(String activityClassName, int iconId) {
/* 181 */       if (activityClassName == null)
/* 182 */         throw new IllegalArgumentException("activityClassName can't be null");
/* 183 */       if (iconId == 0) {
/* 184 */         throw new IllegalArgumentException("iconId can't be 0");
/*     */       }
/*     */ 
/* 187 */       this.activityClassName = activityClassName;
/* 188 */       this.iconId = iconId;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 193 */       boolean result = false;
/*     */ 
/* 195 */       if ((other != null) && ((other instanceof Route))) {
/* 196 */         Route that = (Route)other;
/* 197 */         result = (this.activityClassName.equals(that.activityClassName)) && (this.iconId == that.iconId);
/*     */       }
/*     */ 
/* 200 */       return result;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 205 */       return 31 * (31 + this.activityClassName.hashCode()) + this.iconId;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 210 */       return super.toString() + " (activityClassName: " + this.activityClassName + " iconId: " + this.iconId + ")";
/*     */     }
/*     */ 
/*     */     public JSONObject toJSON() throws JSONException {
/* 214 */       JSONObject json = new JSONObject();
/*     */ 
/* 218 */       JSONObject data = new JSONObject();
/*     */ 
/* 220 */       data.put("appName", ManifestInfo.getDisplayName());
/* 221 */       data.put("activityPackage", Parse.applicationContext.getPackageName());
/* 222 */       data.put("activityClass", this.activityClassName);
/* 223 */       data.put("icon", this.iconId);
/*     */ 
/* 225 */       json.put("data", data);
/* 226 */       json.put("name", "com.parse.StandardPushCallback");
/*     */ 
/* 228 */       return json;
/*     */     }
/*     */ 
/*     */     public Class<? extends Activity> getActivityClass() {
/* 232 */       Class clazz = null;
/*     */       try
/*     */       {
/* 235 */         clazz = Class.forName(this.activityClassName);
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/*     */       }
/* 239 */       if ((clazz != null) && (!Activity.class.isAssignableFrom(clazz))) {
/* 240 */         clazz = null;
/*     */       }
/*     */ 
/* 243 */       if (clazz == null) {
/* 244 */         Parse.logE("com.parse.PushRoutes", "Activity class " + this.activityClassName + " registered to handle push no " + "longer exists. Call PushService.subscribe with an activity class that does exist.");
/*     */       }
/*     */ 
/* 248 */       return clazz;
/*     */     }
/*     */ 
/*     */     public int getIconId() {
/* 252 */       return this.iconId;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.PushRoutes
 * JD-Core Version:    0.6.0
 */