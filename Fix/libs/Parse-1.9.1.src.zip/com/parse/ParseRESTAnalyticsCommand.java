/*    */ package com.parse;
/*    */ 
/*    */ import android.net.Uri;
/*    */ import java.util.Date;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseRESTAnalyticsCommand extends ParseRESTCommand
/*    */ {
/*    */   private static final String EVENT_APP_OPENED = "AppOpened";
/*    */ 
/*    */   public ParseRESTAnalyticsCommand(String httpPath, ParseRequest.Method httpMethod, Map<String, ?> parameters, String sessionToken)
/*    */   {
/* 21 */     super(httpPath, httpMethod, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTAnalyticsCommand trackAppOpenedCommand(String pushHash, String sessionToken)
/*    */   {
/* 26 */     Map parameters = new HashMap();
/* 27 */     if (pushHash != null) {
/* 28 */       parameters.put("push_hash", pushHash);
/*    */     }
/* 30 */     return trackEventCommand("AppOpened", parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTAnalyticsCommand trackEventCommand(String eventName, JSONObject dimensions, String sessionToken)
/*    */   {
/* 35 */     Map parameters = null;
/* 36 */     if (dimensions != null) {
/* 37 */       parameters = new HashMap();
/* 38 */       parameters.put("dimensions", dimensions);
/*    */     }
/* 40 */     return trackEventCommand(eventName, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   static ParseRESTAnalyticsCommand trackEventCommand(String eventName, Map<String, ?> parameters, String sessionToken)
/*    */   {
/* 45 */     String httpPath = String.format("events/%s", new Object[] { Uri.encode(eventName) });
/* 46 */     Map commandParameters = new HashMap();
/* 47 */     if (parameters != null) {
/* 48 */       commandParameters.putAll(parameters);
/*    */     }
/* 50 */     commandParameters.put("at", Parse.encodeDate(new Date()));
/* 51 */     return new ParseRESTAnalyticsCommand(httpPath, ParseRequest.Method.POST, commandParameters, sessionToken);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTAnalyticsCommand
 * JD-Core Version:    0.6.0
 */