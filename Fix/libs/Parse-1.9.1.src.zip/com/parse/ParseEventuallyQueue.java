/*     */ package com.parse;
/*     */ 
/*     */ import android.util.SparseArray;
/*     */ import bolts.Task;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ abstract class ParseEventuallyQueue
/*     */ {
/*     */   private boolean isConnected;
/*     */   private TestHelper testHelper;
/*     */ 
/*     */   public abstract void onDestroy();
/*     */ 
/*     */   public void setConnected(boolean connected)
/*     */   {
/*  28 */     this.isConnected = connected;
/*     */   }
/*     */ 
/*     */   public boolean isConnected() {
/*  32 */     return this.isConnected;
/*     */   }
/*     */ 
/*     */   public abstract int pendingCount();
/*     */ 
/*     */   public void setTimeoutRetryWaitSeconds(double seconds)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setMaxCacheSizeBytes(int bytes)
/*     */   {
/*     */   }
/*     */ 
/*     */   public TestHelper getTestHelper() {
/*  47 */     if (this.testHelper == null) {
/*  48 */       this.testHelper = new TestHelper(null);
/*     */     }
/*  50 */     return this.testHelper;
/*     */   }
/*     */ 
/*     */   protected void notifyTestHelper(int event) {
/*  54 */     notifyTestHelper(event, null);
/*     */   }
/*     */ 
/*     */   protected void notifyTestHelper(int event, Throwable t) {
/*  58 */     if (this.testHelper != null)
/*  59 */       this.testHelper.notify(event, t);
/*     */   }
/*     */ 
/*     */   public abstract void pause();
/*     */ 
/*     */   public abstract void resume();
/*     */ 
/*     */   public abstract Task<Object> enqueueEventuallyAsync(ParseNetworkCommand paramParseNetworkCommand, ParseObject paramParseObject);
/*     */ 
/*     */   protected ParseNetworkCommand<JSONObject, Object> commandFromJSON(JSONObject json)
/*     */     throws JSONException
/*     */   {
/*     */     ParseNetworkCommand command;
/*  85 */     if (ParseRESTCommand.isValidCommandJSONObject(json)) {
/*  86 */       command = ParseRESTCommand.fromJSONObject(json);
/*     */     }
/*     */     else
/*     */     {
/*     */       ParseNetworkCommand command;
/*  87 */       if (ParseCommand.isValidCommandJSONObject(json))
/*  88 */         command = new ParseCommand(json);
/*     */       else
/*  90 */         throw new JSONException("Failed to load command from JSON.");
/*     */     }
/*     */     ParseNetworkCommand command;
/*  92 */     return command;
/*     */   }
/*     */ 
/*     */   Task<Object> waitForOperationSetAndEventuallyPin(ParseOperationSet operationSet, EventuallyPin eventuallyPin)
/*     */   {
/*  97 */     return Task.forResult(null);
/*     */   }
/*     */ 
/*     */   abstract void simulateReboot();
/*     */ 
/*     */   public abstract void clear();
/*     */ 
/*     */   void fakeObjectUpdate()
/*     */   {
/* 113 */     if (this.testHelper != null) {
/* 114 */       this.testHelper.notify(3);
/* 115 */       this.testHelper.notify(1);
/* 116 */       this.testHelper.notify(5);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class TestHelper
/*     */   {
/*     */     private static final int MAX_EVENTS = 1000;
/*     */     public static final int COMMAND_SUCCESSFUL = 1;
/*     */     public static final int COMMAND_FAILED = 2;
/*     */     public static final int COMMAND_ENQUEUED = 3;
/*     */     public static final int COMMAND_NOT_ENQUEUED = 4;
/*     */     public static final int OBJECT_UPDATED = 5;
/*     */     public static final int OBJECT_REMOVED = 6;
/*     */     public static final int NETWORK_DOWN = 7;
/* 156 */     private SparseArray<Semaphore> events = new SparseArray();
/*     */ 
/*     */     public static String getEventString(int event)
/*     */     {
/* 136 */       switch (event) {
/*     */       case 1:
/* 138 */         return "COMMAND_SUCCESSFUL";
/*     */       case 2:
/* 140 */         return "COMMAND_FAILED";
/*     */       case 3:
/* 142 */         return "COMMAND_ENQUEUED";
/*     */       case 4:
/* 144 */         return "COMMAND_NOT_ENQUEUED";
/*     */       case 5:
/* 146 */         return "OBJECT_UPDATED";
/*     */       case 6:
/* 148 */         return "OBJECT_REMOVED";
/*     */       case 7:
/* 150 */         return "NETWORK_DOWN";
/*     */       }
/* 152 */       throw new IllegalStateException("Encountered unknown event: " + event);
/*     */     }
/*     */ 
/*     */     private TestHelper()
/*     */     {
/* 159 */       clear();
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 163 */       this.events.clear();
/* 164 */       this.events.put(1, new Semaphore(1000));
/* 165 */       this.events.put(2, new Semaphore(1000));
/* 166 */       this.events.put(3, new Semaphore(1000));
/* 167 */       this.events.put(4, new Semaphore(1000));
/* 168 */       this.events.put(5, new Semaphore(1000));
/* 169 */       this.events.put(6, new Semaphore(1000));
/* 170 */       this.events.put(7, new Semaphore(1000));
/* 171 */       for (int i = 0; i < this.events.size(); i++) {
/* 172 */         int event = this.events.keyAt(i);
/* 173 */         ((Semaphore)this.events.get(event)).acquireUninterruptibly(1000);
/*     */       }
/*     */     }
/*     */ 
/*     */     public int unexpectedEvents() {
/* 178 */       int sum = 0;
/* 179 */       for (int i = 0; i < this.events.size(); i++) {
/* 180 */         int event = this.events.keyAt(i);
/* 181 */         sum += ((Semaphore)this.events.get(event)).availablePermits();
/*     */       }
/* 183 */       return sum;
/*     */     }
/*     */ 
/*     */     public List<String> getUnexpectedEvents() {
/* 187 */       List unexpectedEvents = new ArrayList();
/* 188 */       for (int i = 0; i < this.events.size(); i++) {
/* 189 */         int event = this.events.keyAt(i);
/* 190 */         if (((Semaphore)this.events.get(event)).availablePermits() > 0) {
/* 191 */           unexpectedEvents.add(getEventString(event));
/*     */         }
/*     */       }
/* 194 */       return unexpectedEvents;
/*     */     }
/*     */ 
/*     */     public void notify(int event) {
/* 198 */       notify(event, null);
/*     */     }
/*     */ 
/*     */     public void notify(int event, Throwable t) {
/* 202 */       ((Semaphore)this.events.get(event)).release();
/*     */     }
/*     */ 
/*     */     public boolean waitFor(int event) {
/* 206 */       return waitFor(event, 1);
/*     */     }
/*     */ 
/*     */     public boolean waitFor(int event, int permits) {
/*     */       try {
/* 211 */         return ((Semaphore)this.events.get(event)).tryAcquire(permits, 120L, TimeUnit.SECONDS);
/*     */       } catch (InterruptedException e) {
/* 213 */         e.printStackTrace();
/* 214 */       }return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseEventuallyQueue
 * JD-Core Version:    0.6.0
 */