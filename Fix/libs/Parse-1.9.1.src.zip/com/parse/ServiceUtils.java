/*    */ package com.parse;
/*    */ 
/*    */ import android.app.Service;
/*    */ import android.content.ComponentName;
/*    */ import android.content.Context;
/*    */ import android.content.Intent;
/*    */ import android.util.SparseArray;
/*    */ 
/*    */ class ServiceUtils
/*    */ {
/*    */   private static final String TAG = "com.parse.ServiceUtils";
/*    */   private static final String WAKE_LOCK_EXTRA = "parseWakeLockId";
/* 14 */   private static final SparseArray<ParseWakeLock> wakeLocks = new SparseArray();
/* 15 */   private static int wakeLockId = 0;
/*    */ 
/*    */   public static boolean runIntentInService(Context context, Intent intent, Class<? extends Service> clazz)
/*    */   {
/* 21 */     boolean startedService = false;
/*    */ 
/* 23 */     if (intent != null) {
/* 24 */       if (clazz != null) {
/* 25 */         intent.setClass(context, clazz);
/*    */       }
/*    */ 
/* 28 */       ComponentName name = context.startService(intent);
/*    */ 
/* 30 */       startedService = name != null;
/* 31 */       if (!startedService) {
/* 32 */         Parse.logE("com.parse.ServiceUtils", "Could not start the service. Make sure that the XML tag <service android:name=\"" + clazz.toString() + "\" /> is in your " + "AndroidManifest.xml as a child of the <application> element.");
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 38 */     return startedService;
/*    */   }
/*    */ 
/*    */   public static boolean runWakefulIntentInService(Context context, Intent intent, Class<? extends Service> clazz, long wakeLockTimeout)
/*    */   {
/* 49 */     boolean startedService = false;
/*    */ 
/* 51 */     if (intent != null) {
/* 52 */       String reason = intent.toString();
/* 53 */       ParseWakeLock wl = ParseWakeLock.acquireNewWakeLock(context, 1, reason, 0L);
/*    */ 
/* 55 */       synchronized (wakeLocks) {
/* 56 */         intent.putExtra("parseWakeLockId", wakeLockId);
/* 57 */         wakeLocks.append(wakeLockId, wl);
/* 58 */         wakeLockId += 1;
/*    */       }
/*    */ 
/* 61 */       startedService = runIntentInService(context, intent, clazz);
/* 62 */       if (!startedService) {
/* 63 */         completeWakefulIntent(intent);
/*    */       }
/*    */     }
/*    */ 
/* 67 */     return startedService;
/*    */   }
/*    */ 
/*    */   public static void completeWakefulIntent(Intent intent)
/*    */   {
/* 74 */     if ((intent != null) && (intent.hasExtra("parseWakeLockId"))) {
/* 75 */       int id = intent.getIntExtra("parseWakeLockId", -1);
/* 76 */       ParseWakeLock wakeLock = null;
/*    */ 
/* 78 */       synchronized (wakeLocks) {
/* 79 */         wakeLock = (ParseWakeLock)wakeLocks.get(id);
/* 80 */         wakeLocks.remove(id);
/*    */       }
/*    */ 
/* 83 */       if (wakeLock == null) {
/* 84 */         Parse.logE("com.parse.ServiceUtils", "Got wake lock id of " + id + " in intent, but no such lock found in " + "global map. Was completeWakefulIntent called twice for the same intent?");
/*    */       }
/*    */       else
/* 87 */         wakeLock.release();
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ServiceUtils
 * JD-Core Version:    0.6.0
 */