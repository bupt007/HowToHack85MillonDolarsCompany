package com.parse;

abstract interface ParseCallback2<T1, T2 extends Throwable>
{
  public abstract void done(T1 paramT1, T2 paramT2);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseCallback2
 * JD-Core Version:    0.6.0
 */