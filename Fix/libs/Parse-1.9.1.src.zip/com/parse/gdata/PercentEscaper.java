/*     */ package com.parse.gdata;
/*     */ 
/*     */ public class PercentEscaper extends UnicodeEscaper
/*     */ {
/*     */   public static final String SAFECHARS_URLENCODER = "-_.*";
/*     */   public static final String SAFEPATHCHARS_URLENCODER = "-_.!~*'()@:$&,;=";
/*     */   public static final String SAFEQUERYSTRINGCHARS_URLENCODER = "-_.!~*'()@:$,;/?:";
/*  87 */   private static final char[] URI_ESCAPED_SPACE = { '+' };
/*     */ 
/*  89 */   private static final char[] UPPER_HEX_DIGITS = "0123456789ABCDEF".toCharArray();
/*     */   private final boolean plusForSpace;
/*     */   private final boolean[] safeOctets;
/*     */ 
/*     */   public PercentEscaper(String safeChars, boolean plusForSpace)
/*     */   {
/* 117 */     if (safeChars.matches(".*[0-9A-Za-z].*")) {
/* 118 */       throw new IllegalArgumentException("Alphanumeric characters are always 'safe' and should not be explicitly specified");
/*     */     }
/*     */ 
/* 124 */     if ((plusForSpace) && (safeChars.contains(" "))) {
/* 125 */       throw new IllegalArgumentException("plusForSpace cannot be specified when space is a 'safe' character");
/*     */     }
/*     */ 
/* 128 */     if (safeChars.contains("%")) {
/* 129 */       throw new IllegalArgumentException("The '%' character cannot be specified as 'safe'");
/*     */     }
/*     */ 
/* 132 */     this.plusForSpace = plusForSpace;
/* 133 */     this.safeOctets = createSafeOctets(safeChars);
/*     */   }
/*     */ 
/*     */   private static boolean[] createSafeOctets(String safeChars)
/*     */   {
/* 142 */     int maxChar = 122;
/* 143 */     char[] safeCharArray = safeChars.toCharArray();
/* 144 */     for (char c : safeCharArray) {
/* 145 */       maxChar = Math.max(c, maxChar);
/*     */     }
/* 147 */     boolean[] octets = new boolean[maxChar + 1];
/* 148 */     for (int c = 48; c <= 57; c++) {
/* 149 */       octets[c] = true;
/*     */     }
/* 151 */     for (int c = 65; c <= 90; c++) {
/* 152 */       octets[c] = true;
/*     */     }
/* 154 */     for (int c = 97; c <= 122; c++) {
/* 155 */       octets[c] = true;
/*     */     }
/* 157 */     for (char c : safeCharArray) {
/* 158 */       octets[c] = true;
/*     */     }
/* 160 */     return octets;
/*     */   }
/*     */ 
/*     */   protected int nextEscapeIndex(CharSequence csq, int index, int end)
/*     */   {
/* 170 */     for (; index < end; index++) {
/* 171 */       char c = csq.charAt(index);
/* 172 */       if ((c >= this.safeOctets.length) || (this.safeOctets[c] == 0)) {
/*     */         break;
/*     */       }
/*     */     }
/* 176 */     return index;
/*     */   }
/*     */ 
/*     */   public String escape(String s)
/*     */   {
/* 186 */     int slen = s.length();
/* 187 */     for (int index = 0; index < slen; index++) {
/* 188 */       char c = s.charAt(index);
/* 189 */       if ((c >= this.safeOctets.length) || (this.safeOctets[c] == 0)) {
/* 190 */         return escapeSlow(s, index);
/*     */       }
/*     */     }
/* 193 */     return s;
/*     */   }
/*     */ 
/*     */   protected char[] escape(int cp)
/*     */   {
/* 203 */     if ((cp < this.safeOctets.length) && (this.safeOctets[cp] != 0))
/* 204 */       return null;
/* 205 */     if ((cp == 32) && (this.plusForSpace))
/* 206 */       return URI_ESCAPED_SPACE;
/* 207 */     if (cp <= 127)
/*     */     {
/* 210 */       char[] dest = new char[3];
/* 211 */       dest[0] = '%';
/* 212 */       dest[2] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 213 */       dest[1] = UPPER_HEX_DIGITS[(cp >>> 4)];
/* 214 */       return dest;
/* 215 */     }if (cp <= 2047)
/*     */     {
/* 218 */       char[] dest = new char[6];
/* 219 */       dest[0] = '%';
/* 220 */       dest[3] = '%';
/* 221 */       dest[5] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 222 */       cp >>>= 4;
/* 223 */       dest[4] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 224 */       cp >>>= 2;
/* 225 */       dest[2] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 226 */       cp >>>= 4;
/* 227 */       dest[1] = UPPER_HEX_DIGITS[(0xC | cp)];
/* 228 */       return dest;
/* 229 */     }if (cp <= 65535)
/*     */     {
/* 232 */       char[] dest = new char[9];
/* 233 */       dest[0] = '%';
/* 234 */       dest[1] = 'E';
/* 235 */       dest[3] = '%';
/* 236 */       dest[6] = '%';
/* 237 */       dest[8] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 238 */       cp >>>= 4;
/* 239 */       dest[7] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 240 */       cp >>>= 2;
/* 241 */       dest[5] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 242 */       cp >>>= 4;
/* 243 */       dest[4] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 244 */       cp >>>= 2;
/* 245 */       dest[2] = UPPER_HEX_DIGITS[cp];
/* 246 */       return dest;
/* 247 */     }if (cp <= 1114111) {
/* 248 */       char[] dest = new char[12];
/*     */ 
/* 251 */       dest[0] = '%';
/* 252 */       dest[1] = 'F';
/* 253 */       dest[3] = '%';
/* 254 */       dest[6] = '%';
/* 255 */       dest[9] = '%';
/* 256 */       dest[11] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 257 */       cp >>>= 4;
/* 258 */       dest[10] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 259 */       cp >>>= 2;
/* 260 */       dest[8] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 261 */       cp >>>= 4;
/* 262 */       dest[7] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 263 */       cp >>>= 2;
/* 264 */       dest[5] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 265 */       cp >>>= 4;
/* 266 */       dest[4] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 267 */       cp >>>= 2;
/* 268 */       dest[2] = UPPER_HEX_DIGITS[(cp & 0x7)];
/* 269 */       return dest;
/*     */     }
/*     */ 
/* 272 */     throw new IllegalArgumentException("Invalid unicode character value " + cp);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.gdata.PercentEscaper
 * JD-Core Version:    0.6.0
 */