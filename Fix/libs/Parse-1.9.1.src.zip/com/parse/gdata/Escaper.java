package com.parse.gdata;

public abstract interface Escaper
{
  public abstract String escape(String paramString);

  public abstract Appendable escape(Appendable paramAppendable);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.gdata.Escaper
 * JD-Core Version:    0.6.0
 */