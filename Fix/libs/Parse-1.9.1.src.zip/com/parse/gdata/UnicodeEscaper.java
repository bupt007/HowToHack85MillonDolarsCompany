/*     */ package com.parse.gdata;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ public abstract class UnicodeEscaper
/*     */   implements Escaper
/*     */ {
/*     */   private static final int DEST_PAD = 32;
/* 455 */   private static final ThreadLocal<char[]> DEST_TL = new ThreadLocal()
/*     */   {
/*     */     protected char[] initialValue() {
/* 458 */       return new char[1024];
/*     */     }
/* 455 */   };
/*     */ 
/*     */   protected abstract char[] escape(int paramInt);
/*     */ 
/*     */   protected int nextEscapeIndex(CharSequence csq, int start, int end)
/*     */   {
/* 109 */     int index = start;
/* 110 */     while (index < end) {
/* 111 */       int cp = codePointAt(csq, index, end);
/* 112 */       if ((cp < 0) || (escape(cp) != null)) {
/*     */         break;
/*     */       }
/* 115 */       index += (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
/*     */     }
/* 117 */     return index;
/*     */   }
/*     */ 
/*     */   public String escape(String string)
/*     */   {
/* 144 */     int end = string.length();
/* 145 */     int index = nextEscapeIndex(string, 0, end);
/* 146 */     return index == end ? string : escapeSlow(string, index);
/*     */   }
/*     */ 
/*     */   protected final String escapeSlow(String s, int index)
/*     */   {
/* 167 */     int end = s.length();
/*     */ 
/* 170 */     char[] dest = (char[])DEST_TL.get();
/* 171 */     int destIndex = 0;
/* 172 */     int unescapedChunkStart = 0;
/*     */ 
/* 174 */     while (index < end) {
/* 175 */       int cp = codePointAt(s, index, end);
/* 176 */       if (cp < 0) {
/* 177 */         throw new IllegalArgumentException("Trailing high surrogate at end of input");
/*     */       }
/*     */ 
/* 180 */       char[] escaped = escape(cp);
/* 181 */       if (escaped != null) {
/* 182 */         int charsSkipped = index - unescapedChunkStart;
/*     */ 
/* 186 */         int sizeNeeded = destIndex + charsSkipped + escaped.length;
/* 187 */         if (dest.length < sizeNeeded) {
/* 188 */           int destLength = sizeNeeded + (end - index) + 32;
/* 189 */           dest = growBuffer(dest, destIndex, destLength);
/*     */         }
/*     */ 
/* 192 */         if (charsSkipped > 0) {
/* 193 */           s.getChars(unescapedChunkStart, index, dest, destIndex);
/* 194 */           destIndex += charsSkipped;
/*     */         }
/* 196 */         if (escaped.length > 0) {
/* 197 */           System.arraycopy(escaped, 0, dest, destIndex, escaped.length);
/* 198 */           destIndex += escaped.length;
/*     */         }
/*     */       }
/* 201 */       unescapedChunkStart = index + (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
/*     */ 
/* 203 */       index = nextEscapeIndex(s, unescapedChunkStart, end);
/*     */     }
/*     */ 
/* 208 */     int charsSkipped = end - unescapedChunkStart;
/* 209 */     if (charsSkipped > 0) {
/* 210 */       int endIndex = destIndex + charsSkipped;
/* 211 */       if (dest.length < endIndex) {
/* 212 */         dest = growBuffer(dest, destIndex, endIndex);
/*     */       }
/* 214 */       s.getChars(unescapedChunkStart, end, dest, destIndex);
/* 215 */       destIndex = endIndex;
/*     */     }
/* 217 */     return new String(dest, 0, destIndex);
/*     */   }
/*     */ 
/*     */   public Appendable escape(Appendable out)
/*     */   {
/* 255 */     Preconditions.checkNotNull(out);
/*     */ 
/* 257 */     return new Appendable(out) {
/* 258 */       int pendingHighSurrogate = -1;
/* 259 */       char[] decodedChars = new char[2];
/*     */ 
/*     */       public Appendable append(CharSequence csq) throws IOException {
/* 262 */         return append(csq, 0, csq.length());
/*     */       }
/*     */ 
/*     */       public Appendable append(CharSequence csq, int start, int end) throws IOException
/*     */       {
/* 267 */         int index = start;
/* 268 */         if (index < end)
/*     */         {
/* 272 */           int unescapedChunkStart = index;
/* 273 */           if (this.pendingHighSurrogate != -1)
/*     */           {
/* 276 */             char c = csq.charAt(index++);
/* 277 */             if (!Character.isLowSurrogate(c)) {
/* 278 */               throw new IllegalArgumentException("Expected low surrogate character but got " + c);
/*     */             }
/*     */ 
/* 281 */             char[] escaped = UnicodeEscaper.this.escape(Character.toCodePoint((char)this.pendingHighSurrogate, c));
/*     */ 
/* 283 */             if (escaped != null)
/*     */             {
/* 286 */               outputChars(escaped, escaped.length);
/* 287 */               unescapedChunkStart++;
/*     */             }
/*     */             else
/*     */             {
/* 291 */               this.val$out.append((char)this.pendingHighSurrogate);
/*     */             }
/* 293 */             this.pendingHighSurrogate = -1;
/*     */           }
/*     */           while (true)
/*     */           {
/* 297 */             index = UnicodeEscaper.this.nextEscapeIndex(csq, index, end);
/* 298 */             if (index > unescapedChunkStart) {
/* 299 */               this.val$out.append(csq, unescapedChunkStart, index);
/*     */             }
/* 301 */             if (index == end)
/*     */             {
/*     */               break;
/*     */             }
/* 305 */             int cp = UnicodeEscaper.codePointAt(csq, index, end);
/* 306 */             if (cp < 0)
/*     */             {
/* 309 */               this.pendingHighSurrogate = (-cp);
/* 310 */               break;
/*     */             }
/*     */ 
/* 313 */             char[] escaped = UnicodeEscaper.this.escape(cp);
/* 314 */             if (escaped != null) {
/* 315 */               outputChars(escaped, escaped.length);
/*     */             }
/*     */             else
/*     */             {
/* 319 */               int len = Character.toChars(cp, this.decodedChars, 0);
/* 320 */               outputChars(this.decodedChars, len);
/*     */             }
/*     */ 
/* 323 */             index += (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
/* 324 */             unescapedChunkStart = index;
/*     */           }
/*     */         }
/* 327 */         return this;
/*     */       }
/*     */ 
/*     */       public Appendable append(char c) throws IOException {
/* 331 */         if (this.pendingHighSurrogate != -1)
/*     */         {
/* 334 */           if (!Character.isLowSurrogate(c)) {
/* 335 */             throw new IllegalArgumentException("Expected low surrogate character but got '" + c + "' with value " + c);
/*     */           }
/*     */ 
/* 339 */           char[] escaped = UnicodeEscaper.this.escape(Character.toCodePoint((char)this.pendingHighSurrogate, c));
/*     */ 
/* 341 */           if (escaped != null) {
/* 342 */             outputChars(escaped, escaped.length);
/*     */           } else {
/* 344 */             this.val$out.append((char)this.pendingHighSurrogate);
/* 345 */             this.val$out.append(c);
/*     */           }
/* 347 */           this.pendingHighSurrogate = -1;
/* 348 */         } else if (Character.isHighSurrogate(c))
/*     */         {
/* 350 */           this.pendingHighSurrogate = c;
/*     */         } else {
/* 352 */           if (Character.isLowSurrogate(c)) {
/* 353 */             throw new IllegalArgumentException("Unexpected low surrogate character '" + c + "' with value " + c);
/*     */           }
/*     */ 
/* 358 */           char[] escaped = UnicodeEscaper.this.escape(c);
/* 359 */           if (escaped != null)
/* 360 */             outputChars(escaped, escaped.length);
/*     */           else {
/* 362 */             this.val$out.append(c);
/*     */           }
/*     */         }
/* 365 */         return this;
/*     */       }
/*     */ 
/*     */       private void outputChars(char[] chars, int len) throws IOException {
/* 369 */         for (int n = 0; n < len; n++)
/* 370 */           this.val$out.append(chars[n]);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   protected static final int codePointAt(CharSequence seq, int index, int end)
/*     */   {
/* 409 */     if (index < end) {
/* 410 */       char c1 = seq.charAt(index++);
/* 411 */       if ((c1 < 55296) || (c1 > 57343))
/*     */       {
/* 414 */         return c1;
/* 415 */       }if (c1 <= 56319)
/*     */       {
/* 417 */         if (index == end) {
/* 418 */           return -c1;
/*     */         }
/*     */ 
/* 421 */         char c2 = seq.charAt(index);
/* 422 */         if (Character.isLowSurrogate(c2)) {
/* 423 */           return Character.toCodePoint(c1, c2);
/*     */         }
/* 425 */         throw new IllegalArgumentException("Expected low surrogate but got char '" + c2 + "' with value " + c2 + " at index " + index);
/*     */       }
/*     */ 
/* 429 */       throw new IllegalArgumentException("Unexpected low surrogate character '" + c1 + "' with value " + c1 + " at index " + (index - 1));
/*     */     }
/*     */ 
/* 434 */     throw new IndexOutOfBoundsException("Index exceeds specified range");
/*     */   }
/*     */ 
/*     */   private static final char[] growBuffer(char[] dest, int index, int size)
/*     */   {
/* 443 */     char[] copy = new char[size];
/* 444 */     if (index > 0) {
/* 445 */       System.arraycopy(dest, 0, copy, 0, index);
/*     */     }
/* 447 */     return copy;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.gdata.UnicodeEscaper
 * JD-Core Version:    0.6.0
 */