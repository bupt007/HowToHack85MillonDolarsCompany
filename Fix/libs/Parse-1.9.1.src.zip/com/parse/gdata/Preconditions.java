/*     */ package com.parse.gdata;
/*     */ 
/*     */ public final class Preconditions
/*     */ {
/*     */   public static void checkArgument(boolean expression)
/*     */   {
/*  71 */     if (!expression)
/*  72 */       throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   public static void checkArgument(boolean expression, Object errorMessage)
/*     */   {
/*  86 */     if (!expression)
/*  87 */       throw new IllegalArgumentException(String.valueOf(errorMessage));
/*     */   }
/*     */ 
/*     */   public static void checkArgument(boolean expression, String errorMessageTemplate, Object[] errorMessageArgs)
/*     */   {
/* 112 */     if (!expression)
/* 113 */       throw new IllegalArgumentException(format(errorMessageTemplate, errorMessageArgs));
/*     */   }
/*     */ 
/*     */   public static void checkState(boolean expression)
/*     */   {
/* 126 */     if (!expression)
/* 127 */       throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   public static void checkState(boolean expression, Object errorMessage)
/*     */   {
/* 141 */     if (!expression)
/* 142 */       throw new IllegalStateException(String.valueOf(errorMessage));
/*     */   }
/*     */ 
/*     */   public static void checkState(boolean expression, String errorMessageTemplate, Object[] errorMessageArgs)
/*     */   {
/* 167 */     if (!expression)
/* 168 */       throw new IllegalStateException(format(errorMessageTemplate, errorMessageArgs));
/*     */   }
/*     */ 
/*     */   public static <T> T checkNotNull(T reference)
/*     */   {
/* 182 */     if (reference == null) {
/* 183 */       throw new NullPointerException();
/*     */     }
/* 185 */     return reference;
/*     */   }
/*     */ 
/*     */   public static <T> T checkNotNull(T reference, Object errorMessage)
/*     */   {
/* 199 */     if (reference == null) {
/* 200 */       throw new NullPointerException(String.valueOf(errorMessage));
/*     */     }
/* 202 */     return reference;
/*     */   }
/*     */ 
/*     */   public static <T> T checkNotNull(T reference, String errorMessageTemplate, Object[] errorMessageArgs)
/*     */   {
/* 224 */     if (reference == null)
/*     */     {
/* 226 */       throw new NullPointerException(format(errorMessageTemplate, errorMessageArgs));
/*     */     }
/*     */ 
/* 229 */     return reference;
/*     */   }
/*     */ 
/*     */   public static void checkElementIndex(int index, int size)
/*     */   {
/* 245 */     checkElementIndex(index, size, "index");
/*     */   }
/*     */ 
/*     */   public static void checkElementIndex(int index, int size, String desc)
/*     */   {
/* 262 */     checkArgument(size >= 0, "negative size: %s", new Object[] { Integer.valueOf(size) });
/* 263 */     if (index < 0) {
/* 264 */       throw new IndexOutOfBoundsException(format("%s (%s) must not be negative", new Object[] { desc, Integer.valueOf(index) }));
/*     */     }
/*     */ 
/* 267 */     if (index >= size)
/* 268 */       throw new IndexOutOfBoundsException(format("%s (%s) must be less than size (%s)", new Object[] { desc, Integer.valueOf(index), Integer.valueOf(size) }));
/*     */   }
/*     */ 
/*     */   public static void checkPositionIndex(int index, int size)
/*     */   {
/* 286 */     checkPositionIndex(index, size, "index");
/*     */   }
/*     */ 
/*     */   public static void checkPositionIndex(int index, int size, String desc)
/*     */   {
/* 303 */     checkArgument(size >= 0, "negative size: %s", new Object[] { Integer.valueOf(size) });
/* 304 */     if (index < 0) {
/* 305 */       throw new IndexOutOfBoundsException(format("%s (%s) must not be negative", new Object[] { desc, Integer.valueOf(index) }));
/*     */     }
/*     */ 
/* 308 */     if (index > size)
/* 309 */       throw new IndexOutOfBoundsException(format("%s (%s) must not be greater than size (%s)", new Object[] { desc, Integer.valueOf(index), Integer.valueOf(size) }));
/*     */   }
/*     */ 
/*     */   public static void checkPositionIndexes(int start, int end, int size)
/*     */   {
/* 329 */     checkPositionIndex(start, size, "start index");
/* 330 */     checkPositionIndex(end, size, "end index");
/* 331 */     if (end < start)
/* 332 */       throw new IndexOutOfBoundsException(format("end index (%s) must not be less than start index (%s)", new Object[] { Integer.valueOf(end), Integer.valueOf(start) }));
/*     */   }
/*     */ 
/*     */   static String format(String template, Object[] args)
/*     */   {
/* 352 */     StringBuilder builder = new StringBuilder(template.length() + 16 * args.length);
/*     */ 
/* 354 */     int templateStart = 0;
/* 355 */     int i = 0;
/* 356 */     while (i < args.length) {
/* 357 */       int placeholderStart = template.indexOf("%s", templateStart);
/* 358 */       if (placeholderStart == -1) {
/*     */         break;
/*     */       }
/* 361 */       builder.append(template.substring(templateStart, placeholderStart));
/* 362 */       builder.append(args[(i++)]);
/* 363 */       templateStart = placeholderStart + 2;
/*     */     }
/* 365 */     builder.append(template.substring(templateStart));
/*     */ 
/* 368 */     if (i < args.length) {
/* 369 */       builder.append(" [");
/* 370 */       builder.append(args[(i++)]);
/* 371 */       while (i < args.length) {
/* 372 */         builder.append(", ");
/* 373 */         builder.append(args[(i++)]);
/*     */       }
/* 375 */       builder.append("]");
/*     */     }
/*     */ 
/* 378 */     return builder.toString();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.gdata.Preconditions
 * JD-Core Version:    0.6.0
 */