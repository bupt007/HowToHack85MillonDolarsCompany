/*     */ package com.parse;
/*     */ 
/*     */ import android.annotation.TargetApi;
/*     */ import android.content.ContentResolver;
/*     */ import android.database.CharArrayBuffer;
/*     */ import android.database.ContentObserver;
/*     */ import android.database.Cursor;
/*     */ import android.database.DataSetObserver;
/*     */ import android.net.Uri;
/*     */ import android.os.Build.VERSION;
/*     */ import android.os.Bundle;
/*     */ import bolts.Task;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executor;
/*     */ 
/*     */ class ParseSQLiteCursor
/*     */   implements Cursor
/*     */ {
/*     */   private Cursor cursor;
/*     */   private Executor executor;
/*     */ 
/*     */   public static Cursor create(Cursor cursor, Executor executor)
/*     */   {
/*  28 */     if (Build.VERSION.SDK_INT >= 14) {
/*  29 */       return cursor;
/*     */     }
/*  31 */     return new ParseSQLiteCursor(cursor, executor);
/*     */   }
/*     */ 
/*     */   private ParseSQLiteCursor(Cursor cursor, Executor executor)
/*     */   {
/*  38 */     this.cursor = cursor;
/*  39 */     this.executor = executor;
/*     */   }
/*     */ 
/*     */   public int getCount()
/*     */   {
/*  44 */     return this.cursor.getCount();
/*     */   }
/*     */ 
/*     */   public int getPosition()
/*     */   {
/*  49 */     return this.cursor.getPosition();
/*     */   }
/*     */ 
/*     */   public boolean move(int offset)
/*     */   {
/*  54 */     return this.cursor.move(offset);
/*     */   }
/*     */ 
/*     */   public boolean moveToPosition(int position)
/*     */   {
/*  59 */     return this.cursor.moveToPosition(position);
/*     */   }
/*     */ 
/*     */   public boolean moveToFirst()
/*     */   {
/*  64 */     return this.cursor.moveToFirst();
/*     */   }
/*     */ 
/*     */   public boolean moveToLast()
/*     */   {
/*  69 */     return this.cursor.moveToLast();
/*     */   }
/*     */ 
/*     */   public boolean moveToNext()
/*     */   {
/*  74 */     return this.cursor.moveToNext();
/*     */   }
/*     */ 
/*     */   public boolean moveToPrevious()
/*     */   {
/*  79 */     return this.cursor.moveToPrevious();
/*     */   }
/*     */ 
/*     */   public boolean isFirst()
/*     */   {
/*  84 */     return this.cursor.isFirst();
/*     */   }
/*     */ 
/*     */   public boolean isLast()
/*     */   {
/*  89 */     return this.cursor.isLast();
/*     */   }
/*     */ 
/*     */   public boolean isBeforeFirst()
/*     */   {
/*  94 */     return this.cursor.isBeforeFirst();
/*     */   }
/*     */ 
/*     */   public boolean isAfterLast()
/*     */   {
/*  99 */     return this.cursor.isAfterLast();
/*     */   }
/*     */ 
/*     */   public int getColumnIndex(String columnName)
/*     */   {
/* 104 */     return this.cursor.getColumnIndex(columnName);
/*     */   }
/*     */ 
/*     */   public int getColumnIndexOrThrow(String columnName) throws IllegalArgumentException
/*     */   {
/* 109 */     return this.cursor.getColumnIndexOrThrow(columnName);
/*     */   }
/*     */ 
/*     */   public String getColumnName(int columnIndex)
/*     */   {
/* 114 */     return this.cursor.getColumnName(columnIndex);
/*     */   }
/*     */ 
/*     */   public String[] getColumnNames()
/*     */   {
/* 119 */     return this.cursor.getColumnNames();
/*     */   }
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 124 */     return this.cursor.getColumnCount();
/*     */   }
/*     */ 
/*     */   public byte[] getBlob(int columnIndex)
/*     */   {
/* 129 */     return this.cursor.getBlob(columnIndex);
/*     */   }
/*     */ 
/*     */   public String getString(int columnIndex)
/*     */   {
/* 134 */     return this.cursor.getString(columnIndex);
/*     */   }
/*     */ 
/*     */   public void copyStringToBuffer(int columnIndex, CharArrayBuffer buffer)
/*     */   {
/* 139 */     this.cursor.copyStringToBuffer(columnIndex, buffer);
/*     */   }
/*     */ 
/*     */   public short getShort(int columnIndex)
/*     */   {
/* 144 */     return this.cursor.getShort(columnIndex);
/*     */   }
/*     */ 
/*     */   public int getInt(int columnIndex)
/*     */   {
/* 149 */     return this.cursor.getInt(columnIndex);
/*     */   }
/*     */ 
/*     */   public long getLong(int columnIndex)
/*     */   {
/* 154 */     return this.cursor.getLong(columnIndex);
/*     */   }
/*     */ 
/*     */   public float getFloat(int columnIndex)
/*     */   {
/* 159 */     return this.cursor.getFloat(columnIndex);
/*     */   }
/*     */ 
/*     */   public double getDouble(int columnIndex)
/*     */   {
/* 164 */     return this.cursor.getDouble(columnIndex);
/*     */   }
/*     */ 
/*     */   @TargetApi(11)
/*     */   public int getType(int columnIndex) {
/* 170 */     return this.cursor.getType(columnIndex);
/*     */   }
/*     */ 
/*     */   public boolean isNull(int columnIndex)
/*     */   {
/* 175 */     return this.cursor.isNull(columnIndex);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void deactivate() {
/* 181 */     this.cursor.deactivate();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean requery() {
/* 187 */     return this.cursor.requery();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 193 */     Task.call(new Callable()
/*     */     {
/*     */       public Void call() throws Exception {
/* 196 */         ParseSQLiteCursor.this.cursor.close();
/* 197 */         return null;
/*     */       }
/*     */     }
/*     */     , this.executor);
/*     */   }
/*     */ 
/*     */   public boolean isClosed()
/*     */   {
/* 204 */     return this.cursor.isClosed();
/*     */   }
/*     */ 
/*     */   public void registerContentObserver(ContentObserver observer)
/*     */   {
/* 209 */     this.cursor.registerContentObserver(observer);
/*     */   }
/*     */ 
/*     */   public void unregisterContentObserver(ContentObserver observer)
/*     */   {
/* 214 */     this.cursor.unregisterContentObserver(observer);
/*     */   }
/*     */ 
/*     */   public void registerDataSetObserver(DataSetObserver observer)
/*     */   {
/* 219 */     this.cursor.registerDataSetObserver(observer);
/*     */   }
/*     */ 
/*     */   public void unregisterDataSetObserver(DataSetObserver observer)
/*     */   {
/* 224 */     this.cursor.unregisterDataSetObserver(observer);
/*     */   }
/*     */ 
/*     */   public void setNotificationUri(ContentResolver cr, Uri uri)
/*     */   {
/* 229 */     this.cursor.setNotificationUri(cr, uri);
/*     */   }
/*     */ 
/*     */   @TargetApi(19)
/*     */   public Uri getNotificationUri() {
/* 235 */     return this.cursor.getNotificationUri();
/*     */   }
/*     */ 
/*     */   public boolean getWantsAllOnMoveCalls()
/*     */   {
/* 240 */     return this.cursor.getWantsAllOnMoveCalls();
/*     */   }
/*     */ 
/*     */   public Bundle getExtras()
/*     */   {
/* 245 */     return this.cursor.getExtras();
/*     */   }
/*     */ 
/*     */   public Bundle respond(Bundle extras)
/*     */   {
/* 250 */     return this.cursor.respond(extras);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseSQLiteCursor
 * JD-Core Version:    0.6.0
 */