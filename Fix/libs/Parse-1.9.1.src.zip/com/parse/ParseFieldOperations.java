/*     */ package com.parse;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ final class ParseFieldOperations
/*     */ {
/*  77 */   private static Map<String, ParseFieldOperationFactory> opDecoderMap = new HashMap();
/*     */ 
/*     */   private static void registerDecoder(String opName, ParseFieldOperationFactory factory)
/*     */   {
/*  84 */     opDecoderMap.put(opName, factory);
/*     */   }
/*     */ 
/*     */   static void registerDefaultDecoders()
/*     */   {
/*  92 */     registerDecoder("Batch", new ParseFieldOperationFactory()
/*     */     {
/*     */       public ParseFieldOperation decode(JSONObject object, ParseDecoder decoder) throws JSONException
/*     */       {
/*  96 */         ParseFieldOperation op = null;
/*  97 */         JSONArray ops = object.getJSONArray("ops");
/*  98 */         for (int i = 0; i < ops.length(); i++) {
/*  99 */           ParseFieldOperation nextOp = ParseFieldOperations.decode(ops.getJSONObject(i), decoder);
/* 100 */           op = nextOp.mergeWithPrevious(op);
/*     */         }
/* 102 */         return op;
/*     */       }
/*     */     });
/* 106 */     registerDecoder("Delete", new ParseFieldOperationFactory()
/*     */     {
/*     */       public ParseFieldOperation decode(JSONObject object, ParseDecoder decoder) throws JSONException
/*     */       {
/* 110 */         return ParseDeleteOperation.getInstance();
/*     */       }
/*     */     });
/* 114 */     registerDecoder("Increment", new ParseFieldOperationFactory()
/*     */     {
/*     */       public ParseFieldOperation decode(JSONObject object, ParseDecoder decoder) throws JSONException
/*     */       {
/* 118 */         return new ParseIncrementOperation((Number)decoder.decode(object.opt("amount")));
/*     */       }
/*     */     });
/* 122 */     registerDecoder("Add", new ParseFieldOperationFactory()
/*     */     {
/*     */       public ParseFieldOperation decode(JSONObject object, ParseDecoder decoder) throws JSONException
/*     */       {
/* 126 */         return new ParseAddOperation((Collection)decoder.decode(object.opt("objects")));
/*     */       }
/*     */     });
/* 130 */     registerDecoder("AddUnique", new ParseFieldOperationFactory()
/*     */     {
/*     */       public ParseFieldOperation decode(JSONObject object, ParseDecoder decoder) throws JSONException
/*     */       {
/* 134 */         return new ParseAddUniqueOperation((Collection)decoder.decode(object.opt("objects")));
/*     */       }
/*     */     });
/* 138 */     registerDecoder("Remove", new ParseFieldOperationFactory()
/*     */     {
/*     */       public ParseFieldOperation decode(JSONObject object, ParseDecoder decoder) throws JSONException
/*     */       {
/* 142 */         return new ParseRemoveOperation((Collection)decoder.decode(object.opt("objects")));
/*     */       }
/*     */     });
/* 146 */     registerDecoder("AddRelation", new ParseFieldOperationFactory()
/*     */     {
/*     */       public ParseFieldOperation decode(JSONObject object, ParseDecoder decoder) throws JSONException
/*     */       {
/* 150 */         JSONArray objectsArray = object.optJSONArray("objects");
/* 151 */         List objectsList = (List)decoder.decode(objectsArray);
/* 152 */         return new ParseRelationOperation(new HashSet(objectsList), null);
/*     */       }
/*     */     });
/* 156 */     registerDecoder("RemoveRelation", new ParseFieldOperationFactory()
/*     */     {
/*     */       public ParseFieldOperation decode(JSONObject object, ParseDecoder decoder) throws JSONException
/*     */       {
/* 160 */         JSONArray objectsArray = object.optJSONArray("objects");
/* 161 */         List objectsList = (List)decoder.decode(objectsArray);
/* 162 */         return new ParseRelationOperation(null, new HashSet(objectsList));
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   static ParseFieldOperation decode(JSONObject encoded, ParseDecoder decoder)
/*     */     throws JSONException
/*     */   {
/* 175 */     String op = encoded.optString("__op");
/* 176 */     ParseFieldOperationFactory factory = (ParseFieldOperationFactory)opDecoderMap.get(op);
/* 177 */     if (factory == null) {
/* 178 */       throw new RuntimeException("Unable to decode operation of type " + op);
/*     */     }
/* 180 */     return factory.decode(encoded, decoder);
/*     */   }
/*     */ 
/*     */   static ArrayList<Object> jsonArrayAsArrayList(JSONArray array)
/*     */   {
/* 187 */     ArrayList result = new ArrayList(array.length());
/* 188 */     for (int i = 0; i < array.length(); i++) {
/*     */       try {
/* 190 */         result.add(array.get(i));
/*     */       }
/*     */       catch (JSONException e) {
/* 193 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/* 196 */     return result;
/*     */   }
/*     */ 
/*     */   private static abstract interface ParseFieldOperationFactory
/*     */   {
/*     */     public abstract ParseFieldOperation decode(JSONObject paramJSONObject, ParseDecoder paramParseDecoder)
/*     */       throws JSONException;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseFieldOperations
 * JD-Core Version:    0.6.0
 */