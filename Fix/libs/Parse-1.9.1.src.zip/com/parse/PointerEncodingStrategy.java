/*    */ package com.parse;
/*    */ 
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class PointerEncodingStrategy extends PointerOrLocalIdEncodingStrategy
/*    */ {
/* 11 */   private static final PointerEncodingStrategy instance = new PointerEncodingStrategy();
/*    */ 
/*    */   public static PointerEncodingStrategy get() {
/* 14 */     return instance;
/*    */   }
/*    */ 
/*    */   public JSONObject encodeRelatedObject(ParseObject object)
/*    */   {
/* 20 */     if (object.getObjectId() == null)
/*    */     {
/* 22 */       throw new IllegalStateException("unable to encode an association with an unsaved ParseObject");
/*    */     }
/* 24 */     return super.encodeRelatedObject(object);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.PointerEncodingStrategy
 * JD-Core Version:    0.6.0
 */