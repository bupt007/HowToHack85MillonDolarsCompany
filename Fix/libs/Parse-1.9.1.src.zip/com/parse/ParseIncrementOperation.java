/*    */ package com.parse;
/*    */ 
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseIncrementOperation
/*    */   implements ParseFieldOperation
/*    */ {
/*    */   private Number amount;
/*    */ 
/*    */   public ParseIncrementOperation(Number amount)
/*    */   {
/* 13 */     this.amount = amount;
/*    */   }
/*    */ 
/*    */   public JSONObject encode(ParseObjectEncodingStrategy objectEncoder) throws JSONException
/*    */   {
/* 18 */     JSONObject output = new JSONObject();
/* 19 */     output.put("__op", "Increment");
/* 20 */     output.put("amount", this.amount);
/* 21 */     return output;
/*    */   }
/*    */ 
/*    */   public ParseFieldOperation mergeWithPrevious(ParseFieldOperation previous)
/*    */   {
/* 26 */     if (previous == null)
/* 27 */       return this;
/* 28 */     if ((previous instanceof ParseDeleteOperation))
/* 29 */       return new ParseSetOperation(this.amount);
/* 30 */     if ((previous instanceof ParseSetOperation)) {
/* 31 */       Object oldValue = ((ParseSetOperation)previous).getValue();
/* 32 */       if ((oldValue instanceof Number)) {
/* 33 */         return new ParseSetOperation(Parse.addNumbers((Number)oldValue, this.amount));
/*    */       }
/* 35 */       throw new IllegalArgumentException("You cannot increment a non-number.");
/*    */     }
/* 37 */     if ((previous instanceof ParseIncrementOperation)) {
/* 38 */       Number oldAmount = ((ParseIncrementOperation)previous).amount;
/* 39 */       return new ParseIncrementOperation(Parse.addNumbers(oldAmount, this.amount));
/*    */     }
/* 41 */     throw new IllegalArgumentException("Operation is invalid after previous operation.");
/*    */   }
/*    */ 
/*    */   public Object apply(Object oldValue, ParseObject object, String key)
/*    */   {
/* 47 */     if (oldValue == null)
/* 48 */       return this.amount;
/* 49 */     if ((oldValue instanceof Number)) {
/* 50 */       return Parse.addNumbers((Number)oldValue, this.amount);
/*    */     }
/* 52 */     throw new IllegalArgumentException("You cannot increment a non-number.");
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseIncrementOperation
 * JD-Core Version:    0.6.0
 */