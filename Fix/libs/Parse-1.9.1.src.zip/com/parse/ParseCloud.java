/*     */ package com.parse;
/*     */ 
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import java.util.Map;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public final class ParseCloud
/*     */ {
/*     */   private static Object convertCloudResponse(Object result)
/*     */   {
/*  42 */     if ((result instanceof JSONObject)) {
/*  43 */       JSONObject jsonResult = (JSONObject)result;
/*     */       try {
/*  45 */         result = jsonResult.get("result");
/*     */       } catch (JSONException e) {
/*  47 */         return result;
/*     */       }
/*     */     }
/*     */ 
/*  51 */     ParseDecoder decoder = new ParseDecoder();
/*  52 */     Object finalResult = decoder.decode(result);
/*  53 */     if (finalResult != null) {
/*  54 */       return finalResult;
/*     */     }
/*     */ 
/*  57 */     return result;
/*     */   }
/*     */ 
/*     */   public static <T> Task<T> callFunctionInBackground(String name, Map<String, ?> params)
/*     */   {
/*  73 */     return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation(name, params)
/*     */     {
/*     */       public Task<T> then(Task<String> task) throws Exception {
/*  76 */         String sessionToken = (String)task.getResult();
/*  77 */         ParseRESTCommand command = ParseRESTCloudCommand.callFunctionCommand(this.val$name, this.val$params, sessionToken);
/*     */ 
/*  79 */         return command.executeAsync().onSuccess(new Continuation()
/*     */         {
/*     */           public T then(Task<Object> task)
/*     */             throws Exception
/*     */           {
/*  84 */             Object result = ParseCloud.access$000(task.getResult());
/*  85 */             return result;
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static <T> T callFunction(String name, Map<String, ?> params)
/*     */     throws ParseException
/*     */   {
/* 106 */     return Parse.waitForTask(callFunctionInBackground(name, params));
/*     */   }
/*     */ 
/*     */   public static <T> void callFunctionInBackground(String name, Map<String, ?> params, FunctionCallback<T> callback)
/*     */   {
/* 122 */     Parse.callbackOnMainThreadAsync(callFunctionInBackground(name, params), callback);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseCloud
 * JD-Core Version:    0.6.0
 */