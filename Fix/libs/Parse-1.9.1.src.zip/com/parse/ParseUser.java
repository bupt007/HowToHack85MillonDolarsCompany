/*      */ package com.parse;
/*      */ 
/*      */ import bolts.Capture;
/*      */ import bolts.Continuation;
/*      */ import bolts.Task;
/*      */ import java.io.File;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.Callable;
/*      */ import org.json.JSONException;
/*      */ import org.json.JSONObject;
/*      */ 
/*      */ @ParseClassName("_User")
/*      */ public class ParseUser extends ParseObject
/*      */ {
/*      */   static final String FILENAME_CURRENT_USER = "currentUser";
/*      */   static final String PIN_CURRENT_USER = "_currentUser";
/*      */   private static final String KEY_SESSION_TOKEN = "sessionToken";
/*      */   private static final String KEY_AUTH_DATA = "authData";
/*      */   private static final String KEY_USERNAME = "username";
/*      */   private static final String KEY_PASSWORD = "password";
/*      */   private static final String KEY_EMAIL = "email";
/*      */   private static final String KEY_IS_NEW = "isNew";
/*   39 */   private static final List<String> READ_ONLY_KEYS = Collections.unmodifiableList(Arrays.asList(new String[] { "sessionToken", "isNew" }));
/*      */ 
/*   51 */   private static final Object MUTEX_CURRENT_USER = new Object();
/*      */   static ParseUser currentUser;
/*   56 */   private static final TaskQueue QUEUE_CURRENT_USER = new TaskQueue();
/*   57 */   private static Map<String, ParseAuthenticationProvider> authenticationProviders = new HashMap();
/*      */ 
/*   61 */   private static boolean currentUserMatchesDisk = false;
/*      */   private String password;
/*      */   private String sessionToken;
/*      */   private final JSONObject authData;
/*      */   private final Set<String> linkedServiceNames;
/*      */   private final Set<String> readOnlyLinkedServiceNames;
/*      */   private boolean isNew;
/*      */   private boolean isLazy;
/*      */   private boolean dirty;
/*      */   private boolean isCurrentUser;
/* 1786 */   private static final Object isAutoUserEnabledMutex = new Object();
/*      */   private static boolean autoUserEnabled;
/* 1820 */   private static final Object isRevocableSessionEnabledMutex = new Object();
/*      */   private static boolean isRevocableSessionEnabled;
/*      */ 
/*      */   public static ParseQuery<ParseUser> getQuery()
/*      */   {
/*   69 */     return ParseQuery.getQuery(ParseUser.class);
/*      */   }
/*      */ 
/*      */   public ParseUser()
/*      */   {
/*   94 */     this.isLazy = false;
/*   95 */     this.isCurrentUser = false;
/*   96 */     this.authData = new JSONObject();
/*   97 */     this.linkedServiceNames = new HashSet();
/*   98 */     this.readOnlyLinkedServiceNames = Collections.unmodifiableSet(this.linkedServiceNames);
/*      */   }
/*      */ 
/*      */   boolean needsDefaultACL()
/*      */   {
/*  103 */     return false;
/*      */   }
/*      */ 
/*      */   boolean isKeyMutable(String key)
/*      */   {
/*  108 */     return !READ_ONLY_KEYS.contains(key);
/*      */   }
/*      */ 
/*      */   static ParseUser logInLazyUser(String authType, JSONObject authData) {
/*  112 */     ParseUser user = (ParseUser)ParseObject.create(ParseUser.class);
/*  113 */     synchronized (user.mutex) {
/*  114 */       user.isCurrentUser = true;
/*  115 */       user.isLazy = true;
/*      */       try {
/*  117 */         user.authData.put(authType, authData);
/*  118 */         user.linkedServiceNames.add(authType);
/*      */       } catch (JSONException e) {
/*  120 */         throw new RuntimeException(e);
/*      */       }
/*      */     }
/*      */ 
/*  124 */     synchronized (MUTEX_CURRENT_USER) {
/*  125 */       currentUserMatchesDisk = false;
/*  126 */       currentUser = user;
/*      */     }
/*      */ 
/*  129 */     return user;
/*      */   }
/*      */ 
/*      */   boolean isLazy()
/*      */   {
/*  138 */     synchronized (this.mutex) {
/*  139 */       return this.isLazy;
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean isDirty(boolean considerChildren)
/*      */   {
/*  145 */     return (this.dirty) || (super.isDirty(considerChildren));
/*      */   }
/*      */ 
/*      */   public boolean isAuthenticated()
/*      */   {
/*  154 */     synchronized (this.mutex) {
/*  155 */       ParseUser current = getCurrentUser();
/*  156 */       return (isLazy()) || ((this.sessionToken != null) && (current != null) && (getObjectId().equals(current.getObjectId())));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void remove(String key)
/*      */   {
/*  163 */     if ("username".equals(key)) {
/*  164 */       throw new IllegalArgumentException("Can't remove the username key.");
/*      */     }
/*  166 */     super.remove(key);
/*      */   }
/*      */ 
/*      */   JSONObject toJSONObjectForSaving(ParseOperationSet operations, ParseObjectEncodingStrategy objectEncoder)
/*      */   {
/*  176 */     synchronized (this.mutex) {
/*  177 */       JSONObject objectJSON = super.toJSONObjectForSaving(operations, objectEncoder);
/*      */ 
/*  179 */       if (this.authData.length() > 0) {
/*      */         try {
/*  181 */           objectJSON.put("authData", this.authData);
/*      */         } catch (JSONException e) {
/*  183 */           throw new RuntimeException("could not attach key: authData");
/*      */         }
/*      */       }
/*  186 */       if (this.password != null) {
/*      */         try {
/*  188 */           objectJSON.put("password", this.password);
/*      */         } catch (JSONException e) {
/*  190 */           throw new RuntimeException("could not attach key: password");
/*      */         }
/*      */       }
/*      */ 
/*  194 */       return objectJSON;
/*      */     }
/*      */   }
/*      */ 
/*      */   JSONObject toJSONObjectForDataFile(boolean includeOperations, ParseObjectEncodingStrategy objectEncoder)
/*      */   {
/*  205 */     synchronized (this.mutex) {
/*  206 */       JSONObject objectJSON = super.toJSONObjectForDataFile(includeOperations, objectEncoder);
/*      */ 
/*  208 */       if (this.sessionToken != null) {
/*      */         try {
/*  210 */           objectJSON.put("session_token", this.sessionToken);
/*      */         } catch (JSONException e) {
/*  212 */           throw new RuntimeException("could not encode value for key: session_token");
/*      */         }
/*      */       }
/*      */ 
/*  216 */       if (this.authData.length() > 0) {
/*      */         try {
/*  218 */           objectJSON.put("auth_data", this.authData);
/*      */         } catch (JSONException e) {
/*  220 */           throw new RuntimeException("could not attach key: auth_data");
/*      */         }
/*      */       }
/*      */ 
/*  224 */       return objectJSON;
/*      */     }
/*      */   }
/*      */ 
/*      */   void mergeFromDiskJSON(JSONObject object)
/*      */   {
/*  230 */     synchronized (this.mutex) {
/*  231 */       String newSessionToken = object.optString("session_token", null);
/*  232 */       if (newSessionToken != null) {
/*  233 */         this.sessionToken = newSessionToken;
/*  234 */         object.remove("session_token");
/*      */       }
/*      */ 
/*  237 */       JSONObject newAuthData = object.optJSONObject("auth_data");
/*  238 */       if (newAuthData != null)
/*      */       {
/*      */         try
/*      */         {
/*  242 */           Iterator i = newAuthData.keys();
/*  243 */           while (i.hasNext()) {
/*  244 */             String key = (String)i.next();
/*  245 */             if (!newAuthData.isNull(key)) {
/*  246 */               this.authData.put(key, newAuthData.get(key));
/*  247 */               this.linkedServiceNames.add(key);
/*      */             }
/*  249 */             synchronizeAuthData(key);
/*      */           }
/*      */         } catch (JSONException e) {
/*  252 */           throw new RuntimeException(e);
/*      */         }
/*  254 */         object.remove("auth_data");
/*      */       }
/*      */ 
/*  257 */       super.mergeFromDiskJSON(object);
/*      */     }
/*      */   }
/*      */ 
/*      */   void mergeFromObject(ParseObject other)
/*      */   {
/*  264 */     synchronized (this.mutex) {
/*  265 */       super.mergeFromObject(other);
/*      */ 
/*  268 */       if (this == other) {
/*  269 */         return;
/*      */       }
/*      */ 
/*  273 */       if ((other instanceof ParseUser)) {
/*  274 */         this.sessionToken = ((ParseUser)other).sessionToken;
/*  275 */         this.isNew = ((ParseUser)other).isNew();
/*      */ 
/*  277 */         Iterator key = this.authData.keys();
/*  278 */         while (key.hasNext()) {
/*  279 */           key.next();
/*  280 */           key.remove();
/*      */         }
/*  282 */         key = ((ParseUser)other).authData.keys();
/*  283 */         while (key.hasNext()) {
/*  284 */           String k = (String)key.next();
/*      */           try
/*      */           {
/*  287 */             Object v = ((ParseUser)other).authData.get(k);
/*  288 */             this.authData.put(k, v);
/*      */           } catch (JSONException e) {
/*  290 */             throw new RuntimeException("A JSONException occurred where one was not possible.");
/*      */           }
/*      */         }
/*      */ 
/*  294 */         this.linkedServiceNames.clear();
/*  295 */         this.linkedServiceNames.addAll(((ParseUser)other).linkedServiceNames);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void mergeFromServer(JSONObject object, ParseDecoder decoder, boolean completeData)
/*      */   {
/*  304 */     synchronized (this.mutex)
/*      */     {
/*  307 */       String newSessionToken = object.optString("sessionToken", null);
/*  308 */       if (newSessionToken != null) {
/*  309 */         this.sessionToken = newSessionToken;
/*      */       }
/*      */ 
/*  312 */       JSONObject newAuthData = object.optJSONObject("authData");
/*      */       try {
/*  314 */         if (newAuthData != null)
/*      */         {
/*  317 */           Iterator i = newAuthData.keys();
/*  318 */           while (i.hasNext()) {
/*  319 */             String key = (String)i.next();
/*  320 */             if (!newAuthData.isNull(key)) {
/*  321 */               this.authData.put(key, newAuthData.get(key));
/*  322 */               this.linkedServiceNames.add(key);
/*      */             }
/*  324 */             synchronizeAuthData(key);
/*      */           }
/*      */         }
/*      */ 
/*  328 */         if (object.has("is_new"))
/*  329 */           this.isNew = object.optBoolean("is_new");
/*      */       }
/*      */       catch (JSONException e) {
/*  332 */         throw new RuntimeException(e);
/*      */       }
/*      */ 
/*  337 */       object.remove("session_token");
/*  338 */       object.remove("sessionToken");
/*      */ 
/*  340 */       super.mergeFromServer(object, decoder, completeData);
/*      */     }
/*      */   }
/*      */ 
/*      */   JSONObject toRest(ParseObjectEncodingStrategy objectEncoder)
/*      */   {
/*  346 */     synchronized (this.mutex) {
/*  347 */       JSONObject objectJSON = super.toRest(objectEncoder);
/*      */ 
/*  349 */       if (this.sessionToken != null) {
/*      */         try {
/*  351 */           objectJSON.put("sessionToken", this.sessionToken);
/*      */         } catch (JSONException e) {
/*  353 */           throw new RuntimeException("could not encode value for key: sessionToken");
/*      */         }
/*      */       }
/*      */ 
/*  357 */       if (this.authData.length() > 0) {
/*      */         try {
/*  359 */           objectJSON.put("authData", this.authData);
/*      */         } catch (JSONException e) {
/*  361 */           throw new RuntimeException("could not attach key: authData");
/*      */         }
/*      */       }
/*      */ 
/*  365 */       return objectJSON;
/*      */     }
/*      */   }
/*      */ 
/*      */   void mergeREST(JSONObject object, ParseDecoder decoder)
/*      */   {
/*  371 */     synchronized (this.mutex) {
/*  372 */       super.mergeREST(object, decoder);
/*      */ 
/*  375 */       if (object.has("sessionToken")) {
/*      */         try {
/*  377 */           this.sessionToken = object.getString("sessionToken");
/*      */         } catch (JSONException e) {
/*  379 */           throw new RuntimeException(e.getMessage());
/*      */         }
/*      */       }
/*      */ 
/*  383 */       if (object.has("authData")) {
/*      */         try
/*      */         {
/*  386 */           JSONObject newData = object.getJSONObject("authData");
/*      */ 
/*  388 */           Iterator i = newData.keys();
/*  389 */           while (i.hasNext()) {
/*  390 */             String key = (String)i.next();
/*  391 */             this.authData.put(key, newData.get(key));
/*  392 */             if (!newData.isNull(key)) {
/*  393 */               this.linkedServiceNames.add(key);
/*      */             }
/*  395 */             synchronizeAuthData(key);
/*      */           }
/*      */         } catch (JSONException e) {
/*  398 */           throw new RuntimeException(e);
/*      */         }
/*      */       }
/*      */ 
/*  402 */       if (object.has("isNew"))
/*      */         try {
/*  404 */           this.isNew = object.getBoolean("isNew");
/*      */         } catch (JSONException e) {
/*  406 */           throw new RuntimeException(e);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean isCurrentUser()
/*      */   {
/*  413 */     synchronized (this.mutex) {
/*  414 */       return this.isCurrentUser;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void cleanUpAuthData() {
/*  419 */     synchronized (this.mutex) {
/*  420 */       Iterator i = this.authData.keys();
/*  421 */       while (i.hasNext()) {
/*  422 */         String key = (String)i.next();
/*  423 */         if (this.authData.isNull(key)) {
/*  424 */           i.remove();
/*  425 */           this.linkedServiceNames.remove(key);
/*  426 */           if (authenticationProviders.containsKey(key))
/*  427 */             ((ParseAuthenticationProvider)authenticationProviders.get(key)).restoreAuthentication(null);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getSessionToken()
/*      */   {
/*  440 */     synchronized (this.mutex) {
/*  441 */       return this.sessionToken;
/*      */     }
/*      */   }
/*      */ 
/*      */   Task<Void> setSessionTokenInBackground(String newSessionToken)
/*      */   {
/*  447 */     synchronized (this.mutex) {
/*  448 */       this.sessionToken = newSessionToken;
/*  449 */       return saveCurrentUserAsync(this).makeVoid();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setUsername(String username)
/*      */   {
/*  460 */     put("username", username);
/*      */   }
/*      */ 
/*      */   public String getUsername()
/*      */   {
/*  467 */     return getString("username");
/*      */   }
/*      */ 
/*      */   public void setPassword(String password)
/*      */   {
/*  477 */     synchronized (this.mutex) {
/*  478 */       this.password = password;
/*  479 */       this.dirty = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setEmail(String email)
/*      */   {
/*  490 */     put("email", email);
/*      */   }
/*      */ 
/*      */   public String getEmail()
/*      */   {
/*  497 */     return getString("email");
/*      */   }
/*      */ 
/*      */   public boolean isNew()
/*      */   {
/*  505 */     synchronized (this.mutex) {
/*  506 */       return this.isNew;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void put(String key, Object value)
/*      */   {
/*  514 */     synchronized (this.mutex) {
/*  515 */       if ("username".equals(key))
/*      */       {
/*  517 */         stripAnonymity();
/*      */       }
/*  519 */       if ("password".equals(key)) {
/*  520 */         setPassword((String)value);
/*  521 */         return;
/*      */       }
/*  523 */       super.put(key, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void stripAnonymity() {
/*  528 */     synchronized (this.mutex) {
/*  529 */       if (ParseAnonymousUtils.isLinked(this)) {
/*  530 */         this.linkedServiceNames.remove("anonymous");
/*      */         try {
/*  532 */           if (getObjectId() != null)
/*  533 */             this.authData.put("anonymous", JSONObject.NULL);
/*      */           else
/*  535 */             this.authData.remove("anonymous");
/*      */         }
/*      */         catch (JSONException e) {
/*  538 */           throw new RuntimeException(e);
/*      */         }
/*  540 */         this.dirty = true;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void restoreAnonymity(JSONObject anonymousData) {
/*  546 */     synchronized (this.mutex) {
/*  547 */       if (anonymousData != null) {
/*  548 */         this.linkedServiceNames.add("anonymous");
/*      */         try {
/*  550 */           this.authData.put("anonymous", anonymousData);
/*      */         } catch (JSONException e) {
/*  552 */           throw new RuntimeException(e);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void validateSave()
/*      */   {
/*  560 */     synchronized (this.mutex) {
/*  561 */       if (getObjectId() == null) {
/*  562 */         throw new IllegalArgumentException("Cannot save a ParseUser until it has been signed up. Call signUp first.");
/*      */       }
/*      */ 
/*  566 */       if ((isAuthenticated()) || (!isDirty()) || (isCurrentUser())) {
/*  567 */         return;
/*      */       }
/*      */     }
/*      */ 
/*  571 */     if (!OfflineStore.isEnabled())
/*      */     {
/*  573 */       ParseUser current = getCurrentUser();
/*  574 */       if ((current != null) && (getObjectId().equals(current.getObjectId()))) {
/*  575 */         return;
/*      */       }
/*      */     }
/*      */ 
/*  579 */     throw new IllegalArgumentException("Cannot save a ParseUser that is not authenticated.");
/*      */   }
/*      */ 
/*      */   Task<Void> saveAsync(Task<Void> toAwait)
/*      */   {
/*  584 */     synchronized (this.mutex)
/*      */     {
/*      */       Task task;
/*      */       Task task;
/*  586 */       if (isLazy())
/*  587 */         task = resolveLazinessAsync(toAwait).makeVoid();
/*      */       else {
/*  589 */         task = super.saveAsync(toAwait);
/*      */       }
/*      */ 
/*  592 */       return task.onSuccessTask(new Continuation()
/*      */       {
/*      */         public Task<Void> then(Task<Void> task) throws Exception
/*      */         {
/*  596 */           if (ParseUser.this.isCurrentUser()) {
/*  597 */             ParseUser.this.cleanUpAuthData();
/*  598 */             return ParseUser.access$100(ParseUser.this).makeVoid();
/*      */           }
/*  600 */           return Task.forResult(null);
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */ 
/*      */   void validateDelete() {
/*  608 */     synchronized (this.mutex) {
/*  609 */       super.validateDelete();
/*  610 */       if ((!isAuthenticated()) && (isDirty()))
/*  611 */         throw new IllegalArgumentException("Cannot delete a ParseUser that is not authenticated.");
/*      */     }
/*      */   }
/*      */ 
/*      */   public ParseUser fetch()
/*      */     throws ParseException
/*      */   {
/*  619 */     return (ParseUser)super.fetch();
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> Task<T> fetchAsync(Task<Void> toAwait)
/*      */   {
/*  625 */     synchronized (this.mutex)
/*      */     {
/*  628 */       if (isLazy()) {
/*  629 */         return Task.forResult(this);
/*      */       }
/*      */ 
/*  632 */       return super.fetchAsync(toAwait).onSuccessTask(new Continuation()
/*      */       {
/*      */         public Task<T> then(Task<T> fetchAsyncTask) throws Exception {
/*  635 */           if (ParseUser.this.isCurrentUser()) {
/*  636 */             ParseUser.this.cleanUpAuthData();
/*  637 */             return ParseUser.access$100(ParseUser.this).continueWithTask(new Continuation(fetchAsyncTask)
/*      */             {
/*      */               public Task<T> then(Task<ParseUser> task) throws Exception {
/*  640 */                 return this.val$fetchAsyncTask;
/*      */               } } );
/*      */           }
/*  644 */           return fetchAsyncTask;
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */ 
/*      */   private ParseRESTUserCommand currentServiceLogInCommand(ParseOperationSet operations)
/*      */     throws ParseException
/*      */   {
/*      */     JSONObject params;
/*      */     JSONObject authData;
/*  655 */     synchronized (this.mutex)
/*      */     {
/*  657 */       params = toJSONObjectForSaving(operations, PointerEncodingStrategy.get());
/*  658 */       authData = this.authData;
/*      */     }
/*      */     ParseRESTUserCommand command;
/*      */     try {
/*  663 */       params.put("authData", authData);
/*  664 */       command = ParseRESTUserCommand.serviceLogInUserCommand(params, this.sessionToken, isRevocableSessionEnabled());
/*      */     }
/*      */     catch (JSONException e) {
/*  667 */       throw new ParseException(e);
/*      */     }
/*      */ 
/*  670 */     return command;
/*      */   }
/*      */ 
/*      */   public Task<Void> signUpInBackground()
/*      */   {
/*  686 */     return this.taskQueue.enqueue(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/*  689 */         return ParseUser.this.signUpAsync(task);
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private Task<Void> signUpAsync(Task<Void> toAwait) {
/*  695 */     ParseUser user = getCurrentUser();
/*  696 */     synchronized (this.mutex) {
/*  697 */       String sessionToken = user != null ? user.getSessionToken() : null;
/*  698 */       if ((getUsername() == null) || (getUsername().length() == 0)) {
/*  699 */         return Task.forError(new IllegalArgumentException("Username cannot be missing or blank"));
/*      */       }
/*      */ 
/*  702 */       if (this.password == null) {
/*  703 */         return Task.forError(new IllegalArgumentException("Password cannot be missing or blank"));
/*      */       }
/*      */ 
/*  706 */       if (getObjectId() != null)
/*      */       {
/*      */         try
/*      */         {
/*  712 */           if ((this.authData.has("anonymous")) && (this.authData.get("anonymous") == JSONObject.NULL))
/*      */           {
/*  714 */             return saveAsync(toAwait);
/*      */           }
/*      */         } catch (JSONException e) {
/*  717 */           return Task.forError(new RuntimeException(e));
/*      */         }
/*      */ 
/*  721 */         return Task.forError(new IllegalArgumentException("Cannot sign up a user that has already signed up."));
/*      */       }
/*      */ 
/*  727 */       if (this.operationSetQueue.size() > 1) {
/*  728 */         return Task.forError(new IllegalArgumentException("Cannot sign up a user that is already signing up."));
/*      */       }
/*      */ 
/*  734 */       if ((user != null) && (ParseAnonymousUtils.isLinked(user)))
/*      */       {
/*  738 */         if (this == user) {
/*  739 */           return Task.forError(new IllegalArgumentException("Attempt to merge currentUser with itself.")); } 
/*      */ checkForChangesToMutableContainers();
/*  744 */         user.checkForChangesToMutableContainers();
/*      */ 
/*  746 */         String oldUsername = user.getUsername();
/*  747 */         String oldPassword = user.password;
/*      */         JSONObject anonymousData;
/*      */         try { anonymousData = user.authData.getJSONObject("anonymous");
/*      */         } catch (JSONException e) {
/*  752 */           return Task.forError(new RuntimeException(e));
/*      */         }
/*      */ 
/*  755 */         user.copyChangesFrom(this);
/*  756 */         user.dirty = true;
/*  757 */         user.setPassword(this.password);
/*  758 */         user.setUsername(getUsername());
/*  759 */         revert();
/*      */ 
/*  761 */         return user.saveAsync(toAwait).continueWithTask(new Object(user, oldUsername, oldPassword, anonymousData)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task) throws Exception {
/*  764 */             if ((task.isCancelled()) || (task.isFaulted())) {
/*  765 */               synchronized (this.val$user.mutex) {
/*  766 */                 if (this.val$oldUsername != null) {
/*  767 */                   this.val$user.setUsername(this.val$oldUsername);
/*      */                 }
/*  769 */                 ParseUser.access$302(this.val$user, this.val$oldPassword);
/*  770 */                 this.val$user.restoreAnonymity(this.val$anonymousData);
/*      */               }
/*  772 */               return task;
/*      */             }
/*      */ 
/*  775 */             ParseUser.this.mergeFromObject(this.val$user);
/*  776 */             return ParseUser.access$100(ParseUser.this).makeVoid();
/*      */           }
/*      */         });
/*      */       }
/*  781 */       return Task.call(new Object()
/*      */       {
/*      */         public ParseOperationSet call() throws Exception {
/*  784 */           synchronized (ParseUser.this.mutex) {
/*  785 */             return ParseUser.this.startSave();
/*      */           }
/*      */         }
/*      */       }).continueWithTask(TaskQueue.waitFor(toAwait)).onSuccessTask(new Continuation(sessionToken)
/*      */       {
/*      */         public Task<Void> then(Task<ParseOperationSet> task)
/*      */           throws Exception
/*      */         {
/*  793 */           ParseOperationSet operations = (ParseOperationSet)task.getResult();
/*  794 */           JSONObject objectJSON = ParseUser.this.toJSONObjectForSaving(operations, PointerEncodingStrategy.get());
/*  795 */           ParseRESTCommand command = ParseRESTUserCommand.signUpUserCommand(objectJSON, this.val$sessionToken, ParseUser.access$500());
/*      */ 
/*  797 */           return command.executeAsync().continueWithTask(new Continuation(operations)
/*      */           {
/*      */             public Task<Void> then(Task<Object> signUpTask) throws Exception {
/*  800 */               return ParseUser.this.handleSaveResultAsync((JSONObject)signUpTask.getResult(), this.val$operations).continueWithTask(new Object(signUpTask)
/*      */               {
/*      */                 public Task<Void> then(Task<Void> task) throws Exception
/*      */                 {
/*  804 */                   if ((!this.val$signUpTask.isCancelled()) && (!this.val$signUpTask.isFaulted())) {
/*  805 */                     synchronized (ParseUser.this.mutex) {
/*  806 */                       ParseUser.access$602(ParseUser.this, true);
/*  807 */                       ParseUser.access$702(ParseUser.this, false);
/*  808 */                       ParseUser.access$802(ParseUser.this, false);
/*      */                     }
/*  810 */                     return ParseUser.access$100(ParseUser.this).makeVoid();
/*      */                   }
/*  812 */                   return this.val$signUpTask.makeVoid();
/*      */                 }
/*      */               });
/*      */             }
/*      */           });
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */ 
/*      */   public void signUp()
/*      */     throws ParseException
/*      */   {
/*  837 */     Parse.waitForTask(signUpInBackground());
/*      */   }
/*      */ 
/*      */   public void signUpInBackground(SignUpCallback callback)
/*      */   {
/*  854 */     Parse.callbackOnMainThreadAsync(signUpInBackground(), callback);
/*      */   }
/*      */ 
/*      */   public static Task<ParseUser> logInInBackground(String username, String password)
/*      */   {
/*  872 */     if (username == null) {
/*  873 */       throw new IllegalArgumentException("Must specify a username for the user to log in with");
/*      */     }
/*  875 */     if (password == null) {
/*  876 */       throw new IllegalArgumentException("Must specify a password for the user to log in with");
/*      */     }
/*      */ 
/*  879 */     ParseRESTCommand command = ParseRESTUserCommand.logInUserCommand(username, password, isRevocableSessionEnabled());
/*      */ 
/*  881 */     return command.executeAsync().onSuccessTask(new Continuation()
/*      */     {
/*      */       public Task<ParseUser> then(Task<Object> task) throws Exception {
/*  884 */         JSONObject json = (JSONObject)task.getResult();
/*  885 */         if (json == JSONObject.NULL) {
/*  886 */           throw new ParseException(101, "invalid login credentials");
/*      */         }
/*      */ 
/*  889 */         ParseUser user = (ParseUser)ParseObject.fromJSON(json, "_User", true);
/*  890 */         return ParseUser.access$100(user);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static ParseUser logIn(String username, String password)
/*      */     throws ParseException
/*      */   {
/*  911 */     return (ParseUser)Parse.waitForTask(logInInBackground(username, password));
/*      */   }
/*      */ 
/*      */   public static void logInInBackground(String username, String password, LogInCallback callback)
/*      */   {
/*  930 */     Parse.callbackOnMainThreadAsync(logInInBackground(username, password), callback);
/*      */   }
/*      */ 
/*      */   public static Task<ParseUser> becomeInBackground(String sessionToken)
/*      */   {
/*  946 */     if (sessionToken == null) {
/*  947 */       throw new IllegalArgumentException("Must specify a sessionToken for the user to log in with");
/*      */     }
/*      */ 
/*  950 */     ParseRESTCommand command = ParseRESTUserCommand.getCurrentUserCommand(sessionToken);
/*  951 */     return command.executeAsync().onSuccessTask(new Continuation()
/*      */     {
/*      */       public Task<ParseUser> then(Task<Object> task) throws Exception {
/*  954 */         JSONObject json = (JSONObject)task.getResult();
/*  955 */         if (json == JSONObject.NULL) {
/*  956 */           return Task.forError(new ParseException(101, "invalid login credentials"));
/*      */         }
/*      */ 
/*  960 */         ParseUser user = (ParseUser)ParseObject.fromJSON(json, "_User", true);
/*  961 */         return ParseUser.access$100(user);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static ParseUser become(String sessionToken)
/*      */     throws ParseException
/*      */   {
/*  980 */     return (ParseUser)Parse.waitForTask(becomeInBackground(sessionToken));
/*      */   }
/*      */ 
/*      */   public static void becomeInBackground(String sessionToken, LogInCallback callback)
/*      */   {
/*  996 */     Parse.callbackOnMainThreadAsync(becomeInBackground(sessionToken), callback);
/*      */   }
/*      */ 
/*      */   static Task<ParseUser> getCurrentUserAsync()
/*      */   {
/* 1001 */     return getCurrentUserAsync(isAutomaticUserEnabled());
/*      */   }
/*      */ 
/*      */   public static ParseUser getCurrentUser()
/*      */   {
/* 1011 */     return getCurrentUser(isAutomaticUserEnabled());
/*      */   }
/*      */ 
/*      */   private static ParseUser getCurrentUser(boolean shouldAutoCreateUser)
/*      */   {
/*      */     try
/*      */     {
/* 1024 */       return (ParseUser)Parse.waitForTask(getCurrentUserAsync(shouldAutoCreateUser));
/*      */     } catch (ParseException e) {
/*      */     }
/* 1027 */     return null;
/*      */   }
/*      */ 
/*      */   private static Task<ParseUser> getCurrentUserAsync(boolean shouldAutoCreateUser)
/*      */   {
/* 1032 */     synchronized (MUTEX_CURRENT_USER) {
/* 1033 */       if (currentUser != null) {
/* 1034 */         return Task.forResult(currentUser);
/*      */       }
/*      */     }
/*      */ 
/* 1038 */     return QUEUE_CURRENT_USER.enqueue(new Continuation(shouldAutoCreateUser)
/*      */     {
/*      */       public Task<ParseUser> then(Task<Void> toAwait) throws Exception {
/* 1041 */         return ParseUser.access$900(this.val$shouldAutoCreateUser, toAwait);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private static Task<ParseUser> getCurrentUserAsync(boolean shouldAutoCreateUser, Task<Void> toAwait) {
/* 1048 */     checkApplicationContext();
/*      */ 
/* 1050 */     return toAwait.continueWithTask(new Object(shouldAutoCreateUser)
/*      */     {
/*      */       public Task<ParseUser> then(Task<Void> ignored)
/*      */         throws Exception
/*      */       {
/*      */         ParseUser current;
/*      */         boolean matchesDisk;
/* 1055 */         synchronized (ParseUser.MUTEX_CURRENT_USER) {
/* 1056 */           current = ParseUser.currentUser;
/* 1057 */           matchesDisk = ParseUser.currentUserMatchesDisk;
/*      */         }
/*      */ 
/* 1060 */         if (current != null) {
/* 1061 */           return Task.forResult(current);
/*      */         }
/*      */ 
/* 1064 */         if (matchesDisk) {
/* 1065 */           if (this.val$shouldAutoCreateUser) {
/* 1066 */             return Task.forResult(ParseAnonymousUtils.lazyLogIn());
/*      */           }
/* 1068 */           return null;
/*      */         }
/*      */         Task task;
/*      */         Task task;
/* 1072 */         if (OfflineStore.isEnabled())
/*      */         {
/* 1074 */           ParseQuery query = ParseQuery.getQuery(ParseUser.class).fromPin("_currentUser").ignoreACLs();
/*      */ 
/* 1077 */           task = query.findInBackground().onSuccessTask(new Continuation()
/*      */           {
/*      */             public Task<ParseUser> then(Task<List<ParseUser>> task) throws Exception {
/* 1080 */               List results = (List)task.getResult();
/* 1081 */               if (results != null) {
/* 1082 */                 if (results.size() == 1) {
/* 1083 */                   return Task.forResult(results.get(0));
/*      */                 }
/* 1085 */                 return ParseObject.unpinAllInBackground("_currentUser").cast();
/*      */               }
/*      */ 
/* 1088 */               return Task.forResult(null);
/*      */             }
/*      */           }).onSuccessTask(new Continuation()
/*      */           {
/*      */             public Task<ParseUser> then(Task<ParseUser> task)
/*      */               throws Exception
/*      */             {
/* 1093 */               ParseUser ldsUser = (ParseUser)task.getResult();
/* 1094 */               if (ldsUser != null) {
/* 1095 */                 return task;
/*      */               }
/*      */ 
/* 1098 */               return ParseObject.migrateFromDiskToLDS("currentUser", "_currentUser").cast();
/*      */             } } );
/*      */         }
/*      */         else {
/* 1103 */           task = Task.forResult((ParseUser)ParseObject.getFromDisk(Parse.applicationContext, "currentUser"));
/*      */         }
/*      */ 
/* 1106 */         return task.continueWith(new Object()
/*      */         {
/*      */           public ParseUser then(Task<ParseUser> task) throws Exception {
/* 1109 */             ParseUser current = (ParseUser)task.getResult();
/* 1110 */             boolean matchesDisk = !task.isFaulted();
/*      */ 
/* 1112 */             synchronized (ParseUser.MUTEX_CURRENT_USER) {
/* 1113 */               ParseUser.currentUser = current;
/* 1114 */               ParseUser.access$1102(matchesDisk);
/*      */             }
/*      */ 
/* 1117 */             if (current != null) {
/* 1118 */               synchronized (current.mutex) {
/* 1119 */                 ParseUser.access$1202(current, true);
/*      */               }
/* 1121 */               return current;
/*      */             }
/*      */ 
/* 1124 */             if (ParseUser.10.this.val$shouldAutoCreateUser) {
/* 1125 */               return ParseAnonymousUtils.lazyLogIn();
/*      */             }
/* 1127 */             return null;
/*      */           } } );
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   static String getCurrentSessionToken() {
/* 1136 */     ParseUser current = getCurrentUser();
/* 1137 */     return current != null ? current.getSessionToken() : null;
/*      */   }
/*      */ 
/*      */   static Task<String> getCurrentSessionTokenAsync()
/*      */   {
/* 1142 */     return getCurrentUserAsync(false).onSuccess(new Continuation()
/*      */     {
/*      */       public String then(Task<ParseUser> task) throws Exception {
/* 1145 */         ParseUser user = (ParseUser)task.getResult();
/* 1146 */         return user != null ? user.getSessionToken() : null;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private static Task<ParseUser> saveCurrentUserAsync(ParseUser user) {
/* 1153 */     return QUEUE_CURRENT_USER.enqueue(new Continuation(user)
/*      */     {
/*      */       public Task<ParseUser> then(Task<Void> toAwait) throws Exception {
/* 1156 */         return ParseUser.access$1300(this.val$user, toAwait);
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private static Task<ParseUser> saveCurrentUserAsync(ParseUser user, Task<Void> toAwait) {
/* 1162 */     checkApplicationContext();
/*      */ 
/* 1164 */     return toAwait.continueWithTask(new Object(user)
/*      */     {
/*      */       public Task<Void> then(Task<Void> ignored)
/*      */         throws Exception
/*      */       {
/*      */         ParseUser oldCurrentUser;
/* 1168 */         synchronized (ParseUser.MUTEX_CURRENT_USER) {
/* 1169 */           oldCurrentUser = ParseUser.currentUser;
/*      */         }
/*      */ 
/* 1172 */         if ((oldCurrentUser != null) && (oldCurrentUser != this.val$user))
/*      */         {
/* 1175 */           oldCurrentUser.logOutInternal();
/*      */         }
/*      */ 
/* 1178 */         synchronized (this.val$user.mutex) {
/* 1179 */           ParseUser.access$1202(this.val$user, true);
/* 1180 */           this.val$user.synchronizeAllAuthData();
/*      */         }
/*      */         Task task;
/*      */         Task task;
/* 1184 */         if (OfflineStore.isEnabled())
/* 1185 */           task = ParseObject.unpinAllInBackground("_currentUser").continueWithTask(new Continuation()
/*      */           {
/*      */             public Task<Void> then(Task<Void> task) throws Exception {
/* 1188 */               return ParseUser.14.this.val$user.pinInBackground("_currentUser", false);
/*      */             }
/*      */           });
/* 1192 */         else task = Task.call(new Callable()
/*      */           {
/*      */             public Void call() throws Exception {
/* 1195 */               ParseUser.14.this.val$user.saveToDisk(Parse.applicationContext, "currentUser");
/*      */ 
/* 1197 */               return null;
/*      */             }
/*      */           }
/*      */           , Task.BACKGROUND_EXECUTOR);
/*      */ 
/* 1201 */         return task;
/*      */       }
/*      */     }).continueWith(new Object(user)
/*      */     {
/*      */       public ParseUser then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1206 */         synchronized (ParseUser.MUTEX_CURRENT_USER) {
/* 1207 */           ParseUser.access$1102(!task.isFaulted());
/* 1208 */           ParseUser.currentUser = this.val$user;
/*      */         }
/* 1210 */         return this.val$user;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   static Task<Void> pinCurrentUserIfNeededAsync(ParseUser user)
/*      */   {
/* 1219 */     synchronized (MUTEX_CURRENT_USER) {
/* 1220 */       if ((!user.isCurrentUser()) || (currentUserMatchesDisk)) {
/* 1221 */         return Task.forResult(null);
/*      */       }
/*      */     }
/*      */ 
/* 1225 */     return saveCurrentUserAsync(user).makeVoid();
/*      */   }
/*      */ 
/*      */   public static Task<Void> logOutInBackground()
/*      */   {
/* 1238 */     return QUEUE_CURRENT_USER.enqueue(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 1241 */         return ParseUser.access$1600(toAwait);
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private static Task<Void> logOutInBackground(Task<Void> toAwait) {
/* 1247 */     checkApplicationContext();
/*      */ 
/* 1251 */     Task userTask = getCurrentUserAsync(false);
/*      */ 
/* 1253 */     return toAwait.continueWithTask(new Continuation(userTask)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 1256 */         Task logOutTask = this.val$userTask.onSuccessTask(new Continuation()
/*      */         {
/*      */           public Task<Void> then(Task<ParseUser> task) throws Exception {
/* 1259 */             ParseUser user = (ParseUser)task.getResult();
/* 1260 */             if (user == null) {
/* 1261 */               return task.cast();
/*      */             }
/* 1263 */             return user.logOutAsync();
/*      */           }
/*      */         });
/* 1267 */         Task diskTask = this.val$userTask.continueWith(new Continuation()
/*      */         {
/*      */           public Boolean then(Task<ParseUser> task)
/*      */             throws Exception
/*      */           {
/* 1272 */             return Boolean.valueOf(ParseFileUtils.deleteQuietly(new File(Parse.getParseDir(), "currentUser")));
/*      */           }
/*      */         }
/*      */         , Task.BACKGROUND_EXECUTOR).continueWithTask(new Continuation()
/*      */         {
/*      */           public Task<Boolean> then(Task<Boolean> task)
/*      */             throws Exception
/*      */           {
/* 1278 */             if (OfflineStore.isEnabled())
/* 1279 */               return ParseObject.unpinAllInBackground("_currentUser").continueWith(new Continuation()
/*      */               {
/*      */                 public Boolean then(Task<Void> task) throws Exception {
/* 1282 */                   return Boolean.valueOf(!task.isFaulted());
/*      */                 }
/*      */               });
/* 1286 */             return task;
/*      */           }
/*      */         }).onSuccess(new Object()
/*      */         {
/*      */           public Void then(Task<Boolean> task)
/*      */             throws Exception
/*      */           {
/* 1291 */             boolean deleted = ((Boolean)task.getResult()).booleanValue();
/* 1292 */             synchronized (ParseUser.MUTEX_CURRENT_USER) {
/* 1293 */               ParseUser.access$1102(deleted);
/* 1294 */               ParseUser.currentUser = null;
/*      */             }
/* 1296 */             return null;
/*      */           }
/*      */         });
/* 1300 */         return Task.whenAll(Arrays.asList(new Task[] { logOutTask, diskTask }));
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static void logOutInBackground(LogOutCallback callback)
/*      */   {
/* 1313 */     Parse.callbackOnMainThreadAsync(logOutInBackground(), callback);
/*      */   }
/*      */ 
/*      */   public static void logOut()
/*      */   {
/*      */     try
/*      */     {
/* 1329 */       Parse.waitForTask(logOutInBackground());
/*      */     }
/*      */     catch (ParseException e)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   private Task<Void> logOutAsync()
/*      */   {
/* 1338 */     String oldSessionToken = logOutInternal();
/* 1339 */     return revokeSessionTokenAsync(oldSessionToken);
/*      */   }
/*      */ 
/*      */   private String logOutInternal()
/*      */   {
/*      */     String oldSessionToken;
/* 1344 */     synchronized (this.mutex) {
/* 1345 */       oldSessionToken = this.sessionToken;
/*      */ 
/* 1347 */       for (String authType : getLinkedServiceNames()) {
/* 1348 */         logOutWith(authType);
/*      */       }
/*      */ 
/* 1351 */       this.isCurrentUser = false;
/* 1352 */       this.isNew = false;
/* 1353 */       this.sessionToken = null;
/*      */     }
/* 1355 */     return oldSessionToken;
/*      */   }
/*      */ 
/*      */   private Task<Void> revokeSessionTokenAsync(String sessionToken) {
/* 1359 */     if ((sessionToken == null) || (!isRevocableSessionToken(sessionToken))) {
/* 1360 */       return Task.forResult(null);
/*      */     }
/* 1362 */     return ParseRESTUserCommand.logOutUserCommand(sessionToken).executeAsync().makeVoid();
/*      */   }
/*      */ 
/*      */   public static Task<Void> requestPasswordResetInBackground(String email)
/*      */   {
/* 1381 */     ParseRESTCommand command = ParseRESTUserCommand.resetUserPasswordCommand(email);
/* 1382 */     return command.executeAsync().makeVoid();
/*      */   }
/*      */ 
/*      */   public static void requestPasswordReset(String email)
/*      */     throws ParseException
/*      */   {
/* 1399 */     Parse.waitForTask(requestPasswordResetInBackground(email));
/*      */   }
/*      */ 
/*      */   public static void requestPasswordResetInBackground(String email, RequestPasswordResetCallback callback)
/*      */   {
/* 1417 */     Parse.callbackOnMainThreadAsync(requestPasswordResetInBackground(email), callback);
/*      */   }
/*      */ 
/*      */   private static void checkApplicationContext()
/*      */   {
/* 1425 */     if (Parse.applicationContext == null)
/* 1426 */       throw new RuntimeException("You must call Parse.initialize(context, oauthKey, oauthSecret) before using the Parse library.");
/*      */   }
/*      */ 
/*      */   public ParseUser fetchIfNeeded()
/*      */     throws ParseException
/*      */   {
/* 1434 */     return (ParseUser)super.fetchIfNeeded();
/*      */   }
/*      */ 
/*      */   boolean isLinked(String authType)
/*      */   {
/* 1440 */     return getLinkedServiceNames().contains(authType);
/*      */   }
/*      */ 
/*      */   private Set<String> getLinkedServiceNames() {
/* 1444 */     synchronized (this.mutex) {
/* 1445 */       return this.readOnlyLinkedServiceNames;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void synchronizeAuthData(String authType) {
/* 1450 */     synchronized (this.mutex) {
/* 1451 */       if (!isCurrentUser()) {
/* 1452 */         return;
/*      */       }
/* 1454 */       ParseAuthenticationProvider provider = (ParseAuthenticationProvider)authenticationProviders.get(authType);
/* 1455 */       if (provider == null) {
/* 1456 */         return;
/*      */       }
/* 1458 */       synchronizeAuthData(provider);
/*      */     }
/*      */   }
/*      */ 
/*      */   void synchronizeAuthData(ParseAuthenticationProvider provider) {
/* 1463 */     synchronized (this.mutex) {
/* 1464 */       String authType = provider.getAuthType();
/* 1465 */       boolean success = provider.restoreAuthentication(this.authData.optJSONObject(authType));
/* 1466 */       if (!success)
/* 1467 */         unlinkFromAsync(authType);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void synchronizeAllAuthData()
/*      */   {
/* 1477 */     synchronized (this.mutex) {
/* 1478 */       Iterator authTypes = this.authData.keys();
/* 1479 */       while (authTypes.hasNext())
/* 1480 */         synchronizeAuthData((String)authTypes.next());
/*      */     }
/*      */   }
/*      */ 
/*      */   Task<Void> unlinkFromAsync(String authType)
/*      */   {
/* 1486 */     synchronized (this.mutex) {
/* 1487 */       if (authType == null) {
/* 1488 */         return Task.forResult(null);
/*      */       }
/* 1490 */       return Task.forResult(null).continueWithTask(new Object(authType)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task) throws Exception {
/* 1493 */           synchronized (ParseUser.this.mutex) {
/* 1494 */             if (ParseUser.this.authData.has(this.val$authType)) {
/* 1495 */               ParseUser.this.authData.put(this.val$authType, JSONObject.NULL);
/* 1496 */               ParseUser.access$702(ParseUser.this, true);
/* 1497 */               return ParseUser.this.saveInBackground();
/*      */             }
/* 1499 */             return Task.forResult(null);
/*      */           }
/*      */         } } );
/*      */     }
/*      */   }
/*      */ 
/*      */   static void registerAuthenticationProvider(ParseAuthenticationProvider provider) {
/* 1507 */     authenticationProviders.put(provider.getAuthType(), provider);
/*      */ 
/* 1509 */     if ((provider instanceof AnonymousAuthenticationProvider))
/*      */     {
/* 1511 */       return;
/*      */     }
/*      */ 
/* 1516 */     ParseUser user = getCurrentUser();
/* 1517 */     if (user != null)
/* 1518 */       user.synchronizeAuthData(provider);
/*      */   }
/*      */ 
/*      */   static Task<ParseUser> logInWithAsync(String authType, JSONObject authData)
/*      */   {
/* 1523 */     Continuation logInWithTask = new Continuation(authType, authData)
/*      */     {
/*      */       public Task<ParseUser> then(Task<Void> task) throws Exception {
/* 1526 */         ParseRESTUserCommand command = ParseRESTUserCommand.serviceLogInUserCommand(this.val$authType, this.val$authData, ParseUser.access$500());
/*      */ 
/* 1528 */         return command.executeAsync().onSuccessTask(new Object(command)
/*      */         {
/*      */           public Task<ParseUser> then(Task<Object> task) throws Exception {
/* 1531 */             JSONObject result = (JSONObject)task.getResult();
/* 1532 */             ParseUser user = (ParseUser)ParseObject.fromJSON(result, "_User", true);
/* 1533 */             synchronized (user.mutex) {
/*      */               try {
/* 1535 */                 user.authData.put(ParseUser.18.this.val$authType, ParseUser.18.this.val$authData);
/* 1536 */                 user.linkedServiceNames.add(ParseUser.18.this.val$authType);
/*      */               } catch (JSONException e) {
/* 1538 */                 throw new ParseException(e);
/*      */               }
/* 1540 */               ParseUser.access$602(user, this.val$command.getStatusCode() == 201);
/*      */             }
/* 1542 */             return ParseUser.access$100(user);
/*      */           }
/*      */         });
/*      */       }
/*      */     };
/* 1549 */     return getCurrentUserAsync().onSuccessTask(new Object(authType, authData, logInWithTask)
/*      */     {
/*      */       public Task<ParseUser> then(Task<ParseUser> task) throws Exception {
/* 1552 */         ParseUser user = (ParseUser)task.getResult(); if (user != null) {
/* 1553 */           synchronized (user.mutex) {
/* 1554 */             if (ParseAnonymousUtils.isLinked(user)) {
/* 1555 */               if (user.isLazy()) {
/* 1556 */                 JSONObject oldAnonymousData = user.authData.optJSONObject("anonymous");
/*      */ 
/* 1558 */                 return user.taskQueue.enqueue(new Continuation(user, oldAnonymousData)
/*      */                 {
/*      */                   public Task<ParseUser> then(Task<Void> toAwait) throws Exception {
/* 1561 */                     return toAwait.continueWithTask(new Object()
/*      */                     {
/*      */                       public Task<Void> then(Task<Void> task) throws Exception {
/* 1564 */                         synchronized (ParseUser.19.1.this.val$user.mutex)
/*      */                         {
/* 1566 */                           ParseUser.19.1.this.val$user.stripAnonymity();
/*      */ 
/* 1568 */                           ParseUser.19.1.this.val$user.authData.put(ParseUser.19.this.val$authType, ParseUser.19.this.val$authData);
/* 1569 */                           ParseUser.19.1.this.val$user.linkedServiceNames.add(ParseUser.19.this.val$authType);
/* 1570 */                           return ParseUser.19.1.this.val$user.resolveLazinessAsync(task).makeVoid();
/*      */                         }
/*      */                       }
/*      */                     }).continueWithTask(new Object()
/*      */                     {
/*      */                       public Task<ParseUser> then(Task<Void> task)
/*      */                         throws Exception
/*      */                       {
/* 1576 */                         synchronized (ParseUser.19.1.this.val$user.mutex) {
/* 1577 */                           if (task.isFaulted()) {
/* 1578 */                             ParseUser.19.1.this.val$user.authData.remove(ParseUser.19.this.val$authType);
/* 1579 */                             ParseUser.19.1.this.val$user.linkedServiceNames.remove(ParseUser.19.this.val$authType);
/* 1580 */                             ParseUser.19.1.this.val$user.restoreAnonymity(ParseUser.19.1.this.val$oldAnonymousData);
/* 1581 */                             return Task.forError(task.getError());
/*      */                           }
/* 1583 */                           if (task.isCancelled()) {
/* 1584 */                             return Task.cancelled();
/*      */                           }
/* 1586 */                           return Task.forResult(ParseUser.19.1.this.val$user);
/*      */                         }
/*      */                       }
/*      */                     });
/*      */                   }
/*      */                 });
/*      */               }
/*      */ 
/* 1596 */               return user.linkWithAsync(this.val$authType, this.val$authData).continueWithTask(new Continuation(user)
/*      */               {
/*      */                 public Task<ParseUser> then(Task<Void> task) throws Exception {
/* 1599 */                   if (task.isFaulted()) {
/* 1600 */                     Exception error = task.getError();
/* 1601 */                     if (((error instanceof ParseException)) && (((ParseException)error).getCode() == 208))
/*      */                     {
/* 1605 */                       return Task.forResult(null).continueWithTask(ParseUser.19.this.val$logInWithTask);
/*      */                     }
/*      */                   }
/* 1608 */                   if (task.isCancelled()) {
/* 1609 */                     return Task.cancelled();
/*      */                   }
/* 1611 */                   return Task.forResult(this.val$user);
/*      */                 }
/*      */               });
/*      */             }
/*      */           }
/*      */         }
/* 1618 */         return Task.forResult(null).continueWithTask(this.val$logInWithTask);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private Task<Void> linkWithAsync(String authType, JSONObject authData, Task<Void> toAwait) {
/* 1625 */     JSONObject oldAnonymousData = authData.optJSONObject("anonymous");
/*      */ 
/* 1627 */     synchronized (this.mutex) {
/* 1628 */       return Task.call(new Object(authType, authData)
/*      */       {
/*      */         public Void call() throws Exception {
/* 1631 */           synchronized (ParseUser.this.mutex) {
/* 1632 */             ParseUser.this.authData.put(this.val$authType, this.val$authData);
/* 1633 */             ParseUser.this.linkedServiceNames.add(this.val$authType);
/*      */ 
/* 1635 */             ParseUser.this.stripAnonymity();
/*      */ 
/* 1637 */             ParseUser.access$702(ParseUser.this, true);
/* 1638 */             return null;
/*      */           }
/*      */         }
/*      */       }).onSuccessTask(new Continuation(toAwait)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task)
/*      */           throws Exception
/*      */         {
/* 1644 */           return ParseUser.this.saveAsync(this.val$toAwait);
/*      */         }
/*      */       }).continueWithTask(new Object(oldAnonymousData, authType)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task)
/*      */           throws Exception
/*      */         {
/* 1649 */           synchronized (ParseUser.this.mutex) {
/* 1650 */             if ((task.isFaulted()) || (task.isCancelled())) {
/* 1651 */               ParseUser.this.restoreAnonymity(this.val$oldAnonymousData);
/* 1652 */               return task;
/*      */             }
/* 1654 */             ParseUser.this.synchronizeAuthData(this.val$authType);
/* 1655 */             return task;
/*      */           }
/*      */         } } );
/*      */     }
/*      */   }
/*      */ 
/*      */   Task<Void> linkWithAsync(String authType, JSONObject authData) {
/* 1663 */     return this.taskQueue.enqueue(new Continuation(authType, authData)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 1666 */         return ParseUser.this.linkWithAsync(this.val$authType, this.val$authData, task);
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private void logOutWith(String authType) {
/* 1672 */     synchronized (this.mutex) {
/* 1673 */       ParseAuthenticationProvider provider = (ParseAuthenticationProvider)authenticationProviders.get(authType);
/* 1674 */       if ((provider != null) && (this.linkedServiceNames.contains(authType)))
/* 1675 */         provider.deauthenticate();
/*      */     }
/*      */   }
/*      */ 
/*      */   private Task<ParseUser> resolveLazinessAsync(Task<Void> toAwait)
/*      */   {
/* 1694 */     synchronized (this.mutex) {
/* 1695 */       if (!isLazy()) {
/* 1696 */         return Task.forResult(null);
/*      */       }
/* 1698 */       if (this.linkedServiceNames.size() == 0)
/*      */       {
/* 1700 */         return signUpAsync(toAwait).onSuccess(new Object()
/*      */         {
/*      */           public ParseUser then(Task<Void> task) throws Exception {
/* 1703 */             synchronized (ParseUser.this.mutex) {
/* 1704 */               ParseUser.access$802(ParseUser.this, false);
/* 1705 */               return ParseUser.this;
/*      */             }
/*      */           }
/*      */         });
/*      */       }
/* 1711 */       Capture operations = new Capture();
/*      */ 
/* 1714 */       return Task.call(new Callable()
/*      */       {
/*      */         public ParseOperationSet call() throws Exception {
/* 1717 */           return ParseUser.this.startSave();
/*      */         }
/*      */       }).onSuccessTask(TaskQueue.waitFor(toAwait)).onSuccessTask(new Continuation(operations)
/*      */       {
/*      */         public Task<ParseUser> then(Task<ParseOperationSet> task)
/*      */           throws Exception
/*      */         {
/* 1724 */           this.val$operations.set(task.getResult());
/* 1725 */           ParseRESTUserCommand command = ParseUser.this.currentServiceLogInCommand((ParseOperationSet)this.val$operations.get());
/* 1726 */           return command.executeAsync().onSuccessTask(new Continuation(command)
/*      */           {
/*      */             public Task<ParseUser> then(Task<Object> task) throws Exception
/*      */             {
/* 1730 */               JSONObject commandResult = (JSONObject)task.getResult();
/* 1731 */               boolean isNew = this.val$command.getStatusCode() == 201;
/*      */               Task resultTask;
/*      */               Task resultTask;
/* 1736 */               if ((OfflineStore.isEnabled()) && (!isNew))
/* 1737 */                 resultTask = Task.forResult(commandResult);
/*      */               else
/* 1739 */                 resultTask = ParseUser.this.handleSaveResultAsync(commandResult, (ParseOperationSet)ParseUser.25.this.val$operations.get()).onSuccess(new Continuation(commandResult)
/*      */                 {
/*      */                   public JSONObject then(Task<Void> task) throws Exception
/*      */                   {
/* 1743 */                     return this.val$commandResult;
/*      */                   }
/*      */                 });
/* 1747 */               return resultTask.onSuccessTask(new Object(isNew)
/*      */               {
/*      */                 public Task<ParseUser> then(Task<JSONObject> task) throws Exception {
/* 1750 */                   JSONObject commandResult = (JSONObject)task.getResult();
/* 1751 */                   synchronized (ParseUser.this.mutex) {
/* 1752 */                     ParseUser.access$702(ParseUser.this, false);
/* 1753 */                     if (this.val$isNew)
/*      */                     {
/* 1757 */                       ParseUser.access$802(ParseUser.this, false);
/* 1758 */                       return Task.forResult(ParseUser.this);
/*      */                     }
/*      */ 
/*      */                   }
/*      */ 
/* 1763 */                   ParseUser newUser = (ParseUser)ParseObject.fromJSON(commandResult, "_User", true);
/* 1764 */                   return ParseUser.access$100(newUser);
/*      */                 }
/*      */               });
/*      */             }
/*      */           });
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> Task<T> fetchFromLocalDatastoreAsync() {
/* 1778 */     if (isLazy()) {
/* 1779 */       return Task.forResult(this);
/*      */     }
/* 1781 */     return super.fetchFromLocalDatastoreAsync();
/*      */   }
/*      */ 
/*      */   public static void enableAutomaticUser()
/*      */   {
/* 1799 */     synchronized (isAutoUserEnabledMutex) {
/* 1800 */       autoUserEnabled = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   static void disableAutomaticUser() {
/* 1805 */     synchronized (isAutoUserEnabledMutex) {
/* 1806 */       autoUserEnabled = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   static boolean isAutomaticUserEnabled() {
/* 1811 */     synchronized (isAutoUserEnabledMutex) {
/* 1812 */       return autoUserEnabled;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static Task<Void> enableRevocableSessionInBackground()
/*      */   {
/* 1834 */     synchronized (isRevocableSessionEnabledMutex) {
/* 1835 */       isRevocableSessionEnabled = true;
/*      */     }
/*      */ 
/* 1838 */     return getCurrentUserAsync(false).onSuccessTask(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<ParseUser> task) throws Exception {
/* 1841 */         ParseUser user = (ParseUser)task.getResult();
/* 1842 */         if (user == null) {
/* 1843 */           return Task.forResult(null);
/*      */         }
/* 1845 */         return user.upgradeToRevocableSessionAsync();
/*      */       } } );
/*      */   }
/*      */ 
/*      */   static void disableRevocableSession() {
/* 1851 */     synchronized (isRevocableSessionEnabledMutex) {
/* 1852 */       isRevocableSessionEnabled = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static boolean isRevocableSessionEnabled() {
/* 1857 */     synchronized (isRevocableSessionEnabledMutex) {
/* 1858 */       return isRevocableSessionEnabled;
/*      */     }
/*      */   }
/*      */ 
/*      */   static boolean isRevocableSessionToken(String sessionToken) {
/* 1863 */     return sessionToken.contains("r:");
/*      */   }
/*      */ 
/*      */   Task<Void> upgradeToRevocableSessionAsync() {
/* 1867 */     return this.taskQueue.enqueue(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 1870 */         return ParseUser.this.upgradeToRevocableSessionAsync(toAwait);
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private Task<Void> upgradeToRevocableSessionAsync(Task<Void> toAwait) {
/* 1876 */     String sessionToken = getSessionToken();
/*      */ 
/* 1878 */     if ((sessionToken == null) || (isRevocableSessionToken(sessionToken))) {
/* 1879 */       return toAwait;
/*      */     }
/*      */ 
/* 1882 */     return toAwait.continueWithTask(new Continuation(sessionToken)
/*      */     {
/*      */       public Task<JSONObject> then(Task<Void> task) throws Exception {
/* 1885 */         return ParseRESTUserCommand.upgradeRevocableSessionCommand(this.val$sessionToken).executeAsync().cast();
/*      */       }
/*      */     }).onSuccessTask(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<JSONObject> task)
/*      */         throws Exception
/*      */       {
/* 1892 */         JSONObject json = (JSONObject)task.getResult();
/* 1893 */         ParseSession session = (ParseSession)ParseObject.fromJSON(json, "_Session", true);
/* 1894 */         return ParseUser.this.setSessionTokenInBackground(session.getSessionToken());
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   static void clearCurrentUserFromMemory()
/*      */   {
/* 1903 */     synchronized (MUTEX_CURRENT_USER) {
/* 1904 */       currentUser = null;
/* 1905 */       currentUserMatchesDisk = false;
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseUser
 * JD-Core Version:    0.6.0
 */