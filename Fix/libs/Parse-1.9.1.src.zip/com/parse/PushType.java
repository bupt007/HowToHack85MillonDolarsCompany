/*    */ package com.parse;
/*    */ 
/*    */  enum PushType
/*    */ {
/*  4 */   NONE("none"), 
/*  5 */   PPNS("ppns"), 
/*  6 */   GCM("gcm");
/*    */ 
/*    */   private final String pushType;
/*    */ 
/* 11 */   private PushType(String pushType) { this.pushType = pushType; }
/*    */ 
/*    */   static PushType fromString(String pushType)
/*    */   {
/* 15 */     if ("none".equals(pushType))
/* 16 */       return NONE;
/* 17 */     if ("ppns".equals(pushType))
/* 18 */       return PPNS;
/* 19 */     if ("gcm".equals(pushType)) {
/* 20 */       return GCM;
/*    */     }
/* 22 */     return null;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 28 */     return this.pushType;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.PushType
 * JD-Core Version:    0.6.0
 */