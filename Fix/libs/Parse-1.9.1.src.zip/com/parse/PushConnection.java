/*     */ package com.parse;
/*     */ 
/*     */ import android.app.AlarmManager;
/*     */ import android.app.PendingIntent;
/*     */ import android.app.Service;
/*     */ import android.content.BroadcastReceiver;
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import android.content.IntentFilter;
/*     */ import android.os.Looper;
/*     */ import android.os.SystemClock;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ import org.json.JSONTokener;
/*     */ 
/*     */ class PushConnection
/*     */ {
/*     */   private static final String TAG = "com.parse.PushConnection";
/*     */   private static final int CONNECT_TIMEOUT_MS = 40000;
/*  64 */   static long KEEP_ALIVE_INTERVAL = 900000L;
/*     */ 
/*  67 */   static long KEEP_ALIVE_ACK_INTERVAL = 60000L;
/*     */ 
/*  69 */   static boolean ENABLE_QUICK_ACK_CHECK = true;
/*     */ 
/*  72 */   static boolean ENABLE_RETRY_DELAY = true;
/*     */   private static final long MIN_RETRY_DELAY_MS = 15000L;
/*     */   private static final long MAX_RETRY_DELAY_MS = 300000L;
/*     */   private static final double RETRY_MULT_FACTOR_MIN = 1.5D;
/*     */   private static final double RETRY_MULT_FACTOR_MAX = 2.0D;
/*     */   private final Service service;
/*     */   private final String host;
/*     */   private final int port;
/*     */   private final ExecutorService executor;
/*     */   private final EventSet eventSet;
/*     */   private final AtomicLong lastReadTime;
/*     */   private static List<StateTransitionListener> stateTransitionListeners;
/*     */ 
/*     */   public PushConnection(Service service, String host, int port)
/*     */   {
/*  89 */     this.service = service;
/*  90 */     this.host = host;
/*  91 */     this.port = port;
/*  92 */     this.executor = Executors.newSingleThreadExecutor();
/*  93 */     this.eventSet = new EventSet(null);
/*  94 */     this.lastReadTime = new AtomicLong();
/*     */ 
/*  96 */     State nextState = new WaitStartState();
/*  97 */     dispatchOnStateChange(this, null, nextState);
/*  98 */     this.executor.execute(nextState);
/*     */   }
/*     */ 
/*     */   public synchronized void start()
/*     */   {
/* 104 */     this.eventSet.signalEvent(Event.START);
/*     */   }
/*     */ 
/*     */   public synchronized void stop()
/*     */   {
/* 109 */     this.eventSet.signalEvent(Event.STOP);
/*     */   }
/*     */ 
/*     */   private static boolean writeLine(Socket socket, String string) {
/* 113 */     boolean sent = false;
/*     */ 
/* 123 */     if (Thread.currentThread() == Looper.getMainLooper().getThread()) {
/* 124 */       throw new Error("Wrote to push socket on main thread.");
/*     */     }
/*     */     try
/*     */     {
/* 128 */       OutputStream stream = socket.getOutputStream();
/* 129 */       stream.write((string + "\n").getBytes("UTF-8"));
/* 130 */       stream.flush();
/* 131 */       sent = true;
/*     */     } catch (IOException e) {
/* 133 */       Parse.logV("com.parse.PushConnection", "PushConnection write failed: " + string + " due to exception: " + e);
/*     */     }
/*     */ 
/* 136 */     return sent;
/*     */   }
/*     */ 
/*     */   private static void closeSocket(Socket socket)
/*     */   {
/*     */     try
/*     */     {
/* 146 */       if (!(socket instanceof SSLSocket)) {
/* 147 */         socket.shutdownInput();
/*     */       }
/* 149 */       socket.close();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void registerStateTransitionListener(StateTransitionListener listener)
/*     */   {
/* 163 */     synchronized (PushConnection.class) {
/* 164 */       if (stateTransitionListeners == null) {
/* 165 */         stateTransitionListeners = new ArrayList();
/*     */       }
/* 167 */       if (!stateTransitionListeners.contains(listener))
/* 168 */         stateTransitionListeners.add(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void unregisterStateTransitionListener(StateTransitionListener listener)
/*     */   {
/* 174 */     synchronized (PushConnection.class) {
/* 175 */       if (stateTransitionListeners == null) {
/* 176 */         return;
/*     */       }
/* 178 */       stateTransitionListeners.remove(listener);
/* 179 */       if (stateTransitionListeners.size() == 0)
/* 180 */         stateTransitionListeners = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void dispatchOnStateChange(PushConnection connection, State from, State to)
/*     */   {
/* 186 */     synchronized (PushConnection.class) {
/* 187 */       if (stateTransitionListeners != null)
/* 188 */         for (StateTransitionListener listener : stateTransitionListeners)
/* 189 */           listener.onStateChange(connection, from, to);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class EventSet
/*     */   {
/* 810 */     private final Lock lock = new ReentrantLock();
/* 811 */     private final Condition condition = this.lock.newCondition();
/* 812 */     private final HashSet<PushConnection.Event> signaledEvents = new HashSet();
/*     */ 
/*     */     public void signalEvent(PushConnection.Event event)
/*     */     {
/* 819 */       this.lock.lock();
/*     */       try
/*     */       {
/* 822 */         this.signaledEvents.add(event);
/* 823 */         this.condition.signalAll();
/*     */       } finally {
/* 825 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void removeEvents(PushConnection.Event[] eventsToRemove)
/*     */     {
/* 834 */       this.lock.lock();
/*     */       try
/*     */       {
/* 837 */         for (PushConnection.Event e : eventsToRemove)
/* 838 */           this.signaledEvents.remove(e);
/*     */       }
/*     */       finally {
/* 841 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public Set<PushConnection.Event> await(PushConnection.Event[] eventsToAwait)
/*     */     {
/* 850 */       return timedAwait(9223372036854775807L, eventsToAwait);
/*     */     }
/*     */ 
/*     */     public Set<PushConnection.Event> timedAwait(long timeoutMs, PushConnection.Event[] eventsToAwait)
/*     */     {
/* 859 */       Set e = Collections.EMPTY_SET;
/* 860 */       Set toAwait = new HashSet(Arrays.asList(eventsToAwait));
/* 861 */       long startMs = SystemClock.elapsedRealtime();
/* 862 */       boolean awaitForever = timeoutMs == 9223372036854775807L;
/*     */ 
/* 864 */       this.lock.lock();
/*     */       try {
/*     */         while (true) {
/* 867 */           long delta = SystemClock.elapsedRealtime() - startMs;
/* 868 */           e = new HashSet(toAwait);
/* 869 */           e.retainAll(this.signaledEvents);
/* 870 */           this.signaledEvents.removeAll(toAwait);
/*     */ 
/* 872 */           if ((e.size() != 0) || ((!awaitForever) && (delta >= timeoutMs)))
/*     */           {
/*     */             break;
/*     */           }
/* 876 */           if (awaitForever)
/* 877 */             this.condition.awaitUninterruptibly();
/*     */           else
/*     */             try {
/* 880 */               this.condition.await(timeoutMs - delta, TimeUnit.MILLISECONDS);
/*     */             }
/*     */             catch (InterruptedException exception)
/*     */             {
/* 884 */               break;
/*     */             }
/*     */         }
/*     */       }
/*     */       finally {
/* 889 */         this.lock.unlock();
/*     */       }
/*     */ 
/* 892 */       return e;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ReaderThread extends Thread
/*     */   {
/*     */     private final Socket socket;
/*     */     private boolean stopped;
/*     */ 
/*     */     public ReaderThread(Socket socket)
/*     */     {
/* 728 */       this.socket = socket;
/* 729 */       this.stopped = false;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 734 */       InputStream is = null;
/* 735 */       BufferedReader reader = null;
/*     */       try
/*     */       {
/* 738 */         is = this.socket.getInputStream();
/*     */ 
/* 740 */         if (is != null) {
/* 741 */           reader = new BufferedReader(new InputStreamReader(is));
/* 742 */           runReaderLoop(reader);
/*     */         }
/*     */       } catch (IOException e) {
/*     */       }
/*     */       finally {
/* 747 */         ParseIOUtils.closeQuietly(reader);
/* 748 */         ParseIOUtils.closeQuietly(is);
/*     */       }
/*     */ 
/* 751 */       synchronized (this) {
/* 752 */         if (!this.stopped)
/* 753 */           PushConnection.this.eventSet.signalEvent(PushConnection.Event.READ_ERROR);
/*     */       }
/*     */     }
/*     */ 
/*     */     private void runReaderLoop(BufferedReader reader)
/*     */     {
/*     */       while (true) {
/* 760 */         String line = null;
/*     */         try
/*     */         {
/* 764 */           line = reader.readLine();
/* 765 */           PushConnection.this.lastReadTime.set(SystemClock.elapsedRealtime());
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/*     */         }
/* 770 */         if (line == null)
/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/* 775 */         JSONTokener tokener = new JSONTokener(line);
/* 776 */         JSONObject message = null;
/*     */         try {
/* 778 */           message = new JSONObject(tokener);
/*     */         }
/*     */         catch (JSONException e) {
/* 781 */           Parse.logE("com.parse.PushConnection", "bad json: " + line, e);
/*     */         }
/*     */ 
/* 784 */         if (message != null) {
/* 785 */           PushRouter.handlePpnsPushAsync(message);
/*     */         }
/*     */ 
/* 790 */         synchronized (this) {
/* 791 */           if (this.stopped)
/* 792 */             break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public void stopReading()
/*     */     {
/* 800 */       synchronized (this) {
/* 801 */         this.stopped = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class KeepAliveMonitor
/*     */   {
/*     */     private final Socket socket;
/*     */     private final long interval;
/*     */     private BroadcastReceiver writeReceiver;
/*     */     private BroadcastReceiver readReceiver;
/*     */     private AlarmManager manager;
/*     */     private PendingIntent broadcast;
/*     */     private Task<Void> keepAliveTask;
/*     */     private boolean unregistered;
/*     */ 
/*     */     public KeepAliveMonitor(Socket socket, long interval)
/*     */     {
/* 554 */       this.socket = socket;
/* 555 */       this.interval = interval;
/*     */     }
/*     */ 
/*     */     public void register()
/*     */     {
/* 565 */       Context appContext = Parse.applicationContext;
/* 566 */       String packageName = appContext.getPackageName();
/*     */ 
/* 568 */       String readAction = "com.parse.PushConnection.readKeepAlive";
/* 569 */       Intent readIntent = new Intent("com.parse.PushConnection.readKeepAlive");
/* 570 */       readIntent.setPackage(packageName);
/* 571 */       readIntent.addCategory(packageName);
/*     */ 
/* 573 */       String writeAction = "com.parse.PushConnection.writeKeepAlive";
/* 574 */       Intent writeIntent = new Intent("com.parse.PushConnection.writeKeepAlive");
/* 575 */       writeIntent.setPackage(packageName);
/* 576 */       writeIntent.addCategory(packageName);
/*     */ 
/* 578 */       this.manager = ((AlarmManager)appContext.getSystemService("alarm"));
/*     */ 
/* 581 */       PendingIntent oldReadBroadcast = PendingIntent.getBroadcast(appContext, 0, readIntent, 0);
/*     */ 
/* 584 */       if (oldReadBroadcast != null) {
/* 585 */         this.manager.cancel(oldReadBroadcast);
/* 586 */         oldReadBroadcast.cancel();
/*     */       } else {
/* 588 */         Parse.logE("com.parse.PushConnection", "oldReadBroadcast was null");
/*     */       }
/*     */ 
/* 591 */       this.broadcast = PendingIntent.getBroadcast(appContext, 0, writeIntent, 0);
/* 592 */       this.manager.cancel(this.broadcast);
/*     */ 
/* 595 */       int alarmType = 2;
/* 596 */       long start = SystemClock.elapsedRealtime();
/* 597 */       this.manager.setInexactRepeating(alarmType, start, this.interval, this.broadcast);
/*     */ 
/* 599 */       this.readReceiver = new BroadcastReceiver()
/*     */       {
/*     */         public void onReceive(Context context, Intent intent) {
/* 602 */           long delta = SystemClock.elapsedRealtime() - PushConnection.this.lastReadTime.get();
/*     */ 
/* 606 */           if (delta > PushConnection.KEEP_ALIVE_ACK_INTERVAL * 2L) {
/* 607 */             Parse.logV("com.parse.PushConnection", "Keep alive failure: last read was " + delta + " ms ago.");
/* 608 */             PushConnection.KeepAliveMonitor.this.signalKeepAliveFailure();
/*     */           }
/*     */         }
/*     */       };
/* 613 */       this.writeReceiver = new BroadcastReceiver(appContext, readIntent)
/*     */       {
/*     */         public void onReceive(Context context, Intent intent) {
/* 616 */           ParseWakeLock wl = ParseWakeLock.acquireNewWakeLock(PushConnection.this.service, 1, "push-keep-alive", 20000L);
/*     */ 
/* 622 */           if (PushConnection.KeepAliveMonitor.this.keepAliveTask == null) {
/* 623 */             PushConnection.KeepAliveMonitor.access$1302(PushConnection.KeepAliveMonitor.this, Task.forResult(null).makeVoid());
/*     */           }
/*     */ 
/* 627 */           PushConnection.KeepAliveMonitor.access$1302(PushConnection.KeepAliveMonitor.this, PushConnection.KeepAliveMonitor.this.keepAliveTask.continueWith(new Continuation(wl)
/*     */           {
/*     */             public Void then(Task<Void> task) {
/* 630 */               if (!PushConnection.access$700(PushConnection.KeepAliveMonitor.this.socket, "{}")) {
/* 631 */                 PushConnection.KeepAliveMonitor.this.signalKeepAliveFailure();
/*     */               }
/*     */ 
/* 640 */               boolean quickAckCheckSucceeded = false;
/*     */ 
/* 642 */               if (PushConnection.ENABLE_QUICK_ACK_CHECK) {
/* 643 */                 long quickCheckDelta = 2500L;
/*     */                 try
/*     */                 {
/* 646 */                   Thread.sleep(quickCheckDelta);
/*     */                 }
/*     */                 catch (InterruptedException e)
/*     */                 {
/*     */                 }
/* 651 */                 long delta = SystemClock.elapsedRealtime() - PushConnection.this.lastReadTime.get();
/* 652 */                 quickAckCheckSucceeded = delta <= 2L * quickCheckDelta;
/*     */               }
/*     */ 
/* 657 */               if (!quickAckCheckSucceeded) {
/* 658 */                 PendingIntent pendingIntent = PendingIntent.getBroadcast(PushConnection.KeepAliveMonitor.2.this.val$appContext, System.identityHashCode(this), PushConnection.KeepAliveMonitor.2.this.val$readIntent, 1342177280);
/*     */ 
/* 663 */                 PushConnection.KeepAliveMonitor.this.manager.set(2, SystemClock.elapsedRealtime() + PushConnection.KEEP_ALIVE_ACK_INTERVAL, pendingIntent);
/*     */               }
/*     */               else
/*     */               {
/* 667 */                 Parse.logV("com.parse.PushConnection", "Keep alive ack was received quickly.");
/*     */               }
/*     */ 
/* 670 */               this.val$wl.release();
/*     */ 
/* 672 */               return null;
/*     */             }
/*     */           }
/*     */           , ParseCommand.NETWORK_EXECUTOR));
/*     */         }
/*     */       };
/* 684 */       IntentFilter readFilter = new IntentFilter("com.parse.PushConnection.readKeepAlive");
/* 685 */       readFilter.addCategory(packageName);
/* 686 */       appContext.registerReceiver(this.readReceiver, readFilter);
/*     */ 
/* 688 */       IntentFilter writeFilter = new IntentFilter("com.parse.PushConnection.writeKeepAlive");
/* 689 */       writeFilter.addCategory(packageName);
/* 690 */       appContext.registerReceiver(this.writeReceiver, writeFilter);
/*     */     }
/*     */ 
/*     */     private synchronized void signalKeepAliveFailure() {
/* 694 */       if (!this.unregistered)
/* 695 */         PushConnection.this.eventSet.signalEvent(PushConnection.Event.KEEP_ALIVE_ERROR);
/*     */     }
/*     */ 
/*     */     public void unregister()
/*     */     {
/* 704 */       Parse.applicationContext.unregisterReceiver(this.readReceiver);
/* 705 */       Parse.applicationContext.unregisterReceiver(this.writeReceiver);
/* 706 */       this.manager.cancel(this.broadcast);
/* 707 */       this.broadcast.cancel();
/*     */ 
/* 709 */       synchronized (this) {
/* 710 */         this.unregistered = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ReachabilityMonitor
/*     */   {
/*     */     private ConnectivityNotifier.ConnectivityListener listener;
/*     */     private boolean unregistered;
/*     */ 
/*     */     private ReachabilityMonitor()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void register()
/*     */     {
/* 504 */       this.listener = new Object()
/*     */       {
/*     */         public void networkConnectivityStatusChanged(Context context, Intent intent) {
/* 507 */           synchronized (PushConnection.ReachabilityMonitor.this) {
/* 508 */             if (!PushConnection.ReachabilityMonitor.this.unregistered)
/* 509 */               PushConnection.this.eventSet.signalEvent(PushConnection.Event.CONNECTIVITY_CHANGED);
/*     */           }
/*     */         }
/*     */       };
/* 515 */       ConnectivityNotifier.getNotifier(PushConnection.this.service).addListener(this.listener);
/*     */     }
/*     */ 
/*     */     public void unregister()
/*     */     {
/* 521 */       ConnectivityNotifier.getNotifier(PushConnection.this.service).removeListener(this.listener);
/*     */ 
/* 523 */       synchronized (this) {
/* 524 */         this.unregistered = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public class StoppedState extends PushConnection.State
/*     */   {
/*     */     public StoppedState()
/*     */     {
/* 480 */       super();
/*     */     }
/*     */     public PushConnection.State runState() {
/* 483 */       return null;
/*     */     }
/*     */ 
/*     */     public boolean isTerminal()
/*     */     {
/* 488 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public class WaitRetryState extends PushConnection.State
/*     */   {
/*     */     private long delay;
/*     */ 
/*     */     public WaitRetryState(long delay)
/*     */     {
/* 436 */       super();
/* 437 */       this.delay = delay;
/*     */     }
/*     */ 
/*     */     public long getDelay() {
/* 441 */       return this.delay;
/*     */     }
/*     */ 
/*     */     public PushConnection.State runState()
/*     */     {
/* 449 */       PushConnection.this.eventSet.removeEvents(new PushConnection.Event[] { PushConnection.Event.START });
/*     */ 
/* 452 */       long actualDelay = this.delay;
/* 453 */       if (!PushConnection.ENABLE_RETRY_DELAY) {
/* 454 */         actualDelay = 0L;
/*     */       }
/*     */ 
/* 461 */       Set e = PushConnection.this.eventSet.timedAwait(actualDelay, new PushConnection.Event[] { PushConnection.Event.STOP, PushConnection.Event.START });
/*     */       PushConnection.State nextState;
/*     */       PushConnection.State nextState;
/* 463 */       if (e.contains(PushConnection.Event.STOP)) {
/* 464 */         nextState = new PushConnection.StoppedState(PushConnection.this);
/*     */       }
/*     */       else
/*     */       {
/*     */         PushConnection.State nextState;
/* 465 */         if (e.contains(PushConnection.Event.START))
/*     */         {
/* 468 */           nextState = new PushConnection.ConnectState(PushConnection.this, 0L);
/*     */         }
/* 470 */         else nextState = new PushConnection.ConnectState(PushConnection.this, this.delay);
/*     */       }
/*     */ 
/* 473 */       return nextState;
/*     */     }
/*     */   }
/*     */ 
/*     */   public class ConnectedState extends PushConnection.State
/*     */   {
/*     */     private final Socket socket;
/*     */ 
/*     */     public ConnectedState(Socket socket)
/*     */     {
/* 375 */       super();
/* 376 */       this.socket = socket;
/*     */     }
/*     */ 
/*     */     public PushConnection.State runState()
/*     */     {
/* 381 */       PushConnection.State nextState = null;
/* 382 */       PushConnection.ReachabilityMonitor reachabilityMonitor = new PushConnection.ReachabilityMonitor(PushConnection.this, null);
/* 383 */       PushConnection.KeepAliveMonitor keepAliveMonitor = new PushConnection.KeepAliveMonitor(PushConnection.this, this.socket, PushConnection.KEEP_ALIVE_INTERVAL);
/* 384 */       PushConnection.ReaderThread readerThread = new PushConnection.ReaderThread(PushConnection.this, this.socket);
/*     */ 
/* 386 */       reachabilityMonitor.register();
/* 387 */       keepAliveMonitor.register();
/* 388 */       readerThread.start();
/*     */ 
/* 390 */       while (nextState == null) {
/* 391 */         Set e = PushConnection.this.eventSet.await(new PushConnection.Event[] { PushConnection.Event.STOP, PushConnection.Event.CONNECTIVITY_CHANGED, PushConnection.Event.KEEP_ALIVE_ERROR, PushConnection.Event.READ_ERROR });
/*     */ 
/* 398 */         if (e.contains(PushConnection.Event.STOP))
/* 399 */           nextState = new PushConnection.StoppedState(PushConnection.this);
/* 400 */         else if ((e.contains(PushConnection.Event.READ_ERROR)) || (e.contains(PushConnection.Event.KEEP_ALIVE_ERROR)) || (e.contains(PushConnection.Event.CONNECTIVITY_CHANGED)))
/*     */         {
/* 403 */           nextState = new PushConnection.WaitRetryState(PushConnection.this, 0L);
/*     */         }
/*     */       }
/*     */ 
/* 407 */       reachabilityMonitor.unregister();
/* 408 */       keepAliveMonitor.unregister();
/* 409 */       readerThread.stopReading();
/* 410 */       PushConnection.access$600(this.socket);
/*     */ 
/* 414 */       PushConnection.this.eventSet.removeEvents(new PushConnection.Event[] { PushConnection.Event.CONNECTIVITY_CHANGED, PushConnection.Event.KEEP_ALIVE_ERROR, PushConnection.Event.READ_ERROR });
/*     */ 
/* 420 */       return nextState;
/*     */     }
/*     */   }
/*     */ 
/*     */   public class ConnectState extends PushConnection.State
/*     */   {
/*     */     private long lastDelay;
/*     */ 
/*     */     public ConnectState(long lastDelay)
/*     */     {
/* 284 */       super();
/* 285 */       this.lastDelay = lastDelay;
/*     */     }
/*     */ 
/*     */     public PushConnection.State runState()
/*     */     {
/* 290 */       boolean connectedAndSentHandshake = false;
/* 291 */       Socket socket = null;
/* 292 */       Throwable t = null;
/*     */       try
/*     */       {
/* 296 */         if (!"push.parse.com".equals(PushConnection.this.host)) {
/* 297 */           socket = new Socket();
/*     */         } else {
/* 299 */           SocketFactory sslSocketFactory = SSLSocketFactory.getDefault();
/* 300 */           socket = sslSocketFactory.createSocket();
/*     */         }
/* 302 */         InetSocketAddress address = new InetSocketAddress(PushConnection.this.host, PushConnection.this.port);
/* 303 */         socket.connect(address, 40000);
/*     */ 
/* 305 */         socket.setKeepAlive(true);
/* 306 */         socket.setTcpNoDelay(true);
/* 307 */         connectedAndSentHandshake = sendHandshake(socket);
/*     */       } catch (IOException e) {
/* 309 */         t = e;
/*     */       }
/*     */       catch (SecurityException e)
/*     */       {
/* 317 */         t = e;
/*     */       }
/*     */ 
/* 320 */       if (t != null) {
/* 321 */         Parse.logI("com.parse.PushConnection", "Failed to connect to push server due to " + t);
/*     */       }
/*     */ 
/* 324 */       if (!connectedAndSentHandshake) {
/* 325 */         PushConnection.access$600(socket);
/* 326 */         return new PushConnection.WaitRetryState(PushConnection.this, nextDelay());
/*     */       }
/* 328 */       return new PushConnection.ConnectedState(PushConnection.this, socket);
/*     */     }
/*     */ 
/*     */     private boolean sendHandshake(Socket socket)
/*     */     {
/* 333 */       boolean success = false;
/* 334 */       Task handshakeTask = PushRouter.getPushRequestJSONAsync();
/*     */       try
/*     */       {
/* 337 */         handshakeTask.waitForCompletion();
/*     */       } catch (InterruptedException e) {
/* 339 */         Parse.logE("com.parse.PushConnection", "Unexpected interruption when waiting for handshake to be sent", e);
/*     */       }
/*     */ 
/* 342 */       JSONObject request = (JSONObject)handshakeTask.getResult();
/* 343 */       if (request != null) {
/* 344 */         success = PushConnection.access$700(socket, request.toString());
/*     */       }
/*     */ 
/* 347 */       return success;
/*     */     }
/*     */ 
/*     */     private long nextDelay()
/*     */     {
/* 353 */       long delay = ()(this.lastDelay * (1.5D + Math.random() * 0.5D));
/* 354 */       delay = Math.min(Math.max(15000L, delay), 300000L);
/*     */ 
/* 356 */       return delay;
/*     */     }
/*     */   }
/*     */ 
/*     */   public class WaitStartState extends PushConnection.State
/*     */   {
/*     */     public WaitStartState()
/*     */     {
/* 256 */       super();
/*     */     }
/*     */     public PushConnection.State runState() {
/* 259 */       PushConnection.State nextState = null;
/* 260 */       Set e = PushConnection.this.eventSet.await(new PushConnection.Event[] { PushConnection.Event.START, PushConnection.Event.STOP });
/*     */ 
/* 262 */       if (e.contains(PushConnection.Event.STOP))
/* 263 */         nextState = new PushConnection.StoppedState(PushConnection.this);
/* 264 */       else if (e.contains(PushConnection.Event.START)) {
/* 265 */         nextState = new PushConnection.ConnectState(PushConnection.this, 0L);
/*     */       }
/*     */ 
/* 268 */       return nextState;
/*     */     }
/*     */   }
/*     */ 
/*     */   public abstract class State
/*     */     implements Runnable
/*     */   {
/*     */     public State()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 218 */       State nextState = runState();
/*     */ 
/* 220 */       PushConnection.access$100(PushConnection.this, this, nextState);
/*     */ 
/* 222 */       if (isTerminal()) {
/* 223 */         Parse.logI("com.parse.PushConnection", this + " finished and is the terminal state. Thread exiting.");
/* 224 */         PushConnection.this.executor.shutdown();
/* 225 */       } else if (nextState != null) {
/* 226 */         Parse.logI("com.parse.PushConnection", "PushConnection transitioning from " + this + " to " + nextState);
/* 227 */         PushConnection.this.executor.execute(nextState);
/*     */       } else {
/* 229 */         throw new NullPointerException(this + " tried to transition to null state.");
/*     */       }
/*     */     }
/*     */ 
/*     */     public abstract State runState();
/*     */ 
/*     */     public boolean isTerminal()
/*     */     {
/* 246 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum Event
/*     */   {
/* 199 */     START, 
/* 200 */     STOP, 
/* 201 */     CONNECTIVITY_CHANGED, 
/* 202 */     KEEP_ALIVE_ERROR, 
/* 203 */     READ_ERROR;
/*     */   }
/*     */ 
/*     */   public static abstract interface StateTransitionListener
/*     */   {
/*     */     public abstract void onStateChange(PushConnection paramPushConnection, PushConnection.State paramState1, PushConnection.State paramState2);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.PushConnection
 * JD-Core Version:    0.6.0
 */