/*     */ package com.parse;
/*     */ 
/*     */ import com.parse.codec.binary.Base64;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class ParseDecoder
/*     */ {
/*     */   List<Object> convertJSONArrayToList(JSONArray array)
/*     */   {
/*  21 */     List list = new ArrayList();
/*  22 */     for (int i = 0; i < array.length(); i++) {
/*  23 */       list.add(decode(array.opt(i)));
/*     */     }
/*  25 */     return list;
/*     */   }
/*     */ 
/*     */   Map<String, Object> convertJSONObjectToMap(JSONObject object) {
/*  29 */     Map outputMap = new HashMap();
/*  30 */     Iterator it = object.keys();
/*  31 */     while (it.hasNext()) {
/*  32 */       String key = (String)it.next();
/*  33 */       Object value = object.opt(key);
/*  34 */       outputMap.put(key, decode(value));
/*     */     }
/*  36 */     return outputMap;
/*     */   }
/*     */ 
/*     */   protected ParseObject decodePointer(String className, String objectId)
/*     */   {
/*  44 */     return ParseObject.createWithoutData(className, objectId);
/*     */   }
/*     */ 
/*     */   public Object decode(Object object) {
/*  48 */     if ((object instanceof JSONArray)) {
/*  49 */       return convertJSONArrayToList((JSONArray)object);
/*     */     }
/*     */ 
/*  52 */     if (!(object instanceof JSONObject)) {
/*  53 */       return object;
/*     */     }
/*     */ 
/*  56 */     JSONObject jsonObject = (JSONObject)object;
/*     */ 
/*  58 */     String opString = jsonObject.optString("__op", null);
/*  59 */     if (opString != null) {
/*     */       try {
/*  61 */         return ParseFieldOperations.decode(jsonObject, this);
/*     */       } catch (JSONException e) {
/*  63 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */ 
/*  67 */     String typeString = jsonObject.optString("__type", null);
/*  68 */     if (typeString == null) {
/*  69 */       return convertJSONObjectToMap(jsonObject);
/*     */     }
/*     */ 
/*  72 */     if (typeString.equals("Date")) {
/*  73 */       String iso = jsonObject.optString("iso");
/*  74 */       return Parse.stringToDate(iso);
/*     */     }
/*     */ 
/*  77 */     if (typeString.equals("Bytes")) {
/*  78 */       String base64 = jsonObject.optString("base64");
/*  79 */       return Base64.decodeBase64(base64);
/*     */     }
/*     */ 
/*  82 */     if (typeString.equals("Pointer")) {
/*  83 */       return decodePointer(jsonObject.optString("className"), jsonObject.optString("objectId"));
/*     */     }
/*     */ 
/*  87 */     if (typeString.equals("File")) {
/*  88 */       return new ParseFile(jsonObject, this);
/*     */     }
/*     */ 
/*  91 */     if (typeString.equals("GeoPoint")) { double latitude;
/*     */       double longitude;
/*     */       try { latitude = jsonObject.getDouble("latitude");
/*  95 */         longitude = jsonObject.getDouble("longitude");
/*     */       } catch (JSONException e) {
/*  97 */         throw new RuntimeException(e);
/*     */       }
/*  99 */       return new ParseGeoPoint(latitude, longitude);
/*     */     }
/*     */ 
/* 102 */     if (typeString.equals("Object")) {
/* 103 */       String className = jsonObject.optString("className", null);
/* 104 */       String objectId = jsonObject.optString("objectId", null);
/* 105 */       ParseObject output = ParseObject.createWithoutData(className, objectId);
/* 106 */       output.mergeAfterFetch(jsonObject, this, true);
/* 107 */       return output;
/*     */     }
/*     */ 
/* 110 */     if (typeString.equals("Relation")) {
/* 111 */       return new ParseRelation(jsonObject, this);
/*     */     }
/*     */ 
/* 114 */     if (typeString.equals("OfflineObject")) {
/* 115 */       throw new RuntimeException("An unexpected offline pointer was encountered.");
/*     */     }
/*     */ 
/* 118 */     return null;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseDecoder
 * JD-Core Version:    0.6.0
 */