/*    */ package com.parse;
/*    */ 
/*    */ import android.net.Uri;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseRESTObjectCommand extends ParseRESTCommand
/*    */ {
/*    */   public ParseRESTObjectCommand(String httpPath, ParseRequest.Method httpMethod, JSONObject parameters, String sessionToken)
/*    */   {
/* 14 */     super(httpPath, httpMethod, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTObjectCommand getObjectCommand(String objectId, String className, String sessionToken)
/*    */   {
/* 19 */     String httpPath = String.format("classes/%s/%s", new Object[] { Uri.encode(className), Uri.encode(objectId) });
/* 20 */     return new ParseRESTObjectCommand(httpPath, ParseRequest.Method.GET, null, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTObjectCommand createObjectCommand(String className, JSONObject changes, String sessionToken)
/*    */   {
/* 25 */     String httpPath = String.format("classes/%s", new Object[] { Uri.encode(className) });
/* 26 */     return new ParseRESTObjectCommand(httpPath, ParseRequest.Method.POST, changes, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTObjectCommand updateObjectCommand(String objectId, String className, JSONObject changes, String sessionToken)
/*    */   {
/* 31 */     String httpPath = String.format("classes/%s/%s", new Object[] { Uri.encode(className), Uri.encode(objectId) });
/* 32 */     return new ParseRESTObjectCommand(httpPath, ParseRequest.Method.PUT, changes, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTObjectCommand deleteObjectCommand(String objectId, String className, String sessionToken)
/*    */   {
/* 37 */     String httpPath = String.format("classes/%s", new Object[] { Uri.encode(className) });
/* 38 */     if (objectId != null) {
/* 39 */       httpPath = httpPath + String.format("/%s", new Object[] { Uri.encode(objectId) });
/*    */     }
/* 41 */     return new ParseRESTObjectCommand(httpPath, ParseRequest.Method.DELETE, null, sessionToken);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTObjectCommand
 * JD-Core Version:    0.6.0
 */