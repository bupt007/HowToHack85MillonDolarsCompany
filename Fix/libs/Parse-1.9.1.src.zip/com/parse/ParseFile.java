/*     */ package com.parse;
/*     */ 
/*     */ import android.webkit.MimeTypeMap;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import bolts.Task.TaskCompletionSource;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class ParseFile
/*     */ {
/*  48 */   private boolean dirty = false;
/*  49 */   private String name = null;
/*  50 */   private String url = null;
/*  51 */   private String contentType = null;
/*     */   byte[] data;
/*  59 */   final TaskQueue taskQueue = new TaskQueue();
/*  60 */   private Set<Task<?>.TaskCompletionSource> currentTasks = Collections.synchronizedSet(new HashSet());
/*     */ 
/*     */   static File getCacheDir()
/*     */   {
/*  35 */     return Parse.getParseCacheDir("files");
/*     */   }
/*     */ 
/*     */   static File getFilesDir() {
/*  39 */     return Parse.getParseFilesDir("files");
/*     */   }
/*     */ 
/*     */   static void clearCache() {
/*  43 */     for (File file : getCacheDir().listFiles())
/*  44 */       ParseFileUtils.deleteQuietly(file);
/*     */   }
/*     */ 
/*     */   public ParseFile(String name, byte[] data, String contentType)
/*     */   {
/*  77 */     if (data.length > Parse.maxParseFileSize) {
/*  78 */       throw new IllegalArgumentException(String.format("ParseFile must be less than %d bytes", new Object[] { Integer.valueOf(Parse.maxParseFileSize) }));
/*     */     }
/*     */ 
/*  81 */     this.name = name;
/*  82 */     this.data = data;
/*  83 */     this.contentType = contentType;
/*     */ 
/*  85 */     this.dirty = true;
/*     */   }
/*     */ 
/*     */   public ParseFile(byte[] data)
/*     */   {
/*  95 */     this(null, data, null);
/*     */   }
/*     */ 
/*     */   public ParseFile(String name, byte[] data)
/*     */   {
/* 111 */     this(name, data, null);
/*     */   }
/*     */ 
/*     */   public ParseFile(byte[] data, String contentType)
/*     */   {
/* 124 */     this(null, data, contentType);
/*     */   }
/*     */ 
/*     */   ParseFile(String name, String url) {
/* 128 */     this.name = name;
/* 129 */     this.url = url;
/*     */   }
/*     */ 
/*     */   private String getFilename() {
/* 133 */     return this.name;
/*     */   }
/*     */ 
/*     */   File getCacheFile()
/*     */   {
/* 142 */     String filename = getFilename();
/* 143 */     return filename != null ? new File(getCacheDir(), filename) : null;
/*     */   }
/*     */ 
/*     */   File getFilesFile() {
/* 147 */     String filename = getFilename();
/* 148 */     return filename != null ? new File(getFilesDir(), filename) : null;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 158 */     return this.name;
/*     */   }
/*     */ 
/*     */   public boolean isDirty()
/*     */   {
/* 167 */     return this.dirty;
/*     */   }
/*     */ 
/*     */   public boolean isDataAvailable()
/*     */   {
/* 174 */     return (this.data != null) || (!isPinned() ? getCacheFile().exists() : getFilesFile().exists());
/*     */   }
/*     */ 
/*     */   public String getUrl()
/*     */   {
/* 184 */     return this.url;
/*     */   }
/*     */ 
/*     */   private byte[] getCachedData() {
/* 188 */     if (this.data != null)
/* 189 */       return this.data;
/*     */     File file;
/*     */     try
/*     */     {
/* 194 */       file = getCacheFile();
/* 195 */       if (file != null)
/* 196 */         return ParseFileUtils.readFileToByteArray(file);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */     try
/*     */     {
/* 203 */       file = getFilesFile();
/* 204 */       if (file != null) {
/* 205 */         return ParseFileUtils.readFileToByteArray(file);
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/* 211 */     return null;
/*     */   }
/*     */ 
/*     */   boolean isPinned() {
/* 215 */     File file = getFilesFile();
/* 216 */     return (file != null) && (file.exists());
/*     */   }
/*     */ 
/*     */   void pin() throws ParseException {
/* 220 */     setPinned(true);
/*     */   }
/*     */ 
/*     */   void unpin() throws ParseException {
/* 224 */     setPinned(false);
/*     */   }
/*     */ 
/*     */   Task<Void> pinInBackground() {
/* 228 */     return setPinnedInBackground(true);
/*     */   }
/*     */ 
/*     */   Task<Void> unpinInBackground() {
/* 232 */     return setPinnedInBackground(false);
/*     */   }
/*     */ 
/*     */   void pinInBackground(ParseCallback1<ParseException> callback) {
/* 236 */     setPinnedInBackground(true, callback);
/*     */   }
/*     */ 
/*     */   void unpinInBackground(ParseCallback1<ParseException> callback) {
/* 240 */     setPinnedInBackground(false, callback);
/*     */   }
/*     */ 
/*     */   private void setPinned(boolean pinned) throws ParseException {
/* 244 */     Parse.waitForTask(setPinnedInBackground(pinned));
/*     */   }
/*     */ 
/*     */   private void setPinnedInBackground(boolean pinned, ParseCallback1<ParseException> callback) {
/* 248 */     Parse.callbackOnMainThreadAsync(setPinnedInBackground(pinned), callback);
/*     */   }
/*     */ 
/*     */   private Task<Void> setPinnedInBackground(boolean pinned) {
/* 252 */     return this.taskQueue.enqueue(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<Void> task) throws Exception {
/* 255 */         return task;
/*     */       }
/*     */     }).continueWith(new Continuation(pinned)
/*     */     {
/*     */       public Void then(Task<Void> task)
/*     */         throws Exception
/*     */       {
/* 260 */         if (((this.val$pinned) && (ParseFile.this.isPinned())) || ((!this.val$pinned) && (!ParseFile.this.isPinned())))
/*     */         {
/* 262 */           return null;
/*     */         }
/*     */         File dest;
/*     */         File src;
/*     */         File dest;
/* 266 */         if (this.val$pinned) {
/* 267 */           File src = ParseFile.this.getCacheFile();
/* 268 */           dest = ParseFile.this.getFilesFile();
/*     */         } else {
/* 270 */           src = ParseFile.this.getFilesFile();
/* 271 */           dest = ParseFile.this.getCacheFile();
/*     */         }
/*     */ 
/* 274 */         if (dest == null) {
/* 275 */           throw new IllegalStateException("Unable to pin file before saving");
/*     */         }
/*     */ 
/* 278 */         if (dest.exists()) {
/* 279 */           ParseFileUtils.deleteQuietly(dest);
/*     */         }
/*     */ 
/* 282 */         if ((this.val$pinned) && (ParseFile.this.data != null)) {
/* 283 */           ParseFileUtils.writeByteArrayToFile(dest, ParseFile.this.data);
/* 284 */           if (src.exists()) {
/* 285 */             ParseFileUtils.deleteQuietly(src);
/*     */           }
/* 287 */           return null;
/*     */         }
/*     */ 
/* 290 */         if ((src == null) || (!src.exists())) {
/* 291 */           throw new IllegalStateException("Unable to pin file before retrieving");
/*     */         }
/*     */ 
/* 294 */         ParseFileUtils.moveFile(src, dest);
/* 295 */         return null;
/*     */       }
/*     */     }
/*     */     , Task.BACKGROUND_EXECUTOR);
/*     */   }
/*     */ 
/*     */   public void save()
/*     */     throws ParseException
/*     */   {
/* 304 */     Parse.waitForTask(saveInBackground());
/*     */   }
/*     */ 
/*     */   private Task<Void> saveAsync(String sessionToken, ProgressCallback uploadProgressCallback, Task<Void> toAwait, Task<Void>.TaskCompletionSource tcs)
/*     */   {
/* 311 */     if (!isDirty()) {
/* 312 */       return Task.forResult(null);
/*     */     }
/*     */ 
/* 316 */     toAwait.continueWith(new Continuation(tcs, sessionToken, uploadProgressCallback)
/*     */     {
/*     */       public Void then(Task<Void> task) throws Exception {
/* 319 */         if (!ParseFile.this.isDirty()) {
/* 320 */           this.val$tcs.trySetResult(null);
/* 321 */           return null;
/*     */         }
/*     */ 
/* 324 */         Task.forResult(null).continueWithTask(new Continuation()
/*     */         {
/*     */           public Task<JSONObject> then(Task<Void> task) throws Exception {
/* 327 */             String fileName = ParseFile.this.name != null ? ParseFile.this.name : "file";
/* 328 */             String mimeType = null;
/* 329 */             if (ParseFile.this.contentType != null) {
/* 330 */               mimeType = ParseFile.this.contentType;
/* 331 */             } else if (fileName.lastIndexOf(".") != -1) {
/* 332 */               String extension = fileName.substring(fileName.lastIndexOf(".") + 1);
/* 333 */               mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
/*     */             }
/* 335 */             if (mimeType == null) {
/* 336 */               mimeType = "application/octet-stream";
/*     */             }
/*     */ 
/* 339 */             ParseRESTCommand command = ParseRESTFileCommand.uploadFileCommand(fileName, ParseFile.this.data, mimeType, ParseFile.3.this.val$sessionToken);
/*     */ 
/* 341 */             command.enableRetrying();
/*     */ 
/* 344 */             ParseFile.3.this.val$tcs.getTask().continueWith(new Continuation(command)
/*     */             {
/*     */               public Void then(Task<Void> task) throws Exception {
/* 347 */                 if (task.isCancelled()) {
/* 348 */                   this.val$command.cancel();
/*     */                 }
/* 350 */                 return null;
/*     */               }
/*     */             });
/* 353 */             return command.executeAsync(ParseFile.3.this.val$uploadProgressCallback, null).cast();
/*     */           }
/*     */         }).onSuccessTask(new Continuation()
/*     */         {
/*     */           public Task<Void> then(Task<JSONObject> task)
/*     */             throws Exception
/*     */           {
/* 358 */             JSONObject result = (JSONObject)task.getResult();
/* 359 */             ParseFile.access$102(ParseFile.this, result.getString("name"));
/* 360 */             ParseFile.access$202(ParseFile.this, result.getString("url"));
/*     */             try
/*     */             {
/* 364 */               ParseFileUtils.writeByteArrayToFile(ParseFile.this.getCacheFile(), ParseFile.this.data);
/*     */             }
/*     */             catch (IOException e)
/*     */             {
/*     */             }
/* 369 */             ParseFile.access$302(ParseFile.this, false);
/*     */ 
/* 371 */             return task.makeVoid();
/*     */           }
/*     */         }).continueWith(new Continuation()
/*     */         {
/*     */           public Void then(Task<Void> task)
/*     */             throws Exception
/*     */           {
/* 376 */             ParseFile.this.currentTasks.remove(ParseFile.3.this.val$tcs);
/* 377 */             if (task.isCancelled())
/* 378 */               ParseFile.3.this.val$tcs.trySetCancelled();
/* 379 */             else if (task.isFaulted())
/* 380 */               ParseFile.3.this.val$tcs.trySetError(task.getError());
/*     */             else {
/* 382 */               ParseFile.3.this.val$tcs.trySetResult(task.getResult());
/*     */             }
/* 384 */             return null;
/*     */           }
/*     */         });
/* 387 */         return null;
/*     */       }
/*     */     });
/* 390 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public Task<Void> saveInBackground(ProgressCallback uploadProgressCallback)
/*     */   {
/* 402 */     Task.TaskCompletionSource tcs = Task.create();
/* 403 */     this.currentTasks.add(tcs);
/*     */ 
/* 405 */     return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation(uploadProgressCallback, tcs)
/*     */     {
/*     */       public Task<Void> then(Task<String> task) throws Exception {
/* 408 */         String sessionToken = (String)task.getResult();
/* 409 */         return ParseFile.this.saveAsync(sessionToken, this.val$uploadProgressCallback, this.val$tcs);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   Task<Void> saveAsync(String sessionToken, ProgressCallback uploadProgressCallback) {
/* 416 */     Task.TaskCompletionSource tcs = Task.create();
/* 417 */     this.currentTasks.add(tcs);
/*     */ 
/* 419 */     return saveAsync(sessionToken, uploadProgressCallback, tcs);
/*     */   }
/*     */ 
/*     */   private Task<Void> saveAsync(String sessionToken, ProgressCallback uploadProgressCallback, Task<Void>.TaskCompletionSource tcs)
/*     */   {
/* 424 */     return this.taskQueue.enqueue(new Continuation(sessionToken, uploadProgressCallback, tcs)
/*     */     {
/*     */       public Task<Void> then(Task<Void> task) throws Exception {
/* 427 */         return ParseFile.this.saveAsync(this.val$sessionToken, this.val$uploadProgressCallback, task, this.val$tcs);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public Task<Void> saveInBackground()
/*     */   {
/* 438 */     return saveInBackground((ProgressCallback)null);
/*     */   }
/*     */ 
/*     */   public void saveInBackground(SaveCallback saveCallback, ProgressCallback progressCallback)
/*     */   {
/* 452 */     Parse.callbackOnMainThreadAsync(saveInBackground(progressCallback), saveCallback);
/*     */   }
/*     */ 
/*     */   public void saveInBackground(SaveCallback callback)
/*     */   {
/* 462 */     Parse.callbackOnMainThreadAsync(saveInBackground(), callback);
/*     */   }
/*     */ 
/*     */   public byte[] getData()
/*     */     throws ParseException
/*     */   {
/* 470 */     return (byte[])Parse.waitForTask(getDataInBackground());
/*     */   }
/*     */ 
/*     */   private Task<byte[]> getDataAsync(ProgressCallback progressCallback, Task<Void> toAwait)
/*     */   {
/* 475 */     if (this.data != null)
/*     */     {
/* 477 */       return Task.forResult(this.data);
/*     */     }
/*     */ 
/* 480 */     Task.TaskCompletionSource tcs = Task.create();
/* 481 */     this.currentTasks.add(tcs);
/*     */ 
/* 486 */     toAwait.continueWith(new Continuation()
/*     */     {
/*     */       public byte[] then(Task<Void> task) throws Exception {
/* 489 */         return ParseFile.this.getCachedData();
/*     */       }
/*     */     }
/*     */     , Task.BACKGROUND_EXECUTOR).continueWith(new Continuation(tcs, progressCallback)
/*     */     {
/*     */       public Void then(Task<byte[]> task)
/*     */         throws Exception
/*     */       {
/* 494 */         byte[] result = (byte[])task.getResult();
/* 495 */         if (result != null)
/*     */         {
/* 497 */           this.val$tcs.trySetResult(result);
/* 498 */           return null;
/*     */         }
/*     */ 
/* 502 */         ParseAWSRequest request = new ParseAWSRequest(ParseFile.this.url);
/* 503 */         request.executeAsync(null, this.val$progressCallback).continueWithTask(new Continuation()
/*     */         {
/*     */           public Task<byte[]> then(Task<byte[]> task) throws Exception
/*     */           {
/* 507 */             if ((task.isFaulted()) && 
/* 508 */               ((task.getError() instanceof IllegalStateException))) {
/* 509 */               return Task.forError(new ParseException(100, task.getError().getMessage()));
/*     */             }
/*     */ 
/* 514 */             if (ParseFile.6.this.val$tcs.getTask().isCancelled()) {
/* 515 */               return ParseFile.6.this.val$tcs.getTask();
/*     */             }
/*     */ 
/* 518 */             ParseFile.this.data = ((byte[])task.getResult());
/* 519 */             if (ParseFile.this.data != null) {
/* 520 */               ParseFileUtils.writeByteArrayToFile(ParseFile.this.getCacheFile(), ParseFile.this.data);
/*     */             }
/*     */ 
/* 523 */             return task;
/*     */           }
/*     */         }).continueWith(new Continuation()
/*     */         {
/*     */           public Void then(Task<byte[]> task)
/*     */             throws Exception
/*     */           {
/* 529 */             ParseFile.this.currentTasks.remove(ParseFile.6.this.val$tcs);
/* 530 */             if (task.isCancelled())
/* 531 */               ParseFile.6.this.val$tcs.trySetCancelled();
/* 532 */             else if (task.isFaulted())
/* 533 */               ParseFile.6.this.val$tcs.trySetError(task.getError());
/*     */             else {
/* 535 */               ParseFile.6.this.val$tcs.trySetResult(task.getResult());
/*     */             }
/*     */ 
/* 538 */             return null;
/*     */           }
/*     */         });
/* 541 */         return null;
/*     */       }
/*     */     });
/* 545 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public Task<byte[]> getDataInBackground(ProgressCallback progressCallback)
/*     */   {
/* 557 */     return this.taskQueue.enqueue(new Continuation(progressCallback)
/*     */     {
/*     */       public Task<byte[]> then(Task<Void> task) throws Exception {
/* 560 */         return ParseFile.this.getDataAsync(this.val$progressCallback, task);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public Task<byte[]> getDataInBackground()
/*     */   {
/* 572 */     return getDataInBackground((ProgressCallback)null);
/*     */   }
/*     */ 
/*     */   public void getDataInBackground(GetDataCallback dataCallback, ProgressCallback progressCallback)
/*     */   {
/* 586 */     Parse.callbackOnMainThreadAsync(getDataInBackground(progressCallback), dataCallback);
/*     */   }
/*     */ 
/*     */   public void getDataInBackground(GetDataCallback dataCallback)
/*     */   {
/* 596 */     Parse.callbackOnMainThreadAsync(getDataInBackground(), dataCallback);
/*     */   }
/*     */ 
/*     */   public void cancel()
/*     */   {
/* 605 */     Set tasks = new HashSet(this.currentTasks);
/* 606 */     for (Task.TaskCompletionSource tcs : tasks) {
/* 607 */       tcs.trySetCancelled();
/*     */     }
/* 609 */     this.currentTasks.removeAll(tasks);
/*     */   }
/*     */ 
/*     */   ParseFile(JSONObject json, ParseDecoder decoder)
/*     */   {
/* 617 */     this(json.optString("name"), json.optString("url"));
/*     */   }
/*     */ 
/*     */   JSONObject encode() throws JSONException {
/* 621 */     JSONObject json = new JSONObject();
/* 622 */     json.put("__type", "File");
/* 623 */     json.put("name", getName());
/*     */ 
/* 625 */     String url = getUrl();
/* 626 */     if (url == null) {
/* 627 */       throw new IllegalStateException("Unable to encode an unsaved ParseFile.");
/*     */     }
/* 629 */     json.put("url", getUrl());
/*     */ 
/* 631 */     return json;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseFile
 * JD-Core Version:    0.6.0
 */