/*     */ package com.parse;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ @ParseClassName("_Role")
/*     */ public class ParseRole extends ParseObject
/*     */ {
/*  16 */   private static final Pattern NAME_PATTERN = Pattern.compile("^[0-9a-zA-Z_\\- ]+$");
/*     */ 
/*     */   ParseRole()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ParseRole(String name)
/*     */   {
/*  33 */     this();
/*  34 */     setName(name);
/*     */   }
/*     */ 
/*     */   public ParseRole(String name, ParseACL acl)
/*     */   {
/*  46 */     this(name);
/*  47 */     setACL(acl);
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  62 */     put("name", name);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  71 */     return getString("name");
/*     */   }
/*     */ 
/*     */   public ParseRelation<ParseUser> getUsers()
/*     */   {
/*  82 */     return getRelation("users");
/*     */   }
/*     */ 
/*     */   public ParseRelation<ParseRole> getRoles()
/*     */   {
/*  94 */     return getRelation("roles");
/*     */   }
/*     */ 
/*     */   void validateSave()
/*     */   {
/*  99 */     synchronized (this.mutex) {
/* 100 */       if ((getObjectId() == null) && (getName() == null)) {
/* 101 */         throw new IllegalStateException("New roles must specify a name.");
/*     */       }
/* 103 */       super.validateSave();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void put(String key, Object value)
/*     */   {
/* 109 */     if ("name".equals(key)) {
/* 110 */       if (getObjectId() != null) {
/* 111 */         throw new IllegalArgumentException("A role's name can only be set before it has been saved.");
/*     */       }
/*     */ 
/* 114 */       if (!(value instanceof String)) {
/* 115 */         throw new IllegalArgumentException("A role's name must be a String.");
/*     */       }
/* 117 */       if (!NAME_PATTERN.matcher((String)value).matches()) {
/* 118 */         throw new IllegalArgumentException("A role's name can only contain alphanumeric characters, _, -, and spaces.");
/*     */       }
/*     */     }
/*     */ 
/* 122 */     super.put(key, value);
/*     */   }
/*     */ 
/*     */   public static ParseQuery<ParseRole> getQuery()
/*     */   {
/* 131 */     return ParseQuery.getQuery(ParseRole.class);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRole
 * JD-Core Version:    0.6.0
 */