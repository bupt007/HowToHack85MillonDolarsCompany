/*     */ package com.parse.twitter;
/*     */ 
/*     */ import android.app.ProgressDialog;
/*     */ import android.content.Context;
/*     */ import android.net.Uri;
/*     */ import android.net.http.AndroidHttpClient;
/*     */ import android.os.AsyncTask;
/*     */ import android.webkit.CookieSyncManager;
/*     */ import com.parse.internal.AsyncCallback;
/*     */ import com.parse.oauth.OAuth1FlowDialog;
/*     */ import com.parse.oauth.OAuth1FlowDialog.FlowResultHandler;
/*     */ import com.parse.oauth.OAuth1FlowException;
/*     */ import com.parse.signpost.OAuthConsumer;
/*     */ import com.parse.signpost.OAuthProvider;
/*     */ import com.parse.signpost.commonshttp.CommonsHttpOAuthConsumer;
/*     */ import com.parse.signpost.commonshttp.CommonsHttpOAuthProvider;
/*     */ import com.parse.signpost.http.HttpParameters;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ 
/*     */ public class Twitter
/*     */ {
/*     */   private static final String USER_AGENT = "Parse Android SDK";
/*     */   private static final String REQUEST_TOKEN_URL = "https://api.twitter.com/oauth/request_token";
/*     */   private static final String AUTHORIZE_URL = "https://api.twitter.com/oauth/authenticate";
/*     */   private static final String ACCESS_TOKEN_URL = "https://api.twitter.com/oauth/access_token";
/*     */   private static final String VERIFIER_PARAM = "oauth_verifier";
/*     */   private static final String USER_ID_PARAM = "user_id";
/*     */   private static final String SCREEN_NAME_PARAM = "screen_name";
/*     */   private static final String CALLBACK_URL = "twitter-oauth://complete";
/*     */   private String consumerKey;
/*     */   private String consumerSecret;
/*     */   private String authToken;
/*     */   private String authTokenSecret;
/*     */   private String userId;
/*     */   private String screenName;
/*     */ 
/*     */   public Twitter(String consumerKey, String consumerSecret)
/*     */   {
/*  46 */     this.consumerKey = consumerKey;
/*  47 */     this.consumerSecret = consumerSecret;
/*     */   }
/*     */ 
/*     */   public String getConsumerKey() {
/*  51 */     return this.consumerKey;
/*     */   }
/*     */ 
/*     */   public Twitter setConsumerKey(String consumerKey) {
/*  55 */     this.consumerKey = consumerKey;
/*  56 */     return this;
/*     */   }
/*     */ 
/*     */   public String getConsumerSecret() {
/*  60 */     return this.consumerSecret;
/*     */   }
/*     */ 
/*     */   public Twitter setConsumerSecret(String consumerSecret) {
/*  64 */     this.consumerSecret = consumerSecret;
/*  65 */     return this;
/*     */   }
/*     */ 
/*     */   public String getAuthToken() {
/*  69 */     return this.authToken;
/*     */   }
/*     */ 
/*     */   public void setAuthToken(String authToken) {
/*  73 */     this.authToken = authToken;
/*     */   }
/*     */ 
/*     */   public String getAuthTokenSecret() {
/*  77 */     return this.authTokenSecret;
/*     */   }
/*     */ 
/*     */   public void setAuthTokenSecret(String authTokenSecret) {
/*  81 */     this.authTokenSecret = authTokenSecret;
/*     */   }
/*     */ 
/*     */   public String getUserId() {
/*  85 */     return this.userId;
/*     */   }
/*     */ 
/*     */   public void setUserId(String userId) {
/*  89 */     this.userId = userId;
/*     */   }
/*     */ 
/*     */   public String getScreenName() {
/*  93 */     return this.screenName;
/*     */   }
/*     */ 
/*     */   public void setScreenName(String screenName) {
/*  97 */     this.screenName = screenName;
/*     */   }
/*     */ 
/*     */   public void signRequest(HttpUriRequest request) {
/* 101 */     OAuthConsumer consumer = new CommonsHttpOAuthConsumer(getConsumerKey(), getConsumerSecret());
/* 102 */     consumer.setTokenWithSecret(getAuthToken(), getAuthTokenSecret());
/*     */     try {
/* 104 */       consumer.sign(request);
/*     */     } catch (Exception e) {
/* 106 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void authorize(Context context, AsyncCallback callback) {
/* 111 */     if ((getConsumerKey() == null) || (getConsumerKey().length() == 0) || (getConsumerSecret() == null) || (getConsumerSecret().length() == 0))
/*     */     {
/* 113 */       throw new IllegalStateException("Twitter must be initialized with a consumer key and secret before authorization.");
/*     */     }
/*     */ 
/* 117 */     OAuthProvider provider = new CommonsHttpOAuthProvider("https://api.twitter.com/oauth/request_token", "https://api.twitter.com/oauth/access_token", "https://api.twitter.com/oauth/authenticate", AndroidHttpClient.newInstance("Parse Android SDK", context));
/*     */ 
/* 123 */     OAuthConsumer consumer = new CommonsHttpOAuthConsumer(getConsumerKey(), getConsumerSecret());
/*     */ 
/* 126 */     ProgressDialog progress = new ProgressDialog(context);
/* 127 */     progress.setMessage("Loading...");
/* 128 */     AsyncTask task = new AsyncTask(callback, context, provider, consumer, progress) {
/*     */       private Throwable error;
/*     */ 
/*     */       protected void onPostExecute(String result) {
/* 133 */         super.onPostExecute(result);
/*     */         try {
/* 135 */           if (this.error != null) { this.val$callback.onFailure(this.error);
/*     */             return; }
/* 139 */           CookieSyncManager.createInstance(this.val$context);
/* 140 */           OAuth1FlowDialog dialog = new OAuth1FlowDialog(this.val$context, result, "twitter-oauth://complete", "api.twitter", new OAuth1FlowDialog.FlowResultHandler()
/*     */           {
/*     */             public void onError(int errorCode, String description, String failingUrl)
/*     */             {
/* 145 */               Twitter.1.this.val$callback.onFailure(new OAuth1FlowException(errorCode, description, failingUrl));
/*     */             }
/*     */ 
/*     */             public void onComplete(String callbackUrl)
/*     */             {
/* 150 */               CookieSyncManager.getInstance().sync();
/* 151 */               Uri uri = Uri.parse(callbackUrl);
/* 152 */               String verifier = uri.getQueryParameter("oauth_verifier");
/* 153 */               if (verifier == null) {
/* 154 */                 Twitter.1.this.val$callback.onCancel();
/* 155 */                 return;
/*     */               }
/* 157 */               AsyncTask getTokenTask = new AsyncTask(verifier) {
/*     */                 private Throwable error;
/*     */ 
/*     */                 protected HttpParameters doInBackground(Void[] params) {
/*     */                   try {
/* 163 */                     Twitter.1.this.val$provider.retrieveAccessToken(Twitter.1.this.val$consumer, this.val$verifier);
/*     */                   } catch (Throwable e) {
/* 165 */                     this.error = e;
/*     */                   }
/* 167 */                   return Twitter.1.this.val$provider.getResponseParameters();
/*     */                 }
/*     */ 
/*     */                 protected void onPreExecute()
/*     */                 {
/* 172 */                   super.onPreExecute();
/* 173 */                   Twitter.1.this.val$progress.show();
/*     */                 }
/*     */ 
/*     */                 protected void onPostExecute(HttpParameters result)
/*     */                 {
/* 178 */                   super.onPostExecute(result);
/*     */                   try {
/* 180 */                     if (this.error != null) { Twitter.1.this.val$callback.onFailure(this.error);
/*     */                       return; }
/*     */                     try {
/* 185 */                       Twitter.this.setAuthToken(Twitter.1.this.val$consumer.getToken());
/* 186 */                       Twitter.this.setAuthTokenSecret(Twitter.1.this.val$consumer.getTokenSecret());
/* 187 */                       Twitter.this.setScreenName(result.getFirst("screen_name"));
/* 188 */                       Twitter.this.setUserId(result.getFirst("user_id"));
/*     */                     } catch (Throwable e) {
/* 190 */                       Twitter.1.this.val$callback.onFailure(e);
/*     */ 
/* 195 */                       Twitter.1.this.val$progress.dismiss(); return;
/*     */                     }
/* 193 */                     Twitter.1.this.val$callback.onSuccess(Twitter.this);
/*     */                   } finally {
/* 195 */                     Twitter.1.this.val$progress.dismiss();
/*     */                   }
/*     */                 }
/*     */               };
/* 199 */               getTokenTask.execute(new Void[0]);
/*     */             }
/*     */ 
/*     */             public void onCancel()
/*     */             {
/* 204 */               Twitter.1.this.val$callback.onCancel();
/*     */             }
/*     */           });
/* 207 */           dialog.show();
/*     */         } finally {
/* 209 */           this.val$progress.dismiss();
/*     */         }
/*     */       }
/*     */ 
/*     */       protected void onPreExecute()
/*     */       {
/* 215 */         super.onPreExecute();
/* 216 */         this.val$progress.show();
/*     */       }
/*     */ 
/*     */       protected String doInBackground(Void[] params)
/*     */       {
/*     */         try {
/* 222 */           return this.val$provider.retrieveRequestToken(this.val$consumer, "twitter-oauth://complete");
/*     */         } catch (Throwable e) {
/* 224 */           this.error = e;
/*     */         }
/* 226 */         return null;
/*     */       }
/*     */     };
/* 229 */     task.execute(new Void[0]);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.twitter.Twitter
 * JD-Core Version:    0.6.0
 */