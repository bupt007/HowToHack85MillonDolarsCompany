package com.parse;

public abstract interface RefreshCallback extends ParseCallback2<ParseObject, ParseException>
{
  public abstract void done(ParseObject paramParseObject, ParseException paramParseException);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.RefreshCallback
 * JD-Core Version:    0.6.0
 */