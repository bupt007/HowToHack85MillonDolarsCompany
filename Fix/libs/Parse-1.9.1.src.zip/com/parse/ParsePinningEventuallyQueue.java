/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import bolts.Task.TaskCompletionSource;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class ParsePinningEventuallyQueue extends ParseEventuallyQueue
/*     */ {
/*     */   private static final String TAG = "ParsePinningEventuallyQueue";
/*  35 */   private HashMap<String, Task<Object>.TaskCompletionSource> pendingOperationSetUUIDTasks = new HashMap();
/*     */ 
/*  41 */   private TaskQueue taskQueue = new TaskQueue();
/*     */ 
/*  48 */   private TaskQueue operationSetTaskQueue = new TaskQueue();
/*     */ 
/*  54 */   private ArrayList<String> eventuallyPinUUIDQueue = new ArrayList();
/*     */ 
/*  62 */   private Task<Void>.TaskCompletionSource connectionTaskCompletionSource = Task.create();
/*  63 */   private final Object connectionLock = new Object();
/*     */   private ConnectivityNotifier notifier;
/*  66 */   private ConnectivityNotifier.ConnectivityListener listener = new ConnectivityNotifier.ConnectivityListener()
/*     */   {
/*     */     public void networkConnectivityStatusChanged(Context context, Intent intent) {
/*  69 */       boolean connectionLost = intent.getBooleanExtra("noConnectivity", false);
/*     */ 
/*  71 */       if (connectionLost)
/*  72 */         ParsePinningEventuallyQueue.this.setConnected(false);
/*     */       else
/*  74 */         ParsePinningEventuallyQueue.this.setConnected(ConnectivityNotifier.isConnected(context));
/*     */     }
/*  66 */   };
/*     */ 
/* 385 */   private final Object taskQueueSyncLock = new Object();
/*     */ 
/* 390 */   private HashMap<String, Task<Object>.TaskCompletionSource> pendingEventuallyTasks = new HashMap();
/*     */ 
/* 396 */   private HashMap<String, ParseOperationSet> uuidToOperationSet = new HashMap();
/*     */ 
/* 402 */   private HashMap<String, EventuallyPin> uuidToEventuallyPin = new HashMap();
/*     */ 
/*     */   public ParsePinningEventuallyQueue(Context context)
/*     */   {
/*  80 */     setConnected(ConnectivityNotifier.isConnected(context));
/*     */ 
/*  82 */     this.notifier = ConnectivityNotifier.getNotifier(context);
/*  83 */     this.notifier.addListener(this.listener);
/*     */ 
/*  85 */     resume();
/*     */   }
/*     */ 
/*     */   public void onDestroy()
/*     */   {
/*  92 */     this.notifier.removeListener(this.listener);
/*     */   }
/*     */ 
/*     */   public void setConnected(boolean connected)
/*     */   {
/*  97 */     synchronized (this.connectionLock) {
/*  98 */       if (isConnected() != connected) {
/*  99 */         super.setConnected(connected);
/* 100 */         if (connected) {
/* 101 */           this.connectionTaskCompletionSource.trySetResult(null);
/* 102 */           this.connectionTaskCompletionSource = Task.create();
/* 103 */           this.connectionTaskCompletionSource.trySetResult(null);
/*     */         } else {
/* 105 */           this.connectionTaskCompletionSource = Task.create();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int pendingCount()
/*     */   {
/*     */     try {
/* 114 */       return ((Integer)Parse.waitForTask(pendingCountAsync())).intValue(); } catch (ParseException e) {
/*     */     }
/* 116 */     throw new IllegalStateException(e);
/*     */   }
/*     */ 
/*     */   public Task<Integer> pendingCountAsync()
/*     */   {
/* 121 */     Task.TaskCompletionSource tcs = Task.create();
/*     */ 
/* 123 */     this.taskQueue.enqueue(new Continuation(tcs)
/*     */     {
/*     */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 126 */         return ParsePinningEventuallyQueue.this.pendingCountAsync(toAwait).continueWithTask(new Continuation()
/*     */         {
/*     */           public Task<Void> then(Task<Integer> task) throws Exception {
/* 129 */             int count = ((Integer)task.getResult()).intValue();
/* 130 */             ParsePinningEventuallyQueue.2.this.val$tcs.setResult(Integer.valueOf(count));
/* 131 */             return Task.forResult(null);
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/* 137 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public Task<Integer> pendingCountAsync(Task<Void> toAwait) {
/* 141 */     return toAwait.continueWithTask(new Continuation()
/*     */     {
/*     */       public Task<Integer> then(Task<Void> task) throws Exception {
/* 144 */         return EventuallyPin.findAllPinned().continueWithTask(new Continuation()
/*     */         {
/*     */           public Task<Integer> then(Task<List<EventuallyPin>> task) throws Exception {
/* 147 */             List pins = (List)task.getResult();
/* 148 */             return Task.forResult(Integer.valueOf(pins.size()));
/*     */           } } );
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void pause() {
/* 157 */     synchronized (this.connectionLock)
/*     */     {
/* 159 */       this.connectionTaskCompletionSource.trySetError(new PauseException(null));
/* 160 */       this.connectionTaskCompletionSource = Task.create();
/* 161 */       this.connectionTaskCompletionSource.trySetError(new PauseException(null));
/*     */     }
/*     */ 
/* 164 */     synchronized (this.taskQueueSyncLock) {
/* 165 */       for (String key : this.pendingEventuallyTasks.keySet())
/*     */       {
/* 167 */         ((Task.TaskCompletionSource)this.pendingEventuallyTasks.get(key)).trySetError(new PauseException(null));
/*     */       }
/* 169 */       this.pendingEventuallyTasks.clear();
/* 170 */       this.uuidToOperationSet.clear();
/* 171 */       this.uuidToEventuallyPin.clear();
/*     */     }
/*     */     try
/*     */     {
/* 175 */       Parse.waitForTask(whenAll(Arrays.asList(new TaskQueue[] { this.taskQueue, this.operationSetTaskQueue })));
/*     */     } catch (ParseException e) {
/* 177 */       throw new IllegalStateException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resume()
/*     */   {
/* 184 */     if (isConnected()) {
/* 185 */       this.connectionTaskCompletionSource.trySetResult(null);
/* 186 */       this.connectionTaskCompletionSource = Task.create();
/* 187 */       this.connectionTaskCompletionSource.trySetResult(null);
/*     */     } else {
/* 189 */       this.connectionTaskCompletionSource = Task.create();
/*     */     }
/*     */ 
/* 192 */     populateQueueAsync();
/*     */   }
/*     */ 
/*     */   private Task<Void> waitForConnectionAsync() {
/* 196 */     synchronized (this.connectionLock) {
/* 197 */       return this.connectionTaskCompletionSource.getTask();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Object> enqueueEventuallyAsync(ParseNetworkCommand command, ParseObject object)
/*     */   {
/* 209 */     Parse.requirePermission("android.permission.ACCESS_NETWORK_STATE");
/* 210 */     Task.TaskCompletionSource tcs = Task.create();
/*     */ 
/* 212 */     this.taskQueue.enqueue(new Continuation(command, object, tcs)
/*     */     {
/*     */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 215 */         return ParsePinningEventuallyQueue.this.enqueueEventuallyAsync(this.val$command, this.val$object, toAwait, this.val$tcs);
/*     */       }
/*     */     });
/* 219 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   private Task<Void> enqueueEventuallyAsync(ParseNetworkCommand command, ParseObject object, Task<Void> toAwait, Task<Object>.TaskCompletionSource tcs)
/*     */   {
/* 224 */     return toAwait.continueWithTask(new Continuation(object, command, tcs)
/*     */     {
/*     */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 227 */         Task pinTask = EventuallyPin.pinEventuallyCommand(this.val$object, this.val$command);
/*     */ 
/* 229 */         return pinTask.continueWithTask(new Continuation()
/*     */         {
/*     */           public Task<Void> then(Task<EventuallyPin> task) throws Exception {
/* 232 */             EventuallyPin pin = (EventuallyPin)task.getResult();
/* 233 */             Exception error = task.getError();
/* 234 */             if (error != null) {
/* 235 */               if (5 >= Parse.getLogLevel()) {
/* 236 */                 Parse.logW("ParsePinningEventuallyQueue", "Unable to save command for later.", error);
/*     */               }
/* 238 */               ParsePinningEventuallyQueue.this.notifyTestHelper(4);
/* 239 */               return Task.forResult(null);
/*     */             }
/*     */ 
/* 242 */             ParsePinningEventuallyQueue.this.pendingOperationSetUUIDTasks.put(pin.getUUID(), ParsePinningEventuallyQueue.5.this.val$tcs);
/*     */ 
/* 245 */             ParsePinningEventuallyQueue.this.populateQueueAsync().continueWithTask(new Continuation()
/*     */             {
/*     */               public Task<Void> then(Task<Void> task)
/*     */                 throws Exception
/*     */               {
/* 252 */                 ParsePinningEventuallyQueue.this.notifyTestHelper(3);
/* 253 */                 return task;
/*     */               }
/*     */             });
/* 257 */             return task.makeVoid();
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private Task<Void> populateQueueAsync()
/*     */   {
/* 271 */     return this.taskQueue.enqueue(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 274 */         return ParsePinningEventuallyQueue.this.populateQueueAsync(toAwait);
/*     */       } } );
/*     */   }
/*     */ 
/*     */   private Task<Void> populateQueueAsync(Task<Void> toAwait) {
/* 280 */     return toAwait.continueWithTask(new Continuation()
/*     */     {
/*     */       public Task<List<EventuallyPin>> then(Task<Void> task) throws Exception
/*     */       {
/* 284 */         return EventuallyPin.findAllPinned(ParsePinningEventuallyQueue.this.eventuallyPinUUIDQueue);
/*     */       }
/*     */     }).onSuccessTask(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<List<EventuallyPin>> task)
/*     */         throws Exception
/*     */       {
/* 289 */         List pins = (List)task.getResult();
/*     */ 
/* 291 */         for (EventuallyPin pin : pins)
/*     */         {
/* 293 */           ParsePinningEventuallyQueue.this.runEventuallyAsync(pin);
/*     */         }
/*     */ 
/* 296 */         return task.makeVoid();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private Task<Void> runEventuallyAsync(EventuallyPin eventuallyPin)
/*     */   {
/* 308 */     String uuid = eventuallyPin.getUUID();
/* 309 */     if (this.eventuallyPinUUIDQueue.contains(uuid))
/*     */     {
/* 311 */       return Task.forResult(null);
/*     */     }
/* 313 */     this.eventuallyPinUUIDQueue.add(uuid);
/*     */ 
/* 315 */     this.operationSetTaskQueue.enqueue(new Continuation(eventuallyPin, uuid)
/*     */     {
/*     */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 318 */         return ParsePinningEventuallyQueue.this.runEventuallyAsync(this.val$eventuallyPin, toAwait).continueWithTask(new Continuation()
/*     */         {
/*     */           public Task<Void> then(Task<Void> task) throws Exception {
/* 321 */             ParsePinningEventuallyQueue.this.eventuallyPinUUIDQueue.remove(ParsePinningEventuallyQueue.9.this.val$uuid);
/* 322 */             return task;
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/* 328 */     return Task.forResult(null);
/*     */   }
/*     */ 
/*     */   private Task<Void> runEventuallyAsync(EventuallyPin eventuallyPin, Task<Void> toAwait)
/*     */   {
/* 338 */     return toAwait.continueWithTask(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<Void> task) throws Exception {
/* 341 */         return ParsePinningEventuallyQueue.this.waitForConnectionAsync();
/*     */       }
/*     */     }).onSuccessTask(new Continuation(eventuallyPin)
/*     */     {
/*     */       public Task<Void> then(Task<Void> task)
/*     */         throws Exception
/*     */       {
/* 346 */         return ParsePinningEventuallyQueue.this.waitForOperationSetAndEventuallyPin(null, this.val$eventuallyPin).continueWithTask(new Continuation()
/*     */         {
/*     */           public Task<Void> then(Task<Object> task) throws Exception
/*     */           {
/* 350 */             Exception error = task.getError();
/* 351 */             if (error != null) {
/* 352 */               if ((error instanceof ParsePinningEventuallyQueue.PauseException))
/*     */               {
/* 354 */                 return task.makeVoid();
/*     */               }
/*     */ 
/* 357 */               if (6 >= Parse.getLogLevel()) {
/* 358 */                 Parse.logE("ParsePinningEventuallyQueue", "Failed to run command.", error);
/*     */               }
/*     */ 
/* 361 */               ParsePinningEventuallyQueue.this.notifyTestHelper(2, error);
/*     */             } else {
/* 363 */               ParsePinningEventuallyQueue.this.notifyTestHelper(1);
/*     */             }
/*     */ 
/* 366 */             Task.TaskCompletionSource tcs = (Task.TaskCompletionSource)ParsePinningEventuallyQueue.this.pendingOperationSetUUIDTasks.remove(ParsePinningEventuallyQueue.10.this.val$eventuallyPin.getUUID());
/*     */ 
/* 368 */             if (tcs != null) {
/* 369 */               if (error != null)
/* 370 */                 tcs.setError(error);
/*     */               else {
/* 372 */                 tcs.setResult(task.getResult());
/*     */               }
/*     */             }
/* 375 */             return task.makeVoid();
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   Task<Object> waitForOperationSetAndEventuallyPin(ParseOperationSet operationSet, EventuallyPin eventuallyPin)
/*     */   {
/* 419 */     if ((eventuallyPin != null) && (eventuallyPin.getType() != 1))
/* 420 */       return process(eventuallyPin, null);
/*     */     String uuid;
/*     */     Task.TaskCompletionSource tcs;
/* 426 */     synchronized (this.taskQueueSyncLock) {
/* 427 */       if ((operationSet != null) && (eventuallyPin == null)) {
/* 428 */         String uuid = operationSet.getUUID();
/* 429 */         this.uuidToOperationSet.put(uuid, operationSet);
/* 430 */       } else if ((operationSet == null) && (eventuallyPin != null)) {
/* 431 */         String uuid = eventuallyPin.getOperationSetUUID();
/* 432 */         this.uuidToEventuallyPin.put(uuid, eventuallyPin);
/*     */       } else {
/* 434 */         throw new IllegalStateException("Either operationSet or eventuallyPin must be set.");
/*     */       }
/*     */ 
/* 437 */       eventuallyPin = (EventuallyPin)this.uuidToEventuallyPin.get(uuid);
/* 438 */       operationSet = (ParseOperationSet)this.uuidToOperationSet.get(uuid);
/*     */ 
/* 440 */       if ((eventuallyPin == null) || (operationSet == null))
/*     */       {
/*     */         Task.TaskCompletionSource tcs;
/*     */         Task.TaskCompletionSource tcs;
/* 441 */         if (this.pendingEventuallyTasks.containsKey(uuid)) {
/* 442 */           tcs = (Task.TaskCompletionSource)this.pendingEventuallyTasks.get(uuid);
/*     */         } else {
/* 444 */           tcs = Task.create();
/* 445 */           this.pendingEventuallyTasks.put(uuid, tcs);
/*     */         }
/* 447 */         return tcs.getTask();
/*     */       }
/* 449 */       tcs = (Task.TaskCompletionSource)this.pendingEventuallyTasks.get(uuid);
/*     */     }
/*     */ 
/* 453 */     return process(eventuallyPin, operationSet).continueWithTask(new Object(uuid, tcs)
/*     */     {
/*     */       public Task<Object> then(Task<Object> task) throws Exception
/*     */       {
/* 457 */         synchronized (ParsePinningEventuallyQueue.this.taskQueueSyncLock) {
/* 458 */           ParsePinningEventuallyQueue.this.pendingEventuallyTasks.remove(this.val$uuid);
/* 459 */           ParsePinningEventuallyQueue.this.uuidToOperationSet.remove(this.val$uuid);
/* 460 */           ParsePinningEventuallyQueue.this.uuidToEventuallyPin.remove(this.val$uuid);
/*     */         }
/*     */ 
/* 463 */         Exception error = task.getError();
/* 464 */         if (error != null)
/* 465 */           this.val$tcs.trySetError(error);
/* 466 */         else if (task.isCancelled())
/* 467 */           this.val$tcs.trySetCancelled();
/*     */         else {
/* 469 */           this.val$tcs.trySetResult(task.getResult());
/*     */         }
/* 471 */         return this.val$tcs.getTask();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private Task<Object> process(EventuallyPin eventuallyPin, ParseOperationSet operationSet)
/*     */   {
/* 482 */     return waitForConnectionAsync().onSuccessTask(new Continuation(eventuallyPin, operationSet)
/*     */     {
/*     */       public Task<Object> then(Task<Void> task) throws Exception {
/* 485 */         int type = this.val$eventuallyPin.getType();
/* 486 */         ParseObject object = this.val$eventuallyPin.getObject();
/* 487 */         String sessionToken = this.val$eventuallyPin.getSessionToken();
/*     */         Task executeTask;
/*     */         Task executeTask;
/* 490 */         if (type == 1) {
/* 491 */           executeTask = object.saveAsync(this.val$operationSet, sessionToken);
/*     */         }
/*     */         else
/*     */         {
/*     */           Task executeTask;
/* 492 */           if (type == 2) {
/* 493 */             executeTask = object.deleteAsync(sessionToken);
/*     */           } else {
/* 495 */             ParseNetworkCommand command = this.val$eventuallyPin.getCommand();
/* 496 */             executeTask = command.executeAsync();
/*     */           }
/*     */         }
/* 499 */         return executeTask.continueWithTask(new Continuation(type, object)
/*     */         {
/*     */           public Task<Object> then(Task<Object> saveTask) throws Exception {
/* 502 */             Exception error = saveTask.getError();
/* 503 */             if ((error != null) && 
/* 504 */               ((error instanceof ParseException)) && (((ParseException)error).getCode() == 100))
/*     */             {
/* 508 */               ParsePinningEventuallyQueue.this.setConnected(false);
/*     */ 
/* 510 */               ParsePinningEventuallyQueue.this.notifyTestHelper(7);
/*     */ 
/* 512 */               return ParsePinningEventuallyQueue.this.process(ParsePinningEventuallyQueue.13.this.val$eventuallyPin, ParsePinningEventuallyQueue.13.this.val$operationSet);
/*     */             }
/*     */ 
/* 520 */             return ParsePinningEventuallyQueue.13.this.val$eventuallyPin.unpinInBackground("_eventuallyPin").continueWithTask(new Object(saveTask)
/*     */             {
/*     */               public Task<Void> then(Task<Void> task) throws Exception
/*     */               {
/* 524 */                 Object result = this.val$saveTask.getResult();
/* 525 */                 if (ParsePinningEventuallyQueue.13.1.this.val$type == 1)
/* 526 */                   return ParsePinningEventuallyQueue.13.1.this.val$object.handleSaveEventuallyResultAsync((JSONObject)result, ParsePinningEventuallyQueue.13.this.val$operationSet);
/* 527 */                 if (ParsePinningEventuallyQueue.13.1.this.val$type == 2) {
/* 528 */                   return ParsePinningEventuallyQueue.13.1.this.val$object.handleDeleteEventuallyResultAsync(result);
/*     */                 }
/* 530 */                 return task;
/*     */               }
/*     */             }).continueWithTask(new Continuation(saveTask)
/*     */             {
/*     */               public Task<Object> then(Task<Void> task)
/*     */                 throws Exception
/*     */               {
/* 536 */                 return this.val$saveTask;
/*     */               } } );
/*     */           } } );
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   void simulateReboot() {
/* 547 */     pause();
/*     */ 
/* 549 */     this.pendingOperationSetUUIDTasks.clear();
/* 550 */     this.pendingEventuallyTasks.clear();
/* 551 */     this.uuidToOperationSet.clear();
/* 552 */     this.uuidToEventuallyPin.clear();
/*     */ 
/* 554 */     resume();
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 559 */     pause();
/*     */ 
/* 561 */     Task task = this.taskQueue.enqueue(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 564 */         return toAwait.continueWithTask(new Continuation()
/*     */         {
/*     */           public Task<Void> then(Task<Void> task) throws Exception {
/* 567 */             return EventuallyPin.findAllPinned().onSuccessTask(new Continuation()
/*     */             {
/*     */               public Task<Void> then(Task<List<EventuallyPin>> task) throws Exception {
/* 570 */                 List pins = (List)task.getResult();
/*     */ 
/* 572 */                 List tasks = new ArrayList();
/* 573 */                 for (EventuallyPin pin : pins) {
/* 574 */                   tasks.add(pin.unpinInBackground("_eventuallyPin"));
/*     */                 }
/* 576 */                 return Task.whenAll(tasks);
/*     */               } } );
/*     */           } } );
/*     */       }
/*     */     });
/*     */     try {
/* 585 */       Parse.waitForTask(task);
/*     */     } catch (ParseException e) {
/* 587 */       throw new IllegalStateException(e);
/*     */     }
/*     */ 
/* 590 */     simulateReboot();
/*     */ 
/* 592 */     resume();
/*     */   }
/*     */ 
/*     */   private Task<Void> whenAll(Collection<TaskQueue> taskQueues)
/*     */   {
/* 603 */     List tasks = new ArrayList();
/*     */ 
/* 605 */     for (TaskQueue taskQueue : taskQueues) {
/* 606 */       Task task = taskQueue.enqueue(new Continuation()
/*     */       {
/*     */         public Task<Void> then(Task<Void> toAwait) throws Exception {
/* 609 */           return toAwait;
/*     */         }
/*     */       });
/* 613 */       tasks.add(task);
/*     */     }
/*     */ 
/* 616 */     return Task.whenAll(tasks);
/*     */   }
/*     */ 
/*     */   private static class PauseException extends Exception
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParsePinningEventuallyQueue
 * JD-Core Version:    0.6.0
 */