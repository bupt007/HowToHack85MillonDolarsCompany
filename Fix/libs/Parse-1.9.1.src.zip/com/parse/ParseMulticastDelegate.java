/*    */ package com.parse;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ class ParseMulticastDelegate<T>
/*    */ {
/*    */   private final List<ParseCallback2<T, ParseException>> callbacks;
/*    */ 
/*    */   public ParseMulticastDelegate()
/*    */   {
/* 11 */     this.callbacks = new LinkedList();
/*    */   }
/*    */ 
/*    */   public void subscribe(ParseCallback2<T, ParseException> callback) {
/* 15 */     this.callbacks.add(callback);
/*    */   }
/*    */ 
/*    */   public void unsubscribe(ParseCallback2<T, ParseException> callback) {
/* 19 */     this.callbacks.remove(callback);
/*    */   }
/*    */ 
/*    */   public void invoke(T result, ParseException exception) {
/* 23 */     for (ParseCallback2 callback : new ArrayList(this.callbacks))
/* 24 */       callback.done(result, exception);
/*    */   }
/*    */ 
/*    */   public void clear()
/*    */   {
/* 29 */     this.callbacks.clear();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseMulticastDelegate
 * JD-Core Version:    0.6.0
 */