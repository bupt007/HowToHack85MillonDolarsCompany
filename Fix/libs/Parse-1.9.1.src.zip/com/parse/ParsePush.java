/*     */ package com.parse;
/*     */ 
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import com.parse.gdata.Preconditions;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class ParsePush
/*     */ {
/*     */   private static final String TAG = "com.parse.ParsePush";
/*  26 */   private Set<String> channelSet = null;
/*  27 */   private ParseQuery<ParseInstallation> query = null;
/*  28 */   private Long expirationTime = null;
/*  29 */   private Long expirationTimeInterval = null;
/*  30 */   private Boolean pushToIOS = null;
/*  31 */   private Boolean pushToAndroid = null;
/*     */   private JSONObject data;
/*     */   static final String V2_PUSH_NOT_CONFIGURED = "In order to use the ParsePush.subscribe or ParsePush.unsubscribe methods you must add the following to your AndroidManifest.xml: \n<receiver android:name=\"com.parse.ParsePushBroadcastReceiver\"\n  android:exported=\"false\">\n  <intent-filter>\n    <action android:name=\"com.parse.push.intent.RECEIVE\" />\n    <action android:name=\"com.parse.push.intent.OPEN\" />\n    <action android:name=\"com.parse.push.intent.DELETE\" />\n  </intent-filter>\n</receiver>\n(Replace \"com.parse.ParsePushBroadcastReceiver\" with your own implementation if you choose to extend ParsePushBroadcastReceiver)";
/*     */ 
/*     */   static void setEnabled(boolean enabled)
/*     */   {
/*  51 */     checkForManifestAndThrowExceptionIfNeeded();
/*  52 */     PushRouter.setForceEnabledAsync(Boolean.valueOf(enabled)).onSuccess(new Continuation(enabled)
/*     */     {
/*     */       public Void then(Task<Void> task) throws Exception {
/*  55 */         if (!this.val$enabled)
/*  56 */           PushService.stopPpnsService(Parse.applicationContext);
/*     */         else {
/*  58 */           PushService.startServiceIfRequired(Parse.applicationContext);
/*     */         }
/*  60 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static Task<Void> subscribeInBackground(String channel)
/*     */   {
/*  74 */     if (channel == null) {
/*  75 */       throw new IllegalArgumentException("Can't subscribe to null channel.");
/*     */     }
/*  77 */     checkForManifestAndThrowExceptionIfNeeded();
/*  78 */     ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/*  79 */     List channels = installation.getList("channels");
/*  80 */     if ((channels == null) || (installation.isDirty("channels")) || (!channels.contains(channel))) {
/*  81 */       installation.addUnique("channels", channel);
/*  82 */       return installation.saveInBackground();
/*     */     }
/*  84 */     return Task.forResult(null);
/*     */   }
/*     */ 
/*     */   public static void subscribeInBackground(String channel, SaveCallback callback)
/*     */   {
/*  98 */     Parse.callbackOnMainThreadAsync(subscribeInBackground(channel), callback);
/*     */   }
/*     */ 
/*     */   public static Task<Void> unsubscribeInBackground(String channel)
/*     */   {
/* 110 */     if (channel == null) {
/* 111 */       throw new IllegalArgumentException("Can't unsubscribe from null channel.");
/*     */     }
/* 113 */     checkForManifestAndThrowExceptionIfNeeded();
/* 114 */     ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/* 115 */     List channels = installation.getList("channels");
/* 116 */     if ((channels != null) && (channels.contains(channel))) {
/* 117 */       installation.removeAll("channels", Arrays.asList(new String[] { channel }));
/* 118 */       return installation.saveInBackground();
/*     */     }
/* 120 */     return Task.forResult(null);
/*     */   }
/*     */ 
/*     */   public static void unsubscribeInBackground(String channel, SaveCallback callback)
/*     */   {
/* 133 */     Parse.callbackOnMainThreadAsync(unsubscribeInBackground(channel), callback);
/*     */   }
/*     */ 
/*     */   private static void checkForManifestAndThrowExceptionIfNeeded()
/*     */   {
/* 150 */     if (!ManifestInfo.getPushUsesBroadcastReceivers())
/* 151 */       throw new IllegalStateException("In order to use the ParsePush.subscribe or ParsePush.unsubscribe methods you must add the following to your AndroidManifest.xml: \n<receiver android:name=\"com.parse.ParsePushBroadcastReceiver\"\n  android:exported=\"false\">\n  <intent-filter>\n    <action android:name=\"com.parse.push.intent.RECEIVE\" />\n    <action android:name=\"com.parse.push.intent.OPEN\" />\n    <action android:name=\"com.parse.push.intent.DELETE\" />\n  </intent-filter>\n</receiver>\n(Replace \"com.parse.ParsePushBroadcastReceiver\" with your own implementation if you choose to extend ParsePushBroadcastReceiver)");
/*     */   }
/*     */ 
/*     */   public static Task<Void> sendMessageInBackground(String message, ParseQuery<ParseInstallation> query)
/*     */   {
/* 167 */     ParsePush push = new ParsePush();
/* 168 */     push.setQuery(query);
/* 169 */     push.setMessage(message);
/* 170 */     return push.sendInBackground();
/*     */   }
/*     */ 
/*     */   public static void sendMessageInBackground(String message, ParseQuery<ParseInstallation> query, SendCallback callback)
/*     */   {
/* 187 */     Parse.callbackOnMainThreadAsync(sendMessageInBackground(message, query), callback);
/*     */   }
/*     */ 
/*     */   public static Task<Void> sendDataInBackground(JSONObject data, ParseQuery<ParseInstallation> query)
/*     */   {
/* 202 */     ParsePush push = new ParsePush();
/* 203 */     push.setQuery(query);
/* 204 */     push.setData(data);
/* 205 */     return push.sendInBackground();
/*     */   }
/*     */ 
/*     */   public static void sendDataInBackground(JSONObject data, ParseQuery<ParseInstallation> query, SendCallback callback)
/*     */   {
/* 223 */     Parse.callbackOnMainThreadAsync(sendDataInBackground(data, query), callback);
/*     */   }
/*     */ 
/*     */   public void setChannel(String channel)
/*     */   {
/* 232 */     Preconditions.checkArgument(channel != null, "channel cannot be null");
/* 233 */     this.channelSet = new HashSet();
/* 234 */     this.channelSet.add(channel);
/* 235 */     this.query = null;
/*     */   }
/*     */ 
/*     */   public void setChannels(Collection<String> channels)
/*     */   {
/* 244 */     Preconditions.checkArgument(channels != null, "channels collection cannot be null");
/* 245 */     for (String channel : channels) {
/* 246 */       Preconditions.checkArgument(channel != null, "channel cannot be null");
/*     */     }
/* 248 */     this.channelSet = new HashSet();
/* 249 */     this.channelSet.addAll(channels);
/* 250 */     this.query = null;
/*     */   }
/*     */ 
/*     */   public void setQuery(ParseQuery<ParseInstallation> query)
/*     */   {
/* 262 */     Preconditions.checkArgument(query != null, "Cannot target a null query");
/* 263 */     Preconditions.checkArgument((this.pushToIOS == null) && (this.pushToAndroid == null), "Cannot set push targets (i.e. setPushToAndroid or setPushToIOS) when pushing to a query");
/*     */ 
/* 265 */     Preconditions.checkArgument(query.getClassName().equals(ParseObject.getClassName(ParseInstallation.class)), "Can only push to a query for Installations");
/*     */ 
/* 267 */     this.channelSet = null;
/* 268 */     this.query = query;
/*     */   }
/*     */ 
/*     */   public void setExpirationTime(long time)
/*     */   {
/* 279 */     this.expirationTime = Long.valueOf(time);
/* 280 */     this.expirationTimeInterval = null;
/*     */   }
/*     */ 
/*     */   public void setExpirationTimeInterval(long timeInterval)
/*     */   {
/* 291 */     this.expirationTime = null;
/* 292 */     this.expirationTimeInterval = Long.valueOf(timeInterval);
/*     */   }
/*     */ 
/*     */   public void clearExpiration()
/*     */   {
/* 299 */     this.expirationTime = null;
/* 300 */     this.expirationTimeInterval = null;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setPushToIOS(boolean pushToIOS)
/*     */   {
/* 314 */     Preconditions.checkArgument(this.query == null, "Cannot set push targets (i.e. setPushToAndroid or setPushToIOS) when pushing to a query");
/*     */ 
/* 316 */     this.pushToIOS = Boolean.valueOf(pushToIOS);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setPushToAndroid(boolean pushToAndroid)
/*     */   {
/* 330 */     Preconditions.checkArgument(this.query == null, "Cannot set push targets (i.e. setPushToAndroid or setPushToIOS) when pushing to a query");
/*     */ 
/* 332 */     this.pushToAndroid = Boolean.valueOf(pushToAndroid);
/*     */   }
/*     */ 
/*     */   public void setData(JSONObject data)
/*     */   {
/* 340 */     this.data = data;
/*     */   }
/*     */ 
/*     */   public void setMessage(String message)
/*     */   {
/* 348 */     JSONObject data = new JSONObject();
/*     */     try {
/* 350 */       data.put("alert", message);
/*     */     } catch (JSONException e) {
/* 352 */       Parse.logE("com.parse.ParsePush", "JSONException in setMessage", e);
/*     */     }
/* 354 */     setData(data);
/*     */   }
/*     */ 
/*     */   public Task<Void> sendInBackground()
/*     */   {
/* 364 */     return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<String> task) throws Exception {
/* 367 */         String sessionToken = (String)task.getResult();
/* 368 */         return ParsePush.this.currentSendCommand(sessionToken).executeAsync().makeVoid();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void send()
/*     */     throws ParseException
/*     */   {
/* 382 */     Parse.waitForTask(sendInBackground());
/*     */   }
/*     */ 
/*     */   public void sendInBackground(SendCallback callback)
/*     */   {
/* 393 */     Parse.callbackOnMainThreadAsync(sendInBackground(), callback);
/*     */   }
/*     */ 
/*     */   ParseRESTCommand currentSendCommand(String sessionToken)
/*     */   {
/* 400 */     if (this.data == null) {
/* 401 */       throw new IllegalArgumentException("Cannot send a push without calling either setMessage or setData");
/*     */     }
/*     */ 
/* 405 */     String deviceType = null;
/* 406 */     if (this.query == null)
/*     */     {
/* 408 */       boolean willPushToAndroid = (this.pushToAndroid == null) || (this.pushToAndroid.booleanValue());
/* 409 */       boolean willPushToIOS = (this.pushToIOS != null) && (this.pushToIOS.booleanValue());
/* 410 */       if ((!willPushToIOS) || (!willPushToAndroid))
/*     */       {
/* 412 */         if (willPushToIOS)
/* 413 */           deviceType = "ios";
/* 414 */         else if (willPushToAndroid)
/* 415 */           deviceType = "android";
/*     */         else {
/* 417 */           throw new IllegalArgumentException("Cannot push if both pushToIOS and pushToAndroid are false");
/*     */         }
/*     */       }
/*     */     }
/* 421 */     return ParseRESTPushCommand.sendPushCommand(this.query, this.channelSet, deviceType, this.expirationTime, this.expirationTimeInterval, this.data, sessionToken);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParsePush
 * JD-Core Version:    0.6.0
 */