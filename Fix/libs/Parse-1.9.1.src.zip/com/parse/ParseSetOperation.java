/*    */ package com.parse;
/*    */ 
/*    */ class ParseSetOperation
/*    */   implements ParseFieldOperation
/*    */ {
/*    */   private Object value;
/*    */ 
/*    */   public ParseSetOperation(Object newValue)
/*    */   {
/* 10 */     this.value = newValue;
/*    */   }
/*    */ 
/*    */   public Object getValue() {
/* 14 */     return this.value;
/*    */   }
/*    */ 
/*    */   public Object encode(ParseObjectEncodingStrategy objectEncoder)
/*    */   {
/* 19 */     return Parse.encode(this.value, objectEncoder);
/*    */   }
/*    */ 
/*    */   public ParseFieldOperation mergeWithPrevious(ParseFieldOperation previous)
/*    */   {
/* 24 */     return this;
/*    */   }
/*    */ 
/*    */   public Object apply(Object oldValue, ParseObject object, String key)
/*    */   {
/* 29 */     return this.value;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseSetOperation
 * JD-Core Version:    0.6.0
 */