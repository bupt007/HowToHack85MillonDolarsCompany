/*    */ package com.parse;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.http.HttpResponse;
/*    */ 
/*    */ abstract class ParseHttpResponse
/*    */ {
/*    */   public abstract int getStatusCode();
/*    */ 
/*    */   public abstract InputStream getContent()
/*    */     throws IOException;
/*    */ 
/*    */   public abstract int getTotalSize();
/*    */ 
/*    */   public abstract String getReasonPhrase();
/*    */ 
/*    */   public static ParseHttpResponse createParseApacheHttpResponse(HttpResponse response)
/*    */   {
/* 22 */     return new ParseApacheHttpResponse(response);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseHttpResponse
 * JD-Core Version:    0.6.0
 */