package com.parse.internal;

public abstract interface AsyncCallback
{
  public abstract void onSuccess(Object paramObject);

  public abstract void onCancel();

  public abstract void onFailure(Throwable paramThrowable);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.internal.AsyncCallback
 * JD-Core Version:    0.6.0
 */