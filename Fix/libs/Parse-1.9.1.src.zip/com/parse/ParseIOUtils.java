/*     */ package com.parse;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ class ParseIOUtils
/*     */ {
/*     */   private static final int EOF = -1;
/*     */   private static final int DEFAULT_BUFFER_SIZE = 4096;
/*     */   private static final int SKIP_BUFFER_SIZE = 2048;
/*     */   private static byte[] SKIP_BYTE_BUFFER;
/*     */ 
/*     */   public static byte[] toByteArray(InputStream input)
/*     */     throws IOException
/*     */   {
/*  54 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/*  55 */     copy(input, output);
/*  56 */     return output.toByteArray();
/*     */   }
/*     */ 
/*     */   public static int copy(InputStream input, OutputStream output)
/*     */     throws IOException
/*     */   {
/*  81 */     long count = copyLarge(input, output);
/*  82 */     if (count > 2147483647L) {
/*  83 */       return -1;
/*     */     }
/*  85 */     return (int)count;
/*     */   }
/*     */ 
/*     */   public static long copyLarge(InputStream input, OutputStream output)
/*     */     throws IOException
/*     */   {
/* 106 */     return copyLarge(input, output, new byte[4096]);
/*     */   }
/*     */ 
/*     */   public static long copyLarge(InputStream input, OutputStream output, byte[] buffer)
/*     */     throws IOException
/*     */   {
/* 127 */     long count = 0L;
/* 128 */     int n = 0;
/* 129 */     while (-1 != (n = input.read(buffer))) {
/* 130 */       output.write(buffer, 0, n);
/* 131 */       count += n;
/*     */     }
/* 133 */     return count;
/*     */   }
/*     */ 
/*     */   public static long copyLarge(InputStream input, OutputStream output, long inputOffset, long length)
/*     */     throws IOException
/*     */   {
/* 157 */     return copyLarge(input, output, inputOffset, length, new byte[4096]);
/*     */   }
/*     */ 
/*     */   public static long skip(InputStream input, long toSkip)
/*     */     throws IOException
/*     */   {
/* 177 */     if (toSkip < 0L) {
/* 178 */       throw new IllegalArgumentException("Skip count must be non-negative, actual: " + toSkip);
/*     */     }
/*     */ 
/* 185 */     if (SKIP_BYTE_BUFFER == null) {
/* 186 */       SKIP_BYTE_BUFFER = new byte[2048];
/*     */     }
/* 188 */     long remain = toSkip;
/* 189 */     while (remain > 0L) {
/* 190 */       long n = input.read(SKIP_BYTE_BUFFER, 0, (int)Math.min(remain, 2048L));
/* 191 */       if (n < 0L) {
/*     */         break;
/*     */       }
/* 194 */       remain -= n;
/*     */     }
/* 196 */     return toSkip - remain;
/*     */   }
/*     */ 
/*     */   public static long copyLarge(InputStream input, OutputStream output, long inputOffset, long length, byte[] buffer)
/*     */     throws IOException
/*     */   {
/* 221 */     if (inputOffset > 0L) {
/* 222 */       skipFully(input, inputOffset);
/*     */     }
/* 224 */     if (length == 0L) {
/* 225 */       return 0L;
/*     */     }
/* 227 */     int bufferLength = buffer.length;
/* 228 */     int bytesToRead = bufferLength;
/* 229 */     if ((length > 0L) && (length < bufferLength)) {
/* 230 */       bytesToRead = (int)length;
/*     */     }
/*     */ 
/* 233 */     long totalRead = 0L;
/*     */     int read;
/* 234 */     while ((bytesToRead > 0) && (-1 != (read = input.read(buffer, 0, bytesToRead)))) {
/* 235 */       output.write(buffer, 0, read);
/* 236 */       totalRead += read;
/* 237 */       if (length <= 0L)
/*     */         continue;
/* 239 */       bytesToRead = (int)Math.min(length - totalRead, bufferLength);
/*     */     }
/*     */ 
/* 242 */     return totalRead;
/*     */   }
/*     */ 
/*     */   public static void skipFully(InputStream input, long toSkip)
/*     */     throws IOException
/*     */   {
/* 261 */     if (toSkip < 0L) {
/* 262 */       throw new IllegalArgumentException("Bytes to skip must not be negative: " + toSkip);
/*     */     }
/* 264 */     long skipped = skip(input, toSkip);
/* 265 */     if (skipped != toSkip)
/* 266 */       throw new EOFException("Bytes to skip: " + toSkip + " actual: " + skipped);
/*     */   }
/*     */ 
/*     */   public static void closeQuietly(InputStream input)
/*     */   {
/*     */     try
/*     */     {
/* 280 */       if (input != null)
/* 281 */         input.close();
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void closeQuietly(OutputStream output)
/*     */   {
/*     */     try
/*     */     {
/* 298 */       if (output != null)
/* 299 */         output.close();
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void closeQuietly(Closeable closeable)
/*     */   {
/*     */     try
/*     */     {
/* 331 */       if (closeable != null)
/* 332 */         closeable.close();
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseIOUtils
 * JD-Core Version:    0.6.0
 */