package com.parse;

abstract interface ParseCallback1<T extends Throwable>
{
  public abstract void done(T paramT);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseCallback1
 * JD-Core Version:    0.6.0
 */