/*    */ package com.parse;
/*    */ 
/*    */ import android.content.BroadcastReceiver;
/*    */ import android.content.Context;
/*    */ import android.content.Intent;
/*    */ 
/*    */ public class GcmBroadcastReceiver extends BroadcastReceiver
/*    */ {
/*    */   public final void onReceive(Context context, Intent intent)
/*    */   {
/* 13 */     PushService.runGcmIntentInService(context, intent);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.GcmBroadcastReceiver
 * JD-Core Version:    0.6.0
 */