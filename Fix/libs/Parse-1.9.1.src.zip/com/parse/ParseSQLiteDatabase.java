/*     */ package com.parse;
/*     */ 
/*     */ import android.content.ContentValues;
/*     */ import android.database.Cursor;
/*     */ import android.database.sqlite.SQLiteDatabase;
/*     */ import android.database.sqlite.SQLiteOpenHelper;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import bolts.Task.TaskCompletionSource;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ 
/*     */ class ParseSQLiteDatabase
/*     */ {
/*  23 */   private static final ExecutorService dbExecutor = Executors.newSingleThreadExecutor();
/*     */ 
/*  30 */   private static final TaskQueue taskQueue = new TaskQueue();
/*     */   private SQLiteDatabase db;
/*  43 */   private Task<Void> current = null;
/*  44 */   private final Object currentLock = new Object();
/*  45 */   private final Task<Void>.TaskCompletionSource tcs = Task.create();
/*     */   private int openFlags;
/*     */ 
/*     */   static Task<ParseSQLiteDatabase> openDatabaseAsync(SQLiteOpenHelper helper, int flags)
/*     */   {
/*  33 */     ParseSQLiteDatabase db = new ParseSQLiteDatabase(flags);
/*  34 */     return db.open(helper).continueWithTask(new Continuation(db)
/*     */     {
/*     */       public Task<ParseSQLiteDatabase> then(Task<Void> task) throws Exception {
/*  37 */         return Task.forResult(this.val$db);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private ParseSQLiteDatabase(int flags)
/*     */   {
/*  55 */     this.openFlags = flags;
/*     */ 
/*  57 */     taskQueue.enqueue(new Object()
/*     */     {
/*     */       public Task<Void> then(Task<Void> toAwait) throws Exception {
/*  60 */         synchronized (ParseSQLiteDatabase.this.currentLock) {
/*  61 */           ParseSQLiteDatabase.access$102(ParseSQLiteDatabase.this, toAwait);
/*     */         }
/*  63 */         return ParseSQLiteDatabase.this.tcs.getTask();
/*     */       } } );
/*     */   }
/*     */ 
/*     */   public Task<Boolean> isReadOnlyAsync() {
/*  69 */     synchronized (this.currentLock) {
/*  70 */       Task task = this.current.continueWith(new Continuation()
/*     */       {
/*     */         public Boolean then(Task<Void> task) throws Exception {
/*  73 */           return Boolean.valueOf(ParseSQLiteDatabase.this.db.isReadOnly());
/*     */         }
/*     */       });
/*  76 */       this.current = task.makeVoid();
/*  77 */       return task;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Boolean> isOpenAsync() {
/*  82 */     synchronized (this.currentLock) {
/*  83 */       Task task = this.current.continueWith(new Continuation()
/*     */       {
/*     */         public Boolean then(Task<Void> task) throws Exception {
/*  86 */           return Boolean.valueOf(ParseSQLiteDatabase.this.db.isOpen());
/*     */         }
/*     */       });
/*  89 */       this.current = task.makeVoid();
/*  90 */       return task;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean inTransaction() {
/*  95 */     return this.db.inTransaction();
/*     */   }
/*     */ 
/*     */   Task<Void> open(SQLiteOpenHelper helper) {
/*  99 */     synchronized (this.currentLock) {
/* 100 */       this.current = this.current.continueWith(new Continuation(helper)
/*     */       {
/*     */         public SQLiteDatabase then(Task<Void> task)
/*     */           throws Exception
/*     */         {
/* 105 */           return (ParseSQLiteDatabase.this.openFlags & 0x1) == 1 ? this.val$helper.getReadableDatabase() : this.val$helper.getWritableDatabase();
/*     */         }
/*     */       }
/*     */       , dbExecutor).continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Void> then(Task<SQLiteDatabase> task)
/*     */           throws Exception
/*     */         {
/* 112 */           ParseSQLiteDatabase.access$302(ParseSQLiteDatabase.this, (SQLiteDatabase)task.getResult());
/* 113 */           return task.makeVoid();
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR);
/*     */ 
/* 116 */       return this.current;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Void> beginTransactionAsync()
/*     */   {
/* 125 */     synchronized (this.currentLock) {
/* 126 */       this.current = this.current.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Void> then(Task<Void> task) throws Exception {
/* 129 */           ParseSQLiteDatabase.this.db.beginTransaction();
/* 130 */           return task;
/*     */         }
/*     */       }
/*     */       , dbExecutor);
/*     */ 
/* 133 */       return this.current.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Void> then(Task<Void> task) throws Exception
/*     */         {
/* 137 */           return task;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Void> setTransactionSuccessfulAsync()
/*     */   {
/* 148 */     synchronized (this.currentLock) {
/* 149 */       this.current = this.current.onSuccessTask(new Continuation()
/*     */       {
/*     */         public Task<Void> then(Task<Void> task) throws Exception {
/* 152 */           ParseSQLiteDatabase.this.db.setTransactionSuccessful();
/* 153 */           return task;
/*     */         }
/*     */       }
/*     */       , dbExecutor);
/*     */ 
/* 156 */       return this.current.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Void> then(Task<Void> task) throws Exception
/*     */         {
/* 160 */           return task;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Void> endTransactionAsync()
/*     */   {
/* 171 */     synchronized (this.currentLock) {
/* 172 */       this.current = this.current.continueWith(new Continuation()
/*     */       {
/*     */         public Void then(Task<Void> task) throws Exception {
/* 175 */           ParseSQLiteDatabase.this.db.endTransaction();
/*     */ 
/* 177 */           return null;
/*     */         }
/*     */       }
/*     */       , dbExecutor);
/*     */ 
/* 180 */       return this.current.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Void> then(Task<Void> task) throws Exception
/*     */         {
/* 184 */           return task;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Void> closeAsync()
/*     */   {
/* 195 */     synchronized (this.currentLock) {
/* 196 */       this.current = this.current.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Void> then(Task<Void> task) throws Exception {
/*     */           try {
/* 200 */             ParseSQLiteDatabase.this.db.close();
/*     */           } finally {
/* 202 */             ParseSQLiteDatabase.this.tcs.setResult(null);
/*     */           }
/* 204 */           return ParseSQLiteDatabase.this.tcs.getTask();
/*     */         }
/*     */       }
/*     */       , dbExecutor);
/*     */ 
/* 207 */       return this.current.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Void> then(Task<Void> task) throws Exception
/*     */         {
/* 211 */           return task;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Cursor> queryAsync(String table, String[] select, String where, String[] args)
/*     */   {
/* 224 */     synchronized (this.currentLock) {
/* 225 */       Task task = this.current.onSuccess(new Continuation(table, select, where, args)
/*     */       {
/*     */         public Cursor then(Task<Void> task) throws Exception {
/* 228 */           return ParseSQLiteDatabase.this.db.query(this.val$table, this.val$select, this.val$where, this.val$args, null, null, null);
/*     */         }
/*     */       }
/*     */       , dbExecutor).onSuccess(new Continuation()
/*     */       {
/*     */         public Cursor then(Task<Cursor> task)
/*     */           throws Exception
/*     */         {
/* 233 */           Cursor cursor = ParseSQLiteCursor.create((Cursor)task.getResult(), ParseSQLiteDatabase.dbExecutor);
/*     */ 
/* 237 */           cursor.getCount();
/* 238 */           return cursor;
/*     */         }
/*     */       }
/*     */       , dbExecutor);
/*     */ 
/* 241 */       this.current = task.makeVoid();
/* 242 */       return task.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Cursor> then(Task<Cursor> task) throws Exception
/*     */         {
/* 246 */           return task;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Void> insertWithOnConflict(String table, ContentValues values, int conflictAlgorithm)
/*     */   {
/* 258 */     synchronized (this.currentLock) {
/* 259 */       Task task = this.current.onSuccess(new Continuation(table, values, conflictAlgorithm)
/*     */       {
/*     */         public Long then(Task<Void> task) throws Exception {
/* 262 */           return Long.valueOf(ParseSQLiteDatabase.this.db.insertWithOnConflict(this.val$table, null, this.val$values, this.val$conflictAlgorithm));
/*     */         }
/*     */       }
/*     */       , dbExecutor);
/*     */ 
/* 265 */       this.current = task.makeVoid();
/* 266 */       return task.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Long> then(Task<Long> task) throws Exception
/*     */         {
/* 270 */           return task;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR).makeVoid();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Void> insertOrThrowAsync(String table, ContentValues values)
/*     */   {
/* 281 */     synchronized (this.currentLock) {
/* 282 */       Task task = this.current.onSuccess(new Continuation(table, values)
/*     */       {
/*     */         public Long then(Task<Void> task) throws Exception {
/* 285 */           return Long.valueOf(ParseSQLiteDatabase.this.db.insertOrThrow(this.val$table, null, this.val$values));
/*     */         }
/*     */       }
/*     */       , dbExecutor);
/*     */ 
/* 288 */       this.current = task.makeVoid();
/* 289 */       return task.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Long> then(Task<Long> task) throws Exception
/*     */         {
/* 293 */           return task;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR).makeVoid();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Integer> updateAsync(String table, ContentValues values, String where, String[] args)
/*     */   {
/* 305 */     synchronized (this.currentLock) {
/* 306 */       Task task = this.current.onSuccess(new Continuation(table, values, where, args)
/*     */       {
/*     */         public Integer then(Task<Void> task) throws Exception {
/* 309 */           return Integer.valueOf(ParseSQLiteDatabase.this.db.update(this.val$table, this.val$values, this.val$where, this.val$args));
/*     */         }
/*     */       }
/*     */       , dbExecutor);
/*     */ 
/* 312 */       this.current = task.makeVoid();
/* 313 */       return task.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Integer> then(Task<Integer> task) throws Exception
/*     */         {
/* 317 */           return task;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Void> deleteAsync(String table, String where, String[] args)
/*     */   {
/* 328 */     synchronized (this.currentLock) {
/* 329 */       Task task = this.current.onSuccess(new Continuation(table, where, args)
/*     */       {
/*     */         public Integer then(Task<Void> task) throws Exception {
/* 332 */           return Integer.valueOf(ParseSQLiteDatabase.this.db.delete(this.val$table, this.val$where, this.val$args));
/*     */         }
/*     */       }
/*     */       , dbExecutor);
/*     */ 
/* 335 */       this.current = task.makeVoid();
/* 336 */       return task.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Integer> then(Task<Integer> task) throws Exception
/*     */         {
/* 340 */           return task;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR).makeVoid();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Task<Cursor> rawQueryAsync(String sql, String[] args)
/*     */   {
/* 352 */     synchronized (this.currentLock) {
/* 353 */       Task task = this.current.onSuccess(new Continuation(sql, args)
/*     */       {
/*     */         public Cursor then(Task<Void> task) throws Exception {
/* 356 */           return ParseSQLiteDatabase.this.db.rawQuery(this.val$sql, this.val$args);
/*     */         }
/*     */       }
/*     */       , dbExecutor).onSuccess(new Continuation()
/*     */       {
/*     */         public Cursor then(Task<Cursor> task)
/*     */           throws Exception
/*     */         {
/* 361 */           Cursor cursor = ParseSQLiteCursor.create((Cursor)task.getResult(), ParseSQLiteDatabase.dbExecutor);
/*     */ 
/* 364 */           cursor.getCount();
/* 365 */           return cursor;
/*     */         }
/*     */       }
/*     */       , dbExecutor);
/*     */ 
/* 368 */       this.current = task.makeVoid();
/* 369 */       return task.continueWithTask(new Continuation()
/*     */       {
/*     */         public Task<Cursor> then(Task<Cursor> task) throws Exception
/*     */         {
/* 373 */           return task;
/*     */         }
/*     */       }
/*     */       , Task.BACKGROUND_EXECUTOR);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseSQLiteDatabase
 * JD-Core Version:    0.6.0
 */