/*    */ package com.parse;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.json.JSONArray;
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseRESTPushCommand extends ParseRESTCommand
/*    */ {
/*    */   public ParseRESTPushCommand(String httpPath, ParseRequest.Method httpMethod, Map<String, ?> parameters, String sessionToken)
/*    */   {
/* 14 */     super(httpPath, httpMethod, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTPushCommand sendPushCommand(ParseQuery<ParseInstallation> query, Set<String> targetChannels, String targetDeviceType, Long expirationTime, Long expirationInterval, JSONObject payload, String sessionToken)
/*    */   {
/* 20 */     Map parameters = new HashMap();
/*    */ 
/* 22 */     if (query != null) {
/* 23 */       ParseQuery.QueryConstraints where = query.getConstraints();
/* 24 */       JSONObject whereJSON = (JSONObject)Parse.encode(where, PointerEncodingStrategy.get());
/* 25 */       parameters.put("where", whereJSON);
/*    */     }
/* 27 */     else if (targetChannels != null) {
/* 28 */       parameters.put("channels", new JSONArray(targetChannels));
/*    */     }
/* 30 */     if (targetDeviceType != null) {
/* 31 */       JSONObject deviceTypeCondition = new JSONObject();
/*    */       try {
/* 33 */         deviceTypeCondition.put("deviceType", targetDeviceType);
/*    */       } catch (JSONException e) {
/* 35 */         throw new RuntimeException(e.getMessage());
/*    */       }
/* 37 */       parameters.put("where", deviceTypeCondition);
/*    */     }
/*    */ 
/* 40 */     if (parameters.size() == 0)
/*    */     {
/* 42 */       parameters.put("where", new JSONObject());
/*    */     }
/*    */ 
/* 45 */     if (expirationTime != null)
/* 46 */       parameters.put("expiration_time", expirationTime);
/* 47 */     else if (expirationInterval != null) {
/* 48 */       parameters.put("expiration_interval", expirationInterval);
/*    */     }
/*    */ 
/* 51 */     if (payload != null) {
/* 52 */       parameters.put("data", payload);
/*    */     }
/*    */ 
/* 55 */     return new ParseRESTPushCommand("push", ParseRequest.Method.POST, parameters, sessionToken);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTPushCommand
 * JD-Core Version:    0.6.0
 */