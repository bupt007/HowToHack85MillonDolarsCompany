package com.parse;

public abstract interface ProgressCallback
{
  public abstract void done(Integer paramInteger);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ProgressCallback
 * JD-Core Version:    0.6.0
 */