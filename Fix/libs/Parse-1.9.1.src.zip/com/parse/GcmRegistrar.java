/*     */ package com.parse;
/*     */ 
/*     */ import android.app.AlarmManager;
/*     */ import android.app.PendingIntent;
/*     */ import android.content.BroadcastReceiver;
/*     */ import android.content.ComponentName;
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import android.content.IntentFilter;
/*     */ import android.os.Bundle;
/*     */ import android.os.SystemClock;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import bolts.Task.TaskCompletionSource;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ class GcmRegistrar
/*     */ {
/*     */   private static final String TAG = "com.parse.GcmRegistrar";
/*     */   private static final String REGISTRATION_ID_EXTRA = "registration_id";
/*     */   private static final String ERROR_EXTRA = "error";
/*     */   private static final String PARSE_SENDER_ID = "1076345567071";
/*     */   private static final String SENDER_ID_EXTRA = "com.parse.push.gcm_sender_id";
/*     */   public static final String REGISTER_ACTION = "com.google.android.c2dm.intent.REGISTER";
/*     */   public static final String REGISTER_RESPONSE_ACTION = "com.google.android.c2dm.intent.REGISTRATION";
/*  55 */   private final Object lock = new Object();
/*  56 */   private Request request = null;
/*  57 */   private Context context = null;
/*     */ 
/*     */   public static GcmRegistrar getInstance()
/*     */   {
/*  35 */     return Singleton.INSTANCE;
/*     */   }
/*     */ 
/*     */   private static String actualSenderIDFromExtra(Object senderIDExtra)
/*     */   {
/*  43 */     if (!(senderIDExtra instanceof String)) {
/*  44 */       return null;
/*     */     }
/*     */ 
/*  47 */     String senderID = (String)senderIDExtra;
/*  48 */     if (!senderID.startsWith("id:")) {
/*  49 */       return null;
/*     */     }
/*     */ 
/*  52 */     return senderID.substring(3);
/*     */   }
/*     */ 
/*     */   GcmRegistrar(Context context)
/*     */   {
/*  61 */     this.context = context;
/*     */   }
/*     */ 
/*     */   public void register()
/*     */   {
/*  70 */     if (ManifestInfo.getPushType() == PushType.GCM)
/*  71 */       synchronized (this.lock) {
/*  72 */         ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/*     */ 
/*  74 */         if ((installation.getDeviceToken() == null) || (installation.isDeviceTokenStale()))
/*     */         {
/*  81 */           if (installation.getPushType() != PushType.GCM) {
/*  82 */             installation.setPushType(PushType.GCM);
/*  83 */             installation.saveEventually();
/*     */           }
/*     */ 
/*  86 */           sendRegistrationRequest();
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   Task<Void> updateAsync()
/*     */   {
/*  96 */     return ParseInstallation.hasCurrentInstallationAsync().onSuccess(new Object()
/*     */     {
/*     */       public Void then(Task<Boolean> task) throws Exception {
/*  99 */         boolean hasCurrentInstallation = ((Boolean)task.getResult()).booleanValue();
/* 100 */         if ((hasCurrentInstallation) && (ManifestInfo.getPushType() == PushType.GCM)) {
/* 101 */           synchronized (GcmRegistrar.this.lock) {
/* 102 */             ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/*     */ 
/* 112 */             if ((installation.getPushType() == PushType.GCM) && (
/* 113 */               (installation.getDeviceToken() == null) || (installation.isDeviceTokenStale()))) {
/* 114 */               GcmRegistrar.this.sendRegistrationRequest();
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 119 */         return null;
/*     */       } } );
/*     */   }
/*     */ 
/*     */   private void sendRegistrationRequest() {
/* 125 */     synchronized (this.lock) {
/* 126 */       if (this.request == null)
/*     */       {
/* 138 */         Bundle metaData = ManifestInfo.getApplicationMetadata(this.context);
/* 139 */         String senderIDs = "1076345567071";
/* 140 */         if (metaData != null) {
/* 141 */           Object senderIDExtra = metaData.get("com.parse.push.gcm_sender_id");
/*     */ 
/* 143 */           if (senderIDExtra != null) {
/* 144 */             String senderID = actualSenderIDFromExtra(senderIDExtra);
/*     */ 
/* 146 */             if (senderID != null)
/* 147 */               senderIDs = senderIDs + "," + senderID;
/*     */             else {
/* 149 */               Parse.logE("com.parse.GcmRegistrar", "Found com.parse.push.gcm_sender_id <meta-data> element with value \"" + senderIDExtra.toString() + "\", but the value is missing the expected \"id:\" " + "prefix.");
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 156 */         this.request = Request.createAndSend(this.context, senderIDs);
/* 157 */         this.request.getTask().continueWith(new Object()
/*     */         {
/*     */           public Void then(Task<String> task) {
/* 160 */             Exception e = task.getError();
/* 161 */             if (e != null) {
/* 162 */               Parse.logE("com.parse.GcmRegistrar", "Got error when trying to register for GCM push", e);
/*     */             }
/*     */ 
/* 165 */             synchronized (GcmRegistrar.this.lock) {
/* 166 */               GcmRegistrar.access$202(GcmRegistrar.this, null);
/*     */             }
/*     */ 
/* 169 */             return null;
/*     */           } } );
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isRegistrationIntent(Intent intent) {
/* 177 */     return (intent != null) && ("com.google.android.c2dm.intent.REGISTRATION".equals(intent.getAction()));
/*     */   }
/*     */ 
/*     */   public void handleRegistrationIntent(Intent intent)
/*     */   {
/* 185 */     if (isRegistrationIntent(intent))
/*     */     {
/* 190 */       String registrationId = intent.getStringExtra("registration_id");
/*     */ 
/* 192 */       if ((registrationId != null) && (registrationId.length() > 0)) {
/* 193 */         ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/*     */ 
/* 195 */         installation.setPushType(PushType.GCM);
/* 196 */         installation.setDeviceToken(registrationId);
/* 197 */         installation.saveEventually();
/*     */       }
/*     */ 
/* 200 */       synchronized (this.lock) {
/* 201 */         if (this.request != null)
/* 202 */           this.request.onReceiveResponseIntent(intent);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   int getRequestIdentifier()
/*     */   {
/* 210 */     synchronized (this.lock) {
/* 211 */       return this.request != null ? this.request.identifier : 0; }  } 
/*     */   private static class Request { private static final String RETRY_ACTION = "com.parse.RetryGcmRegistration";
/*     */     private static final int MAX_RETRIES = 5;
/*     */     private static final int BACKOFF_INTERVAL_MS = 3000;
/*     */     private final Context context;
/*     */     private final String senderId;
/*     */     private final Random random;
/*     */     private final int identifier;
/*     */     private final Task<String>.TaskCompletionSource tcs;
/*     */     private final PendingIntent appIntent;
/*     */     private final AtomicInteger tries;
/*     */     private final PendingIntent retryIntent;
/*     */     private final BroadcastReceiver retryReceiver;
/*     */ 
/* 235 */     public static Request createAndSend(Context context, String senderId) { Request request = new Request(context, senderId);
/* 236 */       request.send();
/*     */ 
/* 238 */       return request; }
/*     */ 
/*     */     private Request(Context context, String senderId)
/*     */     {
/* 242 */       this.context = context;
/* 243 */       this.senderId = senderId;
/* 244 */       this.random = new Random();
/* 245 */       this.identifier = this.random.nextInt();
/* 246 */       this.tcs = Task.create();
/* 247 */       this.appIntent = PendingIntent.getBroadcast(this.context, this.identifier, new Intent(), 0);
/* 248 */       this.tries = new AtomicInteger(0);
/*     */ 
/* 250 */       String packageName = this.context.getPackageName();
/* 251 */       Intent intent = new Intent("com.parse.RetryGcmRegistration").setPackage(packageName);
/* 252 */       intent.addCategory(packageName);
/* 253 */       intent.putExtra("random", this.identifier);
/* 254 */       this.retryIntent = PendingIntent.getBroadcast(this.context, this.identifier, intent, 0);
/*     */ 
/* 256 */       this.retryReceiver = new BroadcastReceiver()
/*     */       {
/*     */         public void onReceive(Context context, Intent intent) {
/* 259 */           if ((intent != null) && (intent.getIntExtra("random", 0) == GcmRegistrar.Request.this.identifier))
/* 260 */             GcmRegistrar.Request.this.send();
/*     */         }
/*     */       };
/* 265 */       IntentFilter filter = new IntentFilter();
/* 266 */       filter.addAction("com.parse.RetryGcmRegistration");
/* 267 */       filter.addCategory(packageName);
/*     */ 
/* 269 */       context.registerReceiver(this.retryReceiver, filter);
/*     */     }
/*     */ 
/*     */     public Task<String> getTask() {
/* 273 */       return this.tcs.getTask();
/*     */     }
/*     */ 
/*     */     private void send() {
/* 277 */       Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
/* 278 */       intent.setPackage("com.google.android.gsf");
/* 279 */       intent.putExtra("sender", this.senderId);
/* 280 */       intent.putExtra("app", this.appIntent);
/*     */ 
/* 282 */       ComponentName name = null;
/*     */       try {
/* 284 */         name = this.context.startService(intent);
/*     */       }
/*     */       catch (SecurityException exception)
/*     */       {
/*     */       }
/* 289 */       if (name == null) {
/* 290 */         finish(null, "GSF_PACKAGE_NOT_AVAILABLE");
/*     */       }
/*     */ 
/* 293 */       this.tries.incrementAndGet();
/*     */ 
/* 295 */       Parse.logV("com.parse.GcmRegistrar", "Sending GCM registration intent");
/*     */     }
/*     */ 
/*     */     public void onReceiveResponseIntent(Intent intent) {
/* 299 */       String registrationId = intent.getStringExtra("registration_id");
/* 300 */       String error = intent.getStringExtra("error");
/*     */ 
/* 302 */       if ((registrationId == null) && (error == null)) {
/* 303 */         Parse.logE("com.parse.GcmRegistrar", "Got no registration info in GCM onReceiveResponseIntent");
/* 304 */         return;
/*     */       }
/*     */ 
/* 308 */       if (("SERVICE_NOT_AVAILABLE".equals(error)) && (this.tries.get() < 5)) {
/* 309 */         AlarmManager manager = (AlarmManager)this.context.getSystemService("alarm");
/* 310 */         int alarmType = 2;
/* 311 */         long delay = (1 << this.tries.get()) * 3000 + this.random.nextInt(3000);
/* 312 */         long start = SystemClock.elapsedRealtime() + delay;
/* 313 */         manager.set(alarmType, start, this.retryIntent);
/*     */       } else {
/* 315 */         finish(registrationId, error);
/*     */       }
/*     */     }
/*     */ 
/*     */     private void finish(String registrationId, String error)
/*     */     {
/*     */       boolean didSetResult;
/*     */       boolean didSetResult;
/* 322 */       if (registrationId != null)
/* 323 */         didSetResult = this.tcs.trySetResult(registrationId);
/*     */       else {
/* 325 */         didSetResult = this.tcs.trySetError(new Exception("GCM registration error: " + error));
/*     */       }
/*     */ 
/* 328 */       if (didSetResult) {
/* 329 */         this.appIntent.cancel();
/* 330 */         this.retryIntent.cancel();
/* 331 */         this.context.unregisterReceiver(this.retryReceiver);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Singleton
/*     */   {
/*  39 */     public static final GcmRegistrar INSTANCE = new GcmRegistrar(Parse.getApplicationContext());
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.GcmRegistrar
 * JD-Core Version:    0.6.0
 */