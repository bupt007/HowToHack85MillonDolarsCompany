/*    */ package com.parse.signpost.signature;
/*    */ 
/*    */ import com.parse.signpost.OAuth;
/*    */ import com.parse.signpost.http.HttpParameters;
/*    */ import com.parse.signpost.http.HttpRequest;
/*    */ 
/*    */ public class QueryStringSigningStrategy
/*    */   implements SigningStrategy
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public String writeSignature(String signature, HttpRequest request, HttpParameters requestParameters)
/*    */   {
/* 25 */     StringBuilder sb = new StringBuilder(OAuth.addQueryParameters(request.getRequestUrl(), new String[] { "oauth_signature", signature }));
/*    */ 
/* 29 */     if (requestParameters.containsKey("oauth_token")) {
/* 30 */       sb.append("&");
/* 31 */       sb.append(requestParameters.getAsQueryString("oauth_token"));
/*    */     }
/* 33 */     if (requestParameters.containsKey("oauth_callback")) {
/* 34 */       sb.append("&");
/* 35 */       sb.append(requestParameters.getAsQueryString("oauth_callback"));
/*    */     }
/* 37 */     if (requestParameters.containsKey("oauth_verifier")) {
/* 38 */       sb.append("&");
/* 39 */       sb.append(requestParameters.getAsQueryString("oauth_verifier"));
/*    */     }
/*    */ 
/* 43 */     sb.append("&");
/* 44 */     sb.append(requestParameters.getAsQueryString("oauth_consumer_key"));
/* 45 */     sb.append("&");
/* 46 */     sb.append(requestParameters.getAsQueryString("oauth_version"));
/* 47 */     sb.append("&");
/* 48 */     sb.append(requestParameters.getAsQueryString("oauth_signature_method"));
/* 49 */     sb.append("&");
/* 50 */     sb.append(requestParameters.getAsQueryString("oauth_timestamp"));
/* 51 */     sb.append("&");
/* 52 */     sb.append(requestParameters.getAsQueryString("oauth_nonce"));
/*    */ 
/* 54 */     String signedUrl = sb.toString();
/*    */ 
/* 56 */     request.setRequestUrl(signedUrl);
/*    */ 
/* 58 */     return signedUrl;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.signature.QueryStringSigningStrategy
 * JD-Core Version:    0.6.0
 */