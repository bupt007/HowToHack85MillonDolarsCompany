/*    */ package com.parse.signpost.signature;
/*    */ 
/*    */ import com.parse.codec.binary.Base64;
/*    */ import com.parse.signpost.exception.OAuthMessageSignerException;
/*    */ import com.parse.signpost.http.HttpParameters;
/*    */ import com.parse.signpost.http.HttpRequest;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public abstract class OAuthMessageSigner
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 4445779788786131202L;
/*    */   private transient Base64 base64;
/*    */   private String consumerSecret;
/*    */   private String tokenSecret;
/*    */ 
/*    */   public OAuthMessageSigner()
/*    */   {
/* 41 */     this.base64 = new Base64();
/*    */   }
/*    */   public abstract String sign(HttpRequest paramHttpRequest, HttpParameters paramHttpParameters) throws OAuthMessageSignerException;
/*    */ 
/*    */   public abstract String getSignatureMethod();
/*    */ 
/*    */   public String getConsumerSecret() {
/* 50 */     return this.consumerSecret;
/*    */   }
/*    */ 
/*    */   public String getTokenSecret() {
/* 54 */     return this.tokenSecret;
/*    */   }
/*    */ 
/*    */   public void setConsumerSecret(String consumerSecret) {
/* 58 */     this.consumerSecret = consumerSecret;
/*    */   }
/*    */ 
/*    */   public void setTokenSecret(String tokenSecret) {
/* 62 */     this.tokenSecret = tokenSecret;
/*    */   }
/*    */ 
/*    */   protected byte[] decodeBase64(String s) {
/* 66 */     return this.base64.decode(s.getBytes());
/*    */   }
/*    */ 
/*    */   protected String base64Encode(byte[] b) {
/* 70 */     return new String(this.base64.encode(b));
/*    */   }
/*    */ 
/*    */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
/*    */   {
/* 75 */     stream.defaultReadObject();
/* 76 */     this.base64 = new Base64();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.signature.OAuthMessageSigner
 * JD-Core Version:    0.6.0
 */