/*    */ package com.parse.signpost.signature;
/*    */ 
/*    */ import com.parse.signpost.OAuth;
/*    */ import com.parse.signpost.exception.OAuthMessageSignerException;
/*    */ import com.parse.signpost.http.HttpParameters;
/*    */ import com.parse.signpost.http.HttpRequest;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.security.GeneralSecurityException;
/*    */ import javax.crypto.Mac;
/*    */ import javax.crypto.SecretKey;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ public class HmacSha1MessageSigner extends OAuthMessageSigner
/*    */ {
/*    */   private static final String MAC_NAME = "HmacSHA1";
/*    */ 
/*    */   public String getSignatureMethod()
/*    */   {
/* 37 */     return "HMAC-SHA1";
/*    */   }
/*    */ 
/*    */   public String sign(HttpRequest request, HttpParameters requestParams) throws OAuthMessageSignerException
/*    */   {
/*    */     try
/*    */     {
/* 44 */       String keyString = OAuth.percentEncode(getConsumerSecret()) + '&' + OAuth.percentEncode(getTokenSecret());
/*    */ 
/* 46 */       byte[] keyBytes = keyString.getBytes("UTF-8");
/*    */ 
/* 48 */       SecretKey key = new SecretKeySpec(keyBytes, "HmacSHA1");
/* 49 */       Mac mac = Mac.getInstance("HmacSHA1");
/* 50 */       mac.init(key);
/*    */ 
/* 52 */       String sbs = new SignatureBaseString(request, requestParams).generate();
/* 53 */       OAuth.debugOut("SBS", sbs);
/* 54 */       byte[] text = sbs.getBytes("UTF-8");
/*    */ 
/* 56 */       return base64Encode(mac.doFinal(text)).trim();
/*    */     } catch (GeneralSecurityException e) {
/* 58 */       throw new OAuthMessageSignerException(e); } catch (UnsupportedEncodingException e) {
/*    */     }
/* 60 */     throw new OAuthMessageSignerException(e);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.signature.HmacSha1MessageSigner
 * JD-Core Version:    0.6.0
 */