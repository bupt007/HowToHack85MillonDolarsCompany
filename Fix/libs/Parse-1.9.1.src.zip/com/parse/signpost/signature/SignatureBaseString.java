/*     */ package com.parse.signpost.signature;
/*     */ 
/*     */ import com.parse.signpost.OAuth;
/*     */ import com.parse.signpost.exception.OAuthMessageSignerException;
/*     */ import com.parse.signpost.http.HttpParameters;
/*     */ import com.parse.signpost.http.HttpRequest;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class SignatureBaseString
/*     */ {
/*     */   private HttpRequest request;
/*     */   private HttpParameters requestParameters;
/*     */ 
/*     */   public SignatureBaseString(HttpRequest request, HttpParameters requestParameters)
/*     */   {
/*  41 */     this.request = request;
/*  42 */     this.requestParameters = requestParameters;
/*     */   }
/*     */ 
/*     */   public String generate()
/*     */     throws OAuthMessageSignerException
/*     */   {
/*     */     try
/*     */     {
/*  55 */       String normalizedUrl = normalizeRequestUrl();
/*  56 */       String normalizedParams = normalizeRequestParameters();
/*     */ 
/*  58 */       return new StringBuilder().append(this.request.getMethod()).append('&').append(OAuth.percentEncode(normalizedUrl)).append('&').append(OAuth.percentEncode(normalizedParams)).toString();
/*     */     } catch (Exception e) {
/*     */     }
/*  61 */     throw new OAuthMessageSignerException(e);
/*     */   }
/*     */ 
/*     */   public String normalizeRequestUrl() throws URISyntaxException
/*     */   {
/*  66 */     URI uri = new URI(this.request.getRequestUrl());
/*  67 */     String scheme = uri.getScheme().toLowerCase();
/*  68 */     String authority = uri.getAuthority().toLowerCase();
/*  69 */     boolean dropPort = ((scheme.equals("http")) && (uri.getPort() == 80)) || ((scheme.equals("https")) && (uri.getPort() == 443));
/*     */ 
/*  71 */     if (dropPort)
/*     */     {
/*  73 */       int index = authority.lastIndexOf(":");
/*  74 */       if (index >= 0) {
/*  75 */         authority = authority.substring(0, index);
/*     */       }
/*     */     }
/*  78 */     String path = uri.getRawPath();
/*  79 */     if ((path == null) || (path.length() <= 0)) {
/*  80 */       path = "/";
/*     */     }
/*     */ 
/*  83 */     return new StringBuilder().append(scheme).append("://").append(authority).append(path).toString();
/*     */   }
/*     */ 
/*     */   public String normalizeRequestParameters()
/*     */     throws IOException
/*     */   {
/*  96 */     if (this.requestParameters == null) {
/*  97 */       return "";
/*     */     }
/*     */ 
/* 100 */     StringBuilder sb = new StringBuilder();
/* 101 */     Iterator iter = this.requestParameters.keySet().iterator();
/*     */ 
/* 103 */     for (int i = 0; iter.hasNext(); i++) {
/* 104 */       String param = (String)iter.next();
/*     */ 
/* 106 */       if (("oauth_signature".equals(param)) || ("realm".equals(param)))
/*     */       {
/*     */         continue;
/*     */       }
/* 110 */       if (i > 0) {
/* 111 */         sb.append("&");
/*     */       }
/*     */ 
/* 114 */       sb.append(this.requestParameters.getAsQueryString(param));
/*     */     }
/* 116 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.signature.SignatureBaseString
 * JD-Core Version:    0.6.0
 */