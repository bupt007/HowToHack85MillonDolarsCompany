/*    */ package com.parse.signpost.signature;
/*    */ 
/*    */ import com.parse.signpost.OAuth;
/*    */ import com.parse.signpost.http.HttpParameters;
/*    */ import com.parse.signpost.http.HttpRequest;
/*    */ 
/*    */ public class AuthorizationHeaderSigningStrategy
/*    */   implements SigningStrategy
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public String writeSignature(String signature, HttpRequest request, HttpParameters requestParameters)
/*    */   {
/* 19 */     StringBuilder sb = new StringBuilder();
/*    */ 
/* 21 */     sb.append("OAuth ");
/* 22 */     if (requestParameters.containsKey("realm")) {
/* 23 */       sb.append(requestParameters.getAsHeaderElement("realm"));
/* 24 */       sb.append(", ");
/*    */     }
/* 26 */     if (requestParameters.containsKey("oauth_token")) {
/* 27 */       sb.append(requestParameters.getAsHeaderElement("oauth_token"));
/* 28 */       sb.append(", ");
/*    */     }
/* 30 */     if (requestParameters.containsKey("oauth_callback")) {
/* 31 */       sb.append(requestParameters.getAsHeaderElement("oauth_callback"));
/* 32 */       sb.append(", ");
/*    */     }
/* 34 */     if (requestParameters.containsKey("oauth_verifier")) {
/* 35 */       sb.append(requestParameters.getAsHeaderElement("oauth_verifier"));
/* 36 */       sb.append(", ");
/*    */     }
/* 38 */     sb.append(requestParameters.getAsHeaderElement("oauth_consumer_key"));
/* 39 */     sb.append(", ");
/* 40 */     sb.append(requestParameters.getAsHeaderElement("oauth_version"));
/* 41 */     sb.append(", ");
/* 42 */     sb.append(requestParameters.getAsHeaderElement("oauth_signature_method"));
/* 43 */     sb.append(", ");
/* 44 */     sb.append(requestParameters.getAsHeaderElement("oauth_timestamp"));
/* 45 */     sb.append(", ");
/* 46 */     sb.append(requestParameters.getAsHeaderElement("oauth_nonce"));
/* 47 */     sb.append(", ");
/* 48 */     sb.append(OAuth.toHeaderElement("oauth_signature", signature));
/*    */ 
/* 50 */     String header = sb.toString();
/* 51 */     request.setHeader("Authorization", header);
/*    */ 
/* 53 */     return header;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.signature.AuthorizationHeaderSigningStrategy
 * JD-Core Version:    0.6.0
 */