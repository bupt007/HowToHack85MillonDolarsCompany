/*     */ package com.parse.signpost;
/*     */ 
/*     */ import com.parse.gdata.PercentEscaper;
/*     */ import com.parse.signpost.http.HttpParameters;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class OAuth
/*     */ {
/*     */   public static final String VERSION_1_0 = "1.0";
/*     */   public static final String ENCODING = "UTF-8";
/*     */   public static final String FORM_ENCODED = "application/x-www-form-urlencoded";
/*     */   public static final String HTTP_AUTHORIZATION_HEADER = "Authorization";
/*     */   public static final String OAUTH_CONSUMER_KEY = "oauth_consumer_key";
/*     */   public static final String OAUTH_TOKEN = "oauth_token";
/*     */   public static final String OAUTH_TOKEN_SECRET = "oauth_token_secret";
/*     */   public static final String OAUTH_SIGNATURE_METHOD = "oauth_signature_method";
/*     */   public static final String OAUTH_SIGNATURE = "oauth_signature";
/*     */   public static final String OAUTH_TIMESTAMP = "oauth_timestamp";
/*     */   public static final String OAUTH_NONCE = "oauth_nonce";
/*     */   public static final String OAUTH_VERSION = "oauth_version";
/*     */   public static final String OAUTH_CALLBACK = "oauth_callback";
/*     */   public static final String OAUTH_CALLBACK_CONFIRMED = "oauth_callback_confirmed";
/*     */   public static final String OAUTH_VERIFIER = "oauth_verifier";
/*     */   public static final String OUT_OF_BAND = "oob";
/*  76 */   private static final PercentEscaper percentEncoder = new PercentEscaper("-._~", false);
/*     */ 
/*     */   public static String percentEncode(String s)
/*     */   {
/*  80 */     if (s == null) {
/*  81 */       return "";
/*     */     }
/*  83 */     return percentEncoder.escape(s);
/*     */   }
/*     */ 
/*     */   public static String percentDecode(String s) {
/*     */     try {
/*  88 */       if (s == null) {
/*  89 */         return "";
/*     */       }
/*  91 */       return URLDecoder.decode(s, "UTF-8");
/*     */     } catch (UnsupportedEncodingException wow) {
/*     */     }
/*  94 */     throw new RuntimeException(wow.getMessage(), wow);
/*     */   }
/*     */ 
/*     */   public static <T extends Map.Entry<String, String>> void formEncode(Collection<T> parameters, OutputStream into)
/*     */     throws IOException
/*     */   {
/*     */     boolean first;
/* 105 */     if (parameters != null) {
/* 106 */       first = true;
/* 107 */       for (Map.Entry entry : parameters) {
/* 108 */         if (first)
/* 109 */           first = false;
/*     */         else {
/* 111 */           into.write(38);
/*     */         }
/* 113 */         into.write(percentEncode(safeToString(entry.getKey())).getBytes());
/* 114 */         into.write(61);
/* 115 */         into.write(percentEncode(safeToString(entry.getValue())).getBytes());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <T extends Map.Entry<String, String>> String formEncode(Collection<T> parameters)
/*     */     throws IOException
/*     */   {
/* 127 */     ByteArrayOutputStream b = new ByteArrayOutputStream();
/* 128 */     formEncode(parameters, b);
/* 129 */     return new String(b.toByteArray());
/*     */   }
/*     */ 
/*     */   public static HttpParameters decodeForm(String form)
/*     */   {
/* 134 */     HttpParameters params = new HttpParameters();
/* 135 */     if (isEmpty(form)) {
/* 136 */       return params;
/*     */     }
/* 138 */     for (String nvp : form.split("\\&")) {
/* 139 */       int equals = nvp.indexOf(61);
/*     */       String value;
/*     */       String name;
/*     */       String value;
/* 142 */       if (equals < 0) {
/* 143 */         String name = percentDecode(nvp);
/* 144 */         value = null;
/*     */       } else {
/* 146 */         name = percentDecode(nvp.substring(0, equals));
/* 147 */         value = percentDecode(nvp.substring(equals + 1));
/*     */       }
/*     */ 
/* 150 */       params.put(name, value);
/*     */     }
/* 152 */     return params;
/*     */   }
/*     */ 
/*     */   public static HttpParameters decodeForm(InputStream content) throws IOException
/*     */   {
/* 157 */     BufferedReader reader = new BufferedReader(new InputStreamReader(content), 8192);
/* 158 */     StringBuilder sb = new StringBuilder();
/* 159 */     String line = reader.readLine();
/* 160 */     while (line != null) {
/* 161 */       sb.append(line);
/* 162 */       line = reader.readLine();
/*     */     }
/*     */ 
/* 165 */     return decodeForm(sb.toString());
/*     */   }
/*     */ 
/*     */   public static <T extends Map.Entry<String, String>> Map<String, String> toMap(Collection<T> from)
/*     */   {
/* 174 */     HashMap map = new HashMap();
/* 175 */     if (from != null) {
/* 176 */       for (Map.Entry entry : from) {
/* 177 */         String key = (String)entry.getKey();
/* 178 */         if (!map.containsKey(key)) {
/* 179 */           map.put(key, entry.getValue());
/*     */         }
/*     */       }
/*     */     }
/* 183 */     return map;
/*     */   }
/*     */ 
/*     */   public static final String safeToString(Object from) {
/* 187 */     return from == null ? null : from.toString();
/*     */   }
/*     */ 
/*     */   public static boolean isEmpty(String str) {
/* 191 */     return (str == null) || (str.length() == 0);
/*     */   }
/*     */ 
/*     */   public static String addQueryParameters(String url, String[] kvPairs)
/*     */   {
/* 217 */     String queryDelim = url.contains("?") ? "&" : "?";
/* 218 */     StringBuilder sb = new StringBuilder(new StringBuilder().append(url).append(queryDelim).toString());
/* 219 */     for (int i = 0; i < kvPairs.length; i += 2) {
/* 220 */       if (i > 0) {
/* 221 */         sb.append("&");
/*     */       }
/* 223 */       sb.append(new StringBuilder().append(percentEncode(kvPairs[i])).append("=").append(percentEncode(kvPairs[(i + 1)])).toString());
/*     */     }
/*     */ 
/* 226 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String addQueryParameters(String url, Map<String, String> params) {
/* 230 */     String[] kvPairs = new String[params.size() * 2];
/* 231 */     int idx = 0;
/* 232 */     for (String key : params.keySet()) {
/* 233 */       kvPairs[idx] = key;
/* 234 */       kvPairs[(idx + 1)] = ((String)params.get(key));
/* 235 */       idx += 2;
/*     */     }
/* 237 */     return addQueryParameters(url, kvPairs);
/*     */   }
/*     */ 
/*     */   public static String prepareOAuthHeader(String[] kvPairs)
/*     */   {
/* 260 */     StringBuilder sb = new StringBuilder("OAuth ");
/* 261 */     for (int i = 0; i < kvPairs.length; i += 2) {
/* 262 */       if (i > 0) {
/* 263 */         sb.append(", ");
/*     */       }
/* 265 */       String value = kvPairs[i].startsWith("oauth_") ? percentEncode(kvPairs[(i + 1)]) : kvPairs[(i + 1)];
/*     */ 
/* 267 */       sb.append(new StringBuilder().append(percentEncode(kvPairs[i])).append("=\"").append(value).append("\"").toString());
/*     */     }
/* 269 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static HttpParameters oauthHeaderToParamsMap(String oauthHeader) {
/* 273 */     HttpParameters params = new HttpParameters();
/* 274 */     if ((oauthHeader == null) || (!oauthHeader.startsWith("OAuth "))) {
/* 275 */       return params;
/*     */     }
/* 277 */     oauthHeader = oauthHeader.substring("OAuth ".length());
/* 278 */     String[] elements = oauthHeader.split(",");
/* 279 */     for (String keyValuePair : elements) {
/* 280 */       String[] keyValue = keyValuePair.split("=");
/* 281 */       params.put(keyValue[0].trim(), keyValue[1].replace("\"", "").trim());
/*     */     }
/* 283 */     return params;
/*     */   }
/*     */ 
/*     */   public static String toHeaderElement(String name, String value)
/*     */   {
/* 298 */     return new StringBuilder().append(percentEncode(name)).append("=\"").append(percentEncode(value)).append("\"").toString();
/*     */   }
/*     */ 
/*     */   public static void debugOut(String key, String value) {
/* 302 */     if (System.getProperty("debug") != null)
/* 303 */       System.out.println(new StringBuilder().append("[SIGNPOST] ").append(key).append(": ").append(value).toString());
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.OAuth
 * JD-Core Version:    0.6.0
 */