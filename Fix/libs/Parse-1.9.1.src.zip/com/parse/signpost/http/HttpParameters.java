/*     */ package com.parse.signpost.http;
/*     */ 
/*     */ import com.parse.signpost.OAuth;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ public class HttpParameters
/*     */   implements Map<String, SortedSet<String>>, Serializable
/*     */ {
/*  43 */   private TreeMap<String, SortedSet<String>> wrappedMap = new TreeMap();
/*     */ 
/*     */   public SortedSet<String> put(String key, SortedSet<String> value) {
/*  46 */     return (SortedSet)this.wrappedMap.put(key, value);
/*     */   }
/*     */ 
/*     */   public SortedSet<String> put(String key, SortedSet<String> values, boolean percentEncode) {
/*  50 */     if (percentEncode) {
/*  51 */       remove(key);
/*  52 */       for (String v : values) {
/*  53 */         put(key, v, true);
/*     */       }
/*  55 */       return get(key);
/*     */     }
/*  57 */     return (SortedSet)this.wrappedMap.put(key, values);
/*     */   }
/*     */ 
/*     */   public String put(String key, String value)
/*     */   {
/*  72 */     return put(key, value, false);
/*     */   }
/*     */ 
/*     */   public String put(String key, String value, boolean percentEncode)
/*     */   {
/*  89 */     SortedSet values = (SortedSet)this.wrappedMap.get(key);
/*  90 */     if (values == null) {
/*  91 */       values = new TreeSet();
/*  92 */       this.wrappedMap.put(percentEncode ? OAuth.percentEncode(key) : key, values);
/*     */     }
/*  94 */     if (value != null) {
/*  95 */       value = percentEncode ? OAuth.percentEncode(value) : value;
/*  96 */       values.add(value);
/*     */     }
/*     */ 
/*  99 */     return value;
/*     */   }
/*     */ 
/*     */   public String putNull(String key, String nullString)
/*     */   {
/* 113 */     return put(key, nullString);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends String, ? extends SortedSet<String>> m) {
/* 117 */     this.wrappedMap.putAll(m);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends String, ? extends SortedSet<String>> m, boolean percentEncode) {
/* 121 */     if (percentEncode) {
/* 122 */       for (String key : m.keySet())
/* 123 */         put(key, (SortedSet)m.get(key), true);
/*     */     }
/*     */     else
/* 126 */       this.wrappedMap.putAll(m);
/*     */   }
/*     */ 
/*     */   public void putAll(String[] keyValuePairs, boolean percentEncode)
/*     */   {
/* 131 */     for (int i = 0; i < keyValuePairs.length - 1; i += 2)
/* 132 */       put(keyValuePairs[i], keyValuePairs[(i + 1)], percentEncode);
/*     */   }
/*     */ 
/*     */   public void putMap(Map<String, List<String>> m)
/*     */   {
/* 143 */     for (String key : m.keySet()) {
/* 144 */       SortedSet vals = get(key);
/* 145 */       if (vals == null) {
/* 146 */         vals = new TreeSet();
/* 147 */         put(key, vals);
/*     */       }
/* 149 */       vals.addAll((Collection)m.get(key));
/*     */     }
/*     */   }
/*     */ 
/*     */   public SortedSet<String> get(Object key) {
/* 154 */     return (SortedSet)this.wrappedMap.get(key);
/*     */   }
/*     */ 
/*     */   public String getFirst(Object key)
/*     */   {
/* 166 */     return getFirst(key, false);
/*     */   }
/*     */ 
/*     */   public String getFirst(Object key, boolean percentDecode)
/*     */   {
/* 185 */     SortedSet values = (SortedSet)this.wrappedMap.get(key);
/* 186 */     if ((values == null) || (values.isEmpty())) {
/* 187 */       return null;
/*     */     }
/* 189 */     String value = (String)values.first();
/* 190 */     return percentDecode ? OAuth.percentDecode(value) : value;
/*     */   }
/*     */ 
/*     */   public String getAsQueryString(Object key)
/*     */   {
/* 202 */     StringBuilder sb = new StringBuilder();
/* 203 */     key = OAuth.percentEncode((String)key);
/* 204 */     Set values = (Set)this.wrappedMap.get(key);
/* 205 */     if (values == null) {
/* 206 */       return new StringBuilder().append(key).append("=").toString();
/*     */     }
/* 208 */     Iterator iter = values.iterator();
/* 209 */     while (iter.hasNext()) {
/* 210 */       sb.append(new StringBuilder().append(key).append("=").append((String)iter.next()).toString());
/* 211 */       if (iter.hasNext()) {
/* 212 */         sb.append("&");
/*     */       }
/*     */     }
/* 215 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getAsHeaderElement(String key) {
/* 219 */     String value = getFirst(key);
/* 220 */     if (value == null) {
/* 221 */       return null;
/*     */     }
/* 223 */     return new StringBuilder().append(key).append("=\"").append(value).append("\"").toString();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key) {
/* 227 */     return this.wrappedMap.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value) {
/* 231 */     for (Set values : this.wrappedMap.values()) {
/* 232 */       if (values.contains(value)) {
/* 233 */         return true;
/*     */       }
/*     */     }
/* 236 */     return false;
/*     */   }
/*     */ 
/*     */   public int size() {
/* 240 */     int count = 0;
/* 241 */     for (String key : this.wrappedMap.keySet()) {
/* 242 */       count += ((SortedSet)this.wrappedMap.get(key)).size();
/*     */     }
/* 244 */     return count;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/* 248 */     return this.wrappedMap.isEmpty();
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 252 */     this.wrappedMap.clear();
/*     */   }
/*     */ 
/*     */   public SortedSet<String> remove(Object key) {
/* 256 */     return (SortedSet)this.wrappedMap.remove(key);
/*     */   }
/*     */ 
/*     */   public Set<String> keySet() {
/* 260 */     return this.wrappedMap.keySet();
/*     */   }
/*     */ 
/*     */   public Collection<SortedSet<String>> values() {
/* 264 */     return this.wrappedMap.values();
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<String, SortedSet<String>>> entrySet() {
/* 268 */     return this.wrappedMap.entrySet();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.http.HttpParameters
 * JD-Core Version:    0.6.0
 */