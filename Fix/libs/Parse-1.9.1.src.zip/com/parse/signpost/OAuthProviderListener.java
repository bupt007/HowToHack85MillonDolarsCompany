package com.parse.signpost;

import com.parse.signpost.http.HttpRequest;
import com.parse.signpost.http.HttpResponse;

public abstract interface OAuthProviderListener
{
  public abstract void prepareRequest(HttpRequest paramHttpRequest)
    throws Exception;

  public abstract void prepareSubmission(HttpRequest paramHttpRequest)
    throws Exception;

  public abstract boolean onResponseReceived(HttpRequest paramHttpRequest, HttpResponse paramHttpResponse)
    throws Exception;
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.OAuthProviderListener
 * JD-Core Version:    0.6.0
 */