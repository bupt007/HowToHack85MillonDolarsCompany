/*     */ package com.parse.signpost;
/*     */ 
/*     */ import com.parse.signpost.basic.UrlStringRequestAdapter;
/*     */ import com.parse.signpost.exception.OAuthCommunicationException;
/*     */ import com.parse.signpost.exception.OAuthExpectationFailedException;
/*     */ import com.parse.signpost.exception.OAuthMessageSignerException;
/*     */ import com.parse.signpost.http.HttpParameters;
/*     */ import com.parse.signpost.http.HttpRequest;
/*     */ import com.parse.signpost.signature.AuthorizationHeaderSigningStrategy;
/*     */ import com.parse.signpost.signature.HmacSha1MessageSigner;
/*     */ import com.parse.signpost.signature.OAuthMessageSigner;
/*     */ import com.parse.signpost.signature.QueryStringSigningStrategy;
/*     */ import com.parse.signpost.signature.SigningStrategy;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Random;
/*     */ 
/*     */ public abstract class AbstractOAuthConsumer
/*     */   implements OAuthConsumer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String consumerKey;
/*     */   private String consumerSecret;
/*     */   private String token;
/*     */   private OAuthMessageSigner messageSigner;
/*     */   private SigningStrategy signingStrategy;
/*     */   private HttpParameters additionalParameters;
/*     */   private HttpParameters requestParameters;
/*     */   private boolean sendEmptyTokens;
/*     */ 
/*     */   public AbstractOAuthConsumer(String consumerKey, String consumerSecret)
/*     */   {
/*  63 */     this.consumerKey = consumerKey;
/*  64 */     this.consumerSecret = consumerSecret;
/*  65 */     setMessageSigner(new HmacSha1MessageSigner());
/*  66 */     setSigningStrategy(new AuthorizationHeaderSigningStrategy());
/*     */   }
/*     */ 
/*     */   public void setMessageSigner(OAuthMessageSigner messageSigner) {
/*  70 */     this.messageSigner = messageSigner;
/*  71 */     messageSigner.setConsumerSecret(this.consumerSecret);
/*     */   }
/*     */ 
/*     */   public void setSigningStrategy(SigningStrategy signingStrategy) {
/*  75 */     this.signingStrategy = signingStrategy;
/*     */   }
/*     */ 
/*     */   public void setAdditionalParameters(HttpParameters additionalParameters) {
/*  79 */     this.additionalParameters = additionalParameters;
/*     */   }
/*     */ 
/*     */   public HttpRequest sign(HttpRequest request) throws OAuthMessageSignerException, OAuthExpectationFailedException, OAuthCommunicationException
/*     */   {
/*  84 */     if (this.consumerKey == null) {
/*  85 */       throw new OAuthExpectationFailedException("consumer key not set");
/*     */     }
/*  87 */     if (this.consumerSecret == null) {
/*  88 */       throw new OAuthExpectationFailedException("consumer secret not set");
/*     */     }
/*     */ 
/*  91 */     this.requestParameters = new HttpParameters();
/*     */     try {
/*  93 */       if (this.additionalParameters != null) {
/*  94 */         this.requestParameters.putAll(this.additionalParameters, false);
/*     */       }
/*  96 */       collectHeaderParameters(request, this.requestParameters);
/*  97 */       collectQueryParameters(request, this.requestParameters);
/*  98 */       collectBodyParameters(request, this.requestParameters);
/*     */ 
/* 101 */       completeOAuthParameters(this.requestParameters);
/*     */ 
/* 103 */       this.requestParameters.remove("oauth_signature");
/*     */     }
/*     */     catch (IOException e) {
/* 106 */       throw new OAuthCommunicationException(e);
/*     */     }
/*     */ 
/* 109 */     String signature = this.messageSigner.sign(request, this.requestParameters);
/* 110 */     OAuth.debugOut("signature", signature);
/*     */ 
/* 112 */     this.signingStrategy.writeSignature(signature, request, this.requestParameters);
/* 113 */     OAuth.debugOut("Auth header", request.getHeader("Authorization"));
/* 114 */     OAuth.debugOut("Request URL", request.getRequestUrl());
/*     */ 
/* 116 */     return request;
/*     */   }
/*     */ 
/*     */   public HttpRequest sign(Object request) throws OAuthMessageSignerException, OAuthExpectationFailedException, OAuthCommunicationException
/*     */   {
/* 121 */     return sign(wrap(request));
/*     */   }
/*     */ 
/*     */   public String sign(String url) throws OAuthMessageSignerException, OAuthExpectationFailedException, OAuthCommunicationException
/*     */   {
/* 126 */     HttpRequest request = new UrlStringRequestAdapter(url);
/*     */ 
/* 129 */     SigningStrategy oldStrategy = this.signingStrategy;
/* 130 */     this.signingStrategy = new QueryStringSigningStrategy();
/*     */ 
/* 132 */     sign(request);
/*     */ 
/* 135 */     this.signingStrategy = oldStrategy;
/*     */ 
/* 137 */     return request.getRequestUrl();
/*     */   }
/*     */ 
/*     */   protected abstract HttpRequest wrap(Object paramObject);
/*     */ 
/*     */   public void setTokenWithSecret(String token, String tokenSecret)
/*     */   {
/* 151 */     this.token = token;
/* 152 */     this.messageSigner.setTokenSecret(tokenSecret);
/*     */   }
/*     */ 
/*     */   public String getToken() {
/* 156 */     return this.token;
/*     */   }
/*     */ 
/*     */   public String getTokenSecret() {
/* 160 */     return this.messageSigner.getTokenSecret();
/*     */   }
/*     */ 
/*     */   public String getConsumerKey() {
/* 164 */     return this.consumerKey;
/*     */   }
/*     */ 
/*     */   public String getConsumerSecret() {
/* 168 */     return this.consumerSecret;
/*     */   }
/*     */ 
/*     */   protected void completeOAuthParameters(HttpParameters out)
/*     */   {
/* 188 */     if (!out.containsKey("oauth_consumer_key")) {
/* 189 */       out.put("oauth_consumer_key", this.consumerKey, true);
/*     */     }
/* 191 */     if (!out.containsKey("oauth_signature_method")) {
/* 192 */       out.put("oauth_signature_method", this.messageSigner.getSignatureMethod(), true);
/*     */     }
/* 194 */     if (!out.containsKey("oauth_timestamp")) {
/* 195 */       out.put("oauth_timestamp", generateTimestamp(), true);
/*     */     }
/* 197 */     if (!out.containsKey("oauth_nonce")) {
/* 198 */       out.put("oauth_nonce", generateNonce(), true);
/*     */     }
/* 200 */     if (!out.containsKey("oauth_version")) {
/* 201 */       out.put("oauth_version", "1.0", true);
/*     */     }
/* 203 */     if ((!out.containsKey("oauth_token")) && (
/* 204 */       ((this.token != null) && (!this.token.equals(""))) || (this.sendEmptyTokens)))
/* 205 */       out.put("oauth_token", this.token, true);
/*     */   }
/*     */ 
/*     */   public HttpParameters getRequestParameters()
/*     */   {
/* 211 */     return this.requestParameters;
/*     */   }
/*     */ 
/*     */   public void setSendEmptyTokens(boolean enable) {
/* 215 */     this.sendEmptyTokens = enable;
/*     */   }
/*     */ 
/*     */   protected void collectHeaderParameters(HttpRequest request, HttpParameters out)
/*     */   {
/* 223 */     HttpParameters headerParams = OAuth.oauthHeaderToParamsMap(request.getHeader("Authorization"));
/* 224 */     out.putAll(headerParams, false);
/*     */   }
/*     */ 
/*     */   protected void collectBodyParameters(HttpRequest request, HttpParameters out)
/*     */     throws IOException
/*     */   {
/* 235 */     String contentType = request.getContentType();
/* 236 */     if ((contentType != null) && (contentType.startsWith("application/x-www-form-urlencoded"))) {
/* 237 */       InputStream payload = request.getMessagePayload();
/* 238 */       out.putAll(OAuth.decodeForm(payload), true);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void collectQueryParameters(HttpRequest request, HttpParameters out)
/*     */   {
/* 248 */     String url = request.getRequestUrl();
/* 249 */     int q = url.indexOf('?');
/* 250 */     if (q >= 0)
/*     */     {
/* 252 */       out.putAll(OAuth.decodeForm(url.substring(q + 1)), true);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String generateTimestamp() {
/* 257 */     return Long.toString(System.currentTimeMillis() / 1000L);
/*     */   }
/*     */ 
/*     */   protected String generateNonce() {
/* 261 */     return Long.toString(new Random().nextLong());
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.AbstractOAuthConsumer
 * JD-Core Version:    0.6.0
 */