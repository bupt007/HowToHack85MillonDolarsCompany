/*    */ package com.parse.signpost.basic;
/*    */ 
/*    */ import com.parse.signpost.AbstractOAuthProvider;
/*    */ import com.parse.signpost.http.HttpRequest;
/*    */ import com.parse.signpost.http.HttpResponse;
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ 
/*    */ public class DefaultOAuthProvider extends AbstractOAuthProvider
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public DefaultOAuthProvider(String requestTokenEndpointUrl, String accessTokenEndpointUrl, String authorizationWebsiteUrl)
/*    */   {
/* 36 */     super(requestTokenEndpointUrl, accessTokenEndpointUrl, authorizationWebsiteUrl);
/*    */   }
/*    */ 
/*    */   protected HttpRequest createRequest(String endpointUrl) throws MalformedURLException, IOException
/*    */   {
/* 41 */     HttpURLConnection connection = (HttpURLConnection)new URL(endpointUrl).openConnection();
/* 42 */     connection.setRequestMethod("POST");
/* 43 */     connection.setAllowUserInteraction(false);
/* 44 */     connection.setRequestProperty("Content-Length", "0");
/* 45 */     return new HttpURLConnectionRequestAdapter(connection);
/*    */   }
/*    */ 
/*    */   protected HttpResponse sendRequest(HttpRequest request) throws IOException {
/* 49 */     HttpURLConnection connection = (HttpURLConnection)request.unwrap();
/* 50 */     connection.connect();
/* 51 */     return new HttpURLConnectionResponseAdapter(connection);
/*    */   }
/*    */ 
/*    */   protected void closeConnection(HttpRequest request, HttpResponse response)
/*    */   {
/* 56 */     HttpURLConnection connection = (HttpURLConnection)request.unwrap();
/* 57 */     if (connection != null)
/* 58 */       connection.disconnect();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.basic.DefaultOAuthProvider
 * JD-Core Version:    0.6.0
 */