/*    */ package com.parse.signpost.basic;
/*    */ 
/*    */ import com.parse.signpost.http.HttpRequest;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class UrlStringRequestAdapter
/*    */   implements HttpRequest
/*    */ {
/*    */   private String url;
/*    */ 
/*    */   public UrlStringRequestAdapter(String url)
/*    */   {
/* 17 */     this.url = url;
/*    */   }
/*    */ 
/*    */   public String getMethod() {
/* 21 */     return "GET";
/*    */   }
/*    */ 
/*    */   public String getRequestUrl() {
/* 25 */     return this.url;
/*    */   }
/*    */ 
/*    */   public void setRequestUrl(String url) {
/* 29 */     this.url = url;
/*    */   }
/*    */ 
/*    */   public void setHeader(String name, String value) {
/*    */   }
/*    */ 
/*    */   public String getHeader(String name) {
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   public Map<String, String> getAllHeaders() {
/* 40 */     return Collections.emptyMap();
/*    */   }
/*    */ 
/*    */   public InputStream getMessagePayload() throws IOException {
/* 44 */     return null;
/*    */   }
/*    */ 
/*    */   public String getContentType() {
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   public Object unwrap() {
/* 52 */     return this.url;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.basic.UrlStringRequestAdapter
 * JD-Core Version:    0.6.0
 */