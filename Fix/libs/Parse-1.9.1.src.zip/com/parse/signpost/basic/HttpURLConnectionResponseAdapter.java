/*    */ package com.parse.signpost.basic;
/*    */ 
/*    */ import com.parse.signpost.http.HttpResponse;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.HttpURLConnection;
/*    */ 
/*    */ public class HttpURLConnectionResponseAdapter
/*    */   implements HttpResponse
/*    */ {
/*    */   private HttpURLConnection connection;
/*    */ 
/*    */   public HttpURLConnectionResponseAdapter(HttpURLConnection connection)
/*    */   {
/* 16 */     this.connection = connection;
/*    */   }
/*    */ 
/*    */   public InputStream getContent() throws IOException {
/* 20 */     return this.connection.getInputStream();
/*    */   }
/*    */ 
/*    */   public int getStatusCode() throws IOException {
/* 24 */     return this.connection.getResponseCode();
/*    */   }
/*    */ 
/*    */   public String getReasonPhrase() throws Exception {
/* 28 */     return this.connection.getResponseMessage();
/*    */   }
/*    */ 
/*    */   public Object unwrap() {
/* 32 */     return this.connection;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.basic.HttpURLConnectionResponseAdapter
 * JD-Core Version:    0.6.0
 */