/*    */ package com.parse.signpost.basic;
/*    */ 
/*    */ import com.parse.signpost.AbstractOAuthConsumer;
/*    */ import com.parse.signpost.http.HttpRequest;
/*    */ import java.net.HttpURLConnection;
/*    */ 
/*    */ public class DefaultOAuthConsumer extends AbstractOAuthConsumer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public DefaultOAuthConsumer(String consumerKey, String consumerSecret)
/*    */   {
/* 35 */     super(consumerKey, consumerSecret);
/*    */   }
/*    */ 
/*    */   protected HttpRequest wrap(Object request)
/*    */   {
/* 40 */     if (!(request instanceof HttpURLConnection)) {
/* 41 */       throw new IllegalArgumentException("The default consumer expects requests of type java.net.HttpURLConnection");
/*    */     }
/*    */ 
/* 44 */     return new HttpURLConnectionRequestAdapter((HttpURLConnection)request);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.basic.DefaultOAuthConsumer
 * JD-Core Version:    0.6.0
 */