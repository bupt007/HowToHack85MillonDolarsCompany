/*     */ package com.parse.signpost;
/*     */ 
/*     */ import com.parse.signpost.exception.OAuthCommunicationException;
/*     */ import com.parse.signpost.exception.OAuthExpectationFailedException;
/*     */ import com.parse.signpost.exception.OAuthMessageSignerException;
/*     */ import com.parse.signpost.exception.OAuthNotAuthorizedException;
/*     */ import com.parse.signpost.http.HttpParameters;
/*     */ import com.parse.signpost.http.HttpRequest;
/*     */ import com.parse.signpost.http.HttpResponse;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public abstract class AbstractOAuthProvider
/*     */   implements OAuthProvider
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String requestTokenEndpointUrl;
/*     */   private String accessTokenEndpointUrl;
/*     */   private String authorizationWebsiteUrl;
/*     */   private HttpParameters responseParameters;
/*     */   private Map<String, String> defaultHeaders;
/*     */   private boolean isOAuth10a;
/*     */   private transient OAuthProviderListener listener;
/*     */ 
/*     */   public AbstractOAuthProvider(String requestTokenEndpointUrl, String accessTokenEndpointUrl, String authorizationWebsiteUrl)
/*     */   {
/*  54 */     this.requestTokenEndpointUrl = requestTokenEndpointUrl;
/*  55 */     this.accessTokenEndpointUrl = accessTokenEndpointUrl;
/*  56 */     this.authorizationWebsiteUrl = authorizationWebsiteUrl;
/*  57 */     this.responseParameters = new HttpParameters();
/*  58 */     this.defaultHeaders = new HashMap();
/*     */   }
/*     */ 
/*     */   public String retrieveRequestToken(OAuthConsumer consumer, String callbackUrl)
/*     */     throws OAuthMessageSignerException, OAuthNotAuthorizedException, OAuthExpectationFailedException, OAuthCommunicationException
/*     */   {
/*  66 */     consumer.setTokenWithSecret(null, null);
/*     */ 
/*  70 */     retrieveToken(consumer, this.requestTokenEndpointUrl, new String[] { "oauth_callback", callbackUrl });
/*     */ 
/*  72 */     String callbackConfirmed = this.responseParameters.getFirst("oauth_callback_confirmed");
/*  73 */     this.responseParameters.remove("oauth_callback_confirmed");
/*  74 */     this.isOAuth10a = Boolean.TRUE.toString().equals(callbackConfirmed);
/*     */ 
/*  78 */     if (this.isOAuth10a) {
/*  79 */       return OAuth.addQueryParameters(this.authorizationWebsiteUrl, new String[] { "oauth_token", consumer.getToken() });
/*     */     }
/*     */ 
/*  82 */     return OAuth.addQueryParameters(this.authorizationWebsiteUrl, new String[] { "oauth_token", consumer.getToken(), "oauth_callback", callbackUrl });
/*     */   }
/*     */ 
/*     */   public void retrieveAccessToken(OAuthConsumer consumer, String oauthVerifier)
/*     */     throws OAuthMessageSignerException, OAuthNotAuthorizedException, OAuthExpectationFailedException, OAuthCommunicationException
/*     */   {
/*  91 */     if ((consumer.getToken() == null) || (consumer.getTokenSecret() == null)) {
/*  92 */       throw new OAuthExpectationFailedException("Authorized request token or token secret not set. Did you retrieve an authorized request token before?");
/*     */     }
/*     */ 
/*  97 */     if ((this.isOAuth10a) && (oauthVerifier != null))
/*  98 */       retrieveToken(consumer, this.accessTokenEndpointUrl, new String[] { "oauth_verifier", oauthVerifier });
/*     */     else
/* 100 */       retrieveToken(consumer, this.accessTokenEndpointUrl, new String[0]);
/*     */   }
/*     */ 
/*     */   protected void retrieveToken(OAuthConsumer consumer, String endpointUrl, String[] additionalParameters)
/*     */     throws OAuthMessageSignerException, OAuthCommunicationException, OAuthNotAuthorizedException, OAuthExpectationFailedException
/*     */   {
/* 149 */     Map defaultHeaders = getRequestHeaders();
/*     */ 
/* 151 */     if ((consumer.getConsumerKey() == null) || (consumer.getConsumerSecret() == null)) {
/* 152 */       throw new OAuthExpectationFailedException("Consumer key or secret not set");
/*     */     }
/*     */ 
/* 155 */     HttpRequest request = null;
/* 156 */     HttpResponse response = null;
/*     */     try {
/* 158 */       request = createRequest(endpointUrl);
/* 159 */       for (String header : defaultHeaders.keySet()) {
/* 160 */         request.setHeader(header, (String)defaultHeaders.get(header));
/*     */       }
/* 162 */       if (additionalParameters != null) {
/* 163 */         HttpParameters httpParams = new HttpParameters();
/* 164 */         httpParams.putAll(additionalParameters, true);
/* 165 */         consumer.setAdditionalParameters(httpParams);
/*     */       }
/*     */ 
/* 168 */       if (this.listener != null) {
/* 169 */         this.listener.prepareRequest(request);
/*     */       }
/*     */ 
/* 172 */       consumer.sign(request);
/*     */ 
/* 174 */       if (this.listener != null) {
/* 175 */         this.listener.prepareSubmission(request);
/*     */       }
/*     */ 
/* 178 */       response = sendRequest(request);
/* 179 */       int statusCode = response.getStatusCode();
/*     */ 
/* 181 */       boolean requestHandled = false;
/* 182 */       if (this.listener != null) {
/* 183 */         requestHandled = this.listener.onResponseReceived(request, response);
/*     */       }
/* 185 */       if (requestHandled) {
/*     */         return;
/*     */       }
/* 189 */       if (statusCode >= 300) {
/* 190 */         handleUnexpectedResponse(statusCode, response);
/*     */       }
/*     */ 
/* 193 */       HttpParameters responseParams = OAuth.decodeForm(response.getContent());
/*     */ 
/* 195 */       String token = responseParams.getFirst("oauth_token");
/* 196 */       String secret = responseParams.getFirst("oauth_token_secret");
/* 197 */       responseParams.remove("oauth_token");
/* 198 */       responseParams.remove("oauth_token_secret");
/*     */ 
/* 200 */       setResponseParameters(responseParams);
/*     */ 
/* 202 */       if ((token == null) || (secret == null)) {
/* 203 */         throw new OAuthExpectationFailedException("Request token or token secret not set in server reply. The service provider you use is probably buggy.");
/*     */       }
/*     */ 
/* 208 */       consumer.setTokenWithSecret(token, secret);
/*     */     }
/*     */     catch (OAuthNotAuthorizedException e) {
/* 211 */       throw e;
/*     */     } catch (OAuthExpectationFailedException e) {
/* 213 */       throw e;
/*     */     } catch (Exception e) {
/* 215 */       throw new OAuthCommunicationException(e);
/*     */     } finally {
/*     */       try {
/* 218 */         closeConnection(request, response);
/*     */       } catch (Exception e) {
/* 220 */         throw new OAuthCommunicationException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void handleUnexpectedResponse(int statusCode, HttpResponse response) throws Exception {
/* 226 */     if (response == null) {
/* 227 */       return;
/*     */     }
/* 229 */     BufferedReader reader = new BufferedReader(new InputStreamReader(response.getContent()), 8192);
/*     */ 
/* 232 */     StringBuilder responseBody = new StringBuilder();
/*     */ 
/* 234 */     String line = reader.readLine();
/* 235 */     while (line != null) {
/* 236 */       responseBody.append(line);
/* 237 */       line = reader.readLine();
/*     */     }
/*     */ 
/* 240 */     switch (statusCode) {
/*     */     case 401:
/* 242 */       throw new OAuthNotAuthorizedException(responseBody.toString());
/*     */     }
/* 244 */     throw new OAuthCommunicationException(new StringBuilder().append("Service provider responded in error: ").append(statusCode).append(" (").append(response.getReasonPhrase()).append(")").toString(), responseBody.toString());
/*     */   }
/*     */ 
/*     */   protected abstract HttpRequest createRequest(String paramString)
/*     */     throws Exception;
/*     */ 
/*     */   protected abstract HttpResponse sendRequest(HttpRequest paramHttpRequest)
/*     */     throws Exception;
/*     */ 
/*     */   protected void closeConnection(HttpRequest request, HttpResponse response)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public HttpParameters getResponseParameters()
/*     */   {
/* 289 */     return this.responseParameters;
/*     */   }
/*     */ 
/*     */   protected String getResponseParameter(String key)
/*     */   {
/* 302 */     return this.responseParameters.getFirst(key);
/*     */   }
/*     */ 
/*     */   public void setResponseParameters(HttpParameters parameters) {
/* 306 */     this.responseParameters = parameters;
/*     */   }
/*     */ 
/*     */   public void setOAuth10a(boolean isOAuth10aProvider) {
/* 310 */     this.isOAuth10a = isOAuth10aProvider;
/*     */   }
/*     */ 
/*     */   public boolean isOAuth10a() {
/* 314 */     return this.isOAuth10a;
/*     */   }
/*     */ 
/*     */   public String getRequestTokenEndpointUrl() {
/* 318 */     return this.requestTokenEndpointUrl;
/*     */   }
/*     */ 
/*     */   public String getAccessTokenEndpointUrl() {
/* 322 */     return this.accessTokenEndpointUrl;
/*     */   }
/*     */ 
/*     */   public String getAuthorizationWebsiteUrl() {
/* 326 */     return this.authorizationWebsiteUrl;
/*     */   }
/*     */ 
/*     */   public void setRequestHeader(String header, String value) {
/* 330 */     this.defaultHeaders.put(header, value);
/*     */   }
/*     */ 
/*     */   public Map<String, String> getRequestHeaders() {
/* 334 */     return this.defaultHeaders;
/*     */   }
/*     */ 
/*     */   public void setListener(OAuthProviderListener listener) {
/* 338 */     this.listener = listener;
/*     */   }
/*     */ 
/*     */   public void removeListener(OAuthProviderListener listener) {
/* 342 */     this.listener = null;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.AbstractOAuthProvider
 * JD-Core Version:    0.6.0
 */