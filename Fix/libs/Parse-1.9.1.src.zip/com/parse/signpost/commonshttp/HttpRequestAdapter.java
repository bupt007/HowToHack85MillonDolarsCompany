/*    */ package com.parse.signpost.commonshttp;
/*    */ 
/*    */ import com.parse.signpost.http.HttpRequest;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URI;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.http.Header;
/*    */ import org.apache.http.HttpEntity;
/*    */ import org.apache.http.HttpEntityEnclosingRequest;
/*    */ import org.apache.http.RequestLine;
/*    */ import org.apache.http.client.methods.HttpUriRequest;
/*    */ 
/*    */ public class HttpRequestAdapter
/*    */   implements HttpRequest
/*    */ {
/*    */   private HttpUriRequest request;
/*    */   private HttpEntity entity;
/*    */ 
/*    */   public HttpRequestAdapter(HttpUriRequest request)
/*    */   {
/* 21 */     this.request = request;
/* 22 */     if ((request instanceof HttpEntityEnclosingRequest))
/* 23 */       this.entity = ((HttpEntityEnclosingRequest)request).getEntity();
/*    */   }
/*    */ 
/*    */   public String getMethod()
/*    */   {
/* 28 */     return this.request.getRequestLine().getMethod();
/*    */   }
/*    */ 
/*    */   public String getRequestUrl() {
/* 32 */     return this.request.getURI().toString();
/*    */   }
/*    */ 
/*    */   public void setRequestUrl(String url) {
/* 36 */     throw new RuntimeException(new UnsupportedOperationException());
/*    */   }
/*    */ 
/*    */   public String getHeader(String name) {
/* 40 */     Header header = this.request.getFirstHeader(name);
/* 41 */     if (header == null) {
/* 42 */       return null;
/*    */     }
/* 44 */     return header.getValue();
/*    */   }
/*    */ 
/*    */   public void setHeader(String name, String value) {
/* 48 */     this.request.setHeader(name, value);
/*    */   }
/*    */ 
/*    */   public Map<String, String> getAllHeaders() {
/* 52 */     Header[] origHeaders = this.request.getAllHeaders();
/* 53 */     HashMap headers = new HashMap();
/* 54 */     for (Header h : origHeaders) {
/* 55 */       headers.put(h.getName(), h.getValue());
/*    */     }
/* 57 */     return headers;
/*    */   }
/*    */ 
/*    */   public String getContentType() {
/* 61 */     if (this.entity == null) {
/* 62 */       return null;
/*    */     }
/* 64 */     Header header = this.entity.getContentType();
/* 65 */     if (header == null) {
/* 66 */       return null;
/*    */     }
/* 68 */     return header.getValue();
/*    */   }
/*    */ 
/*    */   public InputStream getMessagePayload() throws IOException {
/* 72 */     if (this.entity == null) {
/* 73 */       return null;
/*    */     }
/* 75 */     return this.entity.getContent();
/*    */   }
/*    */ 
/*    */   public Object unwrap() {
/* 79 */     return this.request;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.commonshttp.HttpRequestAdapter
 * JD-Core Version:    0.6.0
 */