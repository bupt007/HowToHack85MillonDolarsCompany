/*    */ package com.parse.signpost.commonshttp;
/*    */ 
/*    */ import com.parse.signpost.AbstractOAuthConsumer;
/*    */ import org.apache.http.client.methods.HttpUriRequest;
/*    */ 
/*    */ public class CommonsHttpOAuthConsumer extends AbstractOAuthConsumer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public CommonsHttpOAuthConsumer(String consumerKey, String consumerSecret)
/*    */   {
/* 31 */     super(consumerKey, consumerSecret);
/*    */   }
/*    */ 
/*    */   protected com.parse.signpost.http.HttpRequest wrap(Object request)
/*    */   {
/* 36 */     if (!(request instanceof org.apache.http.HttpRequest)) {
/* 37 */       throw new IllegalArgumentException("This consumer expects requests of type " + org.apache.http.HttpRequest.class.getCanonicalName());
/*    */     }
/*    */ 
/* 42 */     return new HttpRequestAdapter((HttpUriRequest)request);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.commonshttp.CommonsHttpOAuthConsumer
 * JD-Core Version:    0.6.0
 */