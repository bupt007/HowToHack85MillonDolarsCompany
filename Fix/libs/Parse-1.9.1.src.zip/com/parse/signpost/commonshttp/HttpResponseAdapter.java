/*    */ package com.parse.signpost.commonshttp;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.http.HttpEntity;
/*    */ import org.apache.http.StatusLine;
/*    */ 
/*    */ public class HttpResponseAdapter
/*    */   implements com.parse.signpost.http.HttpResponse
/*    */ {
/*    */   private org.apache.http.HttpResponse response;
/*    */ 
/*    */   public HttpResponseAdapter(org.apache.http.HttpResponse response)
/*    */   {
/* 14 */     this.response = response;
/*    */   }
/*    */ 
/*    */   public InputStream getContent() throws IOException {
/* 18 */     return this.response.getEntity().getContent();
/*    */   }
/*    */ 
/*    */   public int getStatusCode() throws IOException {
/* 22 */     return this.response.getStatusLine().getStatusCode();
/*    */   }
/*    */ 
/*    */   public String getReasonPhrase() throws Exception {
/* 26 */     return this.response.getStatusLine().getReasonPhrase();
/*    */   }
/*    */ 
/*    */   public Object unwrap() {
/* 30 */     return this.response;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.commonshttp.HttpResponseAdapter
 * JD-Core Version:    0.6.0
 */