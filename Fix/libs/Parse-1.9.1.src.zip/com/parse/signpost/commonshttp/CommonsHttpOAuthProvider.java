/*    */ package com.parse.signpost.commonshttp;
/*    */ 
/*    */ import com.parse.signpost.AbstractOAuthProvider;
/*    */ import com.parse.signpost.http.HttpRequest;
/*    */ import java.io.IOException;
/*    */ import org.apache.http.HttpEntity;
/*    */ import org.apache.http.client.HttpClient;
/*    */ import org.apache.http.client.methods.HttpPost;
/*    */ import org.apache.http.client.methods.HttpUriRequest;
/*    */ import org.apache.http.impl.client.DefaultHttpClient;
/*    */ 
/*    */ public class CommonsHttpOAuthProvider extends AbstractOAuthProvider
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private transient HttpClient httpClient;
/*    */ 
/*    */   public CommonsHttpOAuthProvider(String requestTokenEndpointUrl, String accessTokenEndpointUrl, String authorizationWebsiteUrl)
/*    */   {
/* 43 */     super(requestTokenEndpointUrl, accessTokenEndpointUrl, authorizationWebsiteUrl);
/* 44 */     this.httpClient = new DefaultHttpClient();
/*    */   }
/*    */ 
/*    */   public CommonsHttpOAuthProvider(String requestTokenEndpointUrl, String accessTokenEndpointUrl, String authorizationWebsiteUrl, HttpClient httpClient)
/*    */   {
/* 49 */     super(requestTokenEndpointUrl, accessTokenEndpointUrl, authorizationWebsiteUrl);
/* 50 */     this.httpClient = httpClient;
/*    */   }
/*    */ 
/*    */   public void setHttpClient(HttpClient httpClient) {
/* 54 */     this.httpClient = httpClient;
/*    */   }
/*    */ 
/*    */   protected HttpRequest createRequest(String endpointUrl) throws Exception
/*    */   {
/* 59 */     HttpPost request = new HttpPost(endpointUrl);
/* 60 */     return new HttpRequestAdapter(request);
/*    */   }
/*    */ 
/*    */   protected com.parse.signpost.http.HttpResponse sendRequest(HttpRequest request) throws Exception
/*    */   {
/* 65 */     org.apache.http.HttpResponse response = this.httpClient.execute((HttpUriRequest)request.unwrap());
/* 66 */     return new HttpResponseAdapter(response);
/*    */   }
/*    */ 
/*    */   protected void closeConnection(HttpRequest request, com.parse.signpost.http.HttpResponse response)
/*    */     throws Exception
/*    */   {
/* 72 */     if (response != null) {
/* 73 */       HttpEntity entity = ((org.apache.http.HttpResponse)response.unwrap()).getEntity();
/* 74 */       if (entity != null)
/*    */         try
/*    */         {
/* 77 */           entity.consumeContent();
/*    */         }
/*    */         catch (IOException e) {
/* 80 */           e.printStackTrace();
/*    */         }
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.commonshttp.CommonsHttpOAuthProvider
 * JD-Core Version:    0.6.0
 */