/*    */ package com.parse.signpost.exception;
/*    */ 
/*    */ public class OAuthCommunicationException extends OAuthException
/*    */ {
/*    */   private String responseBody;
/*    */ 
/*    */   public OAuthCommunicationException(Exception cause)
/*    */   {
/* 24 */     super("Communication with the service provider failed: " + cause.getLocalizedMessage(), cause);
/*    */   }
/*    */ 
/*    */   public OAuthCommunicationException(String message, String responseBody)
/*    */   {
/* 29 */     super(message);
/* 30 */     this.responseBody = responseBody;
/*    */   }
/*    */ 
/*    */   public String getResponseBody() {
/* 34 */     return this.responseBody;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.exception.OAuthCommunicationException
 * JD-Core Version:    0.6.0
 */