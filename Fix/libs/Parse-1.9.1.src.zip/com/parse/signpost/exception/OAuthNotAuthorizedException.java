/*    */ package com.parse.signpost.exception;
/*    */ 
/*    */ public class OAuthNotAuthorizedException extends OAuthException
/*    */ {
/*    */   private static final String ERROR = "Authorization failed (server replied with a 401). This can happen if the consumer key was not correct or the signatures did not match.";
/*    */   private String responseBody;
/*    */ 
/*    */   public OAuthNotAuthorizedException()
/*    */   {
/* 28 */     super("Authorization failed (server replied with a 401). This can happen if the consumer key was not correct or the signatures did not match.");
/*    */   }
/*    */ 
/*    */   public OAuthNotAuthorizedException(String responseBody) {
/* 32 */     super("Authorization failed (server replied with a 401). This can happen if the consumer key was not correct or the signatures did not match.");
/* 33 */     this.responseBody = responseBody;
/*    */   }
/*    */ 
/*    */   public String getResponseBody() {
/* 37 */     return this.responseBody;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.exception.OAuthNotAuthorizedException
 * JD-Core Version:    0.6.0
 */