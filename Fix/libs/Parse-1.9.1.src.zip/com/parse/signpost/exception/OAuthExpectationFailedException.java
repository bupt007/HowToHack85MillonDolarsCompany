/*    */ package com.parse.signpost.exception;
/*    */ 
/*    */ public class OAuthExpectationFailedException extends OAuthException
/*    */ {
/*    */   public OAuthExpectationFailedException(String message)
/*    */   {
/* 22 */     super(message);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.exception.OAuthExpectationFailedException
 * JD-Core Version:    0.6.0
 */