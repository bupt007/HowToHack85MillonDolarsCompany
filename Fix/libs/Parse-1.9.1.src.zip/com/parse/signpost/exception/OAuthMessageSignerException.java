/*    */ package com.parse.signpost.exception;
/*    */ 
/*    */ public class OAuthMessageSignerException extends OAuthException
/*    */ {
/*    */   public OAuthMessageSignerException(String message)
/*    */   {
/* 22 */     super(message);
/*    */   }
/*    */ 
/*    */   public OAuthMessageSignerException(Exception cause) {
/* 26 */     super(cause);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.exception.OAuthMessageSignerException
 * JD-Core Version:    0.6.0
 */