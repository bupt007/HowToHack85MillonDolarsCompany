/*    */ package com.parse.signpost.exception;
/*    */ 
/*    */ public abstract class OAuthException extends Exception
/*    */ {
/*    */   public OAuthException(String message)
/*    */   {
/*  7 */     super(message);
/*    */   }
/*    */ 
/*    */   public OAuthException(Throwable cause) {
/* 11 */     super(cause);
/*    */   }
/*    */ 
/*    */   public OAuthException(String message, Throwable cause) {
/* 15 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.exception.OAuthException
 * JD-Core Version:    0.6.0
 */