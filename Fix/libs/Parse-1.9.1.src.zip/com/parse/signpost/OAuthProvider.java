package com.parse.signpost;

import com.parse.signpost.exception.OAuthCommunicationException;
import com.parse.signpost.exception.OAuthExpectationFailedException;
import com.parse.signpost.exception.OAuthMessageSignerException;
import com.parse.signpost.exception.OAuthNotAuthorizedException;
import com.parse.signpost.http.HttpParameters;
import java.io.Serializable;
import java.util.Map;

public abstract interface OAuthProvider extends Serializable
{
  public abstract String retrieveRequestToken(OAuthConsumer paramOAuthConsumer, String paramString)
    throws OAuthMessageSignerException, OAuthNotAuthorizedException, OAuthExpectationFailedException, OAuthCommunicationException;

  public abstract void retrieveAccessToken(OAuthConsumer paramOAuthConsumer, String paramString)
    throws OAuthMessageSignerException, OAuthNotAuthorizedException, OAuthExpectationFailedException, OAuthCommunicationException;

  public abstract HttpParameters getResponseParameters();

  public abstract void setResponseParameters(HttpParameters paramHttpParameters);

  @Deprecated
  public abstract void setRequestHeader(String paramString1, String paramString2);

  @Deprecated
  public abstract Map<String, String> getRequestHeaders();

  public abstract void setOAuth10a(boolean paramBoolean);

  public abstract boolean isOAuth10a();

  public abstract String getRequestTokenEndpointUrl();

  public abstract String getAccessTokenEndpointUrl();

  public abstract String getAuthorizationWebsiteUrl();

  public abstract void setListener(OAuthProviderListener paramOAuthProviderListener);

  public abstract void removeListener(OAuthProviderListener paramOAuthProviderListener);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.signpost.OAuthProvider
 * JD-Core Version:    0.6.0
 */