/*    */ package com.parse;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.List;
/*    */ import org.json.JSONArray;
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseAddUniqueOperation
/*    */   implements ParseFieldOperation
/*    */ {
/* 17 */   protected LinkedHashSet<Object> objects = new LinkedHashSet();
/*    */ 
/*    */   public ParseAddUniqueOperation(Collection<?> col) {
/* 20 */     this.objects.addAll(col);
/*    */   }
/*    */ 
/*    */   public JSONObject encode(ParseObjectEncodingStrategy objectEncoder) throws JSONException
/*    */   {
/* 25 */     JSONObject output = new JSONObject();
/* 26 */     output.put("__op", "AddUnique");
/* 27 */     output.put("objects", Parse.encode(new ArrayList(this.objects), objectEncoder));
/* 28 */     return output;
/*    */   }
/*    */ 
/*    */   public ParseFieldOperation mergeWithPrevious(ParseFieldOperation previous)
/*    */   {
/* 34 */     if (previous == null)
/* 35 */       return this;
/* 36 */     if ((previous instanceof ParseDeleteOperation))
/* 37 */       return new ParseSetOperation(this.objects);
/* 38 */     if ((previous instanceof ParseSetOperation)) {
/* 39 */       Object value = ((ParseSetOperation)previous).getValue();
/* 40 */       if (((value instanceof JSONArray)) || ((value instanceof List))) {
/* 41 */         return new ParseSetOperation(apply(value, null, null));
/*    */       }
/* 43 */       throw new IllegalArgumentException("You can only add an item to a List or JSONArray.");
/*    */     }
/* 45 */     if ((previous instanceof ParseAddUniqueOperation)) {
/* 46 */       List previousResult = new ArrayList(((ParseAddUniqueOperation)previous).objects);
/*    */ 
/* 48 */       return new ParseAddUniqueOperation((List)apply(previousResult, null, null));
/*    */     }
/* 50 */     throw new IllegalArgumentException("Operation is invalid after previous operation.");
/*    */   }
/*    */ 
/*    */   public Object apply(Object oldValue, ParseObject object, String key)
/*    */   {
/* 56 */     if (oldValue == null)
/* 57 */       return new ArrayList(this.objects);
/* 58 */     if ((oldValue instanceof JSONArray)) {
/* 59 */       ArrayList old = ParseFieldOperations.jsonArrayAsArrayList((JSONArray)oldValue);
/*    */ 
/* 61 */       ArrayList newValue = (ArrayList)apply(old, object, key);
/* 62 */       return new JSONArray(newValue);
/* 63 */     }if ((oldValue instanceof List)) {
/* 64 */       ArrayList result = new ArrayList((List)oldValue);
/*    */ 
/* 67 */       HashMap existingObjectIds = new HashMap();
/* 68 */       for (int i = 0; i < result.size(); i++) {
/* 69 */         if ((result.get(i) instanceof ParseObject)) {
/* 70 */           existingObjectIds.put(((ParseObject)result.get(i)).getObjectId(), Integer.valueOf(i));
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 76 */       for (Iterator i$ = this.objects.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/* 77 */         if ((obj instanceof ParseObject)) {
/* 78 */           String objectId = ((ParseObject)obj).getObjectId();
/* 79 */           if ((objectId != null) && (existingObjectIds.containsKey(objectId)))
/* 80 */             result.set(((Integer)existingObjectIds.get(objectId)).intValue(), obj);
/* 81 */           else if (!result.contains(obj)) {
/* 82 */             result.add(obj);
/*    */           }
/*    */         }
/* 85 */         else if (!result.contains(obj)) {
/* 86 */           result.add(obj);
/*    */         }
/*    */       }
/*    */ 
/* 90 */       return result;
/*    */     }
/* 92 */     throw new IllegalArgumentException("Operation is invalid after previous operation.");
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseAddUniqueOperation
 * JD-Core Version:    0.6.0
 */