/*    */ package com.parse;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import org.json.JSONArray;
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ abstract class ParseNetworkCommand<R, T> extends ParseRequest<R, T>
/*    */ {
/*    */   public ParseNetworkCommand(ParseRequest.Method method, String url)
/*    */   {
/* 13 */     super(method, url);
/*    */   }
/*    */ 
/*    */   abstract JSONObject toJSONObject();
/*    */ 
/*    */   abstract String getOperationSetUUID();
/*    */ 
/*    */   abstract void setOperationSetUUID(String paramString);
/*    */ 
/*    */   abstract String getSessionToken();
/*    */ 
/*    */   abstract String getLocalId();
/*    */ 
/*    */   abstract void setLocalId(String paramString);
/*    */ 
/*    */   abstract void retainLocalIds();
/*    */ 
/*    */   abstract void releaseLocalIds();
/*    */ 
/*    */   protected static void getLocalPointersIn(Object container, ArrayList<JSONObject> localPointers) throws JSONException
/*    */   {
/* 42 */     if ((container instanceof JSONObject)) {
/* 43 */       JSONObject object = (JSONObject)container;
/* 44 */       if (("Pointer".equals(object.opt("__type"))) && (object.has("localId"))) {
/* 45 */         localPointers.add((JSONObject)container);
/* 46 */         return;
/*    */       }
/*    */ 
/* 49 */       Iterator keyIterator = object.keys();
/* 50 */       while (keyIterator.hasNext()) {
/* 51 */         String key = (String)keyIterator.next();
/* 52 */         getLocalPointersIn(object.get(key), localPointers);
/*    */       }
/*    */     }
/*    */ 
/* 56 */     if ((container instanceof JSONArray)) {
/* 57 */       JSONArray array = (JSONArray)container;
/* 58 */       for (int i = 0; i < array.length(); i++)
/* 59 */         getLocalPointersIn(array.get(i), localPointers);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseNetworkCommand
 * JD-Core Version:    0.6.0
 */