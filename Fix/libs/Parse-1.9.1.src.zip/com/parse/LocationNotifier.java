/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.location.Criteria;
/*     */ import android.location.Location;
/*     */ import android.location.LocationListener;
/*     */ import android.location.LocationManager;
/*     */ import android.os.Bundle;
/*     */ import bolts.Capture;
/*     */ import bolts.Task;
/*     */ import bolts.Task.TaskCompletionSource;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ class LocationNotifier
/*     */ {
/*  28 */   private static Location fakeLocation = null;
/*     */ 
/*     */   static Task<Location> getCurrentLocationAsync(Context context, long timeout, Criteria criteria)
/*     */   {
/*  54 */     Task.TaskCompletionSource tcs = Task.create();
/*  55 */     Capture timeoutFuture = new Capture();
/*  56 */     LocationManager manager = (LocationManager)context.getSystemService("location");
/*     */ 
/*  58 */     LocationListener listener = new LocationListener(timeoutFuture, tcs, manager)
/*     */     {
/*     */       public void onLocationChanged(Location location) {
/*  61 */         if (location == null) {
/*  62 */           return;
/*     */         }
/*     */ 
/*  65 */         ((ScheduledFuture)this.val$timeoutFuture.get()).cancel(true);
/*     */ 
/*  67 */         this.val$tcs.trySetResult(location);
/*  68 */         this.val$manager.removeUpdates(this);
/*     */       }
/*     */ 
/*     */       public void onProviderDisabled(String provider)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void onProviderEnabled(String provider)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void onStatusChanged(String provider, int status, Bundle extras)
/*     */       {
/*     */       }
/*     */     };
/*  84 */     timeoutFuture.set(Parse.getScheduledExecutor().schedule(new Runnable(tcs, manager, listener)
/*     */     {
/*     */       public void run() {
/*  87 */         this.val$tcs.trySetError(new ParseException(124, "Location fetch timed out."));
/*  88 */         this.val$manager.removeUpdates(this.val$listener);
/*     */       }
/*     */     }
/*     */     , timeout, TimeUnit.MILLISECONDS));
/*     */ 
/*  92 */     String provider = manager.getBestProvider(criteria, true);
/*  93 */     if (provider != null) {
/*  94 */       manager.requestLocationUpdates(provider, 0L, 0.0F, listener);
/*     */     }
/*     */ 
/*  97 */     if (fakeLocation != null) {
/*  98 */       listener.onLocationChanged(fakeLocation);
/*     */     }
/*     */ 
/* 101 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   static void setFakeLocation(Location location)
/*     */   {
/* 108 */     fakeLocation = location;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.LocationNotifier
 * JD-Core Version:    0.6.0
 */