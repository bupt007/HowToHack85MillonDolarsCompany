/*     */ package com.parse;
/*     */ 
/*     */ import android.app.Activity;
/*     */ import android.app.Notification;
/*     */ import android.app.NotificationManager;
/*     */ import android.app.PendingIntent;
/*     */ import android.content.ComponentName;
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import android.content.res.Resources;
/*     */ import android.content.res.Resources.NotFoundException;
/*     */ import android.graphics.drawable.Drawable;
/*     */ import android.os.Bundle;
/*     */ import android.util.SparseIntArray;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ class ParseNotificationManager
/*     */ {
/*     */   public static final String TAG = "com.parse.ParseNotificationManager";
/*  32 */   private final Object lock = new Object();
/*  33 */   private final AtomicInteger notificationCount = new AtomicInteger(0);
/*  34 */   private volatile boolean shouldShowNotifications = true;
/*     */ 
/*  37 */   private SparseIntArray iconIds = new SparseIntArray();
/*     */ 
/*     */   public static ParseNotificationManager getInstance()
/*     */   {
/*  29 */     return Singleton.INSTANCE;
/*     */   }
/*     */ 
/*     */   public boolean getShouldShowNotifications()
/*     */   {
/*  40 */     return this.shouldShowNotifications;
/*     */   }
/*     */ 
/*     */   public void setShouldShowNotifications(boolean show) {
/*  44 */     this.shouldShowNotifications = show;
/*     */   }
/*     */ 
/*     */   public int getNotificationCount() {
/*  48 */     return this.notificationCount.get();
/*     */   }
/*     */ 
/*     */   public boolean isValidIconId(Context context, int iconId)
/*     */   {
/*     */     int valid;
/*  59 */     synchronized (this.lock) {
/*  60 */       valid = this.iconIds.get(iconId, -1);
/*     */     }
/*     */ 
/*  63 */     if (valid == -1) {
/*  64 */       Resources resources = context.getResources();
/*  65 */       Drawable drawable = null;
/*     */       try
/*     */       {
/*  68 */         drawable = resources.getDrawable(iconId);
/*     */       }
/*     */       catch (Resources.NotFoundException e)
/*     */       {
/*     */       }
/*  73 */       synchronized (this.lock) {
/*  74 */         valid = drawable == null ? 0 : 1;
/*  75 */         this.iconIds.put(iconId, valid);
/*     */       }
/*     */     }
/*     */ 
/*  79 */     return valid == 1;
/*     */   }
/*     */ 
/*     */   public Notification createNotification(Context context, String title, String body, Class<? extends Activity> clazz, int iconId, Bundle extras)
/*     */   {
/*  84 */     Notification notification = null;
/*     */ 
/*  86 */     if (!isValidIconId(context, iconId)) {
/*  87 */       Parse.logE("com.parse.ParseNotificationManager", "Icon id " + iconId + " is not a valid drawable. Trying to fall back to " + "default app icon.");
/*     */ 
/*  89 */       iconId = ManifestInfo.getIconId();
/*     */     }
/*     */ 
/*  92 */     if (iconId == 0) {
/*  93 */       Parse.logE("com.parse.ParseNotificationManager", "Could not find a valid icon id for this app. This is required to create a Notification object to show in the status bar. Make sure that the <application> in in your Manifest.xml has a valid android:icon attribute.");
/*     */     }
/*  96 */     else if ((context == null) || (title == null) || (body == null) || (clazz == null) || (iconId == 0)) {
/*  97 */       Parse.logE("com.parse.ParseNotificationManager", "Must specify non-null context, title, body, and activity class to show notification.");
/*     */     }
/*     */     else {
/* 100 */       long when = System.currentTimeMillis();
/* 101 */       ComponentName name = new ComponentName(context, clazz);
/*     */ 
/* 103 */       Intent intent = new Intent();
/* 104 */       intent.setComponent(name);
/* 105 */       intent.setFlags(268435456);
/*     */ 
/* 107 */       if (extras != null) {
/* 108 */         intent.putExtras(extras);
/*     */       }
/*     */ 
/* 111 */       PendingIntent contentIntent = PendingIntent.getActivity(context, (int)when, intent, 0);
/*     */ 
/* 114 */       notification = new Notification(iconId, body, when);
/* 115 */       notification.flags |= 16;
/* 116 */       notification.defaults |= -1;
/* 117 */       notification.setLatestEventInfo(context, title, body, contentIntent);
/*     */     }
/*     */ 
/* 120 */     return notification;
/*     */   }
/*     */ 
/*     */   public void showNotification(Context context, Notification notification) {
/* 124 */     if ((context != null) && (notification != null)) {
/* 125 */       this.notificationCount.incrementAndGet();
/*     */ 
/* 127 */       if (this.shouldShowNotifications)
/*     */       {
/* 129 */         NotificationManager nm = (NotificationManager)context.getSystemService("notification");
/*     */ 
/* 133 */         int notificationId = (int)System.currentTimeMillis();
/*     */         try
/*     */         {
/* 136 */           nm.notify(notificationId, notification);
/*     */         }
/*     */         catch (SecurityException e) {
/* 139 */           notification.defaults = 5;
/* 140 */           nm.notify(notificationId, notification);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void showNotification(Context context, String title, String body, Class<? extends Activity> cls, int iconId, Bundle extras)
/*     */   {
/* 148 */     showNotification(context, createNotification(context, title, body, cls, iconId, extras));
/*     */   }
/*     */ 
/*     */   public static class Singleton
/*     */   {
/*  25 */     private static final ParseNotificationManager INSTANCE = new ParseNotificationManager();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseNotificationManager
 * JD-Core Version:    0.6.0
 */