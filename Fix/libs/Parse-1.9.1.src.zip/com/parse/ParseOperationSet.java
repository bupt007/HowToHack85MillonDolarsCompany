/*     */ package com.parse;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.UUID;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class ParseOperationSet extends HashMap<String, ParseFieldOperation>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String REST_KEY_IS_SAVE_EVENTUALLY = "__isSaveEventually";
/*     */   private static final String REST_KEY_UUID = "__uuid";
/*     */   private String uuid;
/*  25 */   private boolean isSaveEventually = false;
/*     */ 
/*     */   public ParseOperationSet()
/*     */   {
/*  31 */     this.uuid = UUID.randomUUID().toString();
/*     */   }
/*     */ 
/*     */   private ParseOperationSet(String uuid)
/*     */   {
/*  38 */     this.uuid = uuid;
/*     */   }
/*     */ 
/*     */   public String getUUID() {
/*  42 */     return this.uuid;
/*     */   }
/*     */ 
/*     */   public void setIsSaveEventually(boolean value) {
/*  46 */     this.isSaveEventually = value;
/*     */   }
/*     */ 
/*     */   public boolean isSaveEventually() {
/*  50 */     return this.isSaveEventually;
/*     */   }
/*     */ 
/*     */   public void mergeFrom(ParseOperationSet other)
/*     */   {
/*  58 */     for (String key : other.keySet()) {
/*  59 */       ParseFieldOperation operation1 = (ParseFieldOperation)other.get(key);
/*  60 */       ParseFieldOperation operation2 = (ParseFieldOperation)get(key);
/*  61 */       if (operation2 != null)
/*  62 */         operation2 = operation2.mergeWithPrevious(operation1);
/*     */       else {
/*  64 */         operation2 = operation1;
/*     */       }
/*  66 */       put(key, operation2);
/*     */     }
/*     */   }
/*     */ 
/*     */   public JSONObject toRest(ParseObjectEncodingStrategy objectEncoder)
/*     */     throws JSONException
/*     */   {
/*  74 */     JSONObject operationSetJSON = new JSONObject();
/*  75 */     for (String key : keySet()) {
/*  76 */       ParseFieldOperation op = (ParseFieldOperation)get(key);
/*  77 */       operationSetJSON.put(key, op.encode(objectEncoder));
/*     */     }
/*     */ 
/*  80 */     operationSetJSON.put("__uuid", this.uuid);
/*  81 */     if (this.isSaveEventually) {
/*  82 */       operationSetJSON.put("__isSaveEventually", true);
/*     */     }
/*  84 */     return operationSetJSON;
/*     */   }
/*     */ 
/*     */   public static ParseOperationSet fromRest(JSONObject json, ParseDecoder decoder)
/*     */     throws JSONException
/*     */   {
/*  93 */     Iterator keysIter = json.keys();
/*  94 */     String[] keys = new String[json.length()];
/*  95 */     int index = 0;
/*  96 */     while (keysIter.hasNext()) {
/*  97 */       String key = (String)keysIter.next();
/*  98 */       keys[(index++)] = key;
/*     */     }
/*     */ 
/* 101 */     JSONObject jsonCopy = new JSONObject(json, keys);
/* 102 */     String uuid = (String)jsonCopy.remove("__uuid");
/* 103 */     ParseOperationSet operationSet = uuid == null ? new ParseOperationSet() : new ParseOperationSet(uuid);
/*     */ 
/* 106 */     boolean isSaveEventually = jsonCopy.optBoolean("__isSaveEventually");
/* 107 */     jsonCopy.remove("__isSaveEventually");
/* 108 */     operationSet.setIsSaveEventually(isSaveEventually);
/*     */ 
/* 110 */     Iterator opKeys = jsonCopy.keys();
/* 111 */     while (opKeys.hasNext()) {
/* 112 */       String opKey = (String)opKeys.next();
/* 113 */       Object value = decoder.decode(jsonCopy.get(opKey));
/*     */ 
/* 115 */       if (opKey.equals("ACL"))
/* 116 */         value = ParseACL.createACLFromJSONObject(jsonCopy.getJSONObject(opKey), decoder);
/*     */       ParseFieldOperation fieldOp;
/*     */       ParseFieldOperation fieldOp;
/* 118 */       if ((value instanceof ParseFieldOperation))
/* 119 */         fieldOp = (ParseFieldOperation)value;
/*     */       else {
/* 121 */         fieldOp = new ParseSetOperation(value);
/*     */       }
/* 123 */       operationSet.put(opKey, fieldOp);
/*     */     }
/*     */ 
/* 126 */     return operationSet;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseOperationSet
 * JD-Core Version:    0.6.0
 */