/*    */ package com.parse;
/*    */ 
/*    */ import android.content.Context;
/*    */ import android.os.PowerManager;
/*    */ import android.os.PowerManager.WakeLock;
/*    */ 
/*    */ class ParseWakeLock
/*    */ {
/*    */   private static final String TAG = "com.parse.ParseWakeLock";
/* 13 */   private static volatile boolean hasWakeLockPermission = true;
/*    */   private final PowerManager.WakeLock wakeLock;
/*    */ 
/*    */   public static ParseWakeLock acquireNewWakeLock(Context context, int type, String reason, long timeout)
/*    */   {
/* 17 */     PowerManager.WakeLock wl = null;
/*    */ 
/* 19 */     if (hasWakeLockPermission) {
/*    */       try {
/* 21 */         PowerManager pm = (PowerManager)context.getApplicationContext().getSystemService("power");
/*    */ 
/* 23 */         if (pm != null) {
/* 24 */           wl = pm.newWakeLock(type, reason);
/*    */ 
/* 26 */           if (wl != null) {
/* 27 */             wl.setReferenceCounted(false);
/*    */ 
/* 29 */             if (timeout == 0L)
/* 30 */               wl.acquire();
/*    */             else
/* 32 */               wl.acquire(timeout);
/*    */           }
/*    */         }
/*    */       }
/*    */       catch (SecurityException e) {
/* 37 */         Parse.logE("com.parse.ParseWakeLock", "Failed to acquire a PowerManager.WakeLock. This isnecessary for reliable handling of pushes. Please add this to your Manifest.xml: <uses-permission android:name=\"android.permission.WAKE_LOCK\" /> ");
/*    */ 
/* 41 */         hasWakeLockPermission = false;
/* 42 */         wl = null;
/*    */       }
/*    */     }
/*    */ 
/* 46 */     return new ParseWakeLock(wl);
/*    */   }
/*    */ 
/*    */   private ParseWakeLock(PowerManager.WakeLock wakeLock) {
/* 50 */     this.wakeLock = wakeLock;
/*    */   }
/*    */ 
/*    */   public void release() {
/* 54 */     if (this.wakeLock != null)
/* 55 */       this.wakeLock.release();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseWakeLock
 * JD-Core Version:    0.6.0
 */