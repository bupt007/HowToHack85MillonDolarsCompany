package com.parse;

import org.json.JSONException;

abstract interface ParseFieldOperation
{
  public abstract Object encode(ParseObjectEncodingStrategy paramParseObjectEncodingStrategy)
    throws JSONException;

  public abstract ParseFieldOperation mergeWithPrevious(ParseFieldOperation paramParseFieldOperation);

  public abstract Object apply(Object paramObject, ParseObject paramParseObject, String paramString);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseFieldOperation
 * JD-Core Version:    0.6.0
 */