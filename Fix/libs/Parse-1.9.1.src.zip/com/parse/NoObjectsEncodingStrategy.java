/*    */ package com.parse;
/*    */ 
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class NoObjectsEncodingStrategy
/*    */   implements ParseObjectEncodingStrategy
/*    */ {
/* 10 */   private static final NoObjectsEncodingStrategy instance = new NoObjectsEncodingStrategy();
/*    */ 
/*    */   public static NoObjectsEncodingStrategy get() {
/* 13 */     return instance;
/*    */   }
/*    */ 
/*    */   public JSONObject encodeRelatedObject(ParseObject object)
/*    */   {
/* 18 */     throw new IllegalArgumentException("ParseObjects not allowed here");
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.NoObjectsEncodingStrategy
 * JD-Core Version:    0.6.0
 */