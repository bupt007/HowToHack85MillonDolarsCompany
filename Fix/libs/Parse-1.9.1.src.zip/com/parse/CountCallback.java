package com.parse;

public abstract interface CountCallback
{
  public abstract void done(int paramInt, ParseException paramParseException);
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.CountCallback
 * JD-Core Version:    0.6.0
 */