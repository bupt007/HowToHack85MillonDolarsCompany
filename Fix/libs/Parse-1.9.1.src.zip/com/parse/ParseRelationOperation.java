/*     */ package com.parse;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class ParseRelationOperation<T extends ParseObject>
/*     */   implements ParseFieldOperation
/*     */ {
/*     */   private String targetClass;
/*     */   private Set<ParseObject> relationsToAdd;
/*     */   private Set<ParseObject> relationsToRemove;
/*     */ 
/*     */   ParseRelationOperation(Set<T> newRelationsToAdd, Set<T> newRelationsToRemove)
/*     */   {
/*  24 */     this.targetClass = null;
/*  25 */     this.relationsToAdd = new HashSet();
/*  26 */     this.relationsToRemove = new HashSet();
/*     */ 
/*  28 */     if (newRelationsToAdd != null) {
/*  29 */       for (ParseObject object : newRelationsToAdd) {
/*  30 */         addParseObjectToSet(object, this.relationsToAdd);
/*     */ 
/*  32 */         if (this.targetClass == null) {
/*  33 */           this.targetClass = object.getClassName();
/*     */         }
/*  35 */         else if (!this.targetClass.equals(object.getClassName())) {
/*  36 */           throw new IllegalArgumentException("All objects in a relation must be of the same class.");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  43 */     if (newRelationsToRemove != null) {
/*  44 */       for (ParseObject object : newRelationsToRemove) {
/*  45 */         addParseObjectToSet(object, this.relationsToRemove);
/*     */ 
/*  47 */         if (this.targetClass == null) {
/*  48 */           this.targetClass = object.getClassName();
/*     */         }
/*  50 */         else if (!this.targetClass.equals(object.getClassName())) {
/*  51 */           throw new IllegalArgumentException("All objects in a relation must be of the same class.");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  58 */     if (this.targetClass == null)
/*  59 */       throw new IllegalArgumentException("Cannot create a ParseRelationOperation with no objects.");
/*     */   }
/*     */ 
/*     */   private ParseRelationOperation(String newTargetClass, Set<ParseObject> newRelationsToAdd, Set<ParseObject> newRelationsToRemove)
/*     */   {
/*  65 */     this.targetClass = newTargetClass;
/*  66 */     this.relationsToAdd = new HashSet(newRelationsToAdd);
/*  67 */     this.relationsToRemove = new HashSet(newRelationsToRemove);
/*     */   }
/*     */ 
/*     */   private void addParseObjectToSet(ParseObject obj, Set<ParseObject> set)
/*     */   {
/*  74 */     if ((OfflineStore.getCurrent() != null) || (obj.getObjectId() == null))
/*     */     {
/*  76 */       set.add(obj);
/*  77 */       return;
/*     */     }
/*     */ 
/*  81 */     for (ParseObject existingObject : set) {
/*  82 */       if (obj.getObjectId().equals(existingObject.getObjectId())) {
/*  83 */         set.remove(existingObject);
/*     */       }
/*     */     }
/*  86 */     set.add(obj);
/*     */   }
/*     */ 
/*     */   private void addAllParseObjectsToSet(Collection<ParseObject> list, Set<ParseObject> set)
/*     */   {
/*  93 */     for (ParseObject obj : list)
/*  94 */       addParseObjectToSet(obj, set);
/*     */   }
/*     */ 
/*     */   private void removeParseObjectFromSet(ParseObject obj, Set<ParseObject> set)
/*     */   {
/* 102 */     if ((OfflineStore.getCurrent() != null) || (obj.getObjectId() == null))
/*     */     {
/* 104 */       set.remove(obj);
/* 105 */       return;
/*     */     }
/*     */ 
/* 109 */     for (ParseObject existingObject : set)
/* 110 */       if (obj.getObjectId().equals(existingObject.getObjectId()))
/* 111 */         set.remove(existingObject);
/*     */   }
/*     */ 
/*     */   private void removeAllParseObjectsFromSet(Collection<ParseObject> list, Set<ParseObject> set)
/*     */   {
/* 120 */     for (ParseObject obj : list)
/* 121 */       removeParseObjectFromSet(obj, set);
/*     */   }
/*     */ 
/*     */   String getTargetClass()
/*     */   {
/* 126 */     return this.targetClass;
/*     */   }
/*     */ 
/*     */   JSONArray convertSetToArray(Set<ParseObject> set, ParseObjectEncodingStrategy objectEncoder)
/*     */     throws JSONException
/*     */   {
/* 134 */     JSONArray array = new JSONArray();
/* 135 */     for (ParseObject obj : set) {
/* 136 */       array.put(Parse.encode(obj, objectEncoder));
/*     */     }
/* 138 */     return array;
/*     */   }
/*     */ 
/*     */   public JSONObject encode(ParseObjectEncodingStrategy objectEncoder)
/*     */     throws JSONException
/*     */   {
/* 144 */     JSONObject adds = null;
/* 145 */     JSONObject removes = null;
/*     */ 
/* 147 */     if (this.relationsToAdd.size() > 0) {
/* 148 */       adds = new JSONObject();
/* 149 */       adds.put("__op", "AddRelation");
/* 150 */       adds.put("objects", convertSetToArray(this.relationsToAdd, objectEncoder));
/*     */     }
/*     */ 
/* 153 */     if (this.relationsToRemove.size() > 0) {
/* 154 */       removes = new JSONObject();
/* 155 */       removes.put("__op", "RemoveRelation");
/* 156 */       removes.put("objects", convertSetToArray(this.relationsToRemove, objectEncoder));
/*     */     }
/*     */ 
/* 159 */     if ((adds != null) && (removes != null)) {
/* 160 */       JSONObject result = new JSONObject();
/* 161 */       result.put("__op", "Batch");
/* 162 */       JSONArray ops = new JSONArray();
/* 163 */       ops.put(adds);
/* 164 */       ops.put(removes);
/* 165 */       result.put("ops", ops);
/* 166 */       return result;
/*     */     }
/*     */ 
/* 169 */     if (adds != null) {
/* 170 */       return adds;
/*     */     }
/*     */ 
/* 173 */     if (removes != null) {
/* 174 */       return removes;
/*     */     }
/*     */ 
/* 177 */     throw new IllegalArgumentException("A ParseRelationOperation was created without any data.");
/*     */   }
/*     */ 
/*     */   public ParseFieldOperation mergeWithPrevious(ParseFieldOperation previous)
/*     */   {
/* 182 */     if (previous == null) {
/* 183 */       return this;
/*     */     }
/* 185 */     if ((previous instanceof ParseDeleteOperation)) {
/* 186 */       throw new IllegalArgumentException("You can't modify a relation after deleting it.");
/*     */     }
/* 188 */     if ((previous instanceof ParseRelationOperation))
/*     */     {
/* 190 */       ParseRelationOperation previousOperation = (ParseRelationOperation)previous;
/*     */ 
/* 192 */       if ((previousOperation.targetClass != null) && (!previousOperation.targetClass.equals(this.targetClass)))
/*     */       {
/* 194 */         throw new IllegalArgumentException("Related object object must be of class " + previousOperation.targetClass + ", but " + this.targetClass + " was passed in.");
/*     */       }
/*     */ 
/* 198 */       Set newRelationsToAdd = new HashSet(previousOperation.relationsToAdd);
/*     */ 
/* 200 */       Set newRelationsToRemove = new HashSet(previousOperation.relationsToRemove);
/*     */ 
/* 202 */       if (this.relationsToAdd != null) {
/* 203 */         addAllParseObjectsToSet(this.relationsToAdd, newRelationsToAdd);
/* 204 */         removeAllParseObjectsFromSet(this.relationsToAdd, newRelationsToRemove);
/*     */       }
/* 206 */       if (this.relationsToRemove != null) {
/* 207 */         removeAllParseObjectsFromSet(this.relationsToRemove, newRelationsToAdd);
/* 208 */         addAllParseObjectsToSet(this.relationsToRemove, newRelationsToRemove);
/*     */       }
/* 210 */       return new ParseRelationOperation(this.targetClass, newRelationsToAdd, newRelationsToRemove);
/*     */     }
/*     */ 
/* 213 */     throw new IllegalArgumentException("Operation is invalid after previous operation.");
/*     */   }
/*     */ 
/*     */   public Object apply(Object oldValue, ParseObject object, String key)
/*     */   {
/* 220 */     ParseRelation relation = null;
/*     */ 
/* 222 */     if (oldValue == null) {
/* 223 */       relation = new ParseRelation(object, key);
/* 224 */       relation.setTargetClass(this.targetClass);
/*     */     }
/* 226 */     else if ((oldValue instanceof ParseRelation)) {
/* 227 */       relation = (ParseRelation)oldValue;
/* 228 */       if ((this.targetClass != null) && (!this.targetClass.equals(relation.getTargetClass())))
/* 229 */         throw new IllegalArgumentException("Related object object must be of class " + relation.getTargetClass() + ", but " + this.targetClass + " was passed in.");
/*     */     }
/*     */     else
/*     */     {
/* 233 */       throw new IllegalArgumentException("Operation is invalid after previous operation.");
/*     */     }
/*     */ 
/* 236 */     for (ParseObject relationToAdd : this.relationsToAdd) {
/* 237 */       relation.addKnownObject(relationToAdd);
/*     */     }
/* 239 */     for (ParseObject relationToRemove : this.relationsToRemove) {
/* 240 */       relation.removeKnownObject(relationToRemove);
/*     */     }
/* 242 */     return relation;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRelationOperation
 * JD-Core Version:    0.6.0
 */