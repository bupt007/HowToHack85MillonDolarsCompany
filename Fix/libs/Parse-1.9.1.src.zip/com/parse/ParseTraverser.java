/*     */ package com.parse;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ abstract class ParseTraverser
/*     */ {
/*     */   private boolean traverseParseObjects;
/*     */   private boolean yieldRoot;
/*     */ 
/*     */   public ParseTraverser()
/*     */   {
/*  27 */     this.traverseParseObjects = false;
/*  28 */     this.yieldRoot = false;
/*     */   }
/*     */ 
/*     */   protected abstract boolean visit(Object paramObject);
/*     */ 
/*     */   private void traverseInternal(Object root, boolean yieldRoot, IdentityHashMap<Object, Object> seen)
/*     */   {
/*  41 */     if ((root == null) || (seen.containsKey(root))) {
/*  42 */       return;
/*     */     }
/*     */ 
/*  45 */     if ((yieldRoot) && 
/*  46 */       (!visit(root))) {
/*  47 */       return;
/*     */     }
/*     */ 
/*  51 */     seen.put(root, root);
/*     */ 
/*  53 */     if ((root instanceof JSONObject)) {
/*  54 */       JSONObject json = (JSONObject)root;
/*  55 */       Iterator keys = json.keys();
/*  56 */       while (keys.hasNext()) {
/*  57 */         String key = (String)keys.next();
/*     */         try {
/*  59 */           traverseInternal(json.get(key), true, seen);
/*     */         }
/*     */         catch (JSONException e) {
/*  62 */           throw new RuntimeException(e);
/*     */         }
/*     */       }
/*     */     }
/*  66 */     else if ((root instanceof JSONArray)) {
/*  67 */       JSONArray array = (JSONArray)root;
/*  68 */       for (int i = 0; i < array.length(); i++)
/*     */         try {
/*  70 */           traverseInternal(array.get(i), true, seen);
/*     */         }
/*     */         catch (JSONException e) {
/*  73 */           throw new RuntimeException(e);
/*     */         }
/*     */     }
/*     */     else
/*     */     {
/*     */       Iterator i$;
/*  77 */       if ((root instanceof Map)) {
/*  78 */         Map map = (Map)root;
/*  79 */         for (i$ = map.values().iterator(); i$.hasNext(); ) { Object value = i$.next();
/*  80 */           traverseInternal(value, true, seen);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*     */         Iterator i$;
/*  83 */         if ((root instanceof List)) {
/*  84 */           List list = (List)root;
/*  85 */           for (i$ = list.iterator(); i$.hasNext(); ) { Object value = i$.next();
/*  86 */             traverseInternal(value, true, seen);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*     */           ParseObject object;
/*  89 */           if ((root instanceof ParseObject)) {
/*  90 */             if (this.traverseParseObjects) {
/*  91 */               object = (ParseObject)root;
/*  92 */               for (String key : object.keySet()) {
/*  93 */                 traverseInternal(object.get(key), true, seen);
/*     */               }
/*     */             }
/*     */           }
/*  97 */           else if ((root instanceof ParseACL)) {
/*  98 */             ParseACL acl = (ParseACL)root;
/*  99 */             if (acl.hasUnresolvedUser())
/* 100 */               traverseInternal(ParseUser.getCurrentUser(), true, seen);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public ParseTraverser setTraverseParseObjects(boolean newValue)
/*     */   {
/* 110 */     this.traverseParseObjects = newValue;
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */   public ParseTraverser setYieldRoot(boolean newValue)
/*     */   {
/* 119 */     this.yieldRoot = newValue;
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */   public void traverse(Object root)
/*     */   {
/* 127 */     IdentityHashMap seen = new IdentityHashMap();
/* 128 */     traverseInternal(root, this.yieldRoot, seen);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseTraverser
 * JD-Core Version:    0.6.0
 */