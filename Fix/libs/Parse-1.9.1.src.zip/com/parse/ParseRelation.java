/*     */ package com.parse;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class ParseRelation<T extends ParseObject>
/*     */ {
/*  16 */   private final Object mutex = new Object();
/*     */   private ParseObject parent;
/*     */   private String key;
/*     */   private String targetClass;
/*  28 */   private Set<ParseObject> knownObjects = new HashSet();
/*     */ 
/*     */   ParseRelation(ParseObject parent, String key) {
/*  31 */     this.parent = parent;
/*  32 */     this.key = key;
/*  33 */     this.targetClass = null;
/*     */   }
/*     */ 
/*     */   ParseRelation(String targetClass) {
/*  37 */     this.parent = null;
/*  38 */     this.key = null;
/*  39 */     this.targetClass = targetClass;
/*     */   }
/*     */ 
/*     */   ParseRelation(JSONObject jsonObject, ParseDecoder decoder)
/*     */   {
/*  46 */     this.parent = null;
/*  47 */     this.targetClass = jsonObject.optString("className", null);
/*  48 */     this.key = null;
/*  49 */     JSONArray objectsArray = jsonObject.optJSONArray("objects");
/*  50 */     if (objectsArray != null)
/*  51 */       for (int i = 0; i < objectsArray.length(); i++)
/*  52 */         this.knownObjects.add((ParseObject)decoder.decode(objectsArray.optJSONObject(i)));
/*     */   }
/*     */ 
/*     */   void ensureParentAndKey(ParseObject someParent, String someKey)
/*     */   {
/*  58 */     synchronized (this.mutex) {
/*  59 */       if (this.parent == null) {
/*  60 */         this.parent = someParent;
/*     */       }
/*  62 */       if (this.key == null) {
/*  63 */         this.key = someKey;
/*     */       }
/*  65 */       if (this.parent != someParent) {
/*  66 */         throw new IllegalStateException("Internal error. One ParseRelation retrieved from two different ParseObjects.");
/*     */       }
/*     */ 
/*  69 */       if (!this.key.equals(someKey))
/*  70 */         throw new IllegalStateException("Internal error. One ParseRelation retrieved from two different keys.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void add(T object)
/*     */   {
/*  83 */     synchronized (this.mutex) {
/*  84 */       ParseRelationOperation operation = new ParseRelationOperation(Collections.singleton(object), null);
/*     */ 
/*  86 */       this.targetClass = operation.getTargetClass();
/*  87 */       this.parent.performOperation(this.key, operation);
/*     */ 
/*  89 */       this.knownObjects.add(object);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void remove(T object)
/*     */   {
/* 100 */     synchronized (this.mutex) {
/* 101 */       ParseRelationOperation operation = new ParseRelationOperation(null, Collections.singleton(object));
/*     */ 
/* 103 */       this.targetClass = operation.getTargetClass();
/* 104 */       this.parent.performOperation(this.key, operation);
/*     */ 
/* 106 */       this.knownObjects.remove(object);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ParseQuery<T> getQuery()
/*     */   {
/* 116 */     synchronized (this.mutex)
/*     */     {
/*     */       ParseQuery query;
/* 118 */       if (this.targetClass == null) {
/* 119 */         ParseQuery query = ParseQuery.getQuery(this.parent.getClassName());
/* 120 */         query.redirectClassNameForKey(this.key);
/*     */       } else {
/* 122 */         query = ParseQuery.getQuery(this.targetClass);
/*     */       }
/* 124 */       query.whereRelatedTo(this.parent, this.key);
/* 125 */       return query;
/*     */     }
/*     */   }
/*     */ 
/*     */   JSONObject encodeToJSON(ParseObjectEncodingStrategy objectEncoder) throws JSONException {
/* 130 */     synchronized (this.mutex) {
/* 131 */       JSONObject relation = new JSONObject();
/* 132 */       relation.put("__type", "Relation");
/* 133 */       relation.put("className", this.targetClass);
/* 134 */       JSONArray knownObjectsArray = new JSONArray();
/* 135 */       for (ParseObject knownObject : this.knownObjects)
/*     */         try {
/* 137 */           knownObjectsArray.put(objectEncoder.encodeRelatedObject(knownObject));
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */         }
/* 142 */       relation.put("objects", knownObjectsArray);
/* 143 */       return relation;
/*     */     }
/*     */   }
/*     */ 
/*     */   String getTargetClass() {
/* 148 */     synchronized (this.mutex) {
/* 149 */       return this.targetClass;
/*     */     }
/*     */   }
/*     */ 
/*     */   void setTargetClass(String className) {
/* 154 */     synchronized (this.mutex) {
/* 155 */       this.targetClass = className;
/*     */     }
/*     */   }
/*     */ 
/*     */   void addKnownObject(ParseObject object)
/*     */   {
/* 163 */     synchronized (this.mutex) {
/* 164 */       this.knownObjects.add(object);
/*     */     }
/*     */   }
/*     */ 
/*     */   void removeKnownObject(ParseObject object)
/*     */   {
/* 172 */     synchronized (this.mutex) {
/* 173 */       this.knownObjects.remove(object);
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean hasKnownObject(ParseObject object)
/*     */   {
/* 182 */     synchronized (this.mutex) {
/* 183 */       return this.knownObjects.contains(object);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRelation
 * JD-Core Version:    0.6.0
 */