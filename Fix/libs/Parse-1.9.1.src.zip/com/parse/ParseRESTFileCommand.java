/*    */ package com.parse;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.http.HttpEntity;
/*    */ 
/*    */ class ParseRESTFileCommand extends ParseRESTCommand
/*    */ {
/* 14 */   private byte[] data = null;
/* 15 */   private String contentType = null;
/*    */ 
/*    */   public ParseRESTFileCommand(String httpPath, ParseRequest.Method httpMethod, Map<String, ?> parameters, String sessionToken)
/*    */   {
/* 11 */     super(httpPath, httpMethod, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTFileCommand uploadFileCommand(String fileName, byte[] data, String contentType, String sessionToken)
/*    */   {
/* 19 */     String httpPath = String.format("files/%s", new Object[] { fileName });
/* 20 */     ParseRESTFileCommand command = new ParseRESTFileCommand(httpPath, ParseRequest.Method.POST, null, sessionToken);
/*    */ 
/* 22 */     command.data = data;
/* 23 */     command.contentType = contentType;
/* 24 */     return command;
/*    */   }
/*    */ 
/*    */   protected HttpEntity newEntity(ProgressCallback uploadProgressCallback)
/*    */   {
/* 29 */     CountingByteArrayEntity entity = new CountingByteArrayEntity(this.data, uploadProgressCallback);
/* 30 */     entity.setContentType(this.contentType);
/* 31 */     return entity;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTFileCommand
 * JD-Core Version:    0.6.0
 */