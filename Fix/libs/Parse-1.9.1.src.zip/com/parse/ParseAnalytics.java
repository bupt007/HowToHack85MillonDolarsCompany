/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Intent;
/*     */ import android.os.Bundle;
/*     */ import bolts.Capture;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class ParseAnalytics
/*     */ {
/*     */   private static final String TAG = "com.parse.ParseAnalytics";
/* 223 */   private static final Map<String, Boolean> lruSeenPushes = new LinkedHashMap() {
/*     */     protected boolean removeEldestEntry(Map.Entry<String, Boolean> eldest) {
/* 225 */       return size() > 10;
/*     */     }
/* 223 */   };
/*     */ 
/*     */   public static Task<Void> trackAppOpenedInBackground(Intent intent)
/*     */   {
/*  34 */     String pushData = null;
/*  35 */     if ((intent != null) && (intent.getExtras() != null)) {
/*  36 */       pushData = intent.getExtras().getString("com.parse.Data");
/*     */     }
/*     */ 
/*  39 */     Capture pushHash = new Capture();
/*  40 */     if (pushData != null) {
/*     */       try {
/*  42 */         JSONObject payload = new JSONObject(pushData);
/*  43 */         String hash = payload.optString("push_hash");
/*  44 */         if (hash.length() > 0)
/*  45 */           synchronized (lruSeenPushes) {
/*  46 */             if (lruSeenPushes.containsKey(hash)) {
/*  47 */               return Task.forResult(null);
/*     */             }
/*  49 */             lruSeenPushes.put(hash, Boolean.valueOf(true));
/*  50 */             pushHash.set(hash);
/*     */           }
/*     */       }
/*     */       catch (JSONException e)
/*     */       {
/*  55 */         Parse.logE("com.parse.ParseAnalytics", "Failed to parse push data: " + e.getMessage());
/*     */       }
/*     */     }
/*     */ 
/*  59 */     return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation(pushHash)
/*     */     {
/*     */       public Task<Void> then(Task<String> task) throws Exception {
/*  62 */         String sessionToken = (String)task.getResult();
/*  63 */         ParseRESTCommand command = ParseRESTAnalyticsCommand.trackAppOpenedCommand((String)this.val$pushHash.get(), sessionToken);
/*     */ 
/*  66 */         Task eventuallyTask = Parse.getEventuallyQueue().enqueueEventuallyAsync(command, null);
/*  67 */         return eventuallyTask.makeVoid();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void trackAppOpened(Intent intent)
/*     */   {
/*  77 */     trackAppOpenedInBackground(intent);
/*     */   }
/*     */ 
/*     */   public static void trackAppOpenedInBackground(Intent intent, SaveCallback callback)
/*     */   {
/*  91 */     Parse.callbackOnMainThreadAsync(trackAppOpenedInBackground(intent), callback);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void trackEvent(String name)
/*     */   {
/*  99 */     trackEventInBackground(name);
/*     */   }
/*     */ 
/*     */   public static void trackEventInBackground(String name, SaveCallback callback)
/*     */   {
/* 112 */     Parse.callbackOnMainThreadAsync(trackEventInBackground(name), callback);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void trackEvent(String name, Map<String, String> dimensions)
/*     */   {
/* 120 */     trackEventInBackground(name, dimensions);
/*     */   }
/*     */ 
/*     */   public static void trackEventInBackground(String name, Map<String, String> dimensions, SaveCallback callback)
/*     */   {
/* 146 */     Parse.callbackOnMainThreadAsync(trackEventInBackground(name, dimensions), callback);
/*     */   }
/*     */ 
/*     */   public static Task<Void> trackEventInBackground(String name)
/*     */   {
/* 170 */     return trackEventInBackground(name, (Map)null);
/*     */   }
/*     */ 
/*     */   public static Task<Void> trackEventInBackground(String name, Map<String, String> dimensions)
/*     */   {
/* 197 */     if ((name == null) || (name.trim().length() == 0)) {
/* 198 */       throw new RuntimeException("A name for the custom event must be provided.");
/*     */     }
/*     */ 
/* 201 */     JSONObject jsonDimensions = dimensions != null ? (JSONObject)Parse.encode(dimensions, NoObjectsEncodingStrategy.get()) : null;
/*     */ 
/* 205 */     return ParseUser.getCurrentSessionTokenAsync().onSuccessTask(new Continuation(name, jsonDimensions)
/*     */     {
/*     */       public Task<Void> then(Task<String> task) throws Exception {
/* 208 */         String sessionToken = (String)task.getResult();
/* 209 */         ParseRESTCommand command = ParseRESTAnalyticsCommand.trackEventCommand(this.val$name, this.val$jsonDimensions, sessionToken);
/*     */ 
/* 212 */         Task eventuallyTask = Parse.getEventuallyQueue().enqueueEventuallyAsync(command, null);
/*     */ 
/* 214 */         return eventuallyTask.makeVoid();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   static void clear()
/*     */   {
/* 230 */     synchronized (lruSeenPushes) {
/* 231 */       lruSeenPushes.clear();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseAnalytics
 * JD-Core Version:    0.6.0
 */