/*      */ package com.parse;
/*      */ 
/*      */ import android.content.ContentValues;
/*      */ import android.content.Context;
/*      */ import android.database.Cursor;
/*      */ import android.text.TextUtils;
/*      */ import android.util.Pair;
/*      */ import bolts.Capture;
/*      */ import bolts.Continuation;
/*      */ import bolts.Task;
/*      */ import bolts.Task.TaskCompletionSource;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.UUID;
/*      */ import java.util.WeakHashMap;
/*      */ import org.json.JSONException;
/*      */ import org.json.JSONObject;
/*      */ 
/*      */ class OfflineStore
/*      */ {
/*      */   private static final int MAX_SQL_VARIABLES = 999;
/*   34 */   private static final Object defaultInstanceLock = new Object();
/*      */ 
/*   37 */   private static OfflineStore defaultInstance = null;
/*      */ 
/*  189 */   private final Object lock = new Object();
/*      */   private final OfflineSQLiteOpenHelper helper;
/*  198 */   private final WeakValueHashMap<String, ParseObject> uuidToObjectMap = new WeakValueHashMap();
/*      */ 
/*  205 */   private final WeakValueHashMap<Pair<String, String>, ParseObject> classNameAndObjectIdToObjectMap = new WeakValueHashMap();
/*      */ 
/*  214 */   private final WeakHashMap<ParseObject, Task<String>> objectToUuidMap = new WeakHashMap();
/*      */ 
/*  221 */   private final WeakHashMap<ParseObject, Task<ParseObject>> fetchedObjects = new WeakHashMap();
/*      */ 
/*      */   public static void enableOfflineStore(Context context)
/*      */   {
/*   44 */     synchronized (defaultInstanceLock) {
/*   45 */       if (defaultInstance == null)
/*   46 */         defaultInstance = new OfflineStore(context);
/*      */       else
/*   48 */         throw new RuntimeException("enableOfflineStore() called multiple times.");
/*      */     }
/*      */   }
/*      */ 
/*      */   public static boolean isEnabled()
/*      */   {
/*   54 */     synchronized (defaultInstanceLock) {
/*   55 */       return defaultInstance != null;
/*      */     }
/*      */   }
/*      */ 
/*      */   static void disableOfflineStore()
/*      */   {
/*   63 */     synchronized (defaultInstanceLock) {
/*   64 */       defaultInstance = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static OfflineStore getCurrent()
/*      */   {
/*   74 */     synchronized (defaultInstanceLock) {
/*   75 */       return defaultInstance;
/*      */     }
/*      */   }
/*      */ 
/*      */   private OfflineStore(Context context)
/*      */   {
/*  227 */     this.helper = new OfflineSQLiteOpenHelper(context);
/*      */   }
/*      */ 
/*      */   private Task<String> getOrCreateUUIDAsync(ParseObject object, ParseSQLiteDatabase db)
/*      */   {
/*  235 */     String newUUID = UUID.randomUUID().toString();
/*  236 */     Task.TaskCompletionSource tcs = Task.create();
/*      */ 
/*  238 */     synchronized (this.lock) {
/*  239 */       Task uuidTask = (Task)this.objectToUuidMap.get(object);
/*  240 */       if (uuidTask != null) {
/*  241 */         return uuidTask;
/*      */       }
/*      */ 
/*  245 */       this.objectToUuidMap.put(object, tcs.getTask());
/*  246 */       this.uuidToObjectMap.put(newUUID, object);
/*  247 */       this.fetchedObjects.put(object, tcs.getTask().onSuccess(new Continuation(object)
/*      */       {
/*      */         public ParseObject then(Task<String> task) throws Exception {
/*  250 */           return this.val$object;
/*      */         }
/*      */ 
/*      */       }));
/*      */     }
/*      */ 
/*  260 */     ContentValues values = new ContentValues();
/*  261 */     values.put("uuid", newUUID);
/*  262 */     values.put("className", object.getClassName());
/*  263 */     db.insertOrThrowAsync("ParseObjects", values).continueWith(new Continuation(tcs, newUUID)
/*      */     {
/*      */       public Void then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/*  268 */         this.val$tcs.setResult(this.val$newUUID);
/*  269 */         return null;
/*      */       }
/*      */     });
/*  273 */     return tcs.getTask();
/*      */   }
/*      */ 
/*      */   private <T extends ParseObject> Task<T> getPointerAsync(String uuid, ParseSQLiteDatabase db)
/*      */   {
/*  290 */     synchronized (this.lock) {
/*  291 */       ParseObject existing = (ParseObject)this.uuidToObjectMap.get(uuid);
/*  292 */       if (existing != null) {
/*  293 */         return Task.forResult(existing);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  302 */     String[] select = { "className", "objectId" };
/*  303 */     String where = "uuid = ?";
/*  304 */     String[] args = { uuid };
/*  305 */     return db.queryAsync("ParseObjects", select, where, args).onSuccess(new Object(uuid)
/*      */     {
/*      */       public T then(Task<Cursor> task) throws Exception
/*      */       {
/*  309 */         Cursor cursor = (Cursor)task.getResult();
/*  310 */         cursor.moveToFirst();
/*  311 */         if (cursor.isAfterLast()) {
/*  312 */           cursor.close();
/*  313 */           throw new IllegalStateException("Attempted to find non-existent uuid " + this.val$uuid);
/*      */         }
/*      */ 
/*  316 */         synchronized (OfflineStore.this.lock)
/*      */         {
/*  321 */           ParseObject existing = (ParseObject)OfflineStore.this.uuidToObjectMap.get(this.val$uuid);
/*  322 */           if (existing != null) {
/*  323 */             return existing;
/*      */           }
/*      */ 
/*  326 */           String className = cursor.getString(0);
/*  327 */           String objectId = cursor.getString(1);
/*  328 */           cursor.close();
/*  329 */           ParseObject pointer = ParseObject.createWithoutData(className, objectId);
/*      */ 
/*  334 */           if (objectId == null) {
/*  335 */             OfflineStore.this.uuidToObjectMap.put(this.val$uuid, pointer);
/*  336 */             OfflineStore.this.objectToUuidMap.put(pointer, Task.forResult(this.val$uuid));
/*      */           }
/*  338 */           return pointer;
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> Task<List<T>> findAsync(ParseQuery<T> query, ParseUser user, ParsePin pin)
/*      */   {
/*  351 */     return findAsync(query, user, pin, false);
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> Task<List<T>> findAsync(ParseQuery<T> query, ParseUser user, ParsePin pin, ParseSQLiteDatabase db)
/*      */   {
/*  361 */     return findAsync(query, user, pin, false, db);
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> Task<Integer> countAsync(ParseQuery<T> query, ParseUser user, ParsePin pin)
/*      */   {
/*  371 */     return findAsync(query, user, pin, true).onSuccess(new Continuation()
/*      */     {
/*      */       public Integer then(Task<List<T>> task) throws Exception {
/*  374 */         return Integer.valueOf(((List)task.getResult()).size());
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private <T extends ParseObject> Task<List<T>> findAsync(ParseQuery<T> query, ParseUser user, ParsePin pin, boolean isCount)
/*      */   {
/*  387 */     return this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation(query, user, pin, isCount)
/*      */     {
/*      */       public Task<List<T>> then(Task<ParseSQLiteDatabase> task) throws Exception {
/*  390 */         ParseSQLiteDatabase db = (ParseSQLiteDatabase)task.getResult();
/*  391 */         return OfflineStore.this.findAsync(this.val$query, this.val$user, this.val$pin, this.val$isCount, db).continueWithTask(new Continuation(db)
/*      */         {
/*      */           public Task<List<T>> then(Task<List<T>> task) throws Exception {
/*  394 */             this.val$db.closeAsync();
/*  395 */             return task;
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private <T extends ParseObject> Task<List<T>> findAsync(ParseQuery<T> query, ParseUser user, ParsePin pin, boolean isCount, ParseSQLiteDatabase db)
/*      */   {
/*  417 */     boolean includeIsDeletingEventually = query.includeIsDeletingEventually;
/*  418 */     OfflineQueryLogic queryLogic = new OfflineQueryLogic(this);
/*      */ 
/*  420 */     List results = new ArrayList();
/*      */     Task queryTask;
/*      */     Task queryTask;
/*  423 */     if (pin == null) {
/*  424 */       String table = "ParseObjects";
/*  425 */       String[] select = { "uuid" };
/*  426 */       String where = "className=?";
/*  427 */       if (!includeIsDeletingEventually) {
/*  428 */         where = where + " AND isDeletingEventually=0";
/*      */       }
/*  430 */       String[] args = { query.getClassName() };
/*      */ 
/*  432 */       queryTask = db.queryAsync(table, select, where, args);
/*      */     } else {
/*  434 */       Task uuidTask = (Task)this.objectToUuidMap.get(pin);
/*  435 */       if (uuidTask == null)
/*      */       {
/*  437 */         return Task.forResult(results);
/*      */       }
/*      */ 
/*  440 */       queryTask = uuidTask.onSuccessTask(new Continuation(includeIsDeletingEventually, query, db)
/*      */       {
/*      */         public Task<Cursor> then(Task<String> task) throws Exception {
/*  443 */           String uuid = (String)task.getResult();
/*      */ 
/*  445 */           String table = "ParseObjects A  INNER JOIN Dependencies B  ON A.uuid=B.uuid";
/*      */ 
/*  448 */           String[] select = { "A.uuid" };
/*  449 */           String where = "className=? AND key=?";
/*      */ 
/*  451 */           if (!this.val$includeIsDeletingEventually) {
/*  452 */             where = where + " AND isDeletingEventually=0";
/*      */           }
/*  454 */           String[] args = { this.val$query.getClassName(), uuid };
/*      */ 
/*  456 */           return this.val$db.queryAsync(table, select, where, args);
/*      */         }
/*      */       });
/*      */     }
/*  461 */     return queryTask.onSuccessTask(new Continuation(queryLogic, query, user, db, results)
/*      */     {
/*      */       public Task<Void> then(Task<Cursor> task) throws Exception {
/*  464 */         Cursor cursor = (Cursor)task.getResult();
/*  465 */         List uuids = new ArrayList();
/*  466 */         for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
/*  467 */           uuids.add(cursor.getString(0));
/*      */         }
/*  469 */         cursor.close();
/*      */ 
/*  472 */         OfflineQueryLogic.ConstraintMatcher matcher = this.val$queryLogic.createMatcher(this.val$query, this.val$user);
/*      */ 
/*  474 */         Task checkedAllObjects = Task.forResult(null);
/*  475 */         for (String uuid : uuids) {
/*  476 */           Capture object = new Capture();
/*      */ 
/*  478 */           checkedAllObjects = checkedAllObjects.onSuccessTask(new Continuation(uuid)
/*      */           {
/*      */             public Task<T> then(Task<Void> task) throws Exception {
/*  481 */               return OfflineStore.this.getPointerAsync(this.val$uuid, OfflineStore.8.this.val$db);
/*      */             }
/*      */           }).onSuccessTask(new Continuation(object)
/*      */           {
/*      */             public Task<T> then(Task<T> task)
/*      */               throws Exception
/*      */             {
/*  486 */               this.val$object.set(task.getResult());
/*  487 */               return OfflineStore.this.fetchLocallyAsync((ParseObject)this.val$object.get(), OfflineStore.8.this.val$db);
/*      */             }
/*      */           }).onSuccessTask(new Continuation(object, matcher)
/*      */           {
/*      */             public Task<Boolean> then(Task<T> task)
/*      */               throws Exception
/*      */             {
/*  492 */               if (!((ParseObject)this.val$object.get()).isDataAvailable()) {
/*  493 */                 return Task.forResult(Boolean.valueOf(false));
/*      */               }
/*  495 */               return this.val$matcher.matchesAsync((ParseObject)this.val$object.get(), OfflineStore.8.this.val$db);
/*      */             }
/*      */           }).onSuccess(new Continuation(object)
/*      */           {
/*      */             public Void then(Task<Boolean> task)
/*      */             {
/*  500 */               if (((Boolean)task.getResult()).booleanValue()) {
/*  501 */                 OfflineStore.8.this.val$results.add(this.val$object.get());
/*      */               }
/*  503 */               return null;
/*      */             }
/*      */           });
/*      */         }
/*  508 */         return checkedAllObjects;
/*      */       }
/*      */     }).onSuccessTask(new Continuation(queryLogic, results, query, isCount, db)
/*      */     {
/*      */       public Task<List<T>> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/*  514 */         this.val$queryLogic.sort(this.val$results, this.val$query);
/*      */ 
/*  517 */         List trimmedResults = this.val$results;
/*  518 */         int skip = this.val$query.getSkip();
/*  519 */         if ((!this.val$isCount) && (skip >= 0)) {
/*  520 */           skip = Math.min(this.val$query.getSkip(), trimmedResults.size());
/*  521 */           trimmedResults = trimmedResults.subList(skip, trimmedResults.size());
/*      */         }
/*      */ 
/*  525 */         int limit = this.val$query.getLimit();
/*  526 */         if ((!this.val$isCount) && (limit >= 0) && (trimmedResults.size() > limit)) {
/*  527 */           trimmedResults = trimmedResults.subList(0, limit);
/*      */         }
/*      */ 
/*  531 */         Task fetchedIncludes = Task.forResult(null);
/*  532 */         for (ParseObject object : trimmedResults) {
/*  533 */           fetchedIncludes = fetchedIncludes.onSuccessTask(new Continuation(object)
/*      */           {
/*      */             public Task<Void> then(Task<Void> task) throws Exception {
/*  536 */               return OfflineStore.7.this.val$queryLogic.fetchIncludes(this.val$object, OfflineStore.7.this.val$query, OfflineStore.7.this.val$db);
/*      */             }
/*      */           });
/*      */         }
/*  541 */         List finalTrimmedResults = trimmedResults;
/*  542 */         return fetchedIncludes.onSuccess(new Continuation(finalTrimmedResults)
/*      */         {
/*      */           public List<T> then(Task<Void> task) throws Exception {
/*  545 */             return this.val$finalTrimmedResults;
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   Pair<ParseObject, Boolean> getOrCreateObjectWithoutData(String className, String objectId)
/*      */   {
/*  559 */     if (objectId == null) {
/*  560 */       throw new IllegalStateException("objectId cannot be null.");
/*      */     }
/*      */ 
/*  563 */     Pair classNameAndObjectId = Pair.create(className, objectId);
/*      */ 
/*  565 */     synchronized (this.lock) {
/*  566 */       ParseObject object = (ParseObject)this.classNameAndObjectIdToObjectMap.get(classNameAndObjectId);
/*  567 */       if (object != null) {
/*  568 */         return Pair.create(object, Boolean.valueOf(false));
/*      */       }
/*      */ 
/*  572 */       return Pair.create(ParseObject.create(className), Boolean.valueOf(true));
/*      */     }
/*      */   }
/*      */ 
/*      */   void updateObjectId(ParseObject object, String oldObjectId, String newObjectId)
/*      */   {
/*  581 */     if (oldObjectId != null) {
/*  582 */       if (oldObjectId.equals(newObjectId)) {
/*  583 */         return;
/*      */       }
/*  585 */       throw new RuntimeException("objectIds cannot be changed in offline mode.");
/*      */     }
/*      */ 
/*  588 */     String className = object.getClassName();
/*  589 */     Pair classNameAndNewObjectId = Pair.create(className, newObjectId);
/*      */ 
/*  591 */     synchronized (this.lock)
/*      */     {
/*  593 */       ParseObject existing = (ParseObject)this.classNameAndObjectIdToObjectMap.get(classNameAndNewObjectId);
/*  594 */       if ((existing != null) && (existing != object)) {
/*  595 */         throw new RuntimeException("Attempted to change an objectId to one that's already known to the Offline Store.");
/*      */       }
/*      */ 
/*  600 */       this.classNameAndObjectIdToObjectMap.put(classNameAndNewObjectId, object);
/*      */     }
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> Task<T> fetchLocallyAsync(T object, ParseSQLiteDatabase db)
/*      */   {
/*  615 */     Task.TaskCompletionSource tcs = Task.create();
/*      */     Task uuidTask;
/*  618 */     synchronized (this.lock) {
/*  619 */       if (this.fetchedObjects.containsKey(object))
/*      */       {
/*  624 */         return (Task)this.fetchedObjects.get(object);
/*      */       }
/*      */ 
/*  631 */       this.fetchedObjects.put(object, tcs.getTask());
/*      */ 
/*  633 */       uuidTask = (Task)this.objectToUuidMap.get(object);
/*      */     }
/*  635 */     String className = object.getClassName();
/*  636 */     String objectId = object.getObjectId();
/*      */ 
/*  642 */     Task jsonStringTask = Task.forResult(null);
/*      */ 
/*  644 */     if (objectId == null)
/*      */     {
/*  646 */       if (uuidTask != null)
/*      */       {
/*  661 */         String[] select = { "json" };
/*  662 */         String where = "uuid = ?";
/*  663 */         Capture uuid = new Capture();
/*  664 */         jsonStringTask = uuidTask.onSuccessTask(new Continuation(uuid, db, select)
/*      */         {
/*      */           public Task<Cursor> then(Task<String> task) throws Exception {
/*  667 */             this.val$uuid.set(task.getResult());
/*  668 */             String[] args = { (String)this.val$uuid.get() };
/*  669 */             return this.val$db.queryAsync("ParseObjects", this.val$select, "uuid = ?", args);
/*      */           }
/*      */         }).onSuccess(new Continuation(uuid)
/*      */         {
/*      */           public String then(Task<Cursor> task)
/*      */             throws Exception
/*      */           {
/*  674 */             Cursor cursor = (Cursor)task.getResult();
/*  675 */             cursor.moveToFirst();
/*  676 */             if (cursor.isAfterLast()) {
/*  677 */               cursor.close();
/*  678 */               throw new IllegalStateException("Attempted to find non-existent uuid " + (String)this.val$uuid.get());
/*      */             }
/*  680 */             String json = cursor.getString(0);
/*  681 */             cursor.close();
/*      */ 
/*  683 */             return json;
/*      */           } } );
/*      */       }
/*      */     } else {
/*  688 */       if (uuidTask != null)
/*      */       {
/*  693 */         tcs.setError(new IllegalStateException("This object must have already been fetched from the local datastore, but isn't marked as fetched."));
/*      */ 
/*  695 */         synchronized (this.lock)
/*      */         {
/*  697 */           this.fetchedObjects.remove(object);
/*      */         }
/*  699 */         return tcs.getTask();
/*      */       }
/*      */ 
/*  708 */       String[] select = { "json", "uuid" };
/*  709 */       String where = String.format("%s = ? AND %s = ?", new Object[] { "className", "objectId" });
/*      */ 
/*  712 */       String[] args = { className, objectId };
/*  713 */       jsonStringTask = db.queryAsync("ParseObjects", select, where, args).onSuccess(new Object(object)
/*      */       {
/*      */         public String then(Task<Cursor> task)
/*      */           throws Exception
/*      */         {
/*  718 */           Cursor cursor = (Cursor)task.getResult();
/*  719 */           cursor.moveToFirst();
/*  720 */           if (cursor.isAfterLast())
/*      */           {
/*  726 */             cursor.close();
/*  727 */             throw new ParseException(120, "This object is not available in the offline cache.");
/*      */           }
/*      */ 
/*  732 */           String jsonString = cursor.getString(0);
/*  733 */           String newUUID = cursor.getString(1);
/*  734 */           cursor.close();
/*      */ 
/*  736 */           synchronized (OfflineStore.this.lock)
/*      */           {
/*  742 */             OfflineStore.this.objectToUuidMap.put(this.val$object, Task.forResult(newUUID));
/*  743 */             OfflineStore.this.uuidToObjectMap.put(newUUID, this.val$object);
/*      */           }
/*      */ 
/*  746 */           return jsonString;
/*      */         }
/*      */       });
/*      */     }
/*  751 */     return jsonStringTask.onSuccessTask(new Continuation(db, object)
/*      */     {
/*      */       public Task<Void> then(Task<String> task) throws Exception {
/*  754 */         String jsonString = (String)task.getResult();
/*  755 */         if (jsonString == null)
/*      */         {
/*  761 */           return Task.forError(new ParseException(120, "Attempted to fetch an object offline which was never saved to the offline cache."));
/*      */         }
/*      */ 
/*      */         JSONObject json;
/*      */         try
/*      */         {
/*  771 */           json = new JSONObject(jsonString);
/*      */         } catch (JSONException e) {
/*  773 */           return Task.forError(e);
/*      */         }
/*      */ 
/*  777 */         Map offlineObjects = new HashMap();
/*      */ 
/*  779 */         new ParseTraverser(offlineObjects)
/*      */         {
/*      */           protected boolean visit(Object object) {
/*  782 */             if (((object instanceof JSONObject)) && (((JSONObject)object).optString("__type").equals("OfflineObject")))
/*      */             {
/*  784 */               String uuid = ((JSONObject)object).optString("uuid");
/*  785 */               this.val$offlineObjects.put(uuid, OfflineStore.this.getPointerAsync(uuid, OfflineStore.13.this.val$db));
/*      */             }
/*  787 */             return true;
/*      */           }
/*      */         }
/*  779 */         .setTraverseParseObjects(false).setYieldRoot(false).traverse(json);
/*      */ 
/*  791 */         return Task.whenAll(offlineObjects.values()).onSuccess(new Continuation(json, offlineObjects)
/*      */         {
/*      */           public Void then(Task<Void> task) throws Exception {
/*  794 */             OfflineStore.13.this.val$object.mergeREST(this.val$json, new OfflineStore.OfflineDecoder(OfflineStore.this, this.val$offlineObjects, null));
/*  795 */             return null;
/*      */           }
/*      */         });
/*      */       }
/*      */     }).continueWithTask(new Continuation(tcs, object)
/*      */     {
/*      */       public Task<T> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/*  802 */         if (task.isCancelled())
/*  803 */           this.val$tcs.setCancelled();
/*  804 */         else if (task.isFaulted())
/*  805 */           this.val$tcs.setError(task.getError());
/*      */         else {
/*  807 */           this.val$tcs.setResult(this.val$object);
/*      */         }
/*  809 */         return this.val$tcs.getTask();
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> Task<T> fetchLocallyAsync(T object)
/*      */   {
/*  823 */     return this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation(object)
/*      */     {
/*      */       public Task<T> then(Task<ParseSQLiteDatabase> task) throws Exception {
/*  826 */         ParseSQLiteDatabase db = (ParseSQLiteDatabase)task.getResult();
/*  827 */         return OfflineStore.this.fetchLocallyAsync(this.val$object, db).continueWithTask(new Continuation(db)
/*      */         {
/*      */           public Task<T> then(Task<T> task) throws Exception {
/*  830 */             this.val$db.closeAsync();
/*  831 */             return task;
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private Task<Void> saveLocallyAsync(String key, ParseObject object, ParseSQLiteDatabase db)
/*      */   {
/*  850 */     if ((object.getObjectId() != null) && (!object.isDataAvailable()) && (!object.hasChanges()) && (!object.hasOutstandingOperations()))
/*      */     {
/*  852 */       return Task.forResult(null);
/*      */     }
/*      */ 
/*  855 */     Capture uuid = new Capture();
/*  856 */     Capture encoded = new Capture();
/*      */ 
/*  859 */     return getOrCreateUUIDAsync(object, db).onSuccessTask(new Continuation(uuid, db, encoded, object)
/*      */     {
/*      */       public Task<Void> then(Task<String> task) throws Exception {
/*  862 */         this.val$uuid.set(task.getResult());
/*      */ 
/*  865 */         OfflineStore.OfflineEncodingStrategy encoder = new OfflineStore.OfflineEncodingStrategy(OfflineStore.this, this.val$db);
/*  866 */         this.val$encoded.set(this.val$object.toRest(encoder));
/*      */ 
/*  868 */         return encoder.whenFinished();
/*      */       }
/*      */     }).onSuccessTask(new Continuation(object, encoded, uuid, db)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/*  874 */         String className = this.val$object.getClassName();
/*  875 */         String objectId = this.val$object.getObjectId();
/*  876 */         String json = this.val$encoded.get().toString();
/*      */ 
/*  878 */         ContentValues values = new ContentValues();
/*  879 */         values.put("className", className);
/*  880 */         values.put("json", json);
/*  881 */         if (objectId != null) {
/*  882 */           values.put("objectId", objectId);
/*      */         }
/*  884 */         String where = "uuid = ?";
/*  885 */         String[] args = { (String)this.val$uuid.get() };
/*  886 */         return this.val$db.updateAsync("ParseObjects", values, where, args).makeVoid();
/*      */       }
/*      */     }).onSuccessTask(new Continuation(key, uuid, db)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/*  891 */         ContentValues values = new ContentValues();
/*  892 */         values.put("key", this.val$key);
/*  893 */         values.put("uuid", (String)this.val$uuid.get());
/*  894 */         return this.val$db.insertWithOnConflict("Dependencies", values, 4);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   Task<Void> saveLocallyAsync(ParseObject object)
/*      */   {
/*  915 */     return this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation(object)
/*      */     {
/*      */       public Task<Void> then(Task<ParseSQLiteDatabase> task) throws Exception
/*      */       {
/*  919 */         ParseSQLiteDatabase db = (ParseSQLiteDatabase)task.getResult();
/*  920 */         return db.beginTransactionAsync().onSuccessTask(new Continuation(db)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task) throws Exception {
/*  923 */             return OfflineStore.this.saveLocallyAsync(OfflineStore.18.this.val$object, true, this.val$db);
/*      */           }
/*      */         }).onSuccessTask(new Continuation(db)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task)
/*      */             throws Exception
/*      */           {
/*  928 */             return this.val$db.setTransactionSuccessfulAsync();
/*      */           }
/*      */         }).continueWithTask(new Continuation(db)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task)
/*      */             throws Exception
/*      */           {
/*  933 */             this.val$db.endTransactionAsync();
/*  934 */             this.val$db.closeAsync();
/*  935 */             return task;
/*      */           } } );
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   Task<Void> saveLocallyAsync(ParseObject object, List<ParseObject> children) {
/*  944 */     return this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation(object, children)
/*      */     {
/*      */       public Task<Void> then(Task<ParseSQLiteDatabase> task) throws Exception
/*      */       {
/*  948 */         ParseSQLiteDatabase db = (ParseSQLiteDatabase)task.getResult();
/*  949 */         return db.beginTransactionAsync().onSuccessTask(new Continuation(db)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task) throws Exception {
/*  952 */             return OfflineStore.this.saveLocallyAsync(OfflineStore.19.this.val$object, OfflineStore.19.this.val$children, this.val$db);
/*      */           }
/*      */         }).onSuccessTask(new Continuation(db)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task)
/*      */             throws Exception
/*      */           {
/*  957 */             return this.val$db.setTransactionSuccessfulAsync();
/*      */           }
/*      */         }).continueWithTask(new Continuation(db)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task)
/*      */             throws Exception
/*      */           {
/*  962 */             this.val$db.endTransactionAsync();
/*  963 */             this.val$db.closeAsync();
/*  964 */             return task;
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private Task<Void> saveLocallyAsync(ParseObject object, boolean includeAllChildren, ParseSQLiteDatabase db)
/*      */   {
/*  979 */     ArrayList objectsInTree = new ArrayList();
/*      */ 
/*  981 */     if (!includeAllChildren)
/*  982 */       objectsInTree.add(object);
/*      */     else {
/*  984 */       new ParseTraverser(objectsInTree)
/*      */       {
/*      */         protected boolean visit(Object object) {
/*  987 */           if ((object instanceof ParseObject)) {
/*  988 */             this.val$objectsInTree.add((ParseObject)object);
/*      */           }
/*  990 */           return true;
/*      */         }
/*      */       }
/*  984 */       .setYieldRoot(true).setTraverseParseObjects(true).traverse(object);
/*      */     }
/*      */ 
/*  995 */     return saveLocallyAsync(object, objectsInTree, db);
/*      */   }
/*      */ 
/*      */   private Task<Void> saveLocallyAsync(ParseObject object, List<ParseObject> children, ParseSQLiteDatabase db)
/*      */   {
/* 1001 */     List objects = children != null ? new ArrayList(children) : new ArrayList();
/*      */ 
/* 1004 */     if (!objects.contains(object)) {
/* 1005 */       objects.add(object);
/*      */     }
/*      */ 
/* 1010 */     List tasks = new ArrayList();
/* 1011 */     for (ParseObject obj : objects) {
/* 1012 */       tasks.add(fetchLocallyAsync(obj, db).makeVoid());
/*      */     }
/*      */ 
/* 1015 */     return Task.whenAll(tasks).continueWithTask(new Continuation(object)
/*      */     {
/*      */       public Task<String> then(Task<Void> task) throws Exception {
/* 1018 */         return (Task)OfflineStore.this.objectToUuidMap.get(this.val$object);
/*      */       }
/*      */     }).onSuccessTask(new Continuation(db)
/*      */     {
/*      */       public Task<Void> then(Task<String> task)
/*      */         throws Exception
/*      */       {
/* 1023 */         String uuid = (String)task.getResult();
/* 1024 */         if (uuid == null)
/*      */         {
/* 1026 */           return null;
/*      */         }
/*      */ 
/* 1031 */         return OfflineStore.this.unpinAsync(uuid, this.val$db);
/*      */       }
/*      */     }).onSuccessTask(new Continuation(object, db)
/*      */     {
/*      */       public Task<String> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1036 */         return OfflineStore.this.getOrCreateUUIDAsync(this.val$object, this.val$db);
/*      */       }
/*      */     }).onSuccessTask(new Continuation(objects, db)
/*      */     {
/*      */       public Task<Void> then(Task<String> task)
/*      */         throws Exception
/*      */       {
/* 1041 */         String uuid = (String)task.getResult();
/*      */ 
/* 1044 */         List tasks = new ArrayList();
/* 1045 */         for (ParseObject obj : this.val$objects) {
/* 1046 */           tasks.add(OfflineStore.this.saveLocallyAsync(uuid, obj, this.val$db));
/*      */         }
/*      */ 
/* 1049 */         return Task.whenAll(tasks);
/*      */       } } );
/*      */   }
/*      */ 
/*      */   Task<Void> unpinAsync(ParseObject object) {
/* 1055 */     return Task.forResult(null).continueWithTask(new Continuation(object)
/*      */     {
/*      */       public Task<String> then(Task<Void> task) throws Exception {
/* 1058 */         return (Task)OfflineStore.this.objectToUuidMap.get(this.val$object);
/*      */       }
/*      */     }).continueWithTask(new Continuation()
/*      */     {
/*      */       public Task<Void> then(Task<String> task)
/*      */         throws Exception
/*      */       {
/* 1063 */         String uuid = (String)task.getResult();
/* 1064 */         if (uuid == null)
/*      */         {
/* 1066 */           return Task.forResult(null);
/*      */         }
/* 1068 */         return OfflineStore.this.unpinAsync(uuid);
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private Task<Void> unpinAsync(String key) {
/* 1074 */     return this.helper.getWritableDatabaseAsync().onSuccessTask(new Continuation(key)
/*      */     {
/*      */       public Task<Void> then(Task<ParseSQLiteDatabase> task) throws Exception
/*      */       {
/* 1078 */         ParseSQLiteDatabase db = (ParseSQLiteDatabase)task.getResult();
/* 1079 */         return db.beginTransactionAsync().onSuccessTask(new Continuation(db)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task) throws Exception {
/* 1082 */             return OfflineStore.this.unpinAsync(OfflineStore.27.this.val$key, this.val$db).onSuccessTask(new Continuation()
/*      */             {
/*      */               public Task<Void> then(Task<Void> task) throws Exception {
/* 1085 */                 return OfflineStore.27.1.this.val$db.setTransactionSuccessfulAsync();
/*      */               }
/*      */             }).continueWithTask(new Continuation()
/*      */             {
/*      */               public Task<Void> then(Task<Void> task)
/*      */                 throws Exception
/*      */               {
/* 1090 */                 OfflineStore.27.1.this.val$db.endTransactionAsync();
/* 1091 */                 OfflineStore.27.1.this.val$db.closeAsync();
/* 1092 */                 return task;
/*      */               } } );
/*      */           } } );
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private Task<Void> unpinAsync(String key, ParseSQLiteDatabase db) {
/* 1102 */     List uuidsToDelete = new LinkedList();
/*      */ 
/* 1104 */     return Task.forResult((Void)null).continueWithTask(new Continuation(key, db)
/*      */     {
/*      */       public Task<Cursor> then(Task<Void> task) throws Exception
/*      */       {
/* 1108 */         String sql = "SELECT uuid FROM Dependencies WHERE key=? AND uuid IN ( SELECT uuid FROM Dependencies GROUP BY uuid HAVING COUNT(uuid)=1)";
/*      */ 
/* 1114 */         String[] args = { this.val$key };
/* 1115 */         return this.val$db.rawQueryAsync(sql, args);
/*      */       }
/*      */     }).onSuccessTask(new Continuation(uuidsToDelete, db)
/*      */     {
/*      */       public Task<Void> then(Task<Cursor> task)
/*      */         throws Exception
/*      */       {
/* 1122 */         Cursor cursor = (Cursor)task.getResult();
/* 1123 */         while (cursor.moveToNext()) {
/* 1124 */           this.val$uuidsToDelete.add(cursor.getString(0));
/*      */         }
/* 1126 */         cursor.close();
/*      */ 
/* 1128 */         return OfflineStore.this.deleteObjects(this.val$uuidsToDelete, this.val$db);
/*      */       }
/*      */     }).onSuccessTask(new Continuation(key, db)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1134 */         String where = "key=?";
/* 1135 */         String[] args = { this.val$key };
/* 1136 */         return this.val$db.deleteAsync("Dependencies", where, args);
/*      */       }
/*      */     }).onSuccess(new Object(uuidsToDelete)
/*      */     {
/*      */       public Void then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1141 */         synchronized (OfflineStore.this.lock)
/*      */         {
/* 1143 */           for (String uuid : this.val$uuidsToDelete) {
/* 1144 */             ParseObject object = (ParseObject)OfflineStore.this.uuidToObjectMap.get(uuid);
/* 1145 */             if (object != null) {
/* 1146 */               OfflineStore.this.objectToUuidMap.remove(object);
/* 1147 */               OfflineStore.this.uuidToObjectMap.remove(uuid);
/*      */             }
/*      */           }
/*      */         }
/* 1151 */         return null;
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private Task<Void> deleteObjects(List<String> uuids, ParseSQLiteDatabase db) {
/* 1157 */     if (uuids.size() <= 0) {
/* 1158 */       return Task.forResult(null);
/*      */     }
/*      */ 
/* 1163 */     if (uuids.size() > 999) {
/* 1164 */       return deleteObjects(uuids.subList(0, 999), db).onSuccessTask(new Continuation(uuids, db)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task) throws Exception {
/* 1167 */           return OfflineStore.this.deleteObjects(this.val$uuids.subList(999, this.val$uuids.size()), this.val$db);
/*      */         }
/*      */       });
/*      */     }
/* 1172 */     String[] placeholders = new String[uuids.size()];
/* 1173 */     for (int i = 0; i < placeholders.length; i++) {
/* 1174 */       placeholders[i] = "?";
/*      */     }
/* 1176 */     String where = "uuid IN (" + TextUtils.join(",", placeholders) + ")";
/*      */ 
/* 1178 */     String[] args = (String[])uuids.toArray(new String[uuids.size()]);
/* 1179 */     return db.deleteAsync("ParseObjects", where, args);
/*      */   }
/*      */ 
/*      */   void registerNewObject(ParseObject object)
/*      */   {
/* 1187 */     String objectId = object.getObjectId();
/* 1188 */     if (objectId != null) {
/* 1189 */       String className = object.getClassName();
/* 1190 */       Pair classNameAndObjectId = Pair.create(className, objectId);
/* 1191 */       this.classNameAndObjectIdToObjectMap.put(classNameAndObjectId, object);
/*      */     }
/*      */   }
/*      */ 
/*      */   Task<Void> updateDataForObjectAsync(ParseObject object)
/*      */   {
/*      */     Task fetched;
/* 1203 */     synchronized (this.lock) {
/* 1204 */       fetched = (Task)this.fetchedObjects.get(object);
/* 1205 */       if (fetched == null) {
/* 1206 */         return Task.forError(new IllegalStateException("An object cannot be updated if it wasn't fetched."));
/*      */       }
/*      */     }
/*      */ 
/* 1210 */     return fetched.continueWithTask(new Continuation(object)
/*      */     {
/*      */       public Task<Void> then(Task<ParseObject> task) throws Exception {
/* 1213 */         if (task.isFaulted())
/*      */         {
/* 1215 */           if (((task.getError() instanceof ParseException)) && (((ParseException)task.getError()).getCode() == 120))
/*      */           {
/* 1217 */             return Task.forResult(null);
/*      */           }
/* 1219 */           return task.makeVoid();
/*      */         }
/*      */ 
/* 1222 */         return OfflineStore.this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation()
/*      */         {
/*      */           public Task<Void> then(Task<ParseSQLiteDatabase> task) throws Exception {
/* 1225 */             ParseSQLiteDatabase db = (ParseSQLiteDatabase)task.getResult();
/* 1226 */             return db.beginTransactionAsync().onSuccessTask(new Continuation(db)
/*      */             {
/*      */               public Task<Void> then(Task<Void> task) throws Exception {
/* 1229 */                 return OfflineStore.this.updateDataForObjectAsync(OfflineStore.33.this.val$object, this.val$db).onSuccessTask(new Continuation()
/*      */                 {
/*      */                   public Task<Void> then(Task<Void> task) throws Exception {
/* 1232 */                     return OfflineStore.33.1.1.this.val$db.setTransactionSuccessfulAsync();
/*      */                   }
/*      */                 }).continueWithTask(new Continuation()
/*      */                 {
/*      */                   public Task<Void> then(Task<Void> task)
/*      */                     throws Exception
/*      */                   {
/* 1238 */                     OfflineStore.33.1.1.this.val$db.endTransactionAsync();
/* 1239 */                     OfflineStore.33.1.1.this.val$db.closeAsync();
/* 1240 */                     return task;
/*      */                   } } );
/*      */               } } );
/*      */           } } );
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private Task<Void> updateDataForObjectAsync(ParseObject object, ParseSQLiteDatabase db) {
/* 1252 */     Capture uuid = new Capture();
/* 1253 */     Capture jsonObject = new Capture();
/*      */     Task uuidTask;
/* 1257 */     synchronized (this.lock) {
/* 1258 */       uuidTask = (Task)this.objectToUuidMap.get(object);
/* 1259 */       if (uuidTask == null)
/*      */       {
/* 1261 */         return Task.forResult(null);
/*      */       }
/*      */     }
/* 1264 */     return uuidTask.onSuccessTask(new Continuation(uuid, db, jsonObject, object)
/*      */     {
/*      */       public Task<Void> then(Task<String> task) throws Exception {
/* 1267 */         this.val$uuid.set(task.getResult());
/*      */ 
/* 1270 */         OfflineStore.OfflineEncodingStrategy encoder = new OfflineStore.OfflineEncodingStrategy(OfflineStore.this, this.val$db);
/* 1271 */         this.val$jsonObject.set(this.val$object.toRest(encoder));
/*      */ 
/* 1273 */         return encoder.whenFinished();
/*      */       }
/*      */     }).onSuccessTask(new Continuation(object, jsonObject, uuid, db)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1279 */         String className = this.val$object.getClassName();
/* 1280 */         String objectId = this.val$object.getObjectId();
/* 1281 */         String json = ((JSONObject)this.val$jsonObject.get()).toString();
/* 1282 */         int isDeletingEventually = ((JSONObject)this.val$jsonObject.get()).getInt("isDeletingEventually");
/*      */ 
/* 1284 */         ContentValues values = new ContentValues();
/* 1285 */         values.put("className", className);
/* 1286 */         values.put("json", json);
/* 1287 */         if (objectId != null) {
/* 1288 */           values.put("objectId", objectId);
/*      */         }
/* 1290 */         values.put("isDeletingEventually", Integer.valueOf(isDeletingEventually));
/* 1291 */         String where = "uuid = ?";
/* 1292 */         String[] args = { (String)this.val$uuid.get() };
/*      */ 
/* 1294 */         return this.val$db.updateAsync("ParseObjects", values, where, args).makeVoid();
/*      */       } } );
/*      */   }
/*      */ 
/*      */   Task<Void> deleteDataForObjectAsync(ParseObject object) {
/* 1300 */     return this.helper.getWritableDatabaseAsync().continueWithTask(new Continuation(object)
/*      */     {
/*      */       public Task<Void> then(Task<ParseSQLiteDatabase> task) throws Exception {
/* 1303 */         ParseSQLiteDatabase db = (ParseSQLiteDatabase)task.getResult();
/* 1304 */         return db.beginTransactionAsync().onSuccessTask(new Continuation(db)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task) throws Exception {
/* 1307 */             return OfflineStore.this.deleteDataForObjectAsync(OfflineStore.36.this.val$object, this.val$db).onSuccessTask(new Continuation()
/*      */             {
/*      */               public Task<Void> then(Task<Void> task) throws Exception {
/* 1310 */                 return OfflineStore.36.1.this.val$db.setTransactionSuccessfulAsync();
/*      */               }
/*      */             }).continueWithTask(new Continuation()
/*      */             {
/*      */               public Task<Void> then(Task<Void> task)
/*      */                 throws Exception
/*      */               {
/* 1316 */                 OfflineStore.36.1.this.val$db.endTransactionAsync();
/* 1317 */                 OfflineStore.36.1.this.val$db.closeAsync();
/* 1318 */                 return task;
/*      */               } } );
/*      */           } } );
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private Task<Void> deleteDataForObjectAsync(ParseObject object, ParseSQLiteDatabase db) {
/* 1328 */     Capture uuid = new Capture();
/*      */ 
/* 1332 */     synchronized (this.lock) {
/* 1333 */       uuidTask = (Task)this.objectToUuidMap.get(object);
/* 1334 */       if (uuidTask == null)
/*      */       {
/* 1336 */         return Task.forResult(null);
/*      */       }
/*      */     }
/* 1339 */     Task uuidTask = uuidTask.onSuccessTask(new Continuation(uuid)
/*      */     {
/*      */       public Task<String> then(Task<String> task) throws Exception {
/* 1342 */         this.val$uuid.set(task.getResult());
/* 1343 */         return task;
/*      */       }
/*      */     });
/* 1348 */     Task unpinTask = uuidTask.onSuccessTask(new Continuation(uuid, db)
/*      */     {
/*      */       public Task<Cursor> then(Task<String> task) throws Exception
/*      */       {
/* 1352 */         String[] select = { "key" };
/* 1353 */         String where = "uuid=?";
/* 1354 */         String[] args = { (String)this.val$uuid.get() };
/* 1355 */         return this.val$db.queryAsync("Dependencies", select, where, args);
/*      */       }
/*      */     }).onSuccessTask(new Continuation(db, object)
/*      */     {
/*      */       public Task<Void> then(Task<Cursor> task)
/*      */         throws Exception
/*      */       {
/* 1361 */         Cursor cursor = (Cursor)task.getResult();
/* 1362 */         List uuids = new ArrayList();
/* 1363 */         for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
/* 1364 */           uuids.add(cursor.getString(0));
/*      */         }
/* 1366 */         cursor.close();
/*      */ 
/* 1368 */         List tasks = new ArrayList();
/* 1369 */         for (String uuid : uuids) {
/* 1370 */           Task unpinTask = OfflineStore.this.getPointerAsync(uuid, this.val$db).onSuccessTask(new Continuation()
/*      */           {
/*      */             public Task<ParsePin> then(Task<ParseObject> task) throws Exception {
/* 1373 */               ParsePin pin = (ParsePin)task.getResult();
/* 1374 */               return OfflineStore.this.fetchLocallyAsync(pin, OfflineStore.38.this.val$db);
/*      */             }
/*      */           }).continueWithTask(new Continuation(uuid)
/*      */           {
/*      */             public Task<Void> then(Task<ParsePin> task)
/*      */               throws Exception
/*      */             {
/* 1379 */               ParsePin pin = (ParsePin)task.getResult();
/*      */ 
/* 1381 */               List modified = pin.getObjects();
/* 1382 */               if ((modified == null) || (!modified.contains(OfflineStore.38.this.val$object))) {
/* 1383 */                 return task.makeVoid();
/*      */               }
/*      */ 
/* 1386 */               modified.remove(OfflineStore.38.this.val$object);
/* 1387 */               if (modified.size() == 0) {
/* 1388 */                 return OfflineStore.this.unpinAsync(this.val$uuid, OfflineStore.38.this.val$db);
/*      */               }
/*      */ 
/* 1391 */               pin.setObjects(modified);
/* 1392 */               return OfflineStore.this.saveLocallyAsync(pin, true, OfflineStore.38.this.val$db);
/*      */             }
/*      */           });
/* 1395 */           tasks.add(unpinTask);
/*      */         }
/*      */ 
/* 1398 */         return Task.whenAll(tasks);
/*      */       }
/*      */     });
/* 1403 */     return unpinTask.onSuccessTask(new Continuation(uuid, db)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task) throws Exception {
/* 1406 */         String where = "uuid=?";
/* 1407 */         String[] args = { (String)this.val$uuid.get() };
/* 1408 */         return this.val$db.deleteAsync("Dependencies", where, args);
/*      */       }
/*      */     }).onSuccessTask(new Continuation(uuid, db)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1413 */         String where = "uuid=?";
/* 1414 */         String[] args = { (String)this.val$uuid.get() };
/* 1415 */         return this.val$db.deleteAsync("ParseObjects", where, args);
/*      */       }
/*      */     }).onSuccessTask(new Object(object)
/*      */     {
/*      */       public Task<Void> then(Task<Void> task)
/*      */         throws Exception
/*      */       {
/* 1420 */         synchronized (OfflineStore.this.lock)
/*      */         {
/* 1424 */           String objectId = this.val$object.getObjectId();
/* 1425 */           if (objectId != null) {
/* 1426 */             OfflineStore.this.classNameAndObjectIdToObjectMap.remove(Pair.create(this.val$object.getClassName(), objectId));
/*      */           }
/* 1428 */           OfflineStore.this.fetchedObjects.remove(this.val$object);
/*      */         }
/* 1430 */         return task;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   void simulateReboot()
/*      */   {
/* 1443 */     synchronized (this.lock) {
/* 1444 */       this.uuidToObjectMap.clear();
/* 1445 */       this.objectToUuidMap.clear();
/* 1446 */       this.classNameAndObjectIdToObjectMap.clear();
/* 1447 */       this.fetchedObjects.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */   void clearDatabase(Context context)
/*      */   {
/* 1455 */     this.helper.clearDatabase(context);
/*      */   }
/*      */ 
/*      */   private class OfflineEncodingStrategy
/*      */     implements ParseObjectEncodingStrategy
/*      */   {
/*      */     private ParseSQLiteDatabase db;
/*  120 */     private ArrayList<Task<Void>> tasks = new ArrayList();
/*  121 */     private final Object tasksLock = new Object();
/*      */ 
/*      */     public OfflineEncodingStrategy(ParseSQLiteDatabase db)
/*      */     {
/*  130 */       this.db = db;
/*      */     }
/*      */ 
/*      */     public Task<Void> whenFinished()
/*      */     {
/*  138 */       return Task.whenAll(this.tasks).continueWithTask(new Object()
/*      */       {
/*      */         public Task<Void> then(Task<Void> ignore) throws Exception {
/*  141 */           synchronized (OfflineStore.OfflineEncodingStrategy.this.tasksLock)
/*      */           {
/*  143 */             for (Task task : OfflineStore.OfflineEncodingStrategy.this.tasks) {
/*  144 */               if ((task.isFaulted()) || (task.isCancelled())) {
/*  145 */                 return task;
/*      */               }
/*      */             }
/*  148 */             OfflineStore.OfflineEncodingStrategy.this.tasks.clear();
/*  149 */             return Task.forResult((Void)null);
/*      */           }
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/*      */     public JSONObject encodeRelatedObject(ParseObject object)
/*      */     {
/*      */       try
/*      */       {
/*  161 */         if (object.getObjectId() != null) {
/*  162 */           JSONObject result = new JSONObject();
/*  163 */           result.put("__type", "Pointer");
/*  164 */           result.put("objectId", object.getObjectId());
/*  165 */           result.put("className", object.getClassName());
/*  166 */           return result;
/*      */         }
/*      */ 
/*  169 */         JSONObject result = new JSONObject();
/*  170 */         result.put("__type", "OfflineObject");
/*  171 */         synchronized (this.tasksLock) {
/*  172 */           this.tasks.add(OfflineStore.this.getOrCreateUUIDAsync(object, this.db).onSuccess(new Continuation(result)
/*      */           {
/*      */             public Void then(Task<String> task) throws Exception {
/*  175 */               this.val$result.put("uuid", task.getResult());
/*  176 */               return null;
/*      */             } } ));
/*      */         }
/*  180 */         return result;
/*      */       } catch (JSONException e) {
/*      */       }
/*  183 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class OfflineDecoder extends ParseDecoder
/*      */   {
/*      */     private Map<String, Task<ParseObject>> offlineObjects;
/*      */ 
/*      */     private OfflineDecoder()
/*      */     {
/*   93 */       this.offlineObjects = offlineObjects;
/*      */     }
/*      */ 
/*      */     public Object decode(Object object)
/*      */     {
/*   99 */       if (((object instanceof JSONObject)) && (((JSONObject)object).optString("__type").equals("OfflineObject")))
/*      */       {
/*  101 */         String uuid = ((JSONObject)object).optString("uuid");
/*  102 */         return ((Task)this.offlineObjects.get(uuid)).getResult();
/*      */       }
/*      */ 
/*  109 */       return super.decode(object);
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.OfflineStore
 * JD-Core Version:    0.6.0
 */