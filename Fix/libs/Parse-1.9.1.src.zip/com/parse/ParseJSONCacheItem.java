/*    */ package com.parse;
/*    */ 
/*    */ import com.parse.codec.digest.DigestUtils;
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseJSONCacheItem
/*    */ {
/*    */   private JSONObject json;
/*    */   private String hashValue;
/*    */ 
/*    */   public ParseJSONCacheItem(Object object)
/*    */     throws JSONException
/*    */   {
/* 14 */     this.json = new JSONObject();
/* 15 */     this.json.put("object", Parse.encode(object, PointerOrLocalIdEncodingStrategy.get()));
/* 16 */     this.hashValue = DigestUtils.md5Hex(this.json.toString());
/*    */   }
/*    */ 
/*    */   public boolean equals(ParseJSONCacheItem other) {
/* 20 */     return this.hashValue.equals(other.getHashValue());
/*    */   }
/*    */ 
/*    */   public String getHashValue() {
/* 24 */     return this.hashValue;
/*    */   }
/*    */ 
/*    */   public Object getJSONObject() {
/*    */     try {
/* 29 */       return this.json.get("object"); } catch (JSONException e) {
/*    */     }
/* 31 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseJSONCacheItem
 * JD-Core Version:    0.6.0
 */