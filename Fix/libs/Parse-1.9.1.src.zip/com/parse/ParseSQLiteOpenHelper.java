/*    */ package com.parse;
/*    */ 
/*    */ import android.content.Context;
/*    */ import android.database.sqlite.SQLiteDatabase;
/*    */ import android.database.sqlite.SQLiteDatabase.CursorFactory;
/*    */ import android.database.sqlite.SQLiteOpenHelper;
/*    */ import bolts.Task;
/*    */ 
/*    */ abstract class ParseSQLiteOpenHelper
/*    */ {
/*    */   private final SQLiteOpenHelper helper;
/*    */ 
/*    */   public ParseSQLiteOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version)
/*    */   {
/* 15 */     this.helper = new SQLiteOpenHelper(context, name, factory, version)
/*    */     {
/*    */       public void onOpen(SQLiteDatabase db) {
/* 18 */         super.onOpen(db);
/* 19 */         ParseSQLiteOpenHelper.this.onOpen(db);
/*    */       }
/*    */ 
/*    */       public void onCreate(SQLiteDatabase db)
/*    */       {
/* 24 */         ParseSQLiteOpenHelper.this.onCreate(db);
/*    */       }
/*    */ 
/*    */       public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
/*    */       {
/* 29 */         ParseSQLiteOpenHelper.this.onUpgrade(db, oldVersion, newVersion);
/*    */       } } ;
/*    */   }
/*    */ 
/*    */   public Task<ParseSQLiteDatabase> getReadableDatabaseAsync() {
/* 35 */     return getDatabaseAsync(false);
/*    */   }
/*    */ 
/*    */   public Task<ParseSQLiteDatabase> getWritableDatabaseAsync() {
/* 39 */     return getDatabaseAsync(true);
/*    */   }
/*    */ 
/*    */   private Task<ParseSQLiteDatabase> getDatabaseAsync(boolean writable) {
/* 43 */     return ParseSQLiteDatabase.openDatabaseAsync(this.helper, !writable ? 1 : 0);
/*    */   }
/*    */ 
/*    */   public void onOpen(SQLiteDatabase db)
/*    */   {
/*    */   }
/*    */ 
/*    */   public abstract void onCreate(SQLiteDatabase paramSQLiteDatabase);
/*    */ 
/*    */   public abstract void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2);
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseSQLiteOpenHelper
 * JD-Core Version:    0.6.0
 */