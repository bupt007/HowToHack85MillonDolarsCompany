/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import bolts.Task;
/*     */ import bolts.Task.TaskCompletionSource;
/*     */ import com.parse.internal.AsyncCallback;
/*     */ import com.parse.twitter.Twitter;
/*     */ import java.lang.ref.WeakReference;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class TwitterAuthenticationProvider extends ParseAuthenticationProvider
/*     */ {
/*     */   public static final String AUTH_TYPE = "twitter";
/*     */   private static final String SCREEN_NAME_KEY = "screen_name";
/*     */   private static final String ID_KEY = "id";
/*     */   private static final String AUTH_TOKEN_SECRET_KEY = "auth_token_secret";
/*     */   private static final String AUTH_TOKEN_KEY = "auth_token";
/*     */   private static final String CONSUMER_KEY_KEY = "consumer_key";
/*     */   private static final String CONSUMER_SECRET_KEY = "consumer_secret";
/*     */   private WeakReference<Context> baseContext;
/*     */   private final Twitter twitter;
/*     */   private ParseAuthenticationProvider.ParseAuthenticationCallback currentOperationCallback;
/*     */ 
/*     */   public TwitterAuthenticationProvider(Twitter twitter)
/*     */   {
/*  30 */     this.twitter = twitter;
/*     */   }
/*     */ 
/*     */   private void authenticate(ParseAuthenticationProvider.ParseAuthenticationCallback callback) {
/*  34 */     if (this.currentOperationCallback != null)
/*  35 */       cancel();
/*  36 */     this.currentOperationCallback = callback;
/*     */ 
/*  38 */     Context context = this.baseContext == null ? null : (Context)this.baseContext.get();
/*  39 */     if (context == null) {
/*  40 */       throw new IllegalStateException("Context must be non-null for Twitter authentication to proceed.");
/*     */     }
/*     */ 
/*  43 */     this.twitter.authorize(context, new Object(callback)
/*     */     {
/*     */       public void onCancel()
/*     */       {
/*  47 */         TwitterAuthenticationProvider.this.handleCancel(this.val$callback);
/*     */       }
/*     */ 
/*     */       public void onFailure(Throwable error)
/*     */       {
/*  52 */         if (TwitterAuthenticationProvider.this.currentOperationCallback != this.val$callback)
/*  53 */           return;
/*     */         try
/*     */         {
/*  56 */           this.val$callback.onError(error);
/*     */         } finally {
/*  58 */           TwitterAuthenticationProvider.access$102(TwitterAuthenticationProvider.this, null);
/*     */         }
/*     */       }
/*     */ 
/*     */       public void onSuccess(Object result)
/*     */       {
/*  64 */         if (TwitterAuthenticationProvider.this.currentOperationCallback != this.val$callback)
/*  65 */           return;
/*     */         try {
/*     */           JSONObject authData;
/*     */           try {
/*  70 */             authData = TwitterAuthenticationProvider.this.getAuthData(TwitterAuthenticationProvider.this.twitter.getUserId(), TwitterAuthenticationProvider.this.twitter.getScreenName(), TwitterAuthenticationProvider.this.twitter.getAuthToken(), TwitterAuthenticationProvider.this.twitter.getAuthTokenSecret());
/*     */           }
/*     */           catch (JSONException e) {
/*  73 */             this.val$callback.onError(e);
/*     */ 
/*  78 */             TwitterAuthenticationProvider.access$102(TwitterAuthenticationProvider.this, null); return;
/*     */           }
/*  76 */           this.val$callback.onSuccess(authData);
/*     */         } finally {
/*  78 */           TwitterAuthenticationProvider.access$102(TwitterAuthenticationProvider.this, null);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public Task<JSONObject> authenticateAsync() {
/*  86 */     Task.TaskCompletionSource tcs = Task.create();
/*     */ 
/*  88 */     authenticate(new ParseAuthenticationProvider.ParseAuthenticationCallback(tcs)
/*     */     {
/*     */       public void onSuccess(JSONObject authData) {
/*  91 */         this.val$tcs.setResult(authData);
/*     */       }
/*     */ 
/*     */       public void onCancel()
/*     */       {
/*  96 */         this.val$tcs.setCancelled();
/*     */       }
/*     */ 
/*     */       public void onError(Throwable error)
/*     */       {
/* 101 */         this.val$tcs.setError(new ParseException(error));
/*     */       }
/*     */     });
/* 105 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public JSONObject getAuthData(String userId, String screenName, String authToken, String authTokenSecret) throws JSONException
/*     */   {
/* 110 */     JSONObject authData = new JSONObject();
/* 111 */     authData.put("auth_token", authToken);
/* 112 */     authData.put("auth_token_secret", authTokenSecret);
/* 113 */     authData.put("id", userId);
/* 114 */     authData.put("screen_name", screenName);
/* 115 */     authData.put("consumer_key", this.twitter.getConsumerKey());
/* 116 */     authData.put("consumer_secret", this.twitter.getConsumerSecret());
/* 117 */     return authData;
/*     */   }
/*     */ 
/*     */   public void cancel()
/*     */   {
/* 122 */     handleCancel(this.currentOperationCallback);
/*     */   }
/*     */ 
/*     */   public void deauthenticate()
/*     */   {
/* 127 */     this.twitter.setAuthToken(null);
/* 128 */     this.twitter.setAuthTokenSecret(null);
/* 129 */     this.twitter.setScreenName(null);
/* 130 */     this.twitter.setUserId(null);
/*     */   }
/*     */ 
/*     */   public String getAuthType()
/*     */   {
/* 135 */     return "twitter";
/*     */   }
/*     */ 
/*     */   public Twitter getTwitter() {
/* 139 */     return this.twitter;
/*     */   }
/*     */ 
/*     */   private void handleCancel(ParseAuthenticationProvider.ParseAuthenticationCallback callback)
/*     */   {
/* 146 */     if ((this.currentOperationCallback != callback) || (callback == null))
/* 147 */       return;
/*     */     try
/*     */     {
/* 150 */       callback.onCancel();
/*     */     } finally {
/* 152 */       this.currentOperationCallback = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean restoreAuthentication(JSONObject authData)
/*     */   {
/* 158 */     if (authData == null) {
/* 159 */       this.twitter.setAuthToken(null);
/* 160 */       this.twitter.setAuthTokenSecret(null);
/* 161 */       this.twitter.setScreenName(null);
/* 162 */       this.twitter.setUserId(null);
/*     */ 
/* 164 */       return true;
/*     */     }
/*     */     try {
/* 167 */       this.twitter.setAuthToken(authData.getString("auth_token"));
/* 168 */       this.twitter.setAuthTokenSecret(authData.getString("auth_token_secret"));
/* 169 */       this.twitter.setUserId(authData.getString("id"));
/* 170 */       this.twitter.setScreenName(authData.getString("screen_name"));
/*     */ 
/* 172 */       return true; } catch (Exception e) {
/*     */     }
/* 174 */     return false;
/*     */   }
/*     */ 
/*     */   public TwitterAuthenticationProvider setContext(Context context)
/*     */   {
/* 180 */     this.baseContext = new WeakReference(context);
/* 181 */     return this;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.TwitterAuthenticationProvider
 * JD-Core Version:    0.6.0
 */