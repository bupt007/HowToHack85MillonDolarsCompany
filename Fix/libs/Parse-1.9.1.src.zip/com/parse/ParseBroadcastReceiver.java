/*    */ package com.parse;
/*    */ 
/*    */ import android.content.BroadcastReceiver;
/*    */ import android.content.Context;
/*    */ import android.content.Intent;
/*    */ 
/*    */ public class ParseBroadcastReceiver extends BroadcastReceiver
/*    */ {
/*    */   private static final String TAG = "com.parse.ParseBroadcastReceiver";
/*    */ 
/*    */   public void onReceive(Context context, Intent intent)
/*    */   {
/* 18 */     Parse.logD("com.parse.ParseBroadcastReceiver", "received " + intent.getAction());
/* 19 */     PushService.startServiceIfRequired(context);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseBroadcastReceiver
 * JD-Core Version:    0.6.0
 */