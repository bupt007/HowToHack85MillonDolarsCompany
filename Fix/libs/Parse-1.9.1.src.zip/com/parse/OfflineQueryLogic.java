/*      */ package com.parse;
/*      */ 
/*      */ import bolts.Continuation;
/*      */ import bolts.Task;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.json.JSONArray;
/*      */ import org.json.JSONException;
/*      */ import org.json.JSONObject;
/*      */ 
/*      */ class OfflineQueryLogic
/*      */ {
/*      */   private final OfflineStore store;
/*      */ 
/*      */   OfflineQueryLogic(OfflineStore store)
/*      */   {
/*   45 */     this.store = store;
/*      */   }
/*      */ 
/*      */   private Object getValue(Object container, String key)
/*      */     throws ParseException
/*      */   {
/*   53 */     return getValue(container, key, 0);
/*      */   }
/*      */ 
/*      */   private Object getValue(Object container, String key, int depth) throws ParseException {
/*   57 */     if (key.contains(".")) {
/*   58 */       String[] parts = key.split("\\.", 2);
/*   59 */       Object value = getValue(container, parts[0], depth + 1);
/*      */ 
/*   64 */       if ((value != null) && (value != JSONObject.NULL) && (!(value instanceof Map)) && (!(value instanceof JSONObject)))
/*      */       {
/*   66 */         if (depth > 0) {
/*   67 */           Object restFormat = null;
/*      */           try {
/*   69 */             restFormat = Parse.encode(value, PointerEncodingStrategy.get());
/*      */           }
/*      */           catch (Exception e) {
/*      */           }
/*   73 */           if ((restFormat instanceof JSONObject)) {
/*   74 */             return getValue(restFormat, parts[1], depth + 1);
/*      */           }
/*      */         }
/*   77 */         throw new ParseException(102, String.format("Key %s is invalid.", new Object[] { key }));
/*      */       }
/*      */ 
/*   80 */       return getValue(value, parts[1], depth + 1);
/*      */     }
/*      */ 
/*   83 */     if ((container instanceof ParseObject)) {
/*   84 */       ParseObject object = (ParseObject)container;
/*      */ 
/*   87 */       if (!object.isDataAvailable()) {
/*   88 */         throw new ParseException(121, String.format("Bad key: %s", new Object[] { key }));
/*      */       }
/*      */ 
/*   93 */       if (key.equals("objectId"))
/*   94 */         return object.getObjectId();
/*   95 */       if ((key.equals("createdAt")) || (key.equals("_created_at")))
/*   96 */         return object.getCreatedAt();
/*   97 */       if ((key.equals("updatedAt")) || (key.equals("_updated_at"))) {
/*   98 */         return object.getUpdatedAt();
/*      */       }
/*  100 */       return object.get(key);
/*      */     }
/*      */ 
/*  103 */     if ((container instanceof JSONObject)) {
/*  104 */       return ((JSONObject)container).opt(key);
/*      */     }
/*  106 */     if ((container instanceof Map)) {
/*  107 */       return ((Map)container).get(key);
/*      */     }
/*  109 */     if (container == JSONObject.NULL) {
/*  110 */       return null;
/*      */     }
/*  112 */     if (container == null) {
/*  113 */       return null;
/*      */     }
/*      */ 
/*  116 */     throw new ParseException(121, String.format("Bad key: %s", new Object[] { key }));
/*      */   }
/*      */ 
/*      */   private static int compareTo(Object lhs, Object rhs)
/*      */   {
/*  126 */     boolean lhsIsNullOrUndefined = (lhs == JSONObject.NULL) || (lhs == null);
/*  127 */     boolean rhsIsNullOrUndefined = (rhs == JSONObject.NULL) || (rhs == null);
/*      */ 
/*  129 */     if ((lhsIsNullOrUndefined) || (rhsIsNullOrUndefined)) {
/*  130 */       if (!lhsIsNullOrUndefined)
/*  131 */         return 1;
/*  132 */       if (!rhsIsNullOrUndefined) {
/*  133 */         return -1;
/*      */       }
/*  135 */       return 0;
/*      */     }
/*  137 */     if (((lhs instanceof Date)) && ((rhs instanceof Date)))
/*  138 */       return ((Date)lhs).compareTo((Date)rhs);
/*  139 */     if (((lhs instanceof String)) && ((rhs instanceof String)))
/*  140 */       return ((String)lhs).compareTo((String)rhs);
/*  141 */     if (((lhs instanceof Number)) && ((rhs instanceof Number))) {
/*  142 */       return Parse.compareNumbers((Number)lhs, (Number)rhs);
/*      */     }
/*  144 */     throw new IllegalArgumentException(String.format("Cannot compare %s against %s", new Object[] { lhs, rhs }));
/*      */   }
/*      */ 
/*      */   private static boolean compareList(Object constraint, List<?> values, Decider decider)
/*      */   {
/*  160 */     for (Iterator i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/*  161 */       if (decider.decide(constraint, value)) {
/*  162 */         return true;
/*      */       }
/*      */     }
/*  165 */     return false;
/*      */   }
/*      */ 
/*      */   private static boolean compareArray(Object constraint, JSONArray values, Decider decider)
/*      */   {
/*  172 */     for (int i = 0; i < values.length(); i++) {
/*      */       try {
/*  174 */         if (decider.decide(constraint, values.get(i)))
/*  175 */           return true;
/*      */       }
/*      */       catch (JSONException e)
/*      */       {
/*  179 */         throw new RuntimeException(e);
/*      */       }
/*      */     }
/*  182 */     return false;
/*      */   }
/*      */ 
/*      */   private static boolean compare(Object constraint, Object value, Decider decider)
/*      */   {
/*  191 */     if ((value instanceof List))
/*  192 */       return compareList(constraint, (List)value, decider);
/*  193 */     if ((value instanceof JSONArray)) {
/*  194 */       return compareArray(constraint, (JSONArray)value, decider);
/*      */     }
/*  196 */     return decider.decide(constraint, value);
/*      */   }
/*      */ 
/*      */   private static boolean matchesEqualConstraint(Object constraint, Object value)
/*      */   {
/*  205 */     if ((constraint == null) || (value == null)) {
/*  206 */       return constraint == value;
/*      */     }
/*      */ 
/*  209 */     if (((constraint instanceof Number)) && ((value instanceof Number))) {
/*  210 */       return compareTo(constraint, value) == 0;
/*      */     }
/*      */ 
/*  213 */     if (((constraint instanceof ParseGeoPoint)) && ((value instanceof ParseGeoPoint))) {
/*  214 */       ParseGeoPoint lhs = (ParseGeoPoint)constraint;
/*  215 */       ParseGeoPoint rhs = (ParseGeoPoint)value;
/*  216 */       return (lhs.getLatitude() == rhs.getLatitude()) && (rhs.getLongitude() == rhs.getLongitude());
/*      */     }
/*      */ 
/*  220 */     return compare(constraint, value, new Decider()
/*      */     {
/*      */       public boolean decide(Object constraint, Object value) {
/*  223 */         return constraint.equals(value);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private static boolean matchesNotEqualConstraint(Object constraint, Object value)
/*      */   {
/*  232 */     return !matchesEqualConstraint(constraint, value);
/*      */   }
/*      */ 
/*      */   private static boolean matchesLessThanConstraint(Object constraint, Object value)
/*      */   {
/*  239 */     return compare(constraint, value, new Decider()
/*      */     {
/*      */       public boolean decide(Object constraint, Object value) {
/*  242 */         if ((value == null) || (value == JSONObject.NULL)) {
/*  243 */           return false;
/*      */         }
/*  245 */         return OfflineQueryLogic.access$000(constraint, value) > 0;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private static boolean matchesLessThanOrEqualToConstraint(Object constraint, Object value)
/*      */   {
/*  254 */     return compare(constraint, value, new Decider()
/*      */     {
/*      */       public boolean decide(Object constraint, Object value) {
/*  257 */         if ((value == null) || (value == JSONObject.NULL)) {
/*  258 */           return false;
/*      */         }
/*  260 */         return OfflineQueryLogic.access$000(constraint, value) >= 0;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private static boolean matchesGreaterThanConstraint(Object constraint, Object value)
/*      */   {
/*  269 */     return compare(constraint, value, new Decider()
/*      */     {
/*      */       public boolean decide(Object constraint, Object value) {
/*  272 */         if ((value == null) || (value == JSONObject.NULL)) {
/*  273 */           return false;
/*      */         }
/*  275 */         return OfflineQueryLogic.access$000(constraint, value) < 0;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private static boolean matchesGreaterThanOrEqualToConstraint(Object constraint, Object value)
/*      */   {
/*  284 */     return compare(constraint, value, new Decider()
/*      */     {
/*      */       public boolean decide(Object constraint, Object value) {
/*  287 */         if ((value == null) || (value == JSONObject.NULL)) {
/*  288 */           return false;
/*      */         }
/*  290 */         return OfflineQueryLogic.access$000(constraint, value) <= 0;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private static boolean matchesInConstraint(Object constraint, Object value)
/*      */   {
/*  300 */     if ((constraint instanceof List)) {
/*  301 */       for (Iterator i$ = ((List)constraint).iterator(); i$.hasNext(); ) { Object requiredItem = i$.next();
/*  302 */         if (matchesEqualConstraint(requiredItem, value)) {
/*  303 */           return true;
/*      */         }
/*      */       }
/*  306 */       return false;
/*      */     }
/*  308 */     if ((constraint instanceof JSONArray)) {
/*  309 */       for (int i = 0; i < ((JSONArray)constraint).length(); i++) {
/*  310 */         if (matchesEqualConstraint(((JSONArray)constraint).opt(i), value)) {
/*  311 */           return true;
/*      */         }
/*      */       }
/*  314 */       return false;
/*      */     }
/*  316 */     if (constraint == JSONObject.NULL) {
/*  317 */       return false;
/*      */     }
/*  319 */     if (constraint == null) {
/*  320 */       return false;
/*      */     }
/*  322 */     throw new IllegalArgumentException("Constraint type not supported for $in queries.");
/*      */   }
/*      */ 
/*      */   private static boolean matchesNotInConstraint(Object constraint, Object value)
/*      */   {
/*  329 */     return !matchesInConstraint(constraint, value);
/*      */   }
/*      */ 
/*      */   private static boolean matchesAllConstraint(Object constraint, Object value)
/*      */   {
/*  336 */     if ((value == null) || (value == JSONObject.NULL)) {
/*  337 */       return false;
/*      */     }
/*      */ 
/*  340 */     if ((!(value instanceof List)) && (!(value instanceof JSONArray))) {
/*  341 */       throw new IllegalArgumentException("Value type not supported for $all queries.");
/*      */     }
/*  343 */     if ((constraint instanceof List)) {
/*  344 */       for (Iterator i$ = ((List)constraint).iterator(); i$.hasNext(); ) { Object requiredItem = i$.next();
/*  345 */         if (!matchesEqualConstraint(requiredItem, value)) {
/*  346 */           return false;
/*      */         }
/*      */       }
/*  349 */       return true;
/*      */     }
/*  351 */     if ((constraint instanceof JSONArray)) {
/*  352 */       for (int i = 0; i < ((JSONArray)constraint).length(); i++) {
/*  353 */         Object requiredItem = ((JSONArray)constraint).opt(i);
/*  354 */         if (!matchesEqualConstraint(requiredItem, value)) {
/*  355 */           return false;
/*      */         }
/*      */       }
/*  358 */       return true;
/*      */     }
/*  360 */     throw new IllegalArgumentException("Constraint type not supported for $all queries.");
/*      */   }
/*      */ 
/*      */   private static boolean matchesRegexConstraint(Object constraint, Object value, String options)
/*      */     throws ParseException
/*      */   {
/*  368 */     if ((value == null) || (value == JSONObject.NULL)) {
/*  369 */       return false;
/*      */     }
/*      */ 
/*  372 */     if (options == null) {
/*  373 */       options = "";
/*      */     }
/*      */ 
/*  376 */     if (!options.matches("^[imxs]*$")) {
/*  377 */       throw new ParseException(102, String.format("Invalid regex options: %s", new Object[] { options }));
/*      */     }
/*      */ 
/*  381 */     int flags = 0;
/*  382 */     if (options.contains("i")) {
/*  383 */       flags |= 2;
/*      */     }
/*  385 */     if (options.contains("m")) {
/*  386 */       flags |= 8;
/*      */     }
/*  388 */     if (options.contains("x")) {
/*  389 */       flags |= 4;
/*      */     }
/*  391 */     if (options.contains("s")) {
/*  392 */       flags |= 32;
/*      */     }
/*      */ 
/*  395 */     String regex = (String)constraint;
/*  396 */     Pattern pattern = Pattern.compile(regex, flags);
/*  397 */     Matcher matcher = pattern.matcher((String)value);
/*  398 */     return matcher.find();
/*      */   }
/*      */ 
/*      */   private static boolean matchesExistsConstraint(Object constraint, Object value)
/*      */   {
/*  408 */     if ((constraint != null) && (((Boolean)constraint).booleanValue())) {
/*  409 */       return (value != null) && (value != JSONObject.NULL);
/*      */     }
/*  411 */     return (value == null) || (value == JSONObject.NULL);
/*      */   }
/*      */ 
/*      */   private static boolean matchesNearSphereConstraint(Object constraint, Object value, Double maxDistance)
/*      */   {
/*  420 */     if ((value == null) || (value == JSONObject.NULL)) {
/*  421 */       return false;
/*      */     }
/*  423 */     if (maxDistance == null) {
/*  424 */       return true;
/*      */     }
/*  426 */     ParseGeoPoint point1 = (ParseGeoPoint)constraint;
/*  427 */     ParseGeoPoint point2 = (ParseGeoPoint)value;
/*  428 */     return point1.distanceInRadiansTo(point2) <= maxDistance.doubleValue();
/*      */   }
/*      */ 
/*      */   private static boolean matchesWithinConstraint(Object constraint, Object value)
/*      */     throws ParseException
/*      */   {
/*  437 */     HashMap constraintMap = (HashMap)constraint;
/*      */ 
/*  439 */     ArrayList box = (ArrayList)constraintMap.get("$box");
/*  440 */     ParseGeoPoint southwest = (ParseGeoPoint)box.get(0);
/*  441 */     ParseGeoPoint northeast = (ParseGeoPoint)box.get(1);
/*  442 */     ParseGeoPoint target = (ParseGeoPoint)value;
/*      */ 
/*  444 */     if (northeast.getLongitude() < southwest.getLongitude()) {
/*  445 */       throw new ParseException(102, "whereWithinGeoBox queries cannot cross the International Date Line.");
/*      */     }
/*      */ 
/*  448 */     if (northeast.getLatitude() < southwest.getLatitude()) {
/*  449 */       throw new ParseException(102, "The southwest corner of a geo box must be south of the northeast corner.");
/*      */     }
/*      */ 
/*  452 */     if (northeast.getLongitude() - southwest.getLongitude() > 180.0D) {
/*  453 */       throw new ParseException(102, "Geo box queries larger than 180 degrees in longitude are not supported. Please check point order.");
/*      */     }
/*      */ 
/*  458 */     return (target.getLatitude() >= southwest.getLatitude()) && (target.getLatitude() <= northeast.getLatitude()) && (target.getLongitude() >= southwest.getLongitude()) && (target.getLongitude() <= northeast.getLongitude());
/*      */   }
/*      */ 
/*      */   private static boolean matchesStatelessConstraint(String operator, Object constraint, Object value, ParseQuery.KeyConstraints allKeyConstraints)
/*      */     throws ParseException
/*      */   {
/*  472 */     if (operator.equals("$ne")) {
/*  473 */       return matchesNotEqualConstraint(constraint, value);
/*      */     }
/*  475 */     if (operator.equals("$lt")) {
/*  476 */       return matchesLessThanConstraint(constraint, value);
/*      */     }
/*  478 */     if (operator.equals("$lte")) {
/*  479 */       return matchesLessThanOrEqualToConstraint(constraint, value);
/*      */     }
/*  481 */     if (operator.equals("$gt")) {
/*  482 */       return matchesGreaterThanConstraint(constraint, value);
/*      */     }
/*  484 */     if (operator.equals("$gte")) {
/*  485 */       return matchesGreaterThanOrEqualToConstraint(constraint, value);
/*      */     }
/*  487 */     if (operator.equals("$in")) {
/*  488 */       return matchesInConstraint(constraint, value);
/*      */     }
/*  490 */     if (operator.equals("$nin")) {
/*  491 */       return matchesNotInConstraint(constraint, value);
/*      */     }
/*  493 */     if (operator.equals("$all")) {
/*  494 */       return matchesAllConstraint(constraint, value);
/*      */     }
/*  496 */     if (operator.equals("$regex")) {
/*  497 */       String regexOptions = (String)allKeyConstraints.get("$options");
/*  498 */       return matchesRegexConstraint(constraint, value, regexOptions);
/*      */     }
/*  500 */     if (operator.equals("$options"))
/*      */     {
/*  502 */       return true;
/*      */     }
/*  504 */     if (operator.equals("$exists")) {
/*  505 */       return matchesExistsConstraint(constraint, value);
/*      */     }
/*  507 */     if (operator.equals("$nearSphere")) {
/*  508 */       Double maxDistance = (Double)allKeyConstraints.get("$maxDistance");
/*  509 */       return matchesNearSphereConstraint(constraint, value, maxDistance);
/*      */     }
/*  511 */     if (operator.equals("$maxDistance"))
/*      */     {
/*  513 */       return true;
/*      */     }
/*  515 */     if (operator.equals("$within")) {
/*  516 */       return matchesWithinConstraint(constraint, value);
/*      */     }
/*      */ 
/*  519 */     throw new UnsupportedOperationException(String.format("The offline store does not yet support the %s operator.", new Object[] { operator }));
/*      */   }
/*      */ 
/*      */   private <T extends ParseObject> ConstraintMatcher<T> createInQueryMatcher(ParseUser user, Object constraint, String key)
/*      */   {
/*  561 */     ParseQuery query = (ParseQuery)constraint;
/*  562 */     return new SubQueryMatcher(user, query, key)
/*      */     {
/*      */       protected boolean matches(T object, List<T> results) throws ParseException {
/*  565 */         Object value = OfflineQueryLogic.this.getValue(object, this.val$key);
/*  566 */         return OfflineQueryLogic.access$300(results, value);
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   private <T extends ParseObject> ConstraintMatcher<T> createNotInQueryMatcher(ParseUser user, Object constraint, String key)
/*      */   {
/*  576 */     ConstraintMatcher inQueryMatcher = createInQueryMatcher(user, constraint, key);
/*  577 */     return new ConstraintMatcher(user, inQueryMatcher)
/*      */     {
/*      */       public Task<Boolean> matchesAsync(T object, ParseSQLiteDatabase db) {
/*  580 */         return this.val$inQueryMatcher.matchesAsync(object, db).onSuccess(new Continuation()
/*      */         {
/*      */           public Boolean then(Task<Boolean> task) throws Exception {
/*  583 */             return Boolean.valueOf(!((Boolean)task.getResult()).booleanValue());
/*      */           }
/*      */         });
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   private <T extends ParseObject> ConstraintMatcher<T> createSelectMatcher(ParseUser user, Object constraint, String key)
/*      */   {
/*  595 */     JSONObject constraintJSON = (JSONObject)constraint;
/*  596 */     ParseQuery query = (ParseQuery)constraintJSON.opt("query");
/*  597 */     String resultKey = constraintJSON.optString("key", null);
/*  598 */     return new SubQueryMatcher(user, query, key, resultKey)
/*      */     {
/*      */       protected boolean matches(T object, List<T> results) throws ParseException {
/*  601 */         Object value = OfflineQueryLogic.this.getValue(object, this.val$key);
/*  602 */         for (ParseObject result : results) {
/*  603 */           Object resultValue = OfflineQueryLogic.this.getValue(result, this.val$resultKey);
/*  604 */           if (OfflineQueryLogic.access$400(value, resultValue)) {
/*  605 */             return true;
/*      */           }
/*      */         }
/*  608 */         return false;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   private <T extends ParseObject> ConstraintMatcher<T> createDontSelectMatcher(ParseUser user, Object constraint, String key)
/*      */   {
/*  618 */     ConstraintMatcher selectMatcher = createSelectMatcher(user, constraint, key);
/*  619 */     return new ConstraintMatcher(user, selectMatcher)
/*      */     {
/*      */       public Task<Boolean> matchesAsync(T object, ParseSQLiteDatabase db) {
/*  622 */         return this.val$selectMatcher.matchesAsync(object, db).onSuccess(new Continuation()
/*      */         {
/*      */           public Boolean then(Task<Boolean> task) throws Exception {
/*  625 */             return Boolean.valueOf(!((Boolean)task.getResult()).booleanValue());
/*      */           }
/*      */         });
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   private <T extends ParseObject> ConstraintMatcher<T> createMatcher(ParseUser user, String operator, Object constraint, String key, ParseQuery.KeyConstraints allKeyConstraints)
/*      */   {
/*  638 */     if (operator.equals("$inQuery")) {
/*  639 */       return createInQueryMatcher(user, constraint, key);
/*      */     }
/*  641 */     if (operator.equals("$notInQuery")) {
/*  642 */       return createNotInQueryMatcher(user, constraint, key);
/*      */     }
/*  644 */     if (operator.equals("$select")) {
/*  645 */       return createSelectMatcher(user, constraint, key);
/*      */     }
/*  647 */     if (operator.equals("$dontSelect")) {
/*  648 */       return createDontSelectMatcher(user, constraint, key);
/*      */     }
/*      */ 
/*  654 */     return new ConstraintMatcher(user, key, operator, constraint, allKeyConstraints)
/*      */     {
/*      */       public Task<Boolean> matchesAsync(T object, ParseSQLiteDatabase db) {
/*      */         try {
/*  658 */           Object value = OfflineQueryLogic.this.getValue(object, this.val$key);
/*  659 */           return Task.forResult(Boolean.valueOf(OfflineQueryLogic.access$500(this.val$operator, this.val$constraint, value, this.val$allKeyConstraints)));
/*      */         } catch (ParseException e) {
/*      */         }
/*  662 */         return Task.forError(e);
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   private <T extends ParseObject> ConstraintMatcher<T> createOrMatcher(ParseUser user, ArrayList<ParseQuery.QueryConstraints> queries)
/*      */   {
/*  675 */     ArrayList matchers = new ArrayList();
/*  676 */     for (ParseQuery.QueryConstraints constraints : queries) {
/*  677 */       ConstraintMatcher matcher = createMatcher(user, constraints);
/*  678 */       matchers.add(matcher);
/*      */     }
/*      */ 
/*  683 */     return new ConstraintMatcher(user, matchers)
/*      */     {
/*      */       public Task<Boolean> matchesAsync(T object, ParseSQLiteDatabase db) {
/*  686 */         Task task = Task.forResult(Boolean.valueOf(false));
/*  687 */         for (OfflineQueryLogic.ConstraintMatcher matcher : this.val$matchers)
/*  688 */           task = task.onSuccessTask(new Continuation(matcher, object, db)
/*      */           {
/*      */             public Task<Boolean> then(Task<Boolean> task) throws Exception {
/*  691 */               if (((Boolean)task.getResult()).booleanValue()) {
/*  692 */                 return task;
/*      */               }
/*  694 */               return this.val$matcher.matchesAsync(this.val$object, this.val$db);
/*      */             }
/*      */           });
/*  698 */         return task;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   private <T extends ParseObject> ConstraintMatcher<T> createMatcher(ParseUser user, ParseQuery.QueryConstraints queryConstraints)
/*      */   {
/*  712 */     ArrayList matchers = new ArrayList();
/*  713 */     for (String key : queryConstraints.keySet()) {
/*  714 */       Object queryConstraintValue = queryConstraints.get(key);
/*      */ 
/*  716 */       if (key.equals("$or"))
/*      */       {
/*  721 */         ConstraintMatcher matcher = createOrMatcher(user, (ArrayList)queryConstraintValue);
/*      */ 
/*  723 */         matchers.add(matcher);
/*      */       }
/*      */       else
/*      */       {
/*      */         ParseQuery.KeyConstraints keyConstraints;
/*  725 */         if ((queryConstraintValue instanceof ParseQuery.KeyConstraints))
/*      */         {
/*  729 */           keyConstraints = (ParseQuery.KeyConstraints)queryConstraintValue;
/*  730 */           for (String operator : keyConstraints.keySet()) {
/*  731 */             Object keyConstraintValue = keyConstraints.get(operator);
/*  732 */             ConstraintMatcher matcher = createMatcher(user, operator, keyConstraintValue, key, keyConstraints);
/*      */ 
/*  734 */             matchers.add(matcher);
/*      */           }
/*      */         }
/*  737 */         else if ((queryConstraintValue instanceof ParseQuery.RelationConstraint))
/*      */         {
/*  741 */           ParseQuery.RelationConstraint relation = (ParseQuery.RelationConstraint)queryConstraintValue;
/*  742 */           matchers.add(new ConstraintMatcher(user, relation)
/*      */           {
/*      */             public Task<Boolean> matchesAsync(T object, ParseSQLiteDatabase db) {
/*  745 */               return Task.forResult(Boolean.valueOf(this.val$relation.getRelation().hasKnownObject(object)));
/*      */             }
/*      */ 
/*      */           });
/*      */         }
/*      */         else
/*      */         {
/*  753 */           matchers.add(new ConstraintMatcher(user, key, queryConstraintValue) {
/*      */             public Task<Boolean> matchesAsync(T object, ParseSQLiteDatabase db) {
/*      */               Object objectValue;
/*      */               try {
/*  758 */                 objectValue = OfflineQueryLogic.this.getValue(object, this.val$key);
/*      */               } catch (ParseException e) {
/*  760 */                 return Task.forError(e);
/*      */               }
/*  762 */               return Task.forResult(Boolean.valueOf(OfflineQueryLogic.access$400(this.val$queryConstraintValue, objectValue)));
/*      */             }
/*      */           });
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  771 */     return new ConstraintMatcher(user, matchers)
/*      */     {
/*      */       public Task<Boolean> matchesAsync(T object, ParseSQLiteDatabase db) {
/*  774 */         Task task = Task.forResult(Boolean.valueOf(true));
/*  775 */         for (OfflineQueryLogic.ConstraintMatcher matcher : this.val$matchers)
/*  776 */           task = task.onSuccessTask(new Continuation(matcher, object, db)
/*      */           {
/*      */             public Task<Boolean> then(Task<Boolean> task) throws Exception {
/*  779 */               if (!((Boolean)task.getResult()).booleanValue()) {
/*  780 */                 return task;
/*      */               }
/*  782 */               return this.val$matcher.matchesAsync(this.val$object, this.val$db);
/*      */             }
/*      */           });
/*  786 */         return task;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   static <T extends ParseObject> boolean hasReadAccess(ParseUser user, T object)
/*      */   {
/*  795 */     if (user == object) {
/*  796 */       return true;
/*      */     }
/*      */ 
/*  799 */     ParseACL acl = object.getACL();
/*  800 */     if (acl == null) {
/*  801 */       return true;
/*      */     }
/*  803 */     if (acl.getPublicReadAccess()) {
/*  804 */       return true;
/*      */     }
/*      */ 
/*  807 */     return (user != null) && (acl.getReadAccess(user));
/*      */   }
/*      */ 
/*      */   static <T extends ParseObject> boolean hasWriteAccess(ParseUser user, T object)
/*      */   {
/*  817 */     if (user == object) {
/*  818 */       return true;
/*      */     }
/*      */ 
/*  821 */     ParseACL acl = object.getACL();
/*  822 */     if (acl == null) {
/*  823 */       return true;
/*      */     }
/*  825 */     if (acl.getPublicWriteAccess()) {
/*  826 */       return true;
/*      */     }
/*      */ 
/*  829 */     return (user != null) && (acl.getWriteAccess(user));
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> ConstraintMatcher<T> createMatcher(ParseQuery<T> query, ParseUser user)
/*      */   {
/*  846 */     boolean ignoreACLs = query.ignoreACLs;
/*  847 */     ConstraintMatcher constraintMatcher = createMatcher(user, query.getConstraints());
/*      */ 
/*  849 */     return new ConstraintMatcher(user, ignoreACLs, constraintMatcher)
/*      */     {
/*      */       public Task<Boolean> matchesAsync(T object, ParseSQLiteDatabase db) {
/*  852 */         if ((!this.val$ignoreACLs) && (!OfflineQueryLogic.hasReadAccess(this.user, object))) {
/*  853 */           return Task.forResult(Boolean.valueOf(false));
/*      */         }
/*  855 */         return this.val$constraintMatcher.matchesAsync(object, db);
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> void sort(List<T> results, ParseQuery<T> query)
/*      */     throws ParseException
/*      */   {
/*  865 */     String[] keys = query.sortKeys();
/*      */ 
/*  867 */     for (String key : keys) {
/*  868 */       if ((key.matches("^-?[A-Za-z][A-Za-z0-9_]*$")) || 
/*  869 */         ("_created_at".equals(key)) || ("_updated_at".equals(key))) continue;
/*  870 */       throw new ParseException(105, String.format("Invalid key name: \"%s\".", new Object[] { key }));
/*      */     }
/*      */ 
/*  877 */     String mutableNearSphereKey = null;
/*  878 */     ParseGeoPoint mutableNearSphereValue = null;
/*  879 */     for (String queryKey : query.getConstraints().keySet()) {
/*  880 */       Object queryKeyConstraints = query.getConstraints().get(queryKey);
/*  881 */       if ((queryKeyConstraints instanceof ParseQuery.KeyConstraints)) {
/*  882 */         ParseQuery.KeyConstraints keyConstraints = (ParseQuery.KeyConstraints)queryKeyConstraints;
/*  883 */         if (keyConstraints.containsKey("$nearSphere")) {
/*  884 */           mutableNearSphereKey = queryKey;
/*  885 */           mutableNearSphereValue = (ParseGeoPoint)keyConstraints.get("$nearSphere");
/*      */         }
/*      */       }
/*      */     }
/*  889 */     String nearSphereKey = mutableNearSphereKey;
/*  890 */     ParseGeoPoint nearSphereValue = mutableNearSphereValue;
/*      */ 
/*  893 */     if ((keys.length == 0) && (mutableNearSphereKey == null)) {
/*  894 */       return;
/*      */     }
/*      */ 
/*  901 */     Collections.sort(results, new Object(nearSphereKey, nearSphereValue, keys)
/*      */     {
/*      */       public int compare(T lhs, T rhs) {
/*  904 */         if (this.val$nearSphereKey != null) { ParseGeoPoint lhsPoint;
/*      */           ParseGeoPoint rhsPoint;
/*      */           try { lhsPoint = (ParseGeoPoint)OfflineQueryLogic.this.getValue(lhs, this.val$nearSphereKey);
/*  909 */             rhsPoint = (ParseGeoPoint)OfflineQueryLogic.this.getValue(rhs, this.val$nearSphereKey);
/*      */           } catch (ParseException e) {
/*  911 */             throw new RuntimeException(e);
/*      */           }
/*      */ 
/*  915 */           double lhsDistance = lhsPoint.distanceInRadiansTo(this.val$nearSphereValue);
/*  916 */           double rhsDistance = rhsPoint.distanceInRadiansTo(this.val$nearSphereValue);
/*  917 */           if (lhsDistance != rhsDistance) {
/*  918 */             return lhsDistance - rhsDistance > 0.0D ? 1 : -1;
/*      */           }
/*      */         }
/*      */ 
/*  922 */         for (String key : this.val$keys) {
/*  923 */           boolean descending = false;
/*  924 */           if (key.startsWith("-")) {
/*  925 */             descending = true;
/*  926 */             key = key.substring(1);
/*      */           }Object lhsValue;
/*      */           Object rhsValue;
/*      */           try {
/*  932 */             lhsValue = OfflineQueryLogic.this.getValue(lhs, key);
/*  933 */             rhsValue = OfflineQueryLogic.this.getValue(rhs, key);
/*      */           } catch (ParseException e) {
/*  935 */             throw new RuntimeException(e);
/*      */           }
/*      */           int result;
/*      */           try {
/*  940 */             result = OfflineQueryLogic.access$000(lhsValue, rhsValue);
/*      */           } catch (IllegalArgumentException e) {
/*  942 */             throw new IllegalArgumentException(String.format("Unable to sort by key %s.", new Object[] { key }), e);
/*      */           }
/*  944 */           if (result != 0) {
/*  945 */             return descending ? -result : result;
/*      */           }
/*      */         }
/*  948 */         return 0;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private Task<Void> fetchIncludeAsync(Object container, String path, ParseSQLiteDatabase db)
/*      */     throws ParseException
/*      */   {
/*  959 */     if (container == null) {
/*  960 */       return Task.forResult(null);
/*      */     }
/*      */ 
/*  964 */     if ((container instanceof JSONArray)) {
/*  965 */       JSONArray array = (JSONArray)container;
/*      */ 
/*  967 */       Task task = Task.forResult(null);
/*  968 */       for (int i = 0; i < array.length(); i++) {
/*  969 */         int index = i;
/*  970 */         task = task.onSuccessTask(new Continuation(array, index, path, db)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task) throws Exception {
/*  973 */             return OfflineQueryLogic.this.fetchIncludeAsync(this.val$array.get(this.val$index), this.val$path, this.val$db);
/*      */           } } );
/*      */       }
/*  977 */       return task;
/*      */     }
/*  979 */     if ((container instanceof List)) {
/*  980 */       List list = (List)container;
/*      */ 
/*  982 */       Task task = Task.forResult(null);
/*  983 */       for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object item = i$.next();
/*  984 */         task = task.onSuccessTask(new Continuation(item, path, db)
/*      */         {
/*      */           public Task<Void> then(Task<Void> task) throws Exception {
/*  987 */             return OfflineQueryLogic.this.fetchIncludeAsync(this.val$item, this.val$path, this.val$db);
/*      */           }
/*      */         }); }
/*  991 */       return task;
/*      */     }
/*      */ 
/*  995 */     if (path == null) {
/*  996 */       if (JSONObject.NULL.equals(container))
/*      */       {
/*  999 */         return null;
/* 1000 */       }if ((container instanceof ParseObject)) {
/* 1001 */         ParseObject object = (ParseObject)container;
/* 1002 */         return this.store.fetchLocallyAsync(object, db).makeVoid();
/*      */       }
/* 1004 */       return Task.forError(new ParseException(121, "include is invalid for non-ParseObjects"));
/*      */     }
/*      */ 
/* 1011 */     String[] parts = path.split("\\.", 2);
/* 1012 */     String key = parts[0];
/* 1013 */     String rest = parts.length > 1 ? parts[1] : null;
/*      */ 
/* 1016 */     return Task.forResult(null).continueWithTask(new Continuation(container, db, key)
/*      */     {
/*      */       public Task<Object> then(Task<Void> task) throws Exception {
/* 1019 */         if ((this.val$container instanceof ParseObject))
/*      */         {
/* 1021 */           return OfflineQueryLogic.this.fetchIncludeAsync(this.val$container, null, this.val$db).onSuccess(new Continuation()
/*      */           {
/*      */             public Object then(Task<Void> task) throws Exception {
/* 1024 */               return ((ParseObject)OfflineQueryLogic.20.this.val$container).get(OfflineQueryLogic.20.this.val$key);
/*      */             } } );
/*      */         }
/* 1027 */         if ((this.val$container instanceof Map))
/* 1028 */           return Task.forResult(((Map)this.val$container).get(this.val$key));
/* 1029 */         if ((this.val$container instanceof JSONObject))
/* 1030 */           return Task.forResult(((JSONObject)this.val$container).opt(this.val$key));
/* 1031 */         if (JSONObject.NULL.equals(this.val$container))
/*      */         {
/* 1034 */           return null;
/*      */         }
/* 1036 */         return Task.forError(new IllegalStateException("include is invalid"));
/*      */       }
/*      */     }).onSuccessTask(new Continuation(rest, db)
/*      */     {
/*      */       public Task<Void> then(Task<Object> task)
/*      */         throws Exception
/*      */       {
/* 1042 */         return OfflineQueryLogic.this.fetchIncludeAsync(task.getResult(), this.val$rest, this.val$db);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   <T extends ParseObject> Task<Void> fetchIncludes(T object, ParseQuery<T> query, ParseSQLiteDatabase db)
/*      */   {
/* 1052 */     List includes = query.getIncludes();
/*      */ 
/* 1054 */     Task task = Task.forResult(null);
/* 1055 */     for (String include : includes)
/* 1056 */       task = task.onSuccessTask(new Continuation(object, include, db)
/*      */       {
/*      */         public Task<Void> then(Task<Void> task) throws Exception {
/* 1059 */           return OfflineQueryLogic.this.fetchIncludeAsync(this.val$object, this.val$include, this.val$db);
/*      */         }
/*      */       });
/* 1063 */     return task;
/*      */   }
/*      */ 
/*      */   private abstract class SubQueryMatcher<T extends ParseObject> extends OfflineQueryLogic.ConstraintMatcher<T>
/*      */   {
/*      */     private final ParseQuery<T> subQuery;
/*  526 */     private Task<List<T>> subQueryResults = null;
/*      */ 
/*      */     public SubQueryMatcher(ParseQuery<T> user) {
/*  529 */       super(user);
/*  530 */       this.subQuery = subQuery;
/*      */     }
/*      */ 
/*      */     public Task<Boolean> matchesAsync(T object, ParseSQLiteDatabase db)
/*      */     {
/*  539 */       if (this.subQueryResults == null)
/*      */       {
/*  542 */         this.subQueryResults = OfflineQueryLogic.this.store.findAsync(this.subQuery, this.user, null, db);
/*      */       }
/*  544 */       return this.subQueryResults.onSuccess(new Continuation(object)
/*      */       {
/*      */         public Boolean then(Task<List<T>> task) throws ParseException {
/*  547 */           return Boolean.valueOf(OfflineQueryLogic.SubQueryMatcher.this.matches(this.val$object, (List)task.getResult()));
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/*      */     protected abstract boolean matches(T paramT, List<T> paramList)
/*      */       throws ParseException;
/*      */   }
/*      */ 
/*      */   private static abstract interface Decider
/*      */   {
/*      */     public abstract boolean decide(Object paramObject1, Object paramObject2);
/*      */   }
/*      */ 
/*      */   abstract class ConstraintMatcher<T extends ParseObject>
/*      */   {
/*      */     protected ParseUser user;
/*      */ 
/*      */     public ConstraintMatcher(ParseUser user)
/*      */     {
/*   36 */       this.user = user;
/*      */     }
/*      */ 
/*      */     abstract Task<Boolean> matchesAsync(T paramT, ParseSQLiteDatabase paramParseSQLiteDatabase);
/*      */   }
/*      */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.OfflineQueryLogic
 * JD-Core Version:    0.6.0
 */