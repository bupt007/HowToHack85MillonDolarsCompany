/*     */ package com.parse;
/*     */ 
/*     */ import android.location.Criteria;
/*     */ import android.location.Location;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ 
/*     */ public class ParseGeoPoint
/*     */ {
/*  26 */   static double EARTH_MEAN_RADIUS_KM = 6371.0D;
/*  27 */   static double EARTH_MEAN_RADIUS_MILE = 3958.8000000000002D;
/*     */ 
/*  29 */   private double latitude = 0.0D;
/*  30 */   private double longitude = 0.0D;
/*     */ 
/*     */   public ParseGeoPoint()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ParseGeoPoint(double latitude, double longitude)
/*     */   {
/*  47 */     setLatitude(latitude);
/*  48 */     setLongitude(longitude);
/*     */   }
/*     */ 
/*     */   public void setLatitude(double latitude)
/*     */   {
/*  58 */     if ((latitude > 90.0D) || (latitude < -90.0D)) {
/*  59 */       throw new IllegalArgumentException("Latitude must be within the range (-90.0, 90.0).");
/*     */     }
/*  61 */     this.latitude = latitude;
/*     */   }
/*     */ 
/*     */   public double getLatitude()
/*     */   {
/*  68 */     return this.latitude;
/*     */   }
/*     */ 
/*     */   public void setLongitude(double longitude)
/*     */   {
/*  78 */     if ((longitude > 180.0D) || (longitude < -180.0D)) {
/*  79 */       throw new IllegalArgumentException("Longitude must be within the range (-180.0, 180.0).");
/*     */     }
/*  81 */     this.longitude = longitude;
/*     */   }
/*     */ 
/*     */   public double getLongitude()
/*     */   {
/*  88 */     return this.longitude;
/*     */   }
/*     */ 
/*     */   public double distanceInRadiansTo(ParseGeoPoint point)
/*     */   {
/*  99 */     double d2r = 0.0174532925199433D;
/* 100 */     double lat1rad = this.latitude * d2r;
/* 101 */     double long1rad = this.longitude * d2r;
/* 102 */     double lat2rad = point.getLatitude() * d2r;
/* 103 */     double long2rad = point.getLongitude() * d2r;
/* 104 */     double deltaLat = lat1rad - lat2rad;
/* 105 */     double deltaLong = long1rad - long2rad;
/* 106 */     double sinDeltaLatDiv2 = Math.sin(deltaLat / 2.0D);
/* 107 */     double sinDeltaLongDiv2 = Math.sin(deltaLong / 2.0D);
/*     */ 
/* 110 */     double a = sinDeltaLatDiv2 * sinDeltaLatDiv2 + Math.cos(lat1rad) * Math.cos(lat2rad) * sinDeltaLongDiv2 * sinDeltaLongDiv2;
/*     */ 
/* 113 */     a = Math.min(1.0D, a);
/* 114 */     return 2.0D * Math.asin(Math.sqrt(a));
/*     */   }
/*     */ 
/*     */   public double distanceInKilometersTo(ParseGeoPoint point)
/*     */   {
/* 124 */     return distanceInRadiansTo(point) * EARTH_MEAN_RADIUS_KM;
/*     */   }
/*     */ 
/*     */   public double distanceInMilesTo(ParseGeoPoint point)
/*     */   {
/* 134 */     return distanceInRadiansTo(point) * EARTH_MEAN_RADIUS_MILE;
/*     */   }
/*     */ 
/*     */   public static Task<ParseGeoPoint> getCurrentLocationInBackground(long timeout)
/*     */   {
/* 154 */     Criteria criteria = new Criteria();
/* 155 */     criteria.setAccuracy(0);
/* 156 */     criteria.setPowerRequirement(0);
/* 157 */     return LocationNotifier.getCurrentLocationAsync(Parse.getApplicationContext(), timeout, criteria).onSuccess(new Continuation()
/*     */     {
/*     */       public ParseGeoPoint then(Task<Location> task) throws Exception
/*     */       {
/* 161 */         Location location = (Location)task.getResult();
/* 162 */         return new ParseGeoPoint(location.getLatitude(), location.getLongitude());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static void getCurrentLocationInBackground(long timeout, LocationCallback callback)
/*     */   {
/* 185 */     Parse.callbackOnMainThreadAsync(getCurrentLocationInBackground(timeout), callback);
/*     */   }
/*     */ 
/*     */   public static Task<ParseGeoPoint> getCurrentLocationInBackground(long timeout, Criteria criteria)
/*     */   {
/* 210 */     return LocationNotifier.getCurrentLocationAsync(Parse.getApplicationContext(), timeout, criteria).onSuccess(new Continuation()
/*     */     {
/*     */       public ParseGeoPoint then(Task<Location> task) throws Exception
/*     */       {
/* 214 */         Location location = (Location)task.getResult();
/* 215 */         return new ParseGeoPoint(location.getLatitude(), location.getLongitude());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static void getCurrentLocationInBackground(long timeout, Criteria criteria, LocationCallback callback)
/*     */   {
/* 244 */     Parse.callbackOnMainThreadAsync(getCurrentLocationInBackground(timeout, criteria), callback);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 249 */     return String.format("ParseGeoPoint[%.6f,%.6f]", new Object[] { Double.valueOf(this.latitude), Double.valueOf(this.longitude) });
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseGeoPoint
 * JD-Core Version:    0.6.0
 */