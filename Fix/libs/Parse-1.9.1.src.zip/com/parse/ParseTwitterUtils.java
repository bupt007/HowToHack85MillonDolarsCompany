/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import bolts.Task;
/*     */ import com.parse.twitter.Twitter;
/*     */ import org.json.JSONException;
/*     */ 
/*     */ public final class ParseTwitterUtils
/*     */ {
/*     */   private static Twitter twitter;
/*     */   private static TwitterAuthenticationProvider provider;
/*     */   private static boolean isInitialized;
/*     */ 
/*     */   private static TwitterAuthenticationProvider getAuthenticationProvider()
/*     */   {
/*  20 */     if (provider == null) {
/*  21 */       provider = new TwitterAuthenticationProvider(getTwitter());
/*  22 */       ParseUser.registerAuthenticationProvider(provider);
/*     */     }
/*  24 */     return provider;
/*     */   }
/*     */ 
/*     */   public static Twitter getTwitter()
/*     */   {
/*  33 */     if (twitter == null) {
/*  34 */       twitter = new Twitter("", "");
/*     */     }
/*  36 */     return twitter;
/*     */   }
/*     */ 
/*     */   public static void initialize(String consumerKey, String consumerSecret)
/*     */   {
/*  49 */     getTwitter().setConsumerKey(consumerKey).setConsumerSecret(consumerSecret);
/*     */ 
/*  52 */     getAuthenticationProvider();
/*  53 */     isInitialized = true;
/*     */   }
/*     */ 
/*     */   private static void checkInitialization() {
/*  57 */     if (!isInitialized)
/*  58 */       throw new IllegalStateException("You must call ParseTwitterUtils.initialize() before using ParseTwitterUtils");
/*     */   }
/*     */ 
/*     */   public static boolean isLinked(ParseUser user)
/*     */   {
/*  67 */     return user.isLinked("twitter");
/*     */   }
/*     */ 
/*     */   public static Task<Void> linkInBackground(Context context, ParseUser user)
/*     */   {
/*  84 */     checkInitialization();
/*  85 */     return getAuthenticationProvider().setContext(context).linkAsync(user);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void link(ParseUser user, Context context)
/*     */   {
/*  95 */     link(user, context, null);
/*     */   }
/*     */ 
/*     */   public static void link(ParseUser user, Context context, SaveCallback callback)
/*     */   {
/* 114 */     Parse.callbackOnMainThreadAsync(linkInBackground(context, user), callback, true);
/*     */   }
/*     */ 
/*     */   public static Task<Void> linkInBackground(ParseUser user, String twitterId, String screenName, String authToken, String authTokenSecret)
/*     */   {
/* 136 */     checkInitialization();
/*     */     try {
/* 138 */       TwitterAuthenticationProvider provider = getAuthenticationProvider();
/* 139 */       return provider.linkAsync(user, provider.getAuthData(twitterId, screenName, authToken, authTokenSecret));
/*     */     }
/*     */     catch (JSONException e) {
/*     */     }
/* 143 */     return Task.forError(new ParseException(e));
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void link(ParseUser user, String twitterId, String screenName, String authToken, String authTokenSecret)
/*     */   {
/* 154 */     link(user, twitterId, screenName, authToken, authTokenSecret, null);
/*     */   }
/*     */ 
/*     */   public static void link(ParseUser user, String twitterId, String screenName, String authToken, String authTokenSecret, SaveCallback callback)
/*     */   {
/* 179 */     Parse.callbackOnMainThreadAsync(linkInBackground(user, twitterId, screenName, authToken, authTokenSecret), callback);
/*     */   }
/*     */ 
/*     */   public static Task<ParseUser> logInInBackground(String twitterId, String screenName, String authToken, String authTokenSecret)
/*     */   {
/* 203 */     checkInitialization();
/*     */     try {
/* 205 */       TwitterAuthenticationProvider provider = getAuthenticationProvider();
/* 206 */       return provider.logInAsync(provider.getAuthData(twitterId, screenName, authToken, authTokenSecret));
/*     */     } catch (JSONException e) {
/*     */     }
/* 209 */     return Task.forError(new ParseException(e));
/*     */   }
/*     */ 
/*     */   public static void logIn(String twitterId, String screenName, String authToken, String authTokenSecret, LogInCallback callback)
/*     */   {
/* 234 */     Parse.callbackOnMainThreadAsync(logInInBackground(twitterId, screenName, authToken, authTokenSecret), callback);
/*     */   }
/*     */ 
/*     */   public static Task<ParseUser> logInInBackground(Context context)
/*     */   {
/* 250 */     checkInitialization();
/* 251 */     return getAuthenticationProvider().setContext(context).logInAsync();
/*     */   }
/*     */ 
/*     */   public static void logIn(Context context, LogInCallback callback)
/*     */   {
/* 270 */     Parse.callbackOnMainThreadAsync(logInInBackground(context), callback, true);
/*     */   }
/*     */ 
/*     */   public static void unlink(ParseUser user)
/*     */     throws ParseException
/*     */   {
/* 280 */     Parse.waitForTask(unlinkInBackground(user));
/*     */   }
/*     */ 
/*     */   public static Task<Void> unlinkInBackground(ParseUser user)
/*     */   {
/* 292 */     checkInitialization();
/* 293 */     return getAuthenticationProvider().unlinkAsync(user);
/*     */   }
/*     */ 
/*     */   public static void unlinkInBackground(ParseUser user, SaveCallback callback)
/*     */   {
/* 308 */     Parse.callbackOnMainThreadAsync(unlinkInBackground(user), callback);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseTwitterUtils
 * JD-Core Version:    0.6.0
 */