/*    */ package com.parse;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseRESTQueryCommand extends ParseRESTCommand
/*    */ {
/*    */   public ParseRESTQueryCommand(String httpPath, ParseRequest.Method httpMethod, Map<String, ?> parameters, String sessionToken)
/*    */   {
/* 12 */     super(httpPath, httpMethod, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTQueryCommand findCommand(String className, String order, Map<String, ?> conditions, List<String> selectedKeys, List<String> includedKeys, int limit, int skip, Map<String, ?> extraOptions, boolean tracingEnabled, String sessionToken)
/*    */   {
/* 18 */     String httpPath = String.format("classes/%s", new Object[] { className });
/* 19 */     Map parameters = findCommandParameters(order, conditions, selectedKeys, includedKeys, limit, skip, extraOptions, tracingEnabled);
/*    */ 
/* 21 */     return new ParseRESTQueryCommand(httpPath, ParseRequest.Method.GET, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTQueryCommand countCommand(ParseRESTQueryCommand findCommand) {
/* 25 */     ParseDecoder decoder = new ParseDecoder();
/* 26 */     Map parameters = decoder.convertJSONObjectToMap(findCommand.jsonParameters);
/* 27 */     parameters.put("count", Integer.toString(1));
/* 28 */     parameters.remove("limit");
/* 29 */     parameters.remove("skip");
/* 30 */     return new ParseRESTQueryCommand(findCommand.httpPath, findCommand.method, parameters, findCommand.sessionToken);
/*    */   }
/*    */ 
/*    */   public static Map<String, String> findCommandParameters(String order, Map<String, ?> conditions, List<String> selectedKeys, List<String> includedKeys, int limit, int skip, Map<String, ?> extraOptions, boolean tracingEnabled)
/*    */   {
/* 37 */     HashMap parameters = new HashMap();
/* 38 */     if (order != null) {
/* 39 */       parameters.put("order", order);
/*    */     }
/* 41 */     if ((conditions != null) && (conditions.size() > 0)) {
/* 42 */       JSONObject encodedConditions = (JSONObject)Parse.encode(conditions, PointerEncodingStrategy.get());
/*    */ 
/* 44 */       parameters.put("where", encodedConditions.toString());
/*    */     }
/* 46 */     if (selectedKeys != null) {
/* 47 */       parameters.put("keys", Parse.join(",", selectedKeys));
/*    */     }
/* 49 */     if ((includedKeys != null) && (includedKeys.size() > 0)) {
/* 50 */       parameters.put("include", Parse.join(",", includedKeys));
/*    */     }
/* 52 */     if (limit >= 0) {
/* 53 */       parameters.put("limit", Integer.toString(limit));
/*    */     }
/* 55 */     if (skip > 0) {
/* 56 */       parameters.put("skip", Integer.toString(skip));
/*    */     }
/* 58 */     for (String key : extraOptions.keySet()) {
/* 59 */       JSONObject encodedExtraOptions = (JSONObject)Parse.encode(extraOptions.get(key), PointerEncodingStrategy.get());
/*    */ 
/* 61 */       parameters.put(key, encodedExtraOptions.toString());
/*    */     }
/* 63 */     if (tracingEnabled) {
/* 64 */       parameters.put("trace", "1");
/*    */     }
/* 66 */     return parameters;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTQueryCommand
 * JD-Core Version:    0.6.0
 */