/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.content.pm.PackageInfo;
/*     */ import android.content.pm.PackageManager;
/*     */ import android.content.pm.PackageManager.NameNotFoundException;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ @ParseClassName("_Installation")
/*     */ public class ParseInstallation extends ParseObject
/*     */ {
/*     */   private static final String TAG = "com.parse.ParseInstallation";
/*  40 */   private static final Object MUTEX_CURRENT_INSTALLATION = new Object();
/*     */   private static final String INSTALLATION_ID_LOCATION = "installationId";
/*     */   static final String FILENAME_CURRENT_INSTALLATION = "currentInstallation";
/*     */   private static final String PIN_CURRENT_INSTALLATION = "_currentInstallation";
/*     */   private static final String KEY_INSTALLATION_ID = "installationId";
/*     */   private static final String KEY_DEVICE_TYPE = "deviceType";
/*     */   private static final String KEY_APP_NAME = "appName";
/*     */   private static final String KEY_APP_IDENTIFIER = "appIdentifier";
/*     */   private static final String KEY_PARSE_VERSION = "parseVersion";
/*     */   private static final String KEY_DEVICE_TOKEN = "deviceToken";
/*     */   private static final String KEY_DEVICE_TOKEN_LAST_MODIFIED = "deviceTokenLastModified";
/*     */   private static final String KEY_PUSH_TYPE = "pushType";
/*     */   private static final String KEY_TIME_ZONE = "timeZone";
/*     */   private static final String KEY_APP_VERSION = "appVersion";
/*  57 */   private static final List<String> READ_ONLY_FIELDS = Collections.unmodifiableList(Arrays.asList(new String[] { "deviceType", "installationId", "deviceToken", "pushType", "timeZone", "appVersion", "appName", "parseVersion", "deviceTokenLastModified", "appIdentifier" }));
/*     */ 
/*  63 */   static ParseInstallation currentInstallation = null;
/*     */ 
/*  66 */   static String installationId = null;
/*     */ 
/*     */   static Task<Boolean> hasCurrentInstallationAsync()
/*     */   {
/*  70 */     synchronized (MUTEX_CURRENT_INSTALLATION) {
/*  71 */       if (currentInstallation != null) {
/*  72 */         return Task.forResult(Boolean.valueOf(true));
/*     */       }
/*     */     }
/*     */ 
/*  76 */     if (OfflineStore.isEnabled())
/*     */     {
/*  78 */       ParseQuery query = ParseQuery.getQuery(ParseInstallation.class).fromPin("_currentInstallation").ignoreACLs();
/*     */ 
/*  81 */       return query.countInBackground().onSuccess(new Continuation()
/*     */       {
/*     */         public Boolean then(Task<Integer> task) throws Exception {
/*  84 */           return Boolean.valueOf(((Integer)task.getResult()).intValue() == 1);
/*     */         } } );
/*     */     }
/*  88 */     return Task.call(new Callable()
/*     */     {
/*     */       public Boolean call() throws Exception {
/*  91 */         return Boolean.valueOf(new File(Parse.getParseDir(), "currentInstallation").exists());
/*     */       }
/*     */     }
/*     */     , Task.BACKGROUND_EXECUTOR);
/*     */   }
/*     */ 
/*     */   public static ParseInstallation getCurrentInstallation()
/*     */   {
/*  98 */     boolean deserializedInstallationFromDisk = false;
/*     */     ParseInstallation current;
/* 101 */     synchronized (MUTEX_CURRENT_INSTALLATION) {
/* 102 */       current = currentInstallation;
/*     */     }
/*     */ 
/* 105 */     if (current != null) {
/* 106 */       return current;
/*     */     }
/*     */ 
/* 109 */     if (OfflineStore.isEnabled())
/*     */       try
/*     */       {
/* 112 */         ParseQuery query = ParseQuery.getQuery(ParseInstallation.class).fromPin("_currentInstallation").ignoreACLs();
/*     */ 
/* 115 */         Task task = query.findInBackground().onSuccessTask(new Continuation()
/*     */         {
/*     */           public Task<ParseInstallation> then(Task<List<ParseInstallation>> task) throws Exception {
/* 118 */             List results = (List)task.getResult();
/* 119 */             if (results != null) {
/* 120 */               if (results.size() == 1) {
/* 121 */                 return Task.forResult(results.get(0));
/*     */               }
/* 123 */               return ParseObject.unpinAllInBackground("_currentInstallation").cast();
/*     */             }
/*     */ 
/* 126 */             return Task.forResult(null);
/*     */           }
/*     */         }).onSuccessTask(new Continuation()
/*     */         {
/*     */           public Task<ParseInstallation> then(Task<ParseInstallation> task)
/*     */             throws Exception
/*     */           {
/* 131 */             ParseInstallation ldsInstallation = (ParseInstallation)task.getResult();
/* 132 */             if (ldsInstallation != null) {
/* 133 */               return task;
/*     */             }
/*     */ 
/* 136 */             return ParseObject.migrateFromDiskToLDS("currentInstallation", "_currentInstallation").cast();
/*     */           }
/*     */         });
/* 140 */         current = (ParseInstallation)Parse.waitForTask(task);
/*     */       }
/*     */       catch (ParseException e) {
/*     */       }
/*     */     else {
/* 145 */       current = (ParseInstallation)getFromDisk(Parse.applicationContext, "currentInstallation");
/*     */     }
/*     */ 
/* 148 */     if (current == null) {
/* 149 */       current = (ParseInstallation)ParseObject.create(ParseInstallation.class);
/* 150 */       current.updateDeviceInfo();
/*     */     } else {
/* 152 */       deserializedInstallationFromDisk = true;
/* 153 */       Parse.logV("com.parse.ParseInstallation", "Successfully deserialized Installation object");
/*     */     }
/*     */ 
/* 156 */     if (deserializedInstallationFromDisk) {
/* 157 */       current.maybeUpdateInstallationIdOnDisk();
/*     */     }
/*     */ 
/* 160 */     synchronized (MUTEX_CURRENT_INSTALLATION) {
/* 161 */       currentInstallation = current;
/*     */     }
/*     */ 
/* 164 */     return current;
/*     */   }
/*     */ 
/*     */   static String getOrCreateCurrentInstallationId()
/*     */   {
/* 177 */     synchronized (MUTEX_CURRENT_INSTALLATION) {
/* 178 */       if (installationId == null) {
/*     */         try {
/* 180 */           File installationIdFile = new File(Parse.getParseDir(), "installationId");
/* 181 */           installationId = new String(ParseFileUtils.readFileToByteArray(installationIdFile));
/*     */         } catch (FileNotFoundException e) {
/* 183 */           Parse.logI("com.parse.ParseInstallation", "Couldn't find existing installationId file. Creating one instead.");
/*     */         } catch (IOException e) {
/* 185 */           Parse.logE("com.parse.ParseInstallation", "Unexpected exception reading installation id from disk", e);
/*     */         }
/*     */       }
/*     */ 
/* 189 */       if (installationId == null) {
/* 190 */         installationId = UUID.randomUUID().toString();
/* 191 */         setCurrentInstallationId(installationId);
/*     */       }
/*     */     }
/*     */ 
/* 195 */     return installationId;
/*     */   }
/*     */ 
/*     */   static void setCurrentInstallationId(String newInstallationId) {
/* 199 */     synchronized (MUTEX_CURRENT_INSTALLATION) {
/* 200 */       File installationIdFile = new File(Parse.getParseDir(), "installationId");
/*     */       try
/*     */       {
/* 203 */         ParseFileUtils.writeByteArrayToFile(installationIdFile, newInstallationId.getBytes());
/*     */       } catch (IOException e) {
/* 205 */         Parse.logE("com.parse.ParseInstallation", "Unexpected exception writing installation id to disk", e);
/*     */       }
/*     */ 
/* 208 */       installationId = newInstallationId;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static ParseQuery<ParseInstallation> getQuery()
/*     */   {
/* 228 */     return ParseQuery.getQuery(ParseInstallation.class);
/*     */   }
/*     */ 
/*     */   public String getInstallationId()
/*     */   {
/* 241 */     return getString("installationId");
/*     */   }
/*     */ 
/*     */   boolean needsDefaultACL()
/*     */   {
/* 246 */     return false;
/*     */   }
/*     */ 
/*     */   boolean isKeyMutable(String key)
/*     */   {
/* 251 */     return !READ_ONLY_FIELDS.contains(key);
/*     */   }
/*     */ 
/*     */   void updateBeforeSave()
/*     */   {
/* 256 */     super.updateBeforeSave();
/* 257 */     if (isCurrentInstallation()) {
/* 258 */       updateTimezone();
/* 259 */       updateVersionInfo();
/* 260 */       updateDeviceInfo();
/*     */     }
/*     */   }
/*     */ 
/*     */   <T extends ParseObject> Task<T> fetchAsync(Task<Void> toAwait)
/*     */   {
/* 266 */     synchronized (this.mutex)
/*     */     {
/*     */       Task result;
/*     */       Task result;
/* 271 */       if (getObjectId() == null)
/* 272 */         result = saveAsync(toAwait);
/*     */       else {
/* 274 */         result = Task.forResult(null);
/*     */       }
/* 276 */       return result.onSuccessTask(new Continuation(toAwait)
/*     */       {
/*     */         public Task<T> then(Task<Void> task) throws Exception {
/* 279 */           return ParseInstallation.this.fetchAsync(this.val$toAwait);
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ 
/*     */   Task<Void> handleSaveResultAsync(JSONObject result, ParseOperationSet operationsBeforeSave)
/*     */   {
/* 288 */     Task task = super.handleSaveResultAsync(result, operationsBeforeSave);
/*     */ 
/* 292 */     if (ManifestInfo.getPushUsesBroadcastReceivers()) {
/* 293 */       task = task.onSuccessTask(new Continuation()
/*     */       {
/*     */         public Task<Boolean> then(Task<Void> task) throws Exception {
/* 296 */           return PushRouter.getForceEnabledStateAsync();
/*     */         }
/*     */       }).onSuccess(new Continuation()
/*     */       {
/*     */         public Void then(Task<Boolean> task)
/*     */           throws Exception
/*     */         {
/* 301 */           Boolean forceEnabled = (Boolean)task.getResult();
/* 302 */           if ((forceEnabled == null) || (forceEnabled.booleanValue())) {
/* 303 */             PushService.startServiceIfRequired(Parse.applicationContext);
/*     */           }
/* 305 */           return null;
/*     */         }
/*     */       });
/*     */     }
/* 310 */     return task.onSuccessTask(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<Void> task) throws Exception {
/* 313 */         return ParseInstallation.access$100(ParseInstallation.this);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   Task<Void> handleFetchResultAsync(JSONObject result) {
/* 320 */     return super.handleFetchResultAsync(result).onSuccessTask(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<Void> task) throws Exception {
/* 323 */         return ParseInstallation.access$100(ParseInstallation.this);
/*     */       } } );
/*     */   }
/*     */ 
/*     */   private boolean isCurrentInstallation() {
/* 329 */     synchronized (MUTEX_CURRENT_INSTALLATION) {
/* 330 */       return this == currentInstallation;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void maybeUpdateInstallationIdOnDisk() {
/* 335 */     String installationIdInObject = getInstallationId();
/* 336 */     String installationIdOnDisk = getOrCreateCurrentInstallationId();
/* 337 */     boolean installationIdIsEmpty = (installationIdInObject == null) || (installationIdInObject.length() == 0);
/*     */ 
/* 339 */     if ((!installationIdIsEmpty) && (!installationIdInObject.equals(installationIdOnDisk))) {
/* 340 */       Parse.logW("com.parse.ParseInstallation", "Will update installation id on disk: " + installationIdOnDisk + " because it does not match installation id in ParseInstallation: " + installationIdInObject);
/*     */ 
/* 342 */       setCurrentInstallationId(installationIdInObject);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updateTimezone()
/*     */   {
/* 350 */     String zone = TimeZone.getDefault().getID();
/* 351 */     if (((zone.indexOf(47) > 0) || (zone.equals("GMT"))) && (!zone.equals(get("timeZone"))))
/* 352 */       performPut("timeZone", zone);
/*     */   }
/*     */ 
/*     */   private void updateVersionInfo()
/*     */   {
/* 357 */     synchronized (this.mutex) {
/*     */       try {
/* 359 */         String packageName = Parse.applicationContext.getPackageName();
/* 360 */         PackageManager pm = Parse.applicationContext.getPackageManager();
/* 361 */         PackageInfo pkgInfo = pm.getPackageInfo(packageName, 0);
/* 362 */         String appVersion = pkgInfo.versionName;
/* 363 */         String appName = pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString();
/*     */ 
/* 365 */         if ((packageName != null) && (!packageName.equals(get("appIdentifier")))) {
/* 366 */           performPut("appIdentifier", packageName);
/*     */         }
/* 368 */         if ((appName != null) && (!appName.equals(get("appName")))) {
/* 369 */           performPut("appName", appName);
/*     */         }
/* 371 */         if ((appVersion != null) && (!appVersion.equals(get("appVersion"))))
/* 372 */           performPut("appVersion", appVersion);
/*     */       }
/*     */       catch (PackageManager.NameNotFoundException e) {
/* 375 */         Parse.logW("com.parse.ParseInstallation", "Cannot load package info; will not be saved to installation");
/*     */       }
/*     */ 
/* 378 */       if (!"1.9.1".equals(get("parseVersion")))
/* 379 */         performPut("parseVersion", "1.9.1");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updateDeviceInfo()
/*     */   {
/* 389 */     if (!has("installationId")) {
/* 390 */       performPut("installationId", getOrCreateCurrentInstallationId());
/*     */     }
/* 392 */     String deviceType = "android";
/* 393 */     if (!deviceType.equals(get("deviceType")))
/* 394 */       performPut("deviceType", deviceType);
/*     */   }
/*     */ 
/*     */   PushType getPushType()
/*     */   {
/* 399 */     return PushType.fromString(super.getString("pushType"));
/*     */   }
/*     */ 
/*     */   void setPushType(PushType pushType) {
/* 403 */     if (pushType != null)
/* 404 */       performPut("pushType", pushType.toString());
/*     */   }
/*     */ 
/*     */   void removePushType()
/*     */   {
/* 409 */     performRemove("pushType");
/*     */   }
/*     */ 
/*     */   String getDeviceToken() {
/* 413 */     return super.getString("deviceToken");
/*     */   }
/*     */ 
/*     */   boolean isDeviceTokenStale() {
/* 417 */     return super.getLong("deviceTokenLastModified") != ManifestInfo.getLastModified();
/*     */   }
/*     */ 
/*     */   void setDeviceTokenLastModified(long lastModified)
/*     */   {
/* 422 */     performPut("deviceTokenLastModified", Long.valueOf(lastModified));
/*     */   }
/*     */ 
/*     */   void setDeviceToken(String deviceToken) {
/* 426 */     if ((deviceToken != null) && (deviceToken.length() > 0)) {
/* 427 */       performPut("deviceToken", deviceToken);
/* 428 */       performPut("deviceTokenLastModified", Long.valueOf(ManifestInfo.getLastModified()));
/*     */     }
/*     */   }
/*     */ 
/*     */   void removeDeviceToken() {
/* 433 */     performRemove("deviceToken");
/* 434 */     performRemove("deviceTokenLastModified");
/*     */   }
/*     */ 
/*     */   private static Task<Void> maybeFlushToDiskAsync(ParseInstallation installation) {
/* 438 */     if (!installation.isCurrentInstallation())
/* 439 */       return Task.forResult(null);
/*     */     Task task;
/* 443 */     if (OfflineStore.isEnabled())
/* 444 */       task = ParseObject.unpinAllInBackground("_currentInstallation").continueWithTask(new Continuation(installation)
/*     */       {
/*     */         public Task<Void> then(Task<Void> task) throws Exception {
/* 447 */           return this.val$installation.pinInBackground("_currentInstallation", false);
/*     */         }
/*     */       });
/* 451 */     else task = Task.forResult(null).continueWithTask(new Continuation(installation)
/*     */       {
/*     */         public Task<Void> then(Task<Void> task) throws Exception {
/* 454 */           this.val$installation.saveToDisk(Parse.applicationContext, "currentInstallation");
/* 455 */           return task;
/*     */         }
/*     */       });
/*     */ 
/* 460 */     Task task = task.continueWithTask(new Continuation(installation)
/*     */     {
/*     */       public Task<Void> then(Task<Void> task) throws Exception {
/* 463 */         this.val$installation.maybeUpdateInstallationIdOnDisk();
/* 464 */         return task;
/*     */       }
/*     */     });
/* 468 */     return task;
/*     */   }
/*     */ 
/*     */   static void clearCurrentInstallationFromMemory() {
/* 472 */     synchronized (MUTEX_CURRENT_INSTALLATION) {
/* 473 */       currentInstallation = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   static void clearCurrentInstallationFromDisk(Context context)
/*     */   {
/* 482 */     synchronized (MUTEX_CURRENT_INSTALLATION) {
/* 483 */       currentInstallation = null;
/* 484 */       installationId = null;
/*     */ 
/* 486 */       if (OfflineStore.isEnabled()) {
/* 487 */         ParseObject.unpinAllInBackground("_currentInstallation");
/*     */       }
/*     */ 
/* 490 */       Parse.deleteDiskObject(context, "currentInstallation");
/* 491 */       Parse.deleteDiskObject(context, "installationId");
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseInstallation
 * JD-Core Version:    0.6.0
 */