/*     */ package com.parse;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.PriorityQueue;
/*     */ import java.util.Set;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class PushHistory
/*     */ {
/*     */   private static final String TAG = "com.parse.PushHistory";
/*     */   private final int maxHistoryLength;
/*     */   private final PriorityQueue<Entry> entries;
/*     */   private final HashSet<String> pushIds;
/*     */   private String cutoff;
/*     */   private String lastTime;
/*     */ 
/*     */   public PushHistory(int maxHistoryLength, JSONObject json)
/*     */   {
/*  58 */     this.maxHistoryLength = maxHistoryLength;
/*  59 */     this.entries = new PriorityQueue(maxHistoryLength + 1);
/*  60 */     this.pushIds = new HashSet(maxHistoryLength + 1);
/*  61 */     this.cutoff = null;
/*  62 */     this.lastTime = null;
/*     */ 
/*  64 */     if (json != null) {
/*  65 */       setCutoffTimestamp(json.optString("ignoreAfter", null));
/*  66 */       setLastReceivedTimestamp(json.optString("lastTime", null));
/*     */ 
/*  68 */       JSONObject jsonHistory = json.optJSONObject("history");
/*  69 */       if (jsonHistory != null) {
/*  70 */         Iterator it = jsonHistory.keys();
/*  71 */         while (it.hasNext()) {
/*  72 */           String pushId = (String)it.next();
/*  73 */           String timestamp = jsonHistory.optString(pushId, null);
/*     */ 
/*  75 */           if ((pushId != null) && (timestamp != null))
/*  76 */             tryInsertPush(pushId, timestamp);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public JSONObject toJSON()
/*     */     throws JSONException
/*     */   {
/*  87 */     JSONObject json = new JSONObject();
/*     */ 
/*  89 */     if (this.entries.size() > 0) {
/*  90 */       JSONObject history = new JSONObject();
/*     */ 
/*  92 */       for (Entry e : this.entries) {
/*  93 */         history.put(e.pushId, e.timestamp);
/*     */       }
/*     */ 
/*  96 */       json.put("history", history);
/*     */     }
/*     */ 
/* 103 */     json.putOpt("ignoreAfter", this.cutoff);
/* 104 */     json.putOpt("lastTime", this.lastTime);
/*     */ 
/* 106 */     return json;
/*     */   }
/*     */ 
/*     */   public String getCutoffTimestamp()
/*     */   {
/* 114 */     return this.cutoff;
/*     */   }
/*     */ 
/*     */   private void setCutoffTimestamp(String cutoff) {
/* 118 */     this.cutoff = cutoff;
/*     */   }
/*     */ 
/*     */   public String getLastReceivedTimestamp()
/*     */   {
/* 126 */     return this.lastTime;
/*     */   }
/*     */ 
/*     */   private void setLastReceivedTimestamp(String lastTime) {
/* 130 */     this.lastTime = lastTime;
/*     */   }
/*     */ 
/*     */   public Set<String> getPushIds()
/*     */   {
/* 137 */     return Collections.unmodifiableSet(this.pushIds);
/*     */   }
/*     */ 
/*     */   public boolean tryInsertPush(String pushId, String timestamp)
/*     */   {
/* 149 */     if (timestamp == null) {
/* 150 */       throw new IllegalArgumentException("Can't insert null pushId or timestamp into history");
/*     */     }
/*     */ 
/* 153 */     if ((this.lastTime == null) || (timestamp.compareTo(this.lastTime) > 0)) {
/* 154 */       this.lastTime = timestamp;
/*     */     }
/*     */ 
/* 157 */     if ((this.cutoff != null) && (timestamp.compareTo(this.cutoff) <= 0)) {
/* 158 */       Parse.logE("com.parse.PushHistory", "Ignored old push " + pushId + " at " + timestamp + " before cutoff " + this.cutoff);
/* 159 */       return false;
/*     */     }
/*     */ 
/* 164 */     if (pushId != null) {
/* 165 */       if (this.pushIds.contains(pushId)) {
/* 166 */         Parse.logE("com.parse.PushHistory", "Ignored duplicate push " + pushId);
/* 167 */         return false;
/*     */       }
/*     */ 
/* 170 */       this.entries.add(new Entry(pushId, timestamp));
/* 171 */       this.pushIds.add(pushId);
/*     */ 
/* 173 */       while (this.entries.size() > this.maxHistoryLength) {
/* 174 */         Entry head = (Entry)this.entries.remove();
/*     */ 
/* 176 */         this.pushIds.remove(head.pushId);
/* 177 */         this.cutoff = head.timestamp;
/*     */       }
/*     */     }
/*     */ 
/* 181 */     return true;
/*     */   }
/*     */ 
/*     */   private static class Entry
/*     */     implements Comparable<Entry>
/*     */   {
/*     */     public String pushId;
/*     */     public String timestamp;
/*     */ 
/*     */     public Entry(String pushId, String timestamp)
/*     */     {
/*  24 */       this.pushId = pushId;
/*  25 */       this.timestamp = timestamp;
/*     */     }
/*     */ 
/*     */     public int compareTo(Entry other)
/*     */     {
/*  30 */       return this.timestamp.compareTo(other.timestamp);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.PushHistory
 * JD-Core Version:    0.6.0
 */