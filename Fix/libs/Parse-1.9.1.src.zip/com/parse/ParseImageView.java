/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.graphics.Bitmap;
/*     */ import android.graphics.BitmapFactory;
/*     */ import android.graphics.drawable.Drawable;
/*     */ import android.util.AttributeSet;
/*     */ import android.widget.ImageView;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ 
/*     */ public class ParseImageView extends ImageView
/*     */ {
/*     */   private ParseFile file;
/*     */   private Drawable placeholder;
/*  38 */   private boolean isLoaded = false;
/*     */ 
/*     */   public ParseImageView(Context context)
/*     */   {
/*  47 */     super(context);
/*     */   }
/*     */ 
/*     */   public ParseImageView(Context context, AttributeSet attributeSet)
/*     */   {
/*  59 */     super(context, attributeSet);
/*     */   }
/*     */ 
/*     */   public ParseImageView(Context context, AttributeSet attributeSet, int defStyle)
/*     */   {
/*  73 */     super(context, attributeSet, defStyle);
/*     */   }
/*     */ 
/*     */   protected void onDetachedFromWindow()
/*     */   {
/*  81 */     if (this.file != null)
/*  82 */       this.file.cancel();
/*     */   }
/*     */ 
/*     */   public void setImageBitmap(Bitmap bitmap)
/*     */   {
/*  88 */     super.setImageBitmap(bitmap);
/*  89 */     this.isLoaded = true;
/*     */   }
/*     */ 
/*     */   public void setPlaceholder(Drawable placeholder)
/*     */   {
/* 101 */     this.placeholder = placeholder;
/* 102 */     if (!this.isLoaded)
/* 103 */       setImageDrawable(this.placeholder);
/*     */   }
/*     */ 
/*     */   public void setParseFile(ParseFile file)
/*     */   {
/* 114 */     if (this.file != null) {
/* 115 */       this.file.cancel();
/*     */     }
/* 117 */     this.isLoaded = false;
/* 118 */     this.file = file;
/* 119 */     setImageDrawable(this.placeholder);
/*     */   }
/*     */ 
/*     */   public Task<byte[]> loadInBackground()
/*     */   {
/* 129 */     if (this.file == null) {
/* 130 */       return Task.forResult(null);
/*     */     }
/*     */ 
/* 133 */     ParseFile loadingFile = this.file;
/* 134 */     return this.file.getDataInBackground().onSuccessTask(new Continuation(loadingFile)
/*     */     {
/*     */       public Task<byte[]> then(Task<byte[]> task) throws Exception {
/* 137 */         byte[] data = (byte[])task.getResult();
/* 138 */         if (ParseImageView.this.file != this.val$loadingFile)
/*     */         {
/* 141 */           return Task.cancelled();
/*     */         }
/* 143 */         if (data != null) {
/* 144 */           Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
/* 145 */           if (bitmap != null) {
/* 146 */             ParseImageView.this.setImageBitmap(bitmap);
/*     */           }
/*     */         }
/* 149 */         return task;
/*     */       }
/*     */     }
/*     */     , Task.UI_THREAD_EXECUTOR);
/*     */   }
/*     */ 
/*     */   public void loadInBackground(GetDataCallback completionCallback)
/*     */   {
/* 163 */     Parse.callbackOnMainThreadAsync(loadInBackground(), completionCallback, true);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseImageView
 * JD-Core Version:    0.6.0
 */