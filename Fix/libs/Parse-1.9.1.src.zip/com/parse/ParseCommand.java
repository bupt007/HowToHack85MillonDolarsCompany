/*     */ package com.parse;
/*     */ 
/*     */ import android.os.Build.VERSION;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import com.parse.codec.digest.DigestUtils;
/*     */ import com.parse.signpost.OAuthConsumer;
/*     */ import com.parse.signpost.commonshttp.CommonsHttpOAuthConsumer;
/*     */ import com.parse.signpost.exception.OAuthCommunicationException;
/*     */ import com.parse.signpost.exception.OAuthExpectationFailedException;
/*     */ import com.parse.signpost.exception.OAuthMessageSignerException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.UUID;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.entity.StringEntity;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ import org.json.JSONStringer;
/*     */ import org.json.JSONTokener;
/*     */ 
/*     */ class ParseCommand extends ParseNetworkCommand<JSONObject, Object>
/*     */ {
/*     */   private static final String COMMAND_UUID = "uuid";
/*     */   private static final String SESSION_TOKEN = "session_token";
/*     */   private static final String OS_VERSION = "osVersion";
/*     */   private static final String APP_BUILD_VERSION = "appBuildVersion";
/*     */   private static final String APP_DISPLAY_VERSION = "appDisplayVersion";
/*     */   private static final String INSTALLATION_ID = "iid";
/*     */   private static final String DEVICE_TYPE_AND_SDK_VERSION = "v";
/*     */   private String op;
/*     */   JSONObject params;
/*     */   private String localId;
/*     */   private String operationSetUUID;
/*     */   private final String sessionToken;
/*     */   private String installationId;
/*     */ 
/*     */   private static String generateUrl(String op)
/*     */   {
/*  82 */     return String.format("%s/%s/%s", new Object[] { ParseObject.server, "2", op });
/*     */   }
/*     */ 
/*     */   ParseCommand(String op, String sessionToken)
/*     */   {
/* 103 */     this(op, new JSONObject(), null, null, sessionToken);
/*     */   }
/*     */ 
/*     */   ParseCommand(JSONObject json)
/*     */     throws JSONException
/*     */   {
/* 110 */     this(json.getString("op"), json.getJSONObject("params"), json.optString("localId", null), json.optString("operationSetUUID", null), json.has("session_token") ? json.getString("session_token") : ParseUser.getCurrentSessionToken());
/*     */   }
/*     */ 
/*     */   private ParseCommand(String op, JSONObject params, String localId, String operationSetUUID, String sessionToken)
/*     */   {
/* 122 */     super(ParseRequest.Method.POST, generateUrl(op));
/*     */ 
/* 124 */     this.op = op;
/* 125 */     this.params = params;
/* 126 */     this.localId = localId;
/* 127 */     this.operationSetUUID = operationSetUUID;
/* 128 */     this.sessionToken = sessionToken;
/*     */ 
/* 130 */     this.maxRetries = 0;
/*     */   }
/*     */ 
/*     */   void put(String key, String value)
/*     */   {
/*     */     try {
/* 136 */       this.params.put(key, value);
/*     */     } catch (JSONException e) {
/* 138 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   void put(String key, int value) {
/*     */     try {
/* 144 */       this.params.put(key, value);
/*     */     } catch (JSONException e) {
/* 146 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   void put(String key, long value) {
/*     */     try {
/* 152 */       this.params.put(key, value);
/*     */     } catch (JSONException e) {
/* 154 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   void put(String key, JSONArray value) {
/*     */     try {
/* 160 */       this.params.put(key, value);
/*     */     } catch (JSONException e) {
/* 162 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   void put(String key, JSONObject value) {
/*     */     try {
/* 168 */       this.params.put(key, value);
/*     */     } catch (JSONException e) {
/* 170 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   String getOp() {
/* 175 */     return this.op;
/*     */   }
/*     */ 
/*     */   void setOp(String op) {
/* 179 */     this.op = op;
/* 180 */     setUrl(generateUrl(op));
/*     */   }
/*     */ 
/*     */   String getSessionToken() {
/* 184 */     return this.sessionToken;
/*     */   }
/*     */ 
/*     */   String getOperationSetUUID() {
/* 188 */     return this.operationSetUUID;
/*     */   }
/*     */ 
/*     */   void setOperationSetUUID(String uuid) {
/* 192 */     this.operationSetUUID = uuid;
/*     */   }
/*     */ 
/*     */   String getLocalId() {
/* 196 */     return this.localId;
/*     */   }
/*     */ 
/*     */   void setLocalId(String theLocalId) {
/* 200 */     this.localId = theLocalId;
/*     */   }
/*     */ 
/*     */   void enableRetrying() {
/* 204 */     this.maxRetries = 4;
/*     */   }
/*     */ 
/*     */   static boolean isValidCommandJSONObject(JSONObject jsonObject) {
/* 208 */     return jsonObject.has("op");
/*     */   }
/*     */ 
/*     */   JSONObject toJSONObject()
/*     */   {
/*     */     try
/*     */     {
/* 217 */       JSONObject answer = new JSONObject();
/* 218 */       answer.put("op", this.op);
/* 219 */       answer.put("params", this.params);
/* 220 */       if (this.localId != null) {
/* 221 */         answer.put("localId", this.localId);
/*     */       }
/* 223 */       if (this.operationSetUUID != null) {
/* 224 */         answer.put("operationSetUUID", this.operationSetUUID);
/*     */       }
/* 226 */       answer.put("session_token", this.sessionToken != null ? this.sessionToken : JSONObject.NULL);
/* 227 */       return answer; } catch (JSONException e) {
/*     */     }
/* 229 */     throw new RuntimeException(e.getMessage());
/*     */   }
/*     */ 
/*     */   String getCacheKey()
/*     */   {
/*     */     String json;
/*     */     try {
/* 237 */       json = toDeterministicString(this.params);
/*     */     } catch (JSONException e) {
/* 239 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */ 
/* 243 */     if (this.sessionToken != null) {
/* 244 */       json = json + this.sessionToken;
/*     */     }
/*     */ 
/* 247 */     return "ParseCommand." + this.op + "." + "2" + "." + DigestUtils.md5Hex(json);
/*     */   }
/*     */ 
/*     */   static String toDeterministicString(Object o)
/*     */     throws JSONException
/*     */   {
/* 253 */     JSONStringer stringer = new JSONStringer();
/* 254 */     addToStringer(stringer, o);
/* 255 */     return stringer.toString();
/*     */   }
/*     */ 
/*     */   static void addToStringer(JSONStringer stringer, Object o)
/*     */     throws JSONException
/*     */   {
/* 261 */     if ((o instanceof JSONObject)) {
/* 262 */       stringer.object();
/* 263 */       JSONObject object = (JSONObject)o;
/* 264 */       Iterator keyIterator = object.keys();
/* 265 */       ArrayList keys = new ArrayList();
/* 266 */       while (keyIterator.hasNext()) {
/* 267 */         keys.add(keyIterator.next());
/*     */       }
/* 269 */       Collections.sort(keys);
/*     */ 
/* 271 */       for (String key : keys) {
/* 272 */         stringer.key(key);
/* 273 */         addToStringer(stringer, object.opt(key));
/*     */       }
/*     */ 
/* 276 */       stringer.endObject();
/* 277 */       return;
/*     */     }
/*     */ 
/* 280 */     if ((o instanceof JSONArray)) {
/* 281 */       JSONArray array = (JSONArray)o;
/* 282 */       stringer.array();
/* 283 */       for (int i = 0; i < array.length(); i++) {
/* 284 */         addToStringer(stringer, array.get(i));
/*     */       }
/* 286 */       stringer.endArray();
/* 287 */       return;
/*     */     }
/*     */ 
/* 290 */     stringer.value(o);
/*     */   }
/*     */ 
/*     */   static void addDefaultParameters(JSONObject params, String sessionToken, String installationId)
/*     */     throws JSONException
/*     */   {
/* 302 */     params.put("osVersion", Build.VERSION.RELEASE);
/* 303 */     params.put("appBuildVersion", Integer.toString(ManifestInfo.getVersionCode()));
/* 304 */     params.put("appDisplayVersion", ManifestInfo.getVersionName());
/*     */ 
/* 307 */     params.put("v", "a1.9.1");
/*     */ 
/* 319 */     params.put("iid", installationId);
/*     */ 
/* 322 */     params.put("uuid", UUID.randomUUID().toString());
/*     */ 
/* 325 */     if (sessionToken != null)
/* 326 */       params.put("session_token", sessionToken);
/*     */   }
/*     */ 
/*     */   protected HttpEntity newEntity(ProgressCallback uploadProgressCallback)
/*     */   {
/* 333 */     Iterator keys = this.params.keys();
/* 334 */     JSONObject fullParams = new JSONObject();
/*     */     try {
/* 336 */       while (keys.hasNext()) {
/* 337 */         String key = (String)keys.next();
/* 338 */         fullParams.put(key, this.params.get(key));
/*     */       }
/*     */ 
/* 343 */       addDefaultParameters(fullParams, this.sessionToken, this.installationId);
/*     */     } catch (JSONException e) {
/* 345 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */     try
/*     */     {
/* 349 */       StringEntity entity = new StringEntity(fullParams.toString(), "UTF8");
/* 350 */       entity.setContentType("application/json");
/* 351 */       return entity; } catch (UnsupportedEncodingException e) {
/*     */     }
/* 353 */     throw new RuntimeException(e.getMessage());
/*     */   }
/*     */ 
/*     */   protected HttpUriRequest newRequest(ParseRequest.Method method, ProgressCallback uploadProgressCallback)
/*     */     throws ParseException
/*     */   {
/* 360 */     HttpUriRequest request = super.newRequest(method, uploadProgressCallback);
/*     */     try
/*     */     {
/* 364 */       OAuthConsumer consumer = new CommonsHttpOAuthConsumer(Parse.applicationId, Parse.clientKey);
/* 365 */       consumer.setTokenWithSecret(null, "");
/* 366 */       consumer.sign(request);
/*     */     } catch (OAuthMessageSignerException e) {
/* 368 */       throw new ParseException(109, e.getMessage());
/*     */     } catch (OAuthExpectationFailedException e) {
/* 370 */       throw new ParseException(109, e.getMessage());
/*     */     } catch (OAuthCommunicationException e) {
/* 372 */       throw new ParseException(109, e.getMessage());
/*     */     }
/*     */ 
/* 375 */     return request;
/*     */   }
/*     */ 
/*     */   protected Task<Void> onPreExecute(Task<Void> task)
/*     */   {
/* 380 */     Parse.checkInit();
/* 381 */     resolveLocalIds();
/* 382 */     return task.onSuccessTask(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<Void> task) throws Exception {
/* 385 */         ParseCommand.access$002(ParseCommand.this, ParseInstallation.getOrCreateCurrentInstallationId());
/* 386 */         return task;
/*     */       }
/*     */     }
/*     */     , Task.BACKGROUND_EXECUTOR);
/*     */   }
/*     */ 
/*     */   protected Task<JSONObject> onResponse(ParseHttpResponse response, ProgressCallback downloadProgressCallback)
/*     */   {
/* 394 */     InputStream responseStream = null;
/* 395 */     String content = null;
/*     */     try {
/* 397 */       responseStream = response.getContent();
/* 398 */       content = new String(ParseIOUtils.toByteArray(responseStream));
/*     */     } catch (IOException e) {
/* 400 */       Task localTask = Task.forError(e);
/*     */       return localTask; } finally { ParseIOUtils.closeQuietly(responseStream); }
/*     */     JSONObject json;
/*     */     try
/*     */     {
/* 407 */       JSONTokener tokener = new JSONTokener(content);
/* 408 */       json = new JSONObject(tokener);
/*     */     } catch (JSONException e) {
/* 410 */       return Task.forError(newTemporaryException("bad json response", e));
/*     */     }
/*     */ 
/* 413 */     return Task.forResult(json);
/*     */   }
/*     */   protected Task<Object> onPostExecute(Task<JSONObject> task) {
/* 420 */     JSONObject json = (JSONObject)task.getResult();
/*     */     Object result;
/*     */     try {
/* 423 */       if (json.has("error")) {
/* 424 */         return Task.forError(new ParseException(json.getInt("code"), json.getString("error")));
/*     */       }
/* 426 */       result = json.get("result");
/*     */     } catch (JSONException e) {
/* 428 */       return Task.forError(newTemporaryException("corrupted json", e));
/*     */     }
/* 430 */     return Task.forResult(result);
/*     */   }
/*     */ 
/*     */   public void maybeChangeServerOperation()
/*     */     throws JSONException
/*     */   {
/* 441 */     if (this.localId != null) {
/* 442 */       String objectId = LocalIdManager.getDefaultInstance().getObjectId(this.localId);
/* 443 */       if (objectId != null) {
/* 444 */         this.localId = null;
/*     */ 
/* 446 */         JSONObject data = this.params.optJSONObject("data");
/* 447 */         if (data != null) {
/* 448 */           data.put("objectId", objectId);
/*     */         }
/*     */ 
/* 451 */         if (this.op.equals("create"))
/* 452 */           setOp("update");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resolveLocalIds()
/*     */   {
/*     */     try
/*     */     {
/* 466 */       Object data = this.params.get("data");
/* 467 */       ArrayList localPointers = new ArrayList();
/* 468 */       getLocalPointersIn(data, localPointers);
/* 469 */       for (JSONObject pointer : localPointers) {
/* 470 */         String localId = (String)pointer.get("localId");
/* 471 */         String objectId = LocalIdManager.getDefaultInstance().getObjectId(localId);
/* 472 */         if (objectId == null) {
/* 473 */           throw new IllegalStateException("Tried to serialize a command referencing a new, unsaved object.");
/*     */         }
/*     */ 
/* 476 */         pointer.put("objectId", objectId);
/* 477 */         pointer.remove("localId");
/*     */       }
/*     */ 
/* 480 */       maybeChangeServerOperation();
/*     */     }
/*     */     catch (JSONException e) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void retainLocalIds() {
/* 487 */     if (this.localId != null) {
/* 488 */       LocalIdManager.getDefaultInstance().retainLocalIdOnDisk(this.localId);
/*     */     }
/*     */     try
/*     */     {
/* 492 */       Object data = this.params.get("data");
/* 493 */       ArrayList localPointers = new ArrayList();
/* 494 */       getLocalPointersIn(data, localPointers);
/* 495 */       for (JSONObject pointer : localPointers) {
/* 496 */         String localId = (String)pointer.get("localId");
/* 497 */         LocalIdManager.getDefaultInstance().retainLocalIdOnDisk(localId);
/*     */       }
/*     */     }
/*     */     catch (JSONException e) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void releaseLocalIds() {
/* 505 */     if (this.localId != null) {
/* 506 */       LocalIdManager.getDefaultInstance().releaseLocalIdOnDisk(this.localId);
/*     */     }
/*     */     try
/*     */     {
/* 510 */       Object data = this.params.get("data");
/* 511 */       ArrayList localPointers = new ArrayList();
/* 512 */       getLocalPointersIn(data, localPointers);
/* 513 */       for (JSONObject pointer : localPointers) {
/* 514 */         String localId = (String)pointer.get("localId");
/* 515 */         LocalIdManager.getDefaultInstance().releaseLocalIdOnDisk(localId);
/*     */       }
/*     */     }
/*     */     catch (JSONException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseCommand
 * JD-Core Version:    0.6.0
 */