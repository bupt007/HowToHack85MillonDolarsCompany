/*     */ package com.parse;
/*     */ 
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ class TaskQueue
/*     */ {
/*     */   private Task<Void> tail;
/*  19 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */   private Task<Void> getTaskToAwait()
/*     */   {
/*  28 */     this.lock.lock();
/*     */     try {
/*  30 */       Task toAwait = this.tail != null ? this.tail : Task.forResult(null);
/*  31 */       Task localTask1 = toAwait.continueWith(new Continuation()
/*     */       {
/*     */         public Void then(Task<Void> task) throws Exception {
/*  34 */           return null;
/*     */         }
/*     */       });
/*     */       return localTask1; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   <T> Task<T> enqueue(Continuation<Void, Task<T>> taskStart)
/*     */   {
/*  52 */     this.lock.lock();
/*     */     try
/*     */     {
/*  55 */       Task oldTail = this.tail != null ? this.tail : Task.forResult(null);
/*     */       Task task;
/*     */       try {
/*  60 */         Task toAwait = getTaskToAwait();
/*  61 */         task = (Task)taskStart.then(toAwait);
/*     */       } catch (RuntimeException e) {
/*  63 */         throw e;
/*     */       } catch (Exception e) {
/*  65 */         throw new RuntimeException(e);
/*     */       }
/*     */ 
/*  70 */       this.tail = Task.whenAll(Arrays.asList(new Task[] { oldTail, task }));
/*  71 */       e = task;
/*     */       return e; } finally { this.lock.unlock(); } throw localObject;
/*     */   }
/*     */ 
/*     */   static <T> Continuation<T, Task<T>> waitFor(Task<Void> toAwait)
/*     */   {
/*  82 */     return new Continuation(toAwait)
/*     */     {
/*     */       public Task<T> then(Task<T> task) throws Exception {
/*  85 */         return this.val$toAwait.continueWithTask(new Continuation(task)
/*     */         {
/*     */           public Task<T> then(Task<Void> ignored) throws Exception {
/*  88 */             return this.val$task;
/*     */           } } );
/*     */       } } ;
/*     */   }
/*     */ 
/*     */   Lock getLock() {
/*  96 */     return this.lock;
/*     */   }
/*     */ 
/*     */   void waitUntilFinished() throws InterruptedException {
/* 100 */     this.lock.lock();
/*     */     try {
/* 102 */       if (this.tail == null)
/*     */         return;
/* 105 */       this.tail.waitForCompletion();
/*     */     } finally {
/* 107 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.TaskQueue
 * JD-Core Version:    0.6.0
 */