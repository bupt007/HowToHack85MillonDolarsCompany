/*    */ package com.parse;
/*    */ 
/*    */ import bolts.Task;
/*    */ import com.parse.entity.mime.HttpMultipartMode;
/*    */ import com.parse.entity.mime.MultipartEntity;
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ class CountingMultipartEntity extends MultipartEntity
/*    */ {
/*    */   private final ParseCallback2<Integer, ParseException> progressCallback;
/*    */ 
/*    */   public CountingMultipartEntity(ProgressCallback progressCallback)
/*    */   {
/* 22 */     this(HttpMultipartMode.STRICT, null, null, progressCallback);
/*    */   }
/*    */ 
/*    */   public CountingMultipartEntity(HttpMultipartMode mode, ProgressCallback progressCallback)
/*    */   {
/* 27 */     this(mode, null, null, progressCallback);
/*    */   }
/*    */ 
/*    */   public CountingMultipartEntity(HttpMultipartMode mode, String boundary, Charset charset, ProgressCallback progressCallback)
/*    */   {
/* 32 */     super(mode, boundary, charset);
/*    */ 
/* 35 */     if (progressCallback != null)
/* 36 */       this.progressCallback = new ParseCallback2(progressCallback) {
/* 37 */         Integer maxProgressSoFar = Integer.valueOf(0);
/*    */ 
/*    */         public void done(Integer percentDone, ParseException e) {
/* 40 */           if (percentDone.intValue() > this.maxProgressSoFar.intValue()) {
/* 41 */             this.maxProgressSoFar = percentDone;
/* 42 */             this.val$progressCallback.done(percentDone);
/*    */           }
/*    */         }
/*    */       };
/* 47 */     else this.progressCallback = null;
/*    */   }
/*    */ 
/*    */   public void writeTo(OutputStream outstream)
/*    */     throws IOException
/*    */   {
/* 53 */     super.writeTo(new CountingOutputStream(outstream, this.progressCallback, getContentLength()));
/*    */   }
/*    */ 
/*    */   public static class CountingOutputStream extends FilterOutputStream
/*    */   {
/*    */     private ParseCallback2<Integer, ParseException> progressCallback;
/*    */     private long uploadedSize;
/*    */     private long totalSize;
/* 62 */     private boolean hasReportedDone = false;
/*    */ 
/*    */     public CountingOutputStream(OutputStream out, ParseCallback2<Integer, ParseException> progressCallback, long totalSize)
/*    */     {
/* 66 */       super();
/* 67 */       this.progressCallback = progressCallback;
/* 68 */       this.totalSize = totalSize;
/* 69 */       this.uploadedSize = 0L;
/*    */     }
/*    */ 
/*    */     public void write(byte[] b, int off, int len) throws IOException
/*    */     {
/* 74 */       this.out.write(b, off, len);
/* 75 */       this.uploadedSize += len;
/* 76 */       notifyCallback();
/*    */     }
/*    */ 
/*    */     public void write(int b) throws IOException
/*    */     {
/* 81 */       this.out.write(b);
/* 82 */       this.uploadedSize += 1L;
/* 83 */       notifyCallback();
/*    */     }
/*    */ 
/*    */     private void notifyCallback() {
/* 87 */       if (this.hasReportedDone) {
/* 88 */         return;
/*    */       }
/*    */ 
/* 91 */       int progressToReport = Math.round((float)this.uploadedSize / (float)this.totalSize * 100.0F);
/* 92 */       Parse.callbackOnMainThreadAsync(Task.forResult(Integer.valueOf(progressToReport)), this.progressCallback);
/*    */ 
/* 94 */       if (progressToReport == 100)
/* 95 */         this.hasReportedDone = true;
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.CountingMultipartEntity
 * JD-Core Version:    0.6.0
 */