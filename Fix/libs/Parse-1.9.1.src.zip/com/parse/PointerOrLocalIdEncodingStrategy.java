/*    */ package com.parse;
/*    */ 
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class PointerOrLocalIdEncodingStrategy
/*    */   implements ParseObjectEncodingStrategy
/*    */ {
/* 12 */   private static final PointerOrLocalIdEncodingStrategy instance = new PointerOrLocalIdEncodingStrategy();
/*    */ 
/*    */   public static PointerOrLocalIdEncodingStrategy get()
/*    */   {
/* 16 */     return instance;
/*    */   }
/*    */ 
/*    */   public JSONObject encodeRelatedObject(ParseObject object)
/*    */   {
/* 21 */     JSONObject json = new JSONObject();
/*    */     try {
/* 23 */       if (object.getObjectId() != null) {
/* 24 */         json.put("__type", "Pointer");
/* 25 */         json.put("className", object.getClassName());
/* 26 */         json.put("objectId", object.getObjectId());
/*    */       } else {
/* 28 */         json.put("__type", "Pointer");
/* 29 */         json.put("className", object.getClassName());
/* 30 */         json.put("localId", object.getOrCreateLocalId());
/*    */       }
/*    */     }
/*    */     catch (JSONException e) {
/* 34 */       throw new RuntimeException(e);
/*    */     }
/* 36 */     return json;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.PointerOrLocalIdEncodingStrategy
 * JD-Core Version:    0.6.0
 */