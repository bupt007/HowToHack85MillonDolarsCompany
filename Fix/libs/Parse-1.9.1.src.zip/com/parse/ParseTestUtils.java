/*     */ package com.parse;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.content.res.AssetManager;
/*     */ import android.os.Build;
/*     */ import android.os.Handler;
/*     */ import android.os.Looper;
/*     */ import android.os.StrictMode;
/*     */ import android.os.StrictMode.ThreadPolicy.Builder;
/*     */ import bolts.Task;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.URL;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class ParseTestUtils
/*     */ {
/*     */   private static final String TAG = "com.parse.ParseTestUtils";
/*  30 */   private static final Object TEST_SERVER_LOCK = new Object();
/*     */   private static String testServer;
/* 277 */   private static final AtomicBoolean strictModeEnabled = new AtomicBoolean(false);
/*     */ 
/*     */   public static String useServer(String theServer)
/*     */   {
/*  41 */     String oldServer = ParseObject.server;
/*  42 */     ParseObject.server = theServer;
/*  43 */     return oldServer;
/*     */   }
/*     */ 
/*     */   public static void setTestServer(String server) {
/*  47 */     synchronized (TEST_SERVER_LOCK) {
/*  48 */       testServer = server;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String getTestServer(Context context) {
/*  53 */     if (testServer == null) {
/*  54 */       synchronized (TEST_SERVER_LOCK) {
/*  55 */         if (testServer == null) {
/*     */           try {
/*  57 */             BufferedReader br = new BufferedReader(new InputStreamReader(context.getAssets().open("server.config")));
/*     */ 
/*  59 */             testServer = br.readLine();
/*     */           } catch (Exception e) {
/*  61 */             if (Build.PRODUCT.contains("vbox"))
/*     */             {
/*  63 */               testServer = "http://192.168.56.1:3000";
/*  64 */             } else if ((Build.PRODUCT.contains("sdk")) || (Build.PRODUCT.contains("full_x86")))
/*     */             {
/*  66 */               testServer = "http://10.0.2.2:3000";
/*     */             }
/*  68 */             else testServer = "http://localhost:3000";
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  74 */     return testServer;
/*     */   }
/*     */ 
/*     */   public static String useTestServer(Context context) {
/*  78 */     return useServer(getTestServer(context));
/*     */   }
/*     */ 
/*     */   public static String useBadServerPort() {
/*  82 */     return useBadServerPort(ParseObject.server);
/*     */   }
/*     */ 
/*     */   public static String useInvalidServer()
/*     */   {
/*  91 */     return useServer("http://invalid.server:3000");
/*     */   }
/*     */ 
/*     */   public static String useBadServerPort(String baseUrl)
/*     */   {
/* 100 */     String newUrl = "http://10.0.2.2:6000";
/*     */     try {
/* 102 */       URL base = new URL(baseUrl);
/* 103 */       newUrl = base.getProtocol() + "://" + base.getHost() + ":" + (base.getPort() + 999);
/*     */     }
/*     */     catch (MalformedURLException e) {
/*     */     }
/* 107 */     return useServer(newUrl);
/*     */   }
/*     */ 
/*     */   public static void clearApp()
/*     */   {
/* 114 */     ParseCommand command = new ParseCommand("clear_app", null);
/*     */     try {
/* 116 */       Parse.waitForTask(command.executeAsync());
/*     */     } catch (ParseException e) {
/* 118 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void mockV8Client()
/*     */   {
/* 126 */     ParseCommand command = new ParseCommand("mock_v8_client", null);
/*     */     try {
/* 128 */       Parse.waitForTask(command.executeAsync());
/*     */     } catch (ParseException e) {
/* 130 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void unmockV8Client()
/*     */   {
/* 138 */     ParseCommand command = new ParseCommand("unmock_v8_client", null);
/*     */     try {
/* 140 */       Parse.waitForTask(command.executeAsync());
/*     */     } catch (ParseException e) {
/* 142 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void saveObjectToDisk(ParseObject object, Context context, String filename) {
/* 147 */     object.saveToDisk(context, filename);
/*     */   }
/*     */ 
/*     */   public static ParseObject getObjectFromDisk(Context context, String filename) {
/* 151 */     return ParseObject.getFromDisk(context, filename);
/*     */   }
/*     */ 
/*     */   public static ParseUser getUserObjectFromDisk(Context context, String filename) {
/* 155 */     return (ParseUser)ParseObject.getFromDisk(context, filename);
/*     */   }
/*     */ 
/*     */   public static void saveStringToDisk(String string, Context context, String filename) {
/* 159 */     File file = new File(getParseDir(context), filename);
/*     */     try {
/* 161 */       FileOutputStream out = new FileOutputStream(file);
/* 162 */       out.write(string.getBytes("UTF-8"));
/* 163 */       out.close();
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/*     */     }
/*     */     catch (IOException e) {
/*     */     }
/*     */   }
/*     */ 
/*     */   private static File getParseDir(Context context) {
/* 172 */     return context.getDir("Parse", 0);
/*     */   }
/*     */ 
/*     */   public static Set<String> keySet(ParseObject object) {
/* 176 */     return object.keySet();
/*     */   }
/*     */ 
/*     */   public static void setCommandInitialDelay(long milliSeconds) {
/* 180 */     ParseCommand.setDefaultInitialRetryDelay(milliSeconds);
/*     */   }
/*     */ 
/*     */   public static void clearCurrentInstallationFromMemory() {
/* 184 */     ParseInstallation.currentInstallation = null;
/*     */   }
/*     */ 
/*     */   public static Set<String> pushRoutes(Context context) {
/* 188 */     Task subscriptionsTask = PushRouter.getSubscriptionsAsync(false);
/*     */     try
/*     */     {
/* 191 */       subscriptionsTask.waitForCompletion();
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/*     */     }
/* 196 */     return (Set)subscriptionsTask.getResult();
/*     */   }
/*     */ 
/*     */   public static String getInstallationId(Context context) {
/* 200 */     return ParseInstallation.getCurrentInstallation().getInstallationId();
/*     */   }
/*     */ 
/*     */   public static JSONObject getSerializedPushStateJSON() {
/* 204 */     return Parse.getDiskObject(Parse.applicationContext, "pushState");
/*     */   }
/*     */ 
/*     */   public static void startServiceIfRequired(Context context) {
/* 208 */     PushService.startServiceIfRequired(context);
/*     */   }
/*     */ 
/*     */   public static void setRetryDelayEnabled(boolean enable) {
/* 212 */     PushConnection.ENABLE_RETRY_DELAY = enable;
/*     */   }
/*     */ 
/*     */   public static ServerSocket mockPushServer()
/*     */   {
/*     */     ServerSocket socket;
/*     */     try
/*     */     {
/* 223 */       socket = new ServerSocket(0);
/*     */     } catch (IOException e) {
/* 225 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */ 
/* 228 */     InetSocketAddress address = (InetSocketAddress)socket.getLocalSocketAddress();
/* 229 */     PushService.useServer(address.getHostName(), address.getPort());
/* 230 */     Parse.logI("com.parse.ParseTestUtils", "running mockPushServer on " + address);
/*     */ 
/* 232 */     return socket;
/*     */   }
/*     */ 
/*     */   public static void resetCommandCache() {
/* 236 */     ParseEventuallyQueue cache = Parse.getEventuallyQueue();
/* 237 */     ParseEventuallyQueue.TestHelper helper = cache.getTestHelper();
/* 238 */     cache.clear();
/* 239 */     helper.clear();
/*     */   }
/*     */ 
/*     */   public static void disconnectCommandCache() {
/* 243 */     Parse.eventuallyQueue.setConnected(false);
/*     */   }
/*     */ 
/*     */   public static void reconnectCommandCache() {
/* 247 */     Parse.eventuallyQueue.setConnected(true);
/*     */   }
/*     */ 
/*     */   public static boolean waitForCommandCacheEnqueue() {
/* 251 */     return Parse.eventuallyQueue.getTestHelper().waitFor(3);
/*     */   }
/*     */ 
/*     */   public static boolean waitForCommandCacheSuccess()
/*     */   {
/* 256 */     return (Parse.eventuallyQueue.getTestHelper().waitFor(1)) && (Parse.eventuallyQueue.getTestHelper().waitFor(5));
/*     */   }
/*     */ 
/*     */   public static boolean waitForCommandCacheFailure()
/*     */   {
/* 263 */     return Parse.eventuallyQueue.getTestHelper().waitFor(2);
/*     */   }
/*     */ 
/*     */   public static int commandCacheUnexpectedEvents()
/*     */   {
/* 268 */     return Parse.eventuallyQueue.getTestHelper().unexpectedEvents();
/*     */   }
/*     */ 
/*     */   public static int setPushHistoryLength(int length) {
/* 272 */     int oldLength = PushRouter.MAX_HISTORY_LENGTH;
/* 273 */     PushRouter.MAX_HISTORY_LENGTH = length;
/* 274 */     return oldLength;
/*     */   }
/*     */ 
/*     */   public static void setStrictModeEnabledForMainThread(boolean enabled)
/*     */   {
/* 279 */     if (strictModeEnabled.compareAndSet(!enabled, enabled)) {
/* 280 */       Semaphore done = new Semaphore(0);
/*     */ 
/* 282 */       Handler handler = new Handler(Looper.getMainLooper());
/* 283 */       handler.post(new Runnable(enabled, done)
/*     */       {
/*     */         public void run() {
/* 286 */           ParseTestUtils.setStrictModeEnabledForThisThread(this.val$enabled);
/* 287 */           this.val$done.release();
/*     */         }
/*     */       });
/* 291 */       done.acquireUninterruptibly();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setStrictModeEnabledForThisThread(boolean enabled) {
/* 296 */     if (enabled) {
/* 297 */       StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().penaltyDeath().build());
/*     */     }
/*     */     else
/*     */     {
/* 304 */       StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseTestUtils
 * JD-Core Version:    0.6.0
 */