/*    */ package com.parse;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ class ParseRESTConfigCommand extends ParseRESTCommand
/*    */ {
/*    */   public ParseRESTConfigCommand(String httpPath, ParseRequest.Method httpMethod, Map<String, ?> parameters, String sessionToken)
/*    */   {
/* 10 */     super(httpPath, httpMethod, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTConfigCommand fetchConfigCommand(String sessionToken) {
/* 14 */     return new ParseRESTConfigCommand("config", ParseRequest.Method.GET, null, sessionToken);
/*    */   }
/*    */ 
/*    */   public static ParseRESTConfigCommand updateConfigCommand(Map<String, ?> configParameters, String sessionToken)
/*    */   {
/* 19 */     Map commandParameters = null;
/* 20 */     if (configParameters != null) {
/* 21 */       commandParameters = new HashMap();
/* 22 */       commandParameters.put("params", configParameters);
/*    */     }
/* 24 */     return new ParseRESTConfigCommand("config", ParseRequest.Method.PUT, commandParameters, sessionToken);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTConfigCommand
 * JD-Core Version:    0.6.0
 */