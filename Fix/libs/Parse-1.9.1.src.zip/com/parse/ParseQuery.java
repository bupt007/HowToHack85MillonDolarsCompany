/*      */ package com.parse;
/*      */ 
/*      */ import bolts.Continuation;
/*      */ import bolts.Task;
/*      */ import bolts.Task.TaskCompletionSource;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.regex.Pattern;
/*      */ import org.json.JSONArray;
/*      */ import org.json.JSONException;
/*      */ import org.json.JSONObject;
/*      */ 
/*      */ public class ParseQuery<T extends ParseObject>
/*      */ {
/*      */   private static final String TAG = "com.parse.ParseQuery";
/*      */   private String className;
/*      */   private QueryConstraints where;
/*      */   private ArrayList<String> include;
/*      */   private ArrayList<String> selectedKeys;
/*      */   private int limit;
/*      */   private boolean trace;
/*      */   private int skip;
/*      */   private String order;
/*  209 */   private HashMap<String, Object> extraOptions = null;
/*      */   private long queryStart;
/*      */   private long querySent;
/*      */   private long queryReceived;
/*      */   private long objectsParsed;
/*  219 */   private final Object isRunningLock = new Object();
/*  220 */   private boolean isRunning = false;
/*      */   private Task<Void>.TaskCompletionSource ct;
/*      */   private CachePolicy cachePolicy;
/*      */   private boolean isFromLocalDatastore;
/*      */   private long maxCacheAge;
/*      */   private String pinName;
/*      */   boolean ignoreACLs;
/*      */   boolean includeIsDeletingEventually;
/*      */ 
/*      */   public static <T extends ParseObject> ParseQuery<T> or(List<ParseQuery<T>> queries)
/*      */   {
/*  150 */     List localList = new ArrayList();
/*  151 */     String className = null;
/*  152 */     for (int i = 0; i < queries.size(); i++) {
/*  153 */       if ((className != null) && (!((ParseQuery)queries.get(i)).className.equals(className))) {
/*  154 */         throw new IllegalArgumentException("All of the queries in an or query must be on the same class ");
/*      */       }
/*      */ 
/*  157 */       className = ((ParseQuery)queries.get(i)).className;
/*  158 */       localList.add(queries.get(i));
/*      */     }
/*  160 */     if (localList.size() == 0) {
/*  161 */       throw new IllegalArgumentException("Can't take an or of an empty list of queries");
/*      */     }
/*  163 */     ParseQuery value = new ParseQuery(className);
/*  164 */     return value.whereSatifiesAnyOf(localList);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> ParseQuery<T> getQuery(Class<T> subclass)
/*      */   {
/*  176 */     return new ParseQuery(subclass);
/*      */   }
/*      */ 
/*      */   public static <T extends ParseObject> ParseQuery<T> getQuery(String className)
/*      */   {
/*  188 */     return new ParseQuery(className);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static ParseQuery<ParseUser> getUserQuery()
/*      */   {
/*  198 */     return ParseUser.getQuery();
/*      */   }
/*      */ 
/*      */   public ParseQuery(Class<T> subclass)
/*      */   {
/*  301 */     this(ParseObject.getClassName(subclass));
/*      */   }
/*      */ 
/*      */   public ParseQuery(String theClassName)
/*      */   {
/*  312 */     this.className = theClassName;
/*  313 */     this.limit = -1;
/*  314 */     this.skip = 0;
/*  315 */     this.where = new QueryConstraints();
/*  316 */     this.include = new ArrayList();
/*  317 */     this.cachePolicy = CachePolicy.IGNORE_CACHE;
/*  318 */     this.isFromLocalDatastore = false;
/*  319 */     this.maxCacheAge = 9223372036854775807L;
/*      */ 
/*  321 */     this.trace = false;
/*  322 */     this.extraOptions = new HashMap();
/*      */   }
/*      */ 
/*      */   private void checkIfRunning() {
/*  326 */     checkIfRunning(false);
/*      */   }
/*      */ 
/*      */   private void checkIfRunning(boolean grabLock) {
/*  330 */     synchronized (this.isRunningLock) {
/*  331 */       if (this.isRunning) {
/*  332 */         throw new RuntimeException("This query has an outstanding network connection. You have to wait until it's done.");
/*      */       }
/*  334 */       if (grabLock) {
/*  335 */         this.isRunning = true;
/*  336 */         this.ct = Task.create();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   QueryConstraints getConstraints()
/*      */   {
/*  343 */     return this.where;
/*      */   }
/*      */ 
/*      */   private Task<ParseUser> getUserAsync()
/*      */   {
/*  352 */     return this.ignoreACLs ? Task.forResult(null) : ParseUser.getCurrentUserAsync();
/*      */   }
/*      */ 
/*      */   JSONObject toREST()
/*      */   {
/*  357 */     JSONObject params = new JSONObject();
/*      */     try
/*      */     {
/*  360 */       params.put("className", this.className);
/*  361 */       params.put("where", Parse.encode(this.where, PointerEncodingStrategy.get()));
/*      */ 
/*  363 */       if (this.limit >= 0) {
/*  364 */         params.put("limit", this.limit);
/*      */       }
/*  366 */       if (this.skip > 0) {
/*  367 */         params.put("skip", this.skip);
/*      */       }
/*  369 */       if (this.order != null) {
/*  370 */         params.put("order", this.order);
/*      */       }
/*  372 */       if (!this.include.isEmpty()) {
/*  373 */         params.put("include", Parse.join(",", this.include));
/*      */       }
/*  375 */       if (this.selectedKeys != null) {
/*  376 */         params.put("fields", Parse.join(",", this.selectedKeys));
/*      */       }
/*  378 */       if (this.trace) {
/*  379 */         params.put("trace", "1");
/*      */       }
/*      */ 
/*  383 */       for (String key : this.extraOptions.keySet())
/*  384 */         params.put(key, Parse.encode(this.extraOptions.get(key), PointerEncodingStrategy.get()));
/*      */     }
/*      */     catch (JSONException e) {
/*  387 */       throw new RuntimeException(e);
/*      */     }
/*      */ 
/*  390 */     return params;
/*      */   }
/*      */ 
/*      */   private ParseRESTQueryCommand currentFindCommand(ParseUser user)
/*      */   {
/*  396 */     String sessionToken = user != null ? user.getSessionToken() : null;
/*  397 */     return ParseRESTQueryCommand.findCommand(this.className, this.order, this.where, this.selectedKeys, this.include, this.limit, this.skip, this.extraOptions, this.trace, sessionToken);
/*      */   }
/*      */ 
/*      */   private ParseRESTCommand currentCountCommand(ParseUser user)
/*      */   {
/*  402 */     return ParseRESTQueryCommand.countCommand(currentFindCommand(user));
/*      */   }
/*      */ 
/*      */   private List<T> convertFindResponse(JSONObject response)
/*      */     throws JSONException
/*      */   {
/*  408 */     ArrayList answer = new ArrayList();
/*  409 */     JSONArray results = response.getJSONArray("results");
/*  410 */     if (results == null) {
/*  411 */       Parse.logD("com.parse.ParseQuery", "null results in find response");
/*      */     } else {
/*  413 */       String resultClassName = response.optString("className");
/*  414 */       if (resultClassName.equals("")) {
/*  415 */         resultClassName = this.className;
/*      */       }
/*  417 */       for (int i = 0; i < results.length(); i++) {
/*  418 */         JSONObject data = results.getJSONObject(i);
/*  419 */         ParseObject object = ParseObject.fromJSON(data, resultClassName, this.selectedKeys == null);
/*  420 */         answer.add(object);
/*      */ 
/*  426 */         RelationConstraint relation = (RelationConstraint)this.where.get("$relatedTo");
/*  427 */         if (relation != null) {
/*  428 */           relation.getRelation().addKnownObject(object);
/*      */         }
/*      */       }
/*      */     }
/*  432 */     this.objectsParsed = System.nanoTime();
/*      */ 
/*  434 */     if (response.has("trace")) {
/*  435 */       Object serverTrace = response.get("trace");
/*  436 */       Parse.logD("ParseQuery", String.format("Query pre-processing took %f seconds\n%s\nClient side parsing took %f seconds\n", new Object[] { Float.valueOf((float)(this.querySent - this.queryStart) / 1000000.0F), serverTrace, Float.valueOf((float)(this.objectsParsed - this.queryReceived) / 1000000.0F) }));
/*      */     }
/*      */ 
/*  445 */     return answer;
/*      */   }
/*      */ 
/*      */   private <TResult> Task<TResult> runCommandWithPolicyAsync(CommandDelegate<TResult> c, CachePolicy policy)
/*      */   {
/*  450 */     switch (31.$SwitchMap$com$parse$ParseQuery$CachePolicy[policy.ordinal()]) {
/*      */     case 1:
/*      */     case 2:
/*  453 */       return c.runOnNetworkAsync(true);
/*      */     case 3:
/*  455 */       return c.runFromCacheAsync();
/*      */     case 4:
/*  457 */       return c.runFromCacheAsync().continueWithTask(new Continuation(c)
/*      */       {
/*      */         public Task<TResult> then(Task<TResult> task) throws Exception {
/*  460 */           if ((task.isFaulted()) && ((task.getError() instanceof ParseException))) {
/*  461 */             return this.val$c.runOnNetworkAsync(true);
/*      */           }
/*  463 */           return task;
/*      */         } } );
/*      */     case 5:
/*  467 */       return c.runOnNetworkAsync(false).continueWithTask(new Continuation(c)
/*      */       {
/*      */         public Task<TResult> then(Task<TResult> task) throws Exception
/*      */         {
/*  471 */           if ((task.isFaulted()) && ((task.getError() instanceof ParseException)) && (((ParseException)task.getError()).getCode() == 100))
/*      */           {
/*  474 */             return this.val$c.runFromCacheAsync();
/*      */           }
/*      */ 
/*  478 */           return task;
/*      */         } } );
/*      */     case 6:
/*  482 */       throw new RuntimeException("You cannot use the cache policy CACHE_THEN_NETWORK with find()");
/*      */     }
/*  484 */     throw new RuntimeException("Unknown cache policy: " + this.cachePolicy);
/*      */   }
/*      */ 
/*      */   private Task<Integer> countWithCachePolicyAsync(CachePolicy policy, ParseUser user)
/*      */   {
/*  489 */     CommandDelegate callbacks = new CommandDelegate(user)
/*      */     {
/*      */       public Task<Integer> runOnNetworkAsync(boolean retry) {
/*  492 */         return ParseQuery.this.countFromNetworkAsync(this.val$user, retry);
/*      */       }
/*      */ 
/*      */       public Task<Integer> runFromCacheAsync()
/*      */       {
/*  497 */         return ParseQuery.this.countFromCacheAsync(this.val$user);
/*      */       }
/*      */     };
/*  500 */     return runCommandWithPolicyAsync(callbacks, policy);
/*      */   }
/*      */ 
/*      */   Task<List<T>> findWithCachePolicyAsync(CachePolicy policy, ParseUser user) {
/*  504 */     CommandDelegate callbacks = new CommandDelegate(user)
/*      */     {
/*      */       public Task<List<T>> runOnNetworkAsync(boolean retry) {
/*  507 */         return ParseQuery.this.findFromNetworkAsync(this.val$user, retry);
/*      */       }
/*      */ 
/*      */       public Task<List<T>> runFromCacheAsync()
/*      */       {
/*  512 */         return ParseQuery.this.findFromCacheAsync(this.val$user);
/*      */       }
/*      */     };
/*  515 */     return runCommandWithPolicyAsync(callbacks, policy);
/*      */   }
/*      */ 
/*      */   private Task<T> getFirstWithCachePolicyAsync(CachePolicy policy, ParseUser user) {
/*  519 */     this.limit = 1;
/*  520 */     return findWithCachePolicyAsync(policy, user).continueWith(new Continuation()
/*      */     {
/*      */       public T then(Task<List<T>> task) throws Exception {
/*  523 */         if (task.isFaulted()) {
/*  524 */           throw task.getError();
/*      */         }
/*  526 */         if ((task.getResult() != null) && (((List)task.getResult()).size() > 0)) {
/*  527 */           return (ParseObject)((List)task.getResult()).get(0);
/*      */         }
/*  529 */         throw new ParseException(101, "no results found for query");
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private Task<T> getFirstFromLocalDatastoreAsync(ParseUser user) {
/*  535 */     this.limit = 1;
/*  536 */     return findFromLocalDatastoreAsync(user).continueWith(new Continuation()
/*      */     {
/*      */       public T then(Task<List<T>> task) throws Exception {
/*  539 */         if (task.isFaulted()) {
/*  540 */           throw task.getError();
/*      */         }
/*  542 */         if ((task.getResult() != null) && (((List)task.getResult()).size() > 0)) {
/*  543 */           return (ParseObject)((List)task.getResult()).get(0);
/*      */         }
/*  545 */         throw new ParseException(101, "no results found for query");
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private Task<T> getWithCachePolicyAsync(String objectId, CachePolicy policy, ParseUser user) {
/*  551 */     this.skip = -1;
/*  552 */     this.where = new QueryConstraints();
/*  553 */     this.where.put("objectId", objectId);
/*  554 */     return getFirstWithCachePolicyAsync(policy, user);
/*      */   }
/*      */ 
/*      */   private Task<T> getFromLocalDatastoreAsync(String objectId, ParseUser user) {
/*  558 */     this.skip = -1;
/*  559 */     this.where = new QueryConstraints();
/*  560 */     this.where.put("objectId", objectId);
/*  561 */     return getFirstFromLocalDatastoreAsync(user);
/*      */   }
/*      */ 
/*      */   public void cancel()
/*      */   {
/*  569 */     synchronized (this.isRunningLock) {
/*  570 */       if (this.ct != null) {
/*  571 */         this.ct.trySetCancelled();
/*  572 */         this.ct = null;
/*      */       }
/*  574 */       this.isRunning = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public List<T> find()
/*      */     throws ParseException
/*      */   {
/*  588 */     return (List)Parse.waitForTask(findInBackground());
/*      */   }
/*      */ 
/*      */   public T getFirst()
/*      */     throws ParseException
/*      */   {
/*  603 */     return (ParseObject)Parse.waitForTask(getFirstInBackground());
/*      */   }
/*      */ 
/*      */   private Task<List<T>> findFromNetworkAsync(ParseUser user, boolean shouldRetry)
/*      */   {
/*  612 */     ParseRESTCommand command = currentFindCommand(user);
/*  613 */     if (shouldRetry) {
/*  614 */       command.enableRetrying();
/*      */     }
/*      */ 
/*  617 */     if (this.ct == null)
/*  618 */       command.cancel();
/*      */     else {
/*  620 */       this.ct.getTask().continueWith(new Continuation(command)
/*      */       {
/*      */         public Void then(Task<Void> task) throws Exception {
/*  623 */           if (task.isCancelled()) {
/*  624 */             this.val$command.cancel();
/*      */           }
/*  626 */           return null;
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/*  632 */     boolean caching = this.cachePolicy != CachePolicy.IGNORE_CACHE;
/*  633 */     this.querySent = System.nanoTime();
/*  634 */     return command.executeAsync().onSuccess(new Continuation(caching, command)
/*      */     {
/*      */       public List<T> then(Task<Object> task) throws Exception {
/*  637 */         if (this.val$caching) {
/*  638 */           Object result = task.getResult();
/*  639 */           ParseKeyValueCache.saveToKeyValueCache(this.val$command.getCacheKey(), result.toString());
/*      */         }
/*      */ 
/*  642 */         ParseQuery.access$402(ParseQuery.this, System.nanoTime());
/*  643 */         return ParseQuery.this.convertFindResponse((JSONObject)task.getResult());
/*      */       }
/*      */     }
/*      */     , Task.BACKGROUND_EXECUTOR);
/*      */   }
/*      */ 
/*      */   private static void checkLDSEnabled(boolean enabled)
/*      */   {
/*  649 */     if ((enabled) && (!OfflineStore.isEnabled())) {
/*  650 */       throw new IllegalStateException("Method requires Local Datastore. Please refer to `Parse#enableLocalDatastore(Context)`.");
/*      */     }
/*      */ 
/*  653 */     if ((!enabled) && (OfflineStore.isEnabled()))
/*  654 */       throw new IllegalStateException("Unsupported method when Local Datastore is enabled.");
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> setCachePolicy(CachePolicy newCachePolicy)
/*      */   {
/*  670 */     checkLDSEnabled(false);
/*  671 */     checkIfRunning();
/*      */ 
/*  673 */     this.cachePolicy = newCachePolicy;
/*  674 */     return this;
/*      */   }
/*      */ 
/*      */   public CachePolicy getCachePolicy()
/*      */   {
/*  681 */     checkLDSEnabled(false);
/*      */ 
/*  683 */     return this.cachePolicy;
/*      */   }
/*      */ 
/*      */   ParseQuery<T> fromNetwork()
/*      */   {
/*  696 */     checkLDSEnabled(true);
/*  697 */     checkIfRunning();
/*      */ 
/*  699 */     this.cachePolicy = CachePolicy.NETWORK_ONLY;
/*  700 */     this.isFromLocalDatastore = false;
/*  701 */     this.pinName = null;
/*  702 */     return this;
/*      */   }
/*      */ 
/*      */   boolean isFromNetwork() {
/*  706 */     checkLDSEnabled(true);
/*      */ 
/*  708 */     return this.cachePolicy == CachePolicy.NETWORK_ONLY;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> fromLocalDatastore()
/*      */   {
/*  721 */     return fromPin(null);
/*      */   }
/*      */ 
/*      */   boolean isFromLocalDatastore() {
/*  725 */     checkLDSEnabled(true);
/*      */ 
/*  727 */     return this.isFromLocalDatastore;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> fromPin()
/*      */   {
/*  741 */     return fromPin("_default");
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> fromPin(String name)
/*      */   {
/*  756 */     checkLDSEnabled(true);
/*  757 */     checkIfRunning();
/*      */ 
/*  759 */     this.isFromLocalDatastore = true;
/*  760 */     this.pinName = name;
/*  761 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> ignoreACLs()
/*      */   {
/*  772 */     checkLDSEnabled(true);
/*  773 */     checkIfRunning();
/*      */ 
/*  775 */     this.ignoreACLs = true;
/*  776 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> setMaxCacheAge(long maxAgeInMilliseconds)
/*      */   {
/*  785 */     checkLDSEnabled(false);
/*      */ 
/*  787 */     this.maxCacheAge = maxAgeInMilliseconds;
/*  788 */     return this;
/*      */   }
/*      */ 
/*      */   public long getMaxCacheAge()
/*      */   {
/*  796 */     checkLDSEnabled(false);
/*      */ 
/*  798 */     return this.maxCacheAge;
/*      */   }
/*      */ 
/*      */   private ParseQuery<T> build()
/*      */   {
/*  803 */     if ((!this.isFromLocalDatastore) && (this.ignoreACLs)) {
/*  804 */       throw new IllegalStateException("`ignoreACLs` cannot be combined with network queries");
/*      */     }
/*      */ 
/*  807 */     return this;
/*      */   }
/*      */ 
/*      */   private Task<List<T>> findFromCacheAsync(ParseUser user)
/*      */   {
/*  819 */     return Task.call(new Object(user)
/*      */     {
/*      */       public List<T> call() throws Exception {
/*  822 */         String cacheKey = ParseQuery.this.currentFindCommand(this.val$user).getCacheKey();
/*  823 */         Object cached = ParseKeyValueCache.jsonFromKeyValueCache(cacheKey, ParseQuery.this.maxCacheAge);
/*  824 */         if (cached == null) {
/*  825 */           throw new ParseException(120, "results not cached");
/*      */         }
/*  827 */         if (!(cached instanceof JSONObject)) {
/*  828 */           throw new ParseException(120, "the cache contains the wrong datatype");
/*      */         }
/*      */ 
/*  831 */         JSONObject object = (JSONObject)cached;
/*      */         try {
/*  833 */           return ParseQuery.this.convertFindResponse(object); } catch (JSONException e) {
/*      */         }
/*  835 */         throw new ParseException(120, "the cache contains corrupted json");
/*      */       }
/*      */     }
/*      */     , Task.BACKGROUND_EXECUTOR);
/*      */   }
/*      */ 
/*      */   private Task<Integer> countFromCacheAsync(ParseUser user)
/*      */   {
/*  850 */     return Task.call(new Object(user)
/*      */     {
/*      */       public Integer call() throws Exception {
/*  853 */         String cacheKey = ParseQuery.this.currentCountCommand(this.val$user).getCacheKey();
/*  854 */         Object cached = ParseKeyValueCache.jsonFromKeyValueCache(cacheKey, ParseQuery.this.maxCacheAge);
/*  855 */         if (cached == null) {
/*  856 */           throw new ParseException(120, "results not cached");
/*      */         }
/*  858 */         if (!(cached instanceof JSONObject)) {
/*  859 */           throw new ParseException(120, "the cache contains the wrong datatype");
/*      */         }
/*      */ 
/*  862 */         JSONObject object = (JSONObject)cached;
/*      */         try {
/*  864 */           return Integer.valueOf(object.getInt("count")); } catch (JSONException e) {
/*      */         }
/*  866 */         throw new ParseException(120, "the cache contains corrupted json");
/*      */       }
/*      */     }
/*      */     , Task.BACKGROUND_EXECUTOR);
/*      */   }
/*      */ 
/*      */   private Task<List<T>> findFromLocalDatastoreAsync(ParseUser user)
/*      */   {
/*  881 */     OfflineStore store = OfflineStore.getCurrent();
/*      */     Task task;
/*      */     Task task;
/*  883 */     if (this.pinName != null)
/*  884 */       task = ParsePin.getParsePin(this.pinName);
/*      */     else {
/*  886 */       task = Task.forResult(null);
/*      */     }
/*  888 */     return task.onSuccessTask(new Continuation(store, user)
/*      */     {
/*      */       public Task<List<T>> then(Task<ParsePin> task) throws Exception {
/*  891 */         ParsePin pin = (ParsePin)task.getResult();
/*  892 */         return this.val$store.findAsync(ParseQuery.this, this.val$user, pin);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private Task<Integer> countFromLocalDatastoreAsync(ParseUser user)
/*      */   {
/*  906 */     OfflineStore store = OfflineStore.getCurrent();
/*      */     Task task;
/*      */     Task task;
/*  908 */     if (this.pinName != null)
/*  909 */       task = ParsePin.getParsePin(this.pinName);
/*      */     else {
/*  911 */       task = Task.forResult(null);
/*      */     }
/*  913 */     return task.onSuccessTask(new Continuation(store, user)
/*      */     {
/*      */       public Task<Integer> then(Task<ParsePin> task) throws Exception {
/*  916 */         ParsePin pin = (ParsePin)task.getResult();
/*  917 */         return this.val$store.countAsync(ParseQuery.this, this.val$user, pin);
/*      */       } } );
/*      */   }
/*      */ 
/*      */   private <TResult> Task<TResult> doWithRunningCheck(Callable<Task<TResult>> runnable) {
/*  933 */     checkIfRunning(true);
/*      */     Task task;
/*      */     try {
/*  936 */       task = (Task)runnable.call();
/*      */     } catch (Exception e) {
/*  938 */       task = Task.forError(e);
/*      */     }
/*  940 */     return task.continueWithTask(new Object()
/*      */     {
/*      */       public Task<TResult> then(Task<TResult> task) throws Exception {
/*  943 */         synchronized (ParseQuery.this.isRunningLock) {
/*  944 */           ParseQuery.access$1002(ParseQuery.this, false);
/*  945 */           if (ParseQuery.this.ct != null) {
/*  946 */             ParseQuery.this.ct.trySetResult(null);
/*      */           }
/*  948 */           ParseQuery.access$1102(ParseQuery.this, null);
/*      */         }
/*  950 */         return task;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private <TResult> void doInBackground(CallableWithCachePolicy<Task<TResult>> callable, ParseCallback2<TResult, ParseException> callback)
/*      */   {
/*  960 */     Parse.callbackOnMainThreadAsync(doWithRunningCheck(new Callable(callable, callback)
/*      */     {
/*      */       public Task<TResult> call()
/*      */         throws Exception
/*      */       {
/*      */         Task findTask;
/*  964 */         if (ParseQuery.this.cachePolicy == ParseQuery.CachePolicy.CACHE_THEN_NETWORK) {
/*  965 */           Task findTask = (Task)this.val$callable.call(ParseQuery.CachePolicy.CACHE_ONLY);
/*  966 */           findTask = Parse.callbackOnMainThreadAsync(findTask, this.val$callback);
/*  967 */           findTask = findTask.continueWithTask(new Continuation()
/*      */           {
/*      */             public Task<TResult> then(Task<TResult> task) throws Exception {
/*  970 */               if (task.isCancelled()) {
/*  971 */                 return task;
/*      */               }
/*  973 */               return (Task)ParseQuery.14.this.val$callable.call(ParseQuery.CachePolicy.NETWORK_ONLY);
/*      */             } } );
/*      */         } else {
/*  977 */           findTask = (Task)this.val$callable.call(ParseQuery.this.cachePolicy);
/*      */         }
/*  979 */         return findTask;
/*      */       }
/*      */     }), callback);
/*      */   }
/*      */ 
/*      */   public Task<List<T>> findInBackground()
/*      */   {
/*  995 */     build();
/*      */ 
/*  997 */     return doWithRunningCheck(new Callable()
/*      */     {
/*      */       public Task<List<T>> call() throws Exception {
/* 1000 */         return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
/*      */         {
/*      */           public Task<List<T>> then(Task<ParseUser> task) throws Exception {
/* 1003 */             ParseUser user = (ParseUser)task.getResult();
/* 1004 */             ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1005 */             if (ParseQuery.this.isFromLocalDatastore) {
/* 1006 */               return ParseQuery.this.findFromLocalDatastoreAsync(user);
/*      */             }
/* 1008 */             return ParseQuery.this.findWithCachePolicyAsync(ParseQuery.this.cachePolicy, user);
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public void findInBackground(FindCallback<T> callback)
/*      */   {
/* 1028 */     build();
/*      */ 
/* 1030 */     if (this.isFromLocalDatastore) {
/* 1031 */       Parse.callbackOnMainThreadAsync(doWithRunningCheck(new Callable()
/*      */       {
/*      */         public Task<List<T>> call() throws Exception {
/* 1034 */           return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
/*      */           {
/*      */             public Task<List<T>> then(Task<ParseUser> task) throws Exception {
/* 1037 */               ParseUser user = (ParseUser)task.getResult();
/* 1038 */               ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1039 */               return ParseQuery.this.findFromLocalDatastoreAsync(user);
/*      */             }
/*      */           });
/*      */         }
/*      */       }), callback);
/*      */     }
/*      */     else
/*      */     {
/* 1045 */       doInBackground(new CallableWithCachePolicy()
/*      */       {
/*      */         public Task<List<T>> call(ParseQuery.CachePolicy cachePolicy) {
/* 1048 */           return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation(cachePolicy)
/*      */           {
/*      */             public Task<List<T>> then(Task<ParseUser> task) throws Exception {
/* 1051 */               ParseUser user = (ParseUser)task.getResult();
/* 1052 */               ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1053 */               return ParseQuery.this.findWithCachePolicyAsync(this.val$cachePolicy, user);
/*      */             }
/*      */           });
/*      */         }
/*      */       }
/*      */       , callback);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Task<T> getFirstInBackground()
/*      */   {
/* 1074 */     build();
/*      */ 
/* 1076 */     return doWithRunningCheck(new Callable()
/*      */     {
/*      */       public Task<T> call() throws Exception {
/* 1079 */         return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
/*      */         {
/*      */           public Task<T> then(Task<ParseUser> task) throws Exception {
/* 1082 */             ParseUser user = (ParseUser)task.getResult();
/* 1083 */             ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1084 */             if (ParseQuery.this.isFromLocalDatastore) {
/* 1085 */               return ParseQuery.this.getFirstFromLocalDatastoreAsync(user);
/*      */             }
/* 1087 */             return ParseQuery.this.getFirstWithCachePolicyAsync(ParseQuery.this.cachePolicy, user);
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public void getFirstInBackground(GetCallback<T> callback)
/*      */   {
/* 1109 */     build();
/*      */ 
/* 1111 */     if (this.isFromLocalDatastore) {
/* 1112 */       Parse.callbackOnMainThreadAsync(doWithRunningCheck(new Callable()
/*      */       {
/*      */         public Task<T> call() throws Exception {
/* 1115 */           return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
/*      */           {
/*      */             public Task<T> then(Task<ParseUser> task) throws Exception {
/* 1118 */               ParseUser user = (ParseUser)task.getResult();
/* 1119 */               ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1120 */               return ParseQuery.this.getFirstFromLocalDatastoreAsync(user);
/*      */             }
/*      */           });
/*      */         }
/*      */       }), callback);
/*      */     }
/*      */     else
/*      */     {
/* 1126 */       doInBackground(new CallableWithCachePolicy()
/*      */       {
/*      */         public Task<T> call(ParseQuery.CachePolicy cachePolicy) {
/* 1129 */           return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation(cachePolicy)
/*      */           {
/*      */             public Task<T> then(Task<ParseUser> task) throws Exception {
/* 1132 */               ParseUser user = (ParseUser)task.getResult();
/* 1133 */               ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1134 */               return ParseQuery.this.getFirstWithCachePolicyAsync(this.val$cachePolicy, user);
/*      */             }
/*      */           });
/*      */         }
/*      */       }
/*      */       , callback);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int count()
/*      */     throws ParseException
/*      */   {
/* 1149 */     return ((Integer)Parse.waitForTask(countInBackground())).intValue();
/*      */   }
/*      */ 
/*      */   private Task<Integer> countFromNetworkAsync(ParseUser user, boolean shouldRetry) {
/* 1153 */     ParseRESTCommand command = currentCountCommand(user);
/* 1154 */     if (shouldRetry) {
/* 1155 */       command.enableRetrying();
/*      */     }
/*      */ 
/* 1158 */     if (this.ct == null)
/* 1159 */       command.cancel();
/*      */     else {
/* 1161 */       this.ct.getTask().continueWith(new Continuation(command)
/*      */       {
/*      */         public Void then(Task<Void> task) throws Exception {
/* 1164 */           if (task.isCancelled()) {
/* 1165 */             this.val$command.cancel();
/*      */           }
/* 1167 */           return null;
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/* 1173 */     boolean caching = this.cachePolicy != CachePolicy.IGNORE_CACHE;
/* 1174 */     return command.executeAsync().onSuccessTask(new Continuation(caching, command)
/*      */     {
/*      */       public Task<Object> then(Task<Object> task) throws Exception {
/* 1177 */         if (this.val$caching) {
/* 1178 */           Object result = task.getResult();
/* 1179 */           ParseKeyValueCache.saveToKeyValueCache(this.val$command.getCacheKey(), result.toString());
/*      */         }
/* 1181 */         return task;
/*      */       }
/*      */     }
/*      */     , Task.BACKGROUND_EXECUTOR).onSuccess(new Continuation()
/*      */     {
/*      */       public Integer then(Task<Object> task)
/*      */         throws Exception
/*      */       {
/* 1187 */         return Integer.valueOf(((JSONObject)task.getResult()).optInt("count"));
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public Task<Integer> countInBackground()
/*      */   {
/* 1200 */     build();
/*      */ 
/* 1202 */     return doWithRunningCheck(new Callable()
/*      */     {
/*      */       public Task<Integer> call() throws Exception {
/* 1205 */         return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
/*      */         {
/*      */           public Task<Integer> then(Task<ParseUser> task) throws Exception {
/* 1208 */             ParseUser user = (ParseUser)task.getResult();
/* 1209 */             ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1210 */             if (ParseQuery.this.isFromLocalDatastore) {
/* 1211 */               return ParseQuery.this.countFromLocalDatastoreAsync(user);
/*      */             }
/* 1213 */             return ParseQuery.this.countWithCachePolicyAsync(ParseQuery.this.cachePolicy, user);
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public void countInBackground(CountCallback callback)
/*      */   {
/* 1230 */     build();
/*      */ 
/* 1233 */     ParseCallback2 c = null;
/* 1234 */     if (callback != null) {
/* 1235 */       c = new ParseCallback2(callback)
/*      */       {
/*      */         public void done(Integer integer, ParseException e) {
/* 1238 */           this.val$callback.done(e == null ? integer.intValue() : -1, e);
/*      */         }
/*      */       };
/*      */     }
/* 1243 */     if (this.isFromLocalDatastore) {
/* 1244 */       Parse.callbackOnMainThreadAsync(doWithRunningCheck(new Callable()
/*      */       {
/*      */         public Task<Integer> call() throws Exception {
/* 1247 */           return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
/*      */           {
/*      */             public Task<Integer> then(Task<ParseUser> task) throws Exception {
/* 1250 */               ParseUser user = (ParseUser)task.getResult();
/* 1251 */               ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1252 */               return ParseQuery.this.countFromLocalDatastoreAsync(user);
/*      */             }
/*      */           });
/*      */         }
/*      */       }), c);
/*      */     }
/*      */     else
/*      */     {
/* 1258 */       doInBackground(new CallableWithCachePolicy()
/*      */       {
/*      */         public Task<Integer> call(ParseQuery.CachePolicy cachePolicy) {
/* 1261 */           return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation(cachePolicy)
/*      */           {
/*      */             public Task<Integer> then(Task<ParseUser> task) throws Exception {
/* 1264 */               ParseUser user = (ParseUser)task.getResult();
/* 1265 */               ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1266 */               return ParseQuery.this.countWithCachePolicyAsync(this.val$cachePolicy, user);
/*      */             }
/*      */           });
/*      */         }
/*      */       }
/*      */       , c);
/*      */     }
/*      */   }
/*      */ 
/*      */   public T get(String objectId)
/*      */     throws ParseException
/*      */   {
/* 1288 */     return (ParseObject)Parse.waitForTask(getInBackground(objectId));
/*      */   }
/*      */ 
/*      */   public boolean hasCachedResult()
/*      */   {
/* 1296 */     checkLDSEnabled(false);
/*      */ 
/* 1298 */     ParseUser user = null;
/*      */     try {
/* 1300 */       user = (ParseUser)Parse.waitForTask(getUserAsync());
/*      */     }
/*      */     catch (ParseException e)
/*      */     {
/*      */     }
/*      */ 
/* 1309 */     String raw = ParseKeyValueCache.loadFromKeyValueCache(currentFindCommand(user).getCacheKey(), this.maxCacheAge);
/* 1310 */     return raw != null;
/*      */   }
/*      */ 
/*      */   public void clearCachedResult()
/*      */   {
/* 1319 */     checkLDSEnabled(false);
/*      */ 
/* 1321 */     ParseUser user = null;
/*      */     try {
/* 1323 */       user = (ParseUser)Parse.waitForTask(getUserAsync());
/*      */     }
/*      */     catch (ParseException e)
/*      */     {
/*      */     }
/*      */ 
/* 1329 */     ParseKeyValueCache.clearFromKeyValueCache(currentFindCommand(user).getCacheKey());
/*      */   }
/*      */ 
/*      */   public static void clearAllCachedResults()
/*      */   {
/* 1336 */     checkLDSEnabled(false);
/*      */ 
/* 1338 */     ParseKeyValueCache.clearKeyValueCacheDir();
/*      */   }
/*      */ 
/*      */   public Task<T> getInBackground(String objectId)
/*      */   {
/* 1355 */     build();
/*      */ 
/* 1357 */     return doWithRunningCheck(new Callable(objectId)
/*      */     {
/*      */       public Task<T> call() throws Exception {
/* 1360 */         return ParseQuery.this.getUserAsync().continueWithTask(new Continuation()
/*      */         {
/*      */           public Task<T> then(Task<ParseUser> task) throws Exception {
/* 1363 */             ParseUser user = (ParseUser)task.getResult();
/* 1364 */             ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1365 */             if (ParseQuery.this.isFromLocalDatastore) {
/* 1366 */               return ParseQuery.this.getFromLocalDatastoreAsync(ParseQuery.28.this.val$objectId, user);
/*      */             }
/* 1368 */             return ParseQuery.this.getWithCachePolicyAsync(ParseQuery.28.this.val$objectId, ParseQuery.this.cachePolicy, user);
/*      */           }
/*      */         });
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public void getInBackground(String objectId, GetCallback<T> callback)
/*      */   {
/* 1390 */     build();
/*      */ 
/* 1392 */     if (this.isFromLocalDatastore) {
/* 1393 */       Parse.callbackOnMainThreadAsync(doWithRunningCheck(new Callable(objectId)
/*      */       {
/*      */         public Task<T> call() throws Exception {
/* 1396 */           return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation()
/*      */           {
/*      */             public Task<T> then(Task<ParseUser> task) throws Exception {
/* 1399 */               ParseUser user = (ParseUser)task.getResult();
/* 1400 */               ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1401 */               return ParseQuery.this.getFromLocalDatastoreAsync(ParseQuery.29.this.val$objectId, user);
/*      */             }
/*      */           });
/*      */         }
/*      */       }), callback);
/*      */     }
/*      */     else
/*      */     {
/* 1407 */       doInBackground(new CallableWithCachePolicy(objectId)
/*      */       {
/*      */         public Task<T> call(ParseQuery.CachePolicy cachePolicy) {
/* 1410 */           return ParseQuery.this.getUserAsync().onSuccessTask(new Continuation(cachePolicy)
/*      */           {
/*      */             public Task<T> then(Task<ParseUser> task) throws Exception {
/* 1413 */               ParseUser user = (ParseUser)task.getResult();
/* 1414 */               ParseQuery.access$1302(ParseQuery.this, System.nanoTime());
/* 1415 */               return ParseQuery.this.getWithCachePolicyAsync(ParseQuery.30.this.val$objectId, this.val$cachePolicy, user);
/*      */             }
/*      */           });
/*      */         }
/*      */       }
/*      */       , callback);
/*      */     }
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereEqualTo(String key, Object value)
/*      */   {
/* 1434 */     checkIfRunning();
/* 1435 */     this.where.put(key, value);
/* 1436 */     return this;
/*      */   }
/*      */ 
/*      */   private ParseQuery<T> addCondition(String key, String condition, Object value)
/*      */   {
/* 1441 */     checkIfRunning();
/*      */ 
/* 1443 */     KeyConstraints whereValue = null;
/*      */ 
/* 1446 */     if (this.where.containsKey(key)) {
/* 1447 */       Object existingValue = this.where.get(key);
/* 1448 */       if ((existingValue instanceof KeyConstraints)) {
/* 1449 */         whereValue = (KeyConstraints)existingValue;
/*      */       }
/*      */     }
/* 1452 */     if (whereValue == null) {
/* 1453 */       whereValue = new KeyConstraints();
/*      */     }
/*      */ 
/* 1456 */     whereValue.put(condition, value);
/*      */ 
/* 1458 */     this.where.put(key, whereValue);
/* 1459 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereLessThan(String key, Object value)
/*      */   {
/* 1473 */     return addCondition(key, "$lt", value);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereNotEqualTo(String key, Object value)
/*      */   {
/* 1487 */     return addCondition(key, "$ne", value);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereGreaterThan(String key, Object value)
/*      */   {
/* 1501 */     return addCondition(key, "$gt", value);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereLessThanOrEqualTo(String key, Object value)
/*      */   {
/* 1515 */     return addCondition(key, "$lte", value);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereGreaterThanOrEqualTo(String key, Object value)
/*      */   {
/* 1529 */     return addCondition(key, "$gte", value);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereContainedIn(String key, Collection<? extends Object> values)
/*      */   {
/* 1543 */     return addCondition(key, "$in", new ArrayList(values));
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereContainsAll(String key, Collection<?> values)
/*      */   {
/* 1561 */     return addCondition(key, "$all", new ArrayList(values));
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereMatchesQuery(String key, ParseQuery<?> query)
/*      */   {
/* 1577 */     return addCondition(key, "$inQuery", query);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereDoesNotMatchQuery(String key, ParseQuery<?> query)
/*      */   {
/* 1593 */     return addCondition(key, "$notInQuery", query);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereMatchesKeyInQuery(String key, String keyInQuery, ParseQuery<?> query)
/*      */   {
/* 1609 */     JSONObject condition = new JSONObject();
/*      */     try {
/* 1611 */       condition.put("key", keyInQuery);
/* 1612 */       condition.put("query", query);
/*      */     } catch (JSONException e) {
/* 1614 */       throw new RuntimeException(e);
/*      */     }
/* 1616 */     return addCondition(key, "$select", condition);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereDoesNotMatchKeyInQuery(String key, String keyInQuery, ParseQuery<?> query)
/*      */   {
/* 1633 */     JSONObject condition = new JSONObject();
/*      */     try {
/* 1635 */       condition.put("key", keyInQuery);
/* 1636 */       condition.put("query", query);
/*      */     } catch (JSONException e) {
/* 1638 */       throw new RuntimeException(e);
/*      */     }
/* 1640 */     return addCondition(key, "$dontSelect", condition);
/*      */   }
/*      */ 
/*      */   private ParseQuery<T> whereSatifiesAnyOf(List<ParseQuery<? extends T>> queries)
/*      */   {
/* 1654 */     ArrayList constraints = new ArrayList();
/* 1655 */     for (ParseQuery query : queries) {
/* 1656 */       if (query.limit >= 0) {
/* 1657 */         throw new IllegalArgumentException("Cannot have limits in sub queries of an 'OR' query");
/*      */       }
/* 1659 */       if (query.skip > 0) {
/* 1660 */         throw new IllegalArgumentException("Cannot have skips in sub queries of an 'OR' query");
/*      */       }
/* 1662 */       if (query.order != null) {
/* 1663 */         throw new IllegalArgumentException("Cannot have an order in sub queries of an 'OR' query");
/*      */       }
/* 1665 */       if (!query.include.isEmpty()) {
/* 1666 */         throw new IllegalArgumentException("Cannot have an include in sub queries of an 'OR' query");
/*      */       }
/* 1668 */       if (query.selectedKeys != null) {
/* 1669 */         throw new IllegalArgumentException("Cannot have an selectKeys in sub queries of an 'OR' query");
/*      */       }
/*      */ 
/* 1673 */       constraints.add(query.getConstraints());
/*      */     }
/* 1675 */     this.where.put("$or", constraints);
/* 1676 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereNotContainedIn(String key, Collection<? extends Object> values)
/*      */   {
/* 1690 */     return addCondition(key, "$nin", new ArrayList(values));
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereNear(String key, ParseGeoPoint point)
/*      */   {
/* 1704 */     return addCondition(key, "$nearSphere", point);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereWithinMiles(String key, ParseGeoPoint point, double maxDistance)
/*      */   {
/* 1722 */     return whereWithinRadians(key, point, maxDistance / ParseGeoPoint.EARTH_MEAN_RADIUS_MILE);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereWithinKilometers(String key, ParseGeoPoint point, double maxDistance)
/*      */   {
/* 1740 */     return whereWithinRadians(key, point, maxDistance / ParseGeoPoint.EARTH_MEAN_RADIUS_KM);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereWithinRadians(String key, ParseGeoPoint point, double maxDistance)
/*      */   {
/* 1756 */     addCondition(key, "$nearSphere", point);
/* 1757 */     return addCondition(key, "$maxDistance", Double.valueOf(maxDistance));
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereWithinGeoBox(String key, ParseGeoPoint southwest, ParseGeoPoint northeast)
/*      */   {
/* 1774 */     ArrayList array = new ArrayList();
/* 1775 */     array.add(southwest);
/* 1776 */     array.add(northeast);
/* 1777 */     HashMap dictionary = new HashMap();
/* 1778 */     dictionary.put("$box", array);
/* 1779 */     return addCondition(key, "$within", dictionary);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereMatches(String key, String regex)
/*      */   {
/* 1795 */     return addCondition(key, "$regex", regex);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereMatches(String key, String regex, String modifiers)
/*      */   {
/* 1815 */     addCondition(key, "$regex", regex);
/* 1816 */     if (modifiers.length() != 0) {
/* 1817 */       addCondition(key, "$options", modifiers);
/*      */     }
/* 1819 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereContains(String key, String substring)
/*      */   {
/* 1834 */     String regex = Pattern.quote(substring);
/* 1835 */     whereMatches(key, regex);
/* 1836 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereStartsWith(String key, String prefix)
/*      */   {
/* 1851 */     String regex = "^" + Pattern.quote(prefix);
/* 1852 */     whereMatches(key, regex);
/* 1853 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereEndsWith(String key, String suffix)
/*      */   {
/* 1868 */     String regex = Pattern.quote(suffix) + "$";
/* 1869 */     whereMatches(key, regex);
/* 1870 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> include(String key)
/*      */   {
/* 1883 */     checkIfRunning();
/*      */ 
/* 1885 */     this.include.add(key);
/* 1886 */     return this;
/*      */   }
/*      */ 
/*      */   List<String> getIncludes()
/*      */   {
/* 1893 */     return Collections.unmodifiableList(this.include);
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> selectKeys(Collection<String> keys)
/*      */   {
/* 1911 */     checkIfRunning();
/*      */ 
/* 1913 */     if (this.selectedKeys == null) {
/* 1914 */       this.selectedKeys = new ArrayList();
/*      */     }
/* 1916 */     this.selectedKeys.addAll(keys);
/* 1917 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereExists(String key)
/*      */   {
/* 1929 */     return addCondition(key, "$exists", Boolean.valueOf(true));
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> whereDoesNotExist(String key)
/*      */   {
/* 1941 */     return addCondition(key, "$exists", Boolean.valueOf(false));
/*      */   }
/*      */ 
/*      */   ParseQuery<T> whereRelatedTo(ParseObject parent, String key) {
/* 1945 */     this.where.put("$relatedTo", new RelationConstraint(key, parent));
/* 1946 */     return this;
/*      */   }
/*      */ 
/*      */   ParseQuery<T> redirectClassNameForKey(String key) {
/* 1950 */     this.extraOptions.put("redirectClassNameForKey", key);
/* 1951 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> orderByAscending(String key)
/*      */   {
/* 1962 */     checkIfRunning();
/*      */ 
/* 1964 */     this.order = key;
/* 1965 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> addAscendingOrder(String key)
/*      */   {
/* 1978 */     checkIfRunning();
/*      */ 
/* 1980 */     if (this.order == null)
/* 1981 */       this.order = key;
/*      */     else {
/* 1983 */       this.order = (this.order + "," + key);
/*      */     }
/* 1985 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> orderByDescending(String key)
/*      */   {
/* 1996 */     checkIfRunning();
/*      */ 
/* 1998 */     this.order = ("-" + key);
/* 1999 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> addDescendingOrder(String key)
/*      */   {
/* 2012 */     checkIfRunning();
/*      */ 
/* 2014 */     if (this.order == null)
/* 2015 */       this.order = ("-" + key);
/*      */     else {
/* 2017 */       this.order = (this.order + ",-" + key);
/*      */     }
/* 2019 */     return this;
/*      */   }
/*      */ 
/*      */   String[] sortKeys()
/*      */   {
/* 2026 */     if (this.order == null) {
/* 2027 */       return new String[0];
/*      */     }
/* 2029 */     return this.order.split(",");
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> setLimit(int newLimit)
/*      */   {
/* 2042 */     checkIfRunning();
/*      */ 
/* 2044 */     this.limit = newLimit;
/* 2045 */     return this;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> setTrace(boolean shouldTrace)
/*      */   {
/* 2056 */     checkIfRunning();
/*      */ 
/* 2058 */     this.trace = shouldTrace;
/* 2059 */     return this;
/*      */   }
/*      */ 
/*      */   public int getLimit()
/*      */   {
/* 2066 */     return this.limit;
/*      */   }
/*      */ 
/*      */   public ParseQuery<T> setSkip(int newSkip)
/*      */   {
/* 2078 */     checkIfRunning();
/*      */ 
/* 2080 */     this.skip = newSkip;
/* 2081 */     return this;
/*      */   }
/*      */ 
/*      */   public int getSkip()
/*      */   {
/* 2088 */     return this.skip;
/*      */   }
/*      */ 
/*      */   public String getClassName()
/*      */   {
/* 2095 */     return this.className;
/*      */   }
/*      */ 
/*      */   private static abstract interface CommandDelegate<T>
/*      */   {
/*      */     public abstract Task<T> runOnNetworkAsync(boolean paramBoolean);
/*      */ 
/*      */     public abstract Task<T> runFromCacheAsync();
/*      */   }
/*      */ 
/*      */   private static abstract interface CallableWithCachePolicy<TResult>
/*      */   {
/*      */     public abstract TResult call(ParseQuery.CachePolicy paramCachePolicy);
/*      */   }
/*      */ 
/*      */   public static enum CachePolicy
/*      */   {
/*  241 */     IGNORE_CACHE, 
/*      */ 
/*  248 */     CACHE_ONLY, 
/*      */ 
/*  253 */     NETWORK_ONLY, 
/*      */ 
/*  261 */     CACHE_ELSE_NETWORK, 
/*      */ 
/*  269 */     NETWORK_ELSE_CACHE, 
/*      */ 
/*  279 */     CACHE_THEN_NETWORK;
/*      */   }
/*      */ 
/*      */   static class RelationConstraint
/*      */   {
/*      */     private String key;
/*      */     private ParseObject object;
/*      */ 
/*      */     public RelationConstraint(String key, ParseObject object)
/*      */     {
/*  107 */       if ((key == null) || (object == null)) {
/*  108 */         throw new IllegalArgumentException("Arguments must not be null.");
/*      */       }
/*  110 */       this.key = key;
/*  111 */       this.object = object;
/*      */     }
/*      */ 
/*      */     public String getKey() {
/*  115 */       return this.key;
/*      */     }
/*      */ 
/*      */     public ParseObject getObject() {
/*  119 */       return this.object;
/*      */     }
/*      */ 
/*      */     public ParseRelation<ParseObject> getRelation() {
/*  123 */       return this.object.getRelation(this.key);
/*      */     }
/*      */ 
/*      */     public JSONObject encode(ParseObjectEncodingStrategy objectEncoder)
/*      */     {
/*  130 */       JSONObject json = new JSONObject();
/*      */       try {
/*  132 */         json.put("key", this.key);
/*  133 */         json.put("object", objectEncoder.encodeRelatedObject(this.object));
/*      */       }
/*      */       catch (JSONException e) {
/*  136 */         throw new RuntimeException(e);
/*      */       }
/*  138 */       return json;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class KeyConstraints extends HashMap<String, Object>
/*      */   {
/*      */   }
/*      */ 
/*      */   static class QueryConstraints extends HashMap<String, Object>
/*      */   {
/*      */   }
/*      */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseQuery
 * JD-Core Version:    0.6.0
 */