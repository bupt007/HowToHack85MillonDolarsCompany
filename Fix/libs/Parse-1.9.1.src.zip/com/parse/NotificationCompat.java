/*     */ package com.parse;
/*     */ 
/*     */ import android.annotation.TargetApi;
/*     */ import android.app.Notification;
/*     */ import android.app.Notification.BigTextStyle;
/*     */ import android.app.Notification.Builder;
/*     */ import android.app.PendingIntent;
/*     */ import android.content.Context;
/*     */ import android.graphics.Bitmap;
/*     */ import android.os.Build.VERSION;
/*     */ 
/*     */ class NotificationCompat
/*     */ {
/*     */ 
/*     */   /** @deprecated */
/*     */   public static final int FLAG_HIGH_PRIORITY = 128;
/*     */   public static final int PRIORITY_DEFAULT = 0;
/*     */   private static final NotificationCompatImpl IMPL;
/*     */ 
/*     */   static
/*     */   {
/*  84 */     if (Build.VERSION.SDK_INT >= 16)
/*  85 */       IMPL = new NotificationCompatPostJellyBean();
/*     */     else
/*  87 */       IMPL = new NotificationCompatImplBase();
/*     */   }
/*     */ 
/*     */   public static class Builder
/*     */   {
/*     */     private static final int MAX_CHARSEQUENCE_LENGTH = 5120;
/*     */     Context mContext;
/*     */     CharSequence mContentTitle;
/*     */     CharSequence mContentText;
/*     */     PendingIntent mContentIntent;
/*     */     Bitmap mLargeIcon;
/*     */     int mPriority;
/*     */     Style mStyle;
/* 109 */     Notification mNotification = new Notification();
/*     */ 
/*     */     public Builder(Context context)
/*     */     {
/* 123 */       this.mContext = context;
/*     */ 
/* 126 */       this.mNotification.when = System.currentTimeMillis();
/* 127 */       this.mNotification.audioStreamType = -1;
/* 128 */       this.mPriority = 0;
/*     */     }
/*     */ 
/*     */     public Builder setWhen(long when) {
/* 132 */       this.mNotification.when = when;
/* 133 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setSmallIcon(int icon)
/*     */     {
/* 144 */       this.mNotification.icon = icon;
/* 145 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setSmallIcon(int icon, int level)
/*     */     {
/* 159 */       this.mNotification.icon = icon;
/* 160 */       this.mNotification.iconLevel = level;
/* 161 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setContentTitle(CharSequence title)
/*     */     {
/* 168 */       this.mContentTitle = limitCharSequenceLength(title);
/* 169 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setContentText(CharSequence text)
/*     */     {
/* 176 */       this.mContentText = limitCharSequenceLength(text);
/* 177 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setContentIntent(PendingIntent intent)
/*     */     {
/* 189 */       this.mContentIntent = intent;
/* 190 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setDeleteIntent(PendingIntent intent)
/*     */     {
/* 201 */       this.mNotification.deleteIntent = intent;
/* 202 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setTicker(CharSequence tickerText)
/*     */     {
/* 210 */       this.mNotification.tickerText = limitCharSequenceLength(tickerText);
/* 211 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setLargeIcon(Bitmap icon)
/*     */     {
/* 218 */       this.mLargeIcon = icon;
/* 219 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setAutoCancel(boolean autoCancel)
/*     */     {
/* 229 */       setFlag(16, autoCancel);
/* 230 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setDefaults(int defaults)
/*     */     {
/* 244 */       this.mNotification.defaults = defaults;
/* 245 */       if ((defaults & 0x4) != 0) {
/* 246 */         this.mNotification.flags |= 1;
/*     */       }
/* 248 */       return this;
/*     */     }
/*     */ 
/*     */     private void setFlag(int mask, boolean value) {
/* 252 */       if (value)
/* 253 */         this.mNotification.flags |= mask;
/*     */       else
/* 255 */         this.mNotification.flags &= (mask ^ 0xFFFFFFFF);
/*     */     }
/*     */ 
/*     */     public Builder setPriority(int pri)
/*     */     {
/* 271 */       this.mPriority = pri;
/* 272 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setStyle(Style style)
/*     */     {
/* 284 */       if (this.mStyle != style) {
/* 285 */         this.mStyle = style;
/* 286 */         if (this.mStyle != null) {
/* 287 */           this.mStyle.setBuilder(this);
/*     */         }
/*     */       }
/* 290 */       return this;
/*     */     }
/*     */ 
/*     */     @Deprecated
/*     */     public Notification getNotification()
/*     */     {
/* 298 */       return NotificationCompat.IMPL.build(this);
/*     */     }
/*     */ 
/*     */     public Notification build()
/*     */     {
/* 306 */       return NotificationCompat.IMPL.build(this);
/*     */     }
/*     */ 
/*     */     protected static CharSequence limitCharSequenceLength(CharSequence cs) {
/* 310 */       if (cs == null) return cs;
/* 311 */       if (cs.length() > 5120) {
/* 312 */         cs = cs.subSequence(0, 5120);
/*     */       }
/* 314 */       return cs;
/*     */     }
/*     */ 
/*     */     public static class BigTextStyle extends NotificationCompat.Builder.Style
/*     */     {
/*     */       CharSequence mBigText;
/*     */ 
/*     */       public BigTextStyle()
/*     */       {
/*     */       }
/*     */ 
/*     */       public BigTextStyle(NotificationCompat.Builder builder)
/*     */       {
/* 377 */         setBuilder(builder);
/*     */       }
/*     */ 
/*     */       public BigTextStyle setBigContentTitle(CharSequence title)
/*     */       {
/* 385 */         this.mBigContentTitle = title;
/* 386 */         return this;
/*     */       }
/*     */ 
/*     */       public BigTextStyle setSummaryText(CharSequence cs)
/*     */       {
/* 393 */         this.mSummaryText = cs;
/* 394 */         this.mSummaryTextSet = true;
/* 395 */         return this;
/*     */       }
/*     */ 
/*     */       public BigTextStyle bigText(CharSequence cs)
/*     */       {
/* 403 */         this.mBigText = cs;
/* 404 */         return this;
/*     */       }
/*     */     }
/*     */ 
/*     */     public static abstract class Style
/*     */     {
/*     */       NotificationCompat.Builder mBuilder;
/*     */       CharSequence mBigContentTitle;
/*     */       CharSequence mSummaryText;
/* 329 */       boolean mSummaryTextSet = false;
/*     */ 
/*     */       public void setBuilder(NotificationCompat.Builder builder) {
/* 332 */         if (this.mBuilder != builder) {
/* 333 */           this.mBuilder = builder;
/* 334 */           if (this.mBuilder != null)
/* 335 */             this.mBuilder.setStyle(this);
/*     */         }
/*     */       }
/*     */ 
/*     */       public Notification build()
/*     */       {
/* 341 */         Notification notification = null;
/* 342 */         if (this.mBuilder != null) {
/* 343 */           notification = this.mBuilder.build();
/*     */         }
/* 345 */         return notification;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   @TargetApi(16)
/*     */   static class NotificationCompatPostJellyBean
/*     */     implements NotificationCompat.NotificationCompatImpl
/*     */   {
/*     */     private Notification.Builder postJellyBeanBuilder;
/*     */ 
/*     */     public Notification build(NotificationCompat.Builder b)
/*     */     {
/*  58 */       this.postJellyBeanBuilder = new Notification.Builder(b.mContext);
/*  59 */       this.postJellyBeanBuilder.setContentTitle(b.mContentTitle).setContentText(b.mContentText).setTicker(b.mNotification.tickerText).setSmallIcon(b.mNotification.icon, b.mNotification.iconLevel).setContentIntent(b.mContentIntent).setDeleteIntent(b.mNotification.deleteIntent).setAutoCancel((b.mNotification.flags & 0x10) != 0).setLargeIcon(b.mLargeIcon).setDefaults(b.mNotification.defaults);
/*     */ 
/*  68 */       if ((b.mStyle != null) && 
/*  69 */         ((b.mStyle instanceof NotificationCompat.Builder.BigTextStyle))) {
/*  70 */         NotificationCompat.Builder.BigTextStyle staticStyle = (NotificationCompat.Builder.BigTextStyle)b.mStyle;
/*  71 */         Notification.BigTextStyle style = new Notification.BigTextStyle(this.postJellyBeanBuilder).setBigContentTitle(staticStyle.mBigContentTitle).bigText(staticStyle.mBigText);
/*     */ 
/*  74 */         if (staticStyle.mSummaryTextSet) {
/*  75 */           style.setSummaryText(staticStyle.mSummaryText);
/*     */         }
/*     */       }
/*     */ 
/*  79 */       return this.postJellyBeanBuilder.build();
/*     */     }
/*     */   }
/*     */ 
/*     */   static class NotificationCompatImplBase
/*     */     implements NotificationCompat.NotificationCompatImpl
/*     */   {
/*     */     public Notification build(NotificationCompat.Builder b)
/*     */     {
/*  43 */       Notification result = b.mNotification;
/*  44 */       result.setLatestEventInfo(b.mContext, b.mContentTitle, b.mContentText, b.mContentIntent);
/*     */ 
/*  46 */       if (b.mPriority > 0) {
/*  47 */         result.flags |= 128;
/*     */       }
/*  49 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface NotificationCompatImpl
/*     */   {
/*     */     public abstract Notification build(NotificationCompat.Builder paramBuilder);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.NotificationCompat
 * JD-Core Version:    0.6.0
 */