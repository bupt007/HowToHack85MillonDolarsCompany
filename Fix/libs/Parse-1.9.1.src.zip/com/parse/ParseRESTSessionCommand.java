/*    */ package com.parse;
/*    */ 
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseRESTSessionCommand extends ParseRESTCommand
/*    */ {
/*    */   public static ParseRESTSessionCommand getCurrentSessionCommand(String sessionToken)
/*    */   {
/*  8 */     return new ParseRESTSessionCommand("sessions/me", ParseRequest.Method.GET, null, sessionToken);
/*    */   }
/*    */ 
/*    */   private ParseRESTSessionCommand(String httpPath, ParseRequest.Method httpMethod, JSONObject jsonParameters, String sessionToken)
/*    */   {
/* 13 */     super(httpPath, httpMethod, jsonParameters, sessionToken);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTSessionCommand
 * JD-Core Version:    0.6.0
 */