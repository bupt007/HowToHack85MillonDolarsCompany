/*     */ package com.parse;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Random;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class LocalIdManager
/*     */ {
/*     */   private static LocalIdManager defaultInstance;
/*     */   private File diskPath;
/*     */   private Random random;
/*     */ 
/*     */   public static synchronized LocalIdManager getDefaultInstance()
/*     */   {
/*  21 */     if (defaultInstance == null) {
/*  22 */       defaultInstance = new LocalIdManager();
/*     */     }
/*  24 */     return defaultInstance;
/*     */   }
/*     */ 
/*     */   private LocalIdManager()
/*     */   {
/*  46 */     File parseDir = Parse.getParseDir();
/*  47 */     this.diskPath = new File(parseDir, "LocalId");
/*  48 */     this.diskPath.mkdirs();
/*     */ 
/*  50 */     this.random = new Random();
/*     */   }
/*     */ 
/*     */   private boolean isLocalId(String localId)
/*     */   {
/*  57 */     if (!localId.startsWith("local_")) {
/*  58 */       return false;
/*     */     }
/*  60 */     for (int i = 6; i < localId.length(); i++) {
/*  61 */       char c = localId.charAt(i);
/*  62 */       if (((c < '0') || (c > '9')) && ((c < 'a') || (c > 'f'))) {
/*  63 */         return false;
/*     */       }
/*     */     }
/*  66 */     return true;
/*     */   }
/*     */ 
/*     */   private synchronized MapEntry getMapEntry(String localId)
/*     */   {
/*  73 */     if (!isLocalId(localId)) {
/*  74 */       throw new IllegalStateException("Tried to get invalid local id: \"" + localId + "\".");
/*     */     }
/*     */ 
/*  77 */     JSONObject json = Parse.getDiskObject(new File(this.diskPath, localId));
/*  78 */     if (json == null) {
/*  79 */       return new MapEntry(null);
/*     */     }
/*     */ 
/*  82 */     MapEntry entry = new MapEntry(null);
/*  83 */     entry.retainCount = json.optInt("retainCount", 0);
/*  84 */     entry.objectId = json.optString("objectId", null);
/*  85 */     return entry;
/*     */   }
/*     */ 
/*     */   private synchronized void putMapEntry(String localId, MapEntry entry)
/*     */   {
/*  92 */     if (!isLocalId(localId)) {
/*  93 */       throw new IllegalStateException("Tried to get invalid local id: \"" + localId + "\".");
/*     */     }
/*     */ 
/*  96 */     JSONObject json = new JSONObject();
/*     */     try {
/*  98 */       json.put("retainCount", entry.retainCount);
/*  99 */       if (entry.objectId != null)
/* 100 */         json.put("objectId", entry.objectId);
/*     */     }
/*     */     catch (JSONException je) {
/* 103 */       throw new IllegalStateException("Error creating local id map entry.", je);
/*     */     }
/*     */ 
/* 106 */     File file = new File(this.diskPath, localId);
/* 107 */     if (!this.diskPath.exists()) {
/* 108 */       this.diskPath.mkdirs();
/*     */     }
/*     */ 
/* 111 */     Parse.saveDiskObject(file, json);
/*     */   }
/*     */ 
/*     */   private synchronized void removeMapEntry(String localId)
/*     */   {
/* 118 */     if (!isLocalId(localId)) {
/* 119 */       throw new IllegalStateException("Tried to get invalid local id: \"" + localId + "\".");
/*     */     }
/* 121 */     File file = new File(this.diskPath, localId);
/* 122 */     file.delete();
/*     */   }
/*     */ 
/*     */   synchronized String createLocalId()
/*     */   {
/* 129 */     long localIdNumber = this.random.nextLong();
/* 130 */     String localId = "local_" + Long.toHexString(localIdNumber);
/*     */ 
/* 132 */     if (!isLocalId(localId)) {
/* 133 */       throw new IllegalStateException("Generated an invalid local id: \"" + localId + "\". " + "This should never happen. Contact us at https://parse.com/help");
/*     */     }
/*     */ 
/* 137 */     return localId;
/*     */   }
/*     */ 
/*     */   synchronized void retainLocalIdOnDisk(String localId)
/*     */   {
/* 144 */     MapEntry entry = getMapEntry(localId);
/* 145 */     entry.retainCount += 1;
/* 146 */     putMapEntry(localId, entry);
/*     */   }
/*     */ 
/*     */   synchronized void releaseLocalIdOnDisk(String localId)
/*     */   {
/* 154 */     MapEntry entry = getMapEntry(localId);
/* 155 */     entry.retainCount -= 1;
/*     */ 
/* 157 */     if (entry.retainCount > 0)
/* 158 */       putMapEntry(localId, entry);
/*     */     else
/* 160 */       removeMapEntry(localId);
/*     */   }
/*     */ 
/*     */   synchronized String getObjectId(String localId)
/*     */   {
/* 169 */     MapEntry entry = getMapEntry(localId);
/* 170 */     return entry.objectId;
/*     */   }
/*     */ 
/*     */   synchronized void setObjectId(String localId, String objectId)
/*     */   {
/* 177 */     MapEntry entry = getMapEntry(localId);
/* 178 */     if (entry.retainCount > 0) {
/* 179 */       if (entry.objectId != null) {
/* 180 */         throw new IllegalStateException("Tried to set an objectId for a localId that already has one.");
/*     */       }
/*     */ 
/* 183 */       entry.objectId = objectId;
/* 184 */       putMapEntry(localId, entry);
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized boolean clear()
/*     */     throws IOException
/*     */   {
/* 192 */     String[] files = this.diskPath.list();
/* 193 */     if (files == null) {
/* 194 */       return false;
/*     */     }
/* 196 */     if (files.length == 0) {
/* 197 */       return false;
/*     */     }
/* 199 */     for (String fileName : files) {
/* 200 */       File file = new File(this.diskPath, fileName);
/* 201 */       if (!file.delete()) {
/* 202 */         throw new IOException("Unable to delete file " + fileName + " in localId cache.");
/*     */       }
/*     */     }
/* 205 */     return true;
/*     */   }
/*     */ 
/*     */   private class MapEntry
/*     */   {
/*     */     String objectId;
/*     */     int retainCount;
/*     */ 
/*     */     private MapEntry()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.LocalIdManager
 * JD-Core Version:    0.6.0
 */