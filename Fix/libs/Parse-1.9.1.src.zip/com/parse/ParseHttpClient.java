/*    */ package com.parse;
/*    */ 
/*    */ import android.content.Context;
/*    */ import java.io.IOException;
/*    */ import org.apache.http.client.methods.HttpUriRequest;
/*    */ 
/*    */ abstract class ParseHttpClient
/*    */ {
/*    */   public abstract ParseHttpResponse execute(HttpUriRequest paramHttpUriRequest)
/*    */     throws IOException;
/*    */ 
/*    */   public static ParseHttpClient create(Context context)
/*    */   {
/* 19 */     return new ParseApacheHttpClient(context);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseHttpClient
 * JD-Core Version:    0.6.0
 */