/*    */ package com.parse;
/*    */ 
/*    */ import bolts.Task;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.json.JSONArray;
/*    */ import org.json.JSONException;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ class ParseRESTObjectBatchCommand extends ParseRESTCommand
/*    */ {
/*    */   public static final int COMMAND_OBJECT_BATCH_MAX_SIZE = 50;
/*    */ 
/*    */   public ParseRESTObjectBatchCommand(String httpPath, ParseRequest.Method httpMethod, Map<String, ?> parameters, String sessionToken)
/*    */   {
/* 21 */     super(httpPath, httpMethod, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   public static List<ParseRESTObjectBatchCommand> batchCommands(List<ParseRESTObjectCommand> commands, String sessionToken)
/*    */   {
/* 26 */     List batches = Parse.partitionList(commands, 50);
/*    */ 
/* 28 */     List batchCommands = new ArrayList();
/* 29 */     for (List batch : batches) {
/* 30 */       ParseRESTObjectBatchCommand multiCommand = batchCommand(batch, sessionToken);
/* 31 */       batchCommands.add(multiCommand);
/*    */     }
/* 33 */     return batchCommands;
/*    */   }
/*    */ 
/*    */   public static ParseRESTObjectBatchCommand batchCommand(List<ParseRESTObjectCommand> commands, String sessionToken)
/*    */   {
/* 38 */     List requests = new ArrayList();
/*    */     try {
/* 40 */       for (ParseRESTObjectCommand command : commands) {
/* 41 */         JSONObject requestParameters = new JSONObject();
/* 42 */         requestParameters.put("method", command.method.toString());
/* 43 */         requestParameters.put("path", String.format("/1/%s", new Object[] { command.httpPath }));
/* 44 */         JSONObject body = command.jsonParameters;
/* 45 */         if (body != null) {
/* 46 */           requestParameters.put("body", body);
/*    */         }
/* 48 */         requests.add(requestParameters);
/*    */       }
/*    */     } catch (JSONException e) {
/* 51 */       throw new RuntimeException(e);
/*    */     }
/*    */ 
/* 54 */     Map parameters = new HashMap();
/* 55 */     parameters.put("requests", requests);
/* 56 */     return new ParseRESTObjectBatchCommand("batch", ParseRequest.Method.POST, parameters, sessionToken);
/*    */   }
/*    */ 
/*    */   protected Task<JSONObject> onResponse(ParseHttpResponse response, ProgressCallback downloadProgressCallback)
/*    */   {
/* 62 */     InputStream responseStream = null;
/* 63 */     String content = null;
/*    */     try {
/* 65 */       responseStream = response.getContent();
/* 66 */       content = new String(ParseIOUtils.toByteArray(responseStream));
/*    */     } catch (IOException e) {
/* 68 */       Task localTask = Task.forError(e);
/*    */       return localTask; } finally { ParseIOUtils.closeQuietly(responseStream); }
/*    */     JSONObject json;
/*    */     try
/*    */     {
/* 75 */       JSONArray results = new JSONArray(content);
/* 76 */       json = new JSONObject();
/* 77 */       json.put("results", results);
/*    */     } catch (JSONException e) {
/* 79 */       return Task.forError(newTemporaryException("bad json response", e));
/*    */     }
/*    */ 
/* 82 */     return Task.forResult(json);
/*    */   }
/*    */ 
/*    */   protected Task<Object> onPostExecute(Task<JSONObject> task) {
/* 89 */     JSONObject json = (JSONObject)task.getResult();
/*    */     Object results;
/*    */     try {
/* 93 */       results = json.getJSONArray("results");
/*    */     } catch (JSONException e) {
/* 95 */       return Task.forError(newTemporaryException("corrupted json", e));
/*    */     }
/* 97 */     return Task.forResult(results);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParseRESTObjectBatchCommand
 * JD-Core Version:    0.6.0
 */