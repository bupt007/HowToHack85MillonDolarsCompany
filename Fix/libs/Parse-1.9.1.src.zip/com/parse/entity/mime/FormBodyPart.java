/*     */ package com.parse.entity.mime;
/*     */ 
/*     */ import com.parse.entity.mime.content.ContentBody;
/*     */ 
/*     */ public class FormBodyPart
/*     */ {
/*     */   private final String name;
/*     */   private final Header header;
/*     */   private final ContentBody body;
/*     */ 
/*     */   public FormBodyPart(String name, ContentBody body)
/*     */   {
/*  49 */     if (name == null) {
/*  50 */       throw new IllegalArgumentException("Name may not be null");
/*     */     }
/*  52 */     if (body == null) {
/*  53 */       throw new IllegalArgumentException("Body may not be null");
/*     */     }
/*  55 */     this.name = name;
/*  56 */     this.body = body;
/*  57 */     this.header = new Header();
/*     */ 
/*  59 */     generateContentDisp(body);
/*  60 */     generateContentType(body);
/*  61 */     generateTransferEncoding(body);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  65 */     return this.name;
/*     */   }
/*     */ 
/*     */   public ContentBody getBody() {
/*  69 */     return this.body;
/*     */   }
/*     */ 
/*     */   public Header getHeader() {
/*  73 */     return this.header;
/*     */   }
/*     */ 
/*     */   public void addField(String name, String value) {
/*  77 */     if (name == null) {
/*  78 */       throw new IllegalArgumentException("Field name may not be null");
/*     */     }
/*  80 */     this.header.addField(new MinimalField(name, value));
/*     */   }
/*     */ 
/*     */   protected void generateContentDisp(ContentBody body) {
/*  84 */     StringBuilder buffer = new StringBuilder();
/*  85 */     buffer.append("form-data; name=\"");
/*  86 */     buffer.append(getName());
/*  87 */     buffer.append("\"");
/*  88 */     if (body.getFilename() != null) {
/*  89 */       buffer.append("; filename=\"");
/*  90 */       buffer.append(body.getFilename());
/*  91 */       buffer.append("\"");
/*     */     }
/*  93 */     addField("Content-Disposition", buffer.toString());
/*     */   }
/*     */ 
/*     */   protected void generateContentType(ContentBody body) {
/*  97 */     StringBuilder buffer = new StringBuilder();
/*  98 */     buffer.append(body.getMimeType());
/*  99 */     if (body.getCharset() != null) {
/* 100 */       buffer.append("; charset=");
/* 101 */       buffer.append(body.getCharset());
/*     */     }
/* 103 */     addField("Content-Type", buffer.toString());
/*     */   }
/*     */ 
/*     */   protected void generateTransferEncoding(ContentBody body) {
/* 107 */     addField("Content-Transfer-Encoding", body.getTransferEncoding());
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.entity.mime.FormBodyPart
 * JD-Core Version:    0.6.0
 */