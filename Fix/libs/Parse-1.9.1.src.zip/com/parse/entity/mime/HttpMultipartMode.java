/*    */ package com.parse.entity.mime;
/*    */ 
/*    */ public enum HttpMultipartMode
/*    */ {
/* 38 */   STRICT, 
/*    */ 
/* 40 */   BROWSER_COMPATIBLE;
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.entity.mime.HttpMultipartMode
 * JD-Core Version:    0.6.0
 */