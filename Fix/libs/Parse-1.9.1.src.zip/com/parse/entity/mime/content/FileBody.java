/*     */ package com.parse.entity.mime.content;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class FileBody extends AbstractContentBody
/*     */ {
/*     */   private final File file;
/*     */   private final String filename;
/*     */   private final String charset;
/*     */ 
/*     */   public FileBody(File file, String filename, String mimeType, String charset)
/*     */   {
/*  52 */     super(mimeType);
/*  53 */     if (file == null) {
/*  54 */       throw new IllegalArgumentException("File may not be null");
/*     */     }
/*  56 */     this.file = file;
/*  57 */     if (filename != null)
/*  58 */       this.filename = filename;
/*     */     else
/*  60 */       this.filename = file.getName();
/*  61 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   public FileBody(File file, String mimeType, String charset)
/*     */   {
/*  70 */     this(file, null, mimeType, charset);
/*     */   }
/*     */ 
/*     */   public FileBody(File file, String mimeType) {
/*  74 */     this(file, mimeType, null);
/*     */   }
/*     */ 
/*     */   public FileBody(File file) {
/*  78 */     this(file, "application/octet-stream");
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream() throws IOException {
/*  82 */     return new FileInputStream(this.file);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void writeTo(OutputStream out, int mode)
/*     */     throws IOException
/*     */   {
/*  90 */     writeTo(out);
/*     */   }
/*     */ 
/*     */   public void writeTo(OutputStream out) throws IOException {
/*  94 */     if (out == null) {
/*  95 */       throw new IllegalArgumentException("Output stream may not be null");
/*     */     }
/*  97 */     InputStream in = new FileInputStream(this.file);
/*     */     try {
/*  99 */       byte[] tmp = new byte[4096];
/*     */       int l;
/* 101 */       while ((l = in.read(tmp)) != -1) {
/* 102 */         out.write(tmp, 0, l);
/*     */       }
/* 104 */       out.flush();
/*     */     } finally {
/* 106 */       in.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getTransferEncoding() {
/* 111 */     return "binary";
/*     */   }
/*     */ 
/*     */   public String getCharset() {
/* 115 */     return this.charset;
/*     */   }
/*     */ 
/*     */   public long getContentLength() {
/* 119 */     return this.file.length();
/*     */   }
/*     */ 
/*     */   public String getFilename() {
/* 123 */     return this.filename;
/*     */   }
/*     */ 
/*     */   public File getFile() {
/* 127 */     return this.file;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.entity.mime.content.FileBody
 * JD-Core Version:    0.6.0
 */