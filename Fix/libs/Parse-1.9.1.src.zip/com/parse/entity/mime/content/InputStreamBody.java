/*    */ package com.parse.entity.mime.content;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class InputStreamBody extends AbstractContentBody
/*    */ {
/*    */   private final InputStream in;
/*    */   private final String filename;
/*    */ 
/*    */   public InputStreamBody(InputStream in, String mimeType, String filename)
/*    */   {
/* 43 */     super(mimeType);
/* 44 */     if (in == null) {
/* 45 */       throw new IllegalArgumentException("Input stream may not be null");
/*    */     }
/* 47 */     this.in = in;
/* 48 */     this.filename = filename;
/*    */   }
/*    */ 
/*    */   public InputStreamBody(InputStream in, String filename) {
/* 52 */     this(in, "application/octet-stream", filename);
/*    */   }
/*    */ 
/*    */   public InputStream getInputStream() {
/* 56 */     return this.in;
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   public void writeTo(OutputStream out, int mode)
/*    */     throws IOException
/*    */   {
/* 64 */     writeTo(out);
/*    */   }
/*    */ 
/*    */   public void writeTo(OutputStream out) throws IOException {
/* 68 */     if (out == null)
/* 69 */       throw new IllegalArgumentException("Output stream may not be null");
/*    */     try
/*    */     {
/* 72 */       byte[] tmp = new byte[4096];
/*    */       int l;
/* 74 */       while ((l = this.in.read(tmp)) != -1) {
/* 75 */         out.write(tmp, 0, l);
/*    */       }
/* 77 */       out.flush();
/*    */     } finally {
/* 79 */       this.in.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getTransferEncoding() {
/* 84 */     return "binary";
/*    */   }
/*    */ 
/*    */   public String getCharset() {
/* 88 */     return null;
/*    */   }
/*    */ 
/*    */   public long getContentLength() {
/* 92 */     return -1L;
/*    */   }
/*    */ 
/*    */   public String getFilename() {
/* 96 */     return this.filename;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.entity.mime.content.InputStreamBody
 * JD-Core Version:    0.6.0
 */