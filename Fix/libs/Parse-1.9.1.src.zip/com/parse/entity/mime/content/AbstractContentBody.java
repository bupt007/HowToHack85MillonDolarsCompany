/*    */ package com.parse.entity.mime.content;
/*    */ 
/*    */ public abstract class AbstractContentBody
/*    */   implements ContentBody
/*    */ {
/*    */   private final String mimeType;
/*    */   private final String mediaType;
/*    */   private final String subType;
/*    */ 
/*    */   public AbstractContentBody(String mimeType)
/*    */   {
/* 43 */     if (mimeType == null) {
/* 44 */       throw new IllegalArgumentException("MIME type may not be null");
/*    */     }
/* 46 */     this.mimeType = mimeType;
/* 47 */     int i = mimeType.indexOf('/');
/* 48 */     if (i != -1) {
/* 49 */       this.mediaType = mimeType.substring(0, i);
/* 50 */       this.subType = mimeType.substring(i + 1);
/*    */     } else {
/* 52 */       this.mediaType = mimeType;
/* 53 */       this.subType = null;
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getMimeType() {
/* 58 */     return this.mimeType;
/*    */   }
/*    */ 
/*    */   public String getMediaType() {
/* 62 */     return this.mediaType;
/*    */   }
/*    */ 
/*    */   public String getSubType() {
/* 66 */     return this.subType;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.entity.mime.content.AbstractContentBody
 * JD-Core Version:    0.6.0
 */