/*    */ package com.parse.entity.mime.content;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class ByteArrayBody extends AbstractContentBody
/*    */ {
/*    */   private final byte[] data;
/*    */   private final String filename;
/*    */ 
/*    */   public ByteArrayBody(byte[] data, String mimeType, String filename)
/*    */   {
/* 64 */     super(mimeType);
/* 65 */     if (data == null) {
/* 66 */       throw new IllegalArgumentException("byte[] may not be null");
/*    */     }
/* 68 */     this.data = data;
/* 69 */     this.filename = filename;
/*    */   }
/*    */ 
/*    */   public ByteArrayBody(byte[] data, String filename)
/*    */   {
/* 79 */     this(data, "application/octet-stream", filename);
/*    */   }
/*    */ 
/*    */   public String getFilename() {
/* 83 */     return this.filename;
/*    */   }
/*    */ 
/*    */   public void writeTo(OutputStream out) throws IOException {
/* 87 */     out.write(this.data);
/*    */   }
/*    */ 
/*    */   public String getCharset() {
/* 91 */     return null;
/*    */   }
/*    */ 
/*    */   public String getTransferEncoding() {
/* 95 */     return "binary";
/*    */   }
/*    */ 
/*    */   public long getContentLength() {
/* 99 */     return this.data.length;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.entity.mime.content.ByteArrayBody
 * JD-Core Version:    0.6.0
 */