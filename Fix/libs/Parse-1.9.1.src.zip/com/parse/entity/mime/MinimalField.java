/*    */ package com.parse.entity.mime;
/*    */ 
/*    */ public class MinimalField
/*    */ {
/*    */   private final String name;
/*    */   private final String value;
/*    */ 
/*    */   MinimalField(String name, String value)
/*    */   {
/* 43 */     this.name = name;
/* 44 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 48 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String getBody() {
/* 52 */     return this.value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 57 */     StringBuilder buffer = new StringBuilder();
/* 58 */     buffer.append(this.name);
/* 59 */     buffer.append(": ");
/* 60 */     buffer.append(this.value);
/* 61 */     return buffer.toString();
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.entity.mime.MinimalField
 * JD-Core Version:    0.6.0
 */