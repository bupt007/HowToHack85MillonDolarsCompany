/*     */ package com.parse.entity.mime;
/*     */ 
/*     */ import com.parse.entity.mime.content.ContentBody;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Random;
/*     */ import org.apache.http.Header;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.message.BasicHeader;
/*     */ 
/*     */ public class MultipartEntity
/*     */   implements HttpEntity
/*     */ {
/*  54 */   private static final char[] MULTIPART_CHARS = "-_1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
/*     */   private final HttpMultipart multipart;
/*     */   private final Header contentType;
/*     */   private long length;
/*     */   private volatile boolean dirty;
/*     */ 
/*     */   public MultipartEntity(HttpMultipartMode mode, String boundary, Charset charset)
/*     */   {
/*  76 */     if (boundary == null) {
/*  77 */       boundary = generateBoundary();
/*     */     }
/*  79 */     if (mode == null) {
/*  80 */       mode = HttpMultipartMode.STRICT;
/*     */     }
/*  82 */     this.multipart = new HttpMultipart("form-data", charset, boundary, mode);
/*  83 */     this.contentType = new BasicHeader("Content-Type", generateContentType(boundary, charset));
/*     */ 
/*  86 */     this.dirty = true;
/*     */   }
/*     */ 
/*     */   public MultipartEntity(HttpMultipartMode mode)
/*     */   {
/*  95 */     this(mode, null, null);
/*     */   }
/*     */ 
/*     */   public MultipartEntity()
/*     */   {
/* 102 */     this(HttpMultipartMode.STRICT, null, null);
/*     */   }
/*     */ 
/*     */   protected String generateContentType(String boundary, Charset charset)
/*     */   {
/* 108 */     StringBuilder buffer = new StringBuilder();
/* 109 */     buffer.append("multipart/form-data; boundary=");
/* 110 */     buffer.append(boundary);
/* 111 */     if (charset != null) {
/* 112 */       buffer.append("; charset=");
/* 113 */       buffer.append(charset.name());
/*     */     }
/* 115 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   protected String generateBoundary() {
/* 119 */     StringBuilder buffer = new StringBuilder();
/* 120 */     Random rand = new Random();
/* 121 */     int count = rand.nextInt(11) + 30;
/* 122 */     for (int i = 0; i < count; i++) {
/* 123 */       buffer.append(MULTIPART_CHARS[rand.nextInt(MULTIPART_CHARS.length)]);
/*     */     }
/* 125 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public void addPart(FormBodyPart bodyPart) {
/* 129 */     this.multipart.addBodyPart(bodyPart);
/* 130 */     this.dirty = true;
/*     */   }
/*     */ 
/*     */   public void addPart(String name, ContentBody contentBody) {
/* 134 */     addPart(new FormBodyPart(name, contentBody));
/*     */   }
/*     */ 
/*     */   public boolean isRepeatable() {
/* 138 */     for (FormBodyPart part : this.multipart.getBodyParts()) {
/* 139 */       ContentBody body = part.getBody();
/* 140 */       if (body.getContentLength() < 0L) {
/* 141 */         return false;
/*     */       }
/*     */     }
/* 144 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isChunked() {
/* 148 */     return !isRepeatable();
/*     */   }
/*     */ 
/*     */   public boolean isStreaming() {
/* 152 */     return !isRepeatable();
/*     */   }
/*     */ 
/*     */   public long getContentLength() {
/* 156 */     if (this.dirty) {
/* 157 */       this.length = this.multipart.getTotalLength();
/* 158 */       this.dirty = false;
/*     */     }
/* 160 */     return this.length;
/*     */   }
/*     */ 
/*     */   public Header getContentType() {
/* 164 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public Header getContentEncoding() {
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */   public void consumeContent() throws IOException, UnsupportedOperationException
/*     */   {
/* 173 */     if (isStreaming())
/* 174 */       throw new UnsupportedOperationException("Streaming entity does not implement #consumeContent()");
/*     */   }
/*     */ 
/*     */   public InputStream getContent()
/*     */     throws IOException, UnsupportedOperationException
/*     */   {
/* 180 */     throw new UnsupportedOperationException("Multipart form entity does not implement #getContent()");
/*     */   }
/*     */ 
/*     */   public void writeTo(OutputStream outstream) throws IOException
/*     */   {
/* 185 */     this.multipart.writeTo(outstream);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.entity.mime.MultipartEntity
 * JD-Core Version:    0.6.0
 */