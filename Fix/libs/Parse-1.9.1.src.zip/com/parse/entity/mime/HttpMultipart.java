/*     */ package com.parse.entity.mime;
/*     */ 
/*     */ import com.parse.entity.mime.content.ContentBody;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.http.util.ByteArrayBuffer;
/*     */ 
/*     */ public class HttpMultipart
/*     */ {
/*  94 */   private static final ByteArrayBuffer FIELD_SEP = encode(MIME.DEFAULT_CHARSET, ": ");
/*  95 */   private static final ByteArrayBuffer CR_LF = encode(MIME.DEFAULT_CHARSET, "\r\n");
/*  96 */   private static final ByteArrayBuffer TWO_DASHES = encode(MIME.DEFAULT_CHARSET, "--");
/*     */   private final String subType;
/*     */   private final Charset charset;
/*     */   private final String boundary;
/*     */   private final List<FormBodyPart> parts;
/*     */   private final HttpMultipartMode mode;
/*     */ 
/*     */   private static ByteArrayBuffer encode(Charset charset, String string)
/*     */   {
/*  55 */     ByteBuffer encoded = charset.encode(CharBuffer.wrap(string));
/*  56 */     ByteArrayBuffer bab = new ByteArrayBuffer(encoded.remaining());
/*  57 */     bab.append(encoded.array(), encoded.position(), encoded.remaining());
/*  58 */     return bab;
/*     */   }
/*     */ 
/*     */   private static void writeBytes(ByteArrayBuffer b, OutputStream out) throws IOException
/*     */   {
/*  63 */     out.write(b.buffer(), 0, b.length());
/*     */   }
/*     */ 
/*     */   private static void writeBytes(String s, Charset charset, OutputStream out) throws IOException
/*     */   {
/*  68 */     ByteArrayBuffer b = encode(charset, s);
/*  69 */     writeBytes(b, out);
/*     */   }
/*     */ 
/*     */   private static void writeBytes(String s, OutputStream out) throws IOException
/*     */   {
/*  74 */     ByteArrayBuffer b = encode(MIME.DEFAULT_CHARSET, s);
/*  75 */     writeBytes(b, out);
/*     */   }
/*     */ 
/*     */   private static void writeField(MinimalField field, OutputStream out) throws IOException
/*     */   {
/*  80 */     writeBytes(field.getName(), out);
/*  81 */     writeBytes(FIELD_SEP, out);
/*  82 */     writeBytes(field.getBody(), out);
/*  83 */     writeBytes(CR_LF, out);
/*     */   }
/*     */ 
/*     */   private static void writeField(MinimalField field, Charset charset, OutputStream out) throws IOException
/*     */   {
/*  88 */     writeBytes(field.getName(), charset, out);
/*  89 */     writeBytes(FIELD_SEP, out);
/*  90 */     writeBytes(field.getBody(), charset, out);
/*  91 */     writeBytes(CR_LF, out);
/*     */   }
/*     */ 
/*     */   public HttpMultipart(String subType, Charset charset, String boundary, HttpMultipartMode mode)
/*     */   {
/* 117 */     if (subType == null) {
/* 118 */       throw new IllegalArgumentException("Multipart subtype may not be null");
/*     */     }
/* 120 */     if (boundary == null) {
/* 121 */       throw new IllegalArgumentException("Multipart boundary may not be null");
/*     */     }
/* 123 */     this.subType = subType;
/* 124 */     this.charset = (charset != null ? charset : MIME.DEFAULT_CHARSET);
/* 125 */     this.boundary = boundary;
/* 126 */     this.parts = new ArrayList();
/* 127 */     this.mode = mode;
/*     */   }
/*     */ 
/*     */   public HttpMultipart(String subType, Charset charset, String boundary)
/*     */   {
/* 140 */     this(subType, charset, boundary, HttpMultipartMode.STRICT);
/*     */   }
/*     */ 
/*     */   public HttpMultipart(String subType, String boundary) {
/* 144 */     this(subType, null, boundary);
/*     */   }
/*     */ 
/*     */   public String getSubType() {
/* 148 */     return this.subType;
/*     */   }
/*     */ 
/*     */   public Charset getCharset() {
/* 152 */     return this.charset;
/*     */   }
/*     */ 
/*     */   public HttpMultipartMode getMode() {
/* 156 */     return this.mode;
/*     */   }
/*     */ 
/*     */   public List<FormBodyPart> getBodyParts() {
/* 160 */     return this.parts;
/*     */   }
/*     */ 
/*     */   public void addBodyPart(FormBodyPart part) {
/* 164 */     if (part == null) {
/* 165 */       return;
/*     */     }
/* 167 */     this.parts.add(part);
/*     */   }
/*     */ 
/*     */   public String getBoundary() {
/* 171 */     return this.boundary;
/*     */   }
/*     */ 
/*     */   private void doWriteTo(HttpMultipartMode mode, OutputStream out, boolean writeContent)
/*     */     throws IOException
/*     */   {
/* 179 */     ByteArrayBuffer boundary = encode(this.charset, getBoundary());
/* 180 */     for (FormBodyPart part : this.parts) {
/* 181 */       writeBytes(TWO_DASHES, out);
/* 182 */       writeBytes(boundary, out);
/* 183 */       writeBytes(CR_LF, out);
/*     */ 
/* 185 */       Header header = part.getHeader();
/*     */ 
/* 187 */       switch (1.$SwitchMap$com$parse$entity$mime$HttpMultipartMode[mode.ordinal()]) {
/*     */       case 1:
/* 189 */         for (MinimalField field : header) {
/* 190 */           writeField(field, out);
/*     */         }
/* 192 */         break;
/*     */       case 2:
/* 196 */         MinimalField cd = part.getHeader().getField("Content-Disposition");
/* 197 */         writeField(cd, this.charset, out);
/* 198 */         String filename = part.getBody().getFilename();
/* 199 */         if (filename == null) break;
/* 200 */         MinimalField ct = part.getHeader().getField("Content-Type");
/* 201 */         writeField(ct, this.charset, out);
/*     */       }
/*     */ 
/* 205 */       writeBytes(CR_LF, out);
/*     */ 
/* 207 */       if (writeContent) {
/* 208 */         part.getBody().writeTo(out);
/*     */       }
/* 210 */       writeBytes(CR_LF, out);
/*     */     }
/* 212 */     writeBytes(TWO_DASHES, out);
/* 213 */     writeBytes(boundary, out);
/* 214 */     writeBytes(TWO_DASHES, out);
/* 215 */     writeBytes(CR_LF, out);
/*     */   }
/*     */ 
/*     */   public void writeTo(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 226 */     doWriteTo(this.mode, out, true);
/*     */   }
/*     */ 
/*     */   public long getTotalLength()
/*     */   {
/* 243 */     long contentLen = 0L;
/* 244 */     for (FormBodyPart part : this.parts) {
/* 245 */       ContentBody body = part.getBody();
/* 246 */       long len = body.getContentLength();
/* 247 */       if (len >= 0L)
/* 248 */         contentLen += len;
/*     */       else {
/* 250 */         return -1L;
/*     */       }
/*     */     }
/* 253 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*     */     try {
/* 255 */       doWriteTo(this.mode, out, false);
/* 256 */       byte[] extra = out.toByteArray();
/* 257 */       return contentLen + extra.length;
/*     */     } catch (IOException ex) {
/*     */     }
/* 260 */     return -1L;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.entity.mime.HttpMultipart
 * JD-Core Version:    0.6.0
 */