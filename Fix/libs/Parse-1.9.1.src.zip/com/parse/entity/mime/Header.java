/*     */ package com.parse.entity.mime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Header
/*     */   implements Iterable<MinimalField>
/*     */ {
/*     */   private final List<MinimalField> fields;
/*     */   private final Map<String, List<MinimalField>> fieldMap;
/*     */ 
/*     */   public Header()
/*     */   {
/*  50 */     this.fields = new LinkedList();
/*  51 */     this.fieldMap = new HashMap();
/*     */   }
/*     */ 
/*     */   public void addField(MinimalField field) {
/*  55 */     if (field == null) {
/*  56 */       return;
/*     */     }
/*  58 */     String key = field.getName().toLowerCase(Locale.US);
/*  59 */     List values = (List)this.fieldMap.get(key);
/*  60 */     if (values == null) {
/*  61 */       values = new LinkedList();
/*  62 */       this.fieldMap.put(key, values);
/*     */     }
/*  64 */     values.add(field);
/*  65 */     this.fields.add(field);
/*     */   }
/*     */ 
/*     */   public List<MinimalField> getFields() {
/*  69 */     return new ArrayList(this.fields);
/*     */   }
/*     */ 
/*     */   public MinimalField getField(String name) {
/*  73 */     if (name == null) {
/*  74 */       return null;
/*     */     }
/*  76 */     String key = name.toLowerCase(Locale.US);
/*  77 */     List list = (List)this.fieldMap.get(key);
/*  78 */     if ((list != null) && (!list.isEmpty())) {
/*  79 */       return (MinimalField)list.get(0);
/*     */     }
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */   public List<MinimalField> getFields(String name) {
/*  85 */     if (name == null) {
/*  86 */       return null;
/*     */     }
/*  88 */     String key = name.toLowerCase(Locale.US);
/*  89 */     List list = (List)this.fieldMap.get(key);
/*  90 */     if ((list == null) || (list.isEmpty())) {
/*  91 */       return Collections.emptyList();
/*     */     }
/*  93 */     return new ArrayList(list);
/*     */   }
/*     */ 
/*     */   public int removeFields(String name)
/*     */   {
/*  98 */     if (name == null) {
/*  99 */       return 0;
/*     */     }
/* 101 */     String key = name.toLowerCase(Locale.US);
/* 102 */     List removed = (List)this.fieldMap.remove(key);
/* 103 */     if ((removed == null) || (removed.isEmpty())) {
/* 104 */       return 0;
/*     */     }
/* 106 */     this.fields.removeAll(removed);
/* 107 */     return removed.size();
/*     */   }
/*     */ 
/*     */   public void setField(MinimalField field) {
/* 111 */     if (field == null) {
/* 112 */       return;
/*     */     }
/* 114 */     String key = field.getName().toLowerCase(Locale.US);
/* 115 */     List list = (List)this.fieldMap.get(key);
/* 116 */     if ((list == null) || (list.isEmpty())) {
/* 117 */       addField(field);
/* 118 */       return;
/*     */     }
/* 120 */     list.clear();
/* 121 */     list.add(field);
/* 122 */     int firstOccurrence = -1;
/* 123 */     int index = 0;
/* 124 */     for (Iterator it = this.fields.iterator(); it.hasNext(); index++) {
/* 125 */       MinimalField f = (MinimalField)it.next();
/* 126 */       if (f.getName().equalsIgnoreCase(field.getName())) {
/* 127 */         it.remove();
/* 128 */         if (firstOccurrence == -1) {
/* 129 */           firstOccurrence = index;
/*     */         }
/*     */       }
/*     */     }
/* 133 */     this.fields.add(firstOccurrence, field);
/*     */   }
/*     */ 
/*     */   public Iterator<MinimalField> iterator() {
/* 137 */     return Collections.unmodifiableList(this.fields).iterator();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 142 */     return this.fields.toString();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.entity.mime.Header
 * JD-Core Version:    0.6.0
 */