/*     */ package com.parse;
/*     */ 
/*     */ import android.app.Activity;
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import android.os.Bundle;
/*     */ import bolts.Continuation;
/*     */ import bolts.Task;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ class PushRouter
/*     */ {
/*     */   private static final String TAG = "com.parse.ParsePushRouter";
/*     */   private static final String LEGACY_ROUTE_LOCATION = "persistentCallbacks";
/*     */   private static final String STATE_LOCATION = "pushState";
/*  37 */   public static final Integer V2_PUSH_STATE_VERSION = Integer.valueOf(4);
/*  38 */   private static final Integer V1_LATEST_PUSH_STATE_VERSION = Integer.valueOf(3);
/*  39 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   public static final String GCM_RECEIVE_ACTION = "com.google.android.c2dm.intent.RECEIVE";
/*  43 */   static int MAX_HISTORY_LENGTH = 10;
/*     */   private static Task<Void> lastTask;
/*     */   private static PushListener pushListener;
/*     */   private static PushRouter instance;
/*     */   private final String stateLocation;
/*     */   private final PushRoutes routes;
/*     */   private final PushHistory history;
/* 562 */   private final AtomicBoolean isRefreshingInstallation = new AtomicBoolean(false);
/*     */   private Boolean forceEnabled;
/*     */   private int pushStateVersion;
/*     */ 
/*     */   public static Task<Void> subscribeAsync(String channel, Class<? extends Activity> cls, int iconId)
/*     */   {
/*  62 */     if ((channel != null) && (!PushRoutes.isValidChannelName(channel))) {
/*  63 */       throw new IllegalArgumentException("Invalid channel name: + " + channel + " (must be empty " + "string or a letter followed by alphanumerics or hyphen)");
/*     */     }
/*  65 */     if (cls == null)
/*  66 */       throw new IllegalArgumentException("Can't subscribe to channel with null activity class.");
/*  67 */     if (iconId == 0)
/*  68 */       throw new IllegalArgumentException("Must subscribe to channel with a valid icon identifier.");
/*     */     Task subscribeTask;
/*  73 */     synchronized (PushRouter.class) {
/*  74 */       subscribeTask = getLastTask().onSuccess(new Continuation(channel, cls, iconId)
/*     */       {
/*     */         public Void then(Task<Void> task) {
/*  77 */           PushRouter.access$000().subscribe(this.val$channel, this.val$cls, this.val$iconId);
/*  78 */           return null;
/*     */         }
/*     */       }
/*     */       , EXECUTOR);
/*     */ 
/*  82 */       lastTask = makeUnhandledExceptionsFatal(subscribeTask);
/*     */     }
/*     */ 
/*  85 */     return subscribeTask;
/*     */   }
/*     */ 
/*     */   public static Task<Void> unsubscribeAsync(String channel)
/*     */   {
/*     */     Task unsubscribeTask;
/*  95 */     synchronized (PushRouter.class) {
/*  96 */       unsubscribeTask = getLastTask().onSuccess(new Continuation(channel)
/*     */       {
/*     */         public Void then(Task<Void> task) {
/*  99 */           PushRouter.access$000().unsubscribe(this.val$channel);
/* 100 */           return null;
/*     */         }
/*     */       }
/*     */       , EXECUTOR);
/*     */ 
/* 104 */       lastTask = makeUnhandledExceptionsFatal(unsubscribeTask);
/*     */     }
/*     */ 
/* 107 */     return unsubscribeTask;
/*     */   }
/*     */ 
/*     */   public static Task<Void> setForceEnabledAsync(Boolean forceEnabled)
/*     */   {
/*     */     Task forceEnabledTask;
/* 115 */     synchronized (PushRouter.class) {
/* 116 */       forceEnabledTask = getLastTask().onSuccess(new Continuation(forceEnabled)
/*     */       {
/*     */         public Void then(Task<Void> task) {
/* 119 */           PushRouter.access$000().setForceEnabledState(this.val$forceEnabled);
/* 120 */           return null;
/*     */         }
/*     */       }
/*     */       , EXECUTOR);
/*     */ 
/* 123 */       lastTask = makeUnhandledExceptionsFatal(forceEnabledTask);
/*     */     }
/* 125 */     return forceEnabledTask;
/*     */   }
/*     */ 
/*     */   public static Task<Boolean> getForceEnabledStateAsync()
/*     */   {
/*     */     Task getForceEnabledTask;
/* 133 */     synchronized (PushRouter.class) {
/* 134 */       getForceEnabledTask = getLastTask().onSuccess(new Continuation()
/*     */       {
/*     */         public Boolean then(Task<Void> task) {
/* 137 */           return PushRouter.access$000().forceEnabled;
/*     */         }
/*     */       }
/*     */       , EXECUTOR);
/*     */ 
/* 140 */       lastTask = makeUnhandledExceptionsFatal(getForceEnabledTask.makeVoid());
/*     */     }
/* 142 */     return getForceEnabledTask;
/*     */   }
/*     */ 
/*     */   public static Task<Set<String>> getSubscriptionsAsync(boolean includeDefaultRoute)
/*     */   {
/*     */     Task getSubscriptionsTask;
/* 153 */     synchronized (PushRouter.class) {
/* 154 */       getSubscriptionsTask = getLastTask().onSuccess(new Continuation(includeDefaultRoute)
/*     */       {
/*     */         public Set<String> then(Task<Void> task) {
/* 157 */           return PushRouter.access$000().getSubscriptions(this.val$includeDefaultRoute);
/*     */         }
/*     */       }
/*     */       , EXECUTOR);
/*     */ 
/* 161 */       lastTask = makeUnhandledExceptionsFatal(getSubscriptionsTask.makeVoid());
/*     */     }
/*     */ 
/* 164 */     return getSubscriptionsTask;
/*     */   }
/*     */ 
/*     */   public static Task<JSONObject> getPushRequestJSONAsync()
/*     */   {
/*     */     Task getPushRequestTask;
/* 173 */     synchronized (PushRouter.class) {
/* 174 */       getPushRequestTask = getLastTask().onSuccess(new Continuation()
/*     */       {
/*     */         public JSONObject then(Task<Void> task) {
/* 177 */           return PushRouter.access$000().getPushRequestJSON();
/*     */         }
/*     */       }
/*     */       , EXECUTOR);
/*     */ 
/* 181 */       lastTask = makeUnhandledExceptionsFatal(getPushRequestTask.makeVoid());
/*     */     }
/*     */ 
/* 184 */     return getPushRequestTask;
/*     */   }
/*     */ 
/*     */   public static boolean isGcmPushIntent(Intent intent)
/*     */   {
/* 191 */     return (intent != null) && ("com.google.android.c2dm.intent.RECEIVE".equals(intent.getAction()));
/*     */   }
/*     */ 
/*     */   public static void handleGcmPushIntent(Intent intent)
/*     */   {
/* 198 */     Semaphore done = new Semaphore(0);
/* 199 */     EXECUTOR.submit(new Runnable(intent, done)
/*     */     {
/*     */       public void run() {
/* 202 */         PushRouter.access$000().handleGcmPush(this.val$intent);
/* 203 */         this.val$done.release();
/*     */       }
/*     */     });
/* 207 */     done.acquireUninterruptibly();
/*     */   }
/*     */ 
/*     */   public static Task<Void> handlePpnsPushAsync(JSONObject pushPayload)
/*     */   {
/*     */     Task receivedPushTask;
/* 217 */     synchronized (PushRouter.class) {
/* 218 */       receivedPushTask = getLastTask().onSuccess(new Continuation(pushPayload)
/*     */       {
/*     */         public Void then(Task<Void> task) {
/* 221 */           if (this.val$pushPayload != null) {
/* 222 */             PushRouter.access$000().handlePpnsPush(this.val$pushPayload);
/*     */           }
/* 224 */           return null;
/*     */         }
/*     */       }
/*     */       , EXECUTOR);
/*     */ 
/* 228 */       lastTask = makeUnhandledExceptionsFatal(receivedPushTask);
/*     */     }
/*     */ 
/* 231 */     return receivedPushTask;
/*     */   }
/*     */ 
/*     */   public static Task<Void> reloadFromDiskAsync(boolean removeExistingState)
/*     */   {
/*     */     Task reloadTask;
/* 241 */     synchronized (PushRouter.class) {
/* 242 */       reloadTask = getLastTask().onSuccess(new Continuation(removeExistingState)
/*     */       {
/*     */         public Void then(Task<Void> task) {
/* 245 */           PushRouter.access$200(this.val$removeExistingState);
/* 246 */           return null;
/*     */         }
/*     */       }
/*     */       , EXECUTOR);
/*     */ 
/* 250 */       lastTask = makeUnhandledExceptionsFatal(reloadTask);
/*     */     }
/*     */ 
/* 253 */     return reloadTask;
/*     */   }
/*     */ 
/*     */   public static Task<Void> wipeRoutingAndUpgradePushStateAsync()
/*     */   {
/*     */     Task wipeRoutingAndUpgradePushStateTask;
/* 263 */     synchronized (PushRouter.class) {
/* 264 */       wipeRoutingAndUpgradePushStateTask = getLastTask().onSuccess(new Continuation()
/*     */       {
/*     */         public Void then(Task<Void> task) throws Exception {
/* 267 */           PushRouter.access$000().setPushStateVersion(PushRouter.V2_PUSH_STATE_VERSION.intValue());
/* 268 */           return null;
/*     */         }
/*     */       }
/*     */       , EXECUTOR);
/*     */ 
/* 271 */       lastTask = makeUnhandledExceptionsFatal(wipeRoutingAndUpgradePushStateTask);
/*     */     }
/* 273 */     return wipeRoutingAndUpgradePushStateTask;
/*     */   }
/*     */ 
/*     */   private static synchronized Task<Void> getLastTask()
/*     */   {
/* 280 */     if (lastTask == null) {
/* 281 */       lastTask = Task.forResult(null).makeVoid();
/*     */     }
/*     */ 
/* 284 */     return lastTask;
/*     */   }
/*     */ 
/*     */   private static Task<Void> makeUnhandledExceptionsFatal(Task<Void> lastTask) {
/* 288 */     return lastTask.continueWith(new Continuation()
/*     */     {
/*     */       public Void then(Task<Void> task) {
/* 291 */         if (task.isFaulted()) {
/* 292 */           Task.UI_THREAD_EXECUTOR.execute(new Runnable(task)
/*     */           {
/*     */             public void run() {
/* 295 */               throw new RuntimeException(this.val$task.getError());
/*     */             }
/*     */           });
/*     */         }
/* 300 */         return null;
/*     */       }
/*     */     }
/*     */     , EXECUTOR);
/*     */   }
/*     */ 
/*     */   private static JSONArray getChannelsArrayFromInstallation(ParseInstallation installation)
/*     */   {
/* 310 */     JSONArray array = null;
/* 311 */     List list = installation.getList("channels");
/*     */ 
/* 313 */     if (list != null) {
/* 314 */       array = (JSONArray)Parse.encode(list, PointerOrLocalIdEncodingStrategy.get());
/*     */     }
/*     */ 
/* 317 */     return array != null ? array : new JSONArray();
/*     */   }
/*     */ 
/*     */   static synchronized void setGlobalPushListener(PushListener listener)
/*     */   {
/* 339 */     pushListener = listener;
/*     */   }
/*     */ 
/*     */   static void noteHandlePushResult(JSONObject pushData, HandlePushResult result)
/*     */   {
/*     */     PushListener listener;
/* 344 */     synchronized (PushRouter.class) {
/* 345 */       listener = pushListener;
/*     */     }
/*     */ 
/* 350 */     if (listener != null) {
/* 351 */       PushListener finalListener = listener;
/*     */ 
/* 353 */       getLastTask().continueWith(new Continuation(finalListener, pushData, result)
/*     */       {
/*     */         public Void then(Task<Void> task) {
/* 356 */           this.val$finalListener.onPushHandled(this.val$pushData, this.val$result);
/* 357 */           return null;
/*     */         }
/*     */       }
/*     */       , EXECUTOR);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static PushRouter getInstance()
/*     */   {
/* 373 */     if (instance == null) {
/* 374 */       JSONObject json = migrateV1toV3("persistentCallbacks", "pushState");
/*     */ 
/* 376 */       if (json == null) {
/* 377 */         json = migrateV2toV3("pushState", "pushState");
/*     */       }
/*     */ 
/* 380 */       if (json == null) {
/* 381 */         json = Parse.getDiskObject(Parse.applicationContext, "pushState");
/*     */       }
/*     */ 
/* 384 */       PushRoutes routes = new PushRoutes(json);
/* 385 */       PushHistory history = new PushHistory(MAX_HISTORY_LENGTH, json);
/*     */ 
/* 387 */       instance = new PushRouter("pushState", routes, history);
/*     */ 
/* 390 */       if (json != null) {
/* 391 */         instance.forceEnabled = ((Boolean)json.opt("forceEnabled"));
/* 392 */         instance.pushStateVersion = json.optInt("version", V1_LATEST_PUSH_STATE_VERSION.intValue());
/*     */       }
/*     */     }
/*     */ 
/* 396 */     return instance;
/*     */   }
/*     */ 
/*     */   private static PushRouter reloadInstance(boolean removeExistingState) {
/* 400 */     if (removeExistingState) {
/* 401 */       Parse.deleteDiskObject(Parse.applicationContext, "persistentCallbacks");
/* 402 */       Parse.deleteDiskObject(Parse.applicationContext, "pushState");
/*     */     }
/*     */ 
/* 405 */     instance = null;
/* 406 */     return getInstance();
/*     */   }
/*     */ 
/*     */   static JSONObject migrateV1toV3(String location, String migratedLocation)
/*     */   {
/* 425 */     ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/* 426 */     JSONObject legacyJSON = Parse.getDiskObject(Parse.applicationContext, location);
/* 427 */     JSONObject migratedJSON = null;
/*     */ 
/* 429 */     if (legacyJSON != null) {
/* 430 */       Parse.logD("com.parse.ParsePushRouter", "Migrating push state from V1 to V3: " + legacyJSON);
/*     */ 
/* 432 */       ArrayList channels = new ArrayList();
/* 433 */       Iterator keys = legacyJSON.keys();
/* 434 */       while (keys.hasNext()) {
/* 435 */         channels.add(keys.next());
/*     */       }
/*     */ 
/* 439 */       Collections.sort(channels);
/*     */ 
/* 442 */       installation.addAllUnique("channels", channels);
/* 443 */       installation.saveEventually();
/*     */       try
/*     */       {
/* 446 */         JSONObject json = new JSONObject();
/* 447 */         json.put("version", 3);
/* 448 */         json.put("routes", legacyJSON);
/* 449 */         json.put("channels", getChannelsArrayFromInstallation(installation));
/*     */ 
/* 451 */         Parse.saveDiskObject(Parse.applicationContext, migratedLocation, json);
/* 452 */         migratedJSON = json;
/*     */       } catch (JSONException e) {
/* 454 */         Parse.logE("com.parse.ParsePushRouter", "Unexpected JSONException when serializing upgraded v1 push state: ", e);
/*     */       }
/*     */ 
/* 457 */       if (!location.equals(migratedLocation)) {
/* 458 */         Parse.deleteDiskObject(Parse.applicationContext, location);
/*     */       }
/*     */     }
/*     */ 
/* 462 */     return migratedJSON;
/*     */   }
/*     */ 
/*     */   static JSONObject migrateV2toV3(String location, String migratedLocation)
/*     */   {
/* 495 */     ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/* 496 */     JSONObject json = Parse.getDiskObject(Parse.applicationContext, location);
/* 497 */     JSONObject migratedJSON = null;
/*     */ 
/* 499 */     if (json != null) {
/* 500 */       if (json.optInt("version") == 2) {
/* 501 */         Parse.logD("com.parse.ParsePushRouter", "Migrating push state from V2 to V3: " + json);
/*     */ 
/* 506 */         JSONArray addChannels = json.optJSONArray("addChannels");
/* 507 */         if (addChannels != null) {
/* 508 */           ArrayList toAdd = new ArrayList();
/* 509 */           for (int i = 0; i < addChannels.length(); i++) {
/* 510 */             toAdd.add(addChannels.optString(i));
/*     */           }
/*     */ 
/* 513 */           installation.addAllUnique("channels", toAdd);
/* 514 */           installation.saveEventually();
/*     */         }
/*     */ 
/* 517 */         JSONArray removeChannels = json.optJSONArray("removeChannels");
/* 518 */         if (removeChannels != null) {
/* 519 */           ArrayList toRemove = new ArrayList();
/* 520 */           for (int i = 0; i < removeChannels.length(); i++) {
/* 521 */             toRemove.add(removeChannels.optString(i));
/*     */           }
/*     */ 
/* 524 */           installation.removeAll("channels", toRemove);
/* 525 */           installation.saveEventually();
/*     */         }
/*     */ 
/* 528 */         if (json.has("installation")) {
/* 529 */           installation.mergeFromDiskJSON(json.optJSONObject("installation"));
/* 530 */           installation.saveEventually();
/*     */         }
/*     */         try
/*     */         {
/* 534 */           json.put("version", 3);
/* 535 */           json.remove("addChannels");
/* 536 */           json.remove("removeChannels");
/* 537 */           json.remove("installation");
/* 538 */           json.put("channels", getChannelsArrayFromInstallation(installation));
/*     */ 
/* 540 */           Parse.saveDiskObject(Parse.applicationContext, migratedLocation, json);
/*     */ 
/* 542 */           migratedJSON = json;
/*     */         } catch (JSONException e) {
/* 544 */           Parse.logE("com.parse.ParsePushRouter", "Unexpected JSONException when serializing upgraded v2 push state: ", e);
/*     */         }
/*     */ 
/* 547 */         if (!location.equals(migratedLocation))
/* 548 */           Parse.deleteDiskObject(Parse.applicationContext, location);
/*     */       }
/* 550 */       else if (json.optInt("version") == 3) {
/* 551 */         migratedJSON = json;
/*     */       }
/*     */     }
/*     */ 
/* 555 */     return migratedJSON;
/*     */   }
/*     */ 
/*     */   public PushRouter(String stateLocation, PushRoutes routes, PushHistory history)
/*     */   {
/* 567 */     this.stateLocation = stateLocation;
/* 568 */     this.routes = routes;
/* 569 */     this.history = history;
/* 570 */     this.forceEnabled = null;
/* 571 */     this.pushStateVersion = V1_LATEST_PUSH_STATE_VERSION.intValue();
/*     */   }
/*     */ 
/*     */   public JSONObject toJSON()
/*     */     throws JSONException
/*     */   {
/*     */     JSONObject json;
/*     */     JSONObject json;
/* 606 */     if (V2_PUSH_STATE_VERSION.equals(Integer.valueOf(this.pushStateVersion))) {
/* 607 */       json = this.history.toJSON();
/*     */     } else {
/* 609 */       json = merge(new JSONObject[] { this.routes.toJSON(), this.history.toJSON() });
/*     */ 
/* 611 */       json.put("channels", getChannelsArrayFromInstallation(ParseInstallation.getCurrentInstallation()));
/*     */     }
/* 613 */     json.put("version", this.pushStateVersion);
/* 614 */     json.putOpt("forceEnabled", this.forceEnabled);
/* 615 */     return json;
/*     */   }
/*     */ 
/*     */   private static JSONObject merge(JSONObject[] objects) throws JSONException {
/* 619 */     JSONObject merged = new JSONObject();
/*     */ 
/* 621 */     for (JSONObject object : objects) {
/* 622 */       Iterator it = object.keys();
/*     */ 
/* 624 */       while (it.hasNext()) {
/* 625 */         String key = (String)it.next();
/* 626 */         Object value = object.get(key);
/*     */ 
/* 628 */         merged.put(key, value);
/*     */       }
/*     */     }
/*     */ 
/* 632 */     return merged;
/*     */   }
/*     */ 
/*     */   public boolean saveStateToDisk() {
/* 636 */     boolean success = false;
/*     */     try
/*     */     {
/* 639 */       JSONObject json = toJSON();
/* 640 */       Parse.saveDiskObject(Parse.applicationContext, this.stateLocation, json);
/* 641 */       success = true;
/*     */     } catch (JSONException e) {
/* 643 */       Parse.logE("com.parse.ParsePushRouter", "Error serializing push state to json", e);
/*     */     }
/*     */ 
/* 646 */     return success;
/*     */   }
/*     */ 
/*     */   public JSONObject getPushRequestJSON()
/*     */   {
/* 656 */     JSONObject request = new JSONObject();
/* 657 */     ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/*     */     try
/*     */     {
/* 660 */       request.put("installation_id", installation.getInstallationId());
/* 661 */       request.put("oauth_key", ParseObject.getApplicationId());
/* 662 */       request.put("v", "a1.9.1");
/*     */ 
/* 664 */       String lastReceivedTimestamp = this.history.getLastReceivedTimestamp();
/* 665 */       request.put("last", lastReceivedTimestamp != null ? lastReceivedTimestamp : JSONObject.NULL);
/*     */ 
/* 667 */       Set pushIds = this.history.getPushIds();
/* 668 */       if (pushIds.size() > 0) {
/* 669 */         request.put("last_seen", new JSONArray(pushIds));
/*     */       }
/*     */ 
/* 672 */       request.put("ack_keep_alive", true);
/*     */ 
/* 674 */       request.putOpt("ignore_after", this.history.getCutoffTimestamp());
/*     */     } catch (JSONException e) {
/* 676 */       Parse.logE("com.parse.ParsePushRouter", "Unexpected JSONException serializing push handshake", e);
/* 677 */       return null;
/*     */     }
/*     */ 
/* 680 */     return request;
/*     */   }
/*     */ 
/*     */   public void subscribe(String channel, Class<? extends Activity> cls, int icon)
/*     */   {
/* 688 */     ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/* 689 */     PushRoutes.Route route = new PushRoutes.Route(cls.getName(), icon);
/* 690 */     PushRoutes.Route oldRoute = this.routes.put(channel, route);
/*     */ 
/* 692 */     if (!route.equals(oldRoute)) {
/* 693 */       saveStateToDisk();
/*     */     }
/*     */ 
/* 696 */     if ((oldRoute == null) && (channel != null)) {
/* 697 */       installation.addUnique("channels", channel);
/*     */     }
/*     */ 
/* 705 */     installation.saveEventually();
/*     */   }
/*     */ 
/*     */   public void setForceEnabledState(Boolean forceEnabled)
/*     */   {
/* 714 */     Boolean oldForceEnabledState = this.forceEnabled;
/* 715 */     if ((oldForceEnabledState != null) && (oldForceEnabledState == forceEnabled)) {
/* 716 */       return;
/*     */     }
/* 718 */     this.forceEnabled = forceEnabled;
/* 719 */     saveStateToDisk();
/*     */   }
/*     */ 
/*     */   public void unsubscribe(String channel)
/*     */   {
/* 727 */     PushRoutes.Route oldRoute = this.routes.remove(channel);
/*     */ 
/* 729 */     if (oldRoute != null) {
/* 730 */       saveStateToDisk();
/*     */ 
/* 732 */       if (channel != null) {
/* 733 */         ParseInstallation installation = ParseInstallation.getCurrentInstallation();
/* 734 */         installation.removeAll("channels", Arrays.asList(new String[] { channel }));
/* 735 */         installation.saveEventually();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setPushStateVersion(int version)
/*     */   {
/* 744 */     if (version != this.pushStateVersion) {
/* 745 */       this.pushStateVersion = version;
/* 746 */       saveStateToDisk();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set<String> getSubscriptions(boolean includeDefaultRoute)
/*     */   {
/* 758 */     Set subscriptions = new HashSet();
/* 759 */     List channels = ParseInstallation.getCurrentInstallation().getList("channels");
/*     */ 
/* 761 */     if (channels != null) {
/* 762 */       subscriptions.addAll(channels);
/*     */     }
/*     */ 
/* 765 */     subscriptions.addAll(this.routes.getChannels());
/*     */ 
/* 767 */     if (!includeDefaultRoute) {
/* 768 */       subscriptions.remove(null);
/*     */     }
/*     */ 
/* 771 */     return Collections.unmodifiableSet(subscriptions);
/*     */   }
/*     */ 
/*     */   private Date serverInstallationUpdatedAt(JSONObject pushData) {
/* 775 */     Date updatedAt = null;
/* 776 */     String updatedAtString = pushData.optString("installation_updated_at", null);
/*     */ 
/* 778 */     if (updatedAtString != null) {
/* 779 */       updatedAt = Parse.stringToDate(updatedAtString);
/*     */     }
/*     */ 
/* 782 */     return updatedAt;
/*     */   }
/*     */ 
/*     */   private void maybeRefreshInstallation(Date serverUpdatedAt)
/*     */   {
/* 790 */     ParseInstallation currentInstallation = ParseInstallation.getCurrentInstallation();
/* 791 */     Date updatedAt = currentInstallation.getUpdatedAt();
/*     */ 
/* 793 */     if ((updatedAt != null) && (serverUpdatedAt != null) && (updatedAt.compareTo(serverUpdatedAt) < 0) && 
/* 794 */       (this.isRefreshingInstallation.compareAndSet(false, true)))
/* 795 */       currentInstallation.fetchInBackground().continueWith(new Continuation()
/*     */       {
/*     */         public Void then(Task<ParseObject> task) {
/* 798 */           PushRouter.this.isRefreshingInstallation.set(false);
/* 799 */           return null;
/*     */         }
/*     */       });
/*     */   }
/*     */ 
/*     */   JSONObject convertGcmIntentToJSONObject(Intent intent)
/*     */   {
/* 807 */     JSONObject pushPayload = null;
/*     */ 
/* 809 */     if (intent != null) {
/* 810 */       String messageType = intent.getStringExtra("message_type");
/* 811 */       if (messageType != null)
/*     */       {
/* 817 */         Parse.logI("com.parse.ParsePushRouter", "Ignored special message type " + messageType + " from GCM via intent" + intent);
/*     */       } else {
/* 819 */         String pushDataString = intent.getStringExtra("data");
/* 820 */         String channel = intent.getStringExtra("channel");
/* 821 */         String installationUpdatedAt = intent.getStringExtra("installation_updated_at");
/* 822 */         JSONObject pushData = null;
/* 823 */         boolean ignore = false;
/*     */ 
/* 826 */         if (pushDataString != null) {
/*     */           try {
/* 828 */             pushData = new JSONObject(pushDataString);
/*     */           } catch (JSONException e) {
/* 830 */             Parse.logE("com.parse.ParsePushRouter", "Ignoring push because of JSON exception while processing: " + pushDataString, e);
/* 831 */             ignore = true;
/*     */           }
/*     */         }
/*     */ 
/* 835 */         if (!ignore) {
/*     */           try {
/* 837 */             pushPayload = new JSONObject();
/* 838 */             pushPayload.putOpt("data", pushData);
/* 839 */             pushPayload.putOpt("channel", channel);
/* 840 */             pushPayload.putOpt("installation_updated_at", installationUpdatedAt);
/*     */           } catch (JSONException e) {
/* 842 */             Parse.logE("com.parse.ParsePushRouter", "Ignoring push because of JSON exception while building payload", e);
/* 843 */             pushPayload = null;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 849 */     return pushPayload;
/*     */   }
/*     */ 
/*     */   public HandlePushResult handleGcmPush(Intent intent) {
/* 853 */     JSONObject pushPayload = convertGcmIntentToJSONObject(intent);
/* 854 */     return pushPayload != null ? handlePush(pushPayload) : HandlePushResult.INVALID_DATA;
/*     */   }
/*     */ 
/*     */   public HandlePushResult handlePpnsPush(JSONObject pushPayload)
/*     */   {
/* 861 */     HandlePushResult result = HandlePushResult.FAILED_HISTORY_TEST;
/* 862 */     String pushId = pushPayload.optString("push_id", null);
/* 863 */     String timestamp = pushPayload.optString("time", null);
/*     */ 
/* 865 */     if ((timestamp != null) && (this.history.tryInsertPush(pushId, timestamp))) {
/* 866 */       result = handlePush(pushPayload);
/* 867 */       saveStateToDisk();
/*     */     }
/*     */ 
/* 870 */     return result;
/*     */   }
/*     */ 
/*     */   public HandlePushResult handlePush(JSONObject pushPayload)
/*     */   {
/*     */     HandlePushResult result;
/*     */     HandlePushResult result;
/* 880 */     if (ManifestInfo.getPushUsesBroadcastReceivers()) {
/* 881 */       handlePushInternal(pushPayload);
/* 882 */       result = HandlePushResult.INVOKED_PARSE_PUSH_BROADCAST_RECEIVER;
/*     */     } else {
/* 884 */       result = handlePushLegacy(pushPayload);
/*     */     }
/*     */ 
/* 887 */     maybeRefreshInstallation(serverInstallationUpdatedAt(pushPayload));
/* 888 */     noteHandlePushResult(pushPayload, result);
/*     */ 
/* 890 */     return result;
/*     */   }
/*     */ 
/*     */   private void handlePushInternal(JSONObject pushPayload)
/*     */   {
/* 899 */     JSONObject pushData = pushPayload.optJSONObject("data");
/* 900 */     if (pushData == null) {
/* 901 */       pushData = new JSONObject();
/*     */     }
/*     */ 
/* 909 */     getInstance();
/*     */ 
/* 911 */     String channel = pushPayload.optString("channel", null);
/*     */ 
/* 913 */     Bundle extras = new Bundle();
/* 914 */     extras.putString("com.parse.Data", pushData.toString());
/* 915 */     extras.putString("com.parse.Channel", channel);
/*     */ 
/* 918 */     Context context = Parse.applicationContext;
/* 919 */     Intent pushBroadcastIntent = new Intent("com.parse.push.intent.RECEIVE");
/* 920 */     pushBroadcastIntent.putExtras(extras);
/*     */ 
/* 923 */     pushBroadcastIntent.setPackage(context.getPackageName());
/* 924 */     context.sendBroadcast(pushBroadcastIntent);
/*     */   }
/*     */ 
/*     */   private HandlePushResult handlePushLegacy(JSONObject pushPayload)
/*     */   {
/* 933 */     JSONObject pushData = pushPayload.optJSONObject("data");
/* 934 */     if (pushData == null) {
/* 935 */       pushData = new JSONObject();
/*     */     }
/*     */ 
/* 938 */     String channel = pushPayload.optString("channel", null);
/* 939 */     String action = pushData.optString("action", null);
/*     */ 
/* 941 */     Bundle extras = new Bundle();
/* 942 */     extras.putString("com.parse.Data", pushData.toString());
/* 943 */     extras.putString("com.parse.Channel", channel);
/*     */ 
/* 945 */     if (action != null) {
/* 946 */       Intent broadcastIntent = new Intent();
/* 947 */       broadcastIntent.putExtras(extras);
/* 948 */       broadcastIntent.setAction(action);
/* 949 */       broadcastIntent.setPackage(Parse.applicationContext.getPackageName());
/* 950 */       Parse.applicationContext.sendBroadcast(broadcastIntent);
/*     */ 
/* 953 */       if ((!pushData.has("alert")) && (!pushData.has("title"))) {
/* 954 */         return HandlePushResult.BROADCAST_INTENT;
/*     */       }
/*     */     }
/*     */ 
/* 958 */     PushRoutes.Route route = this.routes.get(channel);
/* 959 */     if ((route == null) && (channel != null)) {
/* 960 */       route = this.routes.get(null);
/*     */     }
/*     */ 
/* 963 */     if (route == null) {
/* 964 */       Parse.logW("com.parse.ParsePushRouter", "Received push that has no handler. Did you call PushService.setDefaultPushCallback or PushService.subscribe? Push payload: " + pushPayload);
/*     */ 
/* 966 */       return action != null ? HandlePushResult.BROADCAST_INTENT : HandlePushResult.NO_ROUTE_FOUND;
/*     */     }
/*     */ 
/* 969 */     Class cls = route.getActivityClass();
/* 970 */     int iconId = route.getIconId();
/* 971 */     String title = pushData.optString("title", ManifestInfo.getDisplayName());
/* 972 */     String body = pushData.optString("alert", "Notification received.");
/*     */ 
/* 974 */     if (iconId == 0) {
/* 975 */       iconId = ManifestInfo.getIconId();
/* 976 */       Parse.logW("com.parse.ParsePushRouter", "Icon ID associated with channel " + channel + "is invalid; defaulting to package icon");
/*     */     }
/*     */ 
/* 979 */     Context context = Parse.applicationContext;
/* 980 */     ParseNotificationManager.getInstance().showNotification(context, title, body, cls, iconId, extras);
/* 981 */     return action != null ? HandlePushResult.SHOW_NOTIFICATION_AND_BROADCAST_INTENT : HandlePushResult.SHOW_NOTIFICATION;
/*     */   }
/*     */ 
/*     */   static abstract interface PushListener
/*     */   {
/*     */     public abstract void onPushHandled(JSONObject paramJSONObject, PushRouter.HandlePushResult paramHandlePushResult);
/*     */   }
/*     */ 
/*     */   static enum HandlePushResult
/*     */   {
/* 324 */     INVALID_DATA, 
/* 325 */     FAILED_HISTORY_TEST, 
/* 326 */     NO_ROUTE_FOUND, 
/* 327 */     INVALID_ROUTE, 
/* 328 */     BROADCAST_INTENT, 
/* 329 */     SHOW_NOTIFICATION, 
/* 330 */     SHOW_NOTIFICATION_AND_BROADCAST_INTENT, 
/* 331 */     INVOKED_PARSE_PUSH_BROADCAST_RECEIVER;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.PushRouter
 * JD-Core Version:    0.6.0
 */