/*    */ package com.parse;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ class KnownParseObjectDecoder extends ParseDecoder
/*    */ {
/*    */   private Map<String, ParseObject> fetchedObjects;
/*    */ 
/*    */   public KnownParseObjectDecoder(Map<String, ParseObject> fetchedObjects)
/*    */   {
/* 14 */     this.fetchedObjects = fetchedObjects;
/*    */   }
/*    */ 
/*    */   protected ParseObject decodePointer(String className, String objectId)
/*    */   {
/* 23 */     if ((this.fetchedObjects != null) && (this.fetchedObjects.containsKey(objectId))) {
/* 24 */       return (ParseObject)this.fetchedObjects.get(objectId);
/*    */     }
/* 26 */     return super.decodePointer(className, objectId);
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.KnownParseObjectDecoder
 * JD-Core Version:    0.6.0
 */