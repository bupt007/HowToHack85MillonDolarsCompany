/*     */ package com.parse;
/*     */ 
/*     */ import android.app.Activity;
/*     */ import android.app.Notification;
/*     */ import android.app.PendingIntent;
/*     */ import android.content.BroadcastReceiver;
/*     */ import android.content.ComponentName;
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import android.content.pm.PackageManager;
/*     */ import android.graphics.Bitmap;
/*     */ import android.net.Uri;
/*     */ import android.os.Build.VERSION;
/*     */ import android.os.Bundle;
/*     */ import java.util.Locale;
/*     */ import java.util.Random;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class ParsePushBroadcastReceiver extends BroadcastReceiver
/*     */ {
/*     */   private static final String TAG = "com.parse.ParsePushReceiver";
/*     */   public static final String KEY_PUSH_CHANNEL = "com.parse.Channel";
/*     */   public static final String KEY_PUSH_DATA = "com.parse.Data";
/*     */   public static final String ACTION_PUSH_RECEIVE = "com.parse.push.intent.RECEIVE";
/*     */   public static final String ACTION_PUSH_OPEN = "com.parse.push.intent.OPEN";
/*     */   public static final String ACTION_PUSH_DELETE = "com.parse.push.intent.DELETE";
/*     */   public static final String PROPERTY_PUSH_ICON = "com.parse.push.notification_icon";
/*     */   protected static final int SMALL_NOTIFICATION_MAX_CHARACTER_LIMIT = 38;
/*     */ 
/*     */   public void onReceive(Context context, Intent intent)
/*     */   {
/* 106 */     String intentAction = intent.getAction();
/* 107 */     switch (intentAction) {
/*     */     case "com.parse.push.intent.RECEIVE":
/* 109 */       onPushReceive(context, intent);
/* 110 */       break;
/*     */     case "com.parse.push.intent.DELETE":
/* 112 */       onPushDismiss(context, intent);
/* 113 */       break;
/*     */     case "com.parse.push.intent.OPEN":
/* 115 */       onPushOpen(context, intent);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void onPushReceive(Context context, Intent intent)
/*     */   {
/* 131 */     JSONObject pushData = null;
/*     */     try {
/* 133 */       pushData = new JSONObject(intent.getStringExtra("com.parse.Data"));
/*     */     } catch (JSONException e) {
/* 135 */       Parse.logE("com.parse.ParsePushReceiver", "Unexpected JSONException when receiving push data: ", e);
/*     */     }
/*     */ 
/* 139 */     String action = null;
/* 140 */     if (pushData != null) {
/* 141 */       action = pushData.optString("action", null);
/*     */     }
/* 143 */     if (action != null) {
/* 144 */       Bundle extras = intent.getExtras();
/* 145 */       Intent broadcastIntent = new Intent();
/* 146 */       broadcastIntent.putExtras(extras);
/* 147 */       broadcastIntent.setAction(action);
/* 148 */       broadcastIntent.setPackage(context.getPackageName());
/* 149 */       context.sendBroadcast(broadcastIntent);
/*     */     }
/*     */ 
/* 152 */     Notification notification = getNotification(context, intent);
/*     */ 
/* 154 */     if (notification != null)
/* 155 */       ParseNotificationManager.getInstance().showNotification(context, notification);
/*     */   }
/*     */ 
/*     */   protected void onPushDismiss(Context context, Intent intent)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void onPushOpen(Context context, Intent intent)
/*     */   {
/* 186 */     ParseAnalytics.trackAppOpenedInBackground(intent);
/*     */ 
/* 188 */     String uriString = null;
/*     */     try {
/* 190 */       JSONObject pushData = new JSONObject(intent.getStringExtra("com.parse.Data"));
/* 191 */       uriString = pushData.optString("uri", null);
/*     */     } catch (JSONException e) {
/* 193 */       Parse.logE("com.parse.ParsePushReceiver", "Unexpected JSONException when receiving push data: ", e);
/*     */     }
/*     */ 
/* 196 */     Class cls = getActivity(context, intent);
/*     */     Intent activityIntent;
/*     */     Intent activityIntent;
/* 198 */     if (uriString != null)
/* 199 */       activityIntent = new Intent("android.intent.action.VIEW", Uri.parse(uriString));
/*     */     else {
/* 201 */       activityIntent = new Intent(context, cls);
/*     */     }
/*     */ 
/* 204 */     activityIntent.putExtras(intent.getExtras());
/*     */ 
/* 211 */     if (Build.VERSION.SDK_INT >= 16) {
/* 212 */       TaskStackBuilderHelper.startActivities(context, cls, activityIntent);
/*     */     } else {
/* 214 */       activityIntent.addFlags(268435456);
/* 215 */       activityIntent.addFlags(67108864);
/* 216 */       context.startActivity(activityIntent);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Class<? extends Activity> getActivity(Context context, Intent intent)
/*     */   {
/* 233 */     String packageName = Parse.applicationContext.getPackageName();
/* 234 */     Intent launchIntent = Parse.applicationContext.getPackageManager().getLaunchIntentForPackage(packageName);
/* 235 */     if (launchIntent == null) {
/* 236 */       return null;
/*     */     }
/* 238 */     String className = launchIntent.getComponent().getClassName();
/* 239 */     Class cls = null;
/*     */     try {
/* 241 */       cls = Class.forName(className);
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/*     */     }
/* 245 */     return cls;
/*     */   }
/*     */ 
/*     */   protected int getSmallIconId(Context context, Intent intent)
/*     */   {
/* 265 */     Bundle metaData = ManifestInfo.getApplicationMetadata(context);
/* 266 */     int explicitId = 0;
/* 267 */     if (metaData != null) {
/* 268 */       explicitId = metaData.getInt("com.parse.push.notification_icon");
/*     */     }
/* 270 */     return explicitId != 0 ? explicitId : ManifestInfo.getIconId();
/*     */   }
/*     */ 
/*     */   protected Bitmap getLargeIcon(Context context, Intent intent)
/*     */   {
/* 289 */     return null;
/*     */   }
/*     */ 
/*     */   private JSONObject getPushData(Intent intent) {
/*     */     try {
/* 294 */       return new JSONObject(intent.getStringExtra("com.parse.Data"));
/*     */     } catch (JSONException e) {
/* 296 */       Parse.logE("com.parse.ParsePushReceiver", "Unexpected JSONException when receiving push data: ", e);
/* 297 */     }return null;
/*     */   }
/*     */ 
/*     */   protected Notification getNotification(Context context, Intent intent)
/*     */   {
/* 319 */     JSONObject pushData = getPushData(intent);
/* 320 */     if ((pushData == null) || ((!pushData.has("alert")) && (!pushData.has("title")))) {
/* 321 */       return null;
/*     */     }
/*     */ 
/* 324 */     String title = pushData.optString("title", ManifestInfo.getDisplayName());
/* 325 */     String alert = pushData.optString("alert", "Notification received.");
/* 326 */     String tickerText = String.format(Locale.getDefault(), "%s: %s", new Object[] { title, alert });
/*     */ 
/* 328 */     Bundle extras = intent.getExtras();
/*     */ 
/* 330 */     Random random = new Random();
/* 331 */     int contentIntentRequestCode = random.nextInt();
/* 332 */     int deleteIntentRequestCode = random.nextInt();
/*     */ 
/* 337 */     String packageName = context.getPackageName();
/*     */ 
/* 339 */     Intent contentIntent = new Intent("com.parse.push.intent.OPEN");
/* 340 */     contentIntent.putExtras(extras);
/* 341 */     contentIntent.setPackage(packageName);
/*     */ 
/* 343 */     Intent deleteIntent = new Intent("com.parse.push.intent.DELETE");
/* 344 */     deleteIntent.putExtras(extras);
/* 345 */     deleteIntent.setPackage(packageName);
/*     */ 
/* 347 */     PendingIntent pContentIntent = PendingIntent.getBroadcast(context, contentIntentRequestCode, contentIntent, 134217728);
/*     */ 
/* 349 */     PendingIntent pDeleteIntent = PendingIntent.getBroadcast(context, deleteIntentRequestCode, deleteIntent, 134217728);
/*     */ 
/* 354 */     NotificationCompat.Builder parseBuilder = new NotificationCompat.Builder(context);
/* 355 */     parseBuilder.setContentTitle(title).setContentText(alert).setTicker(tickerText).setSmallIcon(getSmallIconId(context, intent)).setLargeIcon(getLargeIcon(context, intent)).setContentIntent(pContentIntent).setDeleteIntent(pDeleteIntent).setAutoCancel(true).setDefaults(-1);
/*     */ 
/* 364 */     if ((alert != null) && (alert.length() > 38))
/*     */     {
/* 366 */       parseBuilder.setStyle(new NotificationCompat.Builder.BigTextStyle().bigText(alert));
/*     */     }
/* 368 */     return parseBuilder.build();
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\Parse-1.9.1.jar
 * Qualified Name:     com.parse.ParsePushBroadcastReceiver
 * JD-Core Version:    0.6.0
 */