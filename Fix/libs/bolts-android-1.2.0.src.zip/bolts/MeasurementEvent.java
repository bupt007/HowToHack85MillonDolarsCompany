/*     */ package bolts;
/*     */ 
/*     */ import android.content.ComponentName;
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import android.net.Uri;
/*     */ import android.os.Bundle;
/*     */ import android.util.Log;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class MeasurementEvent
/*     */ {
/*     */   public static final String MEASUREMENT_EVENT_NOTIFICATION_NAME = "com.parse.bolts.measurement_event";
/*     */   public static final String MEASUREMENT_EVENT_NAME_KEY = "event_name";
/*     */   public static final String MEASUREMENT_EVENT_ARGS_KEY = "event_args";
/*     */   public static final String APP_LINK_NAVIGATE_OUT_EVENT_NAME = "al_nav_out";
/*     */   public static final String APP_LINK_NAVIGATE_IN_EVENT_NAME = "al_nav_in";
/*     */   private Context appContext;
/*     */   private String name;
/*     */   private Bundle args;
/*     */ 
/*     */   static void sendBroadcastEvent(Context context, String name, Intent intent, Map<String, String> extraLoggingData)
/*     */   {
/*  78 */     Bundle logData = new Bundle();
/*     */     Bundle intentExtras;
/*  79 */     if (intent != null) {
/*  80 */       Bundle applinkData = AppLinks.getAppLinkData(intent);
/*  81 */       if (applinkData != null) {
/*  82 */         logData = getApplinkLogData(context, name, applinkData, intent);
/*     */       } else {
/*  84 */         Uri intentUri = intent.getData();
/*  85 */         if (intentUri != null) {
/*  86 */           logData.putString("intentData", intentUri.toString());
/*     */         }
/*  88 */         intentExtras = intent.getExtras();
/*  89 */         if (intentExtras != null) {
/*  90 */           for (String key : intentExtras.keySet()) {
/*  91 */             Object o = intentExtras.get(key);
/*  92 */             String logValue = objectToJSONString(o);
/*  93 */             logData.putString(key, logValue);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  99 */     if (extraLoggingData != null) {
/* 100 */       for (String key : extraLoggingData.keySet()) {
/* 101 */         logData.putString(key, (String)extraLoggingData.get(key));
/*     */       }
/*     */     }
/* 104 */     MeasurementEvent event = new MeasurementEvent(context, name, logData);
/* 105 */     event.sendBroadcast();
/*     */   }
/*     */ 
/*     */   private MeasurementEvent(Context context, String eventName, Bundle eventArgs)
/*     */   {
/* 113 */     this.appContext = context.getApplicationContext();
/* 114 */     this.name = eventName;
/* 115 */     this.args = eventArgs;
/*     */   }
/*     */ 
/*     */   private void sendBroadcast() {
/* 119 */     if (this.name == null)
/* 120 */       Log.d(getClass().getName(), "Event name is required");
/*     */     try
/*     */     {
/* 123 */       Class clazz = Class.forName("android.support.v4.content.LocalBroadcastManager");
/* 124 */       Method methodGetInstance = clazz.getMethod("getInstance", new Class[] { Context.class });
/* 125 */       Method methodSendBroadcast = clazz.getMethod("sendBroadcast", new Class[] { Intent.class });
/* 126 */       Object localBroadcastManager = methodGetInstance.invoke(null, new Object[] { this.appContext });
/* 127 */       Intent event = new Intent("com.parse.bolts.measurement_event");
/* 128 */       event.putExtra("event_name", this.name);
/* 129 */       event.putExtra("event_args", this.args);
/* 130 */       methodSendBroadcast.invoke(localBroadcastManager, new Object[] { event });
/*     */     } catch (Exception e) {
/* 132 */       Log.d(getClass().getName(), "LocalBroadcastManager in android support library is required to raise bolts event.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Bundle getApplinkLogData(Context context, String eventName, Bundle appLinkData, Intent applinkIntent)
/*     */   {
/* 138 */     Bundle logData = new Bundle();
/* 139 */     ComponentName resolvedActivity = applinkIntent.resolveActivity(context.getPackageManager());
/*     */ 
/* 141 */     if (resolvedActivity != null) {
/* 142 */       logData.putString("class", resolvedActivity.getShortClassName());
/*     */     }
/*     */ 
/* 145 */     if ("al_nav_out".equals(eventName)) {
/* 146 */       if (resolvedActivity != null) {
/* 147 */         logData.putString("package", resolvedActivity.getPackageName());
/*     */       }
/* 149 */       if (applinkIntent.getData() != null) {
/* 150 */         logData.putString("outputURL", applinkIntent.getData().toString());
/*     */       }
/* 152 */       if (applinkIntent.getScheme() != null)
/* 153 */         logData.putString("outputURLScheme", applinkIntent.getScheme());
/*     */     }
/* 155 */     else if ("al_nav_in".equals(eventName)) {
/* 156 */       if (applinkIntent.getData() != null) {
/* 157 */         logData.putString("inputURL", applinkIntent.getData().toString());
/*     */       }
/* 159 */       if (applinkIntent.getScheme() != null) {
/* 160 */         logData.putString("inputURLScheme", applinkIntent.getScheme());
/*     */       }
/*     */     }
/*     */ 
/* 164 */     for (String key : appLinkData.keySet()) {
/* 165 */       Object o = appLinkData.get(key);
/* 166 */       if ((o instanceof Bundle)) {
/* 167 */         for (String subKey : ((Bundle)o).keySet()) {
/* 168 */           String logValue = objectToJSONString(((Bundle)o).get(subKey));
/* 169 */           if (key.equals("referer_app_link")) {
/* 170 */             if (subKey.equalsIgnoreCase("url")) {
/* 171 */               logData.putString("refererURL", logValue);
/* 172 */               continue;
/* 173 */             }if (subKey.equalsIgnoreCase("app_name")) {
/* 174 */               logData.putString("refererAppName", logValue);
/* 175 */               continue;
/* 176 */             }if (subKey.equalsIgnoreCase("package")) {
/* 177 */               logData.putString("sourceApplication", logValue);
/* 178 */               continue;
/*     */             }
/*     */           }
/* 181 */           logData.putString(key + "/" + subKey, logValue);
/*     */         }
/*     */       } else {
/* 184 */         String logValue = objectToJSONString(o);
/* 185 */         if (key.equals("target_url")) {
/* 186 */           Uri targetURI = Uri.parse(logValue);
/* 187 */           logData.putString("targetURL", targetURI.toString());
/* 188 */           logData.putString("targetURLHost", targetURI.getHost());
/* 189 */           continue;
/*     */         }
/* 191 */         logData.putString(key, logValue);
/*     */       }
/*     */     }
/* 194 */     return logData;
/*     */   }
/*     */ 
/*     */   private static String objectToJSONString(Object o) {
/* 198 */     if (o == null) {
/* 199 */       return null;
/*     */     }
/* 201 */     if (((o instanceof JSONArray)) || ((o instanceof JSONObject))) {
/* 202 */       return o.toString();
/*     */     }
/*     */     try
/*     */     {
/* 206 */       if ((o instanceof Collection)) {
/* 207 */         return new JSONArray((Collection)o).toString();
/*     */       }
/* 209 */       if ((o instanceof Map)) {
/* 210 */         return new JSONObject((Map)o).toString();
/*     */       }
/* 212 */       return o.toString();
/*     */     } catch (Exception ignored) {
/*     */     }
/* 215 */     return null;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.MeasurementEvent
 * JD-Core Version:    0.6.0
 */