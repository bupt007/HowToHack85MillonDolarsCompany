/*     */ package bolts;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ public class Task<TResult>
/*     */ {
/*  35 */   public static final ExecutorService BACKGROUND_EXECUTOR = BoltsExecutors.background();
/*     */ 
/*  42 */   private static final Executor IMMEDIATE_EXECUTOR = BoltsExecutors.immediate();
/*     */ 
/*  47 */   public static final Executor UI_THREAD_EXECUTOR = AndroidExecutors.uiThread();
/*     */ 
/*  49 */   private final Object lock = new Object();
/*     */   private boolean complete;
/*     */   private boolean cancelled;
/*     */   private TResult result;
/*     */   private Exception error;
/*     */   private List<Continuation<TResult, Void>> continuations;
/*     */ 
/*     */   private Task()
/*     */   {
/*  57 */     this.continuations = new ArrayList();
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<TResult>.TaskCompletionSource create()
/*     */   {
/*  67 */     Task task = new Task();
/*  68 */     task.getClass(); return new TaskCompletionSource(null);
/*     */   }
/*     */ 
/*     */   public boolean isCompleted()
/*     */   {
/*  76 */     synchronized (this.lock) {
/*  77 */       return this.complete;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isCancelled()
/*     */   {
/*  85 */     synchronized (this.lock) {
/*  86 */       return this.cancelled;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isFaulted()
/*     */   {
/*  94 */     synchronized (this.lock) {
/*  95 */       return this.error != null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public TResult getResult()
/*     */   {
/* 103 */     synchronized (this.lock) {
/* 104 */       return this.result;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Exception getError()
/*     */   {
/* 112 */     synchronized (this.lock) {
/* 113 */       return this.error;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void waitForCompletion()
/*     */     throws InterruptedException
/*     */   {
/* 121 */     synchronized (this.lock) {
/* 122 */       if (!isCompleted())
/* 123 */         this.lock.wait();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<TResult> forResult(TResult value)
/*     */   {
/* 132 */     TaskCompletionSource tcs = create();
/* 133 */     tcs.setResult(value);
/* 134 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<TResult> forError(Exception error)
/*     */   {
/* 141 */     TaskCompletionSource tcs = create();
/* 142 */     tcs.setError(error);
/* 143 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<TResult> cancelled()
/*     */   {
/* 150 */     TaskCompletionSource tcs = create();
/* 151 */     tcs.setCancelled();
/* 152 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public static Task<Void> delay(long delay)
/*     */   {
/* 162 */     return delay(delay, BoltsExecutors.scheduled());
/*     */   }
/*     */ 
/*     */   static Task<Void> delay(long delay, ScheduledExecutorService executor) {
/* 166 */     if (delay <= 0L) {
/* 167 */       return forResult(null);
/*     */     }
/* 169 */     TaskCompletionSource tcs = create();
/* 170 */     executor.schedule(new Runnable(tcs)
/*     */     {
/*     */       public void run() {
/* 173 */         this.val$tcs.setResult(null);
/*     */       }
/*     */     }
/*     */     , delay, TimeUnit.MILLISECONDS);
/*     */ 
/* 176 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public <TOut> Task<TOut> cast()
/*     */   {
/* 185 */     Task task = this;
/* 186 */     return task;
/*     */   }
/*     */ 
/*     */   public Task<Void> makeVoid()
/*     */   {
/* 193 */     return continueWithTask(new Continuation()
/*     */     {
/*     */       public Task<Void> then(Task<TResult> task) throws Exception {
/* 196 */         if (task.isCancelled()) {
/* 197 */           return Task.cancelled();
/*     */         }
/* 199 */         if (task.isFaulted()) {
/* 200 */           return Task.forError(task.getError());
/*     */         }
/* 202 */         return Task.forResult(null);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<TResult> callInBackground(Callable<TResult> callable)
/*     */   {
/* 214 */     return call(callable, BACKGROUND_EXECUTOR, null);
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<TResult> callInBackground(Callable<TResult> callable, CancellationToken ct)
/*     */   {
/* 221 */     return call(callable, BACKGROUND_EXECUTOR, ct);
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<TResult> call(Callable<TResult> callable, Executor executor)
/*     */   {
/* 231 */     return call(callable, executor, null);
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<TResult> call(Callable<TResult> callable, Executor executor, CancellationToken ct)
/*     */   {
/* 239 */     TaskCompletionSource tcs = create();
/* 240 */     executor.execute(new Runnable(ct, tcs, callable)
/*     */     {
/*     */       public void run() {
/* 243 */         if ((this.val$ct != null) && (this.val$ct.isCancellationRequested())) {
/* 244 */           this.val$tcs.setCancelled();
/* 245 */           return;
/*     */         }
/*     */         try
/*     */         {
/* 249 */           this.val$tcs.setResult(this.val$callable.call());
/*     */         } catch (CancellationException e) {
/* 251 */           this.val$tcs.setCancelled();
/*     */         } catch (Exception e) {
/* 253 */           this.val$tcs.setError(e);
/*     */         }
/*     */       }
/*     */     });
/* 257 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<TResult> call(Callable<TResult> callable)
/*     */   {
/* 267 */     return call(callable, IMMEDIATE_EXECUTOR, null);
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<TResult> call(Callable<TResult> callable, CancellationToken ct)
/*     */   {
/* 274 */     return call(callable, IMMEDIATE_EXECUTOR, ct);
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<Task<TResult>> whenAnyResult(Collection<? extends Task<TResult>> tasks)
/*     */   {
/* 290 */     if (tasks.size() == 0) {
/* 291 */       return forResult(null);
/*     */     }
/*     */ 
/* 294 */     TaskCompletionSource firstCompleted = create();
/* 295 */     AtomicBoolean isAnyTaskComplete = new AtomicBoolean(false);
/*     */ 
/* 297 */     for (Task task : tasks)
/* 298 */       task.continueWith(new Continuation(isAnyTaskComplete, firstCompleted)
/*     */       {
/*     */         public Void then(Task<TResult> task) {
/* 301 */           if (this.val$isAnyTaskComplete.compareAndSet(false, true)) {
/* 302 */             this.val$firstCompleted.setResult(task);
/*     */           }
/* 304 */           return null;
/*     */         }
/*     */       });
/* 308 */     return firstCompleted.getTask();
/*     */   }
/*     */ 
/*     */   public static Task<Task<?>> whenAny(Collection<? extends Task<?>> tasks)
/*     */   {
/* 325 */     if (tasks.size() == 0) {
/* 326 */       return forResult(null);
/*     */     }
/*     */ 
/* 329 */     TaskCompletionSource firstCompleted = create();
/* 330 */     AtomicBoolean isAnyTaskComplete = new AtomicBoolean(false);
/*     */ 
/* 332 */     for (Task task : tasks)
/* 333 */       task.continueWith(new Continuation(isAnyTaskComplete, firstCompleted)
/*     */       {
/*     */         public Void then(Task<Object> task) {
/* 336 */           if (this.val$isAnyTaskComplete.compareAndSet(false, true)) {
/* 337 */             this.val$firstCompleted.setResult(task);
/*     */           }
/* 339 */           return null;
/*     */         }
/*     */       });
/* 343 */     return firstCompleted.getTask();
/*     */   }
/*     */ 
/*     */   public static <TResult> Task<List<TResult>> whenAllResult(Collection<? extends Task<TResult>> tasks)
/*     */   {
/* 372 */     return whenAll(tasks).onSuccess(new Continuation(tasks)
/*     */     {
/*     */       public List<TResult> then(Task<Void> task) throws Exception {
/* 375 */         if (this.val$tasks.size() == 0) {
/* 376 */           return Collections.emptyList();
/*     */         }
/*     */ 
/* 379 */         List results = new ArrayList();
/* 380 */         for (Task individualTask : this.val$tasks) {
/* 381 */           results.add(individualTask.getResult());
/*     */         }
/* 383 */         return results;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static Task<Void> whenAll(Collection<? extends Task<?>> tasks)
/*     */   {
/* 409 */     if (tasks.size() == 0) {
/* 410 */       return forResult(null);
/*     */     }
/*     */ 
/* 413 */     TaskCompletionSource allFinished = create();
/* 414 */     ArrayList causes = new ArrayList();
/* 415 */     Object errorLock = new Object();
/* 416 */     AtomicInteger count = new AtomicInteger(tasks.size());
/* 417 */     AtomicBoolean isCancelled = new AtomicBoolean(false);
/*     */ 
/* 419 */     for (Task task : tasks)
/*     */     {
/* 421 */       Task t = task;
/* 422 */       t.continueWith(new Object(errorLock, causes, isCancelled, count, allFinished)
/*     */       {
/*     */         public Void then(Task<Object> task) {
/* 425 */           if (task.isFaulted()) {
/* 426 */             synchronized (this.val$errorLock) {
/* 427 */               this.val$causes.add(task.getError());
/*     */             }
/*     */           }
/*     */ 
/* 431 */           if (task.isCancelled()) {
/* 432 */             this.val$isCancelled.set(true);
/*     */           }
/*     */ 
/* 435 */           if (this.val$count.decrementAndGet() == 0) {
/* 436 */             if (this.val$causes.size() != 0) {
/* 437 */               if (this.val$causes.size() == 1) {
/* 438 */                 this.val$allFinished.setError((Exception)this.val$causes.get(0));
/*     */               } else {
/* 440 */                 Exception error = new AggregateException(String.format("There were %d exceptions.", new Object[] { Integer.valueOf(this.val$causes.size()) }), this.val$causes);
/*     */ 
/* 443 */                 this.val$allFinished.setError(error);
/*     */               }
/* 445 */             } else if (this.val$isCancelled.get())
/* 446 */               this.val$allFinished.setCancelled();
/*     */             else {
/* 448 */               this.val$allFinished.setResult(null);
/*     */             }
/*     */           }
/* 451 */           return null;
/*     */         }
/*     */       });
/*     */     }
/* 456 */     return allFinished.getTask();
/*     */   }
/*     */ 
/*     */   public Task<Void> continueWhile(Callable<Boolean> predicate, Continuation<Void, Task<Void>> continuation)
/*     */   {
/* 465 */     return continueWhile(predicate, continuation, IMMEDIATE_EXECUTOR, null);
/*     */   }
/*     */ 
/*     */   public Task<Void> continueWhile(Callable<Boolean> predicate, Continuation<Void, Task<Void>> continuation, CancellationToken ct)
/*     */   {
/* 474 */     return continueWhile(predicate, continuation, IMMEDIATE_EXECUTOR, ct);
/*     */   }
/*     */ 
/*     */   public Task<Void> continueWhile(Callable<Boolean> predicate, Continuation<Void, Task<Void>> continuation, Executor executor)
/*     */   {
/* 483 */     return continueWhile(predicate, continuation, executor, null);
/*     */   }
/*     */ 
/*     */   public Task<Void> continueWhile(Callable<Boolean> predicate, Continuation<Void, Task<Void>> continuation, Executor executor, CancellationToken ct)
/*     */   {
/* 493 */     Capture predicateContinuation = new Capture();
/*     */ 
/* 495 */     predicateContinuation.set(new Continuation(ct, predicate, continuation, executor, predicateContinuation)
/*     */     {
/*     */       public Task<Void> then(Task<Void> task) throws Exception {
/* 498 */         if ((this.val$ct != null) && (this.val$ct.isCancellationRequested())) {
/* 499 */           return Task.cancelled();
/*     */         }
/*     */ 
/* 502 */         if (((Boolean)this.val$predicate.call()).booleanValue()) {
/* 503 */           return Task.forResult(null).onSuccessTask(this.val$continuation, this.val$executor).onSuccessTask((Continuation)this.val$predicateContinuation.get(), this.val$executor);
/*     */         }
/*     */ 
/* 506 */         return Task.forResult(null);
/*     */       }
/*     */     });
/* 509 */     return makeVoid().continueWithTask((Continuation)predicateContinuation.get(), executor);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> continuation, Executor executor)
/*     */   {
/* 519 */     return continueWith(continuation, executor, null);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> continuation, Executor executor, CancellationToken ct)
/*     */   {
/* 531 */     TaskCompletionSource tcs = create();
/*     */     boolean completed;
/* 532 */     synchronized (this.lock) {
/* 533 */       completed = isCompleted();
/* 534 */       if (!completed)
/* 535 */         this.continuations.add(new Continuation(tcs, continuation, executor, ct)
/*     */         {
/*     */           public Void then(Task<TResult> task) {
/* 538 */             Task.access$100(this.val$tcs, this.val$continuation, task, this.val$executor, this.val$ct);
/* 539 */             return null;
/*     */           }
/*     */         });
/*     */     }
/* 544 */     if (completed) {
/* 545 */       completeImmediately(tcs, continuation, this, executor, ct);
/*     */     }
/* 547 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> continuation)
/*     */   {
/* 556 */     return continueWith(continuation, IMMEDIATE_EXECUTOR, null);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> continuation, CancellationToken ct)
/*     */   {
/* 565 */     return continueWith(continuation, IMMEDIATE_EXECUTOR, ct);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> continuation, Executor executor)
/*     */   {
/* 574 */     return continueWithTask(continuation, executor, null);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> continuation, Executor executor, CancellationToken ct)
/*     */   {
/* 585 */     TaskCompletionSource tcs = create();
/*     */     boolean completed;
/* 586 */     synchronized (this.lock) {
/* 587 */       completed = isCompleted();
/* 588 */       if (!completed)
/* 589 */         this.continuations.add(new Continuation(tcs, continuation, executor, ct)
/*     */         {
/*     */           public Void then(Task<TResult> task) {
/* 592 */             Task.access$200(this.val$tcs, this.val$continuation, task, this.val$executor, this.val$ct);
/* 593 */             return null;
/*     */           }
/*     */         });
/*     */     }
/* 598 */     if (completed) {
/* 599 */       completeAfterTask(tcs, continuation, this, executor, ct);
/*     */     }
/* 601 */     return tcs.getTask();
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> continuation)
/*     */   {
/* 610 */     return continueWithTask(continuation, IMMEDIATE_EXECUTOR, null);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> continuation, CancellationToken ct)
/*     */   {
/* 619 */     return continueWithTask(continuation, IMMEDIATE_EXECUTOR, ct);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> continuation, Executor executor)
/*     */   {
/* 628 */     return onSuccess(continuation, executor, null);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> continuation, Executor executor, CancellationToken ct)
/*     */   {
/* 638 */     return continueWithTask(new Continuation(ct, continuation)
/*     */     {
/*     */       public Task<TContinuationResult> then(Task<TResult> task) {
/* 641 */         if ((this.val$ct != null) && (this.val$ct.isCancellationRequested())) {
/* 642 */           return Task.cancelled();
/*     */         }
/*     */ 
/* 645 */         if (task.isFaulted())
/* 646 */           return Task.forError(task.getError());
/* 647 */         if (task.isCancelled()) {
/* 648 */           return Task.cancelled();
/*     */         }
/* 650 */         return task.continueWith(this.val$continuation);
/*     */       }
/*     */     }
/*     */     , executor);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> continuation)
/*     */   {
/* 662 */     return onSuccess(continuation, IMMEDIATE_EXECUTOR, null);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> continuation, CancellationToken ct)
/*     */   {
/* 671 */     return onSuccess(continuation, IMMEDIATE_EXECUTOR, ct);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> continuation, Executor executor)
/*     */   {
/* 680 */     return onSuccessTask(continuation, executor, null);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> continuation, Executor executor, CancellationToken ct)
/*     */   {
/* 690 */     return continueWithTask(new Continuation(ct, continuation)
/*     */     {
/*     */       public Task<TContinuationResult> then(Task<TResult> task) {
/* 693 */         if ((this.val$ct != null) && (this.val$ct.isCancellationRequested())) {
/* 694 */           return Task.cancelled();
/*     */         }
/*     */ 
/* 697 */         if (task.isFaulted())
/* 698 */           return Task.forError(task.getError());
/* 699 */         if (task.isCancelled()) {
/* 700 */           return Task.cancelled();
/*     */         }
/* 702 */         return task.continueWithTask(this.val$continuation);
/*     */       }
/*     */     }
/*     */     , executor);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> continuation)
/*     */   {
/* 714 */     return onSuccessTask(continuation, IMMEDIATE_EXECUTOR);
/*     */   }
/*     */ 
/*     */   public <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> continuation, CancellationToken ct)
/*     */   {
/* 724 */     return onSuccessTask(continuation, IMMEDIATE_EXECUTOR, ct);
/*     */   }
/*     */ 
/*     */   private static <TContinuationResult, TResult> void completeImmediately(Task<TContinuationResult>.TaskCompletionSource tcs, Continuation<TResult, TContinuationResult> continuation, Task<TResult> task, Executor executor, CancellationToken ct)
/*     */   {
/* 746 */     executor.execute(new Runnable(ct, tcs, continuation, task)
/*     */     {
/*     */       public void run() {
/* 749 */         if ((this.val$ct != null) && (this.val$ct.isCancellationRequested())) {
/* 750 */           this.val$tcs.setCancelled();
/* 751 */           return;
/*     */         }
/*     */         try
/*     */         {
/* 755 */           Object result = this.val$continuation.then(this.val$task);
/* 756 */           this.val$tcs.setResult(result);
/*     */         } catch (CancellationException e) {
/* 758 */           this.val$tcs.setCancelled();
/*     */         } catch (Exception e) {
/* 760 */           this.val$tcs.setError(e);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private static <TContinuationResult, TResult> void completeAfterTask(Task<TContinuationResult>.TaskCompletionSource tcs, Continuation<TResult, Task<TContinuationResult>> continuation, Task<TResult> task, Executor executor, CancellationToken ct)
/*     */   {
/* 787 */     executor.execute(new Runnable(ct, tcs, continuation, task)
/*     */     {
/*     */       public void run() {
/* 790 */         if ((this.val$ct != null) && (this.val$ct.isCancellationRequested())) {
/* 791 */           this.val$tcs.setCancelled();
/* 792 */           return;
/*     */         }
/*     */         try
/*     */         {
/* 796 */           Task result = (Task)this.val$continuation.then(this.val$task);
/* 797 */           if (result == null)
/* 798 */             this.val$tcs.setResult(null);
/*     */           else
/* 800 */             result.continueWith(new Continuation()
/*     */             {
/*     */               public Void then(Task<TContinuationResult> task) {
/* 803 */                 if ((Task.14.this.val$ct != null) && (Task.14.this.val$ct.isCancellationRequested())) {
/* 804 */                   Task.14.this.val$tcs.setCancelled();
/* 805 */                   return null;
/*     */                 }
/*     */ 
/* 808 */                 if (task.isCancelled())
/* 809 */                   Task.14.this.val$tcs.setCancelled();
/* 810 */                 else if (task.isFaulted())
/* 811 */                   Task.14.this.val$tcs.setError(task.getError());
/*     */                 else {
/* 813 */                   Task.14.this.val$tcs.setResult(task.getResult());
/*     */                 }
/* 815 */                 return null;
/*     */               } } );
/*     */         }
/*     */         catch (CancellationException e) {
/* 820 */           this.val$tcs.setCancelled();
/*     */         } catch (Exception e) {
/* 822 */           this.val$tcs.setError(e);
/*     */         }
/*     */       } } );
/*     */   }
/*     */ 
/*     */   private void runContinuations() {
/* 829 */     synchronized (this.lock) {
/* 830 */       for (Continuation continuation : this.continuations) {
/*     */         try {
/* 832 */           continuation.then(this);
/*     */         } catch (RuntimeException e) {
/* 834 */           throw e;
/*     */         } catch (Exception e) {
/* 836 */           throw new RuntimeException(e);
/*     */         }
/*     */       }
/* 839 */       this.continuations = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public class TaskCompletionSource
/*     */   {
/*     */     private TaskCompletionSource()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Task<TResult> getTask()
/*     */     {
/* 857 */       return Task.this;
/*     */     }
/*     */ 
/*     */     public boolean trySetCancelled()
/*     */     {
/* 864 */       synchronized (Task.this.lock) {
/* 865 */         if (Task.this.complete) {
/* 866 */           return false;
/*     */         }
/* 868 */         Task.access$402(Task.this, true);
/* 869 */         Task.access$502(Task.this, true);
/* 870 */         Task.this.lock.notifyAll();
/* 871 */         Task.this.runContinuations();
/* 872 */         return true;
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean trySetResult(TResult result)
/*     */     {
/* 880 */       synchronized (Task.this.lock) {
/* 881 */         if (Task.this.complete) {
/* 882 */           return false;
/*     */         }
/* 884 */         Task.access$402(Task.this, true);
/* 885 */         Task.access$702(Task.this, result);
/* 886 */         Task.this.lock.notifyAll();
/* 887 */         Task.this.runContinuations();
/* 888 */         return true;
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean trySetError(Exception error)
/*     */     {
/* 896 */       synchronized (Task.this.lock) {
/* 897 */         if (Task.this.complete) {
/* 898 */           return false;
/*     */         }
/* 900 */         Task.access$402(Task.this, true);
/* 901 */         Task.access$802(Task.this, error);
/* 902 */         Task.this.lock.notifyAll();
/* 903 */         Task.this.runContinuations();
/* 904 */         return true;
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setCancelled()
/*     */     {
/* 912 */       if (!trySetCancelled())
/* 913 */         throw new IllegalStateException("Cannot cancel a completed task.");
/*     */     }
/*     */ 
/*     */     public void setResult(TResult result)
/*     */     {
/* 921 */       if (!trySetResult(result))
/* 922 */         throw new IllegalStateException("Cannot set the result of a completed task.");
/*     */     }
/*     */ 
/*     */     public void setError(Exception error)
/*     */     {
/* 930 */       if (!trySetError(error))
/* 931 */         throw new IllegalStateException("Cannot set the error on a completed task.");
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.Task
 * JD-Core Version:    0.6.0
 */