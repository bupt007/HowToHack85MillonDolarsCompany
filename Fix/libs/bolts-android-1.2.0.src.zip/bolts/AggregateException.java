/*     */ package bolts;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ public class AggregateException extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String DEFAULT_MESSAGE = "There were multiple errors.";
/*     */   private List<Throwable> innerThrowables;
/*     */ 
/*     */   public AggregateException(String detailMessage, Throwable[] innerThrowables)
/*     */   {
/*  41 */     this(detailMessage, Arrays.asList(innerThrowables));
/*     */   }
/*     */ 
/*     */   public AggregateException(String detailMessage, List<? extends Throwable> innerThrowables)
/*     */   {
/*  55 */     super(detailMessage, (innerThrowables != null) && (innerThrowables.size() > 0) ? (Throwable)innerThrowables.get(0) : null);
/*     */ 
/*  57 */     this.innerThrowables = Collections.unmodifiableList(innerThrowables);
/*     */   }
/*     */ 
/*     */   public AggregateException(List<? extends Throwable> innerThrowables)
/*     */   {
/*  68 */     this("There were multiple errors.", innerThrowables);
/*     */   }
/*     */ 
/*     */   public List<Throwable> getInnerThrowables()
/*     */   {
/*  76 */     return this.innerThrowables;
/*     */   }
/*     */ 
/*     */   public void printStackTrace(PrintStream err)
/*     */   {
/*  81 */     super.printStackTrace(err);
/*     */ 
/*  83 */     int currentIndex = -1;
/*  84 */     for (Throwable throwable : this.innerThrowables) {
/*  85 */       err.append("\n");
/*  86 */       err.append("  Inner throwable #");
/*  87 */       currentIndex++; err.append(Integer.toString(currentIndex));
/*  88 */       err.append(": ");
/*  89 */       throwable.printStackTrace(err);
/*  90 */       err.append("\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void printStackTrace(PrintWriter err)
/*     */   {
/*  96 */     super.printStackTrace(err);
/*     */ 
/*  98 */     int currentIndex = -1;
/*  99 */     for (Throwable throwable : this.innerThrowables) {
/* 100 */       err.append("\n");
/* 101 */       err.append("  Inner throwable #");
/* 102 */       currentIndex++; err.append(Integer.toString(currentIndex));
/* 103 */       err.append(": ");
/* 104 */       throwable.printStackTrace(err);
/* 105 */       err.append("\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public List<Exception> getErrors()
/*     */   {
/* 114 */     List errors = new ArrayList();
/* 115 */     if (this.innerThrowables == null) {
/* 116 */       return errors;
/*     */     }
/*     */ 
/* 119 */     for (Throwable cause : this.innerThrowables) {
/* 120 */       if ((cause instanceof Exception))
/* 121 */         errors.add((Exception)cause);
/*     */       else {
/* 123 */         errors.add(new Exception(cause));
/*     */       }
/*     */     }
/* 126 */     return errors;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Throwable[] getCauses()
/*     */   {
/* 134 */     return (Throwable[])this.innerThrowables.toArray(new Throwable[this.innerThrowables.size()]);
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.AggregateException
 * JD-Core Version:    0.6.0
 */