/*     */ package bolts;
/*     */ 
/*     */ import android.net.Uri;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ public class AppLink
/*     */ {
/*     */   private Uri sourceUrl;
/*     */   private List<Target> targets;
/*     */   private Uri webUrl;
/*     */ 
/*     */   public AppLink(Uri sourceUrl, List<Target> targets, Uri webUrl)
/*     */   {
/*  91 */     this.sourceUrl = sourceUrl;
/*  92 */     if (targets == null) {
/*  93 */       targets = Collections.emptyList();
/*     */     }
/*  95 */     this.targets = targets;
/*  96 */     this.webUrl = webUrl;
/*     */   }
/*     */ 
/*     */   public Uri getSourceUrl()
/*     */   {
/* 103 */     return this.sourceUrl;
/*     */   }
/*     */ 
/*     */   public List<Target> getTargets()
/*     */   {
/* 110 */     return Collections.unmodifiableList(this.targets);
/*     */   }
/*     */ 
/*     */   public Uri getWebUrl()
/*     */   {
/* 117 */     return this.webUrl;
/*     */   }
/*     */ 
/*     */   public static class Target
/*     */   {
/*     */     private final Uri url;
/*     */     private final String packageName;
/*     */     private final String className;
/*     */     private final String appName;
/*     */ 
/*     */     public Target(String packageName, String className, Uri url, String appName)
/*     */     {
/*  41 */       this.packageName = packageName;
/*  42 */       this.className = className;
/*  43 */       this.url = url;
/*  44 */       this.appName = appName;
/*     */     }
/*     */ 
/*     */     public Uri getUrl()
/*     */     {
/*  52 */       return this.url;
/*     */     }
/*     */ 
/*     */     public String getAppName()
/*     */     {
/*  59 */       return this.appName;
/*     */     }
/*     */ 
/*     */     public String getClassName()
/*     */     {
/*  66 */       return this.className;
/*     */     }
/*     */ 
/*     */     public String getPackageName()
/*     */     {
/*  73 */       return this.packageName;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.AppLink
 * JD-Core Version:    0.6.0
 */