/*    */ package bolts;
/*    */ 
/*    */ import android.content.Context;
/*    */ import android.content.Intent;
/*    */ import android.net.Uri;
/*    */ import android.os.Bundle;
/*    */ 
/*    */ public final class AppLinks
/*    */ {
/*    */   static final String KEY_NAME_APPLINK_DATA = "al_applink_data";
/*    */   static final String KEY_NAME_EXTRAS = "extras";
/*    */   static final String KEY_NAME_TARGET = "target_url";
/*    */ 
/*    */   public static Bundle getAppLinkData(Intent intent)
/*    */   {
/* 36 */     return intent.getBundleExtra("al_applink_data");
/*    */   }
/*    */ 
/*    */   public static Bundle getAppLinkExtras(Intent intent)
/*    */   {
/* 47 */     Bundle appLinkData = getAppLinkData(intent);
/* 48 */     if (appLinkData == null) {
/* 49 */       return null;
/*    */     }
/* 51 */     return appLinkData.getBundle("extras");
/*    */   }
/*    */ 
/*    */   public static Uri getTargetUrl(Intent intent)
/*    */   {
/* 63 */     Bundle appLinkData = getAppLinkData(intent);
/* 64 */     if (appLinkData != null) {
/* 65 */       String targetString = appLinkData.getString("target_url");
/* 66 */       if (targetString != null) {
/* 67 */         return Uri.parse(targetString);
/*    */       }
/*    */     }
/* 70 */     return intent.getData();
/*    */   }
/*    */ 
/*    */   public static Uri getTargetUrlFromInboundIntent(Context context, Intent intent)
/*    */   {
/* 82 */     Bundle appLinkData = getAppLinkData(intent);
/* 83 */     if (appLinkData != null) {
/* 84 */       String targetString = appLinkData.getString("target_url");
/* 85 */       if (targetString != null) {
/* 86 */         MeasurementEvent.sendBroadcastEvent(context, "al_nav_in", intent, null);
/* 87 */         return Uri.parse(targetString);
/*    */       }
/*    */     }
/* 90 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.AppLinks
 * JD-Core Version:    0.6.0
 */