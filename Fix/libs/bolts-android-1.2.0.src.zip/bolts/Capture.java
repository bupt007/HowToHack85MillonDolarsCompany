/*    */ package bolts;
/*    */ 
/*    */ public class Capture<T>
/*    */ {
/*    */   private T value;
/*    */ 
/*    */   public Capture()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Capture(T value)
/*    */   {
/* 24 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public T get() {
/* 28 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void set(T value) {
/* 32 */     this.value = value;
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.Capture
 * JD-Core Version:    0.6.0
 */