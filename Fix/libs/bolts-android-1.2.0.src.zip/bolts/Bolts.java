package bolts;

public final class Bolts
{
  public static final String VERSION = "1.2.0";
}

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.Bolts
 * JD-Core Version:    0.6.0
 */