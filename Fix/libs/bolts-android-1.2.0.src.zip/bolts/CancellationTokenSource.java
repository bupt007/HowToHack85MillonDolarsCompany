/*    */ package bolts;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class CancellationTokenSource
/*    */ {
/*    */   private final CancellationToken token;
/*    */ 
/*    */   public CancellationTokenSource()
/*    */   {
/* 30 */     this.token = new CancellationToken();
/*    */   }
/*    */ 
/*    */   public boolean isCancellationRequested()
/*    */   {
/* 37 */     return this.token.isCancellationRequested();
/*    */   }
/*    */ 
/*    */   public CancellationToken getToken()
/*    */   {
/* 44 */     return this.token;
/*    */   }
/*    */ 
/*    */   public void cancel()
/*    */   {
/* 51 */     this.token.tryCancel();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 56 */     return String.format(Locale.US, "%s@%s[cancellationRequested=%s]", new Object[] { getClass().getName(), Integer.toHexString(hashCode()), Boolean.toString(isCancellationRequested()) });
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.CancellationTokenSource
 * JD-Core Version:    0.6.0
 */