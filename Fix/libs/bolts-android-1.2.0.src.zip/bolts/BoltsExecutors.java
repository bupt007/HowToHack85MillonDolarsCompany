/*     */ package bolts;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ 
/*     */ final class BoltsExecutors
/*     */ {
/*  14 */   private static final BoltsExecutors INSTANCE = new BoltsExecutors();
/*     */   private final ExecutorService background;
/*     */   private final ScheduledExecutorService scheduled;
/*     */   private final Executor immediate;
/*     */ 
/*     */   private static boolean isAndroidRuntime()
/*     */   {
/*  17 */     String javaRuntimeName = System.getProperty("java.runtime.name");
/*  18 */     if (javaRuntimeName == null) {
/*  19 */       return false;
/*     */     }
/*  21 */     return javaRuntimeName.toLowerCase(Locale.US).contains("android");
/*     */   }
/*     */ 
/*     */   private BoltsExecutors()
/*     */   {
/*  29 */     this.background = (!isAndroidRuntime() ? Executors.newCachedThreadPool() : AndroidExecutors.newCachedThreadPool());
/*     */ 
/*  32 */     this.scheduled = Executors.newSingleThreadScheduledExecutor();
/*  33 */     this.immediate = new ImmediateExecutor(null);
/*     */   }
/*     */ 
/*     */   public static ExecutorService background()
/*     */   {
/*  40 */     return INSTANCE.background;
/*     */   }
/*     */ 
/*     */   static ScheduledExecutorService scheduled() {
/*  44 */     return INSTANCE.scheduled;
/*     */   }
/*     */ 
/*     */   static Executor immediate()
/*     */   {
/*  53 */     return INSTANCE.immediate;
/*     */   }
/*     */ 
/*     */   private static class ImmediateExecutor
/*     */     implements Executor
/*     */   {
/*     */     private static final int MAX_DEPTH = 15;
/*  64 */     private ThreadLocal<Integer> executionDepth = new ThreadLocal();
/*     */ 
/*     */     private int incrementDepth()
/*     */     {
/*  72 */       Integer oldDepth = (Integer)this.executionDepth.get();
/*  73 */       if (oldDepth == null) {
/*  74 */         oldDepth = Integer.valueOf(0);
/*     */       }
/*  76 */       int newDepth = oldDepth.intValue() + 1;
/*  77 */       this.executionDepth.set(Integer.valueOf(newDepth));
/*  78 */       return newDepth;
/*     */     }
/*     */ 
/*     */     private int decrementDepth()
/*     */     {
/*  87 */       Integer oldDepth = (Integer)this.executionDepth.get();
/*  88 */       if (oldDepth == null) {
/*  89 */         oldDepth = Integer.valueOf(0);
/*     */       }
/*  91 */       int newDepth = oldDepth.intValue() - 1;
/*  92 */       if (newDepth == 0)
/*  93 */         this.executionDepth.remove();
/*     */       else {
/*  95 */         this.executionDepth.set(Integer.valueOf(newDepth));
/*     */       }
/*  97 */       return newDepth;
/*     */     }
/*     */ 
/*     */     public void execute(Runnable command)
/*     */     {
/* 102 */       int depth = incrementDepth();
/*     */       try {
/* 104 */         if (depth <= 15)
/* 105 */           command.run();
/*     */         else
/* 107 */           BoltsExecutors.background().execute(command);
/*     */       }
/*     */       finally {
/* 110 */         decrementDepth();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.BoltsExecutors
 * JD-Core Version:    0.6.0
 */