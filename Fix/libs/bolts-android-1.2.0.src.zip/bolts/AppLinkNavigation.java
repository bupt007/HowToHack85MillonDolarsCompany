/*     */ package bolts;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.content.Intent;
/*     */ import android.content.pm.ApplicationInfo;
/*     */ import android.content.pm.PackageManager;
/*     */ import android.content.pm.ResolveInfo;
/*     */ import android.net.Uri;
/*     */ import android.net.Uri.Builder;
/*     */ import android.os.Bundle;
/*     */ import android.util.SparseArray;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class AppLinkNavigation
/*     */ {
/*     */   private static final String KEY_NAME_USER_AGENT = "user_agent";
/*     */   private static final String KEY_NAME_VERSION = "version";
/*     */   private static final String KEY_NAME_REFERER_APP_LINK = "referer_app_link";
/*     */   private static final String KEY_NAME_REFERER_APP_LINK_APP_NAME = "app_name";
/*     */   private static final String KEY_NAME_REFERER_APP_LINK_PACKAGE = "package";
/*     */   private static final String VERSION = "1.0";
/*     */   private static AppLinkResolver defaultResolver;
/*     */   private final AppLink appLink;
/*     */   private final Bundle extras;
/*     */   private final Bundle appLinkData;
/*     */ 
/*     */   public AppLinkNavigation(AppLink appLink, Bundle extras, Bundle appLinkData)
/*     */   {
/*  91 */     if (appLink == null) {
/*  92 */       throw new IllegalArgumentException("appLink must not be null.");
/*     */     }
/*  94 */     if (extras == null) {
/*  95 */       extras = new Bundle();
/*     */     }
/*  97 */     if (appLinkData == null) {
/*  98 */       appLinkData = new Bundle();
/*     */     }
/* 100 */     this.appLink = appLink;
/* 101 */     this.extras = extras;
/* 102 */     this.appLinkData = appLinkData;
/*     */   }
/*     */ 
/*     */   public AppLink getAppLink()
/*     */   {
/* 109 */     return this.appLink;
/*     */   }
/*     */ 
/*     */   public Bundle getAppLinkData()
/*     */   {
/* 120 */     return this.appLinkData;
/*     */   }
/*     */ 
/*     */   public Bundle getExtras()
/*     */   {
/* 131 */     return this.extras;
/*     */   }
/*     */ 
/*     */   private Bundle buildAppLinkDataForNavigation(Context context)
/*     */   {
/* 138 */     Bundle data = new Bundle();
/* 139 */     Bundle refererAppLinkData = new Bundle();
/* 140 */     if (context != null) {
/* 141 */       String refererAppPackage = context.getPackageName();
/* 142 */       if (refererAppPackage != null) {
/* 143 */         refererAppLinkData.putString("package", refererAppPackage);
/*     */       }
/* 145 */       ApplicationInfo appInfo = context.getApplicationInfo();
/* 146 */       if (appInfo != null) {
/* 147 */         String refererAppName = context.getString(appInfo.labelRes);
/* 148 */         if (refererAppName != null) {
/* 149 */           refererAppLinkData.putString("app_name", refererAppName);
/*     */         }
/*     */       }
/*     */     }
/* 153 */     data.putAll(getAppLinkData());
/* 154 */     data.putString("target_url", getAppLink().getSourceUrl().toString());
/* 155 */     data.putString("version", "1.0");
/* 156 */     data.putString("user_agent", "Bolts Android 1.2.0");
/* 157 */     data.putBundle("referer_app_link", refererAppLinkData);
/* 158 */     data.putBundle("extras", getExtras());
/* 159 */     return data;
/*     */   }
/*     */ 
/*     */   private Object getJSONValue(Object value)
/*     */     throws JSONException
/*     */   {
/* 166 */     if ((value instanceof Bundle))
/* 167 */       return getJSONForBundle((Bundle)value);
/* 168 */     if ((value instanceof CharSequence))
/* 169 */       return value.toString();
/* 170 */     if ((value instanceof List)) {
/* 171 */       JSONArray array = new JSONArray();
/* 172 */       for (Iterator i$ = ((List)value).iterator(); i$.hasNext(); ) { Object listValue = i$.next();
/* 173 */         array.put(getJSONValue(listValue));
/*     */       }
/* 175 */       return array;
/* 176 */     }if ((value instanceof SparseArray)) {
/* 177 */       JSONArray array = new JSONArray();
/* 178 */       SparseArray sparseValue = (SparseArray)value;
/* 179 */       for (int i = 0; i < sparseValue.size(); i++) {
/* 180 */         array.put(sparseValue.keyAt(i), getJSONValue(sparseValue.valueAt(i)));
/*     */       }
/* 182 */       return array;
/* 183 */     }if ((value instanceof Character))
/* 184 */       return value.toString();
/* 185 */     if ((value instanceof Boolean))
/* 186 */       return value;
/* 187 */     if ((value instanceof Number)) {
/* 188 */       if (((value instanceof Double)) || ((value instanceof Float))) {
/* 189 */         return Double.valueOf(((Number)value).doubleValue());
/*     */       }
/* 191 */       return Long.valueOf(((Number)value).longValue());
/*     */     }
/* 193 */     if ((value instanceof boolean[])) {
/* 194 */       JSONArray array = new JSONArray();
/* 195 */       for (boolean arrValue : (boolean[])(boolean[])value) {
/* 196 */         array.put(getJSONValue(Boolean.valueOf(arrValue)));
/*     */       }
/* 198 */       return array;
/* 199 */     }if ((value instanceof char[])) {
/* 200 */       JSONArray array = new JSONArray();
/* 201 */       for (char arrValue : (char[])(char[])value) {
/* 202 */         array.put(getJSONValue(Character.valueOf(arrValue)));
/*     */       }
/* 204 */       return array;
/* 205 */     }if ((value instanceof CharSequence[])) {
/* 206 */       JSONArray array = new JSONArray();
/* 207 */       for (CharSequence arrValue : (CharSequence[])(CharSequence[])value) {
/* 208 */         array.put(getJSONValue(arrValue));
/*     */       }
/* 210 */       return array;
/* 211 */     }if ((value instanceof double[])) {
/* 212 */       JSONArray array = new JSONArray();
/* 213 */       for (double arrValue : (double[])(double[])value) {
/* 214 */         array.put(getJSONValue(Double.valueOf(arrValue)));
/*     */       }
/* 216 */       return array;
/* 217 */     }if ((value instanceof float[])) {
/* 218 */       JSONArray array = new JSONArray();
/* 219 */       for (float arrValue : (float[])(float[])value) {
/* 220 */         array.put(getJSONValue(Float.valueOf(arrValue)));
/*     */       }
/* 222 */       return array;
/* 223 */     }if ((value instanceof int[])) {
/* 224 */       JSONArray array = new JSONArray();
/* 225 */       for (int arrValue : (int[])(int[])value) {
/* 226 */         array.put(getJSONValue(Integer.valueOf(arrValue)));
/*     */       }
/* 228 */       return array;
/* 229 */     }if ((value instanceof long[])) {
/* 230 */       JSONArray array = new JSONArray();
/* 231 */       for (long arrValue : (long[])(long[])value) {
/* 232 */         array.put(getJSONValue(Long.valueOf(arrValue)));
/*     */       }
/* 234 */       return array;
/* 235 */     }if ((value instanceof short[])) {
/* 236 */       JSONArray array = new JSONArray();
/* 237 */       for (short arrValue : (short[])(short[])value) {
/* 238 */         array.put(getJSONValue(Short.valueOf(arrValue)));
/*     */       }
/* 240 */       return array;
/* 241 */     }if ((value instanceof String[])) {
/* 242 */       JSONArray array = new JSONArray();
/* 243 */       for (String arrValue : (String[])(String[])value) {
/* 244 */         array.put(getJSONValue(arrValue));
/*     */       }
/* 246 */       return array;
/*     */     }
/* 248 */     return null;
/*     */   }
/*     */ 
/*     */   private JSONObject getJSONForBundle(Bundle bundle)
/*     */     throws JSONException
/*     */   {
/* 255 */     JSONObject root = new JSONObject();
/* 256 */     for (String key : bundle.keySet()) {
/* 257 */       root.put(key, getJSONValue(bundle.get(key)));
/*     */     }
/* 259 */     return root;
/*     */   }
/*     */ 
/*     */   public NavigationResult navigate(Context context)
/*     */   {
/* 269 */     PackageManager pm = context.getPackageManager();
/* 270 */     Bundle finalAppLinkData = buildAppLinkDataForNavigation(context);
/*     */ 
/* 272 */     Intent eligibleTargetIntent = null;
/* 273 */     for (AppLink.Target target : getAppLink().getTargets()) {
/* 274 */       Intent targetIntent = new Intent("android.intent.action.VIEW");
/* 275 */       if (target.getUrl() != null)
/* 276 */         targetIntent.setData(target.getUrl());
/*     */       else {
/* 278 */         targetIntent.setData(this.appLink.getSourceUrl());
/*     */       }
/* 280 */       targetIntent.setPackage(target.getPackageName());
/* 281 */       if (target.getClassName() != null) {
/* 282 */         targetIntent.setClassName(target.getPackageName(), target.getClassName());
/*     */       }
/* 284 */       targetIntent.putExtra("al_applink_data", finalAppLinkData);
/*     */ 
/* 286 */       ResolveInfo resolved = pm.resolveActivity(targetIntent, 65536);
/* 287 */       if (resolved != null) {
/* 288 */         eligibleTargetIntent = targetIntent;
/* 289 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 293 */     Intent outIntent = null;
/* 294 */     NavigationResult result = NavigationResult.FAILED;
/* 295 */     if (eligibleTargetIntent != null) {
/* 296 */       outIntent = eligibleTargetIntent;
/* 297 */       result = NavigationResult.APP;
/*     */     }
/*     */     else {
/* 300 */       Uri webUrl = getAppLink().getWebUrl();
/* 301 */       if (webUrl != null) {
/*     */         JSONObject appLinkDataJson;
/*     */         try { appLinkDataJson = getJSONForBundle(finalAppLinkData);
/*     */         } catch (JSONException e) {
/* 306 */           sendAppLinkNavigateEventBroadcast(context, eligibleTargetIntent, NavigationResult.FAILED, e);
/* 307 */           throw new RuntimeException(e);
/*     */         }
/* 309 */         webUrl = webUrl.buildUpon().appendQueryParameter("al_applink_data", appLinkDataJson.toString()).build();
/*     */ 
/* 312 */         outIntent = new Intent("android.intent.action.VIEW", webUrl);
/* 313 */         result = NavigationResult.WEB;
/*     */       }
/*     */     }
/*     */ 
/* 317 */     sendAppLinkNavigateEventBroadcast(context, outIntent, result, null);
/* 318 */     if (outIntent != null) {
/* 319 */       context.startActivity(outIntent);
/*     */     }
/* 321 */     return result;
/*     */   }
/*     */ 
/*     */   private void sendAppLinkNavigateEventBroadcast(Context context, Intent intent, NavigationResult type, JSONException e) {
/* 325 */     Map extraLoggingData = new HashMap();
/* 326 */     if (e != null) {
/* 327 */       extraLoggingData.put("error", e.getLocalizedMessage());
/*     */     }
/*     */ 
/* 330 */     extraLoggingData.put("success", type.isSucceeded() ? "1" : "0");
/* 331 */     extraLoggingData.put("type", type.getCode());
/*     */ 
/* 333 */     MeasurementEvent.sendBroadcastEvent(context, "al_nav_out", intent, extraLoggingData);
/*     */   }
/*     */ 
/*     */   public static void setDefaultResolver(AppLinkResolver resolver)
/*     */   {
/* 348 */     defaultResolver = resolver;
/*     */   }
/*     */ 
/*     */   public static AppLinkResolver getDefaultResolver()
/*     */   {
/* 359 */     return defaultResolver;
/*     */   }
/*     */ 
/*     */   private static AppLinkResolver getResolver(Context context) {
/* 363 */     if (getDefaultResolver() != null) {
/* 364 */       return getDefaultResolver();
/*     */     }
/* 366 */     return new WebViewAppLinkResolver(context);
/*     */   }
/*     */ 
/*     */   public static NavigationResult navigate(Context context, AppLink appLink)
/*     */   {
/* 377 */     return new AppLinkNavigation(appLink, null, null).navigate(context);
/*     */   }
/*     */ 
/*     */   public static Task<NavigationResult> navigateInBackground(Context context, Uri destination, AppLinkResolver resolver)
/*     */   {
/* 392 */     return resolver.getAppLinkFromUrlInBackground(destination).onSuccess(new Continuation(context)
/*     */     {
/*     */       public AppLinkNavigation.NavigationResult then(Task<AppLink> task) throws Exception
/*     */       {
/* 396 */         return AppLinkNavigation.navigate(this.val$context, (AppLink)task.getResult());
/*     */       }
/*     */     }
/*     */     , Task.UI_THREAD_EXECUTOR);
/*     */   }
/*     */ 
/*     */   public static Task<NavigationResult> navigateInBackground(Context context, URL destination, AppLinkResolver resolver)
/*     */   {
/* 413 */     return navigateInBackground(context, Uri.parse(destination.toString()), resolver);
/*     */   }
/*     */ 
/*     */   public static Task<NavigationResult> navigateInBackground(Context context, String destinationUrl, AppLinkResolver resolver)
/*     */   {
/* 428 */     return navigateInBackground(context, Uri.parse(destinationUrl), resolver);
/*     */   }
/*     */ 
/*     */   public static Task<NavigationResult> navigateInBackground(Context context, Uri destination)
/*     */   {
/* 441 */     return navigateInBackground(context, destination, getResolver(context));
/*     */   }
/*     */ 
/*     */   public static Task<NavigationResult> navigateInBackground(Context context, URL destination)
/*     */   {
/* 456 */     return navigateInBackground(context, destination, getResolver(context));
/*     */   }
/*     */ 
/*     */   public static Task<NavigationResult> navigateInBackground(Context context, String destinationUrl)
/*     */   {
/* 471 */     return navigateInBackground(context, destinationUrl, getResolver(context));
/*     */   }
/*     */ 
/*     */   public static enum NavigationResult
/*     */   {
/*  55 */     FAILED("failed", false), 
/*     */ 
/*  59 */     WEB("web", true), 
/*     */ 
/*  63 */     APP("app", true);
/*     */ 
/*     */     private String code;
/*     */     private boolean succeeded;
/*     */ 
/*  68 */     public String getCode() { return this.code; }
/*     */ 
/*     */     public boolean isSucceeded() {
/*  71 */       return this.succeeded;
/*     */     }
/*     */     private NavigationResult(String code, boolean success) {
/*  74 */       this.code = code;
/*  75 */       this.succeeded = success;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.AppLinkNavigation
 * JD-Core Version:    0.6.0
 */