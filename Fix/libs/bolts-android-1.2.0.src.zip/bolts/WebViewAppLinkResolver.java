/*     */ package bolts;
/*     */ 
/*     */ import android.content.Context;
/*     */ import android.net.Uri;
/*     */ import android.webkit.JavascriptInterface;
/*     */ import android.webkit.WebSettings;
/*     */ import android.webkit.WebView;
/*     */ import android.webkit.WebViewClient;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class WebViewAppLinkResolver
/*     */   implements AppLinkResolver
/*     */ {
/*     */   private final Context context;
/*     */   private static final String TAG_EXTRACTION_JAVASCRIPT = "javascript:boltsWebViewAppLinkResolverResult.setValue((function() {  var metaTags = document.getElementsByTagName('meta');  var results = [];  for (var i = 0; i < metaTags.length; i++) {    var property = metaTags[i].getAttribute('property');    if (property && property.substring(0, 'al:'.length) === 'al:') {      var tag = { \"property\": metaTags[i].getAttribute('property') };      if (metaTags[i].hasAttribute('content')) {        tag['content'] = metaTags[i].getAttribute('content');      }      results.push(tag);    }  }  return JSON.stringify(results);})())";
/*     */   private static final String PREFER_HEADER = "Prefer-Html-Meta-Tags";
/*     */   private static final String META_TAG_PREFIX = "al";
/*     */   private static final String KEY_AL_VALUE = "value";
/*     */   private static final String KEY_APP_NAME = "app_name";
/*     */   private static final String KEY_CLASS = "class";
/*     */   private static final String KEY_PACKAGE = "package";
/*     */   private static final String KEY_URL = "url";
/*     */   private static final String KEY_SHOULD_FALLBACK = "should_fallback";
/*     */   private static final String KEY_WEB_URL = "url";
/*     */   private static final String KEY_WEB = "web";
/*     */   private static final String KEY_ANDROID = "android";
/*     */ 
/*     */   public WebViewAppLinkResolver(Context context)
/*     */   {
/*  49 */     this.context = context;
/*     */   }
/*     */ 
/*     */   public Task<AppLink> getAppLinkFromUrlInBackground(Uri url)
/*     */   {
/*  83 */     Capture content = new Capture();
/*  84 */     Capture contentType = new Capture();
/*  85 */     return Task.callInBackground(new Callable(url, content, contentType)
/*     */     {
/*     */       public Void call() throws Exception {
/*  88 */         URL currentURL = new URL(this.val$url.toString());
/*  89 */         URLConnection connection = null;
/*  90 */         while (currentURL != null)
/*     */         {
/*  92 */           connection = currentURL.openConnection();
/*  93 */           if ((connection instanceof HttpURLConnection))
/*     */           {
/*  96 */             ((HttpURLConnection)connection).setInstanceFollowRedirects(true);
/*     */           }
/*  98 */           connection.setRequestProperty("Prefer-Html-Meta-Tags", "al");
/*  99 */           connection.connect();
/*     */ 
/* 101 */           if ((connection instanceof HttpURLConnection)) {
/* 102 */             HttpURLConnection httpConnection = (HttpURLConnection)connection;
/* 103 */             if ((httpConnection.getResponseCode() >= 300) && (httpConnection.getResponseCode() < 400)) {
/* 104 */               currentURL = new URL(httpConnection.getHeaderField("Location"));
/* 105 */               httpConnection.disconnect();
/*     */             } else {
/* 107 */               currentURL = null;
/*     */             }
/* 109 */             continue;
/* 110 */           }currentURL = null;
/*     */         }
/*     */ 
/*     */         try
/*     */         {
/* 115 */           this.val$content.set(WebViewAppLinkResolver.access$300(connection));
/* 116 */           this.val$contentType.set(connection.getContentType());
/*     */         } finally {
/* 118 */           if ((connection instanceof HttpURLConnection)) {
/* 119 */             ((HttpURLConnection)connection).disconnect();
/*     */           }
/*     */         }
/* 122 */         return null;
/*     */       }
/*     */     }).onSuccessTask(new Continuation(contentType, url, content)
/*     */     {
/*     */       public Task<JSONArray> then(Task<Void> task)
/*     */         throws Exception
/*     */       {
/* 128 */         Task.TaskCompletionSource tcs = Task.create();
/* 129 */         WebView webView = new WebView(WebViewAppLinkResolver.this.context);
/* 130 */         webView.getSettings().setJavaScriptEnabled(true);
/* 131 */         webView.setNetworkAvailable(false);
/* 132 */         webView.setWebViewClient(new WebViewClient() {
/* 133 */           private boolean loaded = false;
/*     */ 
/*     */           private void runJavaScript(WebView view) {
/* 136 */             if (!this.loaded)
/*     */             {
/* 139 */               this.loaded = true;
/* 140 */               view.loadUrl("javascript:boltsWebViewAppLinkResolverResult.setValue((function() {  var metaTags = document.getElementsByTagName('meta');  var results = [];  for (var i = 0; i < metaTags.length; i++) {    var property = metaTags[i].getAttribute('property');    if (property && property.substring(0, 'al:'.length) === 'al:') {      var tag = { \"property\": metaTags[i].getAttribute('property') };      if (metaTags[i].hasAttribute('content')) {        tag['content'] = metaTags[i].getAttribute('content');      }      results.push(tag);    }  }  return JSON.stringify(results);})())");
/*     */             }
/*     */           }
/*     */ 
/*     */           public void onPageFinished(WebView view, String url)
/*     */           {
/* 146 */             super.onPageFinished(view, url);
/* 147 */             runJavaScript(view);
/*     */           }
/*     */ 
/*     */           public void onLoadResource(WebView view, String url)
/*     */           {
/* 152 */             super.onLoadResource(view, url);
/* 153 */             runJavaScript(view);
/*     */           }
/*     */         });
/* 157 */         webView.addJavascriptInterface(new Object(tcs) {
/*     */           @JavascriptInterface
/*     */           public void setValue(String value) {
/*     */             try { this.val$tcs.trySetResult(new JSONArray(value));
/*     */             } catch (JSONException e) {
/* 163 */               this.val$tcs.trySetError(e);
/*     */             }
/*     */           }
/*     */         }
/*     */         , "boltsWebViewAppLinkResolverResult");
/*     */ 
/* 167 */         String inferredContentType = null;
/* 168 */         if (this.val$contentType.get() != null) {
/* 169 */           inferredContentType = ((String)this.val$contentType.get()).split(";")[0];
/*     */         }
/* 171 */         webView.loadDataWithBaseURL(this.val$url.toString(), (String)this.val$content.get(), inferredContentType, null, null);
/*     */ 
/* 176 */         return tcs.getTask();
/*     */       }
/*     */     }
/*     */     , Task.UI_THREAD_EXECUTOR).onSuccess(new Continuation(url)
/*     */     {
/*     */       public AppLink then(Task<JSONArray> task)
/*     */         throws Exception
/*     */       {
/* 181 */         Map alData = WebViewAppLinkResolver.access$000((JSONArray)task.getResult());
/* 182 */         AppLink appLink = WebViewAppLinkResolver.access$100(alData, this.val$url);
/* 183 */         return appLink;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private static Map<String, Object> parseAlData(JSONArray dataArray)
/*     */     throws JSONException
/*     */   {
/* 194 */     HashMap al = new HashMap();
/* 195 */     for (int i = 0; i < dataArray.length(); i++) {
/* 196 */       JSONObject tag = dataArray.getJSONObject(i);
/* 197 */       String name = tag.getString("property");
/* 198 */       String[] nameComponents = name.split(":");
/* 199 */       if (!nameComponents[0].equals("al")) {
/*     */         continue;
/*     */       }
/* 202 */       Map root = al;
/* 203 */       for (int j = 1; j < nameComponents.length; j++)
/*     */       {
/* 205 */         List children = (List)root.get(nameComponents[j]);
/*     */ 
/* 207 */         if (children == null) {
/* 208 */           children = new ArrayList();
/* 209 */           root.put(nameComponents[j], children);
/*     */         }
/* 211 */         Map child = children.size() > 0 ? (Map)children.get(children.size() - 1) : null;
/* 212 */         if ((child == null) || (j == nameComponents.length - 1)) {
/* 213 */           child = new HashMap();
/* 214 */           children.add(child);
/*     */         }
/* 216 */         root = child;
/*     */       }
/* 218 */       if (tag.has("content")) {
/* 219 */         if (tag.isNull("content"))
/* 220 */           root.put("value", null);
/*     */         else {
/* 222 */           root.put("value", tag.getString("content"));
/*     */         }
/*     */       }
/*     */     }
/* 226 */     return al;
/*     */   }
/*     */ 
/*     */   private static List<Map<String, Object>> getAlList(Map<String, Object> map, String key)
/*     */   {
/* 231 */     List result = (List)map.get(key);
/* 232 */     if (result == null) {
/* 233 */       return Collections.emptyList();
/*     */     }
/* 235 */     return result;
/*     */   }
/*     */ 
/*     */   private static AppLink makeAppLinkFromAlData(Map<String, Object> appLinkDict, Uri destination)
/*     */   {
/* 240 */     List targets = new ArrayList();
/* 241 */     List platformMapList = (List)appLinkDict.get("android");
/*     */ 
/* 243 */     if (platformMapList == null) {
/* 244 */       platformMapList = Collections.emptyList();
/*     */     }
/* 246 */     for (Map platformMap : platformMapList)
/*     */     {
/* 249 */       List urls = getAlList(platformMap, "url");
/* 250 */       List packages = getAlList(platformMap, "package");
/* 251 */       List classes = getAlList(platformMap, "class");
/* 252 */       List appNames = getAlList(platformMap, "app_name");
/*     */ 
/* 254 */       int maxCount = Math.max(urls.size(), Math.max(packages.size(), Math.max(classes.size(), appNames.size())));
/*     */ 
/* 256 */       for (int i = 0; i < maxCount; i++) {
/* 257 */         String urlString = (String)(String)(urls.size() > i ? ((Map)urls.get(i)).get("value") : null);
/*     */ 
/* 259 */         Uri url = tryCreateUrl(urlString);
/* 260 */         String packageName = (String)(String)(packages.size() > i ? ((Map)packages.get(i)).get("value") : null);
/*     */ 
/* 262 */         String className = (String)(String)(classes.size() > i ? ((Map)classes.get(i)).get("value") : null);
/*     */ 
/* 264 */         String appName = (String)(String)(appNames.size() > i ? ((Map)appNames.get(i)).get("value") : null);
/*     */ 
/* 266 */         AppLink.Target target = new AppLink.Target(packageName, className, url, appName);
/* 267 */         targets.add(target);
/*     */       }
/*     */     }
/*     */ 
/* 271 */     Uri webUrl = destination;
/* 272 */     List webMapList = (List)appLinkDict.get("web");
/* 273 */     if ((webMapList != null) && (webMapList.size() > 0)) {
/* 274 */       Map webMap = (Map)webMapList.get(0);
/* 275 */       List urls = (List)webMap.get("url");
/* 276 */       List shouldFallbacks = (List)webMap.get("should_fallback");
/*     */ 
/* 278 */       if ((shouldFallbacks != null) && (shouldFallbacks.size() > 0)) {
/* 279 */         String shouldFallbackString = (String)((Map)shouldFallbacks.get(0)).get("value");
/* 280 */         if (Arrays.asList(new String[] { "no", "false", "0" }).contains(shouldFallbackString.toLowerCase())) {
/* 281 */           webUrl = null;
/*     */         }
/*     */       }
/* 284 */       if ((webUrl != null) && (urls != null) && (urls.size() > 0)) {
/* 285 */         String webUrlString = (String)((Map)urls.get(0)).get("value");
/* 286 */         webUrl = tryCreateUrl(webUrlString);
/*     */       }
/*     */     }
/* 289 */     return new AppLink(destination, targets, webUrl);
/*     */   }
/*     */ 
/*     */   private static Uri tryCreateUrl(String urlString) {
/* 293 */     if (urlString == null) {
/* 294 */       return null;
/*     */     }
/* 296 */     return Uri.parse(urlString);
/*     */   }
/*     */ 
/*     */   private static String readFromConnection(URLConnection connection)
/*     */     throws IOException
/*     */   {
/*     */     InputStream stream;
/* 305 */     if ((connection instanceof HttpURLConnection)) {
/* 306 */       HttpURLConnection httpConnection = (HttpURLConnection)connection;
/*     */       try {
/* 308 */         stream = connection.getInputStream();
/*     */       } catch (Exception e) {
/* 310 */         InputStream stream = httpConnection.getErrorStream();
/*     */       }
/*     */     } else {
/* 313 */       stream = connection.getInputStream();
/*     */     }
/*     */     try {
/* 316 */       ByteArrayOutputStream output = new ByteArrayOutputStream();
/* 317 */       byte[] buffer = new byte[1024];
/* 318 */       int read = 0;
/* 319 */       while ((read = stream.read(buffer)) != -1) {
/* 320 */         output.write(buffer, 0, read);
/*     */       }
/* 322 */       String charset = connection.getContentEncoding();
/* 323 */       if (charset == null) {
/* 324 */         mimeType = connection.getContentType();
/* 325 */         String[] parts = mimeType.split(";");
/* 326 */         for (String part : parts) {
/* 327 */           part = part.trim();
/* 328 */           if (part.startsWith("charset=")) {
/* 329 */             charset = part.substring("charset=".length());
/* 330 */             break;
/*     */           }
/*     */         }
/* 333 */         if (charset == null) {
/* 334 */           charset = "UTF-8";
/*     */         }
/*     */       }
/* 337 */       String mimeType = new String(output.toByteArray(), charset);
/*     */       return mimeType; } finally { stream.close(); } throw localObject;
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.WebViewAppLinkResolver
 * JD-Core Version:    0.6.0
 */