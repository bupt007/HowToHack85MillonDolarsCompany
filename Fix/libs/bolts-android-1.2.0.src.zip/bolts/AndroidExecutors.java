/*     */ package bolts;
/*     */ 
/*     */ import android.annotation.SuppressLint;
/*     */ import android.os.Build.VERSION;
/*     */ import android.os.Handler;
/*     */ import android.os.Looper;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ final class AndroidExecutors
/*     */ {
/*  40 */   private static final AndroidExecutors INSTANCE = new AndroidExecutors();
/*     */   private final Executor uiThread;
/*  58 */   private static final int CPU_COUNT = Runtime.getRuntime().availableProcessors();
/*  59 */   static final int CORE_POOL_SIZE = CPU_COUNT + 1;
/*  60 */   static final int MAX_POOL_SIZE = CPU_COUNT * 2 + 1;
/*     */   static final long KEEP_ALIVE_TIME = 1L;
/*     */ 
/*     */   private AndroidExecutors()
/*     */   {
/*  45 */     this.uiThread = new UIThreadExecutor(null);
/*     */   }
/*     */ 
/*     */   public static ExecutorService newCachedThreadPool()
/*     */   {
/*  74 */     ThreadPoolExecutor executor = new ThreadPoolExecutor(CORE_POOL_SIZE, MAX_POOL_SIZE, 1L, TimeUnit.SECONDS, new LinkedBlockingQueue());
/*     */ 
/*  80 */     allowCoreThreadTimeout(executor, true);
/*     */ 
/*  82 */     return executor;
/*     */   }
/*     */ 
/*     */   public static ExecutorService newCachedThreadPool(ThreadFactory threadFactory)
/*     */   {
/*  97 */     ThreadPoolExecutor executor = new ThreadPoolExecutor(CORE_POOL_SIZE, MAX_POOL_SIZE, 1L, TimeUnit.SECONDS, new LinkedBlockingQueue(), threadFactory);
/*     */ 
/* 104 */     allowCoreThreadTimeout(executor, true);
/*     */ 
/* 106 */     return executor;
/*     */   }
/*     */ 
/*     */   @SuppressLint({"NewApi"})
/*     */   public static void allowCoreThreadTimeout(ThreadPoolExecutor executor, boolean value)
/*     */   {
/* 120 */     if (Build.VERSION.SDK_INT >= 9)
/* 121 */       executor.allowCoreThreadTimeOut(value);
/*     */   }
/*     */ 
/*     */   public static Executor uiThread()
/*     */   {
/* 129 */     return INSTANCE.uiThread;
/*     */   }
/*     */ 
/*     */   private static class UIThreadExecutor
/*     */     implements Executor
/*     */   {
/*     */     public void execute(Runnable command)
/*     */     {
/* 138 */       new Handler(Looper.getMainLooper()).post(command);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.AndroidExecutors
 * JD-Core Version:    0.6.0
 */