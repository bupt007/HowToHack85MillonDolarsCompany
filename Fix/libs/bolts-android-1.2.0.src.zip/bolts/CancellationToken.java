/*    */ package bolts;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.concurrent.CancellationException;
/*    */ 
/*    */ public class CancellationToken
/*    */ {
/* 31 */   private final Object lock = new Object();
/*    */   private boolean cancellationRequested;
/*    */ 
/*    */   public boolean isCancellationRequested()
/*    */   {
/* 41 */     synchronized (this.lock) {
/* 42 */       return this.cancellationRequested;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void throwIfCancellationRequested()
/*    */     throws CancellationException
/*    */   {
/* 51 */     synchronized (this.lock) {
/* 52 */       if (this.cancellationRequested)
/* 53 */         throw new CancellationException();
/*    */     }
/*    */   }
/*    */ 
/*    */   boolean tryCancel()
/*    */   {
/* 59 */     synchronized (this.lock) {
/* 60 */       if (this.cancellationRequested) {
/* 61 */         return false;
/*    */       }
/*    */ 
/* 64 */       this.cancellationRequested = true;
/*    */     }
/* 66 */     return true;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 71 */     return String.format(Locale.US, "%s@%s[cancellationRequested=%s]", new Object[] { getClass().getName(), Integer.toHexString(hashCode()), Boolean.toString(this.cancellationRequested) });
/*    */   }
/*    */ }

/* Location:           E:\Git\HowToHack85MillonDolarsCompany\Fix\libs\bolts-android-1.2.0.jar
 * Qualified Name:     bolts.CancellationToken
 * JD-Core Version:    0.6.0
 */